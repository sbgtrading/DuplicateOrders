#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using System.Collections.Concurrent;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    #region Category Order
    [Gui.CategoryOrder("Data", 1)]
	[Gui.CategoryOrder("Composite Profile Settings", 2)]
	[Gui.CategoryOrder("Static Profile Settings", 3)]
	[Gui.CategoryOrder("Real Time Profile Settings", 4)]
    [Gui.CategoryOrder("VWAP Settings", 5)]
    [Gui.CategoryOrder("CWAP Settings", 6)]
    [Gui.CategoryOrder("Cluster Settings", 7)]
	[Gui.CategoryOrder("Display Settings", 8)]
	[Gui.CategoryOrder("Indicator Version", 20)] //VERY IMPORTANT - INDI VERSION
	#endregion

	public class ARC_AnchoredVolume : Indicator, ICustomTypeDescriptor
	{
		#region Licensing
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		private bool IsDebug = false;
		string ModuleName = "AnchoredVolume";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler
		{
			static System.Collections.Generic.SortedDictionary<string, long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string, long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire)
			{
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck)
			{
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg)
			{
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach (string keymsg in keys)
				{
					if (keymsg.CompareTo(new_msg) == 0)
					{
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if (ts.TotalMinutes < 2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>() { "22344", "21140", "21868", "25900", "27405"};//27405 is Annual Membership and PropTrader Mastermind 21868
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                StringBuilder sb = new StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion
		#endregion

		#region Indicators, Series and Floating Variables
		//properties that govern reset
		private string _sPreviousIntrument = string.Empty;
        private string _sPreviousBars = string.Empty;
		private string _sChartType = string.Empty;
		private int _iChartInterval = -1;
		private int _iTicksPerLevel = -1;
		private int _iClusterTicks = -1;
        //int
        private int _iEditingProfileStatic = -1;
		private int _iEditingProfileRealTime = -1;
		//double
		//bool
		private bool _bIsToolBarButtonAdded = false;
		private bool _bWorking = true;
		private bool _bIsChart = true;
		private bool _bAa = false;
		private bool _bPannelActive = false;
		private bool _bProfileOnStatic = false;
		private bool _bProfileOnStaticMultiple = false;
		private bool _bProfileOnRealTime = false;
		private bool _bRebuildRealTime = false;
		private bool _bRebuildStatic = false;
		private bool _bBarsAreGood = false;
		private bool _bNewWeek = false;
		private bool _bNewMonth = false;
		//string
		private string _sThisName = "ARC_AnchoredVolume";
		private string _sToolbarName = "ARCAVToolBar", uID;
		private string _sStartDrawText = "Start Draw";
		private string _sStopDrawText = "Stop Draw";
		//other
		private DateTime _dtResetTime = DateTime.MinValue;
		private TimeSpan _tsDayResetTime = new TimeSpan();
		private TimeSpan _tsNextInterval = new TimeSpan();
		private BarDetails _LTF_Bar = null;
		private BarInfo _CTF_Bar = null;
		private Profile _BuildingProfileStatic = null;
		private Profile _BuildingProfileRealTime = null;
		private Profile _BuildingProfileComposite = null;
		private ChartControl _ChartControl = null;
		private ChartScale _ChartScale = null;
		private float PanelWidth = 0f;
		private ProfileSettings _HistoricalProfileSettings = null;
		private ProfileSettings _RealTimeProfileSettings = null;
		private ProfileSettings _CompositeProfileSettings = null;
		private VWAPSettings _VWAPSettings = null;
		private VWAPSettings _CWAPSettings = null;
		private ClusterSettings _ClusterSettings = null;
		private GeneralSettings _GeneralSettings = null;
        private ConcurrentDictionary<int, BarInfo> _dicAllBars = new ConcurrentDictionary<int, BarInfo>();
		private List<Profile> _lstRealTimeProfiles = new List<Profile>();
		private List<Profile> _lstStaticProfiles = new List<Profile>();
		private List<Profile> _lstCompositeProfiles = new List<Profile>(); 

		#region Controls Variables
		private Menu _mnuControlContainer = null;
		private Grid _grdIndyToolbar;
		//private Button gCmdup;
		//private Button gCmddw;

		#endregion

		#endregion

		#region Controls
		//Chart Basics, Buttons and other
		private Chart _wChart = null;
		private Grid _gChart = null;

		//Controls
		private ConcurrentDictionary<string, Button> _dicButtons = new ConcurrentDictionary<string, Button>();
        private ConcurrentDictionary<string, Grid> _dicGrids = new ConcurrentDictionary<string, Grid>();
        private ConcurrentDictionary<string, Separator> _dicSeparators = new ConcurrentDictionary<string, Separator>();
        private ConcurrentDictionary<string, MenuItem> _dicMenuItems = new ConcurrentDictionary<string, MenuItem>();
        private ConcurrentDictionary<string, TextBox> _dicTextBoxes = new ConcurrentDictionary<string, TextBox>();
        #endregion

        #region On State Change
        protected override void OnStateChange()
		{
			#region Set Defaults
			if (State == State.SetDefaults)
			{
				#region Default Crap
				Description = @"  ";
				Name = _sThisName;
				Calculate = Calculate.OnBarClose;
				IsOverlay = true;
				DisplayInDataBox = true;
				DrawOnPricePanel = true;
				DrawHorizontalGridLines = true;
				DrawVerticalGridLines = true;
				PaintPriceMarkers = true;
				ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive = true;
				#endregion

				#region Indicator Settings

                #region Data
                ChartType = "Minute";
				ChartInterval = 5;
				TicksPerLevel = 1;
				ValueAreaLevelsPerStep = 2;
                #endregion

                #region Composite Profile
                ShowComposite = false;
				ShowCurrentProfile = true;
				ShowHistorical = true;
                CompositeType = "Day";
                StartTimeHrs = 9;
                StartTimeMin = 30;
                IntervalMin = 60;
				VAPercentComposite = 69;
                VAOpacComposite = 70;
                ShowVALComposite = true;
                ShowVAHComposite = true;
                ShowPOCComposite = true;
                ShowProfileComposite = true;
                ShowExtremesComposite = true;
                ShowTextComposite = true;
                NormalOpacComposite = 30;
                ProfilePercentComposite = 40;
				ProfilePercentCompositeRightSide = 15;
                TextHistProfileComposite = new SimpleFont("Century Gothic", 14) { Bold = true };
                ExtremesComposite = new Stroke(Brushes.Black, DashStyleHelper.Dash, 2);
                POCComposite = new Stroke(Brushes.Yellow, DashStyleHelper.Dash, 2);
                VAHComposite = new Stroke(Brushes.Maroon, DashStyleHelper.Dash, 2);
                VALComposite = new Stroke(Brushes.Navy, DashStyleHelper.Dash, 2);
                ProfileComposite = new Stroke(Brushes.LightSkyBlue, DashStyleHelper.Dash, 1);
				#endregion

				#region Static Profile
                VAPercentStatic = 69;
                VAOpacHisto = 70;
                ShowVALHisto = true;
                ShowVAHHisto = true;
                ShowPOCHisto = true;
                ShowProfileHisto = true;
                ShowExtremesHisto = true;
				ShowTextStatic = true; 
                NormalOpacHisto = 30;
                ProfilePercentHisto = 40;
                TextHistProfileHisto = new SimpleFont("Century Gothic", 14) { Bold = true };
                Building = new Stroke(Brushes.Cornsilk, DashStyleHelper.Solid, 2);
                ExtremesHisto = new Stroke(Brushes.Black, DashStyleHelper.Dash, 2);
                POCHisto = new Stroke(Brushes.Yellow, DashStyleHelper.Dash, 2);
                VAHHisto = new Stroke(Brushes.Maroon, DashStyleHelper.Dash, 2);
                VALHisto = new Stroke(Brushes.Navy, DashStyleHelper.Dash, 2);
                ProfileHisto = new Stroke(Brushes.LightSkyBlue, DashStyleHelper.Dash, 1);
                #endregion

                #region RealTime Profile
                VAPercentRealTime = 69;
                VAOpacCurrentBar = 70;
                ShowVALCurrentBar = true;
                ShowVAHCurrentBar = true;
                ShowPOCCurrentBar = true;
                ShowProfileCurrentBar = true;
                ShowExtremesCurrentBar = true;
                ShowTextRealTime = true;
                DrawOnLeft = false;
                NormalOpacCurrentBar = 30;
                ProfilePercentCurrentBar = 10;
				ProfilePercentCurrentBarRightSide = 10;
				TextHistProfileCurrentBar = new SimpleFont("Century Gothic", 14) { Bold = true };
                ExtremesCurrentBar = new Stroke(Brushes.Black, DashStyleHelper.Dash, 2);
                POCCurrentBar = new Stroke(Brushes.Yellow, DashStyleHelper.Dash, 2);
                VAHCurrentBar = new Stroke(Brushes.Maroon, DashStyleHelper.Dash, 2);
                VALCurrentBar = new Stroke(Brushes.Navy, DashStyleHelper.Dash, 2);
                ProfileCurrentBar = new Stroke(Brushes.LightSkyBlue, DashStyleHelper.Dash, 1);
                #endregion

                #region VWAP
                ShowVWAP = true;
                Deviation1VWAP = 1;
                Deviation2VWAP = 2;
                Deviation3VWAP = 3;
                VWAPDeviationVWAP = "None";
                OpacityVWAP = 15;
                VwapVWAP = new Stroke(Brushes.Cyan, DashStyleHelper.Solid, 2);
                AboveVWAP = new Stroke(Brushes.Maroon, DashStyleHelper.Solid, 1);
                BelowVWAP = new Stroke(Brushes.DarkGreen, DashStyleHelper.Solid, 1);
                InnerZoneVWAP = Brushes.Green;
                MidZoneVWAP = Brushes.Red;
                OuterZoneVWAP = Brushes.Blue;
                ShowShadingVWAP = true;
                DrawLastValueVWAP = false;
                ShowTextVWAP = true;
                TextFontVWAP = new SimpleFont("Century Gothic", 14) { Bold = true };
                #endregion

                #region CWAP
                ShowCWAP = false;
                Deviation1CWAP = 0.25;
                Deviation2CWAP = 0.5;
                Deviation3CWAP = 1;
                VWAPDeviationCWAP = "Deviation 1";
                OpacityCWAP = 15;
                VwapCWAP = new Stroke(Brushes.Lime, DashStyleHelper.Dash, 2);
                AboveCWAP = new Stroke(Brushes.Black, DashStyleHelper.Solid, 1);
                BelowCWAP = new Stroke(Brushes.Black, DashStyleHelper.Solid, 1);
                InnerZoneCWAP = Brushes.Green;
                MidZoneCWAP = Brushes.Red;
                OuterZoneCWAP = Brushes.Blue;
                ShowShadingCWAP = true;
                DrawLastValueCWAP = false;
                ShowTextCWAP = true;
                TextFontCWAP = new SimpleFont("Century Gothic", 14) { Bold = true };
                #endregion

                #region Cluster
                ClusterTicks = 3;
                Opacity = 70;
                ShowBorder = true;
                ShowShading = true;
                Stroke = new Stroke(Brushes.Black, DashStyleHelper.Solid, 1);
                Show = "None";
                #endregion

                #region Display Settings
                ButtonText = "AVP";
                //DisplayHistogram = true;
                //ExtendLevels = true;
                #endregion

                #endregion
            }
            #endregion

            #region Other States

            #region State Configure
            else if (State == State.Configure)
			{
#if DoLicense
//				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				//IsDebug = System.IO.File.Exists(@"c:\222222222222.txt");
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				IsVisible = true;
//				RemoveDrawObject("lictext");
#endif
				uID = Guid.NewGuid().ToString();
				uID = uID.Replace('-', 'N');
                if (ChartType == "Tick")
					AddDataSeries(BarsPeriodType.Tick, ChartInterval);
				else if (ChartType == "Second")
					AddDataSeries(BarsPeriodType.Second, ChartInterval);
				else if (ChartType == "Minute")
					AddDataSeries(BarsPeriodType.Minute, ChartInterval);
			}
			#endregion

			#region Other States
			else if (State == State.DataLoaded)
			{
				#region VWAP
				VWAPDeviation vwapDeviation = VWAPDeviation.None;
				if(VWAPDeviationVWAP == "Deviation 1")
                    vwapDeviation = VWAPDeviation.Deviation1;
				else if (VWAPDeviationVWAP == "Deviation 2")
					vwapDeviation = VWAPDeviation.Deviation2;
				else if (VWAPDeviationVWAP == "Deviation 3")
					vwapDeviation = VWAPDeviation.Deviation3;
				_VWAPSettings = new VWAPSettings()
				{
					Show = ShowVWAP,
					Deviation1 = Deviation1VWAP,
					Deviation2 = Deviation2VWAP,
					Deviation3 = Deviation3VWAP,
					VWAPDeviation = vwapDeviation,
					Opacity = OpacityVWAP,
					Vwap = VwapVWAP,
					Above = AboveVWAP,
					Below = BelowVWAP,
					InnerZone = InnerZoneVWAP,
					MidZone = MidZoneVWAP,
					OuterZone = OuterZoneVWAP,
					ShowShading = ShowShadingVWAP,
					DrawLastValue = DrawLastValueVWAP,
					ShowText = ShowTextVWAP,
					TextFont = TextFontVWAP
                };
                #endregion

                #region CWAP
                VWAPDeviation cwapDeviation = VWAPDeviation.None;
                if (VWAPDeviationCWAP == "Deviation 1")
                    cwapDeviation = VWAPDeviation.Deviation1;
                else if (VWAPDeviationCWAP == "Deviation 2")
                    cwapDeviation = VWAPDeviation.Deviation2;
                else if (VWAPDeviationCWAP == "Deviation 3")
                    cwapDeviation = VWAPDeviation.Deviation3;
                _CWAPSettings = new VWAPSettings()
				{
					Show = ShowCWAP,
					Deviation1 = Deviation1CWAP,
					Deviation2 = Deviation2CWAP,
					Deviation3 = Deviation3CWAP,
					VWAPDeviation = cwapDeviation,
					Opacity = OpacityCWAP,
					Vwap = VwapCWAP,
					Above = AboveCWAP,
					Below = BelowCWAP,
					InnerZone = InnerZoneCWAP,
					MidZone = MidZoneCWAP,
					OuterZone = OuterZoneCWAP,
					ShowShading = ShowShadingCWAP,
					DrawLastValue = DrawLastValueCWAP,
					ShowText = ShowTextCWAP,
					TextFont = TextFontCWAP
                };
				#endregion

				#region Composite Profile
				_tsDayResetTime = new TimeSpan(StartTimeHrs, StartTimeMin, 0);
				_tsNextInterval = new TimeSpan(IntervalMin * TimeSpan.TicksPerMinute);
                _CompositeProfileSettings = new ProfileSettings()
                {
                    Show = ShowComposite,
					ValueAreaPercent = VAPercentComposite,
                    IsRight = false,
                    VAOpac = VAOpacComposite,
                    IsHistorical = true,
                    ShowVAL = ShowVALComposite,
                    ShowVAH = ShowVAHComposite,
                    ShowPOC = ShowPOCComposite,
                    ShowProfile = ShowProfileComposite,
                    ShowExtremes = ShowExtremesComposite,
					ShowText = ShowTextComposite,
					IsItCalculating = false,
                    NormalOpac = NormalOpacComposite,
                    ProfilePercent = ProfilePercentComposite,
                    ProfilePercentRight = ProfilePercentCompositeRightSide,
                    Text = TextHistProfileComposite,
                    Extremes = ExtremesComposite,
                    POC = POCComposite,
                    VAH = VAHComposite,
                    VAL = VALComposite,
                    Profile = ProfileComposite
                };
                #endregion

                #region Static Profile
                _HistoricalProfileSettings = new ProfileSettings()
				{
					Show = true,
                    ValueAreaPercent = VAPercentStatic,
                    IsRight = false,
					IsHistorical = true,
                    VAOpac = VAOpacHisto,
					ShowVAL = ShowVALHisto,
					ShowVAH = ShowVAHHisto,
					ShowPOC = ShowPOCHisto,
					ShowProfile = ShowProfileHisto,
					ShowExtremes = ShowExtremesHisto,
					ShowText = ShowTextStatic,
					IsItCalculating = false,
					NormalOpac = NormalOpacHisto,
					ProfilePercent = ProfilePercentHisto,
					Text = TextHistProfileHisto,
					Extremes = ExtremesHisto,
					POC = POCHisto,
					VAH = VAHHisto,
					VAL = VALHisto,
					Profile = ProfileHisto
                };
                #endregion

                #region RealTime Profile
                _RealTimeProfileSettings = new ProfileSettings()
                {
					Show = true,
                    ValueAreaPercent = VAPercentRealTime,
                    IsRight = !DrawOnLeft,
                    VAOpac = VAOpacCurrentBar,
                    IsHistorical = false,
                    ShowVAL = ShowVALCurrentBar,
                    ShowVAH = ShowVAHCurrentBar,
                    ShowPOC = ShowPOCCurrentBar,
                    ShowProfile = ShowProfileCurrentBar,
                    ShowExtremes = ShowExtremesCurrentBar,
                    ShowText = ShowTextRealTime,
                    IsItCalculating = false,
                    NormalOpac = NormalOpacCurrentBar,
                    ProfilePercent = ProfilePercentCurrentBar,
					ProfilePercentRight = ProfilePercentCurrentBarRightSide,
					Text = TextHistProfileCurrentBar,
                    Extremes = ExtremesCurrentBar,
                    POC = POCCurrentBar,
                    VAH = VAHCurrentBar,
                    VAL = VALCurrentBar,
                    Profile = ProfileCurrentBar
                };
				#endregion

				#region Cluster
				ClusterDisplay clusterDisplay = ClusterDisplay.None;
				if (Show == "All Bars")
					clusterDisplay = ClusterDisplay.AllBars;
				else if(Show == "Only In Profile")
                    clusterDisplay = ClusterDisplay.OnlyInProfile;
                _ClusterSettings = new ClusterSettings()
				{
					ClusterTicks = ClusterTicks,
					Opacity = Opacity,
					ShowBorder = ShowBorder,
					ShowShading = ShowShading,
					Stroke = Stroke,
					Show = clusterDisplay
                };
				#endregion

				#region General Settings
				_GeneralSettings = new GeneralSettings()
				{
					CompositeCalculationType = CompositeType,
					CompositeResetInterval = _tsNextInterval,
					CompositeStartTime = _tsDayResetTime,
					DisplayHistogram = true,
					ExtendLevels = true,
					ShowComposite = ShowComposite,
					ShowCurrentProfile = ShowCurrentProfile,
					ShowHistorical = ShowHistorical,
					ShowLevelLabels = true,
					ShowOnTop = false,
					ShowProfileLeft = false,
					ShowVolumeNumbers = false
				};
				#endregion

				#region Rebuild
				if (_sPreviousIntrument == Instrument.FullName && _sPreviousBars == string.Format("{0} {1} {2} {3}", Bars.Instrument.FullName, Bars.FromDate.ToString(), Bars.BarsPeriod.ToString(), Bars.IsTickReplay))
				{
					if (_lstRealTimeProfiles.Count > 0)
						_bRebuildRealTime = true;
					if (_lstStaticProfiles.Count > 0)
						_bRebuildStatic = true;
					lock (_dicAllBars)
					{
						if (_sChartType == ChartType && _iChartInterval == ChartInterval && _iTicksPerLevel == TicksPerLevel && _iClusterTicks == ClusterTicks)
						{
							if (_dicAllBars.Count > 0)
								_bBarsAreGood = true;
						}
						else
						{
							_dicAllBars.Clear();
						}
					}
				}
				else
				{
					_lstRealTimeProfiles.Clear();
					_lstStaticProfiles.Clear();
					lock(_dicAllBars)
						_dicAllBars.Clear();
                }
				_sChartType = ChartType;
				_iChartInterval = ChartInterval;
                _sPreviousIntrument = Instrument.FullName;
				_iTicksPerLevel = TicksPerLevel;
				_iClusterTicks = ClusterTicks;
                _sPreviousBars = string.Format("{0} {1} {2} {3}", Bars.Instrument.FullName, Bars.FromDate.ToString(), Bars.BarsPeriod.ToString(), Bars.IsTickReplay);
				#endregion
			}
			else if (State == State.Historical)
			{
				if (!_bAa && _bIsChart)
				{
					addToToolbar();
				}
			}
			else if (State == State.Terminated)
			{
				if (_bAa && _bIsChart) { Cleaner(); }
			}
			#endregion

			#endregion
		}
		#endregion

		#region On Bar Update
		protected override void OnBarUpdate()
		{
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			switch (Bars.BarsPeriod.BaseBarsPeriodType)
			{
				case BarsPeriodType.Tick: if (ChartType == "Tick" && Bars.BarsPeriod.BaseBarsPeriodValue > ChartInterval) return; break;
                case BarsPeriodType.Second: if (ChartType == "Second" && Bars.BarsPeriod.BaseBarsPeriodValue > ChartInterval) return; break;
                case BarsPeriodType.Minute: if (ChartType == "Minute" && Bars.BarsPeriod.BaseBarsPeriodValue > ChartInterval) return; break;
            }

            #region Current Timeframe
            if (BarsInProgress == 0)
			{
				if (CurrentBar == 0)
					return;
				lock (_dicAllBars)
				{
					if (!_dicAllBars.ContainsKey(CurrentBars[0]) || (_bBarsAreGood && IsFirstTickOfBar))
					{
						#region Update New Bar
						BarLocation bar = new BarLocation() { No = CurrentBars[0], StartTime = Times[0][1], EndTime = Times[0][0] };
						if (_bBarsAreGood && !_dicAllBars.ContainsKey(CurrentBars[0] + 1) && CurrentBars[0] > 2)
							_bBarsAreGood = false;
						if (!_bBarsAreGood)
						{
							BarDetails details = new BarDetails() { Bar = bar };
							if (_CTF_Bar != null)
							{
								_CTF_Bar.UpdateBarLocation(bar);
								if (_dicAllBars.ContainsKey(CurrentBar))
									_dicAllBars[CurrentBar] = _CTF_Bar.Clone() as BarInfo;
								else
									_dicAllBars.TryAdd(CurrentBar, _CTF_Bar.Clone() as BarInfo);// new BarInfo(details, TicksPerLevel, _dBasePrice, TickSize, _dValueAreaPercent, ValueAreaLevelsPerStep, _ClusterSettings));
							}
							_CTF_Bar = new BarInfo(details, TicksPerLevel, Instrument, _ClusterSettings);
						}
						#endregion

						#region Rebuild Static Profiles
						if (_bRebuildStatic && State == State.Historical && _lstStaticProfiles.Count > 0)
						{
							for (int i = 0; i < _lstStaticProfiles.Count; i++)
							{
								if (Times[0][0].CompareTo(_lstStaticProfiles[i].Start.EndTime) >= 0 && Times[0][0].CompareTo(_lstStaticProfiles[i].End.EndTime) <= 0)
								{
									if (_lstStaticProfiles[i].Settings == null)
										_lstStaticProfiles[i].Initialize(bar, TicksPerLevel * TickSize, ValueAreaLevelsPerStep, _VWAPSettings, _CWAPSettings, _HistoricalProfileSettings);
									_lstStaticProfiles[i].UpdateSingleClosedBar(_dicAllBars[CurrentBars[0]], CurrentBars[0], Instrument, true);
								}
							}
						}
						else
							_bRebuildStatic = false;
						#endregion

						#region Update Manual Profile
						if (_lstRealTimeProfiles.Count > 0)
						{
							#region Rebuild Real Time Profiles
							if (_bRebuildRealTime && State == State.Historical)
							{
								for (int i = 0; i < _lstRealTimeProfiles.Count; i++)
								{
									if (Times[0][0].CompareTo(_lstRealTimeProfiles[i].Start.EndTime) >= 0)
									{
										if (_lstRealTimeProfiles[i].Settings == null)
											_lstRealTimeProfiles[i].Initialize(bar, TicksPerLevel * TickSize, ValueAreaLevelsPerStep, _VWAPSettings, _CWAPSettings, _RealTimeProfileSettings);
										_lstRealTimeProfiles[i].UpdateSingleClosedBar(_dicAllBars[CurrentBars[0]], CurrentBars[0], Instrument);
									}
								}
							}
							#endregion

							#region Updating Realtime Profiles
							else
							{
								_bRebuildRealTime = false;
								for (int i = 0; i < _lstRealTimeProfiles.Count; i++)
								{
									if (i == _iEditingProfileRealTime)
										continue;
									_lstRealTimeProfiles[i].UpdateSingleClosedBar(_dicAllBars[CurrentBars[0]], CurrentBars[0], Instrument);
								}
							}
							#endregion
						}
						#endregion

						#region Update Composite Profile
						if (_dicAllBars.Count == 1)
						{
							_BuildingProfileComposite = new Profile() { Start = bar, End = bar, High = R2T(Highs[0][0]), Low = R2T(Lows[0][0]) };
							_BuildingProfileComposite.Initialize(bar, TicksPerLevel * TickSize, ValueAreaLevelsPerStep, _VWAPSettings, _CWAPSettings, _CompositeProfileSettings);
						}

						if (Reset(Times[0][0], Times[0][1]))
						{
							_bNewWeek = false;
							_bNewMonth = false;
							_dtResetTime = _dtResetTime.Add(_tsNextInterval);
							//Store and calculate old profile
							if (_BuildingProfileComposite != null)
							{
								double dHigh, dLow;
								GetHighLow(_dicAllBars, _BuildingProfileComposite.Start, _BuildingProfileComposite.End, CurrentBars[0], out dHigh, out dLow);
								_BuildingProfileComposite.High = dHigh;
								_BuildingProfileComposite.Low = dLow;
								_BuildingProfileComposite.UpdateProfile(_dicAllBars, CurrentBars[0], Instrument);
								_lstCompositeProfiles.Add(_BuildingProfileComposite.Clone() as Profile);
								if (_lstCompositeProfiles.Count > 1)
									for (int i = 0; i < _lstCompositeProfiles.Count - 1; i++)
										_lstCompositeProfiles[i].Settings.Show = _GeneralSettings.ShowComposite && _GeneralSettings.DisplayHistogram;
								_lstCompositeProfiles[_lstCompositeProfiles.Count - 1].Settings.Show = _GeneralSettings.ShowComposite && _GeneralSettings.ShowCurrentProfile;
							}
							//Initialize new profile
							_BuildingProfileComposite = new Profile() { Start = bar, End = bar, High = R2T(Highs[0][0]), Low = R2T(Lows[0][0]) };
							_BuildingProfileComposite.Initialize(bar, TicksPerLevel * TickSize, ValueAreaLevelsPerStep, _VWAPSettings, _CWAPSettings, _CompositeProfileSettings);
							//Store the new profile straight in the list if we are during live trading
							if (CurrentBars[0] >= Count - 2)
							{
								double dHigh, dLow;
								GetHighLow(_dicAllBars, _BuildingProfileComposite.Start, _BuildingProfileComposite.End, CurrentBars[0], out dHigh, out dLow);
								_BuildingProfileComposite.High = dHigh;
								_BuildingProfileComposite.Low = dLow;
								_BuildingProfileComposite.UpdateProfile(_dicAllBars, CurrentBars[0], Instrument);
								_lstCompositeProfiles.Add(_BuildingProfileComposite.Clone() as Profile);
								_BuildingProfileComposite = null;
								if (_lstCompositeProfiles.Count > 1)
								{
									for (int i = 0; i < _lstCompositeProfiles.Count - 1; i++)
									{
										_lstCompositeProfiles[i].Settings.Show = _GeneralSettings.ShowComposite && _GeneralSettings.DisplayHistogram;
										_lstCompositeProfiles[i].Settings.IsHistorical = true;
									}
								}
								_lstCompositeProfiles[_lstCompositeProfiles.Count - 1].Settings.Show = _GeneralSettings.ShowComposite && _GeneralSettings.ShowCurrentProfile;
								_lstCompositeProfiles[_lstCompositeProfiles.Count - 1].Settings.IsHistorical = false;
							}
						}
						else
						{
							if (_BuildingProfileComposite != null)
								_BuildingProfileComposite.End = bar;
							else if (_lstCompositeProfiles.Count > 0)
								_lstCompositeProfiles[_lstCompositeProfiles.Count - 1].UpdateSingleClosedBar(_dicAllBars[CurrentBars[0]], CurrentBars[0], Instrument);
							if (CurrentBars[0] == Count - 3 && _BuildingProfileComposite != null)
							{
								double dHigh, dLow;
								GetHighLow(_dicAllBars, _BuildingProfileComposite.Start, _BuildingProfileComposite.End, CurrentBars[0], out dHigh, out dLow);
								_BuildingProfileComposite.High = dHigh;
								_BuildingProfileComposite.Low = dLow;
								_BuildingProfileComposite.UpdateProfile(_dicAllBars, CurrentBars[0], Instrument);
								_lstCompositeProfiles.Add(_BuildingProfileComposite.Clone() as Profile);
								_BuildingProfileComposite = null;
								if (_lstCompositeProfiles.Count > 1)
								{
									for (int i = 0; i < _lstCompositeProfiles.Count - 1; i++)
									{
										_lstCompositeProfiles[i].Settings.Show = _GeneralSettings.ShowComposite && _GeneralSettings.DisplayHistogram;
										_lstCompositeProfiles[i].Settings.IsHistorical = true;
									}
								}
								_lstCompositeProfiles[_lstCompositeProfiles.Count - 1].Settings.Show = _GeneralSettings.ShowComposite && _GeneralSettings.ShowCurrentProfile;
								_lstCompositeProfiles[_lstCompositeProfiles.Count - 1].Settings.IsHistorical = false;
							}
						}
						#endregion
					}
				}
				if (_CTF_Bar != null)
					_CTF_Bar.UpdateOHLC(R2T(Opens[0][0]), R2T(Highs[0][0]), R2T(Lows[0][0]), R2T(Closes[0][0]), Instrument);
			}
			#endregion

			#region Lower Timeframe
			else if (BarsInProgress == 1)
			{
				if (CurrentBars[1] < 2 || _dicAllBars.Count == 0)
					return;
				if (_CTF_Bar != null)
				{
                    if (IsFirstTickOfBar)
					{
                        //List<BarDetails> data = GetOverlapList();
                        //if (data != null && data.Count > 0)
                        //{
                        //	List<BarDetails> separateData = new List<BarDetails>();
                        //	for(int i = 0; i < data.Count; i++)
                        //	{
                        //		separateData.Clear();
                        //		separateData = GetSeparateList(data, i);
                        //		_dicAllBars[CurrentBars[0] - i].UpdateVolume(separateData, false);
                        //                   }
                        //}
                        if (_LTF_Bar != null && _CTF_Bar != null)
							_CTF_Bar.UpdateVolume(new List<BarDetails>() { _LTF_Bar }, false, Instrument);
						//before we create a new bar we store all the old bar details as fixed
						BarLocation bar = new BarLocation() { No = CurrentBars[1], StartTime = Times[1][1], EndTime = Times[1][0] };
						_LTF_Bar = new BarDetails() { Bar = bar };
					}

					if (_LTF_Bar != null)
						_LTF_Bar.UpdateOHLCV(R2T(Opens[1][0]), R2T(Highs[1][0]), R2T(Lows[1][0]), R2T(Closes[1][0]), Volumes[1][0] * 0.5, Volumes[1][0] * 0.5);
				}
				//            List<BarDetails> tempData = GetOverlapList();
				//if (tempData != null && tempData.Count > 0)
				//            {
				//                List<BarDetails> separateData = new List<BarDetails>();
				//                for (int i = 0; i < tempData.Count; i++)
				//                {
				//                    separateData.Clear();
				//                    separateData = GetSeparateList(tempData, i);
				//                    _dicAllBars[CurrentBars[0] - i].UpdateVolume(separateData, true);
				//                }
				//            }
				//if (_LTF_Bar != null)
				//	_dicAllBars[CurrentBars[0]].UpdateVolume(new List<BarDetails>() { _LTF_Bar }, true);
			}
			#endregion
		}
        #endregion

        #region Objects

        #region Classes

        #region Dynamic Classes

        #region General Settings
        private class GeneralSettings
		{
			public string CompositeCalculationType { get; set; }
			public TimeSpan CompositeStartTime { get; set; }
			public TimeSpan CompositeResetInterval { get; set; }
			public bool ShowComposite { get; set; }
			public bool DisplayHistogram { get; set; }
			public bool ShowOnTop { get; set; }
			public bool ShowCurrentProfile { get; set; }
			public bool ShowProfileLeft { get; set; }
			public bool ShowHistorical { get; set; }
			public bool ShowVolumeNumbers { get; set; }
			public bool ShowLevelLabels { get; set; }
			public bool ExtendLevels { get; set; }
		}
        #endregion

        #region Price Level Class
        private class PriceDetails : ICloneable
		{
			#region Floating Variables

			private double _dDividedFormulaRes = 0;

			#endregion

			#region Properties
			//we split these into bid and ask in case Sean wants to use the market data for this
			public double Bid { get; set; }
			public double TempBid { get; set; }
			public double Ask { get; set; }
			public double TempAsk { get; set; }
			public double High { get; set; }
			public double Low { get; set; }
			public double Volume
			{
				get
				{
					return Ask + Bid + TempAsk + TempBid;
				}
			}
			public double DividedFormulaRes { get { return _dDividedFormulaRes; } }
			#endregion

			#region Constructor - Base
			public PriceDetails()
			{
				Bid = 0; TempBid = 0;
				Ask = 0; TempAsk = 0;
				High = double.MinValue;
				Low = double.MaxValue;
			}

			public PriceDetails(PriceDetails price)
			{
				Bid = price.Bid;
				Ask = price.Ask;
				TempAsk = price.TempAsk;
				TempBid = price.TempBid;
				High = price.High;
				Low = price.Low;
			}
			#endregion

			#region Update Bid&Ask
			public void UpdateBidAsk(double bid, double ask)
			{
				Bid += bid;
				Ask += ask;
			}
			public void UpdateBidAsk(PriceDetails details)
			{
				Bid += details.Bid;
				Ask += details.Bid;
			}
			#endregion

			#region Divided Formula Function
			private void DividedFormula(double Open, double Ticksize, int NoTicksInput) //provides the lower part of the range - the start point for calculate/ drawing the profile
			{
				double res = 0;
				double res1 = 0;
				res = Open / Ticksize;
				res1 = Math.Floor(res / NoTicksInput);
				_dDividedFormulaRes = res1 * NoTicksInput * Ticksize;
			}

			//Divided Forumula
			//         Open[0]/ TickSize = no of ticksize   //floor(no of ticksize/ input ticksize) = Res   //	Res * input ticksize * ticks - 1st price from 1st bracket
			#endregion

			#region Clone
			public virtual object Clone()
			{
				return new PriceDetails() { Ask = Ask, Bid = Bid, TempBid = TempBid, TempAsk = TempAsk, High = High, Low = Low };
			}
			#endregion
		}
        #endregion

        #region Indicator Related Classes

        #region POC Class
        private class PocDetails : ICloneable
		{
			#region Floating Variables
			private double _dValueAreaPercent = 70;
			private double _dStep = 0;
			private int _iStepSize = 2; //this step size is for the number of zones prices need to jusp for the VAH VAL calculations (min: 1  max: 2)
			#endregion

			#region Properties
			public PriceDetails PocValue { get; set; }
			public PriceDetails ValueAreaHigh { get; set; }
			public PriceDetails ValueAreaLow { get; set; }
			public BarLocation Bar { get; set; }
			#endregion

			#region Constructor
			public PocDetails()
			{
				PocValue = new PriceDetails();
				ValueAreaHigh = new PriceDetails();
				ValueAreaLow = new PriceDetails();
				Bar = new BarLocation();
				_iStepSize = Math.Max(1, Math.Min(_iStepSize, 2)); //because fuck engineering more than a step of 2 and no-one to use it
			}
			#endregion

			#region Initialize
			public void Initialize(BarLocation bar, double valueAreaPercent, double step, int stepSize)
			{
				Bar = bar.Clone() as BarLocation;
				_dValueAreaPercent = valueAreaPercent;
				_dStep = step;
				_iStepSize = Math.Max(1, Math.Min(stepSize, 2)); //because fuck engineering more than a step of 2 and no-one to use it
			}
			#endregion

			#region Reset
			public void Reset()
			{
				PocValue = new PriceDetails();
				ValueAreaHigh = new PriceDetails();
				ValueAreaLow = new PriceDetails();
			}
			#endregion

			#region Calculate POC
			public double CalculatePOC(ConcurrentDictionary<double, PriceDetails> prices, Instrument instrument, PriceDetails price = null)
			{
				if (prices.Count == 0)
					return 0;
                double dTotalVolume = 0;
				//if any of the below are true then we have to recalulate the entire POC otherwise we just recalculate just the VAH and VAL with the onld POC as it never changed
				if (price == null || PocValue.Volume == 0 || !prices.ContainsKey(price.Low) || prices[price.Low].Volume > PocValue.Volume)
				{
					List<double> lstKeys = prices.Keys.ToList();
					for (int i = 0; i < lstKeys.Count; i++)
					{
						if (prices[lstKeys[i]].Volume > PocValue.Volume)
							PocValue = prices[lstKeys[i]].Clone() as PriceDetails;
						dTotalVolume += prices[lstKeys[i]].Volume;
					}
				}
				if (PocValue.Volume == 0 || _dValueAreaPercent == 0 || dTotalVolume == 0)
					return 0;
				double dValueAreaVolume = dTotalVolume * _dValueAreaPercent * 0.01;
				double dDevelopingVolume = PocValue.Volume;
				ValueAreaHigh = PocValue.Clone() as PriceDetails;
				ValueAreaLow = PocValue.Clone() as PriceDetails;
				//here we calculate the VAL and VAH
				CalculateVAHandVAL(prices, 1, 1, dValueAreaVolume, dDevelopingVolume, instrument);
				return dTotalVolume;
			}
			#endregion

			#region Calculate VAL and VAH
			//this calculates the VAL and VAH per increments for a minimum step of 1 and a maximum step of 2
			private void CalculateVAHandVAL(ConcurrentDictionary<double, PriceDetails> prices, int stepNumberUp, int stepNumberDown, double valueAreaVolume, double developingVolume, Instrument instrument)
			{
				//if there is not volume for the value are we just break out of this function to avoid a stack overflow exception 
				if (valueAreaVolume == 0)
					return;
				//we calculate the above volume for 1 or 2 steps 
				double dAboveVolume = 0;
				//we initiate the value of the price with the first step calculated from the initial POC vlaue
				double dPriceAbove = instrument.MasterInstrument.RoundToTickSize(PocValue.Low + stepNumberUp * (_iStepSize > 1 ? _iStepSize - 1 : _iStepSize) * _dStep);
				//We check that the price actually exists in the dicitonary. If it does then we add, if it doesn't then we just reset the price for the above values as we have no more bar to move to
				if (prices.ContainsKey(dPriceAbove))
					dAboveVolume += prices[dPriceAbove].Volume;
				else
					dPriceAbove = 0;
				//We not check if the step is 2 and that the previous price actually existed, if they don't then we move to the bottom
				if (_iStepSize > 1 && dPriceAbove != 0)
				{
					//if they exist, then we store the value for the next step in a temp double
					double dPriceAboveTemp = instrument.MasterInstrument.RoundToTickSize(PocValue.Low + stepNumberUp * _iStepSize * _dStep);
					if (prices.ContainsKey(dPriceAboveTemp))
					{
						//if the price is in the dictionary then we add the volume to the previous volume and assign the temp price to the latest price
						dAboveVolume += prices[dPriceAboveTemp].Volume;
						dPriceAbove = dPriceAboveTemp;
					}
				}
				//we calculate the below volume for 1 or 2 steps
				double dBelowVolume = 0;
				//we initiate the value of the price with the first step calculated from the initial POC vlaue
				double dPriceBelow = instrument.MasterInstrument.RoundToTickSize(PocValue.Low - stepNumberDown * (_iStepSize > 1 ? _iStepSize - 1 : _iStepSize) * _dStep);
				//We check that the price actually exists in the dicitonary. If it does then we add, if it doesn't then we just reset the price for the below values as we have no more bar to move to
				if (prices.ContainsKey(dPriceBelow))
					dBelowVolume += prices[dPriceBelow].Volume;
				else
					dPriceBelow = 0;
				//We not check if the step is 2 and that the previous price actually existed, if they don't then we move to the next calculation
				if (_iStepSize > 1 && dPriceBelow != 0)
				{
					//if they exist, then we store the value for the next step in a temp double
					double dPriceBelowTemp = instrument.MasterInstrument.RoundToTickSize(PocValue.Low - stepNumberDown * _iStepSize * _dStep);
					if (prices.ContainsKey(dPriceBelowTemp))
					{
						//if the price is in the dictionary then we add the volume to the previous volume and assign the temp price to the latest price
						dBelowVolume += prices[dPriceBelowTemp].Volume;
						dPriceBelow = dPriceBelowTemp;
					}
				}
				//if the above is greater than the below then we change the VAH value
				if (dAboveVolume > dBelowVolume)
				{
					developingVolume += dAboveVolume;
					stepNumberUp++;
					ValueAreaHigh = prices[dPriceAbove].Clone() as PriceDetails;
				}
				//if the below is greater than the avoe volume then we move the VAL to the latest price
				else if (dBelowVolume > dAboveVolume)
				{
					developingVolume += dBelowVolume;
					stepNumberDown++;
					ValueAreaLow = prices[dPriceBelow].Clone() as PriceDetails;
				}
				//if they are both the same (it happens sometimes) then we update both of them
				else
				{
					developingVolume += dAboveVolume + dBelowVolume;
					if (prices.ContainsKey(dPriceAbove))
						ValueAreaHigh = prices[dPriceAbove].Clone() as PriceDetails;
					stepNumberUp++;
					if (prices.ContainsKey(dPriceBelow))
						ValueAreaLow = prices[dPriceBelow].Clone() as PriceDetails;
					stepNumberDown++;
					//              if (!prices.ContainsKey(dPriceAbove) && !prices.ContainsKey(dPriceBelow))
					//bForceStop = true;
				}
				if (stepNumberUp >= prices.Count && stepNumberDown >= prices.Count)
					return;
                //here we check if the volume has hit the value area volume or not
                if (developingVolume < valueAreaVolume)
					CalculateVAHandVAL(prices, stepNumberUp, stepNumberDown, valueAreaVolume, developingVolume, instrument);
				//if the volume isn't enough then we move on to the next call of the function with the new steps
				//if the volume is enough, then we stop going through this function and we can safely say that we have found the VAH and VAL
			}
			#endregion

			#region Clone
			public object Clone()
			{
				return new PocDetails()
				{
					PocValue = PocValue.Clone() as PriceDetails,
					ValueAreaHigh = ValueAreaHigh.Clone() as PriceDetails,
					ValueAreaLow = ValueAreaLow.Clone() as PriceDetails,
					Bar = Bar.Clone() as BarLocation,
					_dValueAreaPercent = _dValueAreaPercent,
					_dStep = _dStep,
					_iStepSize = _iStepSize
				};
			}
			#endregion
		}
        #endregion

        #region VWAP & Std.Dev Class

        #region VWAP Values
        private class VwapStdDevValues : ICloneable
		{
			public BarLocation Bar { get; set; }
			public double Wvap { get; set; }
			public double StdDevUp1 { get; set; }
			public double StdDevUp2 { get; set; }
			public double StdDevUp3 { get; set; }
			public double StdDevDown1 { get; set; }
			public double StdDevDown2 { get; set; }
			public double StdDevDown3 { get; set; } // toate vor fi calculate prin apelarea de calcul a functie din clasa profile - functia de calcula vwap si std dev

            public VwapStdDevValues()
			{
				Bar = null;
				Wvap = 0;
                StdDevUp1 = 0;
				StdDevUp2 = 0;
				StdDevUp3 = 0;
				StdDevDown1 = 0;
				StdDevDown2 = 0;
				StdDevDown3 = 0;
			}

            public object Clone()
			{
				return new VwapStdDevValues()
				{
					Bar = Bar,
					Wvap = Wvap,
					StdDevDown1 = StdDevDown1,
					StdDevDown2 = StdDevDown2,
					StdDevDown3 = StdDevDown3,
					StdDevUp1 = StdDevUp1,
					StdDevUp2 = StdDevUp2,
					StdDevUp3 = StdDevUp3
				};
			}
		}
        #endregion

        #region VWAP Settings
        private class VWAPSettings : ICloneable
		{
			public bool Show { get; set; }
			public float Opacity { get; set; }
			public double Deviation1 { get; set; }
			public double Deviation2 { get; set; }
			public double Deviation3 { get; set; }
			public VWAPDeviation VWAPDeviation { get; set; }
			public Stroke Vwap { get; set; }
			public Stroke Above { get; set; }
			public Stroke Below { get; set; }
			public Brush InnerZone { get; set; }
			public Brush MidZone { get; set; }
			public Brush OuterZone { get; set; }
			public bool DrawLastValue { get; set; }
			public bool ShowShading { get; set; }
			public bool ShowText { get; set; }
			public SimpleFont TextFont { get; set; }

			public object Clone()
			{
				return new VWAPSettings()
				{
					Show = Show,
					Opacity = Opacity,
					Deviation1 = Deviation1,
					Deviation2 = Deviation2,
					Deviation3 = Deviation3,
					VWAPDeviation = VWAPDeviation,
					Vwap = Vwap.Clone() as Stroke,
					Above = Above.Clone() as Stroke,
					Below = Below.Clone() as Stroke,
					InnerZone = InnerZone,
					MidZone = MidZone,
					OuterZone = OuterZone,
					DrawLastValue = DrawLastValue,
					ShowShading = ShowShading,
					ShowText = ShowText,
					TextFont = TextFont
				};
			}
		}
        #endregion

        #region VWAP Calculator
        private class VwapStdDevCalculator : ICloneable
		{
			#region Floating Variables
			private double _dTypicalVol = 0;
			private double _dTotalVol = 0;
			private double _dTypicalTypicalVol = 0;

			private VWAPSettings _Settings = null;
			private ConcurrentDictionary<int, VwapStdDevValues> _dicVWAP = new ConcurrentDictionary<int, VwapStdDevValues>();
			#endregion

			#region Properties
			public VWAPSettings Settings { get { return _Settings; } }
			#endregion

			#region Initialize
			public void Initialize(VWAPSettings settings)
			{
				_Settings = settings.Clone() as VWAPSettings;
			}
            #endregion

            #region Calculations

            #region Reset
            public void Reset()
            {
                lock (_dicVWAP)
                    _dicVWAP.Clear();
				_dTotalVol = 0;
                _dTypicalVol = 0;
                _dTypicalTypicalVol = 0;
			}
            #endregion

            #region Calculate One Bar
            public VwapStdDevValues CalculateOneBar(BarDetails barInfo, bool isBarClosed = true)
			{
				VwapStdDevValues result = new VwapStdDevValues();
				result.Bar = barInfo.Bar.Clone() as BarLocation;

				double dTypicalVol = _dTypicalVol + barInfo.Typical * barInfo.Volume;
				double dTotalVol = _dTotalVol + barInfo.Volume;
				double dTypicalTypicalVol = _dTypicalTypicalVol + barInfo.Typical * barInfo.Typical * barInfo.Volume;

				if (dTotalVol != 0)
					result.Wvap = dTypicalVol / dTotalVol;
				else
					result.Wvap = barInfo.Typical;

				double dDeviation = dTotalVol == 0 ? 0 : Math.Sqrt(Math.Max(dTypicalTypicalVol / dTotalVol - result.Wvap * result.Wvap, 0));

				result.StdDevUp1 = result.Wvap + dDeviation * _Settings.Deviation1;
				result.StdDevDown1 = result.Wvap - dDeviation * _Settings.Deviation1;
				result.StdDevUp2 = result.Wvap + dDeviation * _Settings.Deviation2;
				result.StdDevDown2 = result.Wvap - dDeviation * _Settings.Deviation2;
				result.StdDevUp3 = result.Wvap + dDeviation * _Settings.Deviation3;
				result.StdDevDown3 = result.Wvap - dDeviation * _Settings.Deviation3;

				if (isBarClosed)
				{
					_dTypicalVol = dTypicalVol;
					_dTotalVol = dTotalVol;
					_dTypicalTypicalVol = dTypicalTypicalVol;
				}

				return result;
			}
			#endregion

			#region Calculate More Bars
			public void CalculateMoreBars(ConcurrentDictionary<int, BarInfo> barInfo)
			{
				if (barInfo.Count == 0)
					return;
				List<int> keys = barInfo.Keys.ToList();
				keys.Sort();
                lock (_dicVWAP)
                    for (int i = 0; i <= keys.Count - 1; i++)
						_dicVWAP.TryAdd(keys[i], CalculateOneBar(barInfo[keys[i]]?.BarDetails?.Clone() as BarDetails)); 
			}
			#endregion

			#region Calculate Current Bar
			public void CalculateCurrentBar(BarDetails barInfo)
			{
                if (barInfo == null)
                    return;
                lock (_dicVWAP)
				{
					if (_dicVWAP.ContainsKey(barInfo.Bar.No))
						_dicVWAP[barInfo.Bar.No] = CalculateOneBar(barInfo, false);
					else
						_dicVWAP.TryAdd(barInfo.Bar.No, CalculateOneBar(barInfo, false));
				}
			}
			#endregion

			#region Calculate Closed Bar
			public void CalculateClosedBar(BarDetails barInfo)
			{
				if (barInfo == null)
					return;
				lock (_dicVWAP)
				{
					if (_dicVWAP.ContainsKey(barInfo.Bar.No))
						_dicVWAP[barInfo.Bar.No] = CalculateOneBar(barInfo, true);
					else
						_dicVWAP.TryAdd(barInfo.Bar.No, CalculateOneBar(barInfo, true));
				}
			}
			#endregion

			#endregion

			#region Draw

			#region Draw
			public void Draw(SharpDX.Direct2D1.RenderTarget renderTarget, ChartControl chartControl, ChartScale chartScale, ChartBars bars, Instrument instrument)
			{
				if (_dicVWAP.Count == 0 || !_Settings.Show)
					return;

				List<int> keys = new List<int>();

                lock (_dicVWAP)
					keys = _dicVWAP.Keys.ToList();
				keys.Sort();

				#region Draw Just the Lines
				if (_Settings.DrawLastValue)
				{
					lock (_dicVWAP)
					{
						VwapStdDevValues first = _dicVWAP[keys[0]];
						VwapStdDevValues last = _dicVWAP[keys[keys.Count - 1]];
						DrawLineText(renderTarget, chartControl, chartScale, instrument, first.Bar, last.Bar, last.Wvap, _Settings.Vwap);
						//DrawSharpDX.Line(renderTarget, chartControl, chartScale, first.Bar.StartTime, last.Wvap, last.Bar.EndTime, last.Wvap, _Settings.Vwap);
						if (_Settings.VWAPDeviation != VWAPDeviation.None)
						{
							DrawLineText(renderTarget, chartControl, chartScale, instrument, first.Bar, last.Bar, last.StdDevUp1, _Settings.Above);
							DrawLineText(renderTarget, chartControl, chartScale, instrument, first.Bar, last.Bar, last.StdDevDown1, _Settings.Below);
							if (_Settings.VWAPDeviation != VWAPDeviation.Deviation1)
							{
								DrawLineText(renderTarget, chartControl, chartScale, instrument, first.Bar, last.Bar, last.StdDevUp2, _Settings.Above);
								DrawLineText(renderTarget, chartControl, chartScale, instrument, first.Bar, last.Bar, last.StdDevDown2, _Settings.Below);
								if (_Settings.VWAPDeviation != VWAPDeviation.Deviation2)
								{
									DrawLineText(renderTarget, chartControl, chartScale, instrument, first.Bar, last.Bar, last.StdDevUp3, _Settings.Above);
									DrawLineText(renderTarget, chartControl, chartScale, instrument, first.Bar, last.Bar, last.StdDevDown3, _Settings.Below);
								}
							}
						}
                    }
                }
                #endregion

                #region Draw Full VWAP
                else
				{
					#region Lines
					List<Point> lstUpper3Points = new List<Point>();
					List<Point> lstUpper2Points = new List<Point>();
					List<Point> lstUpper1Points = new List<Point>();
					List<Point> lstVwapPoints = new List<Point>();
					List<Point> lstLower1Points = new List<Point>();
					List<Point> lstLower2Points = new List<Point>();
					List<Point> lstLower3Points = new List<Point>();
					lock (_dicVWAP)
					{
						for (int i = 1; i <= keys.Count - 1; i++)
						{
							float x = chartControl.GetXByBarIndex(bars, keys[i] - 1);
							lstUpper3Points.Add(new Point(x, chartScale.GetYByValue(_dicVWAP[keys[i]].StdDevUp3)));
							lstUpper2Points.Add(new Point(x, chartScale.GetYByValue(_dicVWAP[keys[i]].StdDevUp2)));
							lstUpper1Points.Add(new Point(x, chartScale.GetYByValue(_dicVWAP[keys[i]].StdDevUp1)));
							lstVwapPoints.Add(new Point(x, chartScale.GetYByValue(_dicVWAP[keys[i]].Wvap)));
							lstLower1Points.Add(new Point(x, chartScale.GetYByValue(_dicVWAP[keys[i]].StdDevDown1)));
							lstLower2Points.Add(new Point(x, chartScale.GetYByValue(_dicVWAP[keys[i]].StdDevDown2)));
							lstLower3Points.Add(new Point(x, chartScale.GetYByValue(_dicVWAP[keys[i]].StdDevDown3)));
						}
					}
					DrawSharpDX.DrawLine(renderTarget, chartControl, lstVwapPoints, _Settings.Vwap);//, strokePixAdjustVec);
					if (_Settings.VWAPDeviation != VWAPDeviation.None)
					{
						DrawSharpDX.DrawLine(renderTarget, chartControl, lstUpper1Points, _Settings.Above);//, strokePixAdjustVec);
						DrawSharpDX.DrawLine(renderTarget, chartControl, lstLower1Points, _Settings.Below);//, strokePixAdjustVec);
						if (_Settings.VWAPDeviation != VWAPDeviation.Deviation1)
						{
							DrawSharpDX.DrawLine(renderTarget, chartControl, lstUpper2Points, _Settings.Above);//, strokePixAdjustVec);
							DrawSharpDX.DrawLine(renderTarget, chartControl, lstLower2Points, _Settings.Below);//, strokePixAdjustVec);
							if (_Settings.VWAPDeviation != VWAPDeviation.Deviation2)
							{
								DrawSharpDX.DrawLine(renderTarget, chartControl, lstUpper3Points, _Settings.Above);//, strokePixAdjustVec);
								DrawSharpDX.DrawLine(renderTarget, chartControl, lstLower3Points, _Settings.Below);//, strokePixAdjustVec);
							}
						}
					}
					#endregion

					#region Cloud
					if (_Settings.ShowShading && _Settings.VWAPDeviation != VWAPDeviation.None)
					{
						lstVwapPoints.Reverse();
						List<Point> lVwap_Upper1_ZonePoints = new List<Point>(lstUpper1Points.ToArray());
						lVwap_Upper1_ZonePoints.AddRange(lstVwapPoints.ToArray());
						DrawSharpDX.FillZone(renderTarget, chartControl, lVwap_Upper1_ZonePoints, _Settings.InnerZone, _Settings.Opacity);
						List<Point> lVwap_Lower1_ZonePoints = new List<Point>(lstLower1Points.ToArray());
						lVwap_Lower1_ZonePoints.AddRange(lstVwapPoints.ToArray());
						DrawSharpDX.FillZone(renderTarget, chartControl, lVwap_Lower1_ZonePoints, _Settings.InnerZone, _Settings.Opacity);
						if (_Settings.VWAPDeviation != VWAPDeviation.Deviation1)
						{
							lstUpper2Points.Reverse();
							lstLower2Points.Reverse();
							List<Point> lUpper1_Upper2_ZonePoints = new List<Point>(lstUpper1Points.ToArray());
							lUpper1_Upper2_ZonePoints.AddRange(lstUpper2Points.ToArray());
							DrawSharpDX.FillZone(renderTarget, chartControl, lUpper1_Upper2_ZonePoints, _Settings.MidZone, _Settings.Opacity);
							List<Point> lLower1_Lower2_ZonePoints = new List<Point>(lstLower1Points.ToArray());
							lLower1_Lower2_ZonePoints.AddRange(lstLower2Points.ToArray());
							DrawSharpDX.FillZone(renderTarget, chartControl, lLower1_Lower2_ZonePoints, _Settings.MidZone, _Settings.Opacity);
							if (_Settings.VWAPDeviation != VWAPDeviation.Deviation2)
							{
								List<Point> lUpper2_Upper3_ZonePoints = new List<Point>(lstUpper3Points.ToArray());
								lUpper2_Upper3_ZonePoints.AddRange(lstUpper2Points.ToArray());
								DrawSharpDX.FillZone(renderTarget, chartControl, lUpper2_Upper3_ZonePoints, _Settings.OuterZone, _Settings.Opacity);
								List<Point> lLower2_Lower3_ZonePoints = new List<Point>(lstLower3Points.ToArray());
								lLower2_Lower3_ZonePoints.AddRange(lstLower2Points.ToArray());
								DrawSharpDX.FillZone(renderTarget, chartControl, lLower2_Lower3_ZonePoints, _Settings.OuterZone, _Settings.Opacity);
							}
						}
					}
					#endregion
				}
				#endregion
			}
			#endregion

			#region Draw Line Text
			private void DrawLineText(SharpDX.Direct2D1.RenderTarget renderTarget, ChartControl chartControl, ChartScale chartScale, Instrument instrument, BarLocation start, BarLocation end, double price, Stroke stroke)
			{
				DrawSharpDX.Line(renderTarget, chartControl, chartScale, start.StartTime, price, end.EndTime, price, stroke);
				if (_Settings.ShowText)
					DrawSharpDX.Text(renderTarget, chartControl, chartScale, String.Format("{0} ", instrument.MasterInstrument.FormatPrice(price)), end.EndTime, price, stroke.Brush,
						_Settings.TextFont, SharpDXUtils.HorizontalAlignment.Right, SharpDXUtils.VerticalAlignment.Bottom);
			}
			#endregion

			#endregion

			#region Clone
			public object Clone()
			{
                ConcurrentDictionary<int, VwapStdDevValues> dicVWAP = new ConcurrentDictionary<int, VwapStdDevValues>();
                lock(_dicVWAP)
					foreach (KeyValuePair<int, VwapStdDevValues> key in _dicVWAP)
						dicVWAP.TryAdd(key.Key, key.Value.Clone() as VwapStdDevValues);
				return new VwapStdDevCalculator()
				{
					_dicVWAP = dicVWAP,
					_dTotalVol = _dTotalVol,
					_dTypicalTypicalVol = _dTypicalTypicalVol,
					_dTypicalVol = _dTypicalVol,
					_Settings = _Settings.Clone() as VWAPSettings
				};
			}
			#endregion
		}
        #endregion

        #region CWAP Calculator
        private class CwapStdDevCalculator : ICloneable
        {
            #region Floating Variables
            private double _dTypicalVol = 0;
            private double _dTotalVol = 0;
            private double _dTypicalTypicalVol = 0;

            private VWAPSettings _Settings = null;
            private ConcurrentDictionary<int, VwapStdDevValues> _dicVWAP = new ConcurrentDictionary<int, VwapStdDevValues>();
            #endregion

            #region Properties
            public VWAPSettings Settings { get { return _Settings; } }
            #endregion

            #region Initialize
            public void Initialize(VWAPSettings settings)
            {
                _Settings = settings.Clone() as VWAPSettings;
            }
            #endregion

            #region Calculations

            #region Reset
            public void Reset()
            {
				lock(_dicVWAP)
					_dicVWAP.Clear();
                _dTotalVol = 0;
                _dTypicalVol = 0;
                _dTypicalTypicalVol = 0;
            }
            #endregion

            #region Calculate One Bar
            public VwapStdDevValues CalculateOneBar(Cluster cluster, bool isBarClosed = true)
            {
                VwapStdDevValues result = new VwapStdDevValues();
                result.Bar = cluster.Bar.Clone() as BarLocation;

                double dTypicalVol = _dTypicalVol + cluster.Typical * cluster.Volume;
                double dTotalVol = _dTotalVol + cluster.Volume;
                double dTypicalTypicalVol = _dTypicalTypicalVol + cluster.Typical * cluster.Typical * cluster.Volume;

                if (dTotalVol != 0)
                    result.Wvap = dTypicalVol / dTotalVol;
                else
                    result.Wvap = cluster.Typical;

                double dDeviation = dTotalVol == 0 ? 0 : Math.Sqrt(Math.Max(dTypicalTypicalVol / dTotalVol - result.Wvap * result.Wvap, 0));

                result.StdDevUp1 = result.Wvap + dDeviation * _Settings.Deviation1;
                result.StdDevDown1 = result.Wvap - dDeviation * _Settings.Deviation1;
                result.StdDevUp2 = result.Wvap + dDeviation * _Settings.Deviation2;
                result.StdDevDown2 = result.Wvap - dDeviation * _Settings.Deviation2;
                result.StdDevUp3 = result.Wvap + dDeviation * _Settings.Deviation3;
                result.StdDevDown3 = result.Wvap - dDeviation * _Settings.Deviation3;

                if (isBarClosed)
                {
                    _dTypicalVol = dTypicalVol;
                    _dTotalVol = dTotalVol;
                    _dTypicalTypicalVol = dTypicalTypicalVol;
                }

                return result;
            }
            #endregion

            #region Calculate More Bars
            public void CalculateMoreBars(List<Cluster> clusters)
            {
                if (clusters.Count == 0)
                    return;
				lock (_dicVWAP)
				{
					_dicVWAP.Clear();
					for (int i = 0; i < clusters.Count; i++)
					{
						VwapStdDevValues result = CalculateOneBar(clusters[i]);
						if (result.Wvap != 0)
							_dicVWAP.TryAdd(clusters[i].Bar.No, result);
					}
				}
			}
			#endregion

			#region Calculate Current Bar
			public void CalculateCurrentBar(Cluster cluster)
            {
				if (cluster == null)
					return;
				lock (_dicVWAP)
				{
					if (_dicVWAP.ContainsKey(cluster.Bar.No))
						_dicVWAP[cluster.Bar.No] = CalculateOneBar(cluster, false);
					else
						_dicVWAP.TryAdd(cluster.Bar.No, CalculateOneBar(cluster, false));
				}
			}
			#endregion

			#region Calculate Closed Bar
			public void CalculateClosedBar(Cluster cluster)
            {
				if(cluster == null) return;
				lock (_dicVWAP)
				{
					if (_dicVWAP.ContainsKey(cluster.Bar.No))
						_dicVWAP[cluster.Bar.No] = CalculateOneBar(cluster, true);
					else
						_dicVWAP.TryAdd(cluster.Bar.No, CalculateOneBar(cluster, true));
				}
			}
			#endregion

			#endregion

			#region Draw All

			#region Draw
			public void Draw(SharpDX.Direct2D1.RenderTarget renderTarget, ChartControl chartControl, ChartScale chartScale, ChartBars bars, Instrument instrument)
			{
				if (_dicVWAP.Count == 0 || !_Settings.Show)
					return;

				List<int> keys = new List<int>();

                lock (_dicVWAP)
                    keys = _dicVWAP.Keys.ToList();
                keys.Sort();

                #region Draw Just the Lines
                if (_Settings.DrawLastValue)
				{
					lock (_dicVWAP)
					{
						VwapStdDevValues first = _dicVWAP[keys[0]];
						VwapStdDevValues last = _dicVWAP[keys[keys.Count - 1]];
						DrawLineText(renderTarget, chartControl, chartScale, instrument, first.Bar, last.Bar, last.Wvap, _Settings.Vwap);
						//DrawSharpDX.Line(renderTarget, chartControl, chartScale, first.Bar.StartTime, last.Wvap, last.Bar.EndTime, last.Wvap, _Settings.Vwap);
						if (_Settings.VWAPDeviation != VWAPDeviation.None)
						{
							DrawLineText(renderTarget, chartControl, chartScale, instrument, first.Bar, last.Bar, last.StdDevUp1, _Settings.Above);
							DrawLineText(renderTarget, chartControl, chartScale, instrument, first.Bar, last.Bar, last.StdDevDown1, _Settings.Below);
							if (_Settings.VWAPDeviation != VWAPDeviation.Deviation1)
							{
								DrawLineText(renderTarget, chartControl, chartScale, instrument, first.Bar, last.Bar, last.StdDevUp2, _Settings.Above);
								DrawLineText(renderTarget, chartControl, chartScale, instrument, first.Bar, last.Bar, last.StdDevDown2, _Settings.Below);
								if (_Settings.VWAPDeviation != VWAPDeviation.Deviation2)
								{
									DrawLineText(renderTarget, chartControl, chartScale, instrument, first.Bar, last.Bar, last.StdDevUp3, _Settings.Above);
									DrawLineText(renderTarget, chartControl, chartScale, instrument, first.Bar, last.Bar, last.StdDevDown3, _Settings.Below);
								}
							}
						}
					}
				}
				#endregion

				#region Draw Full VWAP
				else
				{
					#region Lines
					List<Point> lstUpper3Points = new List<Point>();
					List<Point> lstUpper2Points = new List<Point>();
					List<Point> lstUpper1Points = new List<Point>();
					List<Point> lstVwapPoints = new List<Point>();
					List<Point> lstLower1Points = new List<Point>();
					List<Point> lstLower2Points = new List<Point>();
					List<Point> lstLower3Points = new List<Point>();
					lock (_dicVWAP)
					{
						for (int i = 0; i <= keys.Count - 1; i++)
						{
							double x = chartControl.GetXByBarIndex(bars, keys[i]);
							lstUpper3Points.Add(new Point(x, chartScale.GetYByValue(_dicVWAP[keys[i]].StdDevUp3)));
							lstUpper2Points.Add(new Point(x, chartScale.GetYByValue(_dicVWAP[keys[i]].StdDevUp2)));
							lstUpper1Points.Add(new Point(x, chartScale.GetYByValue(_dicVWAP[keys[i]].StdDevUp1)));
							lstVwapPoints.Add(new Point(x, chartScale.GetYByValue(_dicVWAP[keys[i]].Wvap)));
							lstLower1Points.Add(new Point(x, chartScale.GetYByValue(_dicVWAP[keys[i]].StdDevDown1)));
							lstLower2Points.Add(new Point(x, chartScale.GetYByValue(_dicVWAP[keys[i]].StdDevDown2)));
							lstLower3Points.Add(new Point(x, chartScale.GetYByValue(_dicVWAP[keys[i]].StdDevDown3)));
						}
					}
					DrawSharpDX.DrawLine(renderTarget, chartControl, lstVwapPoints, _Settings.Vwap);//, strokePixAdjustVec);
					if (_Settings.VWAPDeviation != VWAPDeviation.None)
					{
						DrawSharpDX.DrawLine(renderTarget, chartControl, lstUpper1Points, _Settings.Above);//, strokePixAdjustVec);
						DrawSharpDX.DrawLine(renderTarget, chartControl, lstLower1Points, _Settings.Below);//, strokePixAdjustVec);
						if (_Settings.VWAPDeviation != VWAPDeviation.Deviation1)
						{
							DrawSharpDX.DrawLine(renderTarget, chartControl, lstUpper2Points, _Settings.Above);//, strokePixAdjustVec);
							DrawSharpDX.DrawLine(renderTarget, chartControl, lstLower2Points, _Settings.Below);//, strokePixAdjustVec);
							if (_Settings.VWAPDeviation != VWAPDeviation.Deviation2)
							{
								DrawSharpDX.DrawLine(renderTarget, chartControl, lstUpper3Points, _Settings.Above);//, strokePixAdjustVec);
								DrawSharpDX.DrawLine(renderTarget, chartControl, lstLower3Points, _Settings.Below);//, strokePixAdjustVec);
							}
						}
					}
					#endregion

					#region Cloud
					if (_Settings.ShowShading && _Settings.VWAPDeviation != VWAPDeviation.None)
					{
						lstVwapPoints.Reverse();
						List<Point> lVwap_Upper1_ZonePoints = new List<Point>(lstUpper1Points.ToArray());
						lVwap_Upper1_ZonePoints.AddRange(lstVwapPoints.ToArray());
						DrawSharpDX.FillZone(renderTarget, chartControl, lVwap_Upper1_ZonePoints, _Settings.InnerZone, _Settings.Opacity);
						List<Point> lVwap_Lower1_ZonePoints = new List<Point>(lstLower1Points.ToArray());
						lVwap_Lower1_ZonePoints.AddRange(lstVwapPoints.ToArray());
						DrawSharpDX.FillZone(renderTarget, chartControl, lVwap_Lower1_ZonePoints, _Settings.InnerZone, _Settings.Opacity);
						if (_Settings.VWAPDeviation != VWAPDeviation.Deviation1)
						{
							lstUpper2Points.Reverse();
							lstLower2Points.Reverse();
							List<Point> lUpper1_Upper2_ZonePoints = new List<Point>(lstUpper1Points.ToArray());
							lUpper1_Upper2_ZonePoints.AddRange(lstUpper2Points.ToArray());
							DrawSharpDX.FillZone(renderTarget, chartControl, lUpper1_Upper2_ZonePoints, _Settings.MidZone, _Settings.Opacity);
							List<Point> lLower1_Lower2_ZonePoints = new List<Point>(lstLower1Points.ToArray());
							lLower1_Lower2_ZonePoints.AddRange(lstLower2Points.ToArray());
							DrawSharpDX.FillZone(renderTarget, chartControl, lLower1_Lower2_ZonePoints, _Settings.MidZone, _Settings.Opacity);
							if (_Settings.VWAPDeviation != VWAPDeviation.Deviation2)
							{
								List<Point> lUpper2_Upper3_ZonePoints = new List<Point>(lstUpper3Points.ToArray());
								lUpper2_Upper3_ZonePoints.AddRange(lstUpper2Points.ToArray());
								DrawSharpDX.FillZone(renderTarget, chartControl, lUpper2_Upper3_ZonePoints, _Settings.OuterZone, _Settings.Opacity);
								List<Point> lLower2_Lower3_ZonePoints = new List<Point>(lstLower3Points.ToArray());
								lLower2_Lower3_ZonePoints.AddRange(lstLower2Points.ToArray());
								DrawSharpDX.FillZone(renderTarget, chartControl, lLower2_Lower3_ZonePoints, _Settings.OuterZone, _Settings.Opacity);
							}
						}
					}
					#endregion
				}
				#endregion
			}
			#endregion

			#region Draw Line Text
			private void DrawLineText(SharpDX.Direct2D1.RenderTarget renderTarget, ChartControl chartControl, ChartScale chartScale, Instrument instrument, BarLocation start, BarLocation end, double price, Stroke stroke)
            {
                DrawSharpDX.Line(renderTarget, chartControl, chartScale, start.StartTime, price, end.EndTime, price, stroke);
                if (_Settings.ShowText)
                    DrawSharpDX.Text(renderTarget, chartControl, chartScale, String.Format("{0} ", instrument.MasterInstrument.FormatPrice(price)), end.EndTime, price, stroke.Brush,
                        _Settings.TextFont, SharpDXUtils.HorizontalAlignment.Right, SharpDXUtils.VerticalAlignment.Bottom);
            }
            #endregion

            #endregion

            #region Clone
            public object Clone()
            {
                ConcurrentDictionary<int, VwapStdDevValues> dicVWAP = new ConcurrentDictionary<int, VwapStdDevValues>();
                lock (_dicVWAP)
                    foreach (KeyValuePair<int, VwapStdDevValues> key in _dicVWAP)
						dicVWAP.TryAdd(key.Key, key.Value.Clone() as VwapStdDevValues);
                return new CwapStdDevCalculator()
                {
                    _dicVWAP = dicVWAP,
                    _dTotalVol = _dTotalVol,
                    _dTypicalTypicalVol = _dTypicalTypicalVol,
                    _dTypicalVol = _dTypicalVol,
                    _Settings = _Settings.Clone() as VWAPSettings
                };
            }
            #endregion
        }
        #endregion

        #endregion

        #region Cluster Classes

        #region Cluster Settings
        private class ClusterSettings : ICloneable
		{
			#region Floating Varialbes
			private SharpDX.RectangleF _rectShowBorder = new SharpDX.RectangleF();
			private SharpDX.RectangleF _rectShowShading = new SharpDX.RectangleF();
			private SharpDX.RectangleF _rectAll = new SharpDX.RectangleF();
			#endregion

			#region Properties
			public int ClusterTicks { get; set; }
			public Stroke Stroke { get; set; }
			public int Opacity { get; set; } 
			public ClusterDisplay Show { get; set; }
			public bool ShowBorder { get; set; }
			public bool ShowShading { get; set; }
			#endregion

			#region Clone
			public object Clone()
			{
				Stroke stroke = Stroke.Clone() as Stroke;
                return new ClusterSettings()
				{
					ClusterTicks = ClusterTicks,
					Stroke = stroke,
					Opacity = Opacity,
					ShowBorder = ShowBorder,
					ShowShading = ShowShading,
					Show = Show
				};
			}
			#endregion

			#region Draw
			public void Draw(SharpDX.Direct2D1.RenderTarget renderTarget, ChartControl chartControl, ChartScale chartScale, SimpleFont simpleFont, int opacity, Stroke stroke, Brush brush, float y, float x)
			{
				Size size0 = SharpDXUtils.MeasureString("SS", simpleFont);
				Size size1 = SharpDXUtils.MeasureString("SB", simpleFont);
				Size size2 = SharpDXUtils.MeasureString("Cluster:", simpleFont);
				float fHeight = (float)Math.Max(Math.Max(size0.Height, size1.Height), size2.Height);

				_rectShowShading = new SharpDX.RectangleF(x, y, (float)size0.Width, fHeight);
				_rectShowBorder = new SharpDX.RectangleF(x + (float)size0.Width + 2f, y, (float)size1.Width, fHeight);
				SharpDX.RectangleF rectTitle = new SharpDX.RectangleF(x + (float)size0.Width + 2f + (float)size1.Width + 2f, y, (float)size2.Width, fHeight);
				float fLeft = x + (float)size0.Width + 2f + (float)size1.Width + 2f + (float)size2.Width + 2f;
				_rectAll = new SharpDX.RectangleF(fLeft, y, x - fLeft, fHeight);

				DrawSharpDX.BoxText(renderTarget, "SS", _rectShowShading, stroke, opacity, brush, simpleFont, true, true, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale), null, false, 0, SharpDXUtils.HorizontalAlignment.Right);
				DrawSharpDX.BoxText(renderTarget, "SB", _rectShowBorder, stroke, opacity, brush, simpleFont, true, true, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale), null, false, 0, SharpDXUtils.HorizontalAlignment.Right);
				DrawSharpDX.BoxText(renderTarget, "Cluster:", rectTitle, stroke, opacity, brush, simpleFont, true, true, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale), null, false, 0, SharpDXUtils.HorizontalAlignment.Right);
			}
			#endregion

			#region In Hit Test
			public bool InHitTest(float x, float y)
			{
				SharpDX.RectangleF rect = new SharpDX.RectangleF(x - 1f, y - 1f, 2f, 2f);
				if (_rectShowShading.Intersects(rect))
				{
					ShowShading = !ShowShading;
					return true;
				}
				return false;
			}
			#endregion

			#region Is Hovering
			public bool IsHovering(float x, float y)
			{
				SharpDX.RectangleF rect = new SharpDX.RectangleF(x - 1f, y - 1f, 2f, 2f);
				if (_rectAll.Intersects(rect))
					return true;
				return false;
			}
			#endregion
        }
        #endregion

        #region Cluster
        private class Cluster : ICloneable
		{
			#region Floating Variables
			private ClusterSettings _Settings = null;
			private BarLocation _Bar = null;
			#endregion

			#region Properties
			public double High { get; set; }
			public double Low { get; set; }
			public double Volume { get; set; }
			public bool AddToProfile { get { return true; } }
            public BarLocation Bar { get { return _Bar; } set { _Bar = value; } }
			public double Typical { get { return (High + Low) / 2; } }
			public ClusterSettings Settings { get { return _Settings; } }
            #endregion

            #region Initialize
            public void Initialize(ClusterSettings settings, BarLocation bar)
			{
				_Settings = settings.Clone() as ClusterSettings;
				_Bar = bar.Clone() as BarLocation;
				Volume = 0;
				Low = 0;
				High = 0;
			}
			#endregion

			#region Calculate
			public void Calculate(ConcurrentDictionary<double, PriceDetails> Prices)
			{
                //if (Bar.EndTime.CompareTo(new DateTime(2022, 10, 6, 23, 30, 0, 0)) >= 0)
                //{

                //}
                Volume = 0;
				Low = 0;
				High = 0;
				if (Prices.Count < _Settings.ClusterTicks)
				{
                    List<double> tempKeys = Prices.Keys.ToList();
                    tempKeys.Sort();
                    Low = Prices[tempKeys[0]].Low;
					High = Prices[tempKeys[tempKeys.Count - 1]].High;
                    for (int i = 0; i < tempKeys.Count; i++)
						Volume += Prices[tempKeys[i]].Volume;
					return;
				}
				bool bDivizible = (_Settings.ClusterTicks % 2) == 0;
				int iHalf = (bDivizible ? _Settings.ClusterTicks : _Settings.ClusterTicks - 1) / 2;

				List<double> keys = Prices.Keys.ToList();
				keys.Sort();
				for (int i = iHalf; i < keys.Count - iHalf; i++)
				{
                    double dVolume = Prices[keys[i]].Volume;
					double high = Prices[keys[i]].High;
					double low = Prices[keys[i]].Low;
					int steps = bDivizible ? iHalf - 1 : iHalf;
					for (int j = 1; j <= steps; j++)
					{
						dVolume += Prices[keys[i + j]].Volume;
						high = Prices[keys[i + j]].High;
					}
					for (int j = 1; j <= steps; j++)
					{
						dVolume += Prices[keys[i - j]].Volume;
						low = Prices[keys[i - j]].Low;
					}
					if (bDivizible)
					{
                        double dFloaterAbove = Prices[keys[i + iHalf]].Volume;
                        double dFloaterBelow = Prices[keys[i - iHalf]].Volume;
						if (dFloaterAbove > dFloaterBelow)
						{
							dVolume += dFloaterAbove;
							high = Prices[keys[i + iHalf]].High;
						}
						else
						{
							dVolume += dFloaterBelow;
							low = Prices[keys[i - iHalf]].Low;
						}
					}
					if (dVolume > Volume)
					{
						Volume = dVolume;
						High = high;
						Low = low;
					}
				}
			}
			#endregion

			#region Draw
			public void Draw(SharpDX.Direct2D1.RenderTarget renderTarget, ChartControl chartControl, ChartScale chartScale, ClusterSettings settings = null, bool inProfile = false)
			{
				if (_Bar == null)
					return;
				ClusterSettings Settings = settings == null ? _Settings : settings;
                if (Settings == null || Settings.Show == ClusterDisplay.None || (Settings.Show != ClusterDisplay.AllBars && !inProfile))
					return;

				DrawSharpDX.Box(renderTarget, chartControl, chartScale, Settings.Stroke, _Bar.StartTime, High, _Bar.EndTime, Low, Settings.Opacity, Settings.ShowBorder, Settings.ShowShading, 0.5f, SharpDXUtils.HorizontalAlignment.Left);
			}
			#endregion

			#region Clone
			public object Clone()
			{
                return new Cluster()
                {
                    High = High,
                    Low = Low,
                    Volume = Volume,
                    _Bar = _Bar.Clone() as BarLocation,
                    _Settings = _Settings.Clone() as ClusterSettings
                };
            }
            #endregion
        }
        #endregion

        #endregion

        #endregion

        #region Bar Related Classes

        #region Bar Location
        private class BarLocation : ICloneable
		{
			public int No { get; set; }
			public DateTime StartTime { get; set; }
			public DateTime EndTime { get; set; }
			public object Clone()
			{
				return new BarLocation() { No = No, StartTime = StartTime, EndTime = EndTime };
			}
		}
		#endregion

		#region Bar Details
		private class BarDetails : PriceDetails
		{
			#region Properties
			public double Typical { get; set; }
			public double Open { get; set; }
			public double Close { get; set; }
			public BarLocation Bar { get; set; }
			#endregion

			#region Constructors
			public BarDetails() : base()
			{
				Typical = 0;
				Bar = new BarLocation();
			}

			public BarDetails(BarLocation bar)
			{
				Bar = bar;
			}
			#endregion

			#region Update OHLC
			public void UpdateOHLCV(double open, double high, double low, double close, double ask, double bid)
			{
				Open = open;
				High = high;
				Low = low;
				Close = close;
				Typical = (high + low + close) / 3;
				Ask = ask;
				Bid = bid;
			}
			#endregion

			#region Update All Data
			public void UpdateAllData(double price, double bid, double ask)
			{
				Bid += bid;
				Ask += ask;
				if (High < price)
					High = price;
				if (Low > price)
					Low = price;
				Typical = (High + Low + price) / 3;
			}
			#endregion

			#region Do We Overlap
			public bool DoWeOverlap(BarDetails otherBar)
			{
				return High > otherBar.Low && Low < otherBar.High;
			}
			#endregion

			#region How Much In Range
			public BarDetails HowMuchIsInRange(BarDetails otherBar)
			{
				//we first grab the high and the low of the range that overlaps our bar
				double dHigh = Math.Min(otherBar.High, High);
				double dLow = Math.Max(otherBar.Low, Low);
				//after which we reduce the stored volume to the percent of the bar that is overlapped
				double dVolumeLeft = ((dHigh - dLow) / (otherBar.High - otherBar.Low)) * otherBar.Volume;
				//after this we return a new BarDetails object with the opverlapping values
				return new BarDetails(otherBar.Bar) { High = dHigh, Low = dLow, Bid = dVolumeLeft / 2, Ask = dVolumeLeft / 2 };
			}
			#endregion

			#region Clone
			public override object Clone()
			{
				return new BarDetails() { Ask = Ask, Bid = Bid, High = High, Low = Low, Close = Close, Open = Open, Bar = Bar.Clone() as BarLocation, Typical = Typical };
			}
			#endregion
		}
		#endregion

		#region BarInfo Class
		private class BarInfo : ICloneable
		{
			#region Floating Variables
			private double _dStep = 0;
			private double _dTickSize = 0;
			private double _dStepTicks = 0;
			private ConcurrentDictionary<double, PriceDetails> _TickPrices = new ConcurrentDictionary<double, PriceDetails>();
            #endregion

            #region Properties
            public ConcurrentDictionary<double, PriceDetails> Prices { get; set; }
			public ConcurrentDictionary<double, PriceDetails> TempPrices { get; set; }
			public BarDetails BarDetails { get; set; }
			//public PocDetails PocDetails { get; set; }
			public Cluster ClusterDetails { get; set; }
			#endregion

			#region Constructors
			public BarInfo() { }
			public BarInfo(BarDetails bar, double step, Instrument instrument, ClusterSettings clusterSettings)
			{
				Prices = new ConcurrentDictionary<double, PriceDetails>();
				TempPrices = new ConcurrentDictionary<double, PriceDetails>();
				BarDetails = bar.Clone() as BarDetails;
                ClusterDetails = new Cluster();
				_dStep = step;
				_dTickSize = instrument.MasterInstrument.TickSize;
				_dStepTicks = instrument.MasterInstrument.RoundToTickSize(_dTickSize * _dStep);
				ClusterDetails.Initialize(clusterSettings, bar.Bar);
			}
			#endregion

			#region Update Bar Location
			public void UpdateBarLocation(BarLocation bar)
			{
				//PocDetails.Bar = bar;
				ClusterDetails.Bar = bar;
				BarDetails.Bar = bar;
			}
			#endregion

			#region Update OHLC
			public void UpdateOHLC(double open, double high, double low, double close, Instrument instrument)
			{
				//first we check to make sure that the low has changed
				if (BarDetails.Low != low)
				{
					//then we grab the lowest bracket for the low
					double dLowLow, dLowHigh;
					CalculateMinMaxPrice(low, instrument, out dLowLow, out dLowHigh);
					//if the price dictionary doesn't contain this price
					if (!Prices.ContainsKey(dLowLow))
					{
						//we add this price to the dictionary
						Prices.TryAdd(dLowLow, new PriceDetails() { Low = dLowLow, High = dLowHigh, Ask = 0, Bid = 0 });
						//then we check the next price bracket to make sure that it exists
						if (!Prices.ContainsKey(dLowHigh))
						{
							//if it doesn't exist, then we calculate the maximum number of steps from the low to the high
							//we do this because we assume that no price was updated up to the high - better safe than sorry
							int iMaxSteps = Convert.ToInt32(Math.Ceiling((high - dLowLow) / _dStepTicks));
							//we check to have more than 1 step (meaning the step that we just added)
							if (iMaxSteps > 1)
							{
								//then we set up this for to run through all the prices that might be in this bar and add the missing ones
								//once we hit the first price from the low that is already in the dictionary, then we break out and move on as there is no need to go through all the prices that are in the dictionary
								for (int i = 1; i < iMaxSteps; i++)
								{
									double dLow = instrument.MasterInstrument.RoundToTickSize(dLowLow + i * _dStepTicks);
									if (!Prices.ContainsKey(dLow))
										Prices.TryAdd(dLow, new PriceDetails() { Low = dLow, High = instrument.MasterInstrument.RoundToTickSize(dLow + _dStepTicks), Ask = 0, Bid = 0 });
									else
										break;
								}
							}
						}
					}
				}

				//next we check to make sure that the high has changed
				if (BarDetails.High != high)
				{
					//then we grab the lowest bracket for the high
					double dHighLow, dHighHigh;
					CalculateMinMaxPrice(low, instrument, out dHighLow, out dHighHigh);
					if (!Prices.ContainsKey(dHighLow))
					{
						//we add this price to the dictionary
						Prices.TryAdd(dHighLow, new PriceDetails() { Low = dHighLow, High = dHighHigh, Ask = 0, Bid = 0 });
						//then we check the next lower price bracket to make sure that it exists
						if (!Prices.ContainsKey(dHighLow - _dStepTicks))
						{
							//if it doesn't exist, then we calculate the maximum number of steps from the high to the low
							//we do this, even though the low would have added the prices all the way to the high, because we break out of this anyway and it gives us a limit without having to create a while loop
							int iMaxSteps = Convert.ToInt32(Math.Ceiling((dHighHigh - low) / _dStepTicks));
							//we check to have more than 1 step (meaning the step that we just added)
							if (iMaxSteps > 1)
							{
								//then we set up this for to run through all the prices that might be in this bar and add the missing ones
								//once we hit the first price from the high, down, that is already in the dictionary, then we break out and move on as there is no need to go through all the prices that are in the dictionary
								for (int i = 1; i < iMaxSteps; i++)
								{
									double dHigh = instrument.MasterInstrument.RoundToTickSize(dHighLow - i * _dStepTicks);
									if (!Prices.ContainsKey(dHigh))
										Prices.TryAdd(dHigh, new PriceDetails() { Low = dHigh, High = instrument.MasterInstrument.RoundToTickSize(dHigh + _dStepTicks), Ask = 0, Bid = 0 });
									else
										break;
								}
							}
						}
					}
				}

				BarDetails.UpdateOHLCV(open, high, low, close, 0, 0);
			}
			#endregion

			#region Add Price
			public void AddPrice(double price, double bid, double ask, bool calculatePOC, Instrument instrument)
			{
				//get the min and max price for the price that came in according to the step 
				double dPriceMin, dPriceMax;
				CalculateMinMaxPrice(price, instrument, out dPriceMin, out dPriceMax);
				//if the prices dictionary contains the minimum price then we add the new data to that price
				if (Prices.ContainsKey(dPriceMin))
					Prices[dPriceMin].UpdateBidAsk(bid, ask);
				//if it doesn't contain that price level we add it to the dictionary so that we can store it
				else
					Prices.TryAdd(dPriceMin, new PriceDetails() { High = dPriceMax, Low = dPriceMin, Bid = bid, Ask = ask });
				//After we do the additions to the dictionary, we need to check the price of the current bar to update the true high and low of the current bar
				BarDetails.UpdateAllData(price, bid, ask);
				//if (calculatePOC)
				//	CalculatePOC();
			}
			#endregion

			#region Calculate POC
			//public void CalculatePOC()
			//{
   //             PocDetails.CalculatePOC(Prices, PocDetails.PocValue);
			//}
			#endregion

			#region Calculate Min Max Price
			private void CalculateMinMaxPrice(double price, Instrument instrument, out double priceMin, out double priceMax)
			{
				//we get the number of steps that we need to increase for the new incomming price (ie. 3.2598)
				double dSteps = Math.Round(instrument.MasterInstrument.RoundToTickSize(price) / instrument.MasterInstrument.RoundToTickSize(_dStep * instrument.MasterInstrument.TickSize), 5);
				//from this base number of steps we need to grab the price for a full step above and below the step that we found (ie. 4 & 3)
				int iStepMin = (int)Math.Floor(dSteps);
				int iStepMax = (int)Math.Ceiling(dSteps);
				//if both steps are the same value (meaning the price was right on the low of the step, then we add one more step to the maximum to make sure that we get the correct range
				if (iStepMin == iStepMax)
					iStepMax = iStepMax + 1;
				//once we have the steps above and below, then we grab the prices for above and below so we can see where to store the values in the dictionary
				priceMin = instrument.MasterInstrument.RoundToTickSize(iStepMin * _dStep * instrument.MasterInstrument.TickSize);
				priceMax = instrument.MasterInstrument.RoundToTickSize(iStepMax * _dStep * instrument.MasterInstrument.TickSize);
			}
			#endregion

			#region Is Bar In Range
			public EInRange IsBarInRange(BarDetails lTF_Bar)
			{
				if (lTF_Bar.Bar.StartTime.CompareTo(BarDetails.Bar.StartTime) >= 0 && lTF_Bar.Bar.EndTime.CompareTo(BarDetails.Bar.EndTime) <= 0)
					return EInRange.Full;
				else if (lTF_Bar.Bar.StartTime.CompareTo(BarDetails.Bar.EndTime) < 0 && lTF_Bar.Bar.EndTime.CompareTo(BarDetails.Bar.StartTime) > 0)
					return EInRange.Partial;
				return EInRange.None;
			}
			#endregion

			#region Update Volume
			public void UpdateVolume(List<BarDetails> volumeToUpdate, bool isTemp, Instrument instrument)
			{
				//whatever happens we reset the temp volume as we enter
				//if we are only adding temps then we don't wnat to pile on to the temps as they get recalculated every time
				//if we are adding to the full volume then we need to reset the temps because we don't need them anymore and they need to be empty for the next LTF bar that comes in
				ResetAllTempVolume();
				//we cycle through all the volumes to add in the list
				for (int i = 0; i < volumeToUpdate.Count; i++)
				{
					BarDetails bar = volumeToUpdate[i];
					//we grab the lowest bracket
					double dPriceMin, dPriceMax;
					CalculateMinMaxPrice(bar.Low, instrument, out dPriceMin, out dPriceMax);

					//we find out the number of steps
					int iSteps = Math.Max(Convert.ToInt32((bar.High - dPriceMin) / _dStepTicks), 1);
                    //it happens sometimes that the price min is equal to the price that is comming in when the bar has the same low and the same high and they are right at the bottom of a price range
                    //for that instance we need check that the steps aren't 0 and we need to keep the steps to 1 to put the volume somewhere
                    //we find the volume per step
                    double volume = bar.Volume / iSteps;
                    double halfVolume = volume / 2;
					//we go through each step
					for (int j = 0; j < iSteps; j++)
					{
						double priceLow = instrument.MasterInstrument.RoundToTickSize(dPriceMin + j * _dStepTicks);
						//we make sure that we have this step in the mother bar
						if (!Prices.ContainsKey(priceLow))
							Prices.TryAdd(priceLow, new PriceDetails() { Low = priceLow, High = instrument.MasterInstrument.RoundToTickSize(priceLow + _dStepTicks) });
                        //{
                        //we add the volume to the certain step
                            if (isTemp)
							{
								//if we are adding to the temp then add them here
								Prices[priceLow].TempAsk += halfVolume;
								Prices[priceLow].TempBid += halfVolume;
								//we also add to the toatal volume
								BarDetails.TempAsk += halfVolume;
								BarDetails.TempBid += halfVolume;
							}
							else
							{
								//if we add them to the normal then we add them here
								Prices[priceLow].Ask += halfVolume;
								Prices[priceLow].Bid += halfVolume;
								//Also we add to the toatl volume
								BarDetails.Ask += halfVolume;
								BarDetails.Bid += halfVolume;
							}
						//}
					}

					//here we update the prices for the the clusters becuase they need to store the data in tick form not in steps
					iSteps = Math.Max(Convert.ToInt32((bar.High - bar.Low) / _dTickSize), 1);
                    volume = bar.Volume / iSteps;
                    halfVolume = volume / 2;
                    for (int j = 0; j < iSteps; j++)
                    {
                        double priceLow = instrument.MasterInstrument.RoundToTickSize(bar.Low + j * _dTickSize);
                        //we make sure that we have this step in the mother bar
                        if (!_TickPrices.ContainsKey(priceLow))
                            _TickPrices.TryAdd(priceLow, new PriceDetails() { Low = priceLow, High = instrument.MasterInstrument.RoundToTickSize(priceLow + _dTickSize) });
                        //we add the volume to the certain step
                        if (isTemp)
                        {
                            //if we are adding to the temp then add them here
                            _TickPrices[priceLow].TempAsk += halfVolume;
                            _TickPrices[priceLow].TempBid += halfVolume;
                        }
                        else
                        {
                            //if we add them to the normal then we add them here
                            _TickPrices[priceLow].Ask += halfVolume;
                            _TickPrices[priceLow].Bid += halfVolume;
                        }
                    }
                }
                //CalculatePOC();
				ClusterDetails.Calculate(_TickPrices);
			}

			#endregion

			#region Reset All Temp Volume
			private void ResetAllTempVolume()
			{
				//First we check to see if we have prices
				//if we don't then we surely don't have any volume in the full bar either
				if (Prices.Count > 0)
				{
					//first we reset the full bar temp volume
					BarDetails.TempAsk = 0;
					BarDetails.TempBid = 0;
					//then we go through each price and reset the temp volume
					IEnumerable<double> lstKeys = Prices.Keys;
					foreach (double key in lstKeys)
					{
						Prices[key].TempAsk = 0;
						Prices[key].TempBid = 0;
					}
				}
				if (_TickPrices.Count > 0)
				{
					//then we go through each price and reset the temp volume
					IEnumerable<double> lstKeys = _TickPrices.Keys;
					foreach (double key in lstKeys)
					{
						_TickPrices[key].TempAsk = 0;
						_TickPrices[key].TempBid = 0;
					}
				}
			}
            #endregion

            #region Draw
            public void Draw(SharpDX.Direct2D1.RenderTarget renderTarget, ChartControl chartControl, ChartScale chartScale, ClusterSettings settings = null)
            {
                ClusterDetails.Draw(renderTarget, chartControl, chartScale, settings, false);
            }
			#endregion

			#region Clone
			public object Clone()
			{
                //Prices
                ConcurrentDictionary<double, PriceDetails> prices = new ConcurrentDictionary<double, PriceDetails>();
				List<double> keys = Prices.Keys.ToList();
				for (int i = 0; i < keys.Count; i++)
					prices.TryAdd(keys[i], Prices[keys[i]].Clone() as PriceDetails);
                //Temp Prices
                ConcurrentDictionary<double, PriceDetails> tempPrices = new ConcurrentDictionary<double, PriceDetails>();
				keys = TempPrices.Keys.ToList();
				for (int i = 0; i < keys.Count; i++)
					tempPrices.TryAdd(keys[i], TempPrices[keys[i]].Clone() as PriceDetails);

				return new BarInfo()
				{
					BarDetails = BarDetails.Clone() as BarDetails,
					ClusterDetails = ClusterDetails.Clone() as Cluster,
					_dStep = _dStep,
					_dStepTicks = _dStepTicks,
					_dTickSize = _dTickSize,
					Prices = prices,
					TempPrices = tempPrices
				};
			}
			#endregion
		}
		#endregion

		#endregion

		#region Profile Class

		#region Profile Settings
		private class ProfileSettings : ICloneable
		{
			#region Properties
			public bool Show { get; set; }
			public int NormalOpac { get; set; }
			public int VAOpac { get; set; }
			public double ValueAreaPercent { get; set; }
			public double ProfilePercent { get; set; }
			public double ProfilePercentRight { get; set; }
			public bool IsItCalculating { get; set; }
			public bool IsRight { get; set; }
			public bool ShowPOC { get; set; }
			public bool ShowVAH { get; set; }
			public bool ShowVAL { get; set; }
			public bool ShowProfile { get; set; }
			public bool ShowExtremes { get; set; }
			public bool ShowText { get; set; }
			public bool IsHistorical { get; set; }
			public SimpleFont Text { get; set; }
			public Stroke POC { get; set; }
			public Stroke VAH { get; set; }
			public Stroke VAL { get; set; }
			public Stroke Profile { get; set; }
			public Stroke Extremes { get; set; }
			#endregion

			#region Clone
			public object Clone()
			{
				return new ProfileSettings()
				{
                    Show = Show,
                    IsHistorical = IsHistorical,
					NormalOpac = NormalOpac,
					VAOpac = VAOpac,
					Extremes = Extremes.Clone() as Stroke,
					ProfilePercent = ProfilePercent,
					ProfilePercentRight = ProfilePercentRight,
					IsItCalculating = IsItCalculating,
					IsRight = IsRight,
					POC = POC.Clone() as Stroke,
					Profile = Profile.Clone() as Stroke,
					ShowExtremes = ShowExtremes,
					ShowText = ShowText,
					ShowPOC = ShowPOC,
					ShowProfile = ShowProfile,
					ShowVAH = ShowVAH,
					ShowVAL = ShowVAL,
					VAH = VAH.Clone() as Stroke,
					VAL = VAL.Clone() as Stroke,
					Text = Text.Clone() as SimpleFont
				};
			}
			#endregion
		}
		#endregion

		private class ProfileSettingsManager
		{

		}

		#region Profile
		private class Profile : ICloneable
		{
            #region Floating Variables
            private int _iCenterBar = 0;
            private int _iRightBar = 0;
            private int _iLeftBar = 0;
            private double _lTotalVolTemp = 0;
            private SharpDX.RectangleF _FullProfile = new SharpDX.RectangleF();
            private SharpDX.RectangleF _LeftProfile = new SharpDX.RectangleF();
            private SharpDX.RectangleF _RightProfile = new SharpDX.RectangleF();
            private SharpDX.RectangleF _MidProfile = new SharpDX.RectangleF();
            private ConcurrentDictionary<double, PriceDetails> _dicPrices = new ConcurrentDictionary<double, PriceDetails>();
			private ProfileSettings _Settings = null;
			#endregion

			#region Properties
			public BarLocation Start { get; set; }
			public BarLocation End { get; set; }
			public double High { get; set; }
			public double Low { get; set; }
			public PocDetails POC { get; set; }
			public double TotalVol { get; set; }
			public VwapStdDevCalculator VWAP { get; set; }
			public CwapStdDevCalculator CWAP { get; set; }
			public bool IsEditing { get; set; }
			public bool IsLeftAdjusted { get; set; }
			public bool IsRightAdjusted { get; set; }
			public bool IsCenterAdjusted { get; set; }
			public bool IsHovered { get; set; }
			public bool IsSelected { get; set; }
			public List<Cluster> Clusters { get; set; }
			public ProfileSettings Settings { get { return _Settings; } }
            #endregion

            #region Profile
            public Profile()
			{
				Start = new BarLocation();
				End = new BarLocation();
				High = double.MinValue;
				Low = double.MaxValue;
				POC = new PocDetails();
				TotalVol = 0;
				VWAP = new VwapStdDevCalculator();
				CWAP = new CwapStdDevCalculator();
				IsEditing = false;
				Clusters = new List<Cluster>();
				IsLeftAdjusted = false;
				IsRightAdjusted = false;
				IsCenterAdjusted = false;
				IsSelected = false;
            }
			#endregion

			#region Initialize
			public void Initialize(BarLocation bar, double step, int stepSize, VWAPSettings vwapSettings, VWAPSettings cwapSettings, ProfileSettings profileSettings)
			{
				_Settings = profileSettings.Clone() as ProfileSettings;
				POC.Initialize(bar, profileSettings.ValueAreaPercent, step, stepSize);
				VWAP.Initialize(vwapSettings);
				CWAP.Initialize(cwapSettings);
			}
			#endregion

			#region Reset
			public void Reset()
			{
				POC.Reset();
                VWAP.Reset();
                CWAP.Reset();
				Clusters.Clear();
                lock (_dicPrices)
                    _dicPrices.Clear();
                TotalVol = 0;
            }
            #endregion

            #region Update Profile
            public void UpdateProfile(ConcurrentDictionary<int, BarInfo> bars, int currentBar, Instrument instrument)
			{
				_Settings.IsItCalculating = true;

				IsEditing = false;
				IsLeftAdjusted = false;
				IsRightAdjusted = false;
				IsCenterAdjusted = false;
				High = double.MinValue;
				Low = double.MaxValue;

				int iEndBar = End.No > currentBar ? currentBar : End.No;
				if (bars.ContainsKey(Start.No) && bars.ContainsKey(iEndBar))
				{
					ConcurrentDictionary<int, BarInfo> neededBars = new ConcurrentDictionary<int, BarInfo>();
					try
					{
						int iSteps = iEndBar - Start.No;
						for (int i = 0; i <= iSteps; i++)
						{
							BarInfo bar = bars[Start.No + i];
							neededBars.TryAdd(Start.No + i, bar);
							if (bar.ClusterDetails.AddToProfile)
								Clusters.Add(bar.ClusterDetails.Clone() as Cluster);
							High = Math.Max(High, bar.BarDetails.High);
							Low = Math.Min(Low, bar.BarDetails.Low);
							if (bar.Prices.Count > 0)
							{
								IEnumerable<double> keys = bar.Prices.Keys;
								lock (_dicPrices)
								{
									foreach (double key in keys)
									{
										if (_dicPrices.ContainsKey(key))
											_dicPrices[key].UpdateBidAsk(bar.Prices[key]);
										else
											_dicPrices.TryAdd(key, bar.Prices[key].Clone() as PriceDetails);
									}
								}
							}
						}
						lock (_dicPrices)
							TotalVol = POC.CalculatePOC(_dicPrices, instrument);
					}
					catch (Exception ex)
					{
						
					}
					VWAP.CalculateMoreBars(neededBars);
					CWAP.CalculateMoreBars(Clusters);
				}
				_Settings.IsItCalculating = false;
			}

			public void UpdateSingleTemp(BarInfo bar, int currentBar)
			{
				//still needs work
            }
            public void UpdateSingleClosedBar(BarInfo bar, int currentBar, Instrument instrument, bool updateAnyway = false)
			{
				if (!updateAnyway && _Settings.IsHistorical)
					return;
				try
				{
					_lTotalVolTemp = 0;
					if (bar.ClusterDetails.AddToProfile)
						Clusters.Add(bar.ClusterDetails.Clone() as Cluster);
					High = Math.Max(High, bar.BarDetails.High);
					Low = Math.Min(Low, bar.BarDetails.Low);
					if (!updateAnyway)
						End = bar.BarDetails.Bar;
					if (bar.Prices.Count > 0)
					{
						IEnumerable<double> keys = bar.Prices.Keys;
						lock (_dicPrices)
						{
							foreach (double key in keys)
							{
								if (_dicPrices.ContainsKey(key))
									_dicPrices[key].UpdateBidAsk(bar.Prices[key]);
								else
									_dicPrices.TryAdd(key, bar.Prices[key].Clone() as PriceDetails);
							}
						}
					}
					lock (_dicPrices)
						TotalVol = POC.CalculatePOC(_dicPrices, instrument);
				}
				catch (Exception ex)
				{
					
				}
				VWAP.CalculateClosedBar(bar?.BarDetails?.Clone() as BarDetails);
                CWAP.CalculateClosedBar(bar.ClusterDetails.Clone() as Cluster);
            }
            #endregion

            #region Draw

            #region Draw Just Box
            public void DrawJustBox(SharpDX.Direct2D1.RenderTarget renderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke)
			{
				if (stroke == null)
					return;
				DrawSharpDX.Box(renderTarget, chartControl, chartScale, stroke, Start.StartTime, High, End.EndTime, Low, 10, true, true);
				DrawSharpDX.Text(renderTarget, chartControl, chartScale, "Building", End.EndTime, Low, stroke.Brush, new SimpleFont("Century Gothic", 10), SharpDXUtils.HorizontalAlignment.Right, SharpDXUtils.VerticalAlignment.Bottom);
				if (_Settings.IsItCalculating)
					return;
			}
			#endregion

			#region Draw
			public void Draw(SharpDX.Direct2D1.RenderTarget renderTarget, ChartControl chartControl, ChartScale chartScale, Instrument instrument, ChartBars bars, Stroke buildingStroke, ClusterSettings settings = null)
			{
				if (_Settings == null || !_Settings.Show || bars == null || instrument == null)
					return;
				if (IsEditing)
				{
					if (buildingStroke == null)
						return;
					DrawJustBox(renderTarget, chartControl, chartScale, buildingStroke);
					return;
				}
                _FullProfile = SharpDXUtils.GetRectangle(renderTarget, chartControl, chartScale, Start.StartTime, High, End.EndTime, Low);
				_FullProfile.Inflate(5f, 5f);

                if (IsHovered)
				{
					float fBox = 1f; float fRound = 2f;
					DrawSharpDX.Box(renderTarget, chartControl, chartScale, new Stroke(Brushes.Cornsilk, DashStyleHelper.Solid, 1), Start.StartTime, High, End.EndTime, Low, 10, true, false);
                    DrawSharpDX.SmallBox(renderTarget, chartControl, chartScale, new Stroke(Brushes.Cornsilk, DashStyleHelper.Solid, 1), Start.StartTime, (High + Low) / 2, fBox, 10, true, false, fRound);
                    _LeftProfile = SharpDXUtils.GetRectangle(renderTarget, chartControl, chartScale, Start.StartTime, (High + Low) / 2, (fBox + fRound) * 2);
                    if (_Settings.IsHistorical)
					{
						DrawSharpDX.SmallBox(renderTarget, chartControl, chartScale, _Settings.Profile, End.EndTime, (High + Low) / 2, fBox, 10, true, false, fRound);
                        _RightProfile = SharpDXUtils.GetRectangle(renderTarget, chartControl, chartScale, End.EndTime, (High + Low) / 2, (fBox + fRound) * 2);
                        DrawSharpDX.SmallCenterBox(renderTarget, chartControl, chartScale, _Settings.Profile, Start.StartTime, End.EndTime, (High + Low) / 2, fBox, 10, true, false, fRound);
                        _MidProfile = SharpDXUtils.GetRectangle(renderTarget, chartControl, chartScale, Start.StartTime, End.EndTime, (High + Low) / 2, (fBox + fRound) * 2, 0.70f);
                    }
                }
				//draw total volume instead of building
				//DrawSharpDX.Text(renderTarget, chartControl, chartScale, "Building", End.EndTime, Low, Brushes.Cornsilk, new SimpleFont("Century Gothic", 10), SharpDXUtils.HorizontalAlignment.Right, SharpDXUtils.VerticalAlignment.Bottom);
				if (_Settings.IsItCalculating)
				{
					DrawSharpDX.Text(renderTarget, chartControl, chartScale, "Calculating...", End.EndTime, Low, Brushes.Cornsilk, _Settings.Text, SharpDXUtils.HorizontalAlignment.Right, SharpDXUtils.VerticalAlignment.Bottom);
					return;
				}

				//don't even try to draw if none of the data is in view
				if (chartControl.GetXByTime(End.EndTime) < -1 || chartControl.GetXByTime(Start.StartTime) > chartControl.ChartPanels[chartScale.PanelIndex].W)
					return;
				//start the drawing
				lock (_dicPrices)
				{
					if (_dicPrices.Count > 0)
					{
						if (_Settings.ShowProfile)
						{
							IEnumerable<double> keys = _dicPrices.Keys;
							foreach (double key in keys)
							{
								PriceDetails price = _dicPrices[key];
								if ((!_Settings.ShowPOC || price.High != POC.PocValue.High) && (!_Settings.ShowVAH || price.High != POC.ValueAreaHigh.High) && (!_Settings.ShowVAL || price.High != POC.ValueAreaLow.High))
								{
									int opac = price.High <= POC.ValueAreaHigh.High && price.Low >= POC.ValueAreaLow.Low ? _Settings.VAOpac : (_Settings.ShowExtremes ? _Settings.NormalOpac : 0);
									Stroke stroke = price.High <= POC.ValueAreaHigh.High && price.Low >= POC.ValueAreaLow.Low ? _Settings.Profile : _Settings.Extremes;
									if (_Settings.IsRight)
										DrawSharpDX.Profile(renderTarget, chartControl, chartScale, stroke, price.High, price.Low, ((double)price.Volume / POC.PocValue.Volume) * _Settings.ProfilePercentRight * 0.01, opac, false, true);
									else
										DrawSharpDX.Profile(renderTarget, chartControl, chartScale, stroke, Start.StartTime, price.High, End.EndTime, price.Low, opac, false, true,
											((double)price.Volume / POC.PocValue.Volume) * _Settings.ProfilePercent * 0.01);
								}
							}
						}
						//Draw Extreme Top
						if (_Settings.ShowExtremes && POC.ValueAreaHigh.High != High)
							DrawLineText(renderTarget, chartControl, chartScale, instrument, _Settings.Extremes, High);
						//Draw Extreme Bottom
						if (_Settings.ShowExtremes && POC.ValueAreaLow.Low != Low)
							DrawLineText(renderTarget, chartControl, chartScale, instrument, _Settings.Extremes, Low);
						//Draw POC
						if (_Settings.ShowPOC)
							DrawPOCVAHVAL(renderTarget, chartControl, chartScale, instrument, _Settings.POC, POC.PocValue, true);
						//Draw VAH
						if (_Settings.ShowVAH)
							DrawPOCVAHVAL(renderTarget, chartControl, chartScale, instrument, _Settings.VAH, POC.ValueAreaHigh, true);
						//Draw VAL
						if (_Settings.ShowVAL)
							DrawPOCVAHVAL(renderTarget, chartControl, chartScale, instrument, _Settings.VAL, POC.ValueAreaLow, true);
					}
				}
				if (VWAP != null)
					VWAP.Draw(renderTarget, chartControl, chartScale, bars, instrument);
				if (CWAP != null)
					CWAP.Draw(renderTarget, chartControl, chartScale, bars, instrument);
				if (Clusters.Count > 0 && settings.Show == ClusterDisplay.OnlyInProfile)
				{
					for (int i = 0; i < Clusters.Count; i++)
						Clusters[i].Draw(renderTarget, chartControl, chartScale, settings, true);
				}

			}
			#endregion

			#region Draw POC, VAL, VAH
			private void DrawPOCVAHVAL(SharpDX.Direct2D1.RenderTarget renderTarget, ChartControl chartControl, ChartScale chartScale, Instrument instrument, Stroke stroke, PriceDetails price, bool DrawLow)
			{
				if (_Settings.IsRight)
					DrawSharpDX.Profile(renderTarget, chartControl, chartScale, stroke, price.High, price.Low, ((double)price.Volume / POC.PocValue.Volume) * _Settings.ProfilePercentRight * 0.01, 100, false, true);
				else
					DrawSharpDX.Profile(renderTarget, chartControl, chartScale, stroke, Start.StartTime, price.High, End.EndTime, price.Low, 100, false, true, ((double)price.Volume / POC.PocValue.Volume) * _Settings.ProfilePercent * 0.01);
				DrawLineText(renderTarget, chartControl, chartScale, instrument, stroke, DrawLow ? price.Low : price.High);
			}
			#endregion

			#region Draw Line Text
			private void DrawLineText(SharpDX.Direct2D1.RenderTarget renderTarget, ChartControl chartControl, ChartScale chartScale, Instrument instrument, Stroke stroke, double price)
			{
				if (_Settings.IsRight)
				{
					DrawSharpDX.Line(renderTarget, chartControl, chartScale, price, _Settings.ProfilePercentRight * 0.01, stroke);
					if(_Settings.ShowText)
						DrawSharpDX.Text(renderTarget, chartControl, chartScale, String.Format("{0} ", instrument.MasterInstrument.FormatPrice(price)), _Settings.ProfilePercentRight * 0.01, price, stroke.Brush,
							_Settings.Text, SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment.Bottom);
				}
				else
				{
					DrawSharpDX.Line(renderTarget, chartControl, chartScale, Start.StartTime, price, End.EndTime, price, stroke);
                    if (_Settings.ShowText)
                        DrawSharpDX.Text(renderTarget, chartControl, chartScale, String.Format("{0} ", instrument.MasterInstrument.FormatPrice(price)), End.EndTime, price, stroke.Brush,
							_Settings.Text, SharpDXUtils.HorizontalAlignment.Right, SharpDXUtils.VerticalAlignment.Bottom);
				}
			}
			#endregion

			#endregion

			#region Check Mouse Inside
			public bool CheckInside(float x, float y, bool isPressed, out bool LeftHovered, out bool CenterHovered, out bool RightHovered)
			{
				LeftHovered = false;
				CenterHovered = false;
				RightHovered = false;
				IsHovered = false;
				SharpDX.RectangleF rect = new SharpDX.RectangleF(x - 15f, y - 15f, 30f, 30f);
				if (_FullProfile.Intersects(rect))
					IsHovered = true;
				if(IsHovered)
				{
					LeftHovered = _LeftProfile.Intersects(rect);
                    CenterHovered = _MidProfile.Intersects(rect);
                    RightHovered = _RightProfile.Intersects(rect);
                    if (isPressed)
					{
						IsLeftAdjusted = _LeftProfile.Intersects(rect);
						IsRightAdjusted = _RightProfile.Intersects(rect);
						IsCenterAdjusted = _MidProfile.Intersects(rect);
						if (IsLeftAdjusted || IsRightAdjusted || IsCenterAdjusted)
							IsEditing = true;
						if (IsCenterAdjusted)
						{
							_iRightBar = End.No;
							_iLeftBar = Start.No;
							_iCenterBar = (End.No + Start.No) / 2;
						}
					}
				}
				return IsHovered;
			}
			#endregion

			#region Get Deviation
			public void GetDeviation(int barNumber, out int LeftBar, out int RightBar)
			{
				int iDiff = barNumber - _iCenterBar;
				LeftBar = _iLeftBar + iDiff;
				RightBar = _iRightBar + iDiff;
			}
            #endregion

            #region Clone
            public object Clone()
            {
                ConcurrentDictionary<double, PriceDetails> dicPrices = new ConcurrentDictionary<double, PriceDetails>();
				lock (_dicPrices)
				{
					foreach (KeyValuePair<double, PriceDetails> kvp in _dicPrices)
						dicPrices.TryAdd(kvp.Key, kvp.Value.Clone() as PriceDetails);
				}
				List<Cluster> clusters = new List<Cluster>();
                foreach (Cluster cluster in Clusters)
                    clusters.Add(cluster.Clone() as Cluster);
                return new Profile()
                {
                    Start = Start.Clone() as BarLocation,
                    End = End.Clone() as BarLocation,
                    POC = POC.Clone() as PocDetails,
                    High = High,
                    Low = Low,
                    TotalVol = TotalVol,
                    _dicPrices = dicPrices,
                    VWAP = VWAP.Clone() as VwapStdDevCalculator,
                    CWAP = CWAP.Clone() as CwapStdDevCalculator,
                    Clusters = clusters,
                    _Settings = _Settings.Clone() as ProfileSettings
                };
            }
            public object ShallowClone()
            {
                return new Profile()
                {
                    Start = Start.Clone() as BarLocation,
                    End = End.Clone() as BarLocation,
                };
            }
            #endregion
        }
        #endregion

        #endregion

        #endregion

        #region Static Classes

        #region Draw Sharp DX
        public static class DrawSharpDX
		{
            #region Fill Zone
            public static void FillZone(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, List<Point> points, Brush brush/*, Vector pixelAdjustVector*/, float Opacity)
            {
                SharpDX.Direct2D1.PathGeometry pathGeometry = new SharpDX.Direct2D1.PathGeometry(NinjaTrader.Core.Globals.D2DFactory);
                SharpDX.Direct2D1.GeometrySink geometrySink = pathGeometry.Open();

                for (int i = 0; i < points.Count; i++)
                {
                    if (i == 0)
                        geometrySink.BeginFigure((points[i]/* + pixelAdjustVector*/).ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
                    else
                        geometrySink.AddLine((points[i]/* + pixelAdjustVector*/).ToVector2());
                }
                geometrySink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
                geometrySink.Close();

                SharpDX.Direct2D1.Brush ZoneBrush = brush.ToDxBrush(RenderTarget);
                ZoneBrush.Opacity = Opacity / 100f;

                SharpDXUtils.WrapInAntiAlias(RenderTarget, () => { RenderTarget.FillGeometry(pathGeometry, ZoneBrush); });

                ZoneBrush.Dispose();
                pathGeometry.Dispose();
                geometrySink.Dispose();
            }
            #endregion

            #region Draw Line
            public static void DrawLine(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, List<Point> points, Stroke stroke)//, Vector pixelAdjustVector)
            {
				if (points.Count == 0)
					return;
                SharpDX.Direct2D1.PathGeometry pathGeometry = new SharpDX.Direct2D1.PathGeometry(NinjaTrader.Core.Globals.D2DFactory);
                SharpDX.Direct2D1.GeometrySink geometrySink = pathGeometry.Open();

                for (int i = 0; i < points.Count; i++)
                {
                    if (i == 0)
                        geometrySink.BeginFigure(points[i].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
                    else
                        geometrySink.AddLine(points[i].ToVector2());
				}
                geometrySink.EndFigure(SharpDX.Direct2D1.FigureEnd.Open);
                geometrySink.Close();

                SharpDX.Direct2D1.Brush brs = stroke.Brush.ToDxBrush(RenderTarget);
                SharpDXUtils.WrapInAntiAlias(RenderTarget, () => { RenderTarget.DrawGeometry(pathGeometry, brs, stroke.Width, stroke.StrokeStyle); });
                pathGeometry.Dispose();
                geometrySink.Dispose();
            }
            #endregion

            #region Line
            public static void Line(SharpDX.Direct2D1.RenderTarget RenderTarget, float x1, float y1, float x2, float y2, Stroke stroke, Tuple<float, float> chartWidthNHeight)
			{
				if (RenderTarget == null || stroke == null || stroke.Brush == Brushes.Transparent || (x1 == x2 && y1 == y2) || !SharpDXUtils.IsLineInChart(x1, y1, x2, y2, chartWidthNHeight))
					return;

				DrawLine(RenderTarget, new SharpDX.Vector2(x1, y1), new SharpDX.Vector2(x2, y2), stroke);
			}

			public static void Line(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, DateTime time1, double price1, DateTime time2, double price2, Stroke stroke)
			{
				if (RenderTarget == null || chartControl == null || chartScale == null || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.IsLineInChart(time1, price1, time2, price2, chartControl, chartScale))
					return;

				float x1 = chartControl.GetXByTime(time1); float y1 = chartScale.GetYByValue(price1);
				float x2 = chartControl.GetXByTime(time2); float y2 = chartScale.GetYByValue(price2);

				DrawLine(RenderTarget, new SharpDX.Vector2(x1, y1), new SharpDX.Vector2(x2, y2), stroke);
			}

			public static void Line(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, double price, double multiple, Stroke stroke)
			{
				if (RenderTarget == null || chartControl == null || chartScale == null || stroke == null || stroke.Brush == Brushes.Transparent)
					return;

                float x1 = -1; float y = chartScale.GetYByValue(price);
                float x2 = (float)chartControl.ChartPanels[chartScale.PanelIndex].W;//ActualWidth;

				x1 = (float)((x2 + x1) * (1 - multiple));

    //            float x1 = chartControl.GetXByTime(time1); float y1 = chartScale.GetYByValue(price1);
				//float x2 = chartControl.GetXByTime(time2); float y2 = chartScale.GetYByValue(price2);

				DrawLine(RenderTarget, new SharpDX.Vector2(x1, y), new SharpDX.Vector2(x2, y), stroke);
			}

			private static void DrawLine(SharpDX.Direct2D1.RenderTarget RenderTarget, SharpDX.Vector2 vector1, SharpDX.Vector2 vector2, Stroke stroke)
			{
				SharpDX.Direct2D1.Brush brs = stroke.Brush.ToDxBrush(RenderTarget);
				SharpDXUtils.WrapInAntiAlias(RenderTarget, () => { RenderTarget.DrawLine(vector1, vector2, brs, stroke.Width, stroke.StrokeStyle); });
				brs.Dispose();
			}
			#endregion

			#region Geometry
			public static void GeometryWithFill(SharpDX.Direct2D1.RenderTarget RenderTarget, List<Tuple<float, float>> Points, Stroke stroke, int opacity, bool outline, bool background, Tuple<float, float> chartWidthNHeight)
			{
				if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.AreAnyPointsInChart(Points, chartWidthNHeight))
					return;

				List<SharpDX.Vector2> points = new List<SharpDX.Vector2>();
				foreach (Tuple<float, float> point in Points)
					points.Add(new SharpDX.Vector2(point.Item1, point.Item2));

				DrawGeometry(RenderTarget, points, stroke, opacity, outline, background);
			}

			public static void GeometryWithFill(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, List<Tuple<DateTime, double>> Points, Stroke stroke, int opacity, bool outline, bool background)
			{
				if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.AreAnyPointsInChart(Points, chartControl, chartScale))
					return;

				List<SharpDX.Vector2> points = new List<SharpDX.Vector2>();
				foreach (Tuple<DateTime, double> point in Points)
					points.Add(new SharpDX.Vector2(chartControl.GetXByTime(point.Item1), chartScale.GetYByValue(point.Item2)));

				DrawGeometry(RenderTarget, points, stroke, opacity, outline, background);
			}

			private static void DrawGeometry(SharpDX.Direct2D1.RenderTarget RenderTarget, List<SharpDX.Vector2> Points, Stroke stroke, int opacity, bool outline, bool background)
			{
				SharpDX.Direct2D1.PathGeometry pathGeometry = new SharpDX.Direct2D1.PathGeometry(NinjaTrader.Core.Globals.D2DFactory);
				SharpDX.Direct2D1.GeometrySink geometrySink = pathGeometry.Open();

				for (int i = 0; i < Points.Count; i++)
				{
					if (i == 0)
						geometrySink.BeginFigure(Points[i], SharpDX.Direct2D1.FigureBegin.Filled);
					else
						geometrySink.AddLine(Points[i]);
				}
				geometrySink.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
				geometrySink.Close();
				SharpDX.Direct2D1.Brush brs = stroke.Brush.ToDxBrush(RenderTarget);
				if (outline)
					RenderTarget.DrawGeometry(pathGeometry, brs, stroke.Width, stroke.StrokeStyle);
				if (background)
				{
					brs.Opacity = opacity / 100f;
					SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
					{
						RenderTarget.FillGeometry(pathGeometry, brs);
					});
				}
				pathGeometry.Dispose(); brs.Dispose(); geometrySink.Dispose();
			}
			#endregion

			#region Box Text
			public static void BoxText(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, string text, DateTime time, double price, Stroke stroke, int opacity,
				Brush textBrush, SimpleFont TextFont, bool outline, bool background, Brush backgroundBrush = null, bool rounded = false, float radius = 2,
				SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
				SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
			{
				Size size = SharpDXUtils.MeasureString(text, TextFont);
				Tuple<float, float> chartWidthNHeight = SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale);
				float x = chartControl.GetXByTime(time); float y = chartScale.GetYByValue(price);

				Box(RenderTarget, x, y, (float)size.Width, (float)size.Height, stroke, opacity, outline, background, chartWidthNHeight, rounded, radius, horizontalAlign, verticalAlign, backgroundBrush);
				Text(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, chartWidthNHeight, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
			}

			public static void BoxText(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, string text, float x, float y, Stroke stroke, int opacity,
				Brush textBrush, SimpleFont TextFont, bool outline, bool background, Brush backgroundBrush = null, bool rounded = false, float radius = 2,
				SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
				SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
			{
				Size size = SharpDXUtils.MeasureString(text, TextFont);
				Tuple<float, float> chartWidthNHeight = SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale);
				Box(RenderTarget, x, y, (float)size.Width, (float)size.Height, stroke, opacity, outline, background, chartWidthNHeight, rounded, radius, horizontalAlign, verticalAlign, backgroundBrush);
				Text(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, chartWidthNHeight, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
			}

            public static void BoxText(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, float width, float height, Stroke stroke, int opacity, Brush textBrush, SimpleFont TextFont,
                bool outline, bool background, Tuple<float, float> chartWidthNHeight, Brush backgroundBrush = null, bool rounded = false, float radius = 2,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                Box(RenderTarget, x, y, width, height, stroke, opacity, outline, background, chartWidthNHeight, rounded, radius, horizontalAlign, verticalAlign, backgroundBrush);
                Text(RenderTarget, text, x, y, width, height, textBrush, TextFont, chartWidthNHeight, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
            }

            public static void BoxText(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, SharpDX.RectangleF rect, Stroke stroke, int opacity, Brush textBrush, SimpleFont TextFont,
                bool outline, bool background, Tuple<float, float> chartWidthNHeight, Brush backgroundBrush = null, bool rounded = false, float radius = 2,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                Box(RenderTarget, rect.Left, rect.Top, rect.Width, rect.Height, stroke, opacity, outline, background, chartWidthNHeight, rounded, radius, horizontalAlign, verticalAlign, backgroundBrush);
                Text(RenderTarget, text, rect.Left, rect.Top, rect.Width, rect.Height, textBrush, TextFont, chartWidthNHeight, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
            }
            #endregion

            #region Profile
            public static void Profile(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, DateTime topLeftTime, double topLeftPrice, DateTime bottomRightTime, double bottomRightPrice,
				int opacity, bool outline, bool background, double multiplier,
				SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
			{
				if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent)
					return;

				float x1 = Math.Max(0, chartControl.GetXByTime(topLeftTime)); float y1 = chartScale.GetYByValue(topLeftPrice);
				//float x2 = Math.Min((float)chartControl.ChartPanels[chartScale.PanelIndex].W/*ActualWidth*/, chartControl.GetXByTime(bottomRightTime)); 
				float y2 = chartScale.GetYByValue(bottomRightPrice);
				float x2 = (float)chartControl.ChartPanels[chartScale.PanelIndex].W;
				float width = (float)((x2 - x1) * multiplier); float height = y2 - y1;

                if (y2 < 0 || y1 > chartControl.ChartPanels[chartScale.PanelIndex].H)
                    return;

                DrawBox(RenderTarget, x1, y1, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
					opacity, outline, background, horizontalAlign, verticalAlign);
			}
			public static void Profile(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, double topLeftPrice, double bottomRightPrice, double percentOfChart,
				int opacity, bool outline, bool background,
				SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
			{
				if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent)
					return;

				float x1 = -1; float y1 = chartScale.GetYByValue(topLeftPrice);
				float x2 = (float)(/*chartControl.ActualWidth -*/ chartControl.ChartPanels[chartScale.PanelIndex].W/*ActualWidth*/); float y2 = chartScale.GetYByValue(bottomRightPrice);
				float width = (float)((x2 - x1) * percentOfChart); float height = y2 - y1;

				if (y2 < 0 || y1 > chartControl.ChartPanels[chartScale.PanelIndex].H)
					return;

				DrawBox(RenderTarget, x2 - width, y1, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
					opacity, outline, background, horizontalAlign, verticalAlign);
			}
			#endregion

			#region Small Box
			public static void SmallBox(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, DateTime time, double price, float boxSize,
				int opacity, bool outline, bool background, float radius = 2,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
			{
				if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent)
					return;

				float x = chartControl.GetXByTime(time); float y = chartScale.GetYByValue(price);
				float x1 = x - boxSize; float y1 = y - boxSize;
				float x2 = x + boxSize; float y2 = y + boxSize;
				float width = x2 - x1; float height = y2 - y1;

                DrawRoundedBox(RenderTarget, x1, y1, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
					opacity, outline, background, horizontalAlign, verticalAlign, radius);
			}
			public static void SmallCenterBox(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, DateTime startTime, DateTime endTime, double price, float boxSize,
				int opacity, bool outline, bool background, float radius = 2,
				SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
			{
				if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent)
					return;

				float xr = chartControl.GetXByTime(endTime);
				float xl = chartControl.GetXByTime(startTime);
				float x = (xr + xl) / 2;
				float y = chartScale.GetYByValue(price);
				float x1 = x - boxSize; float y1 = y - boxSize;
				float x2 = x + boxSize; float y2 = y + boxSize;
				float width = x2 - x1; float height = y2 - y1;

                DrawRoundedBox(RenderTarget, x1, y1, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
					opacity, outline, background, horizontalAlign, verticalAlign, radius);
			}
			#endregion

			#region Box
			public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, DateTime topLeftTime, double topLeftPrice, DateTime bottomRightTime, double bottomRightPrice,
				int opacity, bool outline, bool background, float multiple,
				SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
			{
				if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent)
					return;

				float x1 = chartControl.GetXByTime(topLeftTime); float y1 = chartScale.GetYByValue(topLeftPrice);
				float x2 = chartControl.GetXByTime(bottomRightTime); float y2 = chartScale.GetYByValue(bottomRightPrice);
				float width = x2 - x1; float height = y2 - y1;

				if (!SharpDXUtils.IsRectangleInChart(x1, y1, width, height, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
					return;

				DrawBox(RenderTarget, x1 + (width * multiple), y1, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
					opacity, outline, background, horizontalAlign, verticalAlign);
			}
			public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, DateTime topLeftTime, double topLeftPrice, DateTime bottomRightTime, double bottomRightPrice,
				int opacity, bool outline, bool background,
				SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
			{
				if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent)
					return;

				float x1 = chartControl.GetXByTime(topLeftTime); float y1 = chartScale.GetYByValue(topLeftPrice);
				float x2 = chartControl.GetXByTime(bottomRightTime); float y2 = chartScale.GetYByValue(bottomRightPrice);
				float width = x2 - x1; float height = y2 - y1;

				//if (!SharpDXUtils.IsRectangleInChart(x1, y1, width, height, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
				//	return;

				DrawBox(RenderTarget, x1, y1, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
					opacity, outline, background, horizontalAlign, verticalAlign);
			}

			public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, Tuple<DateTime, double> topLeftPoint, Tuple<DateTime, double> bootomRightPoint,
				int opacity, bool outline, bool background,
				SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
			{
				if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent)
					return;

				float x1 = chartControl.GetXByTime(topLeftPoint.Item1); float y1 = chartScale.GetYByValue(topLeftPoint.Item2);
				float x2 = chartControl.GetXByTime(bootomRightPoint.Item1); float y2 = chartScale.GetYByValue(bootomRightPoint.Item2);
				float width = x2 - x1; float height = y2 - y1;

				if (!SharpDXUtils.IsRectangleInChart(x1, y1, width, height, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
					return;

				DrawBox(RenderTarget, x1, y1, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
					opacity, outline, background, horizontalAlign, verticalAlign);
			}

			public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, Stroke stroke, Tuple<float, float> topLeftPoint, Tuple<float, float> bootomRightPoint, int opacity,
				bool outline, bool background,
				SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
			{
				if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent ||
					!SharpDXUtils.IsRectangleInChart(topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
					return;

				DrawBox(RenderTarget, topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
					opacity, outline, background, horizontalAlign, verticalAlign);
			}

			public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, Stroke stroke, Tuple<float, float> topLeftPoint, Tuple<float, float> bootomRightPoint, int opacity, bool outline, bool background, Tuple<float, float> chartWidthNHeight,
				SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
			{
				if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent ||
					!SharpDXUtils.IsRectangleInChart(topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, chartWidthNHeight))
					return;

				DrawBox(RenderTarget, topLeftPoint.Item1, topLeftPoint.Item2, bootomRightPoint.Item1 - topLeftPoint.Item1, bootomRightPoint.Item2 - topLeftPoint.Item2, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush,
					opacity, outline, background, horizontalAlign, verticalAlign);
			}

			public static void Box(SharpDX.Direct2D1.RenderTarget RenderTarget, float x, float y, float width, float height, Stroke stroke, int opacity, bool outline, bool background, Tuple<float, float> chartWidthNHeight,
				bool rounded = false, float radius = 2,
				SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top, Brush backgroundBrush = null)
			{
				if (RenderTarget == null || (!outline && !background) || stroke == null || stroke.Brush == Brushes.Transparent || !SharpDXUtils.IsRectangleInChart(x, y, width, height, chartWidthNHeight))
					return;
				if (rounded)
					DrawRoundedBox(RenderTarget, x, y, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush, opacity, outline, background, horizontalAlign, verticalAlign, radius);
				else
					DrawBox(RenderTarget, x, y, width, height, stroke, backgroundBrush != null ? backgroundBrush : stroke.Brush, opacity, outline, background, horizontalAlign, verticalAlign);
			}

			private static void DrawBox(SharpDX.Direct2D1.RenderTarget RenderTarget, float x, float y, float width, float height, Stroke stroke, Brush backgroundBrush, int opacity, bool outline, bool background,
				SharpDXUtils.HorizontalAlignment horizontalAlign, SharpDXUtils.VerticalAlignment verticalAlign)
			{
				if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Center)
					x -= width / 2;
				if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Right)
					x -= width;
				if (verticalAlign == SharpDXUtils.VerticalAlignment.Center)
					y -= height / 2;
				if (verticalAlign == SharpDXUtils.VerticalAlignment.Bottom)
					y -= height;
				SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
				if (outline)
				{
					SharpDX.Direct2D1.Brush brs = stroke.Brush.ToDxBrush(RenderTarget);
					if (stroke.StrokeStyle != null)
					{
						SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
						{
							RenderTarget.DrawRectangle(rect, brs, stroke.Width, stroke.StrokeStyle);
						});
					}
					brs.Dispose();
				}
				if (background)
				{
					SharpDX.Direct2D1.Brush brs = backgroundBrush.ToDxBrush(RenderTarget);
					brs.Opacity = (float)(opacity * 0.01f);
					SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
					{
						RenderTarget.FillRectangle(rect, brs);
					});
					brs.Dispose();
				}
			}
			private static void DrawRoundedBox(SharpDX.Direct2D1.RenderTarget RenderTarget, float x, float y, float width, float height, Stroke stroke, Brush backgroundBrush, int opacity, bool outline, bool background,
				SharpDXUtils.HorizontalAlignment horizontalAlign, SharpDXUtils.VerticalAlignment verticalAlign, float radius)
			{
				if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Center)
					x -= width / 2;
				if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Right)
					x -= width;
				if (verticalAlign == SharpDXUtils.VerticalAlignment.Center)
					y -= height / 2;
				if (verticalAlign == SharpDXUtils.VerticalAlignment.Bottom)
					y -= height;

				SharpDX.RectangleF rect = new SharpDX.RectangleF(x - radius, y - radius, width + radius * 2, height + radius * 2);
				SharpDX.Direct2D1.RoundedRectangle roundRect = new SharpDX.Direct2D1.RoundedRectangle() { Rect = rect, RadiusX = radius, RadiusY = radius };
				if (outline)
				{
					SharpDX.Direct2D1.Brush brs = stroke.Brush.ToDxBrush(RenderTarget);
					SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
					{
						RenderTarget.DrawRoundedRectangle(roundRect, brs, stroke.Width, stroke.StrokeStyle);
					});
					brs.Dispose();
				}
				if (background)
				{
					SharpDX.Direct2D1.Brush brs = backgroundBrush.ToDxBrush(RenderTarget);
					brs.Opacity = (float)(opacity * 0.01f);
					SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
					{
						RenderTarget.FillRoundedRectangle(roundRect, brs);
					});
					brs.Dispose();
				}
			}
			#endregion

			#region Text
			public static void Text(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, string text, double percentOfChart, double price, Brush textBrush, SimpleFont TextFont,
				SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
				SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
			{
				if (RenderTarget == null || chartControl == null || chartScale == null || textBrush == null || textBrush == Brushes.Transparent || TextFont == null)
					return;

				float x = (float)(chartControl.ChartPanels[chartScale.PanelIndex].W/*ActualWidth*/ * (1 - percentOfChart)); float y = chartScale.GetYByValue(price);
				Size size = SharpDXUtils.MeasureString(text, TextFont);

				if (size.Width == 0 || size.Height == 0)// || !SharpDXUtils.IsRectangleInChart(x, y, (float)size.Width, (float)size.Height, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
					return;

				DrawText(RenderTarget, text, x, y, (float)size.Width + 10, (float)size.Height, textBrush, TextFont, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
			}

            public static void Text(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, string text, DateTime time, double price, Brush textBrush, SimpleFont TextFont,
                SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
                SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
            {
                if (RenderTarget == null || chartControl == null || chartScale == null || textBrush == null || textBrush == Brushes.Transparent || TextFont == null)
                    return;

                float x = chartControl.GetXByTime(time); float y = chartScale.GetYByValue(price);
                Size size = SharpDXUtils.MeasureString(text, TextFont);

                if (size.Width == 0 || size.Height == 0 || !SharpDXUtils.IsRectangleInChart(x, y, (float)size.Width, (float)size.Height, SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale)))
                    return;

                DrawText(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
            }

            public static void Text(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, Brush textBrush, SimpleFont TextFont, Tuple<float, float> chartWidthNHeight,
				SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
				SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
			{
				if (RenderTarget == null || string.IsNullOrEmpty(text) || textBrush == null || textBrush == Brushes.Transparent || TextFont == null)
					return;
				Size size = SharpDXUtils.MeasureString(text, TextFont);
				if (size.Width == 0 || size.Height == 0 || !SharpDXUtils.IsRectangleInChart(x, y, (float)size.Width, (float)size.Height, chartWidthNHeight))
					return;
				DrawText(RenderTarget, text, x, y, (float)size.Width, (float)size.Height, textBrush, TextFont, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
			}

			public static void Text(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, float width, float height, Brush textBrush, SimpleFont TextFont, Tuple<float, float> chartWidthNHeight,
				SharpDXUtils.HorizontalAlignment horizontalAlign = SharpDXUtils.HorizontalAlignment.Left, SharpDXUtils.VerticalAlignment verticalAlign = SharpDXUtils.VerticalAlignment.Top,
				SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment = SharpDX.DirectWrite.ParagraphAlignment.Center, SharpDX.DirectWrite.TextAlignment textAlignemnt = SharpDX.DirectWrite.TextAlignment.Center)
			{
				if (RenderTarget == null || string.IsNullOrEmpty(text) || width == 0 || height == 0 || textBrush == null || textBrush == Brushes.Transparent || TextFont == null ||
					!SharpDXUtils.IsRectangleInChart(x, y, width, height, chartWidthNHeight))
					return;
				DrawText(RenderTarget, text, x, y, width, height, textBrush, TextFont, horizontalAlign, verticalAlign, paragraphAlignment, textAlignemnt);
			}

			private static void DrawText(SharpDX.Direct2D1.RenderTarget RenderTarget, string text, float x, float y, float width, float height, Brush textBrush, SimpleFont TextFont, SharpDXUtils.HorizontalAlignment horizontalAlign,
				SharpDXUtils.VerticalAlignment verticalAlign, SharpDX.DirectWrite.ParagraphAlignment paragraphAlignment, SharpDX.DirectWrite.TextAlignment textAlignemnt)
			{
				if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Center)
					x -= width / 2;
				if (horizontalAlign == SharpDXUtils.HorizontalAlignment.Right)
					x -= width;
				if (verticalAlign == SharpDXUtils.VerticalAlignment.Center)
					y -= height / 2;
				if (verticalAlign == SharpDXUtils.VerticalAlignment.Bottom)
					y -= height;
				SharpDX.RectangleF rect = new SharpDX.RectangleF(x, y, width, height);
				SimpleFont fs = new SimpleFont(TextFont.Family.ToString(), TextFont.Size) { Bold = TextFont.Bold, Italic = TextFont.Italic };
				SharpDX.DirectWrite.TextFormat tff = fs.ToDirectWriteTextFormat();
				tff.ParagraphAlignment = paragraphAlignment;
				tff.TextAlignment = textAlignemnt;
				SharpDX.Direct2D1.Brush brs = textBrush.ToDxBrush(RenderTarget);
				SharpDXUtils.WrapInAntiAlias(RenderTarget, () =>
				{
					RenderTarget.DrawText(text, tff, rect, brs, SharpDX.Direct2D1.DrawTextOptions.Clip, SharpDX.Direct2D1.MeasuringMode.Natural);
				});
				tff.Dispose();
				brs.Dispose();
			}
			#endregion

			#region Draw Flag
			public static void DrawFlag(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, string text, double price, Stroke stroke, int opacity,
				Brush textBrush, SimpleFont TextFont, bool outline, bool background, Brush backgroundBrush = null, bool rounded = false, float radius = 2, double flagFromScreen = 0.33, bool hovered = false)
			{
				Tuple<float, float> chartWidthHeight = SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale);
				float x1 = chartWidthHeight.Item1;
				float x2 = (float)Math.Max(x1 * (1 - flagFromScreen), 50);
				x1 += 1000;
				float y = chartScale.GetYByValue(price);
				double h = SharpDXUtils.MeasureString(text, TextFont).Height;
				Line(RenderTarget, x2 + radius, y, x1, y, stroke, chartWidthHeight);
				if (hovered)
					Box(RenderTarget, x2, (float)(y - h / 2), x1 - x2, (float)h, stroke, opacity, false, true, chartWidthHeight);
				BoxText(RenderTarget, chartControl, chartScale, text, x2, y, stroke, 0, textBrush, TextFont, outline, background, backgroundBrush, rounded, radius, SharpDXUtils.HorizontalAlignment.Right, SharpDXUtils.VerticalAlignment.Center);
			}
			#endregion
		}
		#endregion

		#region Sharp DX Utils
		public static class SharpDXUtils
		{
			#region Get Chart Width and Height
			public static Tuple<float, float> GetChartWidthNHeight(ChartControl chartControl, ChartScale chartScale)
			{
				return new Tuple<float, float>(chartControl.GetXByTime(chartControl.LastTimePainted), chartScale.GetYByValue(chartScale.MinValue));
			}
			#endregion

			#region Check Co-ordinates in Flag
			public static bool CheckCoordinatesIn(ChartControl chartControl, ChartScale chartScale, double price, string text, SimpleFont TextFont, float x, float y, double flagFromScreen)
			{
				Tuple<float, float> chartWidthHeight = SharpDXUtils.GetChartWidthNHeight(chartControl, chartScale);
				float x1 = chartWidthHeight.Item1;
				float x2 = (float)Math.Max(x1 * (1 - flagFromScreen), 50);
				double height = MeasureString(text, TextFont).Height;
				float yc = chartScale.GetYByValue(price);
				return x <= x1 && x >= x2 && y <= yc + height * 0.5 && y >= yc - height * 0.5;
			}
			#endregion

			#region Measure String
			public static Size MeasureString(string msg, SimpleFont TextFont)
			{
				if (TextFont == null || string.IsNullOrEmpty(msg))
					return new Size(0, 0);

				SimpleFont fs = new SimpleFont(TextFont.Family.ToString(), TextFont.Size) { Bold = TextFont.Bold, Italic = TextFont.Italic };
				using (SharpDX.DirectWrite.TextFormat tff = fs.ToDirectWriteTextFormat())
				using (SharpDX.DirectWrite.TextLayout layout = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, msg, tff, 999999, tff.FontSize))
					return new Size(layout.Metrics.Width, layout.Metrics.Height);
			}

            #endregion

            #region Get Rectangle
            public static SharpDX.RectangleF GetRectangle(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, DateTime topLeftTime, double topLeftPrice, DateTime bottomRightTime, double bottomRightPrice)
            {
                if (RenderTarget == null)
                    return new SharpDX.RectangleF();
                float x1 = chartControl.GetXByTime(topLeftTime); float y1 = chartScale.GetYByValue(topLeftPrice);
                float x2 = chartControl.GetXByTime(bottomRightTime); float y2 = chartScale.GetYByValue(bottomRightPrice);
                float width = x2 - x1; float height = y2 - y1;
                return new SharpDX.RectangleF(x1, y1, width, height);
            }
            public static SharpDX.RectangleF GetRectangle(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, DateTime time, double price, float boxSize)
            {
                if (RenderTarget == null)
                    return new SharpDX.RectangleF();
                float x = chartControl.GetXByTime(time); float y = chartScale.GetYByValue(price);
                float x1 = x - boxSize; float y1 = y - boxSize;
                float x2 = x + boxSize; float y2 = y + boxSize;
                float width = x2 - x1; float height = y2 - y1;
                return new SharpDX.RectangleF(x1, y1, width, height);
            }
            public static SharpDX.RectangleF GetRectangle(SharpDX.Direct2D1.RenderTarget RenderTarget, ChartControl chartControl, ChartScale chartScale, DateTime startTime, DateTime endTime, 
				double price, float boxHeight, float boxWidthPercent)
            {
                if (RenderTarget == null)
                    return new SharpDX.RectangleF();
                float xr = chartControl.GetXByTime(endTime);
                float xl = chartControl.GetXByTime(startTime);
                float x = (xr + xl) / 2;
				float xw = Math.Abs(xr - xl) * boxWidthPercent;
                float y = chartScale.GetYByValue(price);
                float x1 = x - xw * 0.5f; float y1 = y - boxHeight;
                float x2 = x + xw * 0.5f; float y2 = y + boxHeight;
                float width = x2 - x1; float height = y2 - y1;
                return new SharpDX.RectangleF(x1, y1, width, height);
            }
            #endregion

            #region Are Any Points iIn Chart
            public static bool AreAnyPointsInChart(List<Tuple<float, float>> points, Tuple<float, float> chartWidthNHeight)
			{
				foreach (Tuple<float, float> point in points)
					if (IsPointInChart(point.Item1, point.Item2, chartWidthNHeight))
						return true;
				return false;
			}

			public static bool AreAnyPointsInChart(List<Tuple<DateTime, double>> points, ChartControl chartControl, ChartScale chartScale)
			{
				foreach (Tuple<DateTime, double> point in points)
					if (IsPointInChart(point.Item1, point.Item2, chartControl, chartScale))
						return true;
				return false;
			}
			#endregion

			#region Is Line In Chart
			public static bool IsLineInChart(float x1, float y1, float x2, float y2, Tuple<float, float> chartWidthNHeight)
			{
				return IsPointInChart(x1, y1, chartWidthNHeight) || IsPointInChart(x2, y2, chartWidthNHeight);
			}

			public static bool IsLineInChart(DateTime x1, double y1, DateTime x2, double y2, ChartControl chartControl, ChartScale chartScale)
			{
				return IsPointInChart(x1, y1, chartControl, chartScale) || IsPointInChart(x2, y2, chartControl, chartScale);
			}
			#endregion

			#region Is Point In Chart
			public static bool IsPointInChart(float x, float y, Tuple<float, float> chartWidthNHeight)
			{
				return x >= -1 && x <= chartWidthNHeight.Item1 + 1 && y >= -1 && y <= chartWidthNHeight.Item2 + 1;
			}

			public static bool IsPointInChart(DateTime x, double y, ChartControl chartControl, ChartScale chartScale)
			{
				return x.CompareTo(chartControl.FirstTimePainted) >= 0 && x.CompareTo(chartControl.LastTimePainted) <= 0 && y >= chartScale.MinValue && y <= chartScale.MaxValue;
			}
			#endregion

			#region Is Rectangle In Chart
			public static bool IsRectangleInChart(SharpDX.RectangleF rectangle, Tuple<float, float> chartWidthNHeight)
			{
				return IsPointInChart(rectangle.X, rectangle.Y, chartWidthNHeight) || IsPointInChart(rectangle.X + rectangle.Width, rectangle.Y, chartWidthNHeight) ||
					IsPointInChart(rectangle.X, rectangle.Y + rectangle.Height, chartWidthNHeight) || IsPointInChart(rectangle.X + rectangle.Width, rectangle.Y + rectangle.Height, chartWidthNHeight);
			}

			public static bool IsRectangleInChart(float x, float y, float width, float height, Tuple<float, float> chartWidthNHeight)
			{
				SharpDX.RectangleF rectangle = new SharpDX.RectangleF(x, y, width, height);
				return IsPointInChart(rectangle.X, rectangle.Y, chartWidthNHeight) || IsPointInChart(rectangle.X + rectangle.Width, rectangle.Y, chartWidthNHeight) ||
					IsPointInChart(rectangle.X, rectangle.Y + rectangle.Height, chartWidthNHeight) || IsPointInChart(rectangle.X + rectangle.Width, rectangle.Y + rectangle.Height, chartWidthNHeight);
			}

			public static bool IsRectangleInChart(List<Tuple<DateTime, double>> points, ChartControl chartControl, ChartScale chartScale)
			{
				return AreAnyPointsInChart(points, chartControl, chartScale);
			}

			public static bool IsRectangleInChart(List<Tuple<float, float>> points, Tuple<float, float> chartWidthNHeight)
			{
				return AreAnyPointsInChart(points, chartWidthNHeight);
			}
			#endregion

			#region WrapInAntiAlias
			public static void WrapInAntiAlias(SharpDX.Direct2D1.RenderTarget RenderTarget, Action action)
			{
				SharpDX.Direct2D1.AntialiasMode prev = RenderTarget.AntialiasMode;
				RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
				action();
				RenderTarget.AntialiasMode = prev;
			}
			#endregion

			#region Enums

			#region Horizontal Text Alignment
			public enum HorizontalAlignment
			{
				Center,
				Left,
				Right
			}
			#endregion

			#region Vertical Text Alignment
			public enum VerticalAlignment
			{
				Center,
				Top,
				Bottom
			}
			#endregion

			#endregion
		}
		#endregion

		#endregion

		#endregion

		#region States

		#region Historical

		#region Add All things to the toolbar
		private void addToToolbar()
		{
			if (this.ChartControl != null)
			{
                Action p = () =>
                {
                    #region Initialize Tool Strip Stuff
                    _wChart = Window.GetWindow(this.ChartControl.Parent) as Chart;
					if (_wChart == null)
					{
						Print("no chart window");
						return;
					}
					_gChart = _wChart.MainTabControl.Parent as System.Windows.Controls.Grid;
					_gChart.PreviewKeyDown += ChartControl_PreviewKeyDown;
                    #endregion

                    #region Initial SetUp
                    Style style = null;
					foreach (object item in _wChart.MainMenu)
					{
						if (AutomationProperties.GetAutomationId(item as DependencyObject) == (_sToolbarName + uID)) _bIsToolBarButtonAdded = true;
						if (item is MenuItem)
							style = (item as MenuItem).Style;
					}

					_grdIndyToolbar = new Grid { Visibility = Visibility.Collapsed };

					_mnuControlContainer = new Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
					MenuItem MenuControl = new MenuItem { Name = "MenuControl" + uID, BorderThickness = new Thickness(2), BorderBrush = Brushes.Cyan, Header = ButtonText, Foreground = Brushes.Cyan, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, Background = Brushes.Maroon, FontSize = 13 };
					_dicMenuItems.TryAdd(MenuControl.Name, MenuControl);
					_mnuControlContainer.Items.Add(MenuControl);
					#endregion

					#region Profile (Composite) Settings
					string headItem = "miProfileCompositeSettings";
					AddMenuItem("Profile (Composite) Settings", headItem, Brushes.Black, null, MenuControl, true, style);

					_dicMenuItems[headItem].Items.Add(createDropDownMenu(_GeneralSettings.CompositeCalculationType));

					//the next 3 must be inactive when the previous one (combo box) is set to "Day"/ active only when the previous one is "Time"
					_dicMenuItems[headItem].Items.Add(createUpDownMenu(StartTimeHrs.ToString(), _GeneralSettings.CompositeStartTime.Hours, "btStartTimeHrs", "Start (Hrs): ", 1, 0, 23));
					_dicMenuItems[headItem].Items.Add(createUpDownMenu(StartTimeMin.ToString(), _GeneralSettings.CompositeStartTime.Minutes, "btStartTimeMin", "Start (Min): ", 1, 0, 59));
					_dicMenuItems[headItem].Items.Add(createUpDownMenu(IntervalMin.ToString(), _GeneralSettings.CompositeResetInterval.TotalMinutes, "btIntervalMin", "Interval (Min): ", 1, 1, 1440));
                    AddMenuItem("RE-CALCULATE", "btRecalculate_General", Brushes.Black, General_Click, _dicMenuItems[headItem], true, style, false);

                    _dicGrids["btStartTimeHrs"].IsEnabled = _GeneralSettings.CompositeCalculationType == "Time";
                    _dicGrids["btStartTimeMin"].IsEnabled = _GeneralSettings.CompositeCalculationType == "Time";
                    _dicGrids["btIntervalMin"].IsEnabled = _GeneralSettings.CompositeCalculationType == "Time";

                    #endregion

                    #region Profile (Composite) Visual
                    headItem = "miProfileCompositeVisual";
					AddMenuItem("Profile (Composite) Visual", headItem, Brushes.Black, null, MenuControl, true, style);
					AddMenuItem("Profile (Composite) " + (_GeneralSettings.ShowComposite ? "On" : "Off"), "btProfileComposite", Brushes.Black, General_Click, _dicMenuItems[headItem], true, style);
					//AddMenuItem("Display Mode " + (_GeneralSettings.CompositeCalculationType), "btDisplayMode", Brushes.Black, General_Click, _dicMenuItems[headItem], true, style);
					//AddMenuItem("Draw On Top " + (_GeneralSettings.ShowOnTop ? "ON" : "OFF"), "btDrawOnTop", Brushes.Black, General_Click, _dicMenuItems[headItem], true, style);
					AddMenuItem("Current Profile " + (_GeneralSettings.ShowCurrentProfile ? "On" : "Off"), "btCurrentProfile", Brushes.Black, General_Click, _dicMenuItems[headItem], true, style);
					AddMenuItem("Current Profile " + (_GeneralSettings.ShowProfileLeft ? "LEFT" : "RIGHT"), "btCurrentProfilePosition", Brushes.Black, General_Click, _dicMenuItems[headItem], true, style);
					AddMenuItem("Historical Profiles " + (_GeneralSettings.ShowHistorical ? "On" : "Off"), "btHistoricalProfiles", Brushes.Black, General_Click, _dicMenuItems[headItem], true, style);
                    AddMenuItem("Display POC " + (_CompositeProfileSettings.ShowPOC ? "On" : "Off"), "btDisplayPOC_Comp", Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Display VAL " + (_CompositeProfileSettings.ShowVAL ? "On" : "Off"), "btDisplayVAL_Comp", Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Display VAH " + (_CompositeProfileSettings.ShowVAH ? "On" : "Off"), "btDisplayVAH_Comp", Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Display Profile " + (_CompositeProfileSettings.ShowProfile ? "On" : "Off"), "btDisplayProfile_Comp", Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Display Extreme " + (_CompositeProfileSettings.ShowExtremes ? "On" : "Off"), "btDisplayExtremes_Comp", Brushes.Black, General_Click, _dicMenuItems[headItem]);
					AddMenuItem("Display Text " + (_CompositeProfileSettings.ShowText ? "On" : "Off"), "btDisplayText_Comp", Brushes.Black, General_Click, _dicMenuItems[headItem]);
					//AddMenuItem("Volume Numbers " + (_GeneralSettings.ShowVolumeNumbers ? "ON" : "OFF"), "btVolumeNumbers", Brushes.Black, General_Click, _dicMenuItems[headItem], true, style);
					//               AddMenuItem("Level Labels " + (_GeneralSettings.ShowLevelLabels ? "ON" : "OFF"), "btLevelLabels", Brushes.Black, General_Click, _dicMenuItems[headItem], true, style);
					//AddMenuItem("Level Extend " + (_GeneralSettings.ExtendLevels ? "ON" : "OFF"), "btLevelExtend", Brushes.Black, General_Click, _dicMenuItems[headItem], true, style);
					#endregion

					#region Profile (RealTime)
					headItem = "miProfileRealTime";
					AddMenuItem("Profile (RealTime)", headItem, Brushes.Black, null, MenuControl, true, style);
					AddMenuItem("Draw RealTime Profiles", "btDrawRealTimeProfiles", Brushes.Black, General_Click, _dicMenuItems[headItem], true, style, false); 
					AddMenuItem("Display POC " + (_RealTimeProfileSettings.ShowPOC ? "On" : "Off"), "btDisplayPOC_RT", Brushes.Black, General_Click, _dicMenuItems[headItem]);
					AddMenuItem("Display VAL " + (_RealTimeProfileSettings.ShowVAL ? "On" : "Off"), "btDisplayVAL_RT", Brushes.Black, General_Click, _dicMenuItems[headItem]);
					AddMenuItem("Display VAH " + (_RealTimeProfileSettings.ShowVAH ? "On" : "Off"), "btDisplayVAH_RT", Brushes.Black, General_Click, _dicMenuItems[headItem]);
					AddMenuItem("Display Profile " + (_RealTimeProfileSettings.ShowProfile ? "On" : "Off"), "btDisplayProfile_RT", Brushes.Black, General_Click, _dicMenuItems[headItem]);
					AddMenuItem("Display Extreme " + (_RealTimeProfileSettings.ShowExtremes ? "On" : "Off"), "btDisplayExtremes_RT", Brushes.Black, General_Click, _dicMenuItems[headItem]);
					AddMenuItem("Display Text " + (_RealTimeProfileSettings.ShowText ? "On" : "Off"), "btDisplayText_RT", Brushes.Black, General_Click, _dicMenuItems[headItem]);
					#endregion

					#region Profile (Static)
					headItem = "miProfileStatic";
                    AddMenuItem("Profile (Static)", headItem, Brushes.Black, null, MenuControl, true, style);
                    AddMenuItem("Draw Static Profile", "btDrawStaticProfile", Brushes.Black, General_Click, _dicMenuItems[headItem], true, style, false);
					AddMenuItem("Draw Multiple Static Profile", "btDrawStaticMultiProfile", Brushes.Black, General_Click, _dicMenuItems[headItem], true, style, false);
					AddMenuItem("Display POC " + (_HistoricalProfileSettings.ShowPOC ? "On" : "Off"), "btDisplayPOC", Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Display VAL " + (_HistoricalProfileSettings.ShowVAL ? "On" : "Off"), "btDisplayVAL", Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Display VAH " + (_HistoricalProfileSettings.ShowVAH ? "On" : "Off"), "btDisplayVAH", Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Display Profile " + (_HistoricalProfileSettings.ShowProfile ? "On" : "Off"), "btDisplayProfile", Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Display Extreme " + (_HistoricalProfileSettings.ShowExtremes ? "On" : "Off"), "btDisplayExtremes", Brushes.Black, General_Click, _dicMenuItems[headItem]);
					AddMenuItem("Display Text " + (_HistoricalProfileSettings.ShowText ? "On" : "Off"), "btDisplayText", Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Delete All Static Profiles", "btDeleteAllStaticProfile", Brushes.Black, General_Click, _dicMenuItems[headItem], true, style, false);
                    #endregion

                    #region Cluster
                    headItem = "miCluster";
                    AddMenuItem("Cluster", headItem, Brushes.Black, null, MenuControl, true, style);
                    AddMenuItem("Display Border " + (_ClusterSettings.ShowBorder ? "On" : "Off"), "btDisplayBorder", Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Display Shading " + (_ClusterSettings.ShowShading ? "On" : "Off"), "btDisplayShading", Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    #endregion

                    #region WAP
                    headItem = "miWAP";
                    AddMenuItem("WAP", headItem, Brushes.Black, null, MenuControl, true, style);
                    AddMenuItem("Display VWAP " + (_VWAPSettings.Show ? "On" : "Off"), "btDisplayVWAP", Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    AddMenuItem("Display CWAP " + (_CWAPSettings.Show ? "On" : "Off"), "btDisplayCWAP", Brushes.Black, General_Click, _dicMenuItems[headItem]);
                    #endregion

                    #region Subscribe to Tab Control
                    _grdIndyToolbar.Children.Add(_mnuControlContainer);

					_wChart.MainMenu.Add(_grdIndyToolbar);

					foreach (TabItem tab in _wChart.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == _wChart.MainTabControl.SelectedItem) _grdIndyToolbar.Visibility = Visibility.Visible;
					AutomationProperties.SetAutomationId(_grdIndyToolbar, _sToolbarName + uID);
					#endregion

					#region Chart Events
					ChartControl.PreviewMouseMove += new MouseEventHandler(Chart_MouseMove);
					ChartControl.MouseDown += new MouseButtonEventHandler(Chart_MouseDown);
                    ChartControl.KeyDown += ChartControl_PreviewKeyDown;
                    //ChartControl.KeyUp += ChartControl_PreviewKeyUp;
					#endregion

					#region Tab Management
					//if (tabSelected())
					//	InsertControl();
					//else
					//	RemoveControl();

					_wChart.MainTabControl.SelectionChanged += tabChanged;
					_bAa = true;
					#endregion
				};
                GeneralInvokeAction(p);
            }
        }

        //private void ChartControl_PreviewKeyDown(object sender, KeyEventArgs e)
        //{
        //    //e.Handled = true;
        //}
        //private void ChartControl_PreviewKeyUp(object sender, KeyEventArgs e)
        //{
        //    e.Handled = true;
        //}
        #endregion

        #region Add Separator
        private void addSep(string name)
        {
            Separator sep = new Separator();
            sep.Name = name;
            sep.Visibility = Visibility.Visible;
            if (!_wChart.MainMenu.Contains(sep)) _wChart.MainMenu.Add(sep);
            this._dicSeparators.TryAdd(name, sep);
        }
        #endregion

        #region Add Button
        private void addButton(string name, string text, double fontSize, Brush background, Brush textColor, string fontFamily, RoutedEventHandler reh)
        {
            Style s = new Style();

            s.TargetType = typeof(Button);
            s.Setters.Add(new Setter(Button.FontSizeProperty, fontSize));
            s.Setters.Add(new Setter(Button.BackgroundProperty, background));
            s.Setters.Add(new Setter(Button.ForegroundProperty, textColor));
            s.Setters.Add(new Setter(Button.FontFamilyProperty, new FontFamily(fontFamily)));
            s.Setters.Add(new Setter(Button.FontWeightProperty, FontWeights.Bold));
            s.Setters.Add(new Setter(Button.BorderBrushProperty, textColor));
            s.Setters.Add(new Setter(Button.BorderThicknessProperty, new Thickness(2)));

            Button but = new Button();
            but.Style = s;
            but.Name = name;
            but.Content = text;
            but.IsEnabled = true;
            but.HorizontalAlignment = HorizontalAlignment.Left;

            but.Click += reh;

            _wChart.MainMenu.Add(but);

            but.Visibility = Visibility.Collapsed;
            this._dicButtons.TryAdd(name, but);
        }
        #endregion

        #region Add Menu Item
        private void AddMenuItem(string Header, string Name, Brush TextBrush, RoutedEventHandler EventHandler, MenuItem Parent = null, bool Editable = true, Style style = null, bool StaysOpenOnClick = true)
        {
            MenuItem item = new MenuItem { Header = Header, Name = Name, Foreground = TextBrush, StaysOpenOnClick = StaysOpenOnClick, FontWeight = FontWeights.Normal };
            if (style != null)
                item.Style = style;
            item.IsEnabled = Editable;
            if (EventHandler != null)
                item.Click += EventHandler;
            if (Parent != null)
                Parent.Items.Add(item);
            _dicMenuItems.TryAdd(item.Name, item);
        }
        #endregion

        #region Create DropDown Menu
        private Grid createDropDownMenu(string PCtype)
        {
            const int rHeight = 26;

            Label gLabel = new Label();//#RJBug001

            Button gCmdup = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "+", VerticalAlignment = VerticalAlignment.Bottom, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
            Button gCmddw = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "-", VerticalAlignment = VerticalAlignment.Top, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001

            ComboBox CompTypeCombo;


            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });

            #region -- line 1 - Combo --
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Padding = new Thickness(0), Margin = new Thickness(0), Content = "Type : " };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);

            CompTypeCombo = new ComboBox { Name = string.Format("CPS1combo{0}", uID), MinWidth = 75 + gCmdup.Width, Width = 75 + gCmdup.Width, MaxWidth = 75 + gCmdup.Width, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            CompTypeCombo.Items.Add(new ComboBoxItem { Content = "Time" });
            CompTypeCombo.Items.Add(new ComboBoxItem { Content = "Day" });
            CompTypeCombo.Items.Add(new ComboBoxItem { Content = "Week" });
            CompTypeCombo.Items.Add(new ComboBoxItem { Content = "Month" });
            CompTypeCombo.Text = PCtype;
            CompTypeCombo.KeyDown += Combo_KeyDown;
            CompTypeCombo.SelectionChanged += Combo_SelectionChanged;
            CompTypeCombo.SetValue(Grid.ColumnProperty, 1);
            CompTypeCombo.SetValue(Grid.RowProperty, 0);
            CompTypeCombo.SetValue(Grid.ColumnSpanProperty, 2);

            grid.Children.Add(lbl1);
            grid.Children.Add(CompTypeCombo);

            return grid;

            #endregion

        }
        private void Combo_KeyDown(object sender, KeyEventArgs e) { e.Handled = true; }

        #endregion

        #region Create UpDown Menu
        //Function taken from NS VM Lean and needs to be updated to standards after christmas
        private Grid createUpDownMenu(string nudValue1, double value, string id, string content, double increment, double minValue, double maxValue)
        {
            const int rHeight = 26;

            Button gCmdup = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "+", VerticalAlignment = VerticalAlignment.Bottom, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
            Button gCmddw = new Button() { Margin = new Thickness(0), Padding = new Thickness(0, -5, 0, 0), Height = 10, Width = 11, MinWidth = 11, MaxWidth = 11, Content = "-", VerticalAlignment = VerticalAlignment.Top, FontWeight = FontWeights.Bold, FontSize = 13, BorderThickness = new Thickness(0, 1, 1, 1) };//"??" - #RJBug001
            Label gLabel = new Label();//#RJBug001

            Grid grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(55) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(11) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });
            grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight / 2) });

            //line 1
            Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = content };
            lbl1.SetValue(Grid.ColumnProperty, 0);
            lbl1.SetValue(Grid.RowProperty, 0);
            lbl1.SetValue(Grid.RowSpanProperty, 2);

            TextBox nudMST1 = new TextBox() { Name = id + uID, MinWidth = 60, Width = 60, MaxWidth = 60, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = gLabel.Foreground };
            nudMST1.Text = nudValue1;
            nudMST1.KeyDown += menuTxtbox_KeyDown;
            nudMST1.TextChanged += NumericUpDownTextChanged;
            nudMST1.MouseWheel += delegate (object o, MouseWheelEventArgs e)
            {
                e.Handled = true;
                if (e.Delta >= 0) Math.Round(value += increment, 1);
                else Math.Round(value -= increment, 1);
                value = Math.Min(Math.Max(minValue, value), maxValue);
                nudMST1.Text = value.ToString("#0.#");
                InformUserAboutRecalculation();
                ForceRefresh();
            };
            nudMST1.SetValue(Grid.ColumnProperty, 1);
            nudMST1.SetValue(Grid.RowProperty, 0);
            nudMST1.SetValue(Grid.RowSpanProperty, 2);

            Button cmdup1 = new Button() { Name = id + "_Up" + uID, Margin = gCmdup.Margin, Padding = gCmdup.Padding, Height = gCmdup.Height, Width = gCmdup.Width, MinWidth = gCmdup.MinWidth, MaxWidth = gCmdup.MaxWidth, Content = gCmdup.Content, VerticalAlignment = gCmdup.VerticalAlignment, FontWeight = gCmdup.FontWeight, FontSize = gCmdup.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmdup.BorderThickness, BorderBrush = gLabel.Foreground };
            Button cmddw1 = new Button() { Name = id + "_Dn" +uID, Margin = gCmddw.Margin, Padding = gCmddw.Padding, Height = gCmddw.Height, Width = gCmddw.Width, MinWidth = gCmddw.MinWidth, MaxWidth = gCmddw.MaxWidth, Content = gCmddw.Content, VerticalAlignment = gCmddw.VerticalAlignment, FontWeight = gCmddw.FontWeight, FontSize = gCmddw.FontSize, Foreground = gLabel.Foreground, Background = gLabel.Background, BorderThickness = gCmddw.BorderThickness, BorderBrush = gLabel.Foreground };
            cmdup1.Click += UpDownButton_Click;
            cmdup1.SetValue(Grid.ColumnProperty, 2);
            cmdup1.SetValue(Grid.RowProperty, 0);
            cmddw1.Click += UpDownButton_Click;
            cmddw1.SetValue(Grid.ColumnProperty, 2);
            cmddw1.SetValue(Grid.RowProperty, 1);

            _dicGrids.TryAdd(id, grid);
            _dicTextBoxes.TryAdd(nudMST1.Name, nudMST1);
            _dicButtons.TryAdd(cmdup1.Name, cmdup1);
            _dicButtons.TryAdd(cmddw1.Name, cmddw1);

            grid.Children.Add(lbl1);
            grid.Children.Add(nudMST1);
            grid.Children.Add(cmdup1);
            grid.Children.Add(cmddw1);

            //UpdateTextBoxEnable(); - nu cred ca ne  mai trebuie

            return grid;
        }
        #endregion

        #region Tab Selected
        private bool tabSelected()
        {
            bool tabSelected = false;
            foreach (System.Windows.Controls.TabItem tab in _wChart.MainTabControl.Items)
            {
                if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == _wChart.MainTabControl.SelectedItem)
                    tabSelected = true;
            }
            return tabSelected;
        }
        #endregion

        #region Insert Control
        protected void InsertControl()
        {
            foreach (KeyValuePair<string, Button> b in _dicButtons)
            {
                b.Value.Visibility = Visibility.Visible;
			}

			foreach (KeyValuePair<string, MenuItem> b in _dicMenuItems)
			{
				b.Value.Visibility = Visibility.Visible;
			}

			foreach (KeyValuePair<string, Separator> c in _dicSeparators)
            {
                c.Value.Visibility = Visibility.Visible;
            }
            InsertPanel();
        }
        #endregion

        #region Insert Panel
        protected void InsertPanel()
        {
            if (_bPannelActive) return;

            _bPannelActive = true;
        }
        #endregion

        #region Remove Control
        protected void RemoveControl()
        {
            foreach (KeyValuePair<string, Button> b in _dicButtons)
            {
                b.Value.Visibility = Visibility.Collapsed;
            }

            foreach (KeyValuePair<string, MenuItem> b in _dicMenuItems)
            {
                b.Value.Visibility = Visibility.Collapsed;
            }

            foreach (KeyValuePair<string, Separator> c in _dicSeparators)
            {
                c.Value.Visibility = Visibility.Collapsed;
            }

            RemovePanel();
        }
        #endregion

        #region Remove Panel
        protected void RemovePanel()
        {
			if (!_bPannelActive) return;

            _bPannelActive = false;
        }
        #endregion

        #region Is Running In
        private string IsRunningIn()
        {
            // Find the top most NinjaScriptBase
            NinjaScriptBase topMost = this;
            for (; topMost.Parent != null; topMost = topMost.Parent) { }

            // Check if it is a Market Analyzer Indicator Column
            MarketAnalyzerColumns.IndicatorMarketAnalyzerColumn ma = topMost as MarketAnalyzerColumns.IndicatorMarketAnalyzerColumn;

            if (ma != null)
                return "Market Analyzer";

            // Check if its a SuperDom Indicator
            IndicatorSuperDomBase sd = topMost as IndicatorSuperDomBase;

            if (sd != null)
                return "Super DOM";

            // Check if it is a chart indicator
            IndicatorBase ib = topMost as IndicatorBase;

            if (ib != null)
                return "Chart";

            return "Unknown";
        }
        #endregion

        #endregion

        #region Termination

        #region Cleaner
        private void Cleaner()
		{
			if (this.ChartControl != null)
			{
				if (_wChart == null) { _wChart = Window.GetWindow(ChartControl.Parent) as Chart; }
				if (_wChart != null)
				{
                    ChartControl.Dispatcher.InvokeAsync((Action)(() =>
					{
                        _wChart.MainTabControl.SelectionChanged -= tabChanged;

						if(_gChart != null)
                            _gChart.PreviewKeyDown -= ChartControl_PreviewKeyDown;

                        #region Chart Events
                        if (ChartControl != null)
                        {
                            ChartControl.PreviewMouseMove -= Chart_MouseMove;
                            ChartControl.MouseDown -= Chart_MouseDown;
                            ChartControl.KeyDown -= ChartControl_PreviewKeyDown;
                        }
                        //_EasyTraderControl.KeyUp -= ChartControl_PreviewKeyUp;
                        #endregion

                        RemoveControl();

                        #region Remove toolbar stuff
                        foreach (KeyValuePair<string, Separator> b in _dicSeparators)
                            rco(b.Value);
                        _dicSeparators.Clear();
						foreach (KeyValuePair<string, Button> b in this._dicButtons)
                            rco(b.Value, OnOffB);
						this._dicButtons.Clear();

                        if (_grdIndyToolbar != null)
                        {
                            _wChart.MainMenu.Remove(_grdIndyToolbar);
                            _grdIndyToolbar = null;

                            _bIsToolBarButtonAdded = false;
                        }
                        #endregion
                    }));
				}
			}
		}
        #endregion

        #region Remove Chart Object
        private void rco(Button obj, RoutedEventHandler reh)
		{
			if (obj != null)
			{
				obj.Click -= reh;
				if (_wChart.MainMenu.Contains(obj)) _wChart.MainMenu.Remove(obj);
				obj = null;
			}
		}
		private void rco(Separator obj)
		{
			if (obj != null)
			{
				if (_wChart.MainMenu.Contains(obj)) _wChart.MainMenu.Remove(obj);
				obj = null;
			}
		}
		#endregion

		#endregion

		#endregion

		#region On Bar Update

		#region Calculate Base Price
		private static double CalculateBasePrice(double firstLow, int step, double tickSize)
		{
			double dDivizors = firstLow / (step * tickSize);
			return Math.Floor(dDivizors) * step * tickSize;
		}
		#endregion

		#region Get Overlap List
		private List<BarDetails> GetOverlapList()
		{
			if (_LTF_Bar == null)
				return null;

			lock (_dicAllBars)
			{
				//first we grab the inrange for the lower timefrma bar
				EInRange eFirstBarInRange = _dicAllBars[CurrentBars[0]].IsBarInRange(_LTF_Bar);
				//if the LTF bar is fully inside the CTF bar then we push the entire bar through the system
				if (eFirstBarInRange == EInRange.Full)
					return new List<BarDetails> { _LTF_Bar };
				//if the LTF is split between 1 or more bars (let's hope it's no more than 2, although we made this system work for a span of more than 2 bars)
				else if (eFirstBarInRange == EInRange.Partial)
				{
					//we first initialize the result list
					List<BarDetails> lstResult = new List<BarDetails>();
					//then we add the first bars range to this list
					lstResult.Add(_dicAllBars[CurrentBars[0]].BarDetails.HowMuchIsInRange(_LTF_Bar));
					//we initializie the number of bars back
					int iGoingBack = 1;
					//we use a while loop with a maximum of 50 bars back (if a LTF bar is more than 50 CTF bars then choose a smaller fucking timeframe!!!)
					while (iGoingBack < 50)
					{
						//we now check that we are not going farther back than the first bar on the chart
						//Also if the x bar ago doesn't have the _LTF_Bar in its time range then we just break out of the while loop
						//We expect this to be the definitive stop of the while loop every time
						if (CurrentBars[0] - iGoingBack < 0 || _dicAllBars[CurrentBars[0] - iGoingBack].IsBarInRange(_LTF_Bar) == EInRange.None)
							break;
						//if there is a part of the bar in the range, then we grab the exact part that is in the range and add it to the return list
						lstResult.Add(_dicAllBars[CurrentBars[0] - iGoingBack].BarDetails.HowMuchIsInRange(_LTF_Bar));
						//then we increment to go to the previous bar
						iGoingBack++;
					}
					return lstResult;
				}
			}
			return null;
		}
		#endregion

		#region Get Separate List
		private List<BarDetails> GetSeparateList(List<BarDetails> all, int index)
		{
			//we initialize shit and we grab the bar that we want to get the values for
			List<BarDetails> lstResults = new List<BarDetails>();
			BarDetails bar = all[index];
			//we itterate through all the values
			for (int i = 0; i < all.Count; i++)
			{
				//we skip the indiex that we are using as a base
				if (i == index)
					continue;
				//if the bars overlap
				if (bar.DoWeOverlap(all[i]))
				{
					//then we grab how much they overlap by
					BarDetails overlap = bar.HowMuchIsInRange(all[i]);
					//if the low of the overlap is the same as the reference low
					if (overlap.Low == bar.Low)
					{
						//we add it to the list
						lstResults.Add(new BarDetails(bar.Bar) { Low = bar.Low, High = overlap.High, Ask = overlap.Ask / 2, Bid = overlap.Bid / 2 });
						//if the highs are the same we move on to the next index
						if (overlap.High == bar.High)
							continue;
					}
					//if the lows are not the same
					else
					{
						//then we add the 2 steps preceding to adding the high
						double volume = ((overlap.Low - bar.Low) / (bar.High - bar.Low) * bar.Volume) / 2;
						lstResults.Add(new BarDetails(bar.Bar) { Low = bar.Low, High = overlap.Low, Ask = volume, Bid = volume });
						lstResults.Add(new BarDetails(bar.Bar) { Low = overlap.Low, High = overlap.High, Ask = overlap.Ask / 2, Bid = overlap.Bid / 2 });
						//if the highs are equal then we move to the next index
						if (overlap.High == bar.High)
							continue;
					}
					//if there is still space until the high from the overlap, then we add that space here
					double volumeH = ((bar.High - overlap.High) / (bar.High - bar.Low) * bar.Volume) / 2;
					lstResults.Add(new BarDetails(bar.Bar) { Low = overlap.High, High = bar.High, Ask = volumeH, Bid = volumeH });
				}
			}
			//if there are more than 2 bars in the LTF bar, then we need to do a special combination of the zones
			if (all.Count > 2)
			{
				//we still need to get this done, let's hook the other shit up first so we can test though
			}
			return lstResults;
		}
		#endregion

		#endregion

		#region Event Handlers

		#region Tab Changed
		private void tabChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0)
                return;
            TabItem tI = e.AddedItems[0] as TabItem;
            if (tI == null)
                return;
            ChartTab chT = tI.Content as ChartTab;
            if (chT == null || _grdIndyToolbar == null)
                return;
            _grdIndyToolbar.Visibility = chT.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
            //if (tabSelected()) InsertControl(); else RemoveControl();
        }
        #endregion

        #region On Off Button Click
        private void OnOffB(object s, EventArgs e)
        {
            Button b = s as Button;
            if (b != null)
            {
                switch (b.Name)
                {
                    case "bDrawProfileHistorical":
						_bProfileOnStatic = !_bProfileOnStatic;
						b.Content = string.Format("Hist - {0}", _bProfileOnStatic ? _sStopDrawText : _sStartDrawText);
                        ChartControl.InvalidateVisual();
                        break;
					case "bDrawProfileCurrentBar":
                        _bProfileOnRealTime = !_bProfileOnRealTime;
						b.Content = string.Format("CB - {0}", _bProfileOnRealTime ? _sStopDrawText : _sStartDrawText);
						ChartControl.InvalidateVisual();
						break;
				}
            }
        }
        #endregion

        #region General_Click
        private void General_Click(object sender, EventArgs e)
        {
            bool invalidateVisual = false;
            MenuItem item = sender as MenuItem;
            switch (item.Name)
            {

				#region Composite
				case "btProfileComposite":
					_GeneralSettings.ShowComposite = !_GeneralSettings.ShowComposite;
                    ShowComposite = _GeneralSettings.ShowComposite;
                    item.Header = "Profile (Composite) " + (_GeneralSettings.ShowComposite ? "On" : "Off");
					if (_lstCompositeProfiles.Count > 0)
						for (int i = 0; i < _lstCompositeProfiles.Count; i++)
							_lstCompositeProfiles[i].Settings.Show = _GeneralSettings.ShowComposite;
					invalidateVisual = true;
					break;
				case "btDrawOnTop":
					_GeneralSettings.ShowOnTop = !_GeneralSettings.ShowOnTop;
					item.Header = "Draw On Top " + (_GeneralSettings.ShowOnTop ? "On" : "Off");
					//still needs functionality
					invalidateVisual = true; break;
				case "btCurrentProfile":
					_GeneralSettings.ShowCurrentProfile = !_GeneralSettings.ShowCurrentProfile;
					ShowCurrentProfile = _GeneralSettings.ShowCurrentProfile;
                    item.Header = "Current Profile " + (_GeneralSettings.ShowCurrentProfile ? "On" : "Off");
					if (_lstCompositeProfiles.Count > 0)
						_lstCompositeProfiles[_lstCompositeProfiles.Count - 1].Settings.Show = _GeneralSettings.ShowCurrentProfile;
					invalidateVisual = true;
					break;
				case "btCurrentProfilePosition":
					_GeneralSettings.ShowProfileLeft = !_GeneralSettings.ShowProfileLeft;
                    DrawOnLeft = _GeneralSettings.ShowProfileLeft;
                    item.Header = "Current Profile " + (_GeneralSettings.ShowProfileLeft ? "LEFT" : "RIGHT");
					if (_lstCompositeProfiles.Count > 0)
						_lstCompositeProfiles[_lstCompositeProfiles.Count - 1].Settings.IsRight = !_GeneralSettings.ShowProfileLeft;
					invalidateVisual = true;
					break;
				case "btHistoricalProfiles":
					_GeneralSettings.ShowHistorical = !_GeneralSettings.ShowHistorical;
                    ShowHistorical = _GeneralSettings.ShowHistorical;
                    item.Header = "Historical Profiles " + (_GeneralSettings.ShowHistorical ? "On" : "Off");
					if (_lstCompositeProfiles.Count > 1)
						for (int i = 0; i < _lstCompositeProfiles.Count - 1; i++)
							_lstCompositeProfiles[i].Settings.Show = _GeneralSettings.ShowHistorical;
					invalidateVisual = true;
					break;
				//case "btVolumeNumbers": _GeneralSettings.ShowVolumeNumbers = !_GeneralSettings.ShowVolumeNumbers; item.Header = "Volume Numbers " + (_GeneralSettings.ShowVolumeNumbers ? "ON" : "OFF"); invalidateVisual = true; break;
				case "btDisplayPOC_Comp":
					_CompositeProfileSettings.ShowPOC = !_CompositeProfileSettings.ShowPOC;
					ShowPOCComposite = _CompositeProfileSettings.ShowPOC;
                    item.Header = "Display POC " + (_CompositeProfileSettings.ShowPOC ? "On" : "Off");
					for (int i = 0; i < _lstCompositeProfiles.Count; i++)
						_lstCompositeProfiles[i].Settings.ShowPOC = _CompositeProfileSettings.ShowPOC;
					invalidateVisual = true;
					break;
				case "btDisplayVAL_Comp":
					_CompositeProfileSettings.ShowVAL = !_CompositeProfileSettings.ShowVAL;
                    ShowVALComposite = _CompositeProfileSettings.ShowVAL;
                    item.Header = "Display VAL " + (_CompositeProfileSettings.ShowVAL ? "On" : "Off");
					for (int i = 0; i < _lstCompositeProfiles.Count; i++)
						_lstCompositeProfiles[i].Settings.ShowVAL = _CompositeProfileSettings.ShowVAL;
					invalidateVisual = true;
					break;
				case "btDisplayVAH_Comp":
					_CompositeProfileSettings.ShowVAH = !_CompositeProfileSettings.ShowVAH;
                    ShowVAHComposite = _CompositeProfileSettings.ShowVAH;
                    item.Header = "Display VAH " + (_CompositeProfileSettings.ShowVAH ? "On" : "Off");
					for (int i = 0; i < _lstCompositeProfiles.Count; i++)
						_lstCompositeProfiles[i].Settings.ShowVAH = _CompositeProfileSettings.ShowVAH;
					invalidateVisual = true; break;
				case "btDisplayProfile_Comp":
					_CompositeProfileSettings.ShowProfile = !_CompositeProfileSettings.ShowProfile;
                    ShowProfileComposite = _CompositeProfileSettings.ShowProfile;
                    item.Header = "Display Profile " + (_CompositeProfileSettings.ShowProfile ? "On" : "Off");
					for (int i = 0; i < _lstCompositeProfiles.Count; i++)
						_lstCompositeProfiles[i].Settings.ShowProfile = _CompositeProfileSettings.ShowProfile;
					invalidateVisual = true;
					break;
				case "btDisplayExtremes_Comp":
					_CompositeProfileSettings.ShowExtremes = !_CompositeProfileSettings.ShowExtremes;
                    ShowExtremesComposite = _CompositeProfileSettings.ShowExtremes;
                    item.Header = "Display Extreme " + (_CompositeProfileSettings.ShowExtremes ? "On" : "Off");
					for (int i = 0; i < _lstCompositeProfiles.Count; i++)
						_lstCompositeProfiles[i].Settings.ShowExtremes = _CompositeProfileSettings.ShowExtremes;
					invalidateVisual = true;
					break;
				case "btDisplayText_Comp":
					_CompositeProfileSettings.ShowText = !_CompositeProfileSettings.ShowText;
					ShowTextComposite = _CompositeProfileSettings.ShowText;
					item.Header = "Display Text " + (_CompositeProfileSettings.ShowText ? "On" : "Off");
					for (int i = 0; i < _lstCompositeProfiles.Count; i++)
						_lstCompositeProfiles[i].Settings.ShowText = _CompositeProfileSettings.ShowText;
					invalidateVisual = true;
					break;
				#endregion

				//case "btLevelLabels": _GeneralSettings.ShowLevelLabels = !_GeneralSettings.ShowLevelLabels; item.Header = "Level Labels " + (_GeneralSettings.ShowLevelLabels ? "ON" : "OFF"); invalidateVisual = true; break;
				//case "btLevelExtend": _GeneralSettings.ExtendLevels = !_GeneralSettings.ExtendLevels; item.Header = "Level Extend " + (_GeneralSettings.ExtendLevels ? "ON" : "OFF"); invalidateVisual = true; break;

				#region RealTime
				case "btDrawRealTimeProfiles": _bProfileOnRealTime = !_bProfileOnRealTime; invalidateVisual = true; break;
				case "btDisplayPOC_RT":
					_RealTimeProfileSettings.ShowPOC = !_RealTimeProfileSettings.ShowPOC;
                    ShowPOCCurrentBar = _RealTimeProfileSettings.ShowPOC;
                    item.Header = "Display POC " + (_RealTimeProfileSettings.ShowPOC ? "On" : "Off");
					for (int i = 0; i < _lstRealTimeProfiles.Count; i++)
						_lstRealTimeProfiles[i].Settings.ShowPOC = _RealTimeProfileSettings.ShowPOC;
					invalidateVisual = true;
					break;
				case "btDisplayVAL_RT":
					_RealTimeProfileSettings.ShowVAL = !_RealTimeProfileSettings.ShowVAL;
                    ShowVALCurrentBar = _RealTimeProfileSettings.ShowVAL;
                    item.Header = "Display VAL " + (_RealTimeProfileSettings.ShowVAL ? "On" : "Off");
					for (int i = 0; i < _lstRealTimeProfiles.Count; i++)
						_lstRealTimeProfiles[i].Settings.ShowVAL = _RealTimeProfileSettings.ShowVAL;
					invalidateVisual = true;
					break;
				case "btDisplayVAH_RT":
					_RealTimeProfileSettings.ShowVAH = !_RealTimeProfileSettings.ShowVAH;
                    ShowVAHCurrentBar = _RealTimeProfileSettings.ShowVAH;
                    item.Header = "Display VAH " + (_RealTimeProfileSettings.ShowVAH ? "On" : "Off");
					for (int i = 0; i < _lstRealTimeProfiles.Count; i++)
						_lstRealTimeProfiles[i].Settings.ShowVAH = _RealTimeProfileSettings.ShowVAH;
					invalidateVisual = true; break;
				case "btDisplayProfile_RT":
					_RealTimeProfileSettings.ShowProfile = !_RealTimeProfileSettings.ShowProfile;
                    ShowProfileCurrentBar = _RealTimeProfileSettings.ShowProfile;
                    item.Header = "Display Profile " + (_RealTimeProfileSettings.ShowProfile ? "On" : "Off");
					for (int i = 0; i < _lstRealTimeProfiles.Count; i++)
						_lstRealTimeProfiles[i].Settings.ShowProfile = _RealTimeProfileSettings.ShowProfile;
					invalidateVisual = true;
					break;
				case "btDisplayExtremes_RT":
					_RealTimeProfileSettings.ShowExtremes = !_RealTimeProfileSettings.ShowExtremes;
                    ShowExtremesCurrentBar = _RealTimeProfileSettings.ShowExtremes;
                    item.Header = "Display Extreme " + (_RealTimeProfileSettings.ShowExtremes ? "On" : "Off");
					for (int i = 0; i < _lstRealTimeProfiles.Count; i++)
						_lstRealTimeProfiles[i].Settings.ShowExtremes = _RealTimeProfileSettings.ShowExtremes;
					invalidateVisual = true;
					break;
				case "btDisplayText_RT":
					_RealTimeProfileSettings.ShowText = !_RealTimeProfileSettings.ShowText;
					ShowTextRealTime = _RealTimeProfileSettings.ShowText;
					item.Header = "Display Text " + (_RealTimeProfileSettings.ShowText ? "On" : "Off");
					for (int i = 0; i < _lstRealTimeProfiles.Count; i++)
						_lstRealTimeProfiles[i].Settings.ShowText = _RealTimeProfileSettings.ShowText;
					invalidateVisual = true;
					break;
				#endregion

				#region Static
				case "btDrawStaticProfile": _bProfileOnStatic = !_bProfileOnStatic; invalidateVisual = true; break;
				case "btDrawStaticMultiProfile": _bProfileOnStaticMultiple = !_bProfileOnStaticMultiple; invalidateVisual = true; break;
				case "btDisplayPOC":
					_HistoricalProfileSettings.ShowPOC = !_HistoricalProfileSettings.ShowPOC;
                    ShowPOCHisto = _HistoricalProfileSettings.ShowPOC;
                    item.Header = "Display POC " + (_HistoricalProfileSettings.ShowPOC ? "On" : "Off");
					for (int i = 0; i < _lstStaticProfiles.Count; i++)
						_lstStaticProfiles[i].Settings.ShowPOC = _HistoricalProfileSettings.ShowPOC;
					invalidateVisual = true;
					break;
				case "btDisplayVAL":
					_HistoricalProfileSettings.ShowVAL = !_HistoricalProfileSettings.ShowVAL;
                    ShowVALHisto = _HistoricalProfileSettings.ShowVAL;
                    item.Header = "Display VAL " + (_HistoricalProfileSettings.ShowVAL ? "On" : "Off");
					for (int i = 0; i < _lstStaticProfiles.Count; i++)
						_lstStaticProfiles[i].Settings.ShowVAL = _HistoricalProfileSettings.ShowVAL;
					invalidateVisual = true;
					break;
				case "btDisplayVAH":
					_HistoricalProfileSettings.ShowVAH = !_HistoricalProfileSettings.ShowVAH;
                    ShowVAHHisto = _HistoricalProfileSettings.ShowVAH;
                    item.Header = "Display VAH " + (_HistoricalProfileSettings.ShowVAH ? "On" : "Off");
					for (int i = 0; i < _lstStaticProfiles.Count; i++)
						_lstStaticProfiles[i].Settings.ShowVAH = _HistoricalProfileSettings.ShowVAH;
					invalidateVisual = true;
					break;
				case "btDisplayProfile":
					_HistoricalProfileSettings.ShowProfile = !_HistoricalProfileSettings.ShowProfile;
                    ShowProfileHisto = _HistoricalProfileSettings.ShowProfile;
                    item.Header = "Display Profile " + (_HistoricalProfileSettings.ShowProfile ? "On" : "Off");
					for (int i = 0; i < _lstStaticProfiles.Count; i++)
						_lstStaticProfiles[i].Settings.ShowProfile = _HistoricalProfileSettings.ShowProfile;
					invalidateVisual = true;
					break;
				case "btDisplayExtremes":
					_HistoricalProfileSettings.ShowExtremes = !_HistoricalProfileSettings.ShowExtremes;
                    ShowExtremesHisto = _HistoricalProfileSettings.ShowExtremes;
                    item.Header = "Display Extreme " + (_HistoricalProfileSettings.ShowExtremes ? "On" : "Off");
					for (int i = 0; i < _lstStaticProfiles.Count; i++)
						_lstStaticProfiles[i].Settings.ShowExtremes = _HistoricalProfileSettings.ShowExtremes;
					invalidateVisual = true;
					break;
				case "btDisplayText":
					_HistoricalProfileSettings.ShowText = !_HistoricalProfileSettings.ShowText;
					ShowTextStatic = _HistoricalProfileSettings.ShowText;
					item.Header = "Display Text " + (_HistoricalProfileSettings.ShowText ? "On" : "Off");
					for (int i = 0; i < _lstStaticProfiles.Count; i++)
						_lstStaticProfiles[i].Settings.ShowText = _HistoricalProfileSettings.ShowText;
					invalidateVisual = true;
					break;
				case "btDeleteAllStaticProfile":
					_lstStaticProfiles.Clear();
					invalidateVisual = true;
					break;
				#endregion

				#region Cluster
				case "btDisplayBorder":
					_ClusterSettings.ShowBorder = !_ClusterSettings.ShowBorder;
					ShowBorder = _ClusterSettings.ShowBorder;
                    item.Header = "Display Border " + (_ClusterSettings.ShowBorder ? "On" : "Off");
					invalidateVisual = true;
					break;
				case "btDisplayShading":
					_ClusterSettings.ShowShading = !_ClusterSettings.ShowShading;
                    ShowShading = _ClusterSettings.ShowShading;
                    item.Header = "Display Shading " + (_ClusterSettings.ShowShading ? "On" : "Off");
					invalidateVisual = true;
					break;
				#endregion

				#region WAP
				case "btDisplayVWAP":
					_VWAPSettings.Show = !_VWAPSettings.Show;
					ShowVWAP = _VWAPSettings.Show;
                    item.Header = "Display VWAP " + (_VWAPSettings.Show ? "On" : "Off");
					for (int i = 0; i < _lstCompositeProfiles.Count; i++)
						_lstCompositeProfiles[i].VWAP.Settings.Show = _VWAPSettings.Show;
					for (int i = 0; i < _lstRealTimeProfiles.Count; i++)
						_lstRealTimeProfiles[i].VWAP.Settings.Show = _VWAPSettings.Show;
					for (int i = 0; i < _lstStaticProfiles.Count; i++)
						_lstStaticProfiles[i].VWAP.Settings.Show = _VWAPSettings.Show;
					invalidateVisual = true;
					break;
				case "btDisplayCWAP":
					_CWAPSettings.Show = !_CWAPSettings.Show;
                    ShowCWAP = _CWAPSettings.Show;
                    item.Header = "Display CWAP " + (_CWAPSettings.Show ? "On" : "Off");
					for (int i = 0; i < _lstCompositeProfiles.Count; i++)
						_lstCompositeProfiles[i].CWAP.Settings.Show = _CWAPSettings.Show;
					for (int i = 0; i < _lstRealTimeProfiles.Count; i++)
						_lstRealTimeProfiles[i].CWAP.Settings.Show = _CWAPSettings.Show;
					for (int i = 0; i < _lstStaticProfiles.Count; i++)
						_lstStaticProfiles[i].CWAP.Settings.Show = _CWAPSettings.Show;
					invalidateVisual = true;
					break;
				#endregion

				case "btRecalculate_General":
                    System.Windows.Forms.SendKeys.SendWait("{F5}");
                    break;
            }
            if (invalidateVisual)
                CCInvokeAction(() =>
                {
                    ChartControl.InvalidateVisual();
                });
        }
		#endregion

		#region Selection Changed
		private void Combo_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			_GeneralSettings.CompositeCalculationType = ((ComboBoxItem)(sender as ComboBox).SelectedItem).Content.ToString();
			CompositeType = _GeneralSettings.CompositeCalculationType;
			_dicGrids["btStartTimeHrs"].IsEnabled = _GeneralSettings.CompositeCalculationType == "Time";
			_dicGrids["btStartTimeMin"].IsEnabled = _GeneralSettings.CompositeCalculationType == "Time";
			_dicGrids["btIntervalMin"].IsEnabled = _GeneralSettings.CompositeCalculationType == "Time";
			InformUserAboutRecalculation();
		}
		#endregion

		#region Chart Click, Move Events and Keyboard Events

		#region Move
		private void Chart_MouseMove(object sender, MouseEventArgs e)
		{
			//plans
			float eX = ChartingExtensions.ConvertToHorizontalPixels(e.GetPosition(ChartPanel as IInputElement).X, ChartControl.PresentationSource);
			float eY = ChartingExtensions.ConvertToVerticalPixels(e.GetPosition(ChartPanel as IInputElement).Y, ChartControl.PresentationSource);

			#region Building Static Profile
			if (_bProfileOnStatic || _bProfileOnStaticMultiple)
			{
				double dBarNumber = GetBarClicked(eX);
                BarLocation bar = new BarLocation() { StartTime = _ChartControl.GetTimeBySlotIndex(dBarNumber), EndTime = _ChartControl.GetTimeBySlotIndex(dBarNumber), No = (int)Math.Floor(dBarNumber) };
                if (_BuildingProfileStatic != null)
                {
                    _BuildingProfileStatic.End = bar;
                    double dHigh, dLow;
					lock(_dicAllBars)
						GetHighLow(_dicAllBars, _BuildingProfileStatic.Start, _BuildingProfileStatic.End, CurrentBars[0], out dHigh, out dLow);
                    _BuildingProfileStatic.High = dHigh;
                    _BuildingProfileStatic.Low = dLow;
                }
                ChartControl.InvalidateVisual();
                //e.Handled = true;
				return;
			}
            #endregion

            #region Check Inside Static
            if (_lstStaticProfiles.Count > 0 && _iEditingProfileStatic == -1)
            {
                for (int i = 0; i < _lstStaticProfiles.Count; i++)
                {
                    bool bLeft, bCenter, bRight;
                    bool bIsInside = _lstStaticProfiles[i].CheckInside(eX, eY, e.LeftButton == MouseButtonState.Pressed, out bLeft, out bCenter, out bRight);
                    if (bIsInside)
                    {
                        if (bLeft || bRight)
                            e.MouseDevice.SetCursor(Cursors.SizeWE);
                        else if (bCenter)
                            e.MouseDevice.SetCursor(Cursors.SizeAll);
                        ChartControl.InvalidateVisual();
                        if (_lstStaticProfiles[i].IsEditing)
                        {
                            _iEditingProfileStatic = i;
                            _lstStaticProfiles[i].Reset();
                            break;
                        }
                    }
                }
            }
            #endregion

            #region Check Inside RealTime
            if (_lstRealTimeProfiles.Count > 0 && _iEditingProfileRealTime == -1)
            {
                for (int i = 0; i < _lstRealTimeProfiles.Count; i++)
                {
                    bool bLeft, bCenter, bRight;
                    bool bIsInside = _lstRealTimeProfiles[i].CheckInside(eX, eY, e.LeftButton == MouseButtonState.Pressed, out bLeft, out bCenter, out bRight);
                    if (bIsInside)
                    {
                        if (bLeft || bRight)
                            e.MouseDevice.SetCursor(Cursors.SizeWE);
                        else if (bCenter)
                            e.MouseDevice.SetCursor(Cursors.SizeAll);
                        ChartControl.InvalidateVisual();
                        if (_lstRealTimeProfiles[i].IsEditing)
                        {
                            e.MouseDevice.SetCursor(Cursors.SizeWE);
                            _iEditingProfileRealTime = i;
                            _lstRealTimeProfiles[i].Reset();
                            break;
                        }
                    }
                }
            }
            #endregion

            #region Editing Static Profile
            if (_iEditingProfileStatic >= 0)
            {
                int dBarNumber = (int)_ChartControl.GetSlotIndexByX((int)eX);
                BarLocation bar = new BarLocation() { StartTime = _ChartControl.GetTimeBySlotIndex(dBarNumber), EndTime = _ChartControl.GetTimeBySlotIndex(dBarNumber), No = dBarNumber };
                if (e.LeftButton == MouseButtonState.Pressed)
                {
                    e.MouseDevice.SetCursor(Cursors.SizeWE);
                    if (_lstStaticProfiles[_iEditingProfileStatic].IsLeftAdjusted)
                        _lstStaticProfiles[_iEditingProfileStatic].Start = bar;
                    else if (_lstStaticProfiles[_iEditingProfileStatic].IsRightAdjusted)
                        _lstStaticProfiles[_iEditingProfileStatic].End = bar;
                    else if (_lstStaticProfiles[_iEditingProfileStatic].IsCenterAdjusted)
                    {
                        e.MouseDevice.SetCursor(Cursors.SizeAll);
                        int iLeft, iRight;
                        _lstStaticProfiles[_iEditingProfileStatic].GetDeviation(bar.No, out iLeft, out iRight);
                        iRight = Math.Max(1, Math.Min(iRight, CurrentBars[0]));
                        iLeft = Math.Max(1, Math.Min(iLeft, CurrentBars[0]));
                        BarLocation leftBar = new BarLocation() { StartTime = _ChartControl.GetTimeBySlotIndex(iLeft - 1), EndTime = _ChartControl.GetTimeBySlotIndex(iLeft), No = iLeft };
                        BarLocation rightBar = new BarLocation() { StartTime = _ChartControl.GetTimeBySlotIndex(iRight - 1), EndTime = _ChartControl.GetTimeBySlotIndex(iRight), No = iRight };
                        _lstStaticProfiles[_iEditingProfileStatic].End = rightBar;
                        _lstStaticProfiles[_iEditingProfileStatic].Start = leftBar;
                    }
                    double dHigh, dLow;
					lock(_dicAllBars)
						GetHighLow(_dicAllBars, _lstStaticProfiles[_iEditingProfileStatic].Start, _lstStaticProfiles[_iEditingProfileStatic].End, CurrentBars[0], out dHigh, out dLow);
                    _lstStaticProfiles[_iEditingProfileStatic].High = dHigh;
                    _lstStaticProfiles[_iEditingProfileStatic].Low = dLow;
                    ChartControl.InvalidateVisual();
                    e.Handled = true;
                }
                else
                {
                    if (_lstStaticProfiles[_iEditingProfileStatic].IsLeftAdjusted)
                        _lstStaticProfiles[_iEditingProfileStatic].Start = bar;
                    else if (_lstStaticProfiles[_iEditingProfileStatic].IsRightAdjusted)
                        _lstStaticProfiles[_iEditingProfileStatic].End = bar;
                    else if (_lstStaticProfiles[_iEditingProfileStatic].IsCenterAdjusted)
                    {
                        int iLeft, iRight;
                        _lstStaticProfiles[_iEditingProfileStatic].GetDeviation(bar.No, out iLeft, out iRight);
                        iRight = Math.Max(1, Math.Min(iRight, CurrentBars[0]));
                        iLeft = Math.Max(1, Math.Min(iLeft, CurrentBars[0]));
                        BarLocation leftBar = new BarLocation() { StartTime = _ChartControl.GetTimeBySlotIndex(iLeft - 1), EndTime = _ChartControl.GetTimeBySlotIndex(iLeft), No = iLeft };
                        BarLocation rightBar = new BarLocation() { StartTime = _ChartControl.GetTimeBySlotIndex(iRight - 1), EndTime = _ChartControl.GetTimeBySlotIndex(iRight), No = iRight };
                        _lstStaticProfiles[_iEditingProfileStatic].End = rightBar;
                        _lstStaticProfiles[_iEditingProfileStatic].Start = leftBar;
                    }
					lock(_dicAllBars)
						_lstStaticProfiles[_iEditingProfileStatic].UpdateProfile(_dicAllBars, CurrentBars[0], Instrument);
                    _iEditingProfileStatic = -1;
                    ChartControl.InvalidateVisual();
                    e.Handled = true;
                }
            }

            #endregion

            #region Editing RealTime Profile
            if (_iEditingProfileRealTime >= 0)
            {
                double dBarNumber = GetBarClicked(eX);
                BarLocation bar = new BarLocation() { StartTime = _ChartControl.GetTimeBySlotIndex(dBarNumber), EndTime = _ChartControl.GetTimeBySlotIndex(dBarNumber), No = (int)Math.Floor(dBarNumber) };
                if (e.LeftButton == MouseButtonState.Pressed)
                {
                    e.MouseDevice.SetCursor(Cursors.SizeWE);
                    if (_lstRealTimeProfiles[_iEditingProfileRealTime].IsLeftAdjusted)
                        _lstRealTimeProfiles[_iEditingProfileRealTime].Start = bar;
                    double dHigh, dLow;
					lock(_dicAllBars)
						GetHighLow(_dicAllBars, _lstRealTimeProfiles[_iEditingProfileRealTime].Start, _lstRealTimeProfiles[_iEditingProfileRealTime].End, CurrentBars[0], out dHigh, out dLow);
                    _lstRealTimeProfiles[_iEditingProfileRealTime].High = dHigh;
                    _lstRealTimeProfiles[_iEditingProfileRealTime].Low = dLow;
                    ChartControl.InvalidateVisual();
                    e.Handled = true;
                }
                else
                {
                    if (_lstRealTimeProfiles[_iEditingProfileRealTime].IsLeftAdjusted)
                        _lstRealTimeProfiles[_iEditingProfileRealTime].Start = bar;
					lock(_dicAllBars)
						_lstRealTimeProfiles[_iEditingProfileRealTime].UpdateProfile(_dicAllBars, CurrentBars[0], Instrument);
                    _iEditingProfileRealTime = -1;
                    ChartControl.InvalidateVisual();
                    e.Handled = true;
                }
            }

            #endregion
        }
        #endregion

        #region Down
        private void Chart_MouseDown(object sender, MouseEventArgs e)
		{
			//plans
			float eX = ChartingExtensions.ConvertToHorizontalPixels(e.GetPosition(ChartPanel as IInputElement).X, ChartControl.PresentationSource);
			float eY = ChartingExtensions.ConvertToVerticalPixels(e.GetPosition(ChartPanel as IInputElement).Y, ChartControl.PresentationSource);

			#region Building Real Time Profile
			if (_bProfileOnRealTime)
			{
				if (e.LeftButton == MouseButtonState.Pressed)
				{
					double dBarNumber = GetBarClicked(eX);
					BarLocation bar = new BarLocation() { StartTime = _ChartControl.GetTimeBySlotIndex(dBarNumber), EndTime = _ChartControl.GetTimeBySlotIndex(dBarNumber), No = (int)Math.Floor(dBarNumber) };
					if (_BuildingProfileRealTime == null)
					{
						BarLocation endBar = new BarLocation() { StartTime = _ChartControl.GetTimeBySlotIndex(CurrentBars[0]), EndTime = _ChartControl.GetTimeBySlotIndex(CurrentBars[0]), No = CurrentBars[0] };
						_BuildingProfileRealTime = new Profile() { Start = bar, End = endBar, High = R2T(BarsArray[0].GetHigh(bar.No)), Low = R2T(BarsArray[0].GetLow(bar.No)) };
						_BuildingProfileRealTime.Initialize(bar, TicksPerLevel * TickSize, ValueAreaLevelsPerStep, _VWAPSettings, _CWAPSettings, _RealTimeProfileSettings);
					}
					else
						_BuildingProfileRealTime.Start = bar;
					double dHigh, dLow;
					lock(_dicAllBars)
						GetHighLow(_dicAllBars, _BuildingProfileRealTime.Start, _BuildingProfileRealTime.End, CurrentBars[0], out dHigh, out dLow);
					_BuildingProfileRealTime.High = dHigh;
					_BuildingProfileRealTime.Low = dLow;
                    lock (_dicAllBars)
                        _BuildingProfileRealTime.UpdateProfile(_dicAllBars, CurrentBars[0], Instrument);
					_lstRealTimeProfiles.Add(_BuildingProfileRealTime.Clone() as Profile);

					_BuildingProfileRealTime = null;
					_bProfileOnRealTime = false;

					ChartControl.InvalidateVisual();
					e.Handled = true;
				}
                else if (e.RightButton == MouseButtonState.Pressed)
                {
                    if (_BuildingProfileRealTime != null)
                        _BuildingProfileRealTime = null;
                    _bProfileOnRealTime = false;
                    ChartControl.InvalidateVisual();
                    e.Handled = true;
                }
            }
			#endregion

			#region Building Static Profile
			if (_bProfileOnStatic || _bProfileOnStaticMultiple)
			{
				if (e.LeftButton == MouseButtonState.Pressed)
				{
                    int dBarNumber = GetBarClicked(eX);
                    BarLocation bar = new BarLocation() { StartTime = _ChartControl.GetTimeBySlotIndex(dBarNumber), EndTime = _ChartControl.GetTimeBySlotIndex(dBarNumber), No = dBarNumber };
                    if (_BuildingProfileStatic == null)
					{
						_BuildingProfileStatic = new Profile() { Start = bar, End = bar, High = R2T(BarsArray[0].GetHigh(bar.No)), Low = R2T(BarsArray[0].GetLow(bar.No)) };
						_BuildingProfileStatic.Initialize(bar, TicksPerLevel * TickSize, ValueAreaLevelsPerStep, _VWAPSettings, _CWAPSettings, _HistoricalProfileSettings);
					}
					else
					{
						_BuildingProfileStatic.End = bar;

                        lock (_dicAllBars)
                            _BuildingProfileStatic.UpdateProfile(_dicAllBars, CurrentBars[0], Instrument);

						_lstStaticProfiles.Add(_BuildingProfileStatic.Clone() as Profile);

						_BuildingProfileStatic = null;
						_bProfileOnStatic = false;
					}
					ChartControl.InvalidateVisual();
					e.Handled = true;
				}
				else if (e.RightButton == MouseButtonState.Pressed)
				{
					if (_BuildingProfileStatic != null)
						_BuildingProfileStatic = null;
					_bProfileOnStatic = false;
					_bProfileOnStaticMultiple = false;
					ChartControl.InvalidateVisual();
					e.Handled = true;
				}
			}
			#endregion

			if (e.LeftButton != MouseButtonState.Pressed)
				return;

            #region Check Inside Static
            if (_lstStaticProfiles.Count > 0 && _iEditingProfileStatic == -1)
            {
                for (int i = 0; i < _lstStaticProfiles.Count; i++)
                {
                    bool bLeft, bCenter, bRight;
                    _lstStaticProfiles[i].IsSelected = _lstStaticProfiles[i].CheckInside(eX, eY, e.LeftButton == MouseButtonState.Pressed, out bLeft, out bCenter, out bRight);
                }
            }
            #endregion

            #region Check Inside RealTime
            if (_lstRealTimeProfiles.Count > 0 && _iEditingProfileRealTime == -1)
            {
                for (int i = 0; i < _lstRealTimeProfiles.Count; i++)
                {
                    bool bLeft, bCenter, bRight;
                    _lstRealTimeProfiles[i].IsSelected = _lstRealTimeProfiles[i].CheckInside(eX, eY, e.LeftButton == MouseButtonState.Pressed, out bLeft, out bCenter, out bRight);
                }
            }
            #endregion

        }
        #endregion

        #region Key Down
        public void ChartControl_PreviewKeyDown(object sender, KeyEventArgs e)
		{
			if (!tabSelected())
				return;
			#region DEL
			if (e.Key == Key.Delete && !IsAnyDrawingToolSelected())
			{
                if (_bProfileOnRealTime)
                {
                    if (_BuildingProfileRealTime != null)
                        _BuildingProfileRealTime = null;
                    _bProfileOnRealTime = false;
                    ChartControl.InvalidateVisual();
                    e.Handled = true;
                }
                else if (_bProfileOnStatic || _bProfileOnStaticMultiple)
                {
                    if (_BuildingProfileStatic != null)
                        _BuildingProfileStatic = null;
                    _bProfileOnStatic = false;
                    _bProfileOnStaticMultiple = false;
                    ChartControl.InvalidateVisual();
                    e.Handled = true;
				}
				else
				{
					if (_lstStaticProfiles.Count > 0 && _iEditingProfileStatic == -1)
					{
						for (int i = 0; i < _lstStaticProfiles.Count; i++)
						{
							if (_lstStaticProfiles[i].IsHovered || _lstStaticProfiles[i].IsSelected)
							{
								_lstStaticProfiles.RemoveAt(i);
								e.Handled = true;
								ChartControl.InvalidateVisual();
								break;
							}
						}
					}
					if (!e.Handled && _lstRealTimeProfiles.Count > 0 && _iEditingProfileRealTime == -1)
					{
						for (int i = 0; i < _lstRealTimeProfiles.Count; i++)
						{
							if (_lstRealTimeProfiles[i].IsHovered || _lstRealTimeProfiles[i].IsSelected)
							{
								_lstRealTimeProfiles.RemoveAt(i);
								e.Handled = true;
								ChartControl.InvalidateVisual();
								break;
							}
						}
					}
				}
                //e.Handled = true;
            }
            #endregion
        }
		#endregion

		#endregion

        //
        #region Numeric Up Down Text Changed
        private void NumericUpDownTextChanged(object sender, EventArgs e)
        {
            TextBox txtSender = sender as TextBox;
            if (txtSender.Text.Length > 0)
            {
                float result;
                bool isNumeric = float.TryParse(txtSender.Text, out result);

                if (!isNumeric)
                {
                    txtSender.Text = "1";
                    txtSender.Select(txtSender.Text.Length, 0);
                }
                if (_dicTextBoxes.ContainsKey(txtSender.Name))
                {
                    string name = txtSender.Name.Remove(txtSender.Name.Length - uID.Length);

                    switch (name)//.Substring(0, txtSender.Name.Length - uID.Length))
                    {
                        case "btStartTimeHrs": StartTimeHrs = Convert.ToInt32(txtSender.Text); _GeneralSettings.CompositeStartTime = new TimeSpan(StartTimeHrs, StartTimeMin, 0); break;
                        case "btStartTimeMin": StartTimeMin = Convert.ToInt32(txtSender.Text); _GeneralSettings.CompositeStartTime = new TimeSpan(StartTimeHrs, StartTimeMin, 0); break;
                        case "btIntervalMin": IntervalMin = Convert.ToInt32(txtSender.Text); _GeneralSettings.CompositeResetInterval = new TimeSpan(IntervalMin * TimeSpan.TicksPerMinute); break;
                    }
                    InformUserAboutRecalculation();
                }
            }
        }
        #endregion

        #region Combo Box Up Down Button Click
        private void UpDownButton_Click(object sender, RoutedEventArgs e)
        {
            Button cmd = sender as Button;
            if (cmd != null && _dicButtons.ContainsKey(cmd.Name))
            {
                string name = cmd.Name.Remove(cmd.Name.Length - uID.Length);
                switch (name)
                {
                    case "btStartTimeHrs_Up": _dicTextBoxes["btStartTimeHrs" + uID].Text = (Math.Min(23, Convert.ToInt32(_dicTextBoxes["btStartTimeHrs" + uID].Text) + 1)).ToString(); break;
                    case "btStartTimeHrs_Dn": _dicTextBoxes["btStartTimeHrs" + uID].Text = (Math.Max(0, Convert.ToInt32(_dicTextBoxes["btStartTimeHrs" + uID].Text) - 1)).ToString(); break;
                    case "btStartTimeMin_Up": _dicTextBoxes["btStartTimeMin" + uID].Text = (Math.Min(59, Convert.ToInt32(_dicTextBoxes["btStartTimeMin" + uID].Text) + 1)).ToString(); break;
                    case "btStartTimeMin_Dn": _dicTextBoxes["btStartTimeMin" + uID].Text = (Math.Max(0, Convert.ToInt32(_dicTextBoxes["btStartTimeMin" + uID].Text) - 1)).ToString(); break;
                    case "btIntervalMin_Up": _dicTextBoxes["btIntervalMin" + uID].Text = (Math.Min(1440, Convert.ToInt32(_dicTextBoxes["btIntervalMin" + uID].Text) + 1)).ToString(); break;
                    case "btIntervalMin_Dn": _dicTextBoxes["btIntervalMin" + uID].Text = (Math.Max(0, Convert.ToInt32(_dicTextBoxes["btIntervalMin" + uID].Text) - 1)).ToString(); break;
                }
                InformUserAboutRecalculation();
            }
        }
        #endregion

        //

        #region -- DoubleEditKeyPress -- 
        //Function taken from NS VM Lean and needs to be updated to standards after christmas
        private void menuTxtbox_KeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true;
            TextBox txtSender = sender as TextBox;

            int keyVal = (int)e.Key;
            int value = -1;
            if (keyVal >= (int)Key.D0 && keyVal <= (int)Key.D9) value = keyVal - (int)Key.D0;
            else if (keyVal >= (int)Key.NumPad0 && keyVal <= (int)Key.NumPad9) value = keyVal - (int)Key.NumPad0;

            bool isNumeric = (e.Key >= Key.D0 && e.Key <= Key.D9) || (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9);

            if (isNumeric || e.Key == Key.Back || (e.Key == Key.Decimal && _dicTextBoxes.ContainsKey(txtSender.Name)))
            {
                string newText = value != -1 ? value.ToString() : e.Key == Key.Decimal ? System.Globalization.CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator : "";
                int tbPosition = txtSender.SelectionStart;
                txtSender.Text = txtSender.SelectedText == "" ? txtSender.Text.Insert(tbPosition, newText) : txtSender.Text.Replace(txtSender.SelectedText, newText);
                txtSender.Select(tbPosition + 1, 0);
            }
        }
        #endregion

        #endregion

        #region Default NT Functions

//		SharpDX.Direct2D1.Brush br = null;
//		public override void OnRenderTargetChanged()
//		{
//			if(br!=null && !br.IsDisposed) br.Dispose(); br=null;
//			if(RenderTarget==null) return;
//			br = Brushes.Yellow.ToDxBrush(RenderTarget);
//		}
        #region On Render
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            if (Bars == null || chartControl == null || chartScale == null || this == null || RenderTarget == null
#if DoLicense
                || !ValidLicense
#endif
                ) return;

            if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1)
                return;

            if (!IsOverlay)
                IsOverlay = true;

			_ChartControl = chartControl;
			_ChartScale = chartScale;
			PanelWidth = ChartPanel.W;

			//base.OnRender(chartControl, chartScale);
//if(IsDebug){
//	Print(ChartPanel.W+"  "+chartControl.GetXByBarIndex(ChartBars, ChartBars.ToIndex)+"   actualwidth("+chartScale.PanelIndex+"): "+chartControl.ChartPanels[chartScale.PanelIndex].ActualWidth);
//	var vect = new SharpDX.Vector2(
//		chartControl.GetXByBarIndex(ChartBars, ChartBars.), 100f);
//	RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(vect, 10f, 4f), br);
//}

			try
			{
				if (_BuildingProfileStatic != null)
					_BuildingProfileStatic.DrawJustBox(RenderTarget, chartControl, chartScale, Building);
				if (_lstRealTimeProfiles.Count > 0)
				{
					for (int i = _lstRealTimeProfiles.Count - 1; i >= 0; i--)
						_lstRealTimeProfiles[i].Draw(RenderTarget, chartControl, chartScale, Instrument, ChartBars, Building, _ClusterSettings);
				}
				if (_lstStaticProfiles.Count > 0)
				{
					for (int i = _lstStaticProfiles.Count - 1; i >= 0; i--)
						_lstStaticProfiles[i].Draw(RenderTarget, chartControl, chartScale, Instrument, ChartBars, Building, _ClusterSettings);
				}
				if (_lstCompositeProfiles.Count > 0)
				{
					for (int i = _lstCompositeProfiles.Count - 1; i >= 0; i--)
						_lstCompositeProfiles[i].Draw(RenderTarget, chartControl, chartScale, Instrument, ChartBars, Building, _ClusterSettings);
				}
				lock (_dicAllBars)
				{
					if (_ClusterSettings.Show == ClusterDisplay.AllBars && _dicAllBars.Count > 0)
					{
						int iMin = _dicAllBars.Keys.Min(x => x);
						int iStart = Math.Max(iMin, (int)Math.Floor(chartControl.GetSlotIndexByX(-1)));
						int iEnd = Math.Min(CurrentBars[0], ChartBars.ToIndex);//(int)Math.Floor(chartControl.GetSlotIndexByX((int)chartControl.ActualWidth)));
						for (int i = iStart; i <= iEnd; i++)
						{
							_dicAllBars[i].Draw(RenderTarget, chartControl, chartScale, _ClusterSettings);
						}
					}
				}
			}
			catch (Exception ex)
			{
				Print(ex.ToString());
			}
		}
		#endregion

		#endregion

		#region Functions

		#region Is Any Drawing Tool Selected
		private bool IsAnyDrawingToolSelected()
		{
			if (ChartPanel.ChartObjects.Count > 0)
			{
				for (int i = 0; i < ChartPanel.ChartObjects.Count; i++)
				{
					if (ChartPanel.ChartObjects[i].IsSelected)
						return true;
				}
			}
			return false;
		}
		#endregion

		#region Get Bar Clicked
		private int GetBarClicked(float eX)
		{
			int dBarNumber = (int)_ChartControl.GetSlotIndexByX((int)(eX));
			float fDistanceBetweenBars = _ChartControl.GetXByBarIndex(ChartBars, dBarNumber) - _ChartControl.GetXByBarIndex(ChartBars, dBarNumber - 1);
			return (int)_ChartControl.GetSlotIndexByX((int)(eX + fDistanceBetweenBars * 0.5));
		}
		#endregion

		#region Inform User About Recalculation
		private void InformUserAboutRecalculation()
		{
			string name = "btRecalculate_General";// string.Format(, uID);
			_dicMenuItems[name].Background = Brushes.Yellow;
			_dicMenuItems[name].FontWeight = FontWeights.Bold;
			_dicMenuItems[name].FontStyle = FontStyles.Italic;
		}
		#endregion

		#region Invoke Action
		private void CCInvokeAction(Action p)
		{
			if (ChartControl.Dispatcher.CheckAccess())
			{
				p();
			}
			else
			{
				ChartControl.Dispatcher.InvokeAsync(p);
			}
		}
		#endregion

		#region Invoke Action
		private void GeneralInvokeAction(Action p)
		{
			if (Dispatcher.CheckAccess())
			{
				p();
			}
			else
			{
				ChartControl.Dispatcher.InvokeAsync(p);
			}
		}
        #endregion

        #region Clone Entire Indicator to Preserve Profiles
        public override object Clone()
        {
            ARC_AnchoredVolume indiAnchoredVolume = base.Clone() as ARC_AnchoredVolume;

            if (indiAnchoredVolume != null)
            {
				//Here we pass the data to the new instance of the indicator
				indiAnchoredVolume.SetPropsToCheckReset(_sPreviousIntrument, _sPreviousBars, _sChartType, _iChartInterval, _iTicksPerLevel, _iClusterTicks);
                if (!string.IsNullOrEmpty(_sPreviousIntrument) && !string.IsNullOrWhiteSpace(_sPreviousIntrument) &&
                    !string.IsNullOrEmpty(_sPreviousBars) && !string.IsNullOrWhiteSpace(_sPreviousBars))
				{
					indiAnchoredVolume.SetProfileStatic(_lstStaticProfiles);
					indiAnchoredVolume.SetProfileDynamic(_lstRealTimeProfiles);
					lock(_dicAllBars)
						indiAnchoredVolume.SetBars(_dicAllBars);
                }
			}
			//indiAnchoredVolume.

			return indiAnchoredVolume;
        }
		#endregion

		#region Clone Helper

		#region Set Profile Dynamic
		public void SetProfileDynamic(object obj)
		{
			if (obj is List<Profile>)
			{
				List<Profile> profile = obj as List<Profile>;
				_lstRealTimeProfiles = new List<Profile>();
				foreach (Profile p in profile)
					_lstRealTimeProfiles.Add(p.ShallowClone() as Profile);
			}
		}
		#endregion

		#region Set Profile Static
		public void SetProfileStatic(object obj)
		{
			if (obj is List<Profile>)
			{
				List<Profile> profile = obj as List<Profile>;
				foreach (Profile p in profile)
					_lstStaticProfiles.Add(p.ShallowClone() as Profile);
			}
		}
		#endregion

		#region Set Bars For Cache
		public void SetBars(object obj)
		{
			if (obj is ConcurrentDictionary<int, BarInfo>)
			{
                ConcurrentDictionary<int, BarInfo> bars = obj as ConcurrentDictionary<int, BarInfo>;
				foreach (KeyValuePair<int, BarInfo> b in bars)
                    _dicAllBars.TryAdd(b.Key, b.Value.Clone() as BarInfo);
			}
		}
		#endregion

		#region Set Properties To Check Reset
		private void SetPropsToCheckReset(string previousIntrument, string previousBars, string ChartType, int ChartInterval, int TicksPerLevel, int ClusterTicks)
		{
			_sPreviousIntrument = previousIntrument;
			_sPreviousBars = previousBars;
			_sChartType = ChartType;
			_iChartInterval = ChartInterval;
			_iTicksPerLevel = TicksPerLevel;
			_iClusterTicks = ClusterTicks;
        }
		#endregion

		#endregion

		#region Round To Tick
		private double R2T(double value)
		{
			return Instrument.MasterInstrument.RoundToTickSize(value);
		}
        #endregion

        #region Get High Low
        private void GetHighLow(ConcurrentDictionary<int, BarInfo> bars, BarLocation start, BarLocation end, int currentBar, out double high, out double low)
        {
            high = double.MinValue;
            low = double.MaxValue;
            int iEndBar = end.No > currentBar ? currentBar : end.No;
            lock (bars)
            {
                if (bars.ContainsKey(start.No) && bars.ContainsKey(iEndBar))
                {
                    int iSteps = iEndBar - start.No;
                    for (int i = 0; i <= iSteps; i++)
                    {
                        high = Math.Max(high, bars[start.No + i].BarDetails.High);
                        low = Math.Min(low, bars[start.No + i].BarDetails.Low);
                    }
                }
            }
        }
        #endregion

        #endregion

        #region Comp Type ComboMenu
        internal class ESTCT : StringConverter
		{
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
			public override System.ComponentModel.TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
			{
				return new StandardValuesCollection(new String[] { "Time", "Day", "Week", "Month" });
			}
		}
		#endregion

		#region Reset
		private bool Reset(DateTime time0, DateTime time1)
		{
			if (CompositeType == "Month")
			{
				if (time1.Month != time0.Month)
					_bNewMonth = true;
                return _bNewMonth && BarsArray[0].IsFirstBarOfSession;
            }
			if (CompositeType == "Week")
			{
				if (time1.DayOfWeek > time0.DayOfWeek)
					_bNewWeek = true;
				return _bNewWeek && BarsArray[0].IsFirstBarOfSession;
    //            System.Globalization.Calendar cal = new System.Globalization.CultureInfo("en-US").Calendar;
    //            int week0 = cal.GetWeekOfYear(time0, System.Globalization.CalendarWeekRule.FirstDay, DayOfWeek.Monday);
    //int week1 = cal.GetWeekOfYear(time1, System.Globalization.CalendarWeekRule.FirstDay, DayOfWeek.Monday);
    //return week0 != week1;
            }
			if (CompositeType == "Day")
				return BarsArray[0].IsFirstBarOfSession;
			if (time0.TimeOfDay.CompareTo(_tsDayResetTime) >= 0 && time1.TimeOfDay.CompareTo(_tsDayResetTime) < 0)
			{
                _dtResetTime = time0.Date.Add(_tsDayResetTime);
				return true;
			}
			else if (BarsArray[0].IsFirstBarOfSession)
			{
                _dtResetTime = Times[0][0];
				return true;
			}
			else if (time0.CompareTo(_dtResetTime) >= 0 && time1.CompareTo(_dtResetTime) < 0)
				return true;
			//this last one is a safety measure so that we make sure that we reset the times after the weekend
			else if (time0.CompareTo(_dtResetTime) >= 0)
			{
                _dtResetTime = Times[0][0];
                return true;
			}
			return false;
		}
		#endregion

		#region Properties

		#region VWAP Deviation
		internal class VWAPDT : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override System.ComponentModel.TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "None", "Deviation 1", "Deviation 2", "Deviation 3" });
            }
        }
        #endregion

        #region Cluster Display
        internal class CD : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override System.ComponentModel.TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "None", "All Bars", "Only In Profile" });
            }
        }
        #endregion

        #region Chart Type
        internal class CHRTT : StringConverter
        {
            public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
            public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }
            public override System.ComponentModel.TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
            {
                return new StandardValuesCollection(new String[] { "Tick", "Second", "Minute" });
            }
        }
        #endregion

        #region Override Display Name
        public override string DisplayName { get { return _sThisName; } }
        #endregion

        #endregion

        #region Enums

        #region In Range
        public enum EInRange
        {
            Full,
            Partial,
            None
        }
        #endregion

        #region VWAP Deviation
        public enum VWAPDeviation
        {
            None,
            Deviation1,
            Deviation2,
            Deviation3,
        }
        #endregion

        #region Cluster Display
        public enum ClusterDisplay
        {
            None,
            AllBars,
            OnlyInProfile
        }
        #endregion

        #endregion

        #endregion

        #region Properties

        #region 
        [Browsable(false)]
        [XmlIgnore()]
        public string PreviousIntrument { get; set; }

        [Browsable(false)]
        [XmlIgnore()]
        public string PreviousBars { get; set; }
		#endregion

		#region Data
		[NinjaScriptProperty]
		[Display(Name = "Chart Type", Description = "", Order = 10, GroupName = "Data")]
		[TypeConverter(typeof(CHRTT))]
		public string ChartType { get; set; }

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Name = "Chart Interval", Description = "", Order = 20, GroupName = "Data")]
		public int ChartInterval { get; set; }

        [Range(1, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Ticks Per Level", Description = "", Order = 30, GroupName = "Data")]
        public int TicksPerLevel { get; set; }

        [Range(1, 2), NinjaScriptProperty]
        [Display(Name = "Value Area Levels Per Step", Description = "", Order = 40, GroupName = "Data")]
        public int ValueAreaLevelsPerStep { get; set; }
        #endregion

        #region Composite Profile

        [NinjaScriptProperty]
        [Display(Name = "Show Composite", Description = "", Order = 0, GroupName = "Composite Profile Settings")]
        public bool ShowComposite { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Current Profile", Description = "", Order = 1, GroupName = "Composite Profile Settings")]
        public bool ShowCurrentProfile { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show Historical", Description = "", Order = 2, GroupName = "Composite Profile Settings")]
		public bool ShowHistorical { get; set; }

		[NinjaScriptProperty]
        [Display(Name = "Period Type", Description = "", Order = 6, GroupName = "Composite Profile Settings")]
        [TypeConverter(typeof(ESTCT))]
        [RefreshProperties(RefreshProperties.All)]
        public string CompositeType { get; set; }

        [Range(0, 23), NinjaScriptProperty]
        [Display(Name = "Start (Hrs.)", Description = "", Order = 7, GroupName = "Composite Profile Settings")]
        public int StartTimeHrs { get; set; }

        [Range(0, 59), NinjaScriptProperty]
        [Display(Name = "Start (Min.)", Description = "", Order = 8, GroupName = "Composite Profile Settings")]
        public int StartTimeMin { get; set; }

        [Range(1, 1440), NinjaScriptProperty]
        [Display(Name = "Interval (Min.)", Description = "", Order = 9, GroupName = "Composite Profile Settings")]
        public int IntervalMin { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Value Area %", Description = "", Order = 10, GroupName = "Composite Profile Settings")]
        public int VAPercentComposite { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Value Area Opacity", Description = "", Order = 15, GroupName = "Composite Profile Settings")]
        public int VAOpacComposite { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show VAL", Description = "", Order = 20, GroupName = "Composite Profile Settings")]
        public bool ShowVALComposite { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show VAH", Description = "", Order = 30, GroupName = "Composite Profile Settings")]
        public bool ShowVAHComposite { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show POC", Description = "", Order = 40, GroupName = "Composite Profile Settings")]
        public bool ShowPOCComposite { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Profile", Description = "", Order = 50, GroupName = "Composite Profile Settings")]
        public bool ShowProfileComposite { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Extremes", Description = "", Order = 60, GroupName = "Composite Profile Settings")]
        public bool ShowExtremesComposite { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Text", Description = "", Order = 65, GroupName = "Composite Profile Settings")]
        public bool ShowTextComposite { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Normal Opacity", Description = "", Order = 70, GroupName = "Composite Profile Settings")]
        public int NormalOpacComposite { get; set; }

        [Range(0.0001, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Profile Width %", Description = "", Order = 80, GroupName = "Composite Profile Settings")]
        public double ProfilePercentComposite { get; set; }

        [Range(0.0001, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Profile Width % (Right Side)", Description = "", Order = 85, GroupName = "Composite Profile Settings")]
        public double ProfilePercentCompositeRightSide { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Profile Text Font", Description = "", Order = 90, GroupName = "Composite Profile Settings")]
        public SimpleFont TextHistProfileComposite { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Extremes", Description = "", Order = 100, GroupName = "Composite Profile Settings")]
        public Stroke ExtremesComposite { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "POC", Description = "", Order = 110, GroupName = "Composite Profile Settings")]
        public Stroke POCComposite { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "VAH", Description = "", Order = 120, GroupName = "Composite Profile Settings")]
        public Stroke VAHComposite { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "VAL", Description = "", Order = 130, GroupName = "Composite Profile Settings")]
        public Stroke VALComposite { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Profile", Description = "", Order = 140, GroupName = "Composite Profile Settings")]
        public Stroke ProfileComposite { get; set; }

        #endregion

        #region Static Profile
        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Value Area %", Description = "", Order = 5, GroupName = "Static Profile Settings")]
        public int VAPercentStatic { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Value Area Opacity", Description = "", Order = 10, GroupName = "Static Profile Settings")]
        public int VAOpacHisto { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show VAL", Description = "", Order = 20, GroupName = "Static Profile Settings")]
        public bool ShowVALHisto { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show VAH", Description = "", Order = 30, GroupName = "Static Profile Settings")]
        public bool ShowVAHHisto { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show POC", Description = "", Order = 40, GroupName = "Static Profile Settings")]
        public bool ShowPOCHisto { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Profile", Description = "", Order = 50, GroupName = "Static Profile Settings")]
        public bool ShowProfileHisto { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Extremes", Description = "", Order = 60, GroupName = "Static Profile Settings")]
        public bool ShowExtremesHisto { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show Text", Description = "", Order = 65, GroupName = "Static Profile Settings")]
		public bool ShowTextStatic { get; set; }

		[Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Normal Opacity", Description = "", Order = 70, GroupName = "Static Profile Settings")]
        public int NormalOpacHisto { get; set; }

        [Range(0.0001, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Profile Width %", Description = "", Order = 80, GroupName = "Static Profile Settings")]
        public double ProfilePercentHisto { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Profile Text Font", Description = "", Order = 90, GroupName = "Static Profile Settings")]
        public SimpleFont TextHistProfileHisto { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Building Profile", Description = "", Order = 100, GroupName = "Static Profile Settings")]
        public Stroke Building { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Extremes", Description = "", Order = 105, GroupName = "Static Profile Settings")]
		public Stroke ExtremesHisto { get; set; }

		[NinjaScriptProperty]
        [Display(Name = "POC", Description = "", Order = 110, GroupName = "Static Profile Settings")]
        public Stroke POCHisto { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "VAH", Description = "", Order = 120, GroupName = "Static Profile Settings")]
        public Stroke VAHHisto { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "VAL", Description = "", Order = 130, GroupName = "Static Profile Settings")]
        public Stroke VALHisto { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Profile", Description = "", Order = 140, GroupName = "Static Profile Settings")]
        public Stroke ProfileHisto { get; set; }

        #endregion

        #region Real Time Profile
        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Value Area %", Description = "", Order = 5, GroupName = "Real Time Profile Settings")]
        public int VAPercentRealTime { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Value Area Opacity", Description = "", Order = 10, GroupName = "Real Time Profile Settings")]
        public int VAOpacCurrentBar { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Draw Profile On Left", Description = "", Order = 20, GroupName = "Real Time Profile Settings")]
        public bool DrawOnLeft { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show VAL", Description = "", Order = 25, GroupName = "Real Time Profile Settings")]
        public bool ShowVALCurrentBar { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show VAH", Description = "", Order = 30, GroupName = "Real Time Profile Settings")]
        public bool ShowVAHCurrentBar { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show POC", Description = "", Order = 40, GroupName = "Real Time Profile Settings")]
        public bool ShowPOCCurrentBar { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Profile", Description = "", Order = 50, GroupName = "Real Time Profile Settings")]
        public bool ShowProfileCurrentBar { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Extremes", Description = "", Order = 60, GroupName = "Real Time Profile Settings")]
        public bool ShowExtremesCurrentBar { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show Text", Description = "", Order = 65, GroupName = "Real Time Profile Settings")]
		public bool ShowTextRealTime { get; set; }

		[Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Normal Opacity", Description = "", Order = 70, GroupName = "Real Time Profile Settings")]
        public int NormalOpacCurrentBar { get; set; }

        [Range(0.0001, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Profile Width %", Description = "", Order = 80, GroupName = "Real Time Profile Settings")]
        public double ProfilePercentCurrentBar { get; set; }

        [Range(0.0001, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Profile Width % (Right Side)", Description = "", Order = 85, GroupName = "Real Time Profile Settings")]
        public double ProfilePercentCurrentBarRightSide { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Profile Text Font", Description = "", Order = 90, GroupName = "Real Time Profile Settings")]
        public SimpleFont TextHistProfileCurrentBar { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Extremes", Description = "", Order = 100, GroupName = "Real Time Profile Settings")]
        public Stroke ExtremesCurrentBar { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "POC", Description = "", Order = 110, GroupName = "Real Time Profile Settings")]
        public Stroke POCCurrentBar { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "VAH", Description = "", Order = 120, GroupName = "Real Time Profile Settings")]
        public Stroke VAHCurrentBar { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "VAL", Description = "", Order = 130, GroupName = "Real Time Profile Settings")]
        public Stroke VALCurrentBar { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Profile", Description = "", Order = 140, GroupName = "Real Time Profile Settings")]
        public Stroke ProfileCurrentBar { get; set; }

        #endregion

        #region VWAP

        [NinjaScriptProperty]
        [Display(Name = "Show VWAP", Description = "", Order = 10, GroupName = "VWAP Settings")]
        public bool ShowVWAP { get; set; }

        [Range(0.0001, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Deviation 1", Description = "", Order = 20, GroupName = "VWAP Settings")]
        public double Deviation1VWAP { get; set; }

        [Range(0.0001, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Deviation 2", Description = "", Order = 30, GroupName = "VWAP Settings")]
        public double Deviation2VWAP { get; set; }

        [Range(0.0001, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Deviation 3", Description = "", Order = 40, GroupName = "VWAP Settings")]
        public double Deviation3VWAP { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "VWAP Deviation", Description = "", Order = 50, GroupName = "VWAP Settings")]
        [TypeConverter(typeof(VWAPDT))]
        public string VWAPDeviationVWAP { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Opacity", Description = "", Order = 60, GroupName = "VWAP Settings")]
        public int OpacityVWAP { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "VWAP", Description = "", Order = 70, GroupName = "VWAP Settings")]
        public Stroke VwapVWAP { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Above", Description = "", Order = 80, GroupName = "VWAP Settings")]
        public Stroke AboveVWAP { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Below", Description = "", Order = 90, GroupName = "VWAP Settings")]
        public Stroke BelowVWAP { get; set; }

        [XmlIgnore]
        [Display(Name = "Inner Zone Color", Description = "", Order = 100, GroupName = "VWAP Settings")]
        public Brush InnerZoneVWAP { get; set; }
        [Browsable(false)]
        public string InnerZoneVWAP_ { get { return Serialize.BrushToString(InnerZoneVWAP); } set { InnerZoneVWAP = Serialize.StringToBrush(value); } }

        [XmlIgnore]
        [Display(Name = "Mid Zone Color", Description = "", Order = 110, GroupName = "VWAP Settings")]
        public Brush MidZoneVWAP { get; set; }
        [Browsable(false)]
        public string MidZoneVWAP_ { get { return Serialize.BrushToString(MidZoneVWAP); } set { MidZoneVWAP = Serialize.StringToBrush(value); } }

        [XmlIgnore]
        [Display(Name = "Outer Zone Color", Description = "", Order = 120, GroupName = "VWAP Settings")]
        public Brush OuterZoneVWAP { get; set; }
        [Browsable(false)]
        public string OuterZoneVWAP_ { get { return Serialize.BrushToString(OuterZoneVWAP); } set { OuterZoneVWAP = Serialize.StringToBrush(value); } }

        [NinjaScriptProperty]
        [Display(Name = "Show Shading", Description = "", Order = 130, GroupName = "VWAP Settings")]
        public bool ShowShadingVWAP { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Draw Last Value", Description = "", Order = 150, GroupName = "VWAP Settings")]
        public bool DrawLastValueVWAP { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Text", Description = "", Order = 160, GroupName = "VWAP Settings")]
        public bool ShowTextVWAP { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "VWAP Text Font", Description = "", Order = 170, GroupName = "VWAP Settings")]
        public SimpleFont TextFontVWAP { get; set; }

        #endregion

        #region CWAP

        [NinjaScriptProperty]
        [Display(Name = "Show CWAP", Description = "", Order = 10, GroupName = "CWAP Settings")]
        public bool ShowCWAP { get; set; }

        [Range(0.0001, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Deviation 1", Description = "", Order = 20, GroupName = "CWAP Settings")]
        public double Deviation1CWAP { get; set; }

        [Range(0.0001, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Deviation 2", Description = "", Order = 30, GroupName = "CWAP Settings")]
        public double Deviation2CWAP { get; set; }

        [Range(0.0001, double.MaxValue), NinjaScriptProperty]
        [Display(Name = "Deviation 3", Description = "", Order = 40, GroupName = "CWAP Settings")]
        public double Deviation3CWAP { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "CWAP Deviation", Description = "", Order = 50, GroupName = "CWAP Settings")]
        [TypeConverter(typeof(VWAPDT))]
        public string VWAPDeviationCWAP { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Opacity", Description = "", Order = 60, GroupName = "CWAP Settings")]
        public int OpacityCWAP { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "CWAP", Description = "", Order = 70, GroupName = "CWAP Settings")]
        public Stroke VwapCWAP { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Above", Description = "", Order = 80, GroupName = "CWAP Settings")]
        public Stroke AboveCWAP { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Below", Description = "", Order = 90, GroupName = "CWAP Settings")]
        public Stroke BelowCWAP { get; set; }

        [XmlIgnore]
        [Display(Name = "Inner Zone Color", Description = "", Order = 100, GroupName = "CWAP Settings")]
        public Brush InnerZoneCWAP { get; set; }
        [Browsable(false)]
        public string InnerZoneCWAP_ { get { return Serialize.BrushToString(InnerZoneCWAP); } set { InnerZoneCWAP = Serialize.StringToBrush(value); } }

        [XmlIgnore]
        [Display(Name = "Mid Zone Color", Description = "", Order = 110, GroupName = "CWAP Settings")]
        public Brush MidZoneCWAP { get; set; }
        [Browsable(false)]
        public string MidZoneCWAP_ { get { return Serialize.BrushToString(MidZoneCWAP); } set { MidZoneCWAP = Serialize.StringToBrush(value); } }

        [XmlIgnore]
        [Display(Name = "Outer Zone Color", Description = "", Order = 120, GroupName = "CWAP Settings")]
        public Brush OuterZoneCWAP { get; set; }
        [Browsable(false)]
        public string OuterZoneCWAP_ { get { return Serialize.BrushToString(OuterZoneCWAP); } set { OuterZoneCWAP = Serialize.StringToBrush(value); } }

        [NinjaScriptProperty]
        [Display(Name = "Show Shading", Description = "", Order = 130, GroupName = "CWAP Settings")]
        public bool ShowShadingCWAP { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Draw Last Value", Description = "", Order = 140, GroupName = "CWAP Settings")]
        public bool DrawLastValueCWAP { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Text", Description = "", Order = 150, GroupName = "CWAP Settings")]
        public bool ShowTextCWAP { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "CWAP Text Font", Description = "", Order = 160, GroupName = "CWAP Settings")]
        public SimpleFont TextFontCWAP { get; set; }

        #endregion

        #region Cluster 

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Cluster Ticks", Description = "", Order = 10, GroupName = "Cluster Settings")]
        public int ClusterTicks { get; set; }

        [Range(0, int.MaxValue), NinjaScriptProperty]
        [Display(Name = "Opacity", Description = "", Order = 20, GroupName = "Cluster Settings")]
        public int Opacity { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Border", Description = "", Order = 30, GroupName = "Cluster Settings")]
        public bool ShowBorder { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Shading", Description = "", Order = 40, GroupName = "Cluster Settings")]
        public bool ShowShading { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Cluster Color", Description = "", Order = 50, GroupName = "Cluster Settings")]
        public Stroke Stroke { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Cluster Display", Description = "", Order = 60, GroupName = "Cluster Settings")]
        [TypeConverter(typeof(CD))]
        public string Show { get; set; }

        #endregion

        #region Display Settings
        [NinjaScriptProperty]
		[Display(Name = "Button Text", Description = "", Order = 10, GroupName = "Display Settings")]
		public string ButtonText { get; set; }

        //[NinjaScriptProperty]
        //[Display(Name = "Show As Histogram", Description = "", Order = 20, GroupName = "Display Settings")]
        //public bool DisplayHistogram { get; set; }

        //[NinjaScriptProperty]
        //[Display(Name = "Extend Levels", Description = "", Order = 30, GroupName = "Display Settings")]
        //public bool ExtendLevels { get; set; }

        #endregion

        #region Indicator Version
        private const string VERSION = "v1.16 30.Sep.2024";
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }
        /// <summary>
        /// Updates:
        /// v1.11	Fixed UI button dissappears
        ///			Fixed OnRender error
        ///			Locked all dictionary references to make sure this indicator isn't causing Roy's hashtable error
        ///			Updated the zone wehre clients can move and resize the profiles
        ///			Edited the start bar to help make it more accurate
        ///	v1.12	Updated code to grab the bar that it is clicked on not from the middle of the bar onward only
        ///			Updated the way the Text Draws to give it a buffer of 10 pixels in width
        ///			Updated the code to only delete a profile if there is no chart object selected
        ///	v1.13	Changed Dictionary to ConcurrentDictionary to account for the hashtable error. (if the error still occurs it might be because of the load factor)
		///	V1.14   Fixed the UI 'Profile Composite (Settings)' - dropdown and up down 
		///	V1.15   Replaced ChartPanel.ActualWidth with ChartPanel.W - ActualWidth seems to be consistently less than ChartPanel.W
        /// </summary>
        #endregion

        #endregion

        #region Custom Property Manipulation
        private void ModifyProperties(PropertyDescriptorCollection col)
		{
			if(CompositeType != "Time")
			{
                col.Remove(col.Find("StartTimeHrs", true));
				col.Remove(col.Find("StartTimeMin", true));
				col.Remove(col.Find("IntervalMin", true));
			}
		}
		#endregion

		#region ICustomTypeDescriptor Members
		public PropertyDescriptorCollection GetProperties() { return TypeDescriptor.GetProperties(GetType()); }
		public object GetPropertyOwner(PropertyDescriptor pd) { return this; }
		public AttributeCollection GetAttributes() { return TypeDescriptor.GetAttributes(GetType()); }
		public string GetClassName() { return TypeDescriptor.GetClassName(GetType()); }
		public string GetComponentName() { return TypeDescriptor.GetComponentName(GetType()); }
		public TypeConverter GetConverter() { return TypeDescriptor.GetConverter(GetType()); }
		public EventDescriptor GetDefaultEvent() { return TypeDescriptor.GetDefaultEvent(GetType()); }
		public PropertyDescriptor GetDefaultProperty() { return TypeDescriptor.GetDefaultProperty(GetType()); }
		public object GetEditor(Type editorBaseType) { return TypeDescriptor.GetEditor(GetType(), editorBaseType); }
		public EventDescriptorCollection GetEvents(Attribute[] attributes) { return TypeDescriptor.GetEvents(GetType(), attributes); }
		public EventDescriptorCollection GetEvents() { return TypeDescriptor.GetEvents(GetType()); }
		public PropertyDescriptorCollection GetProperties(Attribute[] attributes)
		{
			PropertyDescriptorCollection orig = GetFilteredIndicatorProperties(TypeDescriptor.GetProperties(GetType(), attributes), this.IsOwnedByChart, this.IsCreatedByStrategy);
			PropertyDescriptor[] arr = new PropertyDescriptor[orig.Count];
			orig.CopyTo(arr, 0);
			PropertyDescriptorCollection col = new PropertyDescriptorCollection(arr);
			ModifyProperties(col);
			return col;
		}
		public static PropertyDescriptorCollection GetFilteredIndicatorProperties(PropertyDescriptorCollection origProperties, bool isOwnedByChart, bool isCreatedByStrategy)
		{
			List<PropertyDescriptor> allProps = new List<PropertyDescriptor>();
			foreach (PropertyDescriptor pd in origProperties) { allProps.Add(pd); }
			Type[] excludedTypes = new Type[] { typeof(System.Windows.Media.Brush), typeof(NinjaTrader.Gui.Stroke), typeof(System.Windows.Media.Color), typeof(System.Windows.Media.Pen) };
			Func<Type, bool> IsNotAVisualType = (Type propType) => {
				foreach (Type testType in excludedTypes) { if (testType.IsAssignableFrom(propType)) return false; }
				return true;
			};
			IEnumerable<string> baseIndProperties = from bp in typeof(IndicatorBase).GetProperties(BindingFlags.Instance | BindingFlags.Public) select bp.Name;
			IEnumerable<PropertyDescriptor> filteredProps = from p in allProps where p.IsBrowsable && (!isOwnedByChart && !isCreatedByStrategy ? (!baseIndProperties.Contains(p.Name) && p.Name != "Calculate" && p.Name != "Displacement" && IsNotAVisualType(p.PropertyType)) : true) select p;
			return new PropertyDescriptorCollection(filteredProps.ToArray());
		}
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_AnchoredVolume[] cacheARC_AnchoredVolume;
		public ARC.ARC_AnchoredVolume ARC_AnchoredVolume(string chartType, int chartInterval, int ticksPerLevel, int valueAreaLevelsPerStep, bool showComposite, bool showCurrentProfile, bool showHistorical, string compositeType, int startTimeHrs, int startTimeMin, int intervalMin, int vAPercentComposite, int vAOpacComposite, bool showVALComposite, bool showVAHComposite, bool showPOCComposite, bool showProfileComposite, bool showExtremesComposite, bool showTextComposite, int normalOpacComposite, double profilePercentComposite, double profilePercentCompositeRightSide, SimpleFont textHistProfileComposite, Stroke extremesComposite, Stroke pOCComposite, Stroke vAHComposite, Stroke vALComposite, Stroke profileComposite, int vAPercentStatic, int vAOpacHisto, bool showVALHisto, bool showVAHHisto, bool showPOCHisto, bool showProfileHisto, bool showExtremesHisto, bool showTextStatic, int normalOpacHisto, double profilePercentHisto, SimpleFont textHistProfileHisto, Stroke building, Stroke extremesHisto, Stroke pOCHisto, Stroke vAHHisto, Stroke vALHisto, Stroke profileHisto, int vAPercentRealTime, int vAOpacCurrentBar, bool drawOnLeft, bool showVALCurrentBar, bool showVAHCurrentBar, bool showPOCCurrentBar, bool showProfileCurrentBar, bool showExtremesCurrentBar, bool showTextRealTime, int normalOpacCurrentBar, double profilePercentCurrentBar, double profilePercentCurrentBarRightSide, SimpleFont textHistProfileCurrentBar, Stroke extremesCurrentBar, Stroke pOCCurrentBar, Stroke vAHCurrentBar, Stroke vALCurrentBar, Stroke profileCurrentBar, bool showVWAP, double deviation1VWAP, double deviation2VWAP, double deviation3VWAP, string vWAPDeviationVWAP, int opacityVWAP, Stroke vwapVWAP, Stroke aboveVWAP, Stroke belowVWAP, bool showShadingVWAP, bool drawLastValueVWAP, bool showTextVWAP, SimpleFont textFontVWAP, bool showCWAP, double deviation1CWAP, double deviation2CWAP, double deviation3CWAP, string vWAPDeviationCWAP, int opacityCWAP, Stroke vwapCWAP, Stroke aboveCWAP, Stroke belowCWAP, bool showShadingCWAP, bool drawLastValueCWAP, bool showTextCWAP, SimpleFont textFontCWAP, int clusterTicks, int opacity, bool showBorder, bool showShading, Stroke stroke, string show, string buttonText)
		{
			return ARC_AnchoredVolume(Input, chartType, chartInterval, ticksPerLevel, valueAreaLevelsPerStep, showComposite, showCurrentProfile, showHistorical, compositeType, startTimeHrs, startTimeMin, intervalMin, vAPercentComposite, vAOpacComposite, showVALComposite, showVAHComposite, showPOCComposite, showProfileComposite, showExtremesComposite, showTextComposite, normalOpacComposite, profilePercentComposite, profilePercentCompositeRightSide, textHistProfileComposite, extremesComposite, pOCComposite, vAHComposite, vALComposite, profileComposite, vAPercentStatic, vAOpacHisto, showVALHisto, showVAHHisto, showPOCHisto, showProfileHisto, showExtremesHisto, showTextStatic, normalOpacHisto, profilePercentHisto, textHistProfileHisto, building, extremesHisto, pOCHisto, vAHHisto, vALHisto, profileHisto, vAPercentRealTime, vAOpacCurrentBar, drawOnLeft, showVALCurrentBar, showVAHCurrentBar, showPOCCurrentBar, showProfileCurrentBar, showExtremesCurrentBar, showTextRealTime, normalOpacCurrentBar, profilePercentCurrentBar, profilePercentCurrentBarRightSide, textHistProfileCurrentBar, extremesCurrentBar, pOCCurrentBar, vAHCurrentBar, vALCurrentBar, profileCurrentBar, showVWAP, deviation1VWAP, deviation2VWAP, deviation3VWAP, vWAPDeviationVWAP, opacityVWAP, vwapVWAP, aboveVWAP, belowVWAP, showShadingVWAP, drawLastValueVWAP, showTextVWAP, textFontVWAP, showCWAP, deviation1CWAP, deviation2CWAP, deviation3CWAP, vWAPDeviationCWAP, opacityCWAP, vwapCWAP, aboveCWAP, belowCWAP, showShadingCWAP, drawLastValueCWAP, showTextCWAP, textFontCWAP, clusterTicks, opacity, showBorder, showShading, stroke, show, buttonText);
		}

		public ARC.ARC_AnchoredVolume ARC_AnchoredVolume(ISeries<double> input, string chartType, int chartInterval, int ticksPerLevel, int valueAreaLevelsPerStep, bool showComposite, bool showCurrentProfile, bool showHistorical, string compositeType, int startTimeHrs, int startTimeMin, int intervalMin, int vAPercentComposite, int vAOpacComposite, bool showVALComposite, bool showVAHComposite, bool showPOCComposite, bool showProfileComposite, bool showExtremesComposite, bool showTextComposite, int normalOpacComposite, double profilePercentComposite, double profilePercentCompositeRightSide, SimpleFont textHistProfileComposite, Stroke extremesComposite, Stroke pOCComposite, Stroke vAHComposite, Stroke vALComposite, Stroke profileComposite, int vAPercentStatic, int vAOpacHisto, bool showVALHisto, bool showVAHHisto, bool showPOCHisto, bool showProfileHisto, bool showExtremesHisto, bool showTextStatic, int normalOpacHisto, double profilePercentHisto, SimpleFont textHistProfileHisto, Stroke building, Stroke extremesHisto, Stroke pOCHisto, Stroke vAHHisto, Stroke vALHisto, Stroke profileHisto, int vAPercentRealTime, int vAOpacCurrentBar, bool drawOnLeft, bool showVALCurrentBar, bool showVAHCurrentBar, bool showPOCCurrentBar, bool showProfileCurrentBar, bool showExtremesCurrentBar, bool showTextRealTime, int normalOpacCurrentBar, double profilePercentCurrentBar, double profilePercentCurrentBarRightSide, SimpleFont textHistProfileCurrentBar, Stroke extremesCurrentBar, Stroke pOCCurrentBar, Stroke vAHCurrentBar, Stroke vALCurrentBar, Stroke profileCurrentBar, bool showVWAP, double deviation1VWAP, double deviation2VWAP, double deviation3VWAP, string vWAPDeviationVWAP, int opacityVWAP, Stroke vwapVWAP, Stroke aboveVWAP, Stroke belowVWAP, bool showShadingVWAP, bool drawLastValueVWAP, bool showTextVWAP, SimpleFont textFontVWAP, bool showCWAP, double deviation1CWAP, double deviation2CWAP, double deviation3CWAP, string vWAPDeviationCWAP, int opacityCWAP, Stroke vwapCWAP, Stroke aboveCWAP, Stroke belowCWAP, bool showShadingCWAP, bool drawLastValueCWAP, bool showTextCWAP, SimpleFont textFontCWAP, int clusterTicks, int opacity, bool showBorder, bool showShading, Stroke stroke, string show, string buttonText)
		{
			if (cacheARC_AnchoredVolume != null)
				for (int idx = 0; idx < cacheARC_AnchoredVolume.Length; idx++)
					if (cacheARC_AnchoredVolume[idx] != null && cacheARC_AnchoredVolume[idx].ChartType == chartType && cacheARC_AnchoredVolume[idx].ChartInterval == chartInterval && cacheARC_AnchoredVolume[idx].TicksPerLevel == ticksPerLevel && cacheARC_AnchoredVolume[idx].ValueAreaLevelsPerStep == valueAreaLevelsPerStep && cacheARC_AnchoredVolume[idx].ShowComposite == showComposite && cacheARC_AnchoredVolume[idx].ShowCurrentProfile == showCurrentProfile && cacheARC_AnchoredVolume[idx].ShowHistorical == showHistorical && cacheARC_AnchoredVolume[idx].CompositeType == compositeType && cacheARC_AnchoredVolume[idx].StartTimeHrs == startTimeHrs && cacheARC_AnchoredVolume[idx].StartTimeMin == startTimeMin && cacheARC_AnchoredVolume[idx].IntervalMin == intervalMin && cacheARC_AnchoredVolume[idx].VAPercentComposite == vAPercentComposite && cacheARC_AnchoredVolume[idx].VAOpacComposite == vAOpacComposite && cacheARC_AnchoredVolume[idx].ShowVALComposite == showVALComposite && cacheARC_AnchoredVolume[idx].ShowVAHComposite == showVAHComposite && cacheARC_AnchoredVolume[idx].ShowPOCComposite == showPOCComposite && cacheARC_AnchoredVolume[idx].ShowProfileComposite == showProfileComposite && cacheARC_AnchoredVolume[idx].ShowExtremesComposite == showExtremesComposite && cacheARC_AnchoredVolume[idx].ShowTextComposite == showTextComposite && cacheARC_AnchoredVolume[idx].NormalOpacComposite == normalOpacComposite && cacheARC_AnchoredVolume[idx].ProfilePercentComposite == profilePercentComposite && cacheARC_AnchoredVolume[idx].ProfilePercentCompositeRightSide == profilePercentCompositeRightSide && cacheARC_AnchoredVolume[idx].TextHistProfileComposite == textHistProfileComposite && cacheARC_AnchoredVolume[idx].ExtremesComposite == extremesComposite && cacheARC_AnchoredVolume[idx].POCComposite == pOCComposite && cacheARC_AnchoredVolume[idx].VAHComposite == vAHComposite && cacheARC_AnchoredVolume[idx].VALComposite == vALComposite && cacheARC_AnchoredVolume[idx].ProfileComposite == profileComposite && cacheARC_AnchoredVolume[idx].VAPercentStatic == vAPercentStatic && cacheARC_AnchoredVolume[idx].VAOpacHisto == vAOpacHisto && cacheARC_AnchoredVolume[idx].ShowVALHisto == showVALHisto && cacheARC_AnchoredVolume[idx].ShowVAHHisto == showVAHHisto && cacheARC_AnchoredVolume[idx].ShowPOCHisto == showPOCHisto && cacheARC_AnchoredVolume[idx].ShowProfileHisto == showProfileHisto && cacheARC_AnchoredVolume[idx].ShowExtremesHisto == showExtremesHisto && cacheARC_AnchoredVolume[idx].ShowTextStatic == showTextStatic && cacheARC_AnchoredVolume[idx].NormalOpacHisto == normalOpacHisto && cacheARC_AnchoredVolume[idx].ProfilePercentHisto == profilePercentHisto && cacheARC_AnchoredVolume[idx].TextHistProfileHisto == textHistProfileHisto && cacheARC_AnchoredVolume[idx].Building == building && cacheARC_AnchoredVolume[idx].ExtremesHisto == extremesHisto && cacheARC_AnchoredVolume[idx].POCHisto == pOCHisto && cacheARC_AnchoredVolume[idx].VAHHisto == vAHHisto && cacheARC_AnchoredVolume[idx].VALHisto == vALHisto && cacheARC_AnchoredVolume[idx].ProfileHisto == profileHisto && cacheARC_AnchoredVolume[idx].VAPercentRealTime == vAPercentRealTime && cacheARC_AnchoredVolume[idx].VAOpacCurrentBar == vAOpacCurrentBar && cacheARC_AnchoredVolume[idx].DrawOnLeft == drawOnLeft && cacheARC_AnchoredVolume[idx].ShowVALCurrentBar == showVALCurrentBar && cacheARC_AnchoredVolume[idx].ShowVAHCurrentBar == showVAHCurrentBar && cacheARC_AnchoredVolume[idx].ShowPOCCurrentBar == showPOCCurrentBar && cacheARC_AnchoredVolume[idx].ShowProfileCurrentBar == showProfileCurrentBar && cacheARC_AnchoredVolume[idx].ShowExtremesCurrentBar == showExtremesCurrentBar && cacheARC_AnchoredVolume[idx].ShowTextRealTime == showTextRealTime && cacheARC_AnchoredVolume[idx].NormalOpacCurrentBar == normalOpacCurrentBar && cacheARC_AnchoredVolume[idx].ProfilePercentCurrentBar == profilePercentCurrentBar && cacheARC_AnchoredVolume[idx].ProfilePercentCurrentBarRightSide == profilePercentCurrentBarRightSide && cacheARC_AnchoredVolume[idx].TextHistProfileCurrentBar == textHistProfileCurrentBar && cacheARC_AnchoredVolume[idx].ExtremesCurrentBar == extremesCurrentBar && cacheARC_AnchoredVolume[idx].POCCurrentBar == pOCCurrentBar && cacheARC_AnchoredVolume[idx].VAHCurrentBar == vAHCurrentBar && cacheARC_AnchoredVolume[idx].VALCurrentBar == vALCurrentBar && cacheARC_AnchoredVolume[idx].ProfileCurrentBar == profileCurrentBar && cacheARC_AnchoredVolume[idx].ShowVWAP == showVWAP && cacheARC_AnchoredVolume[idx].Deviation1VWAP == deviation1VWAP && cacheARC_AnchoredVolume[idx].Deviation2VWAP == deviation2VWAP && cacheARC_AnchoredVolume[idx].Deviation3VWAP == deviation3VWAP && cacheARC_AnchoredVolume[idx].VWAPDeviationVWAP == vWAPDeviationVWAP && cacheARC_AnchoredVolume[idx].OpacityVWAP == opacityVWAP && cacheARC_AnchoredVolume[idx].VwapVWAP == vwapVWAP && cacheARC_AnchoredVolume[idx].AboveVWAP == aboveVWAP && cacheARC_AnchoredVolume[idx].BelowVWAP == belowVWAP && cacheARC_AnchoredVolume[idx].ShowShadingVWAP == showShadingVWAP && cacheARC_AnchoredVolume[idx].DrawLastValueVWAP == drawLastValueVWAP && cacheARC_AnchoredVolume[idx].ShowTextVWAP == showTextVWAP && cacheARC_AnchoredVolume[idx].TextFontVWAP == textFontVWAP && cacheARC_AnchoredVolume[idx].ShowCWAP == showCWAP && cacheARC_AnchoredVolume[idx].Deviation1CWAP == deviation1CWAP && cacheARC_AnchoredVolume[idx].Deviation2CWAP == deviation2CWAP && cacheARC_AnchoredVolume[idx].Deviation3CWAP == deviation3CWAP && cacheARC_AnchoredVolume[idx].VWAPDeviationCWAP == vWAPDeviationCWAP && cacheARC_AnchoredVolume[idx].OpacityCWAP == opacityCWAP && cacheARC_AnchoredVolume[idx].VwapCWAP == vwapCWAP && cacheARC_AnchoredVolume[idx].AboveCWAP == aboveCWAP && cacheARC_AnchoredVolume[idx].BelowCWAP == belowCWAP && cacheARC_AnchoredVolume[idx].ShowShadingCWAP == showShadingCWAP && cacheARC_AnchoredVolume[idx].DrawLastValueCWAP == drawLastValueCWAP && cacheARC_AnchoredVolume[idx].ShowTextCWAP == showTextCWAP && cacheARC_AnchoredVolume[idx].TextFontCWAP == textFontCWAP && cacheARC_AnchoredVolume[idx].ClusterTicks == clusterTicks && cacheARC_AnchoredVolume[idx].Opacity == opacity && cacheARC_AnchoredVolume[idx].ShowBorder == showBorder && cacheARC_AnchoredVolume[idx].ShowShading == showShading && cacheARC_AnchoredVolume[idx].Stroke == stroke && cacheARC_AnchoredVolume[idx].Show == show && cacheARC_AnchoredVolume[idx].ButtonText == buttonText && cacheARC_AnchoredVolume[idx].EqualsInput(input))
						return cacheARC_AnchoredVolume[idx];
			return CacheIndicator<ARC.ARC_AnchoredVolume>(new ARC.ARC_AnchoredVolume(){ ChartType = chartType, ChartInterval = chartInterval, TicksPerLevel = ticksPerLevel, ValueAreaLevelsPerStep = valueAreaLevelsPerStep, ShowComposite = showComposite, ShowCurrentProfile = showCurrentProfile, ShowHistorical = showHistorical, CompositeType = compositeType, StartTimeHrs = startTimeHrs, StartTimeMin = startTimeMin, IntervalMin = intervalMin, VAPercentComposite = vAPercentComposite, VAOpacComposite = vAOpacComposite, ShowVALComposite = showVALComposite, ShowVAHComposite = showVAHComposite, ShowPOCComposite = showPOCComposite, ShowProfileComposite = showProfileComposite, ShowExtremesComposite = showExtremesComposite, ShowTextComposite = showTextComposite, NormalOpacComposite = normalOpacComposite, ProfilePercentComposite = profilePercentComposite, ProfilePercentCompositeRightSide = profilePercentCompositeRightSide, TextHistProfileComposite = textHistProfileComposite, ExtremesComposite = extremesComposite, POCComposite = pOCComposite, VAHComposite = vAHComposite, VALComposite = vALComposite, ProfileComposite = profileComposite, VAPercentStatic = vAPercentStatic, VAOpacHisto = vAOpacHisto, ShowVALHisto = showVALHisto, ShowVAHHisto = showVAHHisto, ShowPOCHisto = showPOCHisto, ShowProfileHisto = showProfileHisto, ShowExtremesHisto = showExtremesHisto, ShowTextStatic = showTextStatic, NormalOpacHisto = normalOpacHisto, ProfilePercentHisto = profilePercentHisto, TextHistProfileHisto = textHistProfileHisto, Building = building, ExtremesHisto = extremesHisto, POCHisto = pOCHisto, VAHHisto = vAHHisto, VALHisto = vALHisto, ProfileHisto = profileHisto, VAPercentRealTime = vAPercentRealTime, VAOpacCurrentBar = vAOpacCurrentBar, DrawOnLeft = drawOnLeft, ShowVALCurrentBar = showVALCurrentBar, ShowVAHCurrentBar = showVAHCurrentBar, ShowPOCCurrentBar = showPOCCurrentBar, ShowProfileCurrentBar = showProfileCurrentBar, ShowExtremesCurrentBar = showExtremesCurrentBar, ShowTextRealTime = showTextRealTime, NormalOpacCurrentBar = normalOpacCurrentBar, ProfilePercentCurrentBar = profilePercentCurrentBar, ProfilePercentCurrentBarRightSide = profilePercentCurrentBarRightSide, TextHistProfileCurrentBar = textHistProfileCurrentBar, ExtremesCurrentBar = extremesCurrentBar, POCCurrentBar = pOCCurrentBar, VAHCurrentBar = vAHCurrentBar, VALCurrentBar = vALCurrentBar, ProfileCurrentBar = profileCurrentBar, ShowVWAP = showVWAP, Deviation1VWAP = deviation1VWAP, Deviation2VWAP = deviation2VWAP, Deviation3VWAP = deviation3VWAP, VWAPDeviationVWAP = vWAPDeviationVWAP, OpacityVWAP = opacityVWAP, VwapVWAP = vwapVWAP, AboveVWAP = aboveVWAP, BelowVWAP = belowVWAP, ShowShadingVWAP = showShadingVWAP, DrawLastValueVWAP = drawLastValueVWAP, ShowTextVWAP = showTextVWAP, TextFontVWAP = textFontVWAP, ShowCWAP = showCWAP, Deviation1CWAP = deviation1CWAP, Deviation2CWAP = deviation2CWAP, Deviation3CWAP = deviation3CWAP, VWAPDeviationCWAP = vWAPDeviationCWAP, OpacityCWAP = opacityCWAP, VwapCWAP = vwapCWAP, AboveCWAP = aboveCWAP, BelowCWAP = belowCWAP, ShowShadingCWAP = showShadingCWAP, DrawLastValueCWAP = drawLastValueCWAP, ShowTextCWAP = showTextCWAP, TextFontCWAP = textFontCWAP, ClusterTicks = clusterTicks, Opacity = opacity, ShowBorder = showBorder, ShowShading = showShading, Stroke = stroke, Show = show, ButtonText = buttonText }, input, ref cacheARC_AnchoredVolume);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_AnchoredVolume ARC_AnchoredVolume(string chartType, int chartInterval, int ticksPerLevel, int valueAreaLevelsPerStep, bool showComposite, bool showCurrentProfile, bool showHistorical, string compositeType, int startTimeHrs, int startTimeMin, int intervalMin, int vAPercentComposite, int vAOpacComposite, bool showVALComposite, bool showVAHComposite, bool showPOCComposite, bool showProfileComposite, bool showExtremesComposite, bool showTextComposite, int normalOpacComposite, double profilePercentComposite, double profilePercentCompositeRightSide, SimpleFont textHistProfileComposite, Stroke extremesComposite, Stroke pOCComposite, Stroke vAHComposite, Stroke vALComposite, Stroke profileComposite, int vAPercentStatic, int vAOpacHisto, bool showVALHisto, bool showVAHHisto, bool showPOCHisto, bool showProfileHisto, bool showExtremesHisto, bool showTextStatic, int normalOpacHisto, double profilePercentHisto, SimpleFont textHistProfileHisto, Stroke building, Stroke extremesHisto, Stroke pOCHisto, Stroke vAHHisto, Stroke vALHisto, Stroke profileHisto, int vAPercentRealTime, int vAOpacCurrentBar, bool drawOnLeft, bool showVALCurrentBar, bool showVAHCurrentBar, bool showPOCCurrentBar, bool showProfileCurrentBar, bool showExtremesCurrentBar, bool showTextRealTime, int normalOpacCurrentBar, double profilePercentCurrentBar, double profilePercentCurrentBarRightSide, SimpleFont textHistProfileCurrentBar, Stroke extremesCurrentBar, Stroke pOCCurrentBar, Stroke vAHCurrentBar, Stroke vALCurrentBar, Stroke profileCurrentBar, bool showVWAP, double deviation1VWAP, double deviation2VWAP, double deviation3VWAP, string vWAPDeviationVWAP, int opacityVWAP, Stroke vwapVWAP, Stroke aboveVWAP, Stroke belowVWAP, bool showShadingVWAP, bool drawLastValueVWAP, bool showTextVWAP, SimpleFont textFontVWAP, bool showCWAP, double deviation1CWAP, double deviation2CWAP, double deviation3CWAP, string vWAPDeviationCWAP, int opacityCWAP, Stroke vwapCWAP, Stroke aboveCWAP, Stroke belowCWAP, bool showShadingCWAP, bool drawLastValueCWAP, bool showTextCWAP, SimpleFont textFontCWAP, int clusterTicks, int opacity, bool showBorder, bool showShading, Stroke stroke, string show, string buttonText)
		{
			return indicator.ARC_AnchoredVolume(Input, chartType, chartInterval, ticksPerLevel, valueAreaLevelsPerStep, showComposite, showCurrentProfile, showHistorical, compositeType, startTimeHrs, startTimeMin, intervalMin, vAPercentComposite, vAOpacComposite, showVALComposite, showVAHComposite, showPOCComposite, showProfileComposite, showExtremesComposite, showTextComposite, normalOpacComposite, profilePercentComposite, profilePercentCompositeRightSide, textHistProfileComposite, extremesComposite, pOCComposite, vAHComposite, vALComposite, profileComposite, vAPercentStatic, vAOpacHisto, showVALHisto, showVAHHisto, showPOCHisto, showProfileHisto, showExtremesHisto, showTextStatic, normalOpacHisto, profilePercentHisto, textHistProfileHisto, building, extremesHisto, pOCHisto, vAHHisto, vALHisto, profileHisto, vAPercentRealTime, vAOpacCurrentBar, drawOnLeft, showVALCurrentBar, showVAHCurrentBar, showPOCCurrentBar, showProfileCurrentBar, showExtremesCurrentBar, showTextRealTime, normalOpacCurrentBar, profilePercentCurrentBar, profilePercentCurrentBarRightSide, textHistProfileCurrentBar, extremesCurrentBar, pOCCurrentBar, vAHCurrentBar, vALCurrentBar, profileCurrentBar, showVWAP, deviation1VWAP, deviation2VWAP, deviation3VWAP, vWAPDeviationVWAP, opacityVWAP, vwapVWAP, aboveVWAP, belowVWAP, showShadingVWAP, drawLastValueVWAP, showTextVWAP, textFontVWAP, showCWAP, deviation1CWAP, deviation2CWAP, deviation3CWAP, vWAPDeviationCWAP, opacityCWAP, vwapCWAP, aboveCWAP, belowCWAP, showShadingCWAP, drawLastValueCWAP, showTextCWAP, textFontCWAP, clusterTicks, opacity, showBorder, showShading, stroke, show, buttonText);
		}

		public Indicators.ARC.ARC_AnchoredVolume ARC_AnchoredVolume(ISeries<double> input , string chartType, int chartInterval, int ticksPerLevel, int valueAreaLevelsPerStep, bool showComposite, bool showCurrentProfile, bool showHistorical, string compositeType, int startTimeHrs, int startTimeMin, int intervalMin, int vAPercentComposite, int vAOpacComposite, bool showVALComposite, bool showVAHComposite, bool showPOCComposite, bool showProfileComposite, bool showExtremesComposite, bool showTextComposite, int normalOpacComposite, double profilePercentComposite, double profilePercentCompositeRightSide, SimpleFont textHistProfileComposite, Stroke extremesComposite, Stroke pOCComposite, Stroke vAHComposite, Stroke vALComposite, Stroke profileComposite, int vAPercentStatic, int vAOpacHisto, bool showVALHisto, bool showVAHHisto, bool showPOCHisto, bool showProfileHisto, bool showExtremesHisto, bool showTextStatic, int normalOpacHisto, double profilePercentHisto, SimpleFont textHistProfileHisto, Stroke building, Stroke extremesHisto, Stroke pOCHisto, Stroke vAHHisto, Stroke vALHisto, Stroke profileHisto, int vAPercentRealTime, int vAOpacCurrentBar, bool drawOnLeft, bool showVALCurrentBar, bool showVAHCurrentBar, bool showPOCCurrentBar, bool showProfileCurrentBar, bool showExtremesCurrentBar, bool showTextRealTime, int normalOpacCurrentBar, double profilePercentCurrentBar, double profilePercentCurrentBarRightSide, SimpleFont textHistProfileCurrentBar, Stroke extremesCurrentBar, Stroke pOCCurrentBar, Stroke vAHCurrentBar, Stroke vALCurrentBar, Stroke profileCurrentBar, bool showVWAP, double deviation1VWAP, double deviation2VWAP, double deviation3VWAP, string vWAPDeviationVWAP, int opacityVWAP, Stroke vwapVWAP, Stroke aboveVWAP, Stroke belowVWAP, bool showShadingVWAP, bool drawLastValueVWAP, bool showTextVWAP, SimpleFont textFontVWAP, bool showCWAP, double deviation1CWAP, double deviation2CWAP, double deviation3CWAP, string vWAPDeviationCWAP, int opacityCWAP, Stroke vwapCWAP, Stroke aboveCWAP, Stroke belowCWAP, bool showShadingCWAP, bool drawLastValueCWAP, bool showTextCWAP, SimpleFont textFontCWAP, int clusterTicks, int opacity, bool showBorder, bool showShading, Stroke stroke, string show, string buttonText)
		{
			return indicator.ARC_AnchoredVolume(input, chartType, chartInterval, ticksPerLevel, valueAreaLevelsPerStep, showComposite, showCurrentProfile, showHistorical, compositeType, startTimeHrs, startTimeMin, intervalMin, vAPercentComposite, vAOpacComposite, showVALComposite, showVAHComposite, showPOCComposite, showProfileComposite, showExtremesComposite, showTextComposite, normalOpacComposite, profilePercentComposite, profilePercentCompositeRightSide, textHistProfileComposite, extremesComposite, pOCComposite, vAHComposite, vALComposite, profileComposite, vAPercentStatic, vAOpacHisto, showVALHisto, showVAHHisto, showPOCHisto, showProfileHisto, showExtremesHisto, showTextStatic, normalOpacHisto, profilePercentHisto, textHistProfileHisto, building, extremesHisto, pOCHisto, vAHHisto, vALHisto, profileHisto, vAPercentRealTime, vAOpacCurrentBar, drawOnLeft, showVALCurrentBar, showVAHCurrentBar, showPOCCurrentBar, showProfileCurrentBar, showExtremesCurrentBar, showTextRealTime, normalOpacCurrentBar, profilePercentCurrentBar, profilePercentCurrentBarRightSide, textHistProfileCurrentBar, extremesCurrentBar, pOCCurrentBar, vAHCurrentBar, vALCurrentBar, profileCurrentBar, showVWAP, deviation1VWAP, deviation2VWAP, deviation3VWAP, vWAPDeviationVWAP, opacityVWAP, vwapVWAP, aboveVWAP, belowVWAP, showShadingVWAP, drawLastValueVWAP, showTextVWAP, textFontVWAP, showCWAP, deviation1CWAP, deviation2CWAP, deviation3CWAP, vWAPDeviationCWAP, opacityCWAP, vwapCWAP, aboveCWAP, belowCWAP, showShadingCWAP, drawLastValueCWAP, showTextCWAP, textFontCWAP, clusterTicks, opacity, showBorder, showShading, stroke, show, buttonText);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_AnchoredVolume ARC_AnchoredVolume(string chartType, int chartInterval, int ticksPerLevel, int valueAreaLevelsPerStep, bool showComposite, bool showCurrentProfile, bool showHistorical, string compositeType, int startTimeHrs, int startTimeMin, int intervalMin, int vAPercentComposite, int vAOpacComposite, bool showVALComposite, bool showVAHComposite, bool showPOCComposite, bool showProfileComposite, bool showExtremesComposite, bool showTextComposite, int normalOpacComposite, double profilePercentComposite, double profilePercentCompositeRightSide, SimpleFont textHistProfileComposite, Stroke extremesComposite, Stroke pOCComposite, Stroke vAHComposite, Stroke vALComposite, Stroke profileComposite, int vAPercentStatic, int vAOpacHisto, bool showVALHisto, bool showVAHHisto, bool showPOCHisto, bool showProfileHisto, bool showExtremesHisto, bool showTextStatic, int normalOpacHisto, double profilePercentHisto, SimpleFont textHistProfileHisto, Stroke building, Stroke extremesHisto, Stroke pOCHisto, Stroke vAHHisto, Stroke vALHisto, Stroke profileHisto, int vAPercentRealTime, int vAOpacCurrentBar, bool drawOnLeft, bool showVALCurrentBar, bool showVAHCurrentBar, bool showPOCCurrentBar, bool showProfileCurrentBar, bool showExtremesCurrentBar, bool showTextRealTime, int normalOpacCurrentBar, double profilePercentCurrentBar, double profilePercentCurrentBarRightSide, SimpleFont textHistProfileCurrentBar, Stroke extremesCurrentBar, Stroke pOCCurrentBar, Stroke vAHCurrentBar, Stroke vALCurrentBar, Stroke profileCurrentBar, bool showVWAP, double deviation1VWAP, double deviation2VWAP, double deviation3VWAP, string vWAPDeviationVWAP, int opacityVWAP, Stroke vwapVWAP, Stroke aboveVWAP, Stroke belowVWAP, bool showShadingVWAP, bool drawLastValueVWAP, bool showTextVWAP, SimpleFont textFontVWAP, bool showCWAP, double deviation1CWAP, double deviation2CWAP, double deviation3CWAP, string vWAPDeviationCWAP, int opacityCWAP, Stroke vwapCWAP, Stroke aboveCWAP, Stroke belowCWAP, bool showShadingCWAP, bool drawLastValueCWAP, bool showTextCWAP, SimpleFont textFontCWAP, int clusterTicks, int opacity, bool showBorder, bool showShading, Stroke stroke, string show, string buttonText)
		{
			return indicator.ARC_AnchoredVolume(Input, chartType, chartInterval, ticksPerLevel, valueAreaLevelsPerStep, showComposite, showCurrentProfile, showHistorical, compositeType, startTimeHrs, startTimeMin, intervalMin, vAPercentComposite, vAOpacComposite, showVALComposite, showVAHComposite, showPOCComposite, showProfileComposite, showExtremesComposite, showTextComposite, normalOpacComposite, profilePercentComposite, profilePercentCompositeRightSide, textHistProfileComposite, extremesComposite, pOCComposite, vAHComposite, vALComposite, profileComposite, vAPercentStatic, vAOpacHisto, showVALHisto, showVAHHisto, showPOCHisto, showProfileHisto, showExtremesHisto, showTextStatic, normalOpacHisto, profilePercentHisto, textHistProfileHisto, building, extremesHisto, pOCHisto, vAHHisto, vALHisto, profileHisto, vAPercentRealTime, vAOpacCurrentBar, drawOnLeft, showVALCurrentBar, showVAHCurrentBar, showPOCCurrentBar, showProfileCurrentBar, showExtremesCurrentBar, showTextRealTime, normalOpacCurrentBar, profilePercentCurrentBar, profilePercentCurrentBarRightSide, textHistProfileCurrentBar, extremesCurrentBar, pOCCurrentBar, vAHCurrentBar, vALCurrentBar, profileCurrentBar, showVWAP, deviation1VWAP, deviation2VWAP, deviation3VWAP, vWAPDeviationVWAP, opacityVWAP, vwapVWAP, aboveVWAP, belowVWAP, showShadingVWAP, drawLastValueVWAP, showTextVWAP, textFontVWAP, showCWAP, deviation1CWAP, deviation2CWAP, deviation3CWAP, vWAPDeviationCWAP, opacityCWAP, vwapCWAP, aboveCWAP, belowCWAP, showShadingCWAP, drawLastValueCWAP, showTextCWAP, textFontCWAP, clusterTicks, opacity, showBorder, showShading, stroke, show, buttonText);
		}

		public Indicators.ARC.ARC_AnchoredVolume ARC_AnchoredVolume(ISeries<double> input , string chartType, int chartInterval, int ticksPerLevel, int valueAreaLevelsPerStep, bool showComposite, bool showCurrentProfile, bool showHistorical, string compositeType, int startTimeHrs, int startTimeMin, int intervalMin, int vAPercentComposite, int vAOpacComposite, bool showVALComposite, bool showVAHComposite, bool showPOCComposite, bool showProfileComposite, bool showExtremesComposite, bool showTextComposite, int normalOpacComposite, double profilePercentComposite, double profilePercentCompositeRightSide, SimpleFont textHistProfileComposite, Stroke extremesComposite, Stroke pOCComposite, Stroke vAHComposite, Stroke vALComposite, Stroke profileComposite, int vAPercentStatic, int vAOpacHisto, bool showVALHisto, bool showVAHHisto, bool showPOCHisto, bool showProfileHisto, bool showExtremesHisto, bool showTextStatic, int normalOpacHisto, double profilePercentHisto, SimpleFont textHistProfileHisto, Stroke building, Stroke extremesHisto, Stroke pOCHisto, Stroke vAHHisto, Stroke vALHisto, Stroke profileHisto, int vAPercentRealTime, int vAOpacCurrentBar, bool drawOnLeft, bool showVALCurrentBar, bool showVAHCurrentBar, bool showPOCCurrentBar, bool showProfileCurrentBar, bool showExtremesCurrentBar, bool showTextRealTime, int normalOpacCurrentBar, double profilePercentCurrentBar, double profilePercentCurrentBarRightSide, SimpleFont textHistProfileCurrentBar, Stroke extremesCurrentBar, Stroke pOCCurrentBar, Stroke vAHCurrentBar, Stroke vALCurrentBar, Stroke profileCurrentBar, bool showVWAP, double deviation1VWAP, double deviation2VWAP, double deviation3VWAP, string vWAPDeviationVWAP, int opacityVWAP, Stroke vwapVWAP, Stroke aboveVWAP, Stroke belowVWAP, bool showShadingVWAP, bool drawLastValueVWAP, bool showTextVWAP, SimpleFont textFontVWAP, bool showCWAP, double deviation1CWAP, double deviation2CWAP, double deviation3CWAP, string vWAPDeviationCWAP, int opacityCWAP, Stroke vwapCWAP, Stroke aboveCWAP, Stroke belowCWAP, bool showShadingCWAP, bool drawLastValueCWAP, bool showTextCWAP, SimpleFont textFontCWAP, int clusterTicks, int opacity, bool showBorder, bool showShading, Stroke stroke, string show, string buttonText)
		{
			return indicator.ARC_AnchoredVolume(input, chartType, chartInterval, ticksPerLevel, valueAreaLevelsPerStep, showComposite, showCurrentProfile, showHistorical, compositeType, startTimeHrs, startTimeMin, intervalMin, vAPercentComposite, vAOpacComposite, showVALComposite, showVAHComposite, showPOCComposite, showProfileComposite, showExtremesComposite, showTextComposite, normalOpacComposite, profilePercentComposite, profilePercentCompositeRightSide, textHistProfileComposite, extremesComposite, pOCComposite, vAHComposite, vALComposite, profileComposite, vAPercentStatic, vAOpacHisto, showVALHisto, showVAHHisto, showPOCHisto, showProfileHisto, showExtremesHisto, showTextStatic, normalOpacHisto, profilePercentHisto, textHistProfileHisto, building, extremesHisto, pOCHisto, vAHHisto, vALHisto, profileHisto, vAPercentRealTime, vAOpacCurrentBar, drawOnLeft, showVALCurrentBar, showVAHCurrentBar, showPOCCurrentBar, showProfileCurrentBar, showExtremesCurrentBar, showTextRealTime, normalOpacCurrentBar, profilePercentCurrentBar, profilePercentCurrentBarRightSide, textHistProfileCurrentBar, extremesCurrentBar, pOCCurrentBar, vAHCurrentBar, vALCurrentBar, profileCurrentBar, showVWAP, deviation1VWAP, deviation2VWAP, deviation3VWAP, vWAPDeviationVWAP, opacityVWAP, vwapVWAP, aboveVWAP, belowVWAP, showShadingVWAP, drawLastValueVWAP, showTextVWAP, textFontVWAP, showCWAP, deviation1CWAP, deviation2CWAP, deviation3CWAP, vWAPDeviationCWAP, opacityCWAP, vwapCWAP, aboveCWAP, belowCWAP, showShadingCWAP, drawLastValueCWAP, showTextCWAP, textFontCWAP, clusterTicks, opacity, showBorder, showShading, stroke, show, buttonText);
		}
	}
}

#endregion
