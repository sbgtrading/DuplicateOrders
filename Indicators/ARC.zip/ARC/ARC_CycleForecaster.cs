
#define DoLicense
#define MODERATORS

//#define SPEECH_ENABLED
//#define GAPLESS_DIFFTOOPEN
//#define RSS_AND_RVI

#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
//using System.Diagnostics;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.Linq;
#if SPEECH_ENABLED
using SpeechLib;
using System.Reflection;
using System.Threading;
#endif

using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Automation;

using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using SharpDX.DirectWrite;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion --
// This namespace holds all indicators and is required. Do not change it.
public enum ARC_CycleForecaster_PredictionLocType {
		TopRight,
		TopLeft,
		BottomRight,
		BottomLeft,
		Center,
		None
	}
public enum ARC_CycleForecaster_ExcursionStyle { Static, Dynamic }
public enum ARC_CycleForecaster_AnalysisType {
		CCI,
		RSI,
		Stoch,
		MACD,
		MACDHisto,
		VMDivergence,
		Fisher,
#if RSS_AND_RVI
		RSS,
		RVI,
#endif
#if GAPLESS_DIFFTOOPEN
		GaplessPZ,
		DiffToOpen,
#endif
}
public enum ARC_CycleForecaster_MarkerDirection  {Longs, Shorts, Both, None}
public enum ARC_CycleForecaster_RacingStripeType {Subpanel, BothPanels};
public enum ARC_CycleForecaster_ViewStates       {Data, Trading}
public enum ARC_CycleForecaster_MarkerType       {ArrowUp, ArrowDown, Dot, Square, Diamond, TriangleUp, TriangleDown}

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    /// <summary>
    /// Gives a minute-by-minute statistical analysis of trend, trend reversal and open-to-close relationship over the history of an instrument
    /// </summary>
	public delegate void SpeechDelegate_ARC_CycleForecaster(string str);
    #region -- Category Order --
    [CategoryOrder("Parameters", 1)]
	[CategoryOrder("Peak/Valley Selection", 2)]
    [CategoryOrder("Visuals", 3)]
//    [CategoryOrder("Visuals - ChopZone", 4)]
    [CategoryOrder("Visuals - PeakTimes", 5)]
    [CategoryOrder("Visuals - Entry Markers", 6)]
    [CategoryOrder("Audio", 7)]
    [CategoryOrder("Indicator Version", 8)]
#if SPEECH_ENABLED
    [CategoryOrder("Alert Voice", 200)]
#endif
	#endregion
//    [Description("Gives a minute-by-minute statistical analysis of trend, trend reversal and open-to-close relationship over the history of an instrument")]
    [TypeConverter("NinjaTrader.NinjaScript.Indicators.ARC.CycleForecasterConverter")]
	public class ARC_CycleForecaster : Indicator
    {
//====================================================================================================
		#region SayItPlayIt methods
		private string RemoveNumbersFromString(string instr, int CharsToSkip) {
			if(instr.Length <= CharsToSkip) return instr;
			string outstr = string.Empty;
			if(CharsToSkip>0) outstr = instr.Substring(0,CharsToSkip);

			for(int i = 0+CharsToSkip; i<instr.Length; i++) {
				if((int)instr[i] >= (int)'0' && (int)instr[i] <= (int)'9') continue; else outstr = string.Concat(outstr,instr[i]);
			}
			return outstr;
		}
		private void PlayIt(string EncodedTag) {
			string[] elements = EncodedTag.Split(new char[]{':'}, StringSplitOptions.None);
			if(elements.Length>0) {
				if(elements[elements.Length-1].Length>0) PlaySound(AddSoundFolder(elements[elements.Length-1]));
//				TimeOfText = NinjaTrader.Core.Globals.Now;
//				AlertMsg = MakeString(new Object[]{"WAV file ",elements[elements.Length-1]," played"});
			}
		}
#if SPEECH_ENABLED
		private static void SayItThread (string WhatToSay) {
			if(WhatToSay.Length>0) {
				SpVoice voice = new SpVoice();
				// Tells the program to speak everything in the textbox using Default settings
				voice.Speak(WhatToSay, SpeechVoiceSpeakFlags.SVSFDefault);
			}
		}
		private void SayIt (string EncodedTag, double Price) {
			if(!SpeechEnabled) {
				TimeOfText  = NinjaTrader.Core.Globals.Now;
//				AlertMsg = "Speech not available\nPut Interop.SpeechLib.DLL into 'bin\\Custom' folder and restart the platform";
//				Draw.TextFixed(this, "infomsg", AlertMsg, TextPosition.Center,ChartControl.Properties.AxisPen.Brush, ChartControl.Font, Color.Black, ChartControl.BackBrush, 10);
				return;
			}
			if((State == State.Historical)) return;
			string[] elements = EncodedTag.Split(new char[]{':'}, StringSplitOptions.None);
			if(elements.Length>0) {
				if(elements[0][0]=='/') return;
				SpeechDelegate_ARC_CycleForecaster speechThread = new SpeechDelegate_ARC_CycleForecaster(SayItThread);
				string SayThis = elements[elements.Length-1].ToUpper();
				if(SayThis.Contains("[SAYPRICE]")) {
					string pricestr1 = Instrument.MasterInstrument.FormatPrice(Price);
					string spokenprice = string.Empty + pricestr1[0];
					int i = 0;
					while(i<pricestr1.Length) {
						spokenprice = MakeString(new Object[]{spokenprice," ",pricestr1[i++]});
					}
					SayThis = SayThis.Replace("[SAYPRICE]", spokenprice);
				}
				if(SayThis.Contains("[TIMEFRAME]")) {
					SayThis = SayThis.Replace("[TIMEFRAME]", TimeFrameText);
				}
				if(SayThis.Contains("[INSTRUMENTNAME]")) {
					string name = Instrument.FullName.Replace('-',' ');
					name = RemoveNumbersFromString(name,1);
					string spokenphrase = string.Empty;// + name[0];
					int i = 0;
					while(i<name.Length) {
						spokenphrase = MakeString(new Object[]{spokenphrase," ",name[i++]});
					}
					SayThis = SayThis.Replace("[INSTRUMENTNAME]", spokenphrase);
				}
				speechThread.BeginInvoke(SayThis, null, null);
//				TimeOfText  = NinjaTrader.Core.Globals.Now;
//				AlertMsg = MakeString(new Object[]{"'",SayThis,"' was spoken"});
//				Draw.TextFixed(this, "infomsg", AlertMsg, TextPosition.Center,ChartControl.Properties.AxisPen.Brush, ChartControl.Font, Color.Black, ChartControl.BackBrush, 10);
			}
		}
#else
		private void SayIt (string EncodedTag) {}
		private void SayIt (string EncodedTag, double dummyprice) {}
#endif
		#endregion
//==================================================================
	#region MakeString
	private static string MakeString(object[] s, string Separator){
		System.Text.StringBuilder stb = new System.Text.StringBuilder(s.Length*2);
		for(int i = 0; i<s.Length; i++) {
			stb = stb.Append(s[i].ToString());
			if(i<s.Length-1 && Separator.Length>0) stb = stb.Append(Separator);
		}
		return stb.ToString();
	}
	private void PrintMakeString(object[] s, string Separator){
		System.Text.StringBuilder stb = new System.Text.StringBuilder(s.Length*2);
		for(int i = 0; i<s.Length; i++) {
			stb = stb.Append(s[i].ToString());
			if(i<s.Length-1 && Separator.Length>0) stb = stb.Append(Separator);
		}
//		PrintThese.Add(stb.ToString());
		Print(stb.ToString());
	}
	private void PrintMakeString(object[] s){
		System.Text.StringBuilder stb = new System.Text.StringBuilder(s.Length);
		for(int i = 0; i<s.Length; i++) {
			stb = stb.Append(s[i].ToString());
		}
		Print(stb.ToString());
	}
	private void PrintMakeString(string filepath, object[] s){
		System.Text.StringBuilder stb = new System.Text.StringBuilder(s.Length);
		for(int i = 0; i<s.Length; i++) {
			stb = stb.Append(s[i].ToString());
		}
		System.IO.File.AppendAllText(filepath,stb.ToString());
	}
	private void PrintMakeString(string filepath, object[] s, string Separator) {
		System.Text.StringBuilder stb = new System.Text.StringBuilder(s.Length*2);
		for(int i = 0; i<s.Length; i++) {
			stb = stb.Append(s[i].ToString());
			if(i<s.Length-1 && Separator.Length>0) stb = stb.Append(Separator);
		}
		System.IO.File.AppendAllText(filepath,stb.ToString());
	}
	private static string MakeString(object[] s){
		System.Text.StringBuilder stb = new System.Text.StringBuilder(s.Length);
		for(int i = 0; i<s.Length; i++) {
			stb = stb.Append(s[i].ToString());
		}
		return stb.ToString();
	}
		#endregion
//====================================================================================================
#if SPEECH_ENABLED
		static Assembly  SpeechLib = null;
#endif
		private string VERSION = "v1.2 10-July-2022";
		//v1.2 Changed uID to Guid, added MacdHisto AnalysisType (in response to a user request)

		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "CycleForecaster";
#if FREE_TRIAL_VERSION
		DateTime HardcodeExpireDate = DateTime.MinValue;//new DateTime(2019,11,10);
#endif
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "13741", "27405"};//27405 is Annual Membership
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                var sb = new System.Text.StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", NinjaTrader.Cbi.LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId, NinjaTrader.Cbi.LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion


		private const int UP = 1;
		private const int FLAT = 0;
		private const int DOWN = -1;

		internal struct TimePrice {
			public DateTime Time;
			public double Price;
			public TimePrice (DateTime time, double price) {this.Time=time; this.Price=price;}
		}
		internal class HistoData{
			public double Val;
			public double MinHigh=double.MinValue;
			public double MaxLow=double.MinValue;
			public char IsSignalBar;
			public DateTime PrintTime = DateTime.MinValue;
			public HistoData(double _histo, double _minhigh, double _maxlow, char _isSignalBar, DateTime _printTime){Val=_histo; MinHigh=_minhigh; MaxLow=_maxlow; IsSignalBar=_isSignalBar; PrintTime=_printTime;}
		}
		#region Variables 1
		private string   TimeFrameText = string.Empty;
		private bool     SpeechEnabled = false;
		private string NL = Environment.NewLine;
		private int MarkersThisBar = 0;

		private Brush LongRacingStripeBrush = null;
		private Brush ShortRacingStripeBrush = null;
		private SharpDX.Direct2D1.Brush[] PlotBrushDXes50pct = null;
		private SharpDX.Direct2D1.Brush PeakTimesBrushDX   = null;
		private SharpDX.Direct2D1.Brush ChannelBkgBrushDX  = null;
		private SharpDX.Direct2D1.Brush ExcursionLevel1_BrushDX = null;
		private SharpDX.Direct2D1.Brush ExcursionLevel2_BrushDX = null;
		private SharpDX.Direct2D1.Brush ExcursionLevel3_BrushDX = null;
		private SharpDX.Direct2D1.Brush DownMomentumBkg_BrushDX = null;
		private SharpDX.Direct2D1.Brush UpMomentumBkg_BrushDX   = null;
		private SharpDX.Direct2D1.Brush PredictionOscillatorBrushDX = null;
		private SharpDX.Direct2D1.Brush ChartBackgroundBrushDX = null;
//		private SharpDX.Direct2D1.Brush VMDLabelDotBrushDX = null;
//		private SharpDX.Direct2D1.Brush RSILabelDotBrushDX = null;
//		private SharpDX.Direct2D1.Brush CCILabelDotBrushDX = null;
//		private SharpDX.Direct2D1.Brush StochLabelDotBrushDX = null;
//		private SharpDX.Direct2D1.Brush MACDLabelDotBrushDX = null;
//		private SharpDX.Direct2D1.Brush FisherLabelDotBrushDX = null;
		SortedDictionary<ARC_CycleForecaster_AnalysisType,SharpDX.Direct2D1.Brush> LabelDotBrushDX_dict = new SortedDictionary<ARC_CycleForecaster_AnalysisType,SharpDX.Direct2D1.Brush>();
		public List<ARC_CycleForecaster_AnalysisType> enumAnalysisTypes = new List<ARC_CycleForecaster_AnalysisType>();

		private int ACTIVEUP_HISTO_PLOT_ID = 0;
		private int ACTIVEDOWN_HISTO_PLOT_ID = 0;
		private int THLEVEL_PLOT_ID = 0;
		private int BHLEVEL_PLOT_ID = 0;
		private int BBUpper_PLOT_ID = 0;
		private int BBLower_PLOT_ID = 0;
		private int BBline_PLOT_ID = 0;
		private int BBdot_PLOT_ID = 0;

		private int CCILINE_PLOT_ID = 0;
		private int RSILINE_PLOT_ID = 0;
		private int RSIAVGLINE_PLOT_ID = 0;
		private int RSSLINE_PLOT_ID = 0;
		private int MACDLINE_PLOT_ID = 0;
		private int MACDSIGNALLINE_PLOT_ID = 0;
		private int MACDDIFFHISTO_PLOT_ID = 0;
		private int RVILINE_PLOT_ID = 0;
		private int STOCHDLINE_PLOT_ID = 0;
		private int STOCHKLINE_PLOT_ID = 0;
		private int FISHERLINE_PLOT_ID = 0;

		private int DAY_OF_WEEK_OF_LAST_BAR = -1;
		private List<int>			PlotIDsToHide = null;
		private Series<double>		ExcursionSeries;
		private Series<double>		PlotA, PlotB, PlotC;

		private bool isExcursionMasterOn = false;
		private RSI rsi;
		private StochasticsFast stoch;
		private ATR atr256;
		private SMA sma65;
		private FisherTransform fisher;
#if RSS_AND_RVI
		private RSS rss;
		private RVI rvi;
#endif
		private bool IsDebug = true;
		#endregion

		#region Variables 2
        private MACD MACD1;
        private MACD MACD2;
        private MACD MACD3;
        private MACD MACD4;
		private MACD macd;
	// Wizard generated variables
		private double pMinHighPeakForValidMarker = 0.001;
		private double pMaxLowPeakForValidMarker = -0.001;
		private bool   ShowMarkers = false;
		private int    pMarkerSeparation = 3;

		private int    pWeeksToGoBack = 1;
		private Brush  pLongMarkerColor = Brushes.Lime;
		private Brush  pShortMarkerColor = Brushes.Magenta;
		private int    MaxWeeksAccessible = 0;
		private string DataShortageMsg = string.Empty;

		private string pZeroTimeStr="0:00";
		// User defined variables (add any user defined variables below)
//		private double[,]  CountsHisto = new double [7,SLICES_MAX]; //one element for each minute in the day
//		private int[,]     Averager = new int [7,SLICES_MAX]; //one element for each CountsHisto
		private DateTime   ZeroTime = DateTime.MinValue;
//		private int        PriorDay=0, slice=0, maxslice=-1, DayOfWk=0;
//		private int[]      DayCount  = new int[7];
		private double     TodayOpen = double.MinValue;//, ma, ma1, ma0, p;
		private double	   OpenGap   = double.MinValue;
		private bool       RunInit=true;
//		private string     AnalysisDesc="", TableHeader="";
		private int        relativebar = 0;
		private static	   DateTime PredictionTimeToSearchFor;
		private DateTime   PriorDayDT = DateTime.MinValue;
		private DateTime   EarliestDay = DateTime.MinValue;
		#endregion

		#region Variables 3
		private DateTime TimeAtLaunch = NinjaTrader.Core.Globals.Now, then, now;
		private TimeSpan SinceLaunch;
		private DateTime TimeOfError  = DateTime.MinValue;
		private string ErrorMsg = "", debug_file=string.Empty;
		private bool Debug = false;

		private bool InZone = false;
		private int  line = 0;
		private bool SoundsAreActive = false;
		private int  SoundAlertBar = 0;

		private int longs  = 0;
		private int shorts = 0;
		private SortedDictionary<long,string> CSVcontents = new SortedDictionary<long,string>();
		private string CSVfilename = string.Empty;
		private bool MktAnalyzerDataWritten = false;

		private bool RemoveDaysAgoMsg		= false;
		private DateTime    LastWeekKey		= DateTime.MinValue;
		private string      LogFileName		= System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NScycforc_log.txt");
		private double      MinutesPerBar	= 1;
		private Series<int> nextSignal;

		//private string FileName= System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ninjadump.txt");
private DateTime T1=DateTime.MinValue;
private DateTime T2=DateTime.MinValue;
		private List<string> PrintThese=new List<string>();
		#endregion

		#region -- AnalysisSet --
		private class AnalysisSet {
			public SortedDictionary<DateTime,HistoData> GaplessHisto;
			public SortedDictionary<DateTime,double> CoreData;
			public List<DateTime>  FutureHistoKeys = new List<DateTime>();  //these are used in the Plot method
			public List<HistoData> HistoDataList = new List<HistoData>();
			public int Sign1 = 0;
			public DateTime        DTlastHistoPeakCalc = DateTime.MinValue;
			public List<DateTime>  HistoHighPeaks, HistoLowPeaks;
			public List<TimePrice> HighPeaksToday, LowPeaksToday;
			public SortedDictionary<DateTime,double> LongTimeLabels;
			public SortedDictionary<DateTime,double> ShortTimeLabels;
			public double FutureHistoMax = 0;
			public double FutureHistoMin = 0;
			public Series<double> Histo;
			public Series<double> ShiftedHisto;
			public List<double>	ShiftedHistoAbs;
			public bool NewDayFlag;
			public DayOfWeek YesterdayDOW;

			public AnalysisSet(){
			}
		}
		private SortedDictionary<ARC_CycleForecaster_AnalysisType, AnalysisSet> 
					AnalysisSets = new SortedDictionary<ARC_CycleForecaster_AnalysisType, AnalysisSet>();
		private AnalysisSet CurrentASet;
		#endregion
		private List<int> MultiSigBuyClusters  = new List<int>();
		private List<int> MultiSigSellClusters = new List<int>();

		#region -- BB region --
        private StdDev SDBB;
		private MACD BollingerMACD;
		#endregion

		private bool   RecalculateButtonHit = true;

		private DateTime StartOfNextSession = DateTime.MinValue;
		private bool     Is24HrSession      = false;

		string lastprint = string.Empty;
		private void PrintOnce(string s){
			if(s!=lastprint) Print(s);
			lastprint=s;
		}

		#region -- UI menu variables -------------------------------------------------------
        private Menu MenuControlContainer;
		private MenuItem miExcursionLevelsMaster, miExcursionLevels1, miExcursionLevels2, miExcursionLevels3, miShowHideBollingerBands, miRecalculate1;
        private MenuItem MenuControl, miAvgMFELongs, miAvgMFEShorts, miAvgMFEAll, miAvgPtsLongs, miAvgPtsShorts;
        private MenuItem miAvgMAELongs, miAvgMAEShorts, miAvgMAEAll;
		private MenuItem miAnalysisType_CCIperiod, miAnalysisType_RSIperiod, miAnalysisType_Dperiod, miAnalysisType_Kperiod, miAnalysisType_MACDfast, miAnalysisType_MACDslow, miAnalysisType_RSSLength, miAnalysisType_RSSperiod1, miAnalysisType_RSSperiod2, miAnalysisType_FisherPeriod, miAnalysisType_RVIperiod;
		private MenuItem miAnalysisType_SubMenu, miViewState, miExcursionLevels, miRacingStripeDirection;
		private SortedDictionary<string, MenuItem> miAnalysisTypes = new SortedDictionary<string, MenuItem>();
		private ComboBox comboExcursionStyle;
		private string toolbarname = "ARCCFTB", uID;
        private bool isToolBarButtonAdded = false;
        private Chart chartWindow;
        private Grid indytoolbar;

		#endregion
//=====================================================================================================
		private void CalculateStatistics(KeyValuePair<DateTime,HistoData> entry, KeyValuePair<DateTime,HistoData> exit, char Type, ref double[] Stats){
			#region -- Calculate Statistics --
			var Entryabar = Bars.GetBar(entry.Value.PrintTime);
			var Exitabar  = Bars.GetBar(exit.Value.PrintTime);
			if(Entryabar >= BarsArray[0].Count-2 || Exitabar >= BarsArray[0].Count-2) return;
			double entryPrice = Closes[0].GetValueAt(Entryabar);
			double mae = entryPrice;
			double mfe = entryPrice;
			double netpts = 0;
			for(int abar = Entryabar; abar<=Exitabar; abar++){
				if(Type=='S'){
					mae = Math.Max(Highs[0].GetValueAt(abar),mae);
					mfe = Math.Min(Lows[0].GetValueAt(abar),mfe);
					netpts = entryPrice-Closes[0].GetValueAt(abar);
				}else if(Type=='L'){
					mfe = Math.Max(Highs[0].GetValueAt(abar),mfe);
					mae = Math.Min(Lows[0].GetValueAt(abar),mae);
					netpts = Closes[0].GetValueAt(abar)-entryPrice;
				}
			}
//Print(string.Format("bar{0} {1} to {2}: ${3}  mae: {4}  mfe: {5}",Entryabar, entry.Value.PrintTime, exit.Value.PrintTime, entryPrice, mae, mfe));
			Stats[0] = Stats[0]+1;
			Stats[1] = Stats[1]+Math.Abs(mae-entryPrice);
			Stats[2] = Stats[2]+Math.Abs(mfe-entryPrice);
			Stats[3] = Stats[3]+netpts;
			#endregion
		}
//=====================================================================================================
		private void addToolBar(){
			#region -- addToolBar ------------------------------------------------------------------
			MenuControlContainer = new System.Windows.Controls.Menu { Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Center };
			MenuControl = new MenuItem {Name="CycFor"+uID,Header = pButtonText, BorderThickness = new Thickness(2), BorderBrush = Brushes.Yellow, Foreground = Brushes.Pink, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			MenuControl.GotFocus += delegate(object o, RoutedEventArgs e){
				#region -- Calculate Averages --
				{
					ChartControl.Dispatcher.InvokeAsync((Action)(() =>{
						List<KeyValuePair<DateTime, HistoData>> sigs = null;
						int lastindex = 0;
						if(this.pIsMultiSignal){
							if (DrawObjects != null && DrawObjects.Count > 0){
								sigs = new List<KeyValuePair<DateTime, HistoData>>();
								List<IDrawingTool> objects = DrawObjects.Where(arr => arr.Anchors.Count() > 0 && arr.Tag.Contains("nscf_")).ToList();
								foreach(var tool in objects){
//if(IsDebug) Print(tool.ToString()+"  tag: "+tool.Tag);
									ChartAnchor anchor = tool.Anchors.FirstOrDefault();
									int index = Convert.ToInt32(anchor.SlotIndex);
									if(tool.Tag.EndsWith("L") && index!=lastindex){
										var tx = BarsArray[0].GetTime(index);
										sigs.Add(new KeyValuePair<DateTime,HistoData>(tx, new HistoData(0, 0, 0,'L',tx)));
										lastindex = index;
									}
									else if(tool.Tag.EndsWith("S") && index!=lastindex){
										var tx = BarsArray[0].GetTime(index);
										sigs.Add(new KeyValuePair<DateTime,HistoData>(tx, new HistoData(0, 0, 0,'S',tx)));
										lastindex = index;
									}
								}
							}
						}else{
							sigs = CurrentASet.GaplessHisto.Where(k=>k.Value.IsSignalBar != ' ').ToList();
						}
						if(sigs==null) return;
						double[] LongStats = new double[4]{0,0,0,0};//count, sumMAE, sumMFE, net
						double[] ShortStats = new double[4]{0,0,0,0};//count, sumMAE, sumMFE, net
						KeyValuePair<DateTime,HistoData> end;

//ClearOutputWindow();
//Print("Bars.Count: "+BarsArray[0].Count);
						foreach(var s in sigs){
							if(s.Value.IsSignalBar=='S'){//a short signal found
								//Get next 'L' signal...this is the reversal from the 'S'
								try{
									end = sigs.First(k=>k.Value.PrintTime > s.Value.PrintTime && k.Value.IsSignalBar=='L');
									CalculateStatistics(s, end, 'S', ref ShortStats);
								}catch{}
							}
							if(s.Value.IsSignalBar=='L'){//a short signal found
								//Get next 'S' signal...this is the reversal from the 'L'
								try{
									end = sigs.First(k=>k.Value.PrintTime > s.Value.PrintTime && k.Value.IsSignalBar=='S');
									CalculateStatistics(s, end, 'L', ref LongStats);
								}catch{}
							}
						}
						double t = 0;
						if(LongStats[0]>0){
							t = Math.Round((LongStats[1]/LongStats[0])/TickSize,1);
							miAvgMAELongs.Header="Longs MAE: " + t+" = "+(t*Instrument.MasterInstrument.PointValue*TickSize).ToString("C");
							t = Math.Round((LongStats[2]/LongStats[0])/TickSize,1);
							miAvgMFELongs.Header="Longs MFE: " + t+" = "+(t*Instrument.MasterInstrument.PointValue*TickSize).ToString("C");
							t = Math.Round((LongStats[3]/LongStats[0])/TickSize,1);
							if(t>0)
								miAvgPtsLongs.Header="Longs Pts: +" + t+" = "+(t*Instrument.MasterInstrument.PointValue*TickSize).ToString("C");
							else
								miAvgPtsLongs.Header="Longs Pts: " + t+" = "+(t*Instrument.MasterInstrument.PointValue*TickSize).ToString("C");
						}
						if(ShortStats[0]>0){
							t = Math.Round((ShortStats[1]/ShortStats[0])/TickSize,1);
							miAvgMAEShorts.Header="Shorts MAE: " + t+" = "+(t*Instrument.MasterInstrument.PointValue*TickSize).ToString("C");
							t = Math.Round((ShortStats[2]/ShortStats[0])/TickSize,1);
							miAvgMFEShorts.Header="Shorts MFE: " + t+" = "+(t*Instrument.MasterInstrument.PointValue*TickSize).ToString("C");
							t = Math.Round((ShortStats[3]/ShortStats[0])/TickSize,1);
							if(t>0)
								miAvgPtsShorts.Header="Shorts Pts: +" + t+" = "+(t*Instrument.MasterInstrument.PointValue*TickSize).ToString("C");
							else
								miAvgPtsShorts.Header="Shorts Pts: " + t+" = "+(t*Instrument.MasterInstrument.PointValue*TickSize).ToString("C");
						}
						double total = LongStats[0]+ShortStats[0];
						if(total>0){
							t = Math.Round(((LongStats[1]+ShortStats[1])/total)/TickSize,1);
							miAvgMAEAll.Header="Longs&Shorts MAE: " + t+" = "+(t*Instrument.MasterInstrument.PointValue*TickSize).ToString("C");
							t = Math.Round(((LongStats[2]+ShortStats[2])/total)/TickSize,1);
							miAvgMFEAll.Header="Longs&Shorts MFE: " + t+" = "+(t*Instrument.MasterInstrument.PointValue*TickSize).ToString("C");
						}
					}));
				}
				#endregion
			};
			MenuControlContainer.Items.Add(MenuControl);
	//- - - - - - - - - - - - -
			#region -- miViewState --
			miViewState = new MenuItem {Header = "View State:  "+pViewState.ToString(), Name="VS" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miViewState.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if(pViewState == ARC_CycleForecaster_ViewStates.Data)         pViewState = ARC_CycleForecaster_ViewStates.Trading;
				else if(pViewState == ARC_CycleForecaster_ViewStates.Trading) pViewState = ARC_CycleForecaster_ViewStates.Data;
				miViewState.Header = "Vew State:  "+pViewState.ToString();
				InformUserAboutRecalculation();
				//ForceRefresh();
				};
			miViewState.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta > 0){
					if(pViewState == ARC_CycleForecaster_ViewStates.Data)         pViewState = ARC_CycleForecaster_ViewStates.Trading;
					else if(pViewState == ARC_CycleForecaster_ViewStates.Trading) pViewState = ARC_CycleForecaster_ViewStates.Data;
				}else{
					if(pViewState == ARC_CycleForecaster_ViewStates.Data)         pViewState = ARC_CycleForecaster_ViewStates.Trading;
					else if(pViewState == ARC_CycleForecaster_ViewStates.Trading) pViewState = ARC_CycleForecaster_ViewStates.Data;
				}
				miViewState.Header = "View State:  "+pViewState.ToString();
				InformUserAboutRecalculation();
				//ForceRefresh();
			};
			#endregion

			MenuControl.Items.Add(miViewState);
	//- - - - - - - - - - - - - 
			miAnalysisType_SubMenu = new MenuItem { 
				Header = "Analysis Type:  "+(this.IsMultiSignal ? "MultiSig ("+this.pAnalysisType.ToString()+")" : pAnalysisType.ToString()), 
				Name="at" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
			#region -- Analysis Types -----------------
			var enumAnalysisTypes = Enum.GetNames(typeof(ARC_CycleForecaster_AnalysisType)).ToList();
			enumAnalysisTypes.Sort();
	//- - - - - - - - - - - - - 
			bool isCurrentSelection = false;
			#region -- Add MultiSignal to top of AnalysisType menu --
			miAnalysisTypes["MultiSignal"] = new MenuItem {Header = "MultiSignal", Foreground = Brushes.Black, FontWeight = pIsMultiSignal ? FontWeights.ExtraBold : FontWeights.Normal , StaysOpenOnClick = true };
			miAnalysisTypes["MultiSignal"].Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pIsMultiSignal = !pIsMultiSignal;
				if(pIsMultiSignal)
					miAnalysisTypes["MultiSignal"].FontWeight = FontWeights.ExtraBold;
				else
					miAnalysisTypes["MultiSignal"].FontWeight = FontWeights.Normal;
				InformUserAboutRecalculation();
			};
			miAnalysisType_SubMenu.Items.Add(miAnalysisTypes["MultiSignal"]);
			#endregion
			#region -- MultiSignal Arrow Count --
			var miMultSigArrowCount = new MenuItem {Header = "MultSig Arrow Count:  "+this.pMultiSignalArrowCount.ToString(), Name="MSac" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miMultSigArrowCount.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled = true;
				if(e.Delta>0) pMultiSignalArrowCount++; 
				else {
					if(pMultiSignalArrowCount==1) return; else pMultiSignalArrowCount--;
				}
				miMultSigArrowCount.Header = "MultSig Arrow Count:  "+this.pMultiSignalArrowCount.ToString();
				InformUserAboutRecalculation();
				ForceRefresh();
			};
			miAnalysisType_SubMenu.Items.Add(miMultSigArrowCount);
			#endregion
			#region -- MultiSignal BarVariance --
			var miMultSigBarVariance = new MenuItem {Header = "MultSig BarVariance:  "+this.pMultiSignalBarVariance.ToString(), Name="MSbv" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miMultSigBarVariance.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled = true;
				if(e.Delta>0) pMultiSignalBarVariance++; 
				else {
					if(pMultiSignalBarVariance==1) return; else pMultiSignalBarVariance--;
				}
				miMultSigBarVariance.Header = "MultSig BarVariance:  "+this.pMultiSignalBarVariance.ToString();
				InformUserAboutRecalculation();
				ForceRefresh();
			};
			miAnalysisType_SubMenu.Items.Add(miMultSigBarVariance);
			#endregion

			miAnalysisType_SubMenu.Items.Add(new Separator());

			foreach(string et in enumAnalysisTypes) {
				isCurrentSelection = this.pAnalysisType.ToString() == et;
				miAnalysisTypes[et] = new MenuItem {Header = et, Foreground = Brushes.Black, FontWeight = isCurrentSelection ? FontWeights.ExtraBold : FontWeights.Normal , StaysOpenOnClick = true };
				if(!isCurrentSelection)
					miAnalysisTypes[et].ToolTip = "Left-click here to select "+et;
				if(et == "VMDivergence"){
					#region -- Add VMDivergence --
					miAnalysisTypes[et].Click += delegate (object o, RoutedEventArgs e){
						e.Handled = true;
						miAnalysisTypes[pAnalysisType.ToString()].ToolTip = "Left-click here to select "+pAnalysisType.ToString();
						miAnalysisTypes[et].ToolTip = "";
						this.pAnalysisType = ARC_CycleForecaster_AnalysisType.VMDivergence;
						foreach(var mi in miAnalysisTypes.Keys) miAnalysisTypes[mi].FontWeight = FontWeights.Normal;
						miAnalysisTypes[et].FontWeight = FontWeights.ExtraBold;
						InformUserAboutRecalculation();
					};
					miAnalysisType_SubMenu.Items.Add(miAnalysisTypes[et]);
					#endregion
					miAnalysisType_SubMenu.Items.Add(new Separator());
				}
				else if(et == "CCI"){
					#region -- Add CCI menu item, and CCI period numerical up/down --
					miAnalysisTypes[et].Click += delegate (object o, RoutedEventArgs e){
						e.Handled = true;
						miAnalysisTypes[pAnalysisType.ToString()].ToolTip = "Left-click here to select "+pAnalysisType.ToString();
						miAnalysisTypes[et].ToolTip = "";
						this.pAnalysisType = ARC_CycleForecaster_AnalysisType.CCI;
						foreach(var mi in miAnalysisTypes.Keys) miAnalysisTypes[mi].FontWeight = FontWeights.Normal;
						miAnalysisTypes[et].FontWeight = FontWeights.ExtraBold;
						InformUserAboutRecalculation();
					};
					miAnalysisType_CCIperiod = new MenuItem { Header = this.pCCIperiod.ToString() + " - CCI period", Name = "CCIperiod", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
					miAnalysisType_CCIperiod.MouseWheel += delegate(object o, MouseWheelEventArgs e){
						e.Handled=true;
						if(e.Delta > 0){
							this.pCCIperiod++;
						}else{
							this.pCCIperiod = Math.Max(1, pCCIperiod-1);
						}
						miAnalysisType_CCIperiod.Header = this.pCCIperiod.ToString() + " - CCI period";
						if(pAnalysisType.ToString() == et){
							InformUserAboutRecalculation();
						}
					};
					miAnalysisType_SubMenu.Items.Add(miAnalysisTypes[et]);
					miAnalysisType_SubMenu.Items.Add(miAnalysisType_CCIperiod);
					#endregion -----------------------------------------------------------------
					miAnalysisType_SubMenu.Items.Add(new Separator());
				}
				else if(et == "RSI"){
					#region -- Add RSI menu item, and RSI period numerical up/down --
					miAnalysisTypes[et].Click += delegate (object o, RoutedEventArgs e){
						e.Handled = true;
						miAnalysisTypes[pAnalysisType.ToString()].ToolTip = "Left-click here to select "+pAnalysisType.ToString();
						miAnalysisTypes[et].ToolTip = "";
						this.pAnalysisType = ARC_CycleForecaster_AnalysisType.RSI;
						foreach(var mi in miAnalysisTypes.Keys) miAnalysisTypes[mi].FontWeight = FontWeights.Normal;
						miAnalysisTypes[et].FontWeight = FontWeights.ExtraBold;
						InformUserAboutRecalculation();
						System.Windows.Forms.SendKeys.SendWait("{F5}");
					};
					miAnalysisType_RSIperiod = new MenuItem { Header = this.pRSIperiod.ToString()+" - RSI period", Name = "RSIperiod", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
					miAnalysisType_RSIperiod.MouseWheel += delegate(object o, MouseWheelEventArgs e){
						e.Handled=true;
						if(e.Delta > 0){
							this.pRSIperiod++;
						}else{
							this.pRSIperiod = Math.Max(1, pRSIperiod-1);
						}
						miAnalysisType_RSIperiod.Header = this.pRSIperiod.ToString()+" - RSI period";
						if(pAnalysisType.ToString() == et){
							InformUserAboutRecalculation();
						}
					};
					miAnalysisType_SubMenu.Items.Add(miAnalysisTypes[et]);
					miAnalysisType_SubMenu.Items.Add(miAnalysisType_RSIperiod);
					#endregion -----------------------------------------------------------------
					miAnalysisType_SubMenu.Items.Add(new Separator());
				}
				else if(et == "Stoch"){
					#region -- Add Stoch menu item, and Stoch D and K period numerical up/down --
					miAnalysisTypes[et].Click += delegate (object o, RoutedEventArgs e){
						e.Handled = true;
						miAnalysisTypes[pAnalysisType.ToString()].ToolTip = "Left-click here to select "+pAnalysisType.ToString();
						miAnalysisTypes[et].ToolTip = "";
						this.pAnalysisType = ARC_CycleForecaster_AnalysisType.Stoch;
						foreach(var mi in miAnalysisTypes.Keys) miAnalysisTypes[mi].FontWeight = FontWeights.Normal;
						miAnalysisTypes[et].FontWeight = FontWeights.ExtraBold;
						InformUserAboutRecalculation();
					};
					miAnalysisType_Dperiod = new MenuItem { Header = this.pDperiod.ToString()+" - D period", Name = "Dperiod", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
					miAnalysisType_Dperiod.MouseWheel += delegate(object o, MouseWheelEventArgs e){
						e.Handled=true;
						if(e.Delta > 0){
							this.pDperiod++;
						}else{
							this.pDperiod = Math.Max(1, pDperiod-1);
						}
						miAnalysisType_Dperiod.Header = this.pDperiod.ToString()+" - D period";
						if(pAnalysisType.ToString() == et){
							InformUserAboutRecalculation();
						}
					};
					miAnalysisType_Kperiod = new MenuItem { Header = this.pKperiod.ToString()+" - K period", Name = "Kperiod", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
					miAnalysisType_Kperiod.MouseWheel += delegate(object o, MouseWheelEventArgs e){
						e.Handled=true;
						if(e.Delta > 0){
							this.pKperiod++;
						}else{
							this.pKperiod = Math.Max(1, pKperiod-1);
						}
						miAnalysisType_Kperiod.Header = this.pKperiod.ToString()+" - K period";
						if(pAnalysisType.ToString() == et){
							InformUserAboutRecalculation();
						}
					};
					miAnalysisType_SubMenu.Items.Add(miAnalysisTypes[et]);
					miAnalysisType_SubMenu.Items.Add(miAnalysisType_Dperiod);
					miAnalysisType_SubMenu.Items.Add(miAnalysisType_Kperiod);
					#endregion -----------------------------------------------------------------
					miAnalysisType_SubMenu.Items.Add(new Separator());
				}
				else if(et.StartsWith("MACD")){
					#region -- Add MACD menu item, and MACD fast/slow period numerical up/down --
					miAnalysisTypes[et].Click += delegate (object o, RoutedEventArgs e){
						e.Handled = true;
						miAnalysisTypes[pAnalysisType.ToString()].ToolTip = "Left-click here to select "+pAnalysisType.ToString();
						miAnalysisTypes[et].ToolTip = "";
						this.pAnalysisType = ARC_CycleForecaster_AnalysisType.MACD;
						foreach(var mi in miAnalysisTypes.Keys) miAnalysisTypes[mi].FontWeight = FontWeights.Normal;
						miAnalysisTypes[et].FontWeight = FontWeights.ExtraBold;
						InformUserAboutRecalculation();
					};
					miAnalysisType_MACDfast = new MenuItem { Header = this.pMACDfast.ToString()+" - fast period", Name = "MACDfastperiod", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
					miAnalysisType_MACDfast.MouseWheel += delegate(object o, MouseWheelEventArgs e){
						e.Handled=true;
						if(e.Delta > 0){
							this.pMACDfast++;
						}else{
							this.pMACDfast = Math.Max(1, pMACDfast-1);
						}
						miAnalysisType_MACDfast.Header = this.pMACDfast.ToString()+" - fast period";
						if(pAnalysisType.ToString() == et){
							InformUserAboutRecalculation();
						}
					};

					miAnalysisType_MACDslow = new MenuItem { Header = this.pMACDslow.ToString()+" - slow period", Name = "MACDslowperiod", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
					miAnalysisType_MACDslow.MouseWheel += delegate(object o, MouseWheelEventArgs e){
						e.Handled=true;
						if(e.Delta > 0){
							this.pMACDslow++;
						}else{
							this.pMACDslow = Math.Max(1, pMACDslow-1);
						}
						miAnalysisType_MACDslow.Header = this.pMACDslow.ToString()+" - slow period";
						if(pAnalysisType.ToString() == et){
							InformUserAboutRecalculation();
						}
					};
					miAnalysisType_SubMenu.Items.Add(miAnalysisTypes[et]);
					miAnalysisType_SubMenu.Items.Add(miAnalysisType_MACDfast);
					miAnalysisType_SubMenu.Items.Add(miAnalysisType_MACDslow);
					#endregion -----------------------------------------------------------------
					miAnalysisType_SubMenu.Items.Add(new Separator());
				}
				else if(et == "Fisher"){
					#region -- Add Fisher menu item, and Fisher period numerical up/down --
					miAnalysisTypes[et].Click += delegate (object o, RoutedEventArgs e){
						e.Handled = true;
						miAnalysisTypes[pAnalysisType.ToString()].ToolTip = "Left-click here to select "+pAnalysisType.ToString();
						miAnalysisTypes[et].ToolTip = "";
						this.pAnalysisType = ARC_CycleForecaster_AnalysisType.Fisher;
						foreach(var mi in miAnalysisTypes.Keys) miAnalysisTypes[mi].FontWeight = FontWeights.Normal;
						miAnalysisTypes[et].FontWeight = FontWeights.ExtraBold;
						InformUserAboutRecalculation();
					};
					miAnalysisType_FisherPeriod = new MenuItem { Header = this.pFisherPeriod.ToString()+" - Fisher period", Name = "FisherPeriod", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
					miAnalysisType_FisherPeriod.MouseWheel += delegate(object o, MouseWheelEventArgs e){
						e.Handled=true;
						if(e.Delta > 0){
							this.pFisherPeriod++;
						}else{
							this.pFisherPeriod = Math.Max(1, pFisherPeriod-1);
						}
						miAnalysisType_FisherPeriod.Header = this.pFisherPeriod.ToString()+" - Fisher period";
						if(pAnalysisType.ToString() == et){
							InformUserAboutRecalculation();
						}
					};
					miAnalysisType_SubMenu.Items.Add(miAnalysisTypes[et]);
					miAnalysisType_SubMenu.Items.Add(miAnalysisType_FisherPeriod);
					#endregion -----------------------------------------------------------------
					miAnalysisType_SubMenu.Items.Add(new Separator());
				}
#if RSS_AND_RVI
				else if(et == "RSS"){
					#region -- Add RSS menu item, and RSS Length, Period1 and Period2 numerical up/down --
					miAnalysisTypes[et].Click += delegate (object o, RoutedEventArgs e){
						e.Handled = true;
						miAnalysisTypes[pAnalysisType.ToString()].ToolTip = "Left-click here to select "+pAnalysisType.ToString();
						miAnalysisTypes[et].ToolTip = "";
						this.pAnalysisType = ARC_CycleForecaster_AnalysisType.RSS;
						foreach(var mi in miAnalysisTypes.Keys) miAnalysisTypes[mi].FontWeight = FontWeights.Normal;
						miAnalysisTypes[et].FontWeight = FontWeights.ExtraBold;
						InformUserAboutRecalculation();
					};
					miAnalysisType_RSSLength = new MenuItem { Header = this.pRSSLength.ToString()+" - RSS length", Name = "RSSLength", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
					miAnalysisType_RSSLength.MouseWheel += delegate(object o, MouseWheelEventArgs e){
						e.Handled=true;
						if(e.Delta > 0){
							this.pRSSLength++;
						}else{
							this.pRSSLength = Math.Max(1, pRSSLength-1);
						}
						miAnalysisType_RSSLength.Header = this.pRSSLength.ToString()+" - RSS length";
						if(pAnalysisType.ToString() == et){
							InformUserAboutRecalculation();
						}
					};

					miAnalysisType_RSSperiod1 = new MenuItem { Header = this.pRSSperiod1.ToString()+" - RSS period 1", Name = "RSSperiod1", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
					miAnalysisType_RSSperiod1.MouseWheel += delegate(object o, MouseWheelEventArgs e){
						e.Handled=true;
						if(e.Delta > 0){
							this.pRSSperiod1++;
						}else{
							this.pRSSperiod1 = Math.Max(1, pRSSperiod1-1);
						}
						miAnalysisType_RSSperiod1.Header = this.pRSSperiod1.ToString()+" - RSS period 1";
						if(pAnalysisType.ToString() == et){
							InformUserAboutRecalculation();
						}
					};

					miAnalysisType_RSSperiod2 = new MenuItem { Header = this.pRSSperiod2.ToString()+" - RSS period 2", Name = "RSSperiod2", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
					miAnalysisType_RSSperiod2.MouseWheel += delegate(object o, MouseWheelEventArgs e){
						e.Handled=true;
						if(e.Delta > 0){
							this.pRSSperiod2++;
						}else{
							this.pRSSperiod2 = Math.Max(1, pRSSperiod2-1);
						}
						miAnalysisType_RSSperiod2.Header = this.pRSSperiod2.ToString()+" - RSS period 2";
						if(pAnalysisType.ToString() == et){
							InformUserAboutRecalculation();
						}
					};
					miAnalysisType_SubMenu.Items.Add(miAnalysisTypes[et]);
					miAnalysisType_SubMenu.Items.Add(miAnalysisType_RSSLength);
					miAnalysisType_SubMenu.Items.Add(miAnalysisType_RSSperiod1);
					miAnalysisType_SubMenu.Items.Add(miAnalysisType_RSSperiod2);
					#endregion -----------------------------------------------------------------
					miAnalysisType_SubMenu.Items.Add(new Separator());
				}
				else if(et == "RVI"){
					#region -- Add RVI menu item, and RVI period numerical up/down --
					miAnalysisTypes[et].Click += delegate (object o, RoutedEventArgs e){
						e.Handled = true;
						miAnalysisTypes[pAnalysisType.ToString()].ToolTip = "Left-click here to select "+pAnalysisType.ToString();
						miAnalysisTypes[et].ToolTip = "";
						this.pAnalysisType = ARC_CycleForecaster_AnalysisType.RVI;
						foreach(var mi in miAnalysisTypes.Keys) miAnalysisTypes[mi].FontWeight = FontWeights.Normal;
						miAnalysisTypes[et].FontWeight = FontWeights.ExtraBold;
						InformUserAboutRecalculation();
					};
					miAnalysisType_RVIperiod = new MenuItem { Header = this.pRVIperiod.ToString()+" - RVI period", Name = "RVIperiod", Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
					miAnalysisType_RVIperiod.MouseWheel += delegate(object o, MouseWheelEventArgs e){
						e.Handled=true;
						if(e.Delta > 0){
							this.pRVIperiod++;
						}else{
							this.pRVIperiod = Math.Max(1, pRVIperiod-1);
						}
						miAnalysisType_RVIperiod.Header = this.pRVIperiod.ToString()+" - RVI period";
						if(pAnalysisType.ToString() == et){
							InformUserAboutRecalculation();
						}
					};
					miAnalysisType_SubMenu.Items.Add(miAnalysisTypes[et]);
					miAnalysisType_SubMenu.Items.Add(miAnalysisType_RVIperiod);
					#endregion -----------------------------------------------------------------
					miAnalysisType_SubMenu.Items.Add(new Separator());
				}
#endif
			}
	//- - - - - - - - - - - - - 
			#endregion
			MenuControl.Items.Add(miAnalysisType_SubMenu);
	//- - - - - - - - - - - - - 
			ShowMarkers = this.pMarkerDirection != ARC_CycleForecaster_MarkerDirection.None; 
			#region -- MarkerDirection --
			var miMarkerDirection = new MenuItem {Header = "Marker Direction:  "+pMarkerDirection.ToString().Replace("Both","Longs & Shorts"), Name="st" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miMarkerDirection.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if(pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Longs)       pMarkerDirection = ARC_CycleForecaster_MarkerDirection.Shorts;
				else if(pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Shorts) pMarkerDirection = ARC_CycleForecaster_MarkerDirection.Both;
				else if(pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Both)   pMarkerDirection = ARC_CycleForecaster_MarkerDirection.None;
				else if(pMarkerDirection == ARC_CycleForecaster_MarkerDirection.None)   pMarkerDirection = ARC_CycleForecaster_MarkerDirection.Longs;
				miMarkerDirection.Header = "Marker Direction:  "+pMarkerDirection.ToString().Replace("Both","Longs & Shorts");
//				var objects = DrawObjects.ToList();
//				foreach (dynamic dob in objects) {
//					if (dob.Tag.Contains("nscf_")) RemoveDrawObject(dob.Tag);
//				}
//				if(pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Both){
//					foreach(var kvp in CurrentASet.GaplessHisto)
//						DrawMarkerThisBar(kvp.Value.IsSignalBar, pAnalysisType, kvp.Value.PrintTime);
//				}else if(pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Longs){
//					foreach(var kvp in CurrentASet.GaplessHisto.Values.Where(k=> k.IsSignalBar=='L'))
//						DrawMarkerThisBar(kvp.IsSignalBar, pAnalysisType, kvp.PrintTime);
//				}else if(pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Shorts){
//					foreach(var kvp in CurrentASet.GaplessHisto.Values.Where(k=> k.IsSignalBar=='S'))
//						DrawMarkerThisBar(kvp.IsSignalBar, pAnalysisType, kvp.PrintTime);
//				}
				ShowMarkers = this.pMarkerDirection != ARC_CycleForecaster_MarkerDirection.None; 
				InformUserAboutRecalculation();
				ForceRefresh();
				};
			miMarkerDirection.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta > 0){
					if(pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Longs)       pMarkerDirection = ARC_CycleForecaster_MarkerDirection.Shorts;
					else if(pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Shorts) pMarkerDirection = ARC_CycleForecaster_MarkerDirection.Both;
					else if(pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Both)   pMarkerDirection = ARC_CycleForecaster_MarkerDirection.None;
					else if(pMarkerDirection == ARC_CycleForecaster_MarkerDirection.None)   pMarkerDirection = ARC_CycleForecaster_MarkerDirection.Longs;
				}else{
					if(pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Longs)       pMarkerDirection = ARC_CycleForecaster_MarkerDirection.None;
					else if(pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Shorts) pMarkerDirection = ARC_CycleForecaster_MarkerDirection.Longs;
					else if(pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Both)   pMarkerDirection = ARC_CycleForecaster_MarkerDirection.Shorts;
					else if(pMarkerDirection == ARC_CycleForecaster_MarkerDirection.None)   pMarkerDirection = ARC_CycleForecaster_MarkerDirection.Both;
				}
				miMarkerDirection.Header = "Marker Direction:  "+pMarkerDirection.ToString().Replace("Both","Longs & Shorts");
//				var objects = DrawObjects.ToList();
//				foreach (dynamic dob in objects) {
//					if (dob.Tag.Contains("nscf_")) RemoveDrawObject(dob.Tag);
//				}
//				if(pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Both){
//					foreach(var kvp in CurrentASet.GaplessHisto){
//						DrawMarkerThisBar(kvp.Value.IsSignalBar, pAnalysisType, kvp.Value.PrintTime);
//					}
//				}else if(pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Longs){
//					var list = CurrentASet.GaplessHisto.Values.Where(k=> k.IsSignalBar=='L').ToList();
//					if(list!=null && list.Count>0)
//						foreach(var kvp in list)
//							DrawMarkerThisBar(kvp.IsSignalBar, pAnalysisType, kvp.PrintTime);
//				}else if(pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Shorts){
//					var list = CurrentASet.GaplessHisto.Values.Where(k=> k.IsSignalBar=='S').ToList();
//					if(list!=null && list.Count>0)
//						foreach(var kvp in list)
//							DrawMarkerThisBar(kvp.IsSignalBar, pAnalysisType, kvp.PrintTime);
//				}
				ShowMarkers = this.pMarkerDirection != ARC_CycleForecaster_MarkerDirection.None; 
				InformUserAboutRecalculation();
				ForceRefresh();
			};
			#endregion
			MenuControl.Items.Add(miMarkerDirection);
	//- - - - - - - - - - - - - 
			MenuControl.Items.Add(new Separator());
			#region -- RacingStripeDirection --
			var miRacingStripeDirection = new MenuItem {Header = "Racing Stripe Direction:  "+pRacingStripeDirection.ToString().Replace("Both","Longs & Shorts"), Name="st" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miRacingStripeDirection.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if(pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.Longs)       pRacingStripeDirection = ARC_CycleForecaster_MarkerDirection.Shorts;
				else if(pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.Shorts) pRacingStripeDirection = ARC_CycleForecaster_MarkerDirection.Both;
				else if(pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.Both)   pRacingStripeDirection = ARC_CycleForecaster_MarkerDirection.None;
				else if(pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.None)   pRacingStripeDirection = ARC_CycleForecaster_MarkerDirection.Longs;
				miRacingStripeDirection.Header = "Racing Stripe Direction:  "+pRacingStripeDirection.ToString().Replace("Both","Longs & Shorts");
				InformUserAboutRecalculation();
				PaintRacingStripes();
//				ForceRefresh();
			};
			miRacingStripeDirection.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta > 0){
					if(pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.Longs)       pRacingStripeDirection = ARC_CycleForecaster_MarkerDirection.Shorts;
					else if(pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.Shorts) pRacingStripeDirection = ARC_CycleForecaster_MarkerDirection.Both;
					else if(pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.Both)   pRacingStripeDirection = ARC_CycleForecaster_MarkerDirection.None;
					else if(pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.None)   pRacingStripeDirection = ARC_CycleForecaster_MarkerDirection.Longs;
				}else{
					if(pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.None)        pRacingStripeDirection = ARC_CycleForecaster_MarkerDirection.Longs;
					else if(pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.Both)   pRacingStripeDirection = ARC_CycleForecaster_MarkerDirection.None;
					else if(pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.Shorts) pRacingStripeDirection = ARC_CycleForecaster_MarkerDirection.Both;
					else if(pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.Longs)  pRacingStripeDirection = ARC_CycleForecaster_MarkerDirection.Shorts;
				}
				miRacingStripeDirection.Header = "Racing Stripe Direction:  "+pRacingStripeDirection.ToString().Replace("Both","Longs & Shorts");
				InformUserAboutRecalculation();
				PaintRacingStripes();
//				ForceRefresh();
			};
			#endregion
			MenuControl.Items.Add(miRacingStripeDirection);
	//- - - - - - - - - - - - - 
			#region -- Racing Stripe Type --
			var miRacingStripeType = new MenuItem {Header = "Racing Stripe Type:  "+pRacingStripeType.ToString(), Name="RS" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miRacingStripeType.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				if(     pRacingStripeType == ARC_CycleForecaster_RacingStripeType.BothPanels) pRacingStripeType = ARC_CycleForecaster_RacingStripeType.Subpanel;
				else if(pRacingStripeType == ARC_CycleForecaster_RacingStripeType.Subpanel)   pRacingStripeType = ARC_CycleForecaster_RacingStripeType.BothPanels;
				miRacingStripeType.Header = "Racing Stripe Type:  "+pRacingStripeType.ToString();
				InformUserAboutRecalculation(true);
				PaintRacingStripes();
//				ForceRefresh();
			};
			miRacingStripeType.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled = true;
				if(e.Delta > 0){
					if(     pRacingStripeType == ARC_CycleForecaster_RacingStripeType.BothPanels) pRacingStripeType = ARC_CycleForecaster_RacingStripeType.Subpanel;
					else if(pRacingStripeType == ARC_CycleForecaster_RacingStripeType.Subpanel)   pRacingStripeType = ARC_CycleForecaster_RacingStripeType.BothPanels;
				}else{
					if(     pRacingStripeType == ARC_CycleForecaster_RacingStripeType.Subpanel)   pRacingStripeType = ARC_CycleForecaster_RacingStripeType.BothPanels;
					else if(pRacingStripeType == ARC_CycleForecaster_RacingStripeType.BothPanels) pRacingStripeType = ARC_CycleForecaster_RacingStripeType.BothPanels;
				}
				miRacingStripeType.Header = "Racing Stripe Type:  "+pRacingStripeType.ToString();
				InformUserAboutRecalculation(true);
				PaintRacingStripes();
//				ForceRefresh();
			};
			MenuControl.Items.Add(miRacingStripeType);

//			var miRacingStripeLongOpacity = new MenuItem {Header = "Long Racing stripe opacity:  "+this.pLongRacingStripeOpacity.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
//			miRacingStripeLongOpacity.MouseWheel += delegate(object o, MouseWheelEventArgs e){
//				e.Handled=true;
//				if(e.Delta > 0){
//					pLongRacingStripeOpacity = Math.Min(100,pLongRacingStripeOpacity+5);
//				}else{
//					pLongRacingStripeOpacity = Math.Max(0, pLongRacingStripeOpacity-5);
//				}
//				miRacingStripeLongOpacity.Header = "Long Racing stripe opacity:  "+this.pLongRacingStripeOpacity.ToString();
//				InformUserAboutRecalculation();
//			};
//			miRacingStripeLongOpacity.ToolTip = "Set to zero to remove the stripes";
//			MenuControl.Items.Add(miRacingStripeLongOpacity);

//			var miRacingStripeShortOpacity = new MenuItem {Header = "Short Racing stripe opacity:  "+this.pShortRacingStripeOpacity.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
//			miRacingStripeShortOpacity.MouseWheel += delegate(object o, MouseWheelEventArgs e){
//				e.Handled=true;
//				if(e.Delta > 0){
//					pShortRacingStripeOpacity = Math.Min(100,pShortRacingStripeOpacity+5);
//				}else{
//					pShortRacingStripeOpacity = Math.Max(0, pShortRacingStripeOpacity-5);
//				}
//				miRacingStripeShortOpacity.Header = "Short Racing stripe opacity:  "+this.pShortRacingStripeOpacity.ToString();
//				InformUserAboutRecalculation();
//			};
//			miRacingStripeShortOpacity.ToolTip = "Set to zero to remove the stripes";

//			MenuControl.Items.Add(miRacingStripeShortOpacity);
			#endregion
			MenuControl.Items.Add(new Separator());
	//- - - - - - - - - - - - - 
			#region -- Momentum background --
			var miMomentumBkg = new MenuItem {Header = "Momentum Background:  "+(pEnableMomentumBkg?"ON":"OFF"), Name="MB" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miMomentumBkg.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				pEnableMomentumBkg = !pEnableMomentumBkg;
				miMomentumBkg.Header = "Momentum Background:  "+(pEnableMomentumBkg?"ON":"OFF");
				ForceRefresh();
			};
			miMomentumBkg.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled = true;
				pEnableMomentumBkg = !pEnableMomentumBkg;
				miMomentumBkg.Header = "Momentum Background:  "+(pEnableMomentumBkg?"ON":"OFF");
				ForceRefresh();
			};
			MenuControl.Items.Add(miMomentumBkg);
	//- - - - - - - - - - - - - 
//			var miMomUpBkgOpacity = new MenuItem {Header = "Long background opacity:  "+this.pUpBkgOpacity.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
//			miMomUpBkgOpacity.MouseWheel += delegate(object o, MouseWheelEventArgs e){
//				e.Handled=true;
//				if(e.Delta > 0){
//					pUpBkgOpacity = Math.Min(100,pUpBkgOpacity+5);
//				}else{
//					pUpBkgOpacity = Math.Max(0, pUpBkgOpacity-5);
//				}
//				miMomUpBkgOpacity.Header = "Long background opacity:  "+this.pUpBkgOpacity.ToString();
//				ForceRefresh();
//			};
//			MenuControl.Items.Add(miMomUpBkgOpacity);
//	//- - - - - - - - - - - - - 
//			var miMomDownBkgOpacity = new MenuItem {Header = "Short background opacity:  "+this.pDownBkgOpacity.ToString(), Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
//			miMomDownBkgOpacity.MouseWheel += delegate(object o, MouseWheelEventArgs e){
//				e.Handled=true;
//				if(e.Delta > 0){
//					pDownBkgOpacity = Math.Min(100,pDownBkgOpacity+5);
//				}else{
//					pDownBkgOpacity = Math.Max(0, pDownBkgOpacity-5);
//				}
//				miMomDownBkgOpacity.Header = "Short background opacity:  "+this.pDownBkgOpacity.ToString();
//				ForceRefresh();
//			};
//			MenuControl.Items.Add(miMomDownBkgOpacity);
			#endregion
	//- - - - - - - - - - - - - 
			MenuControl.Items.Add(new Separator());
	//- - - - - - - - - - - - - 
            var miAvg_SubMenu = new MenuItem { Header = "Averages (in ticks)", Name="ASub" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };
			#region -- Longs MFE/MAE Averages -----------------
	//- - - - - - - - - - - - - 
			miAvgMFELongs = new MenuItem {Header = "Longs MFE  N/A", Name="ALmfe" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miAvg_SubMenu.Items.Add(miAvgMFELongs);
	//- - - - - - - - - - - - - 
			miAvgMAELongs = new MenuItem {Header = "Longs MAE  N/A", Name="ALmae" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miAvg_SubMenu.Items.Add(miAvgMAELongs);
	//- - - - - - - - - - - - - 
			miAvgPtsLongs = new MenuItem {Header = "Longs Pts  N/A", Name="ALnet" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
if(IsDebug)	miAvg_SubMenu.Items.Add(miAvgPtsLongs);
			#endregion
	//- - - - - - - - - - - - - 
			miAvg_SubMenu.Items.Add(new Separator());
			#region -- Shorts MFE/MAE Averages -----------------
			miAvgMFEShorts = new MenuItem {Header = "Shorts MFE  N/A", Name="ASmfe" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miAvg_SubMenu.Items.Add(miAvgMFEShorts);
	//- - - - - - - - - - - - - 
			miAvgMAEShorts = new MenuItem {Header = "Shorts MAE  N/A", Name="ASmae" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miAvg_SubMenu.Items.Add(miAvgMAEShorts);
	//- - - - - - - - - - - - - 
			miAvgPtsShorts = new MenuItem {Header = "Shorts Pts  N/A", Name="ASnet" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
if(IsDebug)	miAvg_SubMenu.Items.Add(miAvgPtsShorts);
			#endregion
	//- - - - - - - - - - - - - 
			miAvg_SubMenu.Items.Add(new Separator());
	//- - - - - - - - - - - - - 
			#region -- Longs & Shorts MFE/MAE Averages -----------------
			miAvgMFEAll = new MenuItem {Header = "Longs&Shorts MFE  N/A", Name="ASLmfe" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miAvg_SubMenu.Items.Add(miAvgMFEAll);
	//- - - - - - - - - - - - - 
			miAvgMAEAll = new MenuItem {Header = "Longs&Shorts MAE  N/A", Name="ASLmae" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miAvg_SubMenu.Items.Add(miAvgMAEAll);
			#endregion
	//- - - - - - - - - - - - - 
			MenuControl.Items.Add(miAvg_SubMenu);
	//- - - - - - - - - - - - - 
            #region -- Excursion Levels --
            miExcursionLevels = new MenuItem { Header = "Excursion Levels", Name="EL" + uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal };

            isExcursionMasterOn = pDisplayExcursion1 || pDisplayExcursion2 || pDisplayExcursion3;
            miExcursionLevelsMaster = new MenuItem { Header = "--- MASTER " + (isExcursionMasterOn ? "ON" : "OFF") + " ---", Name = "btExcursionLevels_Master", Foreground = Brushes.Black, StaysOpenOnClick = true };
			miExcursionLevelsMaster.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				isExcursionMasterOn = !isExcursionMasterOn;
				miExcursionLevelsMaster.Header = "--- MASTER " + (isExcursionMasterOn ? "ON" : "OFF") + " ---";

				pDisplayExcursion1 = isExcursionMasterOn;
				pDisplayExcursion2 = isExcursionMasterOn;
				pDisplayExcursion3 = isExcursionMasterOn;
				miExcursionLevels1.Header = "Show Level 1 " + (pDisplayExcursion1 ? "ON" : "OFF");
				miExcursionLevels2.Header = "Show Level 2 " + (pDisplayExcursion2 ? "ON" : "OFF");
				miExcursionLevels3.Header = "Show Level 3 " + (pDisplayExcursion3 ? "ON" : "OFF");
				ForceRefresh();
			};
            miExcursionLevels.Items.Add(miExcursionLevelsMaster);

            miExcursionLevels1 = new MenuItem { Header = "Show Level 1 " + (pDisplayExcursion1 ? "ON" : "OFF"), Name = "EL1"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miExcursionLevels1.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				pDisplayExcursion1 = !pDisplayExcursion1;
				miExcursionLevels1.Header = "Show Level 1 " + (pDisplayExcursion1 ? "ON" : "OFF");
				ForceRefresh();
			};
            miExcursionLevels.Items.Add(miExcursionLevels1);
            miExcursionLevels2 = new MenuItem { Header = "Show Level 2 " + (pDisplayExcursion2 ? "ON" : "OFF"), Name = "EL2"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miExcursionLevels2.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				pDisplayExcursion2 = !pDisplayExcursion2;
				miExcursionLevels2.Header = "Show Level 2 " + (pDisplayExcursion2 ? "ON" : "OFF");
				ForceRefresh();
			};
            miExcursionLevels.Items.Add(miExcursionLevels2);

            miExcursionLevels3 = new MenuItem { Header = "Show Level 3 " + (pDisplayExcursion3 ? "ON" : "OFF"), Name = "EL3"+uID, Foreground = Brushes.Black, StaysOpenOnClick = true };
            miExcursionLevels3.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
				pDisplayExcursion3 = !pDisplayExcursion3;
				miExcursionLevels3.Header = "Show Level 3 " + (pDisplayExcursion3 ? "ON" : "OFF");
				ForceRefresh();
			};
			miExcursionLevels.Items.Add(miExcursionLevels3);

			List<string> cbItems = new List<string>();
			foreach (var pt in Enum.GetValues(typeof(ARC_CycleForecaster_ExcursionStyle))) cbItems.Add(pt.ToString());            
			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(26) });
			Label lbl1 = new Label() { HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), Content = "Lines' Mode :" };
			lbl1.SetValue(Grid.ColumnProperty, 0);
			lbl1.SetValue(Grid.RowProperty, 0);
			comboExcursionStyle = new ComboBox() { Name = "comboES" + uID, MinWidth = 86, Width = 86, MaxWidth = 86, Margin = new Thickness(5, 0, 0, 0) };
			foreach (string cbitem in cbItems) comboExcursionStyle.Items.Add(cbitem);
			comboExcursionStyle.SelectedItem = pExcursionLevelsIsStatic ? ARC_CycleForecaster_ExcursionStyle.Static.ToString() : ARC_CycleForecaster_ExcursionStyle.Dynamic.ToString();
			comboExcursionStyle.SelectionChanged += delegate(object sender, SelectionChangedEventArgs e)
			{
				pExcursionLevelsIsStatic = (string)comboExcursionStyle.SelectedItem == ARC_CycleForecaster_ExcursionStyle.Static.ToString() ? true : false;
				ForceRefresh();
			};
			comboExcursionStyle.SetValue(Grid.ColumnProperty, 1);
			comboExcursionStyle.SetValue(Grid.RowProperty, 0);
			grid.Children.Add(lbl1);
			grid.Children.Add(comboExcursionStyle);
			miExcursionLevels.Items.Add(grid);

			MenuControl.Items.Add(miExcursionLevels);
			#endregion
	//- - - - - - - - - - - - - 
			MenuControl.Items.Add(new Separator());
	//- - - - - - - - - - - - - 
			#region -- Toggle PredictionText location --
			var miPredictionTextLocation = new MenuItem {Header = "Prediction Text:  "+pPredictionMsgLoc.ToString(), Name = "PT"+uID, Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = true };
			miPredictionTextLocation.MouseWheel += delegate(object o, MouseWheelEventArgs e){
				e.Handled=true;
				if(e.Delta > 0){
					if(     pPredictionMsgLoc == ARC_CycleForecaster_PredictionLocType.None)        pPredictionMsgLoc = ARC_CycleForecaster_PredictionLocType.BottomLeft;
					else if(pPredictionMsgLoc == ARC_CycleForecaster_PredictionLocType.BottomLeft)  pPredictionMsgLoc = ARC_CycleForecaster_PredictionLocType.BottomRight;
					else if(pPredictionMsgLoc == ARC_CycleForecaster_PredictionLocType.BottomRight) pPredictionMsgLoc = ARC_CycleForecaster_PredictionLocType.Center;
					else if(pPredictionMsgLoc == ARC_CycleForecaster_PredictionLocType.Center)      pPredictionMsgLoc = ARC_CycleForecaster_PredictionLocType.TopLeft;
					else if(pPredictionMsgLoc == ARC_CycleForecaster_PredictionLocType.TopLeft)     pPredictionMsgLoc = ARC_CycleForecaster_PredictionLocType.TopRight;
					else if(pPredictionMsgLoc == ARC_CycleForecaster_PredictionLocType.TopRight)    pPredictionMsgLoc = ARC_CycleForecaster_PredictionLocType.None;
				}else{
					if(     pPredictionMsgLoc == ARC_CycleForecaster_PredictionLocType.None)        pPredictionMsgLoc = ARC_CycleForecaster_PredictionLocType.TopRight;
					else if(pPredictionMsgLoc == ARC_CycleForecaster_PredictionLocType.TopRight)    pPredictionMsgLoc = ARC_CycleForecaster_PredictionLocType.TopLeft;
					else if(pPredictionMsgLoc == ARC_CycleForecaster_PredictionLocType.TopLeft)     pPredictionMsgLoc = ARC_CycleForecaster_PredictionLocType.Center;
					else if(pPredictionMsgLoc == ARC_CycleForecaster_PredictionLocType.Center)      pPredictionMsgLoc = ARC_CycleForecaster_PredictionLocType.BottomRight;
					else if(pPredictionMsgLoc == ARC_CycleForecaster_PredictionLocType.BottomRight) pPredictionMsgLoc = ARC_CycleForecaster_PredictionLocType.BottomLeft;
					else if(pPredictionMsgLoc == ARC_CycleForecaster_PredictionLocType.BottomLeft)  pPredictionMsgLoc = ARC_CycleForecaster_PredictionLocType.None;
				}
				miPredictionTextLocation.Header = "Prediction Text:  "+pPredictionMsgLoc.ToString();
				RemoveDrawObject("pred");
				InformUserAboutRecalculation();
			};
			MenuControl.Items.Add(miPredictionTextLocation);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Show/Hide BollingerBands -- - REMOVED
//			if(!pEnableBBands){
//				Plots[BBUpper_PLOT_ID].Brush = Brushes.Transparent;
//				Plots[BBLower_PLOT_ID].Brush = Brushes.Transparent;
//				Plots[BBline_PLOT_ID].Brush = Brushes.Transparent;
//				Plots[BBdot_PLOT_ID].Brush = Brushes.Transparent;
//			}
//			miShowHideBollingerBands = new MenuItem { Header = "Show BollingerBands: "+(pEnableBBands ? "ON":"OFF"), HorizontalAlignment = HorizontalAlignment.Center , Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = false };
//			miShowHideBollingerBands.Click += delegate (object o, RoutedEventArgs e){
//				e.Handled = true;
//				pEnableBBands = !pEnableBBands;
//				miShowHideBollingerBands.Header = "Show BollingerBands: "+(pEnableBBands ? "ON":"OFF");
//				if(!pEnableBBands){
//					Plots[BBUpper_PLOT_ID].Brush = Brushes.Transparent;
//					Plots[BBLower_PLOT_ID].Brush = Brushes.Transparent;
//					Plots[BBline_PLOT_ID].Brush = Brushes.Transparent;
//					Plots[BBdot_PLOT_ID].Brush = Brushes.Transparent;
//				}else{
//					Plots[BBUpper_PLOT_ID].Brush = BBBrushes[BBUpper_PLOT_ID];
//					Plots[BBLower_PLOT_ID].Brush = BBBrushes[BBLower_PLOT_ID];
//					Plots[BBline_PLOT_ID].Brush = BBBrushes[BBline_PLOT_ID];
//					Plots[BBdot_PLOT_ID].Brush = BBBrushes[BBdot_PLOT_ID];
//				}
//				System.Windows.Forms.SendKeys.SendWait("{F5}");
//			};
//			MenuControl.Items.Add(miShowHideBollingerBands);
			#endregion
	//- - - - - - - - - - - - - 
			#region -- Recalc Profiles --
			miRecalculate1 = new MenuItem { Header = "RE-CALCULATE", Name = "RC1"+uID, HorizontalAlignment = HorizontalAlignment.Center , Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = false };
			miRecalculate1.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
//				Draw.TextFixed(this, "DataLoadingMsg", "Reclaculating in process..."+DateTime.Now.ToShortTimeString(), TextPosition.TopLeft);
				ResetRecalculationUI();
				RecalculateButtonHit = true;
				System.Windows.Forms.SendKeys.SendWait("{F5}");
			};
			MenuControl.Items.Add(miRecalculate1);
			#endregion
			#endregion -- addToolBar --
			indytoolbar.Children.Add(MenuControlContainer);
		}
//================================================================
		private void PaintRacingStripes(){
			#region -- PaintRacingStripes --
			bool LongStripe = pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.Both || pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.Longs;
			bool ShortStripe = pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.Both || pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.Shorts;
			for(int abar = 1; abar<Bars.Count; abar++){
				var dt = Times[0].GetValueAt(abar);
				BackBrushes.Set(abar, null);
				BackBrushesAll.Set(abar, null);
				if(pRacingStripeDirection != ARC_CycleForecaster_MarkerDirection.None){
					if( !CurrentASet.GaplessHisto.ContainsKey(dt)) continue;
					if(pRacingStripeType == ARC_CycleForecaster_RacingStripeType.BothPanels){
						if(LongStripe && CurrentASet.GaplessHisto[dt].IsSignalBar=='L')       BackBrushesAll.Set(abar, LongRacingStripeBrush);
						else if(ShortStripe && CurrentASet.GaplessHisto[dt].IsSignalBar=='S') BackBrushesAll.Set(abar, ShortRacingStripeBrush);
					}else{//just the subpanel
						if(LongStripe && CurrentASet.GaplessHisto[dt].IsSignalBar=='L')       BackBrushes.Set(abar, LongRacingStripeBrush);
						else if(ShortStripe && CurrentASet.GaplessHisto[dt].IsSignalBar=='S') BackBrushes.Set(abar, ShortRacingStripeBrush);
					}
				}
			}
			#endregion
		}
//================================================================
		#region -- UI Methods --
        #region -- TabSelectionChangedHandler() --
        private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count <= 0) return;
            TabItem tabItem = e.AddedItems[0] as System.Windows.Controls.TabItem;
            if (tabItem == null) return;
            ChartTab temp = tabItem.Content as ChartTab;
            if (temp != null && indytoolbar != null)
                indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
        }
        #endregion
//=====================================================================================================
		private void InformUserAboutRecalculation(bool RecalcBtnHitSetting = false){
			miRecalculate1.Background = Brushes.Yellow;
			miRecalculate1.FontWeight = FontWeights.Bold;
			miRecalculate1.FontStyle  = FontStyles.Italic;
			RecalculateButtonHit = RecalcBtnHitSetting;
			if(!RecalculateButtonHit) {
				DrawOnPricePanel = false;
				Draw.TextFixed(this,"recalcnow",". Hit 'RE-CALCULATE' to enact your changes .",TextPosition.Center, Brushes.Yellow, new SimpleFont("Arial",18), Brushes.Yellow, Brushes.Black, 100);
				ForceRefresh();
			}
		}
		private void ResetRecalculationUI(){
			miRecalculate1.FontWeight = FontWeights.Normal;
			miRecalculate1.FontStyle = FontStyles.Normal;
			miRecalculate1.Background = null;
			RecalculateButtonHit = true;
		}
		#endregion
//================================================================
		protected override void OnStateChange()
		{
if(IsDebug && State!=null)Print("State: "+State.ToString());
			#region -- OnStateChange --
			//----------------------------------------------------------------
			if (State == State.SetDefaults)
			{
				#region -- SetDefaults --
				Name = "ARC_CycleForecaster";
				this.MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
				//Print(Name," entering Initialize()");
				var ExcludedIds = new List<string>();
				ExcludedIds.Add("1E53E271B82EC62C7C03A15C336229AE");//Ben


				Debug = false;//System.IO.File.Exists("c:\\222222222222.txt") && ExcludedIds.Contains(NinjaTrader.Cbi.License.MachineId);
				IsDebug = System.IO.File.Exists("c:\\222222222222.txt") && (
					NinjaTrader.Cbi.License.MachineId=="1E53E271B82EC62C7C03A15C336229AE" || NinjaTrader.Cbi.License.MachineId=="766C8CD2AD83CA787BCA6A2A76B2303B");
				if(!Debug) {
				} else {
					T1 = new DateTime(2014,4,21,1,0,0);
					T2 = new DateTime(2014,4,21,1,59,0);
				}
//Debug = false;
				Calculate=Calculate.OnBarClose;
				IsAutoScale			= true;
				IsOverlay			= false;
				DrawOnPricePanel    = true;
				PaintPriceMarkers   = false;

				#region -- Plots --
				AddPlot(new Stroke(Brushes.Lime, 4),          PlotStyle.Dot, "LongSig");
				AddPlot(new Stroke(Brushes.Magenta, 4),       PlotStyle.Dot, "ShortSig");
//				AddPlot(new Stroke(Brushes.Transparent, 1),   PlotStyle.Dot, "Predictions");
				ACTIVEUP_HISTO_PLOT_ID = 2;
				AddPlot(new Stroke(Brushes.LimeGreen,2), PlotStyle.Bar, "Up");
				ACTIVEDOWN_HISTO_PLOT_ID = 3;
				AddPlot(new Stroke(Brushes.Red, 2),        PlotStyle.Bar, "Down");

//				AddPlot(new Stroke(Brushes.Silver,2),       PlotStyle.Bar, "InactiveUp");
//				INACTIVEUP_HISTO_PLOT_ID = 5;
//				AddPlot(new Stroke(Brushes.DimGray, 2),     PlotStyle.Bar, "InactiveDown");
//				INACTIVEDOWN_HISTO_PLOT_ID = 6;
//				AddPlot(new Stroke(Brushes.DarkGray, 1),    PlotStyle.Bar, "Inversion");
//				INVERSION_HISTO_PLOT_ID = 7;
//				AddPlot(new Stroke(Brushes.Transparent, 1), PlotStyle.Dot, "ShiftedHisto");
//				HISTO_PLOT_ID = 4;
				AddPlot(new Stroke(Brushes.Yellow, 1), PlotStyle.Hash, "MarkerLineTop");
				THLEVEL_PLOT_ID = 4;
				AddPlot(new Stroke(Brushes.Yellow, 1), PlotStyle.Hash, "MarkerLineBottom");
				BHLEVEL_PLOT_ID = 5;
	//			AddPlot(new Stroke(Brushes.Transparent, 2), PlotStyle.Hash, "ShiftedHisto");
	//			SHIFTEDHISTO_PLOT_ID = 11;
				BBUpper_PLOT_ID = 6;
				AddPlot(new Stroke(Brushes.Black, 1), PlotStyle.Line,   "BBUpper");
				BBLower_PLOT_ID = 7;
				AddPlot(new Stroke(Brushes.Black, 1), PlotStyle.Line,   "BBLower");
				BBline_PLOT_ID = 8;
				AddPlot(new Stroke(Brushes.DimGray, 2), PlotStyle.Line, "BBline");
				BBdot_PLOT_ID = 9;
				AddPlot(new Stroke(Brushes.White, 4), PlotStyle.Dot,    "BBDot");

				CCILINE_PLOT_ID = 10;
				AddPlot(new Stroke(Brushes.Orange, 3), PlotStyle.Line,   "CCI Line");
				RSILINE_PLOT_ID = 11;
				AddPlot(new Stroke(Brushes.Orange, 3), PlotStyle.Line,   "RSI Line");
				RSIAVGLINE_PLOT_ID = 12;
				AddPlot(new Stroke(Brushes.Yellow, 2), PlotStyle.Line,   "RSI Avg Line");
				MACDLINE_PLOT_ID = 13;
				AddPlot(new Stroke(Brushes.Silver, 3), PlotStyle.Line,   "MACD Line");
				MACDSIGNALLINE_PLOT_ID = 14;
				AddPlot(new Stroke(Brushes.Yellow, 1), PlotStyle.Line,   "MACD Signal Line");
				MACDDIFFHISTO_PLOT_ID = 15;
				AddPlot(new Stroke(Brushes.DodgerBlue, 2), PlotStyle.Bar,"MACD Diff Histo");
				STOCHDLINE_PLOT_ID = 16;
				AddPlot(new Stroke(Brushes.Orange, 3), PlotStyle.Line,   "Stoch D Line");
				STOCHKLINE_PLOT_ID = 17;
				AddPlot(new Stroke(Brushes.Blue, 3), PlotStyle.Line,   "Stoch K Line");
				FISHERLINE_PLOT_ID = 18;
				AddPlot(new Stroke(Brushes.Blue, 3), PlotStyle.Line,   "Fisher Line");
#if RSS_AND_RVI
				RSSLINE_PLOT_ID = 19;
				AddPlot(new Stroke(Brushes.Orange, 3), PlotStyle.Line,   "RSS Line");
				RVILINE_PLOT_ID = 20;
				AddPlot(new Stroke(Brushes.Orange, 3), PlotStyle.Line,   "RVI Line");
#endif
				
				PlotIDsToHide = new List<int>(){6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};//these plots will not paint into the future (to the right of the current bar)
				AddLine(new Stroke(Brushes.DarkGray, DashStyleHelper.Solid, 1), 0, "Zero line");
				#endregion -- end Plots --

				BandPeriod     = 10;
				StdDevNumber   = 1;
				ChannelColor   = Brushes.DodgerBlue;
				ChannelOpacity = 20;
				pBBFast = 12;
				pBBSlow = 26;
                DotsUpRisingColor    = Brushes.Ivory;
                DotsDownRisingColor  = Brushes.Ivory;
                DotsDownFallingColor = Brushes.Magenta;
                DotsUpFallingColor   = Brushes.Magenta;
				pPredictionOscillatorBrush = Brushes.Pink;
				pPredictionOscillatorLineWidth = 3;

				pVMDLabelDotBrush    = Brushes.Pink;
				pRSILabelDotBrush    = Brushes.Yellow;
				pCCILabelDotBrush    = Brushes.Aqua;
				pStochLabelDotBrush  = Brushes.Chartreuse;
				pMACDLabelDotBrush   = Brushes.DarkOrange;
				pFisherLabelDotBrush = Brushes.IndianRed;

				pShowHistoricalTimeLabels = true;
				pMultiSignalArrowCount = 5;
				pMultiSignalBarVariance = 2;

				pDisplayExcursion1 = false;
				pDisplayExcursion2 = false;
				pDisplayExcursion3 = false;
				pLevel1Color = Brushes.WhiteSmoke;
                pLevel2Color = Brushes.Blue;
                pLevel3Color = Brushes.Red;
                pWidthExcursionLines     = 3;
				pExcursionLevelsIsStatic = true;
				pUseAutoPeakCalculation  = true;

				pButtonText         = "CycForc";
				pMarkerDirection    = ARC_CycleForecaster_MarkerDirection.Both;
				pViewState          = ARC_CycleForecaster_ViewStates.Data;
				#endregion
	        }
			//----------------------------------------------------------------
			if (State == State.Configure) {
				Guid x = Guid.NewGuid();
				uID = Instrument.MasterInstrument.Name+x+pButtonText;//prevent multiple toolbar with same name
				uID = uID.Replace(" ",string.Empty).Replace("-",string.Empty);
				#region -- Configure --

				if(ChartControl!=null && pSavePredictions){
					CSVfilename = MakeString(new Object[]{NinjaTrader.Cbi.DB.DBDir,"CycF",Instrument.FullName,Bars.BarsPeriod,pAnalysisType,".txt"},"_");
					if(System.IO.File.Exists(CSVfilename)) System.IO.File.Delete(CSVfilename);
				}
#if SPEECH_ENABLED
				string dll = System.IO.Path.Combine(System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","custom"),"interop.speechlib.dll");   //"c:\users\ben\Documents\NinjaTrader 7\"
				if(System.IO.File.Exists(dll)) {
					SpeechEnabled = true;
					SpeechLib = Assembly.LoadFile(dll);
				}
#endif
				#endregion
				PlotBrushDXes50pct = new SharpDX.Direct2D1.Brush[Plots.Length];
				IsDebug = System.IO.File.Exists("c:\\222222222222.txt");
#if DoLicense
				Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				RemoveDrawObject("lictext");
				IsDebug=false;
#endif
			}
			//----------------------------------------------------------------
			if(State == State.DataLoaded){
                #region -- Add Custom Toolbar --
                if (!isToolBarButtonAdded && ChartControl != null)
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        ChartControl.AllowDrop = false;
                        chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                        if (chartWindow == null) return;

                        foreach (DependencyObject item in chartWindow.MainMenu) if (AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

                        if (!isToolBarButtonAdded)
                        {
                            indytoolbar = new System.Windows.Controls.Grid { Visibility = Visibility.Collapsed };

                            addToolBar();

                            chartWindow.MainMenu.Add(indytoolbar);
                            chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

                            foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
                            AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
                        }
                    }));
                #endregion

				#region -- DataLoaded --
				if(pLongRacingStripeOpacity==0) LongRacingStripeBrush = null;
				else{
					LongRacingStripeBrush = pLongRacingStripeColor.Clone();
					LongRacingStripeBrush.Opacity = pLongRacingStripeOpacity/100.0;
					LongRacingStripeBrush.Freeze();
				}

				if(pShortRacingStripeOpacity==0) ShortRacingStripeBrush = null;
				else{
					ShortRacingStripeBrush = pShortRacingStripeColor.Clone();
					ShortRacingStripeBrush.Opacity = pShortRacingStripeOpacity/100.0;
					ShortRacingStripeBrush.Freeze();
				}
				#endregion

				this.Is24HrSession = BarsArray[0].TradingHours.Name.Contains("Default 24");

				TimeFrameText = Bars.BarsPeriod.ToString().Replace("min","minutes");
				if(Bars.BarsPeriod.Value==1) TimeFrameText = TimeFrameText.Replace("minutes","minute");
				if(Bars.BarsPeriod.BarsPeriodType==BarsPeriodType.Second)     MinutesPerBar = Bars.BarsPeriod.Value/60;
				if(Bars.BarsPeriod.BarsPeriodType==BarsPeriodType.Minute)     MinutesPerBar = Bars.BarsPeriod.Value;
				if(Bars.BarsPeriod.BarsPeriodType==BarsPeriodType.HeikenAshi) MinutesPerBar = Bars.BarsPeriod.Value;
				if(Bars.BarsPeriod.BarsPeriodType==BarsPeriodType.Day)        MinutesPerBar = Bars.BarsPeriod.Value*1440;
				//if(ChartControl!=null) TempMsgs = new TemporaryMessageManager(ChartControl.Properties.AxisPen.Brush, ChartControl.Properties.AxisPen.Brush, ChartControl.Properties.AxisPen.Brush, ChartControl.Properties.AxisPen.Brush, ChartControl.Properties.AxisPen.Brush);
				PlotA = new Series<double>(this,MaximumBarsLookBack.Infinite);
				PlotB = new Series<double>(this,MaximumBarsLookBack.Infinite);
				PlotC = new Series<double>(this,MaximumBarsLookBack.Infinite);
				nextSignal      = new Series<int>(this,MaximumBarsLookBack.Infinite);
				ExcursionSeries = new Series<double>(this,MaximumBarsLookBack.Infinite);

//				var enumAnalysisTypes = Enum.GetValues(typeof(ARC_CycleForecaster_AnalysisType)).Cast<ARC_CycleForecaster_AnalysisType>();
				enumAnalysisTypes = Enum.GetValues(typeof(ARC_CycleForecaster_AnalysisType)).Cast<ARC_CycleForecaster_AnalysisType>().ToList();
				foreach(var type in enumAnalysisTypes){
					AnalysisSets[type] = new AnalysisSet();
				}
				foreach(var atype in AnalysisSets){
					atype.Value.DTlastHistoPeakCalc = BarsArray[0].GetTime(0);
					atype.Value.Sign1			 = 0;
					atype.Value.FutureHistoMax	 = 0;
					atype.Value.FutureHistoMin	 = 0;
					atype.Value.HistoHighPeaks	 = new List<DateTime>();
					atype.Value.HistoLowPeaks	 = new List<DateTime>();
					atype.Value.HighPeaksToday	 = new List<TimePrice>();
					atype.Value.LowPeaksToday	 = new List<TimePrice>();
					atype.Value.LongTimeLabels	 = new SortedDictionary<DateTime,double>();
					atype.Value.ShortTimeLabels	 = new SortedDictionary<DateTime,double>();
					atype.Value.GaplessHisto	 = new SortedDictionary<DateTime,HistoData>();
					atype.Value.CoreData		 = new SortedDictionary<DateTime,double>();
					atype.Value.Histo			 = new Series<double>(this,MaximumBarsLookBack.Infinite);
					atype.Value.ShiftedHisto	 = new Series<double>(this,MaximumBarsLookBack.Infinite);
					atype.Value.ShiftedHistoAbs	 = new List<double>();
					atype.Value.FutureHistoKeys	 = new List<DateTime>();
					atype.Value.HistoDataList	 = new List<HistoData>();
					atype.Value.NewDayFlag		 = false;
					atype.Value.YesterdayDOW	 = DayOfWeek.Sunday;
				}
				CurrentASet = AnalysisSets[pAnalysisType];

				stoch  = StochasticsFast(pDperiod, pKperiod);
				rsi    = RSI(pRSIperiod,1);
				fisher = FisherTransform(pFisherPeriod);
				//vmd = new Series<double>(this,MaximumBarsLookBack.Infinite);
#if RSS_AND_RVI
				rss = RSS(pRSSperiod1, pRSSperiod2, pRSSLength);
				rvi = RVI(pRVIperiod);
#endif
				atr256 = ATR(256);
				sma65 = SMA(atr256, 65);
				if(pViewState == ARC_CycleForecaster_ViewStates.Data && pAnalysisType == ARC_CycleForecaster_AnalysisType.VMDivergence)
					BollingerMACD = MACD(CurrentASet.ShiftedHisto, pBBFast, pBBSlow, BandPeriod);
				else
					BollingerMACD = MACD(PlotA, pBBFast, pBBSlow, BandPeriod);
				SDBB = StdDev(BollingerMACD, BandPeriod);

				//core for VMDivergence analysis type
                MACD1 = MACD(8, 20, 20);
                MACD2 = MACD(10, 20, 20);
                MACD3 = MACD(20, 60, 20);
                MACD4 = MACD(60, 240, 20);

				//core for MACD analysis type
				macd = MACD(this.pMACDfast, pMACDslow, pMACDsmooth);
			}
			//----------------------------------------------------------------
			if(State == State.Realtime){
				#region -- Realtime --
				foreach(var k in AnalysisSets.First().Value.GaplessHisto){
					var rbar = CurrentBar - Bars.GetBar(k.Value.PrintTime);
					if(rbar>0 && rbar<CurrentBar-1){
						UpperMarkerLine[rbar] = k.Value.MinHigh;//GetUpperLowerLevel('U', Hlevel, dt.AddDays(-7*pMaxWeeks));
						LowerMarkerLine[rbar] = k.Value.MaxLow;//GetUpperLowerLevel('L', Llevel, dt.AddDays(-7*pMaxWeeks));
					}
				}
				if(BarsArray[0].GetTime(0) > BarsArray[0].GetTime(CurrentBars[0]).AddDays(-7*this.pMaxWeeks)){
					var ts = new TimeSpan(BarsArray[0].GetTime(0).Ticks - BarsArray[0].GetTime(CurrentBars[0]).AddDays(-7*this.pMaxWeeks).Ticks);
					var days = Math.Abs((7 * this.pMaxWeeks) - ts.TotalDays);
					Draw.TextFixed(this, "not enough days","Not enough data on chart...add "+(days+1).ToString("0")+"-days to your chart", TextPosition.BottomRight, Brushes.Black, new SimpleFont("Arial",16), Brushes.Red, Brushes.Red, 90);
				}

				#endregion
			}
			if(State == State.Terminated){
				#region -- Terminated --
				if (chartWindow != null && indytoolbar != null)
				{
					if (ChartControl.Dispatcher.CheckAccess()) {
						chartWindow.MainMenu.Remove(indytoolbar);
						indytoolbar = null;

						chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
						chartWindow = null;
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							chartWindow.MainMenu.Remove(indytoolbar);
							indytoolbar = null;

							chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
							chartWindow = null;
						}));
					}
				}
				#endregion
			}
			#endregion
		}
//================================================================
		#region -- CalculateStartOfNextSession() --
		private DateTime IntToDateTime(int year, int month, int day, int time){
			int hr  = Convert.ToInt32(Math.Truncate(Convert.ToDouble(time)/100.0));
			int min = time - hr*100;
			return new DateTime(year, month, day, hr, min, 0);
		}

		private DateTime CalculateStartOfNextSession(DateTime dt){
			if(Is24HrSession) return dt;
			var now = dt;
			bool done = false;
			DateTime SessionStartTime = DateTime.MinValue;
			//Print(BarsArray[0].TradingHours.Name+"  "+BarsArray[0].TradingHours.GetPreviousTradingDayEnd(now).ToString());
			while(!done){
				now = now.AddDays(1);
				foreach (var x in BarsArray[0].TradingHours.Sessions) {
					if(now.DayOfWeek == x.BeginDay) {
						SessionStartTime = IntToDateTime(now.Year, now.Month, now.Day, x.BeginTime);
						done=true;
					}
				}
//				Print(x.BeginTime+" end: "+x.EndTime+"   "+x.ToString()+" TradingDay: "+x.TradingDay.ToString());
			}
			//Print("Today is "+now.DayOfWeek.ToString()+"  Session starts at "+SessionStartTime.ToString());
			return SessionStartTime;
		}
		#endregion
//================================================================
private void Printf(string msg) {
	//File.AppendAllText(FileName, msg,NL);
}
//================================================================
		/// <summary>
		/// Called on each bar update event (incoming tick)
		/// </summary>
		protected override void OnBarUpdate() {
try{
			//if(BackBrushes.Count>0) PrintOnce(CurrentBars[0]+": OBU BackBrushes.Count = "+BackBrushes.Count);
			if(ErrorMsg.Length>0) {
				Print("1335: "+ErrorMsg); 
				Alert("error",Priority.High,ErrorMsg,AddSoundFolder("alert4.wav"),1000,Brushes.Red, Brushes.Black);
			}
			if(Instrument==null) return;
			#region -- Licensing --
#if DoLicense
			if(!ValidLicense) {
				if(this.NewCustId<0)
					Draw.TextFixed(this,"lictext","Your ARC Contact Id is not present\n"+MachineId+"\n\nPlease run your ARC_LicenseActivator v1 indicator\n\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architechtsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			#endregion

			if(CurrentBar<5) {
				RunInit = true;
				return;
			}
			if((State == State.Historical)){
				then = Time[1];
				now = Time[0];
			}
			if(Bars.BarsPeriod.BarsPeriodType != BarsPeriodType.Minute && Bars.BarsPeriod.BarsPeriodType != BarsPeriodType.HeikenAshi && Bars.BarsPeriod.BarsPeriodType != BarsPeriodType.Second) {
				return;
			}
			SinceLaunch = new TimeSpan(Math.Abs(NinjaTrader.Core.Globals.Now.Ticks - TimeAtLaunch.Ticks));
			if(SinceLaunch.TotalSeconds>120) {
				RemoveDaysAgoMsg = true;
				RemoveDrawObject("info");
				RemoveDrawObject("info1");
				RemoveDrawObject("info2");
			}
			//============================================
			if(RunInit) {
				RunInit = false;

				#region RunInit

				try {ZeroTime = DateTime.Parse(pZeroTimeStr);} 
				catch {Log("Invalid Zero time, must be in 24hr format: 'hh:mm'",LogLevel.Alert); return;}
				ZeroTime = new DateTime(Time[0].Year, Time[0].Month,Time[0].Day, ZeroTime.Hour, ZeroTime.Minute,0,0);

				TimeSpan ts = new TimeSpan(Math.Abs(Time[0].Ticks-NinjaTrader.Core.Globals.Now.Ticks));
				if(ts.TotalDays<pMaxWeeks*7) {
					DataShortageMsg = MakeString(new Object[]{"WARNING - Data Shortage:  RevForcast chart data begins ",ts.TotalDays.ToString("0"),"-days ago, and you've requested ",pMaxWeeks,"-weeks of data...please add more data to your chart"});
//					Draw.TextFixed(this, "permanent",DataShortageMsg,TextPosition.TopLeft);
				} else {
//					Draw.TextFixed(this, "info2",MakeString(new Object[]{"RevForcast input data began at: ",Time[0]}),TextPosition.TopLeft);
				}

				#endregion
			}
			//============================================
			if(DataShortageMsg.Length>0) {
				Alert("permanent1",NinjaTrader.NinjaScript.Priority.High,MakeString(new Object[]{"Add more data to your ",Instrument.FullName," chart"}), AddSoundFolder("Alert2.wav"),100, Brushes.Red, Brushes.White);
			}

			if(IsFirstTickOfBar){
				MarkersThisBar = 0;
				StartOfNextSession = CalculateStartOfNextSession(BarsArray[0].LastBarTime);
				foreach(var kvp in AnalysisSets){
					DateTime t1 = Time[1];
					double cval = 0;
					while(t1 < Time[0]){
						if(kvp.Value.CoreData.ContainsKey(t1)) cval = kvp.Value.CoreData[t1];
						kvp.Value.CoreData[t1] = cval;
						t1 = t1.AddMinutes(this.MinutesPerBar);
					}
				}
			}

			foreach(var kvp in AnalysisSets){
				if(!pIsMultiSignal && kvp.Key!=pAnalysisType) {
					continue;
				}
				kvp.Value.CoreData[Time[0]] = CalculateCore(kvp.Key, 0, Time[0], Time[1]);
				kvp.Value.Histo[0] = CalculateHisto(0, kvp.Value.CoreData);
			}

			if(Time[0].Day!=Time[1].Day){
				TimeSpan ts = new TimeSpan(Time[0].Ticks - Bars.GetTime(0).Ticks);
				MaxWeeksAccessible = (int)(ts.TotalDays/7.0);
			}

			if(IsFirstTickOfBar) {
				#region -- Fill in missing times in GaplessHisto --
				foreach(var kvp in AnalysisSets){
					if(!pIsMultiSignal && kvp.Key!=pAnalysisType) continue;
					LastWeekKey = Time[0].AddDays(-7*pWeeksToGoBack);
					DateTime t1 = Time[1];
					while(t1 < Time[0]){//fill in any gaps between Time[0] and Time[1]
						if(!kvp.Value.GaplessHisto.ContainsKey(t1)){
							if(!pUseAutoPeakCalculation)
								kvp.Value.GaplessHisto[t1] = new HistoData(kvp.Value.Histo[0], pMinHighPeakForValidMarker, pMaxLowPeakForValidMarker, ' ', t1.AddDays(7*pWeeksToGoBack));
							else
								kvp.Value.GaplessHisto[t1] = new HistoData(kvp.Value.Histo[0], double.MinValue, double.MinValue, ' ', t1.AddDays(7*pWeeksToGoBack));
						}
						t1 = t1.AddMinutes(this.MinutesPerBar);
					}
				}
				#endregion
				DAY_OF_WEEK_OF_LAST_BAR = (int)Bars.GetTime(Bars.Count-1).DayOfWeek;
				if(this.pIsMultiSignal) {
					while(MultiSigBuyClusters.Count  >= this.pMultiSignalBarVariance) MultiSigBuyClusters.RemoveAt(MultiSigBuyClusters.Count-1);
					while(MultiSigSellClusters.Count >= this.pMultiSignalBarVariance) MultiSigSellClusters.RemoveAt(MultiSigSellClusters.Count-1);

					while(MultiSigBuyClusters.Count  < this.pMultiSignalBarVariance) MultiSigBuyClusters.Insert(0,0);
					while(MultiSigSellClusters.Count < this.pMultiSignalBarVariance) MultiSigSellClusters.Insert(0,0);
				}
			}

			foreach(var kvp in AnalysisSets){
				if(!pIsMultiSignal && kvp.Key!=pAnalysisType) continue;
				if(pUseAutoPeakCalculation)
					kvp.Value.GaplessHisto[Time[0]] = new HistoData(kvp.Value.Histo[0], double.MinValue, double.MinValue, ' ', Time[0].AddDays(7*pWeeksToGoBack));
				else
					kvp.Value.GaplessHisto[Time[0]] = new HistoData(kvp.Value.Histo[0], pMinHighPeakForValidMarker, pMaxLowPeakForValidMarker, ' ', Time[0].AddDays(7*pWeeksToGoBack));

				#region -- Update ShiftedHisto --
				if(kvp.Value.GaplessHisto.ContainsKey(LastWeekKey)) {
line=2535;//Print(line);
					kvp.Value.ShiftedHisto[0] = kvp.Value.GaplessHisto[LastWeekKey].Val;
				}
				#endregion
			}

			if(Time[1].Day != Time[0].Day) {
				PriorDayDT = Time[1];
				foreach(var kvp in AnalysisSets){
					kvp.Value.NewDayFlag = true;
				}
			}
			#region DrawHistograms
			{
line=2550;//Print(line);
				foreach(var kvp in AnalysisSets){
					if(!pIsMultiSignal && kvp.Key!=pAnalysisType) continue;
					if(kvp.Value.Histo[0] > 0) 
						ActiveUp[0] = kvp.Value.Histo[0];
					else 
						ActiveDown[0] = kvp.Value.Histo[0];

					if(State == State.Realtime && IsFirstTickOfBar){
						int rbar = 0;
						while(!UpperMarkerLine.IsValidDataPoint(rbar) && rbar<CurrentBar-1) rbar++;
						UpperMarkerLine[0] = UpperMarkerLine[rbar];
						LowerMarkerLine[0] = LowerMarkerLine[rbar];
					}
				}
			}
			#endregion
//}catch(Exception err){Print(line+": "+err.ToString());}

			if(!pUseAutoPeakCalculation){
				UpperMarkerLine[0] = pMinHighPeakForValidMarker;
				LowerMarkerLine[0] = pMaxLowPeakForValidMarker;
			}
			#region -- BB on complete histo --
			if(pAnalysisType == ARC_CycleForecaster_AnalysisType.VMDivergence){
line=2576;
				BBline[0]  = BollingerMACD[0];
				BBdot[0]   = BBline[0];
				BBUpper[0] = BollingerMACD.Avg[0] + SDBB[0]*this.StdDevNumber;
				BBLower[0] = BollingerMACD.Avg[0] - SDBB[0]*this.StdDevNumber;
	            if (IsRising(BBline))
	            {
line=2583;
	                if (BBline[0] > BBUpper[0])
	                {
	                    //bbDotTrend[0] = 2.0;
	                    PlotBrushes[BBdot_PLOT_ID][0] = DotsUpRisingColor;
	                }
	                else
	                {
	                    //bbDotTrend[0] = 1.0;
	                    PlotBrushes[BBdot_PLOT_ID][0] = DotsDownRisingColor;
	                }
	            }
	            else if (IsFalling(BBline))
	            {
line=2597;
	                if (BBline[0] < BBLower[0])
	                {
	                    //bbDotTrend[0] = -2.0;
	                    PlotBrushes[BBdot_PLOT_ID][0] = DotsDownFallingColor;
	                }
	                else
	                {
	                   // bbDotTrend[0] = -1.0;
	                    PlotBrushes[BBdot_PLOT_ID][0] = DotsUpFallingColor;
	                }
	            }
	            else if(CurrentBars[0]>1)
	            {
	                //bbDotTrend[0] = bbDotTrend[1];
	                PlotBrushes[BBdot_PLOT_ID][0] = PlotBrushes[BBdot_PLOT_ID][1];
	            }
			}
			#endregion
			#region -- Calculate ExcursionSeries --
			if(IsFirstTickOfBar){
line=2619;
//foreach(var kvp in AnalysisSets) Print(line+"  AnalysisSets["+kvp.Key+"]");
				if(this.pAnalysisType == ARC_CycleForecaster_AnalysisType.VMDivergence){
					ExcursionSeries[0] = sma65[0];
				}else{
					CurrentASet.ShiftedHistoAbs.Add(Math.Abs(CurrentASet.ShiftedHisto[0]));
					while(CurrentASet.ShiftedHistoAbs.Count>65) CurrentASet.ShiftedHistoAbs.RemoveAt(0);
					ExcursionSeries[0] = CurrentASet.ShiftedHistoAbs.Average();
				}
			}
			#endregion

			foreach(var kvp in AnalysisSets){
				if(!pIsMultiSignal && kvp.Key!=pAnalysisType) continue;
				if(kvp.Value.Histo[1]>FLAT) kvp.Value.Sign1 = UP;
				if(kvp.Value.Histo[1]<FLAT) kvp.Value.Sign1 = DOWN;
				DateTime tfuture = Time[0].AddDays(7);
				if(CSVfilename.Length>0)
					CSVcontents[tfuture.ToBinary()] = MakeString(new Object[] {"0",tfuture.ToBinary(), tfuture, kvp.Value.Histo[0],tfuture.ToString("HHmm"),Close[0],NL},",");
				if(kvp.Value.NewDayFlag && (kvp.Value.Sign1>0 && kvp.Value.Histo[0]<0 || kvp.Value.Sign1<0 && kvp.Value.Histo[0]>0)){
					kvp.Value.NewDayFlag = false;
					HandleHistoPeakCalculation(kvp.Value.DTlastHistoPeakCalc, kvp.Value);
					kvp.Value.DTlastHistoPeakCalc = Time[0];

					kvp.Value.YesterdayDOW = PriorDayDT.DayOfWeek;
//					DayCount[(int)YesterdayDOW]++;

					AutoCalculateLevels(ref pMaxLowPeakForValidMarker, ref pMinHighPeakForValidMarker, CurrentBar-1, kvp.Value.HighPeaksToday, kvp.Value.LowPeaksToday, kvp.Value.GaplessHisto, kvp.Value.LongTimeLabels, kvp.Value.ShortTimeLabels);
					if(pSavePredictions && ChartControl!=null) {
						foreach(TimePrice pt in kvp.Value.HighPeaksToday) {
							int abar = Bars.GetBar(pt.Time);
							if(kvp.Value.GaplessHisto.ContainsKey(pt.Time))
								WriteToCSV(pt.Time.AddDays(7),DOWN,kvp.Value.GaplessHisto[pt.Time].Val, Bars.GetClose(abar));
							else
								WriteToCSV(pt.Time.AddDays(7),DOWN,0,Bars.GetClose(abar));
						}
						foreach(TimePrice pt in kvp.Value.LowPeaksToday) {
							int abar = Bars.GetBar(pt.Time);
							if(kvp.Value.GaplessHisto.ContainsKey(pt.Time))
								WriteToCSV(pt.Time.AddDays(7),UP,kvp.Value.GaplessHisto[pt.Time].Val, Bars.GetClose(abar));
							else
								WriteToCSV(pt.Time.AddDays(7),UP,0,Bars.GetClose(abar));
						}
						if(CSVcontents.Count>0 && CSVfilename.Length>0) {
//							MktAnalyzerDataWritten = true;
							var full_name = CSVfilename.Replace(".txt",kvp.Key.ToString()+".txt");
							foreach(string s in CSVcontents.Values)
								System.IO.File.AppendAllText(full_name,s);
							CSVcontents.Clear();
							Draw.TextFixed(this, "MktAdata",MakeString(new Object[] {longs," long predictions and ",shorts," short predictions written to file: ",full_name}),TextPosition.BottomRight);
						}
					}

					PlacePredictionRecords (pMinHighPeakForValidMarker, pMaxLowPeakForValidMarker, kvp.Value);

					kvp.Value.HighPeaksToday.Clear();
					kvp.Value.LowPeaksToday.Clear();

					kvp.Value.HistoHighPeaks.Sort();
					kvp.Value.HistoLowPeaks.Sort();

					if(kvp.Value.HistoHighPeaks.Count>1) {
						if(kvp.Value.HistoHighPeaks[0].Ticks>kvp.Value.HistoHighPeaks[1].Ticks) kvp.Value.HistoHighPeaks.Reverse();
						//while(DateTime.Compare(HistoHighPeaks[0],LastWeekKey)<0) HistoHighPeaks.RemoveAt(0);
					}
					if(kvp.Value.HistoLowPeaks.Count>1) {
						if(kvp.Value.HistoLowPeaks[0].Ticks>kvp.Value.HistoLowPeaks[1].Ticks)   kvp.Value.HistoLowPeaks.Reverse();
						//while(DateTime.Compare(HistoLowPeaks[0],LastWeekKey)<0) HistoLowPeaks.RemoveAt(0);
					}
				}
				DrawMarkers(0, kvp.Key, kvp.Value.ShortTimeLabels, kvp.Value.LongTimeLabels, MultiSigBuyClusters, MultiSigSellClusters);

				while(kvp.Value.HistoHighPeaks.Count>0 && kvp.Value.HistoHighPeaks[0]<now) kvp.Value.HistoHighPeaks.RemoveAt(0);
				while(kvp.Value.HistoLowPeaks.Count>0  && kvp.Value.HistoLowPeaks[0]<now)  kvp.Value.HistoLowPeaks.RemoveAt(0);
				nextSignal[0]=(0);
				#region calculate NextSignal
				if(kvp.Value.HistoHighPeaks.Count>0 && kvp.Value.HistoLowPeaks.Count>0) {
					if(DateTime.Compare(kvp.Value.HistoHighPeaks[0],kvp.Value.HistoLowPeaks[0])<0) {
						nextSignal[0] = DOWN;
					} else if(DateTime.Compare(kvp.Value.HistoHighPeaks[0],kvp.Value.HistoLowPeaks[0])>0) {
						nextSignal[0] = UP;
					}
				}
				else if(kvp.Value.HistoHighPeaks.Count>0) {
					nextSignal[0] = DOWN;
				} else {
					nextSignal[0] = UP;
				}
				#endregion
				string msgs = AssemblePredictionMsgs(kvp.Value.HistoHighPeaks, kvp.Value.HistoLowPeaks);
				if(CurrentBar>Bars.Count-5 && ChartControl!=null && pPredictionMsgLoc!=ARC_CycleForecaster_PredictionLocType.None) {
					DrawOnPricePanel = true;
					if(pPredictionMsgLoc==ARC_CycleForecaster_PredictionLocType.TopRight)         Draw.TextFixed(this, "pred", msgs, TextPosition.TopRight,    Brushes.White, ChartControl.Properties.LabelFont, Brushes.Black, Brushes.Black, 40);
					else if(pPredictionMsgLoc==ARC_CycleForecaster_PredictionLocType.TopLeft)     Draw.TextFixed(this, "pred", msgs, TextPosition.TopLeft,     Brushes.White, ChartControl.Properties.LabelFont, Brushes.Black, Brushes.Black, 40);
					else if(pPredictionMsgLoc==ARC_CycleForecaster_PredictionLocType.Center)      Draw.TextFixed(this, "pred", msgs, TextPosition.Center,      Brushes.White, ChartControl.Properties.LabelFont, Brushes.Black, Brushes.Black, 40);
					else if(pPredictionMsgLoc==ARC_CycleForecaster_PredictionLocType.BottomRight) Draw.TextFixed(this, "pred", msgs, TextPosition.BottomRight, Brushes.White, ChartControl.Properties.LabelFont, Brushes.Black, Brushes.Black, 40);
					else if(pPredictionMsgLoc==ARC_CycleForecaster_PredictionLocType.BottomLeft)  Draw.TextFixed(this, "pred", msgs, TextPosition.BottomLeft,  Brushes.White, ChartControl.Properties.LabelFont, Brushes.Black, Brushes.Black, 40);
				}

				SinceLaunch = new TimeSpan(Math.Abs(NinjaTrader.Core.Globals.Now.Ticks - TimeAtLaunch.Ticks));
				if(Debug && CurrentBar>Bars.Count-2) {
					Print(SinceLaunch.TotalSeconds+" seconds to execute "+Bars.Count+"-bars ARC_CycleForecaster "+kvp.Key.ToString());
				}
			}
}catch(Exception x){
	#region -- error --
	TimeOfError = NinjaTrader.Core.Globals.Now; 
	ErrorMsg = MakeString(new Object[]{line,":  ARC_CycleForecaster Error @ bar ",Time[0], " ",x,NL,"----",NL,"Max/Min: ",this.pMinHighPeakForValidMarker,"/",this.pMaxLowPeakForValidMarker,NL,Instrument.FullName," ",Bars.BarsPeriod.ToString(),NL,"Bars.Count: ",Bars.Count,"   CB: ",CurrentBar,"  BIP: ",BarsInProgress,NL,"---- end of report ----"}); 
	Print(ErrorMsg); 
	string s1 = x.ToString();
	if(ChartControl!=null) {
		if(s1.Contains("Memory")) Draw.TextFixed(this, "ns_cferror",MakeString(new Object[]{"Possible memory error occurred.",NL,"See OutputWindow for more details",NL,"Please close down NinjaTrader and reopen"}),TextPosition.BottomRight);
		else if(s1.Contains("ArgumentOutOfRange")) Draw.TextFixed(this, "ns_cferror",MakeString(new Object[]{"ArgumentOutOfRange",NL,"See OutputWindow for more details",NL,"Please close down NinjaTrader and reopen"}),TextPosition.BottomRight);
		else Draw.TextFixed(this, "ns_cferror",MakeString(new Object[]{"ARC_CycleForecaster Error",NL,"See OutputWindow for more details",NL,"Please close down NinjaTrader and reopen"}),TextPosition.BottomRight);
	} else {
		if(s1.Contains("Memory")) PrintMakeString(new Object[]{"Possible memory error occurred.",NL,"See OutputWindow for more details",NL,"Please close down NinjaTrader and reopen"});
		else if(s1.Contains("ArgumentOutOfRange")) PrintMakeString(new Object[]{"ArgumentOutOfRange",NL,"See OutputWindow for more details",NL,"Please close down NinjaTrader and reopen"});
		else PrintMakeString(new Object[]{"ARC_CycleForecaster Error",NL,"See OutputWindow for more details",NL,"Please close down NinjaTrader and reopen"});
	}
	#endregion
}
        }
//===========================================================================================================
		private void WriteToCSV(DateTime FutureTime, int PeakType, double HistoValue, double ClosePrice){
			CSVcontents[FutureTime.ToBinary()]=(MakeString(new Object[] {PeakType,FutureTime.ToBinary(),FutureTime,HistoValue,/*FutureTime.ToString("HHmm"),ClosePrice,*/NL},","));
			if(PeakType==-1) shorts++;
			else if(PeakType==1) longs++;
		}
//===========================================================================================================
		private string DrawMarkerThisBar(char Type, ARC_CycleForecaster_AnalysisType AnalysisType, DateTime t){
			return DrawMarkerThisBar(Type, AnalysisType, CurrentBars[0]-BarsArray[0].GetBar(t));
		}
//===========================================================================================================
		private string DrawMarkerThisBar(char Type, ARC_CycleForecaster_AnalysisType AnalysisType, int relativebar){
			if(relativebar<0 || relativebar > BarsArray[0].Count-5) return string.Empty;
			string tag_drawn = string.Empty;
			int abar = CurrentBars[0]-relativebar;
			#region -- DrawMarker this bar --
			if(ChartControl==null) {
				if(Type=='S')      ShortSig[relativebar] = High[relativebar]+TickSize*pMarkerSeparation;
				else if(Type=='L') LongSig[relativebar]  = Low[relativebar]-TickSize*pMarkerSeparation;
				if(IsDebug){
					if(Type=='S') Print(Times[0][0].ToString()+"  "+Type+"   Short: "+ShortSig[relativebar]);
					if(Type=='L') Print(Times[0][0].ToString()+"  "+Type+"   Long: "+LongSig[relativebar]);
				}
//PrintMakeString(new Object[]{Time[0].ToString(),"  Drawing short dot at ",Time[relativebar].ToString(),"  Relative bar: ",relativebar,"   Dot at: ",ShortSig[0]});
			}
			else {
line=2781;
				//try{
//PrintOnce("CB: "+CurrentBars[0]+"   BackBrushes.Count: "+BackBrushes.Count);
				if(pRacingStripeDirection != ARC_CycleForecaster_MarkerDirection.None){
					#region -- nullify BackBrush --
					if(pRacingStripeType == ARC_CycleForecaster_RacingStripeType.Subpanel) 
						BackBrushes.Set(abar, null);
					else 
						BackBrushesAll.Set(abar, null);
					#endregion
line=2791;
					#region -- Add RacingStripe to BackBrush if necessary --
					if(Type == 'L' && (pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.Longs || pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.Both)) {
						if(pRacingStripeType == ARC_CycleForecaster_RacingStripeType.Subpanel) BackBrushes[relativebar] = LongRacingStripeBrush;
						else BackBrushesAll[relativebar] = LongRacingStripeBrush;
					}
					if(Type == 'S' && (pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.Shorts || pRacingStripeDirection == ARC_CycleForecaster_MarkerDirection.Both)) {
						if(pRacingStripeType == ARC_CycleForecaster_RacingStripeType.Subpanel) BackBrushes[relativebar] = ShortRacingStripeBrush;
						else BackBrushesAll[relativebar] = ShortRacingStripeBrush;
					}
					#endregion
				}
				//}catch(Exception e1){Print(line+":  "+e1.ToString());}

//PrintMakeString(new Object[]{Time[0].ToString(),"  Drawing short dot at ",Time[relativebar].ToString(),"  Relative bar: ",relativebar,"   Dot at: ",ShortSig[0]});
line=2806;
				DrawOnPricePanel = true;
				double offset = TickSize * pMarkerSeparation;
				//try{
				if(Type=='L' && (pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Longs || pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Both)){
					if(pGlobalizeMarkers){
						tag_drawn = DrawSpecificMarkerType(AnalysisType, pLongMarkerType, Type, relativebar, Low[relativebar]-offset, pLongMarker_Template);
					}else{
						tag_drawn = DrawSpecificMarkerType(AnalysisType, pLongMarkerType, Type, relativebar, Low[relativebar]-offset, pLongMarkerColor);
					}
					if(pLongWAV.Length>0 && SoundsAreActive)  SoundAlertHandler(UP, pLongWAV);
					if(SpeechEnabled) SayIt(pLongPhrase,0);
				}else if(Type=='S' && (pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Shorts || pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Both)){
//if(Times[0][relativebar].Hour==9 && Times[0][relativebar].Minute==20) Print(Times[0][relativebar].ToString()+"   High: "+High[relativebar]+"   offset: "+offset);
line=2820;
					if(pGlobalizeMarkers){
						tag_drawn = DrawSpecificMarkerType(AnalysisType, pShortMarkerType, Type, relativebar, High[relativebar]+offset, pShortMarker_Template);
					}else{
						tag_drawn = DrawSpecificMarkerType(AnalysisType, pShortMarkerType, Type, relativebar, High[relativebar]+offset, pShortMarkerColor);
					}
line=2826;
					if(pShortWAV.Length>0 && SoundsAreActive)  SoundAlertHandler(DOWN, pShortWAV);
					if(SpeechEnabled) SayIt(pShortPhrase,0);
				}
//Print("------------------- Drawing short dot on chart");
				//if(ShiftedHisto.IsValidDataPoint(relativebar)) ShortSig[relativebar]=(ShiftedHisto[relativebar]);
line=2832;
				//}catch(Exception e1){Print(line+":  "+e1.ToString());}
			}
			#endregion
			return tag_drawn;
		}
//===========================================================================================================
		#region -- DrawSpecificMarkerType --
		private string DrawSpecificMarkerType(ARC_CycleForecaster_AnalysisType AnalysisType, ARC_CycleForecaster_MarkerType MarkerType, char Dir, int relativebar, double price, Brush clr){
			MarkersThisBar = MarkersThisBar+1;
			if(MarkersThisBar>1){//stagger multiple arrows on same bar
				if(Dir=='L') price = price - MarkersThisBar * Math.Max(1,this.pMarkerSeparation)*TickSize;
				else price = price + MarkersThisBar * Math.Max(1,this.pMarkerSeparation)*TickSize;
			}
			var tag = AnalysisType.ToString();
			tag = string.Format("nscf_{0}-{1}-{2}", tag.Substring(0, Math.Min(tag.Length,3)), CurrentBars[0]-relativebar, Dir);

			if(MarkerType == ARC_CycleForecaster_MarkerType.Dot)
				TriggerCustomEvent(o2 =>{	
					Draw.Dot(this, tag, true, relativebar, price, clr);
				},0,null);
			else if(MarkerType == ARC_CycleForecaster_MarkerType.Diamond)
				TriggerCustomEvent(o2 =>{	
					Draw.Diamond(this, tag, true, relativebar, price, clr);
				},0,null);
			else if(MarkerType == ARC_CycleForecaster_MarkerType.Square)
				TriggerCustomEvent(o2 =>{	
					Draw.Square(this, tag, true, relativebar, price, clr);
				},0,null);
			else if(MarkerType == ARC_CycleForecaster_MarkerType.ArrowUp)
				TriggerCustomEvent(o2 =>{	
					Draw.ArrowUp(this, tag, true, relativebar, price, clr);
				},0,null);
			else if(MarkerType == ARC_CycleForecaster_MarkerType.ArrowDown)
				TriggerCustomEvent(o2 =>{	
					Draw.ArrowDown(this, tag, true, relativebar, price, clr);
				},0,null);
			else if(MarkerType == ARC_CycleForecaster_MarkerType.TriangleUp)
				TriggerCustomEvent(o2 =>{	
					Draw.TriangleUp(this, tag, true, relativebar, price, clr);
				},0,null);
			else if(MarkerType == ARC_CycleForecaster_MarkerType.TriangleDown)
				TriggerCustomEvent(o2 =>{	
					Draw.TriangleDown(this, tag, true, relativebar, price, clr);
				},0,null);
			return tag;
		}
		private string DrawSpecificMarkerType(ARC_CycleForecaster_AnalysisType AnalysisType, ARC_CycleForecaster_MarkerType MarkerType, char Dir, int relativebar, double price, string DrawingTemplateName){
			if(DrawingTemplateName.Contains("> ")){
				int i = DrawingTemplateName.IndexOf("> ");
				DrawingTemplateName = DrawingTemplateName.Substring(i+2);
			}
			MarkersThisBar = MarkersThisBar+1;
			if(MarkersThisBar>1){//stagger multiple arrows on same bar
				if(Dir=='L') price = price - MarkersThisBar * Math.Max(1,this.pMarkerSeparation)*TickSize;
				else price = price + MarkersThisBar * Math.Max(1,this.pMarkerSeparation)*TickSize;
			}
			var tag = AnalysisType.ToString();
			tag = string.Format("nscf_{0}-{1}-{2}", tag.Substring(0, Math.Min(tag.Length,3)), CurrentBars[0]-relativebar, Dir);

			if(MarkerType == ARC_CycleForecaster_MarkerType.Dot)
				TriggerCustomEvent(o2 =>{	
					Draw.Dot(this, tag, true, relativebar, price, true, DrawingTemplateName);
				},0,null);
			else if(MarkerType == ARC_CycleForecaster_MarkerType.Diamond)
				TriggerCustomEvent(o2 =>{	
					Draw.Diamond(this, tag, true, relativebar, price, true, DrawingTemplateName);
				},0,null);
			else if(MarkerType == ARC_CycleForecaster_MarkerType.Square)
				TriggerCustomEvent(o2 =>{	
					Draw.Square(this, tag, true, relativebar, price, true, DrawingTemplateName);
				},0,null);
			else if(MarkerType == ARC_CycleForecaster_MarkerType.ArrowUp)
				TriggerCustomEvent(o2 =>{	
					Draw.ArrowUp(this, tag, true, relativebar, price, true, DrawingTemplateName);
				},0,null);
			else if(MarkerType == ARC_CycleForecaster_MarkerType.ArrowDown)
				TriggerCustomEvent(o2 =>{	
					Draw.ArrowDown(this, tag, true, relativebar, price, true, DrawingTemplateName);
				},0,null);
			else if(MarkerType == ARC_CycleForecaster_MarkerType.TriangleUp)
				TriggerCustomEvent(o2 =>{	
					Draw.TriangleUp(this, tag, true, relativebar, price, true, DrawingTemplateName);
				},0,null);
			else if(MarkerType == ARC_CycleForecaster_MarkerType.TriangleDown)
				TriggerCustomEvent(o2 =>{	
					Draw.TriangleDown(this, tag, true, relativebar, price, true, DrawingTemplateName);
				},0,null);
			return tag;
		}
		#endregion
//===========================================================================================================
		private void DrawMarkers(int relativebar, ARC_CycleForecaster_AnalysisType AnalysisType, SortedDictionary<DateTime, double> ShortTimeLabels, SortedDictionary<DateTime, double> LongTimeLabels, List<int> BuyClusters, List<int> SellClusters) {
			#region -- DrawMarkers --
			if(relativebar>=CurrentBar) return;
			if(!pPermitEarlySignals && MaxWeeksAccessible < pMaxWeeks) return;

			var t = CurrentBars[0]-(relativebar+1);
line=2932;
			var ListOfSignalDT = ShortTimeLabels.Keys.ToList();
			if(IsThisBarPredicted(ListOfSignalDT, Time[relativebar], Time[relativebar+1])) {
				if(this.pIsMultiSignal && pMultiSignalArrowCount>1) {
					MultiSigSellClusters[0] = MultiSigSellClusters[0]+1;
					int sig = MultiSigSellClusters.Sum();
					if(sig >= pMultiSignalArrowCount){//if the signal count on all bars within the BarVariance is greater than the pMultiSignalArrowCount, then the signal is significant, draw it
						DrawMarkerThisBar('S', AnalysisType, relativebar);
						for(int i = 0; i<MultiSigSellClusters.Count; i++) MultiSigSellClusters[i] = -MultiSigSellClusters[i];//once a valid multisig arrow is found, clear out the shorts count so we can start building another signal count on subsequent bars
					}
				}else
					DrawMarkerThisBar('S', AnalysisType, relativebar);
			}
			else {
				ListOfSignalDT = LongTimeLabels.Keys.ToList();
				if(IsThisBarPredicted(ListOfSignalDT, Time[relativebar], Time[relativebar+1])) {
					if(this.pIsMultiSignal && pMultiSignalArrowCount>1) {
						MultiSigBuyClusters[0] = MultiSigBuyClusters[0]+1;
						int sig = MultiSigBuyClusters.Sum();
						if(sig >= pMultiSignalArrowCount){//if the signal count on all bars within the BarVariance is greater than the pMultiSignalArrowCount, then the signal is significant, draw it
							DrawMarkerThisBar('L', AnalysisType, relativebar);
							for(int i = 0; i<MultiSigBuyClusters.Count; i++) MultiSigBuyClusters[i] = -MultiSigBuyClusters[i];//once a valid multisig arrow is found, clear out the longs count so we can start building another signal count on subsequent bars
						}
					}else
						DrawMarkerThisBar('L', AnalysisType, relativebar);
				}
			}
			#endregion
		}
//===========================================================================================================
		private void SoundAlertHandler(int direction, string wav){
line=2963;
			if(SoundAlertBar != CurrentBars[0] && State == State.Realtime){
				wav = AddSoundFolder(wav.Replace("<inst>",Instrument.MasterInstrument.Name));
				//Print("Looking for wav: "+wav);
				if(System.IO.File.Exists(wav)){
					if(direction == UP)   Alert("long",  Priority.High, "CycleForecasterer Long",  wav, 1,  Brushes.Green, Brushes.White);
					if(direction == DOWN) Alert("short",  Priority.High, "CycleForecasterer Short",  wav, 1,  Brushes.Red, Brushes.White);
				}
				SoundAlertBar = CurrentBars[0];
			}
		}
//===========================================================================================================
//===========================================================================================================
	private double CalcCCI(int period, int relativebar) {
		double avg1 = SMA(Typical, period)[relativebar];
		double mean = 0;
		for (int idx = Math.Min(CurrentBar-relativebar, period - 1); idx >= 0; idx--) {
			double avg2 = SMA(Typical, period)[idx+relativebar];
			mean += Math.Abs(Typical[idx+relativebar] - avg2);
		}
		return ((Typical[relativebar] - avg1) / (mean == 0 ? 1 : (0.015 * (mean / Math.Min(period, CurrentBar - relativebar + 1)))));
	}
//===========================================================================================================
	private double CalculateCore(ARC_CycleForecaster_AnalysisType AnalysisType, int relativebar, DateTime TimeThisBar, DateTime TimePriorBar){
		#region -- CalculateCore --
		if(CurrentBars[0]<relativebar) return 0;
//if(TimeThisBar.Day !=TimePriorBar.Day) Print(NL,"PriorDay: ",TimePriorBar.ToString(),"   New day: ",TimeThisBar.ToString());
//		ISeries<double> H, L, C;
//
//		H = High;
//		L = Low;
//		C = Close;
//string infomsg = string.Empty;
		double p=0;

#if GAPLESS_DIFFTOOPEN
		if((TimeThisBar.Ticks >= ZeroTime.Ticks && TimePriorBar.Ticks < ZeroTime.Ticks)){// || TimeThisBar.Ticks > ZeroTime.Ticks) {
			DateTime PriorZeroTime = ZeroTime;
			ZeroTime = new DateTime(TimeThisBar.Year, TimeThisBar.Month, TimeThisBar.Day, ZeroTime.Hour, ZeroTime.Minute, 0,0);
			TodayOpen = Open[relativebar];
			if(AnalysisType == ARC_CycleForecaster_AnalysisType.GaplessPZ) {
				double slow = SMA(pPowerZonePeriod)[relativebar];
				OpenGap = TodayOpen - slow;
			}
		}
		while(TimeThisBar.Ticks>ZeroTime.Ticks) ZeroTime = ZeroTime.AddDays(1);
#endif
line=3010;
		PlotB[relativebar]=0;
		PlotC[relativebar]=0;
		if(AnalysisType == ARC_CycleForecaster_AnalysisType.CCI) {
			//AnalysisDesc = "CCI(",pCCIperiod,")";
			//TableHeader = "Chart TimeSlice, TimeSlice#, Net count, , , , ,,Dates included (",DayCount,")";
			p = CalcCCI(pCCIperiod, relativebar);//CCI(pCCIperiod)[relativebar];
			PlotA[relativebar] = p;
			
		} else if(AnalysisType == ARC_CycleForecaster_AnalysisType.Stoch) {
			//AnalysisDesc = "Stoch(k: ",pKperiod," d:",pDperiod,")";
			//TableHeader = "Chart TimeSlice, TimeSlice#, Net count, , , , ,,Dates included (",DayCount,")";
			p = stoch.D[relativebar]-50.0;
			PlotA[relativebar] = p;
			PlotB[relativebar] = stoch.K[relativebar]-50.0;
		} else if(AnalysisType == ARC_CycleForecaster_AnalysisType.RSI) {
			//AnalysisDesc = "RSI(k: ",pKperiod," d:",pDperiod,")";
			//TableHeader = "Chart TimeSlice, TimeSlice#, Net count, , , , ,,Dates included (",DayCount,")";
			p = rsi[relativebar]-50.0;
			PlotA[relativebar] = p;
			PlotB[relativebar] = rsi.Avg[relativebar]-50.0;
		} else if(AnalysisType == ARC_CycleForecaster_AnalysisType.Fisher) {
			//AnalysisDesc = "RSI(k: ",pKperiod," d:",pDperiod,")";
			//TableHeader = "Chart TimeSlice, TimeSlice#, Net count, , , , ,,Dates included (",DayCount,")";
			p = fisher[relativebar];
			PlotA[relativebar] = p;
#if RSS_AND_RVI
		} else if(AnalysisType == ARC_CycleForecaster_AnalysisType.RSS) {
			//AnalysisDesc = "RSI(k: ",pKperiod," d:",pDperiod,")";
			//TableHeader = "Chart TimeSlice, TimeSlice#, Net count, , , , ,,Dates included (",DayCount,")";
			p = rss[relativebar]-50.0;
			PlotA[relativebar] = p;
		} else if(AnalysisType == ARC_CycleForecaster_AnalysisType.RVI) {
			//AnalysisDesc = "RSI(k: ",pKperiod," d:",pDperiod,")";
			//TableHeader = "Chart TimeSlice, TimeSlice#, Net count, , , , ,,Dates included (",DayCount,")";
			p = rvi[relativebar]-50.0;
			PlotA[relativebar] = p;
#endif
		} else if(AnalysisType == ARC_CycleForecaster_AnalysisType.MACD) {
			//AnalysisDesc = "MACD(",pMACDfast,",",pMACDslow,",",pMACDsmooth,")";
			//TableHeader = "Chart TimeSlice, TimeSlice#, Net count, , , , ,,Dates included (",DayCount,")";
			p = macd[relativebar];
			PlotA[relativebar] = p;
			PlotB[relativebar] = macd.Avg[relativebar];
			PlotC[relativebar] = macd.Diff[relativebar];

		} else if(AnalysisType == ARC_CycleForecaster_AnalysisType.MACDHisto) {
			//AnalysisDesc = "MACD(",pMACDfast,",",pMACDslow,",",pMACDsmooth,")";
			//TableHeader = "Chart TimeSlice, TimeSlice#, Net count, , , , ,,Dates included (",DayCount,")";
			p = macd.Diff[relativebar];
			PlotA[relativebar] = p;
			PlotB[relativebar] = macd[relativebar];
			PlotC[relativebar] = macd.Avg[relativebar];

		} else if(AnalysisType == ARC_CycleForecaster_AnalysisType.VMDivergence) {
//			try{
            p = MACD1.Diff[relativebar] + MACD2.Diff[relativebar] + MACD3.Diff[relativebar] + MACD4.Diff[relativebar];
			PlotA[relativebar] = p;
//			}catch(Exception e2){Print("-------------"+NL+"BIP: "+BarsInProgress+" "+line+":  relbar: "+relativebar+"  cb: "+CurrentBars[0]+NL+e2.ToString());}
		}
#if GAPLESS_DIFFTOOPEN
		else if(AnalysisType == ARC_CycleForecaster_AnalysisType.GaplessPZ) {
			if(TodayOpen == double.MinValue) p = 0;
			else {
				double slow = SMA(pPowerZonePeriod)[relativebar];
				p = Close[relativebar] - slow - OpenGap;
			}
			PlotA[relativebar] = p;
		} 
		else if(AnalysisType == ARC_CycleForecaster_AnalysisType.DiffToOpen) {
			if(TodayOpen == double.MinValue) p = 0;
			else p = (High[relativebar]+Low[relativebar])/2.0 - TodayOpen;
			PlotA[relativebar] = p;
		} 
#endif
//		else if(AnalysisType == ARC_CycleForecaster_AnalysisType.UpDownFromZeroTime) {
//					if(TodayOpen < 0) return;
//					//AnalysisDesc = "Is bar above or below the open of the day?  Positive count = Price is above open    Negative count = Price below open";
//					//TableHeader = "Chart TimeSlice, TimeSlice#, Net count, Pos count, Neg count, Pos/Total, Neg/Total,,Dates included ("+DayCount+")";
//					p = (High[relativebar]+Low[relativebar])/2.0;
//					if(p > TodayOpen) CountsHisto[DayOfWk,slice] = CountsHisto[DayOfWk,slice]+1;
//					else CountsHisto[DayOfWk,slice] = CountsHisto[DayOfWk,slice]-1;
//
//				} else if(AnalysisType == ARC_CycleForecaster_AnalysisType.UpDownTrend) {
//					//AnalysisDesc = "Is the "+pPowerZonePeriod+"-SMA up from prior bar or down from prior bar?  Pos = Up counts   Neg = Down counts";
//					//TableHeader = "Chart TimeSlice, TimeSlice#, Net count, Pos count, Neg count, Pos/Total, Neg/Total,,Dates included ("+DayCount+")";
//					ma1 = SMA(pPowerZonePeriod)[relativebar+1];
//					ma0 = SMA(pPowerZonePeriod)[relativebar];
//					if(ma0 > ma1) CountsHisto[DayOfWk,slice] = CountsHisto[DayOfWk,slice]+1;
//					else CountsHisto[DayOfWk,slice] = CountsHisto[DayOfWk,slice]-1;
//				}
//Print("                            ");
		return p;
		#endregion
	}
//===========================================================================================================
	private double CalculateHisto(int relativebar, SortedDictionary<DateTime, double> CoreData) {
		#region -- CalculateHisto --
		if(EarliestDay == DateTime.MinValue) EarliestDay = Time[relativebar];
		int averager = 0;
		double CoreTotal = 0;
		bool printit = false;//Time[relativebar].Hour==12 && Time[relativebar].Minute==9;
		DateTime Tminus7 = Time[relativebar];
		if(printit) Print(MakeString(new Object[]{NL,Time[relativebar].ToString(),"  Core: "}));
		for(int weekptr = 0; weekptr < this.pMaxWeeks; weekptr++){
			if(DateTime.Compare(Tminus7,EarliestDay)<0) break;
			if(CoreData.Keys.Contains(Tminus7)) {
				CoreTotal = CoreTotal + CoreData[Tminus7];
				if(printit) Print(MakeString(new Object[]{weekptr,":       ",CoreData[Tminus7].ToString("0.0000")," at ",Tminus7.ToString()}));
				averager++;
			}
			Tminus7 = Tminus7.AddDays(-7);
			//AdjustTimeForHolidays(ref Tminus7, -7, printit);
		}
		//if(printit)Print("CoreTotal: "+CoreTotal.ToString()+" / count: "+averager+"   Avg: "+(CoreTotal/averager).ToString("0.0000"));
		if(averager>0) {
			if(printit) Print("  Histo returned: "+(CoreTotal/averager).ToString("0.0000"));
//if(Time[relativebar].Hour==12 && Time[relativebar].Minute==9) Print(Time[relativebar].ToString()+"  Histo: "+(CoreTotal/averager).ToString("0.0000")+"    line 1737");
			return(CoreTotal / averager);
		}
		else return(CoreTotal);
		#endregion
	}
//===========================================================================================================
	private void HandleHistoPeakCalculation (DateTime MinKey, AnalysisSet AnaSet) {
		#region -- Calculate the peaks in the GaplessHisto plot...build DateTime Lists of these peaks/valleys --
		double     maxhistoval = 0;
		double     minhistoval = 0;
		int abspredictedbar=0;
		double MAX_LOW_PEAK  = (pUseAutoPeakCalculation? 0: pMaxLowPeakForValidMarker);
		double MIN_HIGH_PEAK = (pUseAutoPeakCalculation? 0: pMinHighPeakForValidMarker);
		int i = 0;
		DateTime dt;

		//try{
			bool InZone =false;// HTimes[0].Day==1 && HTimes[0].Month==4;
			var HTimes = new List<DateTime>(from d in AnaSet.GaplessHisto.Keys 
				where DateTime.Compare(d, MinKey)>=0 && DateTime.Compare(d, Time[0])<=0
				select d);
			int HistoDirection = FLAT;
			DateTime PeakTime = DateTime.MinValue;//(HTimes.Count>0 && GaplessHisto[HTimes[0]]>0 ? HTimes[0]: DateTime.MinValue);
			DateTime ValleyTime = DateTime.MinValue;//(HTimes.Count>0 && GaplessHisto[HTimes[0]]<0 ? HTimes[0]: DateTime.MinValue);
			DateTime ZeroCrossedDT = DateTime.MinValue;
			for(i = 0; i<HTimes.Count; i++) {
				//try{
					DateTime t0 = HTimes[i];
					double Histo0 = AnaSet.GaplessHisto[t0].Val;
					if(Histo0>0 && HistoDirection != UP) {
						if(ValleyTime != DateTime.MinValue){
//							dt = ValleyTime.AddMinutes(-this.pMinutesAdvanceWarning);
							AnaSet.LowPeaksToday.Add(new TimePrice(ValleyTime, minhistoval));
						}
						ValleyTime = DateTime.MinValue;
						ZeroCrossedDT = HTimes[i];
						maxhistoval = Histo0;
						if(maxhistoval > MIN_HIGH_PEAK) PeakTime = t0;
						HistoDirection = UP;
					}
					else if(Histo0<0 && HistoDirection != DOWN) {
						if(PeakTime != DateTime.MinValue){
//							dt = PeakTime.AddMinutes(-this.pMinutesAdvanceWarning);
							AnaSet.HighPeaksToday.Add(new TimePrice(PeakTime, maxhistoval));
						}
						PeakTime = DateTime.MinValue;
						ZeroCrossedDT = HTimes[i];
						minhistoval = Histo0;
						if(minhistoval < MAX_LOW_PEAK) ValleyTime = t0;
						HistoDirection = DOWN;
					}
line=3171;
					if(Histo0>0 && HistoDirection == UP && Histo0 >= maxhistoval) {
						maxhistoval = Histo0;
						if(maxhistoval > MIN_HIGH_PEAK) {
							PeakTime = t0;
						}
					}
					else if(Histo0<0 && HistoDirection == DOWN && Histo0 <= minhistoval) {
						minhistoval = Histo0;
						if(minhistoval < MAX_LOW_PEAK) {
							ValleyTime = t0;
						}
					}
				//}catch(Exception err1) {  }
			}
		//}catch(Exception err){  }
		#endregion
	}
//===========================================================================================================
	private void PlacePredictionRecords (double minhigh, double maxlow, AnalysisSet AnaSet) {
		#region -- Determine which peaks from HistoPeaks are valid and update HistoHighPeaks and HistoLowPeaks --
		for(int i = 0; AnaSet.HighPeaksToday!=null && i<AnaSet.HighPeaksToday.Count; i++){
			if(AnaSet.HighPeaksToday[i].Price >= minhigh) {
				AnaSet.HistoHighPeaks.Add(AnaSet.HighPeaksToday[i].Time.AddDays(7));
			}
		}
		for(int i = 0; AnaSet.LowPeaksToday!=null && i<AnaSet.LowPeaksToday.Count; i++){
			if(AnaSet.LowPeaksToday[i].Price <= maxlow)  {
				AnaSet.HistoLowPeaks.Add(AnaSet.LowPeaksToday[i].Time.AddDays(7));
			}
		}
		#endregion
	}
//===========================================================================================================
	private bool IsThisBarPredicted(List<DateTime> PeaksList, DateTime TimeOfBar, DateTime TimeOfPriorBar) {
		#region -- IsThisBarPredicted --
		PredictionTimeToSearchFor = TimeOfBar;
		if(PeaksList.Exists(FindPredictionInList)) {
			PeaksList.Remove(TimeOfBar);
			return(true);
		}
		int i = 0;
		while(i<PeaksList.Count){
			if(PeaksList[i].Ticks <= TimeOfBar.Ticks && PeaksList[i].Ticks > TimeOfPriorBar.Ticks) {
				PeaksList.RemoveAt(i);
				return(true);
			}
			i++;
		}
		return false;
		#endregion
	}

//===========================================================================================================
	private bool IsThisBarPredicted(char Type, DateTime TimeOfBar, DateTime TimeOfPriorBar, AnalysisSet AnaSet) {
		if(AnaSet.GaplessHisto.Count(k=>k.Value.PrintTime.Ticks <= TimeOfBar.Ticks && k.Value.PrintTime.Ticks > TimeOfPriorBar.Ticks && k.Value.IsSignalBar==Type) > 0) {
			return(true);
		}
		return false;
	}
//===========================================================================================================
	public override void OnCalculateMinMax()
	{
		if(CurrentASet == null) return;
		#region -- OnCalculateMinMax --
		// make sure to always start fresh values to calculate new min/max values
		double tmpMin = 0;
		double tmpMax = 0;
		if(pViewState == ARC_CycleForecaster_ViewStates.Data){
			tmpMin = CurrentASet.FutureHistoMin;
			tmpMax = CurrentASet.FutureHistoMax;
		}
		double plotValue = 0;
		// For performance optimization, only loop through what is viewable on the chart
		for (int index = ChartBars.FromIndex; index <= ChartBars.ToIndex; index++)
		{
		  try{
			if(pViewState == ARC_CycleForecaster_ViewStates.Trading){
				if(!PlotA.IsValidDataPointAt(index)) continue;
				plotValue = PlotA.GetValueAt(index);
			}else{
				if(!CurrentASet.ShiftedHisto.IsValidDataPointAt(index)) continue;
				plotValue = CurrentASet.ShiftedHisto.GetValueAt(index);
			}
			tmpMin = Math.Min(tmpMin, plotValue);
			tmpMax = Math.Max(tmpMax, plotValue);
		  }catch(Exception ocmm){Print("OCMinMax: "+ocmm.ToString());}
		}
		// Finally, set the minimum and maximum Y-Axis values to +/- 50 ticks from the primary close value
		MinValue = tmpMin;
		MaxValue = tmpMax;
		#endregion
	}
//===========================================================================================================
	private int GetTimeLabelY(double histo, ChartScale chartScale, ARC_CycleForecaster_AnalysisType atype, double ev){
		#region -- GetTimeLabelY --
		int result = 0;
		if(!pIsMultiSignal){
			result = chartScale.GetYByValue( histo);
			result = pViewState==ARC_CycleForecaster_ViewStates.Data ? result : (histo > 0 ? chartScale.GetYByValue(ev)-pTimeLabelSeparation : chartScale.GetYByValue(-ev)+pTimeLabelSeparation);
		}else{
			if(atype == pAnalysisType)
				result = chartScale.GetYByValue( histo);
			else{
				if(histo>0) result = chartScale.GetYByValue( 0.8 * chartScale.MaxValue);
				else        result = chartScale.GetYByValue( 0.8 * chartScale.MinValue);
			}
		}
		return result;
		#endregion
	}
//========Plot============================================================
	protected override void OnRender(ChartControl chartControl, ChartScale chartScale) {
		#region -- initialize --
		if (!IsVisible) return;
		if(chartControl==null) return;
line=3287;
//try{
		if(RecalculateButtonHit==false){
			return;
		}
		RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
		SharpDX.Direct2D1.AntialiasMode OSM = RenderTarget.AntialiasMode;
		RenderTarget.AntialiasMode          = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
		SoundsAreActive = true;
		int RMaB = Math.Min(Bars.Count-1, ChartBars.ToIndex);
		int LMaB = Math.Max(5, ChartBars.FromIndex);
		DateTime t0=DateTime.MinValue;
		DateTime t7=DateTime.MinValue;
		int abar = 0;
		double v = 0;
		int barcount = 0;
		int y0 = chartScale.GetYByValue( 0);
		int y1, rbar, x0, x1, offset;
		float yZeroLine=0f;
		float x0f = 0;
		float y0f = 0;
		double ev = 0;

		float[] ysPriorBar = new float[Plots.Length];
		float[] xsPriorBar = new float[Plots.Length];
		for(int i = 0; i<Plots.Length; i++) {
			ysPriorBar[i]=float.MinValue;
			xsPriorBar[i]=float.MinValue;
		}
//		if(LabelDotBrushDX_dict.Count != enumAnalysisTypes.Count){
//			foreach(var type in enumAnalysisTypes){
//				LabelDotBrushDX_dict[type] = Brushes.White.ToDxBrush(RenderTarget);
//			}
//		}

		#endregion

		#region -- Excursion levels --
		if(this.pExcursionLevelsIsStatic){
			ev = ExcursionSeries.GetValueAt(RMaB-1);
			float w = Convert.ToSingle(ChartPanel.W);
			if(pDisplayExcursion1){
				float y = chartScale.GetYByValue(ev);
				RenderTarget.DrawLine(new SharpDX.Vector2(0, y), new SharpDX.Vector2(w, y), ExcursionLevel1_BrushDX, pWidthExcursionLines);
				y = chartScale.GetYByValue(-ev);
				RenderTarget.DrawLine(new SharpDX.Vector2(0, y), new SharpDX.Vector2(w, y), ExcursionLevel1_BrushDX, pWidthExcursionLines);
			}
			if(pDisplayExcursion2){
				float y = chartScale.GetYByValue(ev*2);
				RenderTarget.DrawLine(new SharpDX.Vector2(0, y), new SharpDX.Vector2(w, y), ExcursionLevel2_BrushDX, pWidthExcursionLines);
				y = chartScale.GetYByValue(-ev*2);
				RenderTarget.DrawLine(new SharpDX.Vector2(0, y), new SharpDX.Vector2(w, y), ExcursionLevel2_BrushDX, pWidthExcursionLines);
			}
			if(pDisplayExcursion3){
				float y = chartScale.GetYByValue(ev*3);
				RenderTarget.DrawLine(new SharpDX.Vector2(0, y), new SharpDX.Vector2(w, y), ExcursionLevel3_BrushDX, pWidthExcursionLines);
				y = chartScale.GetYByValue(-ev*3);
				RenderTarget.DrawLine(new SharpDX.Vector2(0, y), new SharpDX.Vector2(w, y), ExcursionLevel3_BrushDX, pWidthExcursionLines);
			}
		}else if(pDisplayExcursion1 || pDisplayExcursion2 || pDisplayExcursion3){
			x1 = chartControl.GetXByBarIndex(ChartBars, 1);
			float Ly, Ry;
			for(abar = Math.Max(2,ChartBars.FromIndex); abar < RMaB; abar++){
				double Lev = ExcursionSeries.GetValueAt(abar-1);
				double Rev = ExcursionSeries.GetValueAt(abar);
				x0 = chartControl.GetXByBarIndex(ChartBars, abar);
				if(pDisplayExcursion1){
					Ly = chartScale.GetYByValue(Lev);
					Ry = chartScale.GetYByValue(Rev);
					RenderTarget.DrawLine(new SharpDX.Vector2(x1, Ly), new SharpDX.Vector2(x0, Ry), ExcursionLevel1_BrushDX, pWidthExcursionLines);
					Ly = chartScale.GetYByValue(-Lev);
					Ry = chartScale.GetYByValue(-Rev);
					RenderTarget.DrawLine(new SharpDX.Vector2(x1, Ly), new SharpDX.Vector2(x0, Ry), ExcursionLevel1_BrushDX, pWidthExcursionLines);
				}
				if(pDisplayExcursion2){
					Ly = chartScale.GetYByValue(Lev*2);
					Ry = chartScale.GetYByValue(Rev*2);
					RenderTarget.DrawLine(new SharpDX.Vector2(x1, Ly), new SharpDX.Vector2(x0, Ry), ExcursionLevel2_BrushDX, pWidthExcursionLines);
					Ly = chartScale.GetYByValue(-Lev*2);
					Ry = chartScale.GetYByValue(-Rev*2);
					RenderTarget.DrawLine(new SharpDX.Vector2(x1, Ly), new SharpDX.Vector2(x0, Ry), ExcursionLevel2_BrushDX, pWidthExcursionLines);
				}
				if(pDisplayExcursion3){
					Ly = chartScale.GetYByValue(Lev*3);
					Ry = chartScale.GetYByValue(Rev*3);
					RenderTarget.DrawLine(new SharpDX.Vector2(x1, Ly), new SharpDX.Vector2(x0, Ry), ExcursionLevel3_BrushDX, pWidthExcursionLines);
					Ly = chartScale.GetYByValue(-Lev*3);
					Ry = chartScale.GetYByValue(-Rev*3);
					RenderTarget.DrawLine(new SharpDX.Vector2(x1, Ly), new SharpDX.Vector2(x0, Ry), ExcursionLevel3_BrushDX, pWidthExcursionLines);
				}
				x1 = x0;
			}
		}
		#endregion

		#region -- Set plots and draw plots for oscillator and min/max line custom rendering --
		{
			var barslotwidth = chartControl.Properties.BarDistance;//x0f-x1f;
			var half_barslotwidth = barslotwidth/2f;
			{
				int PLOTA_ID = 0;
				int PLOTB_ID = 1;
				int PLOTC_ID = 2;
				var PlotReferenceTable = new SortedDictionary<int, int>();
						//Key is the Plot id (based on the creation order of the plots in OnStateChange)...
						//Values are which DataSeries plot is connected to that Plot.  0 is PlotA, 1 is PlotB, 2 is PlotC
				if(pAnalysisType == ARC_CycleForecaster_AnalysisType.VMDivergence){
					PlotReferenceTable[ACTIVEUP_HISTO_PLOT_ID]   = PLOTA_ID;
					PlotReferenceTable[ACTIVEDOWN_HISTO_PLOT_ID] = PLOTA_ID;//both VMDivergences plots are drawn from PlotA
				}
				else if(pAnalysisType == ARC_CycleForecaster_AnalysisType.CCI){
					PlotReferenceTable[CCILINE_PLOT_ID] = PLOTA_ID;
				}
				else if(pAnalysisType == ARC_CycleForecaster_AnalysisType.RSI){
					PlotReferenceTable[RSILINE_PLOT_ID] = PLOTA_ID;
					if(pViewState == ARC_CycleForecaster_ViewStates.Trading)
						PlotReferenceTable[RSIAVGLINE_PLOT_ID] = PLOTB_ID;
				}
				else if(pAnalysisType == ARC_CycleForecaster_AnalysisType.Fisher){
					PlotReferenceTable[FISHERLINE_PLOT_ID] = PLOTA_ID;
				}
#if RSS_AND_RVI
				else if(pAnalysisType == ARC_CycleForecaster_AnalysisType.RSS){
					PlotReferenceTable[RSSLINE_PLOT_ID] = PLOTA_ID;
				}
				else if(pAnalysisType == ARC_CycleForecaster_AnalysisType.RVI){
					PlotReferenceTable[RVILINE_PLOT_ID] = PLOTA_ID;
				}
#endif
				else if(pAnalysisType == ARC_CycleForecaster_AnalysisType.MACD){
					PlotReferenceTable[MACDLINE_PLOT_ID]       = PLOTA_ID;
					if(pViewState == ARC_CycleForecaster_ViewStates.Trading){
						PlotReferenceTable[MACDSIGNALLINE_PLOT_ID] = PLOTB_ID;
						PlotReferenceTable[MACDDIFFHISTO_PLOT_ID]  = PLOTC_ID;
					}
				}
				else if(pAnalysisType == ARC_CycleForecaster_AnalysisType.MACDHisto){
					if(pViewState == ARC_CycleForecaster_ViewStates.Trading){
						PlotReferenceTable[MACDLINE_PLOT_ID]       = PLOTA_ID;
						PlotReferenceTable[MACDSIGNALLINE_PLOT_ID] = PLOTB_ID;
					}
						PlotReferenceTable[MACDDIFFHISTO_PLOT_ID]  = PLOTC_ID;
				}
				else if(pAnalysisType == ARC_CycleForecaster_AnalysisType.Stoch){
					PlotReferenceTable[STOCHDLINE_PLOT_ID] = PLOTA_ID;
					if(pViewState == ARC_CycleForecaster_ViewStates.Trading)
						PlotReferenceTable[STOCHKLINE_PLOT_ID] = PLOTB_ID;
				}
line=3428;
				#region -- Draw zero line --
				yZeroLine = chartScale.GetYByValue(Lines[0].Value);
				float lineY = yZeroLine;
				RenderTarget.DrawLine(new SharpDX.Vector2(0,lineY), new SharpDX.Vector2(Convert.ToSingle(ChartPanel.W), lineY), Lines[0].BrushDX, Convert.ToSingle(Lines[0].Width));
				#endregion
line=3434;

				#region -- Draw Min/Max line, Fill-in momentum background, Draw oscillators based on ViewState --
				float minmaxlineY = 0;
				var plotkeys = PlotReferenceTable.ToList();
				plotkeys.Reverse();//the higher number plot is laid down first, so it's in the background behind the other plots
				float x1f = float.MinValue;
				float y1f = float.MinValue;
				x0f = 0;
				y0f = 0;
				CurrentASet.FutureHistoMax = 0;
				CurrentASet.FutureHistoMin = 0;
				if(pViewState == ARC_CycleForecaster_ViewStates.Data){//draw the Min/Max lines on just the 1st pass of the visible bars
line=3447;
					for(abar = LMaB; abar<=RMaB; abar++){
						#region -- Draw the min/max lines --
						x0f = chartControl.GetXByBarIndex(ChartBars, abar);
						t0  = BarsArray[0].GetTime(abar);
						t7  = t0.AddDays(-7);
						if(CurrentASet.GaplessHisto.ContainsKey(t7) && CurrentASet.GaplessHisto[t7].PrintTime == t0){
							CurrentASet.FutureHistoMax = Math.Max(CurrentASet.FutureHistoMax, CurrentASet.GaplessHisto[t7].MinHigh);
//if(FutureHistoMax>8) Print(Times[0].GetValueAt(abar).ToString()+"   t7: "+t7.ToString());
							CurrentASet.FutureHistoMin = Math.Min(CurrentASet.FutureHistoMin, CurrentASet.GaplessHisto[t7].MaxLow);
							minmaxlineY = chartScale.GetYByValue(CurrentASet.GaplessHisto[t7].MinHigh);
							int p = THLEVEL_PLOT_ID;
							#region -- Draw line --
							if(Plots[p].PlotStyle==PlotStyle.Hash){
								try{
									if(chartControl.Properties.BarDistance<=3){
										var v0 = new SharpDX.Vector2(x0f,minmaxlineY);
										var v1 = new SharpDX.Vector2(x0f+1f, minmaxlineY);
										RenderTarget.DrawLine(v0,v1, Plots[p].BrushDX, (float)Plots[p].Pen.Thickness);
									}
									else {
										int dashsize = (int)((chartControl.Properties.BarDistance/2)*0.8);
										var v0 = new SharpDX.Vector2(x0f-chartControl.Properties.BarDistance/2+1,minmaxlineY);
										var v1 = new SharpDX.Vector2(x0f+dashsize,minmaxlineY);
										RenderTarget.DrawLine(v0,v1, Plots[p].BrushDX, (float)Plots[p].Pen.Thickness);
									}
								}catch{}
							}
							else if(Plots[p].PlotStyle==PlotStyle.Line) {
								try{
									var v0 = new SharpDX.Vector2(x1f, minmaxlineY);
									var v1 = new SharpDX.Vector2(xsPriorBar[p], ysPriorBar[p]);
									RenderTarget.DrawLine(v0,v1, Plots[p].BrushDX, (float)Plots[p].Pen.Thickness);
								}catch{}
								ysPriorBar[p] = minmaxlineY;
								xsPriorBar[p] = x0f;
							}
							else {// all other plot styles get represented as a Dot (I don't want to support Triangles, Blocks, Crosses, etc
								offset = (int)(chartControl.Properties.BarDistance/2);
								if(offset<1) offset = 1;
								RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x0f,minmaxlineY),chartControl.Properties.BarDistance,chartControl.Properties.BarDistance), Plots[p].BrushDX);
							}
							#endregion
							minmaxlineY = chartScale.GetYByValue(CurrentASet.GaplessHisto[t7].MaxLow);
							p = BHLEVEL_PLOT_ID;
							#region -- Draw line --
							if(Plots[p].PlotStyle==PlotStyle.Hash){
								try{
									if(chartControl.Properties.BarDistance<=3){
										var v0 = new SharpDX.Vector2(x0f,minmaxlineY);
										var v1 = new SharpDX.Vector2(x0f+1f, minmaxlineY);
										RenderTarget.DrawLine(v0,v1, Plots[p].BrushDX, (float)Plots[p].Pen.Thickness);
									}
									else {
										int dashsize = (int)((chartControl.Properties.BarDistance/2)*0.8);
										var v0 = new SharpDX.Vector2(x0f-chartControl.Properties.BarDistance/2+1,minmaxlineY);
										var v1 = new SharpDX.Vector2(x0f+dashsize,minmaxlineY);
										RenderTarget.DrawLine(v0,v1, Plots[p].BrushDX, (float)Plots[p].Pen.Thickness);
									}
								}catch{}
							}
							else if(Plots[p].PlotStyle==PlotStyle.Line) {
								try{
									var v0 = new SharpDX.Vector2(x0f, minmaxlineY);
									var v1 = new SharpDX.Vector2(xsPriorBar[p], ysPriorBar[p]);
									RenderTarget.DrawLine(v0,v1, Plots[p].BrushDX, (float)Plots[p].Pen.Thickness);
								}catch{}
								ysPriorBar[p] = minmaxlineY;
								xsPriorBar[p] = x0f;
							}
							else {// all other plot styles get represented as a Dot (I don't want to support Triangles, Blocks, Crosses, etc
								offset = (int)(chartControl.Properties.BarDistance/2);
								if(offset<1) offset = 1;
								RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x0f,minmaxlineY),chartControl.Properties.BarDistance,chartControl.Properties.BarDistance), Plots[p].BrushDX);
							}
							#endregion
						}
						#endregion
					}
				}
				x0f = 0;
				float momentumX1 = 0;
				int momentumDir = 0;
				double histo = 0;
				if(pEnableMomentumBkg && RecalculateButtonHit){
line=3532;
					#region -- paint background momentum --
					for(abar = LMaB; abar<=RMaB; abar++){
						x0f = chartControl.GetXByBarIndex(ChartBars, abar);
						if(pViewState == ARC_CycleForecaster_ViewStates.Trading)
							histo = PlotA.GetValueAt(abar);
						else
							histo = CurrentASet.ShiftedHisto.GetValueAt(abar);

						if(histo < Lines[0].Value && momentumDir >= 0){  //down momentum if the oscillator Y is greater than the zero lineY
							RenderTarget.FillRectangle(new SharpDX.RectangleF(momentumX1, lineY, x0f-momentumX1-half_barslotwidth, -Convert.ToSingle(ChartPanel.H)), UpMomentumBkg_BrushDX);
							momentumX1 = x0f-half_barslotwidth;
							momentumDir = -1;
						}else if(histo > Lines[0].Value && momentumDir <= 0){  //up momentum if the oscillator Y is less than the zero lineY
							RenderTarget.FillRectangle(new SharpDX.RectangleF(momentumX1, lineY, x0f-momentumX1-half_barslotwidth, Convert.ToSingle(ChartPanel.H)), DownMomentumBkg_BrushDX);
							momentumX1 = x0f-half_barslotwidth;
							momentumDir = 1;
						}
						if(abar == RMaB){
							if(momentumDir >= 0){  //last zone is up momentum
								RenderTarget.FillRectangle(new SharpDX.RectangleF(momentumX1, lineY, x0f-momentumX1-half_barslotwidth, -Convert.ToSingle(ChartPanel.H)), UpMomentumBkg_BrushDX);
								momentumX1 = x0f-half_barslotwidth;
							}else if(momentumDir <= 0){  //last zone is down momentum
								RenderTarget.FillRectangle(new SharpDX.RectangleF(momentumX1, lineY, x0f-momentumX1-half_barslotwidth, Convert.ToSingle(ChartPanel.H)), DownMomentumBkg_BrushDX);
								momentumX1 = x0f-half_barslotwidth;
							}
						}
					}
					#endregion
				}
				foreach(var plots in plotkeys){
					abar = 0;
					x1f = float.MinValue;
					y1f = float.MinValue;
					x0f = 0;
					y0f = 0;

					for(abar = LMaB; abar<=RMaB; abar++){
line=3570;
						if(!PlotA.IsValidDataPointAt(abar)) continue;

						if(pViewState == ARC_CycleForecaster_ViewStates.Trading)
							histo = plots.Value == PLOTA_ID ? PlotA.GetValueAt(abar) : (plots.Value==PLOTB_ID ? PlotB.GetValueAt(abar) : PlotC.GetValueAt(abar));
						else{
							histo = CurrentASet.ShiftedHisto.GetValueAt(abar);
							if(pAnalysisType == ARC_CycleForecaster_AnalysisType.VMDivergence){
								if(     histo > Lines[0].Value && plots.Key == ACTIVEDOWN_HISTO_PLOT_ID) {continue;}
								else if(histo < Lines[0].Value && plots.Key == ACTIVEUP_HISTO_PLOT_ID)   {continue;}
							}
						}
						if(y1f == float.MinValue){//initialize the "prior value" element of the array
							y1f = chartScale.GetYByValue( histo);
						}else{
							x1f = x0f;
							y1f = y0f;
						}
line=3588;
						//calculate a new current value
						x0f = chartControl.GetXByBarIndex(ChartBars, abar);
						y0f = chartScale.GetYByValue( histo);

						if(Plots[plots.Key].PlotStyle == PlotStyle.Line){
							RenderTarget.DrawLine(new SharpDX.Vector2(x1f, y1f), new SharpDX.Vector2(x0f, y0f), Plots[plots.Key].BrushDX, Convert.ToSingle(Plots[plots.Key].Pen.Thickness));
						}else if(Plots[plots.Key].PlotStyle == PlotStyle.Bar){
							RenderTarget.FillRectangle(new SharpDX.RectangleF(x0f, lineY, Plots[plots.Key].Width/*x0f-x1f*/, y0f-lineY), Plots[plots.Key].BrushDX);
						}
					}
				}
				#endregion
			}
		}
		#endregion

		#region -- Draw BB band --
		if(pAnalysisType == ARC_CycleForecaster_AnalysisType.VMDivergence && this.ChannelOpacity>0 && ChannelColor!=Brushes.Transparent && RecalculateButtonHit){
			float dotwidth = Plots[BBdot_PLOT_ID].Width;
			for (int i = RMaB; i >= LMaB; i--)
			{
				drawRegion(
					new double[] { BBUpper.GetValueAt(i), BBUpper.GetValueAt(i-1), BBLower.GetValueAt(i-1), BBLower.GetValueAt(i) }, 
					new int[] { i, i-1, i-1, i }, 
					ChannelBkgBrushDX, chartControl, chartScale);

				x1 = chartControl.GetXByBarIndex(ChartBars, i);
				y1 = chartScale.GetYByValue(BBline.GetValueAt(i));
				if(xsPriorBar[BBline_PLOT_ID] != float.MinValue){
					RenderTarget.DrawLine(new SharpDX.Vector2(xsPriorBar[BBline_PLOT_ID], ysPriorBar[BBline_PLOT_ID]), new SharpDX.Vector2(x1,  y1), Plots[BBline_PLOT_ID].BrushDX, Plots[BBline_PLOT_ID].Width);
				}
				xsPriorBar[BBline_PLOT_ID] = x1;
				ysPriorBar[BBline_PLOT_ID] = y1;
			}
			var yU = 0f;
			var yL = 0f;
			for (int i = RMaB-1; i >= LMaB; i--)
			{
				x1 = chartControl.GetXByBarIndex(ChartBars, i);
				yU = chartScale.GetYByValue(BBUpper.GetValueAt(i));
				if(xsPriorBar[BBUpper_PLOT_ID] != float.MinValue)
					RenderTarget.DrawLine(new SharpDX.Vector2(xsPriorBar[BBUpper_PLOT_ID], ysPriorBar[BBUpper_PLOT_ID]), new SharpDX.Vector2(x1, yU), Plots[BBUpper_PLOT_ID].BrushDX, Plots[BBUpper_PLOT_ID].Width);

				xsPriorBar[BBUpper_PLOT_ID] = x1;
				ysPriorBar[BBUpper_PLOT_ID] = yU;

				yL = chartScale.GetYByValue(BBLower.GetValueAt(i));
				if(xsPriorBar[BBLower_PLOT_ID] != float.MinValue)
					RenderTarget.DrawLine(new SharpDX.Vector2(xsPriorBar[BBLower_PLOT_ID], ysPriorBar[BBLower_PLOT_ID]), new SharpDX.Vector2(x1, yL), Plots[BBLower_PLOT_ID].BrushDX, Plots[BBLower_PLOT_ID].Width);

				xsPriorBar[BBLower_PLOT_ID] = x1;
				ysPriorBar[BBLower_PLOT_ID] = yL;
			}
			for (int i = RMaB; i >= LMaB; i--)
			{
				x1 = chartControl.GetXByBarIndex(ChartBars, i);
				if(!BBdot.IsValidDataPointAt(i)) continue;
				y1 = chartScale.GetYByValue(BBdot.GetValueAt(i));
				if(PlotBrushes[BBdot_PLOT_ID].GetDxBrush(i)!=null)
					RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x1, y1), dotwidth, dotwidth), PlotBrushes[BBdot_PLOT_ID].GetDxBrush(i));
			}
		}
		#endregion

		#region -- Draw text labels and future histo plot --
		SharpDX.DirectWrite.TextFormat labelFormat = chartControl.Properties.LabelFont.ToDirectWriteTextFormat();
		SharpDX.DirectWrite.TextLayout labelLayout=null;
			
line=3657;
		int texty,textx = 0;
		int height=0;
		for(int i = 0; i<Plots.Length; i++) {
			ysPriorBar[i]=float.MinValue;
			xsPriorBar[i]=float.MinValue;
		}

		double maxplot = 0;
		double minplot = 0;
		string timestr;
		SharpDX.Size2F size;

		double mins = Bars.BarsPeriod.Value;
		if(Bars.BarsPeriod.BarsPeriodType == BarsPeriodType.Second) mins = mins/60.0;
		if(Bars.BarsPeriod.BarsPeriodType!=BarsPeriodType.Minute){
			int ptr = Math.Min(CurrentBar,200);
			TimeSpan ts = new TimeSpan(Times[0].GetValueAt(CurrentBars[0]-ptr).Ticks-Times[0].GetValueAt(CurrentBars[0]).Ticks);
			mins = ts.TotalMinutes/(double)ptr;
		}
		int BarsInMarginSpace = ChartBars.ToIndex-RMaB;

		foreach(var kvp in AnalysisSets){
			if(!pIsMultiSignal && kvp.Key!=pAnalysisType) continue;
			var CurrentASet = kvp.Value;
			if(RMaB < Bars.Count-1)
				CurrentASet.FutureHistoKeys.Clear();
			else {
				if(IsFirstTickOfBar) CurrentASet.FutureHistoKeys = CurrentASet.GaplessHisto.Where(n=> n.Value.PrintTime >= BarsArray[0].GetTime(BarsArray[0].Count-1)).Select(n=>n.Key).ToList();
			}
			int XofLastTimestamp = -99999; //we don't want two or more timestamps on the same bar...this will check for such situations

			ev = 0;
			if(pViewState == ARC_CycleForecaster_ViewStates.Trading) ev = ExcursionSeries.GetValueAt(RMaB-1)*2;

			if(pShowPeakTimes){
				float xRMB = ChartPanel.W-chartControl.GetXByBarIndex(ChartBars,Bars.Count-1);
				#region -- ShowPeakTimes on historical bars --
				var FirstBarDT = Bars.GetTime(LMaB);
				var LastBarDT = Bars.GetTime(RMaB);
				if(BarsInMarginSpace>0){
					LastBarDT = LastBarDT.AddMinutes(BarsInMarginSpace * MinutesPerBar);
				}
				if(xRMB>0.3*chartControl.Properties.BarDistance) {
					LastBarDT = LastBarDT.AddYears(1);//includes all timestamps on the histos in the future
//					Print("2100 chart was panned to the left");
				}
				if(IsFirstTickOfBar) {
					CurrentASet.HistoDataList = CurrentASet.GaplessHisto.Where(k=> k.Value.PrintTime >= FirstBarDT && k.Value.PrintTime <= LastBarDT && k.Value.IsSignalBar!=' ').Select(k=>k.Value).ToList();
				}

				int adj = 0;//adjustment on dotlabel and label for multisignals...to prevent overlapping
				if(this.pIsMultiSignal) adj = (int)kvp.Key*3;
				if(CurrentASet.HistoDataList!=null && CurrentASet.HistoDataList.Count>0){
					foreach(var dt in CurrentASet.HistoDataList) {
//try{
						bool IsFutureTimeLabel = dt.PrintTime>Bars.GetTime(Bars.Count-1);
line=3712;
						if(!IsFutureTimeLabel) {
							int barnumber = BarsArray[0].GetBar(dt.PrintTime); //we check the Day of the bar against the dt.Day...we only print a label if its properly printing on the chart on the day it's supposed to
							if(Bars.GetTime(barnumber).Day != dt.PrintTime.Day) continue;
						}

						timestr = string.Format("{0}:{1}",dt.PrintTime.Hour,dt.PrintTime.Minute.ToString("00"));
						labelLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, timestr, labelFormat, ChartPanel.W, (float)chartControl.Properties.LabelFont.Size);

						double histo = dt.Val;
//						texty = pViewState==ARC_CycleForecaster_ViewStates.Data ? texty : (histo > 0 ? chartScale.GetYByValue(ev)-pTimeLabelSeparation : chartScale.GetYByValue(-ev)+pTimeLabelSeparation);
						if(histo>0) {
							texty = GetTimeLabelY(histo, chartScale, kvp.Key, ev) + adj;//moves the labeldots out just a few pixels, to offset any duplicate prints
							y0f = texty;
							texty = texty-4-(int)labelLayout.Metrics.Height; 
						}else{
							texty = GetTimeLabelY(histo, chartScale, kvp.Key, ev) - adj;//moves the labeldots out just a few pixels, to offset any duplicate prints
							y0f = texty;
							texty = texty+4;
						}
						x0 = chartControl.GetXByBarIndex(ChartBars, Bars.GetBar(dt.PrintTime));
						if(!IsFutureTimeLabel){
							textx = x0 - (int)(labelLayout.Metrics.Width/2);
							if(textx!=XofLastTimestamp) {
								if(LabelDotBrushDX_dict.ContainsKey(kvp.Key) && LabelDotBrushDX_dict[kvp.Key]!=null) RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x0, y0f), Plots[texty > yZeroLine ? 0:1].Width, Plots[texty > yZeroLine ? 0:1].Width), LabelDotBrushDX_dict[kvp.Key]);
								if(pShowHistoricalTimeLabels && !IsFutureTimeLabel){
									if(pIsMultiSignal && kvp.Key != pAnalysisType && ChartBackgroundBrushDX!=null)//fill background of time labels when those labels are from other analysis types
										RenderTarget.FillRectangle(new SharpDX.RectangleF(textx-2, texty, labelLayout.Metrics.Width+4, labelLayout.Metrics.Height), ChartBackgroundBrushDX);
									RenderTarget.DrawTextLayout(new SharpDX.Vector2(textx, texty), labelLayout, PeakTimesBrushDX);//, DrawTextOptions.NoSnap);
								}
							}
						}
line=3744;
						XofLastTimestamp = textx;
						if(labelLayout!=null && !labelLayout.IsDisposed){
							labelLayout.Dispose();
							labelLayout = null;
						}
//}catch(Exception err){Print("Line "+line+": Error: "+err.ToString());}
				  }
				}
				#endregion
			}


			if(CurrentASet.FutureHistoKeys!=null) {
				List<double> LastHistoHeight = new List<double>();
				barcount = -1;
				foreach (DateTime dt in CurrentASet.FutureHistoKeys) {
					t0 = CurrentASet.GaplessHisto[dt].PrintTime;
					if(t0 < Times[0].GetValueAt(CurrentBars[0])) {continue;}
					if(pEliminateOvernightGap && t0 < StartOfNextSession) {continue;}
					barcount++;
					abar = Bars.Count-1 + barcount;
					x0   = chartControl.GetXByBarIndex(ChartBars, abar);
					if(x0 > ChartPanel.W) break;
					if(pViewState == ARC_CycleForecaster_ViewStates.Trading) 
						v = (CurrentASet.GaplessHisto[dt].Val > 0 ? ev : -ev);
					else
						v = CurrentASet.GaplessHisto[dt].Val;
					if(double.IsNaN(v)) continue;
					CurrentASet.FutureHistoMax = Math.Max(CurrentASet.FutureHistoMax, CurrentASet.GaplessHisto[dt].Val);
					CurrentASet.FutureHistoMin = Math.Min(CurrentASet.FutureHistoMin, CurrentASet.GaplessHisto[dt].Val);
					if(!pIsMultiSignal || kvp.Key == pAnalysisType){
						#region -- custom plot future oscillator if the ViewState is Data --
						if(pViewState == ARC_CycleForecaster_ViewStates.Data){
							for(int p = ACTIVEUP_HISTO_PLOT_ID; p<Plots.Length; p++) {
								if(PlotIDsToHide.Contains(p)) continue;
								double h = v;
//if(!pShowInversionHisto && p==INVERSION_HISTO_PLOT_ID) continue;
								if(p==THLEVEL_PLOT_ID){
									h = CurrentASet.GaplessHisto[dt].MinHigh;
									if(h==double.MinValue) {
										continue;
									}
								}
								else if(p==BHLEVEL_PLOT_ID){
									h = CurrentASet.GaplessHisto[dt].MaxLow;
									if(h==double.MinValue) {
										continue;
									}
								}else {
line=3794;
									if(p==ACTIVEUP_HISTO_PLOT_ID && h<0) continue;
									if(p==ACTIVEDOWN_HISTO_PLOT_ID && h>0) continue;
									if(h>maxplot)maxplot = h;
									else if(h<minplot)minplot = h;
								}

								y1 = chartScale.GetYByValue(h);
								height = Math.Abs(y1-y0);

								if(Plots[p].Pen.Brush != Brushes.Transparent) {
									int p0 = p;
//									if(Plots[p].PlotStyle==PlotStyle.Bar) {
//										RenderTarget.FillRectangle(new SharpDX.RectangleF(x0-(int)(pPredictionOscillatorLineWidth/2f), Math.Min(y0,y1), pPredictionOscillatorLineWidth, height), PredictionOscillatorBrushDX);
//									}
//									else if(Plots[p].PlotStyle==PlotStyle.Hash){
//										try{
//											if(chartControl.Properties.BarDistance<=3){
//												var v0 = new SharpDX.Vector2(x0,y1);
//												var v1 = new SharpDX.Vector2(x0+1f,y1);
//												RenderTarget.DrawLine(v0,v1, PredictionOscillatorBrushDX, pPredictionOscillatorLineWidth);
//											}
//											else {
//												int dashsize = (int)((chartControl.Properties.BarDistance/2)*0.8);
//												var v0 = new SharpDX.Vector2(x0-chartControl.Properties.BarDistance/2+1,y1);
//												var v1 = new SharpDX.Vector2(x0+dashsize,y1);
//												RenderTarget.DrawLine(v0,v1, PredictionOscillatorBrushDX, pPredictionOscillatorLineWidth);
//											}
//										}catch{}
//									}
//									else if(Plots[p].PlotStyle==PlotStyle.Line) 
									if(p0 == THLEVEL_PLOT_ID || p0 == BHLEVEL_PLOT_ID)
									{
line=3827;
										if(Plots[p0].PlotStyle == PlotStyle.Hash){
											if(chartControl.Properties.BarDistance<=3){
												var v0 = new SharpDX.Vector2(x0,y1);
												var v1 = new SharpDX.Vector2(x0+1f,y1);
												RenderTarget.DrawLine(v0,v1, PlotBrushDXes50pct[p0], Convert.ToSingle(Plots[p0].Pen.Thickness));
											} else {
												int dashsize = (int)((chartControl.Properties.BarDistance/2)*0.8);
												var v0 = new SharpDX.Vector2(x0-chartControl.Properties.BarDistance/2+1,y1);
												var v1 = new SharpDX.Vector2(x0+dashsize,y1);
												RenderTarget.DrawLine(v0,v1, PlotBrushDXes50pct[p0], Convert.ToSingle(Plots[p0].Pen.Thickness));
											}
										}else{
											var v0 = new SharpDX.Vector2(x0,y1);
											var v1 = new SharpDX.Vector2(xsPriorBar[p0], ysPriorBar[p0]);
											RenderTarget.DrawLine(v0,v1, PlotBrushDXes50pct[p0], Convert.ToSingle(Plots[p0].Pen.Thickness));
										}
										ysPriorBar[p0] = y1;
										xsPriorBar[p0] = x0;
									}else{
										if(p==ACTIVEDOWN_HISTO_PLOT_ID)   p0=ACTIVEUP_HISTO_PLOT_ID;
										var v0 = new SharpDX.Vector2(x0,y1);
										var v1 = new SharpDX.Vector2(xsPriorBar[p0], ysPriorBar[p0]);
										RenderTarget.DrawLine(v0,v1, PredictionOscillatorBrushDX, pPredictionOscillatorLineWidth);
										ysPriorBar[p0] = y1;
										xsPriorBar[p0] = x0;
									}
//									else {// all other plot styles get represented as a Dot (I don't want to support Triangles, Blocks, Crosses, etc
line=3855;
//										offset = (int)(chartControl.Properties.BarDistance/2);
//										if(offset<1) offset = 1;
//										RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(new SharpDX.Vector2(x0,y1),chartControl.Properties.BarDistance/2f,chartControl.Properties.BarDistance/2f), PredictionOscillatorBrushDX);
//									}
								}
							}
						}
						#endregion
					}
					if(pShowPeakTimes && CurrentASet.GaplessHisto[dt].IsSignalBar != ' '){
						#region -- Print the PeakTime label --
						timestr = string.Format("{0}:{1}",t0.Hour,t0.Minute.ToString("00"));
						labelLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, timestr, labelFormat, ChartPanel.W, Convert.ToSingle(chartControl.Properties.LabelFont.Size));

						texty = GetTimeLabelY(v, chartScale, kvp.Key, ev);
						if(v>0) texty = texty-4-(int)labelLayout.Metrics.Height-pTimeLabelSeparation; else texty = texty+4+pTimeLabelSeparation;

						x0 = chartControl.GetXByBarIndex(ChartBars, abar);
						textx = x0 - (int)(labelLayout.Metrics.Width/2);
line=3875;
						if(textx!=XofLastTimestamp) {
//							Print("Printing "+timestr+" at "+dt.PrintTime.ToString());    
//							RenderTarget.FillRectangle(new SharpDX.RectangleF(x0, yZeroLine, 3f, texty-yZeroLine + (texty > yZeroLine ? 0 : Convert.ToSingle(chartControl.Properties.LabelFont.Size)+4f)), texty > yZeroLine ? Plots[0].BrushDX : Plots[1].BrushDX);
							if(LabelDotBrushDX_dict.ContainsKey(kvp.Key) && LabelDotBrushDX_dict[kvp.Key]!=null) RenderTarget.FillRectangle(new SharpDX.RectangleF(x0, yZeroLine, 3f, texty-yZeroLine + (texty > yZeroLine ? 0 : Convert.ToSingle(chartControl.Properties.LabelFont.Size)+4f)), LabelDotBrushDX_dict[kvp.Key]);
							if(pIsMultiSignal && kvp.Key != pAnalysisType && ChartBackgroundBrushDX!=null)//fill background of time labels when those labels are from other analysis types
								RenderTarget.FillRectangle(new SharpDX.RectangleF(textx-2, texty, labelLayout.Metrics.Width+4, labelLayout.Metrics.Height), ChartBackgroundBrushDX);
							RenderTarget.DrawTextLayout(new SharpDX.Vector2(textx,texty), labelLayout, PeakTimesBrushDX);//, DrawTextOptions.NoSnap);
						}
line=3884;
						XofLastTimestamp = textx;
						if(labelLayout!=null && !labelLayout.IsDisposed){
							labelLayout.Dispose();
							labelLayout = null;
						}
						#endregion
					}
				}
			}
		}
		#endregion
		if(labelFormat!=null && !labelFormat.IsDisposed){
			labelFormat.Dispose();
			labelFormat = null;
		}
line=3900;
//}catch(Exception err){Print("Line "+line+": Error: "+err.ToString());}
		RenderTarget.AntialiasMode = OSM;
	}
//==========================================================================================================================================
	#region -- drawRegion --
		private void drawRegion(Point[] points, SharpDX.Direct2D1.Brush dxbrush)
		{
			SharpDX.Vector2[] vectors = new[] { points[1].ToVector2(), points[2].ToVector2(), points[3].ToVector2() };

			SharpDX.Direct2D1.PathGeometry geo1 = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
			SharpDX.Direct2D1.GeometrySink sink1 = geo1.Open();
			sink1.BeginFigure(points[0].ToVector2(), SharpDX.Direct2D1.FigureBegin.Filled);
			sink1.AddLines(vectors);
			sink1.EndFigure(SharpDX.Direct2D1.FigureEnd.Closed);
			sink1.Close();

			RenderTarget.FillGeometry(geo1, dxbrush);
			geo1.Dispose();
			sink1.Dispose();
		}
		private void drawRegion(double[] yValues, int[] xIndex, SharpDX.Direct2D1.Brush dxbrush, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = false, bool atMiddle = false)
		{
			drawRegion(new Point[]{
				new Point(GetX0(xIndex[0], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[0])),
				new Point(GetX0(xIndex[1], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[1])),
				new Point(GetX0(xIndex[2], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[2])),
				new Point(GetX0(xIndex[3], chartControl, atMiddle), drawOnPricePanel?0:chartScale.GetYByValue(yValues[3]))
				},
				dxbrush
			);
		}

		private void drawRacingStripe(double[] yValues, int[] xIndex, SharpDX.Direct2D1.Brush dxbrush, ChartControl chartControl, ChartScale chartScale, bool drawOnPricePanel = false, bool atMiddle = false)
		{
			if(dxbrush==null) return;
			var half = (int)(chartControl.Properties.BarDistance / 2);
			drawRegion(new Point[]{
				new Point(GetX0(xIndex[0],   chartControl, atMiddle)-half, drawOnPricePanel?0:chartScale.GetYByValue(yValues[0])),
				new Point(GetX0(xIndex[1],   chartControl, atMiddle)-half, drawOnPricePanel?0:chartScale.GetYByValue(yValues[1])),
				new Point(GetX0(xIndex[2]+1, chartControl, atMiddle)-half-1, drawOnPricePanel?0:chartScale.GetYByValue(yValues[2])),
				new Point(GetX0(xIndex[3]+1, chartControl, atMiddle)-half-1, drawOnPricePanel?0:chartScale.GetYByValue(yValues[3]))
				},
				dxbrush
			);
		}
		private int GetX0(int bars, ChartControl chartControl, bool atMiddle = false) { return chartControl.GetXByBarIndex(chartControl.BarsArray[0], bars) - (atMiddle ? (int)(chartControl.Properties.BarDistance / 2) : 0); }
		#endregion
//==========================================================================================================================================
		public override void OnRenderTargetChanged()
		{
//try{
			#region -- OnRenderTargetChanged --
			#region dispose of brushes
line=3954;//Printline);
			if( PeakTimesBrushDX!=null && !PeakTimesBrushDX.IsDisposed) {PeakTimesBrushDX.Dispose(); PeakTimesBrushDX = null;}
			if( ChannelBkgBrushDX!=null && !ChannelBkgBrushDX.IsDisposed) {ChannelBkgBrushDX.Dispose(); ChannelBkgBrushDX=null;}
			if( ExcursionLevel1_BrushDX!=null && !ExcursionLevel1_BrushDX.IsDisposed) {ExcursionLevel1_BrushDX.Dispose(); ExcursionLevel1_BrushDX=null;}
			if( ExcursionLevel2_BrushDX!=null && !ExcursionLevel2_BrushDX.IsDisposed) {ExcursionLevel2_BrushDX.Dispose(); ExcursionLevel2_BrushDX=null;}
			if( ExcursionLevel3_BrushDX!=null && !ExcursionLevel3_BrushDX.IsDisposed) {ExcursionLevel3_BrushDX.Dispose(); ExcursionLevel3_BrushDX=null;}
			if( DownMomentumBkg_BrushDX!=null && !DownMomentumBkg_BrushDX.IsDisposed) {DownMomentumBkg_BrushDX.Dispose(); DownMomentumBkg_BrushDX=null;}
			if( UpMomentumBkg_BrushDX!=null && !UpMomentumBkg_BrushDX.IsDisposed) {UpMomentumBkg_BrushDX.Dispose(); UpMomentumBkg_BrushDX=null;}
			if( PredictionOscillatorBrushDX !=null && !PredictionOscillatorBrushDX.IsDisposed) {PredictionOscillatorBrushDX.Dispose(); PredictionOscillatorBrushDX = null;}
			if( ChartBackgroundBrushDX!=null && !ChartBackgroundBrushDX.IsDisposed) {ChartBackgroundBrushDX.Dispose(); ChartBackgroundBrushDX = null;}
			for(int i = 0; i<PlotBrushDXes50pct.Length; i++) {
				if(PlotBrushDXes50pct[i] !=null){// && !PlotBrushDXes50pct[i].IsDisposed) {
					PlotBrushDXes50pct[i].Dispose(); PlotBrushDXes50pct[i] = null;
				}
			}
//			if( VMDLabelDotBrushDX!=null && !VMDLabelDotBrushDX.IsDisposed) {VMDLabelDotBrushDX.Dispose();VMDLabelDotBrushDX =null;}
//			if( RSILabelDotBrushDX!=null && !RSILabelDotBrushDX.IsDisposed) {RSILabelDotBrushDX.Dispose(); RSILabelDotBrushDX=null;}
//			if( CCILabelDotBrushDX!=null && !CCILabelDotBrushDX.IsDisposed) {CCILabelDotBrushDX.Dispose(); CCILabelDotBrushDX=null;}
//			if( StochLabelDotBrushDX!=null && !StochLabelDotBrushDX.IsDisposed) {StochLabelDotBrushDX.Dispose(); StochLabelDotBrushDX=null;}
//			if( MACDLabelDotBrushDX!=null && !MACDLabelDotBrushDX.IsDisposed) {MACDLabelDotBrushDX.Dispose(); MACDLabelDotBrushDX=null;}
//			if( FisherLabelDotBrushDX!=null && !FisherLabelDotBrushDX.IsDisposed) {FisherLabelDotBrushDX.Dispose(); FisherLabelDotBrushDX=null;}
//			LabelDotBrushDX_dict[ARC_CycleForecaster_AnalysisType.CCI]
line=3976;//Printline);
			var list = LabelDotBrushDX_dict.Keys.ToList();
			foreach(var k in list){
				//Print("Disposing brush for "+k.ToString());
				if( LabelDotBrushDX_dict[k]!=null && !LabelDotBrushDX_dict[k].IsDisposed) {LabelDotBrushDX_dict[k].Dispose(); LabelDotBrushDX_dict[k]=null;}
			}
//			if(CZoneBrushDX !=null && !CZoneBrushDX.IsDisposed) {CZoneBrushDX.Dispose(); CZoneBrushDX = null;}
//			if( !=null && !.IsDisposed) {.Dispose(); =null;}
			#endregion

line=3986;//Printline);
			for(int i = 0; i<Plots.Length; i++) {
				if(RenderTarget!=null){
					PlotBrushDXes50pct[i]=Plots[i].Pen.Brush.ToDxBrush(RenderTarget);
					PlotBrushDXes50pct[i].Opacity = 0.5f;
				}
			}
line=3993;//Printline);
			if(RenderTarget!=null)
				PeakTimesBrushDX = Brushes.White.ToDxBrush(RenderTarget);
line=3996;//Printline);
			if(RenderTarget!=null){
				ChannelBkgBrushDX = ChannelColor.ToDxBrush(RenderTarget);
	            ChannelBkgBrushDX.Opacity = ChannelOpacity / 100f;
			}
line=4001;//Printline);
			if(RenderTarget!=null) ExcursionLevel1_BrushDX = pLevel1Color.ToDxBrush(RenderTarget);
			if(RenderTarget!=null) ExcursionLevel2_BrushDX = pLevel2Color.ToDxBrush(RenderTarget);
			if(RenderTarget!=null) ExcursionLevel3_BrushDX = pLevel3Color.ToDxBrush(RenderTarget);
			if(RenderTarget!=null) {
				UpMomentumBkg_BrushDX   = pUpMomentumBkgBrush.ToDxBrush(RenderTarget);
				UpMomentumBkg_BrushDX.Opacity = pUpBkgOpacity/100f;
			}
line=4009;//Printline);
			if(RenderTarget!=null) {
				DownMomentumBkg_BrushDX = pDownMomentumBkgBrush.ToDxBrush(RenderTarget);
				DownMomentumBkg_BrushDX.Opacity = pDownBkgOpacity/100f;
			}
line=4014;//Printline);
			if(RenderTarget!=null) {
				PredictionOscillatorBrushDX = pPredictionOscillatorBrush.ToDxBrush(RenderTarget);
			}
line=4018;//Printline);
			if(RenderTarget!=null && ChartControl!=null){
				ChartBackgroundBrushDX = ChartControl.Properties.ChartBackground.ToDxBrush(RenderTarget);
			}
line=4022;//Printline);
			if(RenderTarget!=null){
				LabelDotBrushDX_dict[ARC_CycleForecaster_AnalysisType.VMDivergence] = pVMDLabelDotBrush.ToDxBrush(RenderTarget);
			}
			if(RenderTarget!=null){
line=4027;//Printline);
				LabelDotBrushDX_dict[ARC_CycleForecaster_AnalysisType.RSI] = pRSILabelDotBrush.ToDxBrush(RenderTarget);
			}
			if(RenderTarget!=null){
line=4031;//Printline);
				LabelDotBrushDX_dict[ARC_CycleForecaster_AnalysisType.CCI] = pCCILabelDotBrush.ToDxBrush(RenderTarget);
			}
			if(RenderTarget!=null){
line=4035;//Printline);
				LabelDotBrushDX_dict[ARC_CycleForecaster_AnalysisType.Stoch] = pStochLabelDotBrush.ToDxBrush(RenderTarget);
			}
			if(RenderTarget!=null){
line=4039;//Printline);
				LabelDotBrushDX_dict[ARC_CycleForecaster_AnalysisType.MACD] = pMACDLabelDotBrush.ToDxBrush(RenderTarget);
			}
			if(RenderTarget!=null){
line=4039;//Printline);
				LabelDotBrushDX_dict[ARC_CycleForecaster_AnalysisType.MACDHisto] = pMACDLabelDotBrush.ToDxBrush(RenderTarget);
			}
			if(RenderTarget!=null){
line=4043;//Printline);
				LabelDotBrushDX_dict[ARC_CycleForecaster_AnalysisType.Fisher] = pFisherLabelDotBrush.ToDxBrush(RenderTarget);
			}
			#endregion
//}catch(Exception e1){
//	Print("PlotBrushDXes50pct.Length: "+PlotBrushDXes50pct.Length+"  Plots.Length: "+Plots.Length);
//	Print(line+":  e1: "+e1.ToString());
//}
		}

//====================================================================
		private string AddSoundFolder(string wav){
			return System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", wav);
		}
//====================================================================
		private static int CompareTimePriceByTime(TimePrice a, TimePrice b){
			return a.Time.CompareTo(b.Time);
		}
//====================================================================
		private static int CompareTimePriceByPrice(TimePrice a, TimePrice b){
			return a.Price.CompareTo(b.Price);
		}
//===========================================================================================================
		private void AutoCalculateLevels(ref double MaxLows, ref double MinHighs, int absLastBarOfDay, List<TimePrice> HighPeaksToday, List<TimePrice> LowPeaksToday, SortedDictionary<DateTime, HistoData> GaplessHisto, SortedDictionary<DateTime,double> LongTimeLabels, SortedDictionary<DateTime,double> ShortTimeLabels) {
			#region -- AutoCalculateFilterLevels --
			try{

			if(pUseAutoPeakCalculation){
				HighPeaksToday.Sort(CompareTimePriceByPrice);
				if(HighPeaksToday.Count>1 && HighPeaksToday[0].Price < HighPeaksToday.Last().Price) HighPeaksToday.Reverse();
				if(HighPeaksToday.Count>0){
					int count = (int)Math.Round(HighPeaksToday.Count * pAutoPeakPercentile/100.0, 0);
					MinHighs = HighPeaksToday[count].Price;
					var p = MinHighs;
					HighPeaksToday = HighPeaksToday.Where(k=>k.Price >= p).ToList();
				}
				foreach(var p in HighPeaksToday){
					GaplessHisto[p.Time].IsSignalBar = 'S';
					ShortTimeLabels[GaplessHisto[p.Time].PrintTime] = p.Price;
				}
			}else{
				foreach(var p in HighPeaksToday)
					if(GaplessHisto[p.Time].Val > MinHighs){
						GaplessHisto[p.Time].IsSignalBar = 'S';
						ShortTimeLabels[GaplessHisto[p.Time].PrintTime] = p.Price;
					}
			}

			if(pUseAutoPeakCalculation){
				LowPeaksToday.Sort(CompareTimePriceByPrice);
				if(LowPeaksToday.Count>1 && LowPeaksToday[0].Price > LowPeaksToday[LowPeaksToday.Count-1].Price) LowPeaksToday.Reverse();
				if(LowPeaksToday.Count>0){
					int count = (int)Math.Round(LowPeaksToday.Count * pAutoPeakPercentile/100.0, 0);
					MaxLows = LowPeaksToday[count].Price;
					var p = MaxLows;
					LowPeaksToday = LowPeaksToday.Where(k=>k.Price <= p).ToList();
				}
				foreach(var p in LowPeaksToday){
					GaplessHisto[p.Time].IsSignalBar = 'L';
					LongTimeLabels[GaplessHisto[p.Time].PrintTime] = p.Price;
				}
			}else{
				foreach(var p in LowPeaksToday)
					if(GaplessHisto[p.Time].Val < MaxLows){
						GaplessHisto[p.Time].IsSignalBar = 'L';
						LongTimeLabels[GaplessHisto[p.Time].PrintTime] = p.Price;
					}
			}
			
			var keys = GaplessHisto.Where(k=>k.Value.MinHigh == double.MinValue || k.Value.MaxLow == double.MinValue).Select(k=>k.Key).ToList();
			foreach(var k in keys) {
				GaplessHisto[k].MaxLow  = MaxLows;
				GaplessHisto[k].MinHigh = MinHighs;
			}
			}catch(Exception ex){PrintMakeString(new Object[]{Time[0].ToString(),"  Line:",line,"   Error in AutoCalculateLevels: ",ex.ToString()});}
			#endregion
		}
//==================================================================================================
		private static bool FindPredictionInList(DateTime t) {
			if(t == PredictionTimeToSearchFor) return true;
			else return false;
		}
//===========================================================================================================
		public string GetPredictionsString() 
		{
			Update();
			string msgs = string.Empty;
			try{ msgs = AssemblePredictionMsgs(CurrentASet.HistoHighPeaks, CurrentASet.HistoLowPeaks); }catch(Exception gp2){}
			return msgs;
		}
//===========================================================================================================
        protected override void OnMarketData(MarketDataEventArgs e)
        {
			then = now;
			now = e.Time;
//			if(now.Day!=then.Day) NewDay=true;
        }
//===========================================================================================================
		private string AssemblePredictionMsgs(List<DateTime> HistoHighPeaks, List<DateTime> HistoLowPeaks){
			#region AssemblePredictionMsgs
			var antype = pAnalysisType.ToString();
			if(antype.Contains("VMD")) 
				antype="VMD";
			else
				antype = antype.Substring(0,Math.Min(antype.Length,4));

			if(pMarkerDirection == ARC_CycleForecaster_MarkerDirection.None) return "None selected";
			int MsgCount = 0;
			int lptr = 0;
			int hptr = 0;
			int pptr = 0; //this is the pointer to the Predictions Series<double>, which is exposed to the caller
			int SearchCount = 0;
			string PredictionMsgs = "Future Signals...";//string.Empty;

			while(MsgCount<4 && SearchCount<50) {
				SearchCount++;
				if(lptr>=HistoLowPeaks.Count && hptr>=HistoHighPeaks.Count) break;
				if(HistoLowPeaks.Count==0 && HistoHighPeaks.Count == 0)     break;
				long predH = 0;
				if(hptr<=HistoHighPeaks.Count-1 && (pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Shorts || pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Both)) {
					predH = HistoHighPeaks[hptr].Ticks;
					if(predH < now.Ticks) { HistoHighPeaks.RemoveAt(hptr); predH = -1; SearchCount--; }
				}
				long predL = 0;
				if(lptr<=HistoLowPeaks.Count-1 && (pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Longs || pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Both)) {
					predL = HistoLowPeaks[lptr].Ticks;
					if(predL < now.Ticks) { HistoLowPeaks.RemoveAt(lptr); predL = -1; SearchCount--; }
				}
				if(predH<0 || predL<0) continue;

				string infostr = string.Empty;
				if((predL==0 || predH <= predL) && hptr < HistoHighPeaks.Count && (pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Shorts || pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Both)) {
					TimeSpan tosignal = new TimeSpan(HistoHighPeaks[hptr].Ticks - now.Ticks);
					if(pptr<CurrentBar-3 && pptr<8) {
						pptr++;
					}
					if(ChartControl!=null){
						if(tosignal.TotalMinutes > 1)       infostr = MakeString(new Object[]{" in ",tosignal.TotalMinutes.ToString("0")," mins"});
						else if(tosignal.TotalMinutes == 1) infostr = MakeString(new Object[]{" in ",tosignal.TotalMinutes.ToString("0")," min"});
						else if(tosignal.TotalMinutes < 1)  infostr = " now";
						PredictionMsgs = MakeString(new Object[]{PredictionMsgs , NL , antype," SHORT",infostr});
					}
					MsgCount++;
					if(hptr<HistoHighPeaks.Count) hptr++;
				}
				if((predH==0 || predL <= predH) && lptr < HistoLowPeaks.Count && (pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Longs || pMarkerDirection == ARC_CycleForecaster_MarkerDirection.Both)) {
					TimeSpan tosignal = new TimeSpan(HistoLowPeaks[lptr].Ticks - now.Ticks);
					if(pptr<CurrentBar-3 && pptr<8) {
						pptr++;
					}
					if(ChartControl!=null){
						if(tosignal.TotalMinutes > 1)       infostr = MakeString(new Object[]{" in ",tosignal.TotalMinutes.ToString("0")," mins"});
						else if(tosignal.TotalMinutes == 1) infostr = MakeString(new Object[]{" in ",tosignal.TotalMinutes.ToString("0")," min"});
						else if(tosignal.TotalMinutes == 0) infostr = " now";
						PredictionMsgs = MakeString(new Object[]{PredictionMsgs , NL , antype," LONG",infostr});
					}
					MsgCount++;
					if(lptr<HistoLowPeaks.Count) lptr++;
				}
			}
			return PredictionMsgs;
			#endregion
		}
//===========================================================================================================
		internal class LoadSoundFileList : StringConverter
		{
			#region LoadSoundFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";

				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("SOUND OFF");
//				list.Add("<inst>_Short_CycleForecaster.wav");
//				list.Add("<inst>_Long_CycleForecaster.wav");
//				list.Add("<inst>_Neutral_CycleForecaster.wav");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
        }
//==============================================================================================
		private static string RemoveInsignificantDigits(string input){
			if(!input.Contains( @".")) return input;
			var sb = new System.Text.StringBuilder(input);
			while(sb.Length>0 && sb[sb.Length-1] == '0') 
				sb = sb.Remove(sb.Length-1,1);
			if(sb[sb.Length-1] == '.') sb = sb.Remove(sb.Length-1,1);
			return sb.ToString();
		}
//==============================================================================================
		private static string KeepOnlyTheseCharacters(string instr, string CharactersToKeep){
		string ret = string.Empty;
		char[] str = instr.ToCharArray(0,instr.Length);
		for(int i = 0; i<str.Length; i++) if(CharactersToKeep.Contains(str[i].ToString())) ret = string.Concat(ret,str[i].ToString());
		return ret;
	}
//==============================================================================================
		internal class LoadDrawingTemplates : StringConverter
		{
			#region LoadDrawingTemplates
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string search = "*.xml";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				var list = new List<string>();//new string[filCustom.Length+1];
				var types = new List<string>(){"Dot","ArrowUp","ArrowDown","Diamond","TriangleUp","TriangleDown","Square"};
				foreach(var type in types){
					string[] paths = new string[4]{NinjaTrader.Core.Globals.UserDataDir,"templates","DrawingTool",type};
//					HLtemplates_folder = System.IO.Path.Combine(paths);
					try{
						dirCustom = new System.IO.DirectoryInfo(System.IO.Path.Combine(paths));
						filCustom = dirCustom.GetFiles( search);
					}catch{}

					if(list.Count==0) list.Add("Default");
					if(filCustom!=null){
						foreach (System.IO.FileInfo fi in filCustom)
						{
							string name = fi.Name.Replace(".xml",string.Empty);
							if(name=="Default") continue;
							name = type+"> "+name;
							if(!list.Contains(name)){
								list.Add(name);
							}
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
		}
		#region Plots
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> LongSig {get { return Values[0]; }}
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> ShortSig {get { return Values[1]; }}
//		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
//		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
//		public Series<double> Predictions {get { return Values[2]; }}
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> ActiveUp {get { return Values[2]; }}
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> ActiveDown {get { return Values[3]; }}
//		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
//		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
//		public Series<double> InactiveUp {get { return Values[5]; }}
//		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
//		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
//		public Series<double> InactiveDown {get { return Values[6]; }}
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> UpperMarkerLine {get { return Values[4]; }}
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> LowerMarkerLine {get { return Values[5]; }}

		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> BBUpper {get { return Values[6]; }}
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> BBLower {get { return Values[7]; }}
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> BBline {get { return Values[8]; }}
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> BBdot {get { return Values[9]; }}

		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> CCIline {get { return Values[10]; }}
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> RSIline {get { return Values[11]; }}
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> RSIAvgline {get { return Values[12]; }}
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> MACDline {get { return Values[13]; }}
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> MACDSignalLine {get { return Values[14]; }}
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> MACDDiffLine {get { return Values[15]; }}
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> StochDline {get { return Values[16]; }}
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> StochKline {get { return Values[17]; }}
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> Fisherline {get { return Values[18]; }}
#if RSS_AND_RVI
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> RSSline {get { return Values[19]; }}
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> RVIline {get { return Values[20]; }}
#endif
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<double> Complete_Histo {get { Update(); return CurrentASet.ShiftedHisto; }}
//		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
//		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
//		public Series<bool> InChopZone
//		{get { return inChopZone; }}
		[Browsable(false)]	// this line prevents the data series from being displayed in the indicator properties dialog, do not remove
		[XmlIgnore()]		// this line ensures that the indicator can be saved/recovered as part of a chart template, do not remove
		public Series<int> NextSignal{ get { Update(); return nextSignal; }}
		#endregion

		#region -- Peak/Valley Selection --
        [Display(Order = 10, Name = "Use AutoPeak Calc?", GroupName = "Peak/Valley Selection", Description = "")]
		[Description("Automatically calculate Max/Min peak levels, or use the fixed values")]
		[NinjaScriptProperty]
        [RefreshProperties(RefreshProperties.All)] // Needed to refresh the property grid when the value changes
		public bool pUseAutoPeakCalculation{get;set;}

		private int pAutoPeakPercentile = 20;
		[Description("Automatically calculate Max/Min peak levels, every day, based on this percentile (enter between 0 and 100, recommend 20).  Small percentiles reduce the number of signals, larger percentiles increase them.  Enter '-1' to turn-off auto calculation")]
        [Display(Order = 20, Name = "AutoPercentile", GroupName = "Peak/Valley Selection")]
		[NinjaScriptProperty]
		public int AutoPeakPercentile
		{
			get { return pAutoPeakPercentile; }
			set { pAutoPeakPercentile = Math.Min(100,Math.Max(-1,value)); }
		}
		[Description("Minimum upward histo peak distance to qualify as a marked turning point")]
        [Display(Order = 30, Name = "Min peak level", GroupName = "Peak/Valley Selection")]
		[NinjaScriptProperty]
		public string HighPeakMinForValidMarker
		{
			get { return RemoveInsignificantDigits(pMinHighPeakForValidMarker.ToString("0.00000000")); }
			set { pMinHighPeakForValidMarker = Math.Abs(Convert.ToDouble(KeepOnlyTheseCharacters(value.ToString(), "+0123456789.eE"))); }
		}
		[Description("Maximum downward histo peak distance to qualify as a marked turning point")]
        [Display(Order = 40, Name = "Max peak level", GroupName = "Peak/Valley Selection")]
		[NinjaScriptProperty]
		public string LowPeakMaxForValidMarker
		{
			get { return RemoveInsignificantDigits(pMaxLowPeakForValidMarker.ToString("0.00000000"));}
			set { pMaxLowPeakForValidMarker = -Math.Abs(Convert.ToDouble(KeepOnlyTheseCharacters(value.ToString(), "+-0123456789.eE"))); }
		}
		#endregion
		
		#region Signature parameters
		private ARC_CycleForecaster_AnalysisType pAnalysisType = ARC_CycleForecaster_AnalysisType.VMDivergence;
        [Display(Order = 10, Name = "Analysis Type", GroupName = "Parameters", Description = "")]
		[NinjaScriptProperty]
		public ARC_CycleForecaster_AnalysisType AnalysisType
		{
			get { return pAnalysisType; }
			set { pAnalysisType = value; }
		}

		private bool pIsMultiSignal = false;
        [Display(Order = 20, Name = "MultiSignals Enabled", GroupName = "Parameters", Description = "")]
		[NinjaScriptProperty]
		public bool IsMultiSignal
		{
			get { return pIsMultiSignal; }
			set { pIsMultiSignal = value; }
		}

		private int pRSIperiod = 14;
        [Display(Order = 30, Name = "RSI Period", GroupName = "Parameters", Description = "")]
		[NinjaScriptProperty]
		public int RSIperiod
		{
			get { return pRSIperiod; }
			set { pRSIperiod = Math.Max(1, value); }
		}
		private int pFisherPeriod = 10;
        [Display(Order = 40, Name = "Fisher Period", GroupName = "Parameters", Description = "")]
		[NinjaScriptProperty]
		public int FisherPeriod
		{
			get { return pFisherPeriod; }
			set { pFisherPeriod = Math.Max(1, value); }
		}
#if RSS_AND_RVI
//		private int pRVIperiod = 14;
//		[Display(Order = 50, Name = "RVI Period", GroupName = "Parameters", Description = "")]
//		[NinjaScriptProperty]
//		public int RVIperiod
//		{
//			get { return pRVIperiod; }
//			set { pRVIperiod = Math.Max(1, value); }
//		}
//		private int pRSSperiod1 = 10;
//		[Display(Order = 60, Name = "RSS Period 1", GroupName = "Parameters", Description = "")]
//		[NinjaScriptProperty]
//		public int RSSperiod1
//		{
//			get { return pRSSperiod1; }
//			set { pRSSperiod1 = Math.Max(1, value); }
//		}
//		private int pRSSperiod2 = 40;
//		[Display(Order = 70, Name = "RSS Period 2", GroupName = "Parameters", Description = "")]
//		[NinjaScriptProperty]
//		public int RSSperiod2
//		{
//			get { return pRSSperiod2; }
//			set { pRSSperiod2 = Math.Max(1, value); }
//		}
//		private int pRSSLength = 5;
//		[Display(Order = 80, Name = "RSS Length", GroupName = "Parameters", Description = "")]
//		[NinjaScriptProperty]
//		public int RSSLength
//		{
//			get { return pRSSLength; }
//			set { pRSSLength = Math.Max(1, value); }
//		}
#endif

		private int    pCCIperiod = 30;
        [Display(Order = 90, Name = "CCI Period", GroupName = "Parameters", Description = "")]
		[NinjaScriptProperty]
		public int CCIperiod
		{
			get { return pCCIperiod; }
			set { pCCIperiod = Math.Max(1, value); }
		}

		private int    pMACDfast = 5;
        [Display(Order = 100, Name = "MACD fast", GroupName = "Parameters", Description = "Fast MA period for MACD - used in MACD AnalysisType")]
		[NinjaScriptProperty]
		public int MACDfast
		{
			get { return pMACDfast; }
			set { pMACDfast = Math.Max(1, value); }
		}
		
		private int    pMACDslow = 20;
        [Display(Order = 101, Name = "MACD slow", GroupName = "Parameters", Description = "Slow MA period for MACD - used in MACD AnalysisType")]
		[NinjaScriptProperty]
		public int MACDslow
		{
			get { return pMACDslow; }
			set { pMACDslow = Math.Max(1, value); }
		}
		private int    pMACDsmooth = 9;
        [Display(Order = 102, Name = "MACD smooth", GroupName = "Parameters", Description = "Smooth MA period for MACD - used in MACD AnalysisType")]
		[NinjaScriptProperty]
		public int MACDsmooth
		{
			get { return pMACDsmooth; }
			set { pMACDsmooth = Math.Max(1, value); }
		}

		private int    pDperiod = 7;
        [Display(Order = 110, Name = "Stoch D period", GroupName = "Parameters", Description = "Only used if Stoch AnalysisType is selected")]
		[NinjaScriptProperty]
		public int StochDperiod
		{
			get { return pDperiod; }
			set { pDperiod = Math.Max(1, value); }
		}
		
		private int    pKperiod = 14;
        [Display(Order = 111, Name = "Stoch K period", GroupName = "Parameters", Description = "Only used if Stoch AnalysisType is selected")]
		[NinjaScriptProperty]
		public int StochKperiod
		{
			get { return pKperiod; }
			set { pKperiod = Math.Max(1, value); }
		}

		private int pMaxWeeks = 2;
        [Display(Order = 120, Name = "Max Weeks", GroupName = "Parameters", Description = "Number of weeks in the calculation")]
		[NinjaScriptProperty]
		public int MaxWeeks
		{
			get { return pMaxWeeks; }
			set { pMaxWeeks = Math.Max(1,value); }
		}
		private bool pEliminateOvernightGap = false;
//        [Display(Order = 130, Name = "Eliminate Overnight Gap", GroupName = "Parameters", Description = "If there's an overnight gap, there may be a long gap in the oscillator panel.")]
//		public bool EliminateOvernightGap
//		{
//			get { return pEliminateOvernightGap; }
//			set { pEliminateOvernightGap = value; }
//		}

//		private int pMinutesAdvanceWarning = 0;
//        [Display(Order = 170, Name = "Minutes advance warning", GroupName = "Parameters", Description = "If you want to get the Long or Short signals to plot in advance of their actual time, increase this parameter")]
//		[NinjaScriptProperty]
//		public int MinutesAdvanceWarning
//		{
//			get { return pMinutesAdvanceWarning; }
//			set { pMinutesAdvanceWarning = value; }
//		}
		#endregion

		#region Visuals
        [Display(Order = 10, Name = "Marker Direction", GroupName = "Visuals", Description = "")]
		public ARC_CycleForecaster_MarkerDirection pMarkerDirection {get;set;}

		[Description("Button text - enter how you want the UI button to be labeled")]
		[Display(Order = 20, Name = "Button Txt",  GroupName = "Visuals", ResourceType = typeof(Custom.Resource))]
		public string pButtonText {get;set;}

		private ARC_CycleForecaster_PredictionLocType pPredictionMsgLoc = ARC_CycleForecaster_PredictionLocType.TopLeft;
        [Display(Order = 30, Name = "Prediction msg location", GroupName = "Visuals", Description = "Where to put the prediction messages")]
		public ARC_CycleForecaster_PredictionLocType PredictionMsgLoc{
			get { return pPredictionMsgLoc; }
			set { pPredictionMsgLoc = value; }
		}

//		[Display(Order = 40, Name = "Show day counts", GroupName = "Visuals", Description = "Gives you an idea of the number of days being recognized by the algorithm")]
//		public bool ShowDayCount{
//			get { return pShowDayCount; }
//			set { pShowDayCount = value; }
//		}

//		[Display(Order = 50, Name = "Enable BollingerBands", GroupName = "Visuals", Description = "")]
//		public bool pEnableBBands {get;set;}

		[XmlIgnore]
		[Display(Order = 40, Name = "Prediction Line Color", GroupName = "Visuals", Description = "")]
		public Brush pPredictionOscillatorBrush { get; set; }
				[Browsable(false)]
				public string PredictionOscillatorBrushSerialize{ get { return Serialize.BrushToString(pPredictionOscillatorBrush); } set { pPredictionOscillatorBrush = Serialize.StringToBrush(value); }}

		[Display(Order = 50, Name = "Prediction Line Width", GroupName = "Visuals", Description = "")]
		public int pPredictionOscillatorLineWidth { get; set; }

		[XmlIgnore]
		[Display(Order = 70, Name = "CCI labeldot", GroupName = "Visuals", Description = "")]
		public Brush pCCILabelDotBrush { get; set; }
				[Browsable(false)]
				public string CCILabelDotBrushSerialize{ get { return Serialize.BrushToString(pCCILabelDotBrush); } set { pCCILabelDotBrush = Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Order = 80, Name = "Fisher labeldot", GroupName = "Visuals", Description = "")]
		public Brush pFisherLabelDotBrush { get; set; }
				[Browsable(false)]
				public string FisherLabelDotBrushSerialize{ get { return Serialize.BrushToString(pFisherLabelDotBrush); } set { pFisherLabelDotBrush = Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Order = 90, Name = "MACD labeldot", GroupName = "Visuals", Description = "")]
		public Brush pMACDLabelDotBrush { get; set; }
				[Browsable(false)]
				public string MACDLabelDotBrushSerialize{ get { return Serialize.BrushToString(pMACDLabelDotBrush); } set { pMACDLabelDotBrush = Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Order = 100, Name = "RSI labeldot", GroupName = "Visuals", Description = "")]
		public Brush pRSILabelDotBrush { get; set; }
				[Browsable(false)]
				public string RSILabelDotBrushSerialize{ get { return Serialize.BrushToString(pRSILabelDotBrush); } set { pRSILabelDotBrush = Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Order = 110, Name = "Stoch labeldot", GroupName = "Visuals", Description = "")]
		public Brush pStochLabelDotBrush { get; set; }
				[Browsable(false)]
				public string StochLabelDotBrushSerialize{ get { return Serialize.BrushToString(pStochLabelDotBrush); } set { pStochLabelDotBrush = Serialize.StringToBrush(value); }}
		[XmlIgnore]
		[Display(Order = 120, Name = "VMD labeldot", GroupName = "Visuals", Description = "")]
		public Brush pVMDLabelDotBrush { get; set; }
				[Browsable(false)]
				public string VMDLabelDotBrushSerialize{ get { return Serialize.BrushToString(pVMDLabelDotBrush); } set { pVMDLabelDotBrush = Serialize.StringToBrush(value); }}

		[Range(1,int.MaxValue)]
		[Display(Order = 130, Name = "Multisignal Arrow Count", GroupName = "Visuals", Description = "Min number of buy/sell arrows in adjacent bars to qualify as a valid Multisignal")]
		public int pMultiSignalArrowCount { get; set; }

		[Range(1,int.MaxValue)]
		[Display(Order = 140, Name = "Multisignal Bar Variance", GroupName = "Visuals", Description = "Num of bars involved in the clustering of signals")]
		public int pMultiSignalBarVariance { get; set; }

		#endregion

		#region "BB Parameters"
        [Range(1, int.MaxValue)]
        [Display(Name = "Period Bollinger Band", GroupName = "BB Parameters", Description = "Band Period for Bollinger Band", Order = 0)]
        public int BandPeriod { get; set; }

        [Display(Name = "Lookback fast EMA", GroupName = "BB Parameters", Description = "Period for fast EMA", Order = 5)]
        public int pBBFast { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Name = "Lookback slow EMA", GroupName = "BB Parameters", Description = "Period for slow EMA", Order = 10)]
        public int pBBSlow { get; set; }


        [Range(0, double.MaxValue)]
        [Display(Name = "Std. dev. multiplier", GroupName = "BB Parameters", Description = "Number of standard deviations", Order = 20)]
        public double StdDevNumber { get; set; }

		[XmlIgnore]
		[Display(Name = "Rising dots above channel ", GroupName = "BB Parameters", Description = "Select Color", Order = 30)]
		public Brush DotsUpRisingColor { get; set; }
				[Browsable(false)]
				public string DotsUpRisingColorSerialize{ get { return Serialize.BrushToString(DotsUpRisingColor); } set { DotsUpRisingColor = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Rising dots inside/below channel ", GroupName = "BB Parameters", Description = "Select Color", Order = 40)]
		public Brush DotsDownRisingColor { get; set; }
				[Browsable(false)]
				public string DotsDownRisingColorSerialize{ get { return Serialize.BrushToString(DotsDownRisingColor); } set { DotsDownRisingColor = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Falling dots below channel ", GroupName = "BB Parameters", Description = "Select Color", Order = 50)]
		public Brush DotsDownFallingColor { get; set; }
				[Browsable(false)]
				public string DotsDownFallingColorSerialize { get { return Serialize.BrushToString(DotsDownFallingColor); } set { DotsDownFallingColor = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 60, Name = "Falling dots inside/above channel ", GroupName = "BB Parameters", Description = "Select Color")]
		public Brush DotsUpFallingColor { get; set; }
				[Browsable(false)]
				public string DotsUpFallingColorSerialize { get { return Serialize.BrushToString(DotsUpFallingColor); } set { DotsUpFallingColor = Serialize.StringToBrush(value); }}

        [XmlIgnore]
        [Display(Order = 70, Name = "Channel Color", GroupName = "BB Parameters", Description = "Select Color")]
        public Brush ChannelColor { get; set; }
		        [Browsable(false)]
    		    public string ChannelColorSerialize {get { return Serialize.BrushToString(ChannelColor); } set { ChannelColor = Serialize.StringToBrush(value); }}

		[Range(0, 100)]
        [Display(Order = 80, Name = "Channel Opacity", GroupName = "BB Parameters", Description = "Opacity for shading the area between the Bollinger Bands")]
        public int ChannelOpacity { get; set; }

		#endregion

		#region "Price Excursion"
		[XmlIgnore]
		[Display(Name = "Color level 1 ", GroupName = "Price Excursion", Description = "Select Color for Level 1 lines", Order = 10)]
		public Brush pLevel1Color { get; set; }
				[Browsable(false)]
				public string Level1ColorSerialize { get { return Serialize.BrushToString(pLevel1Color); }set { pLevel1Color = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Color level 2 ", GroupName = "Price Excursion", Description = "Select Color for Level 2 lines", Order = 20)]
		public Brush pLevel2Color { get; set; }
				[Browsable(false)]
				public string Level2ColorSerialize{ get { return Serialize.BrushToString(pLevel2Color); } set { pLevel2Color = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Name = "Color level 3 ", GroupName = "Price Excursion", Description = "Select Color for Level 3 lines", Order = 30)]
		public Brush pLevel3Color { get; set; }
				[Browsable(false)]
				public string Level3ColorSerialize{get { return Serialize.BrushToString(pLevel3Color); }set { pLevel3Color = Serialize.StringToBrush(value); }}

		[Display(Name = "Display Level 1", GroupName = "Price Excursion", Description = "", Order = 40)]
		public bool pDisplayExcursion1 {get;set;}
		[Display(Name = "Display Level 2", GroupName = "Price Excursion", Description = "", Order = 50)]
		public bool pDisplayExcursion2 {get;set;}
		[Display(Name = "Display Level 3", GroupName = "Price Excursion", Description = "", Order = 60)]
		public bool pDisplayExcursion3 {get;set;}

		[Range(1, int.MaxValue)]
		[Display(Name = "Width for lines", GroupName = "Price Excursion", Description = "Width for level lines", Order = 70)]
		public int pWidthExcursionLines { get; set; }
		
		[Display(Name = "Static levels?", GroupName = "Price Excursion", Description = "", Order = 80)]
		public bool pExcursionLevelsIsStatic {get;set;}
		#endregion

		#region Other properties
		public bool PredictionTimesRelative = false;
	//		private bool pPlacePredictions=false;
	//		[Description("Testing")]
	//        [Category("Testing")]
	//        public bool PlacePredictions
	//        {
	//            get { return pPlacePredictions; }
	//            set { pPlacePredictions = value; }
	//        }

	//		private bool pWritePredictionsOnPricePanel = true;
	//		[Description("Write price predictions messages to Price Panel?  If not, they'll be written to the histogram panel")]
	//        [Category("Visual")]
	//        public bool PredictionsOnPrice
	//        {
	//            get { return pWritePredictionsOnPricePanel; }
	//            set { pWritePredictionsOnPricePanel = value; }
	//        }


		private string pLongPhrase = "/[InstrumentName] Long [SayPrice]";
		private string pShortPhrase = "/[InstrumentName] Short [SayPrice]";
#if SPEECH_ENABLED
		#region SpeechEnabled
		[Description("Message to speak when a long signal occurs...put '/' at beginning of line to turn-off spoken message")]
		[Category("Alert Voice")]
		public string LongPhrase
		{
			get { return pLongPhrase; }
			set { pLongPhrase = value; }
		}
		[Description("Message to speak when a short signal occurs...put '/' at beginning of line to turn-off spoken message")]
		[Category("Alert Voice")]
		public string ShortPhrase
		{
			get { return pShortPhrase; }
			set { pShortPhrase = value; }
		}
		#endregion
#endif

		#region ChopZone visual settings
//		private bool pChopZonesEnabled = true;
//		private bool pChopZonesOnAllPanels = false;
//		private int pChopZoneOpacity = 8;
//		private Brush pChopZoneColor = Brushes.Maroon;
//		private double pChopZonesMinutes = 10;
//		[Description("Number of minutes to qualify a ChopZone is present")]
//		[Category("Visuals - ChopZone")]
//		public double CZMinutes
//		{
//			get { return pChopZonesMinutes; }
//			set { pChopZonesMinutes = value; }
//		}
//		[Description("Enable ChopZones?  Set to 'false' to help speedup your computer")]
//		[Category("Visuals - ChopZone")]
//		public bool ChopZoneEnabled
//		{
//			get { return pChopZonesEnabled; }
//			set { pChopZonesEnabled = value; }
//		}
//		[Description("Extend the background coloring of chop zone across all panels on the chart? (only used if ShiftCurrentHisto = true")]
//		[Category("Visuals - ChopZone")]
//		public bool CZOnAllPanels
//		{
//			get { return pChopZonesOnAllPanels; }
//			set { pChopZonesOnAllPanels = value; }
//		}
//		[Description("Opacity of ChopZone color, 0=transparent, 10=opaque")]
//		[Category("Visuals - ChopZone")]
//		public int CZOpacity
//		{
//			get { return pChopZoneOpacity; }
//			set { pChopZoneOpacity = Math.Max(0,Math.Min(10,value)); }
//		}
//		[XmlIgnore()]
//		[Description("Color of ChopZone")]
//		[Category("Visuals - ChopZone")]
//		public Brush CZColor{	get { return pChopZoneColor; }	set { pChopZoneColor = value; }		}
//					[Browsable(false)]
//					public string CZClSerialize
//					{	get { return Serialize.BrushToString(pChopZoneColor); } set { pChopZoneColor = Serialize.StringToBrush(value); }
//					}
		#endregion
		#region Lines on EndOfChopZone category
//		private int pEOCZ_NumOfLines = 2;
//		[Display(ResourceType = typeof(Custom.Resource), Name = "\tNumber shown", GroupName = "Lines on EndOfChopZone")]
//		[Description("Specify the max number of auto-drawn horizontal lines drawn on the open price of the bars at the end of ChopZones")]
//		public int EOCZ_NumOfLines
//		{
//			get { return pEOCZ_NumOfLines; }
//			set { pEOCZ_NumOfLines = Math.Max(-1,value); }
//		}
//		private int pEOCZ_WidthOfLines = 2;
//		[Description("Specify the thickness of horizontal lines drawn on PowerZone markers")]
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Line width", GroupName = "Lines on EndOfChopZone")]
//		public int EOCZ_WidthOfLines
//		{
//			get { return pEOCZ_WidthOfLines; }
//			set { pEOCZ_WidthOfLines = Math.Max(1,value); }
//		}
//		private DashStyleHelper pEOCZ_LineStyle = DashStyleHelper.Solid;
//		[Description("Line style for EndOfChopZone lines?")]
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Line style", GroupName = "Lines on EndOfChopZone")]
//		public DashStyleHelper EOCZ_LineStyle
//		{
//			get { return pEOCZ_LineStyle; }
//			set { pEOCZ_LineStyle = value; }
//		}
//		private EOCZ_PriceOptions pEOCZ_Price = EOCZ_PriceOptions.Close;
//		[Description("Price for EndOfChopZone lines?")]
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Basis price", GroupName = "Lines on EndOfChopZone")]
//		public EOCZ_PriceOptions EOCZ_Price
//		{
//			get { return pEOCZ_Price; }
//			set { pEOCZ_Price = value; }
//		}
//		private Brush pEOCZ_LineColor = Brushes.Lime;
//		[XmlIgnore()]
//		[Description("Color of the EndOfChopZone lines")]
//		[Display(ResourceType = typeof(Custom.Resource), Name = "Line Color", GroupName = "Lines on EndOfChopZone")]
//		public Brush EOCZ_LineColor
//		{
//			get { return pEOCZ_LineColor; }
//			set { pEOCZ_LineColor = value; }
//		}
//		[Browsable(false)]
//		public string EOCZLSerialize
//		{	get { return Serialize.BrushToString(pEOCZ_LineColor); } set { pEOCZ_LineColor = Serialize.StringToBrush(value); }
//		}
		#endregion

//		private int pTimeBlockOpacity = 5;
//		[Description("Opacity of the future TimeBlocks (only relevant if ShiftCurrentHisto is true)  0=transparent, 10=solid opaque")]
//		[Category("Visuals - Shifted Histo")]
//		public int TimeBlockOpacity
//		{
//			get { return pTimeBlockOpacity; }
//			set { pTimeBlockOpacity = Math.Max(0,Math.Min(10,value)); }
//		}

//		private bool pShowInversionHisto = false;
//		[Description("Show the Inverted histo?")]
//		[Category("Visuals")]
//		public bool ShowInversionHisto
//		{
//			get { return pShowInversionHisto; }
//			set { pShowInversionHisto = value; }
//		}

//privateboolpAutoScale=true;
//		[Description("Automatically scale the histogram to the vertical size of the subpanel?")]
//		[Category("Visuals")]
//		public bool AutomaticScaling
//		{
//get{returnpAutoScale;}
//set{pAutoScale=value;}
//		}
		
		private bool pSavePredictions = false;
//		[Description("Save predictions to Market Analyzer compatible file for MarketAnalyzer indicator?")]
//		[Category("MarketAnalyzer")]
//		public bool SavePredictions
//		{
//			get { return pSavePredictions; }
//			set { pSavePredictions = value; }
//		}

#if GAPLESS_DIFFTOOPEN
		[Description("Zero time for calculating the opening price.  Used for GaplessPZ and DiffToOpen analysis types")]
		[Category("Beta")]
		public string ZeroTimeStr
		{
			get { return pZeroTimeStr; }
			set { pZeroTimeStr = value; }
		}
#endif
		private bool pPermitEarlySignals = false;
//		[Description("Permit early signals, before MaxWeeks number of weeks has become accessible?")]
//		[Category("Parameters")]
//		public bool PermitEarlySignals
//		{
//			get { return pPermitEarlySignals; }
//			set { pPermitEarlySignals = value; }
//		}

		private bool pShowPeakTimes = true;
        [Display(Order = 10, Name = "Show Peak Time text", GroupName = "Visuals - PeakTimes", Description = "Print the time of the peak on the peak")]
		public bool ShowPeakTimes
		{
			get { return pShowPeakTimes; }
			set { pShowPeakTimes = value; }
		}
		[Description("Removing historical time labels can help declutter the subpanel")]
		[Display(Order =20, Name = "Show historical time labels",  GroupName = "Visuals - PeakTimes", ResourceType = typeof(Custom.Resource))]
		public bool pShowHistoricalTimeLabels {get;set;}

		private int pTimeLabelSeparation = 0;
        [Display(Order = 30, Name = "Time label separation", GroupName = "Visuals - PeakTimes", Description = "Distance from histo to the time label")]
		public int TimeLabelSeparation
		{
			get { return pTimeLabelSeparation; }
			set { pTimeLabelSeparation = value; }
		}

		//==================================
		#region Visuals - Entry Markers
        [Display(Order = 5, Name = "View State", GroupName = "Visuals - Entry Markers", Description = "Is the oscillator the prediction (Data), or the live, non-prediction (Trading)")]
		public ARC_CycleForecaster_ViewStates pViewState {get;set;}

		private ARC_CycleForecaster_MarkerType pLongMarkerType = ARC_CycleForecaster_MarkerType.ArrowUp;
        [Display(Order = 10, Name = "Long Marker Type", GroupName = "Visuals - Entry Markers", Description = "")]
		public ARC_CycleForecaster_MarkerType LongMarkerType
		{
			get { return pLongMarkerType; }
			set { pLongMarkerType = value; }
		}

		private ARC_CycleForecaster_MarkerType pShortMarkerType = ARC_CycleForecaster_MarkerType.ArrowDown;
        [Display(Order = 20, Name = "Short Marker Type", GroupName = "Visuals - Entry Markers", Description = "")]
		public ARC_CycleForecaster_MarkerType ShortMarkerType
		{
			get { return pShortMarkerType; }
			set { pShortMarkerType = value; }
		}

		[XmlIgnore]
		[Display(Order = 30, Name = "Long Marker color", GroupName = "Visuals - Entry Markers", Description = "Only valid if these are NOT global markers")]
		public Brush LongMarkerColor{	get { return pLongMarkerColor; }	set { pLongMarkerColor = value; }		}
					[Browsable(false)]
					public string BMClSerialize	{	get { return Serialize.BrushToString(pLongMarkerColor); } set { pLongMarkerColor = Serialize.StringToBrush(value); }}

		[XmlIgnore]
		[Display(Order = 40, Name = "Short Marker color", GroupName = "Visuals - Entry Markers", Description = "Only valid if these are NOT global markers")]
		public Brush ShortMarkerColor{	get { return pShortMarkerColor; }	set { pShortMarkerColor = value; }		}
					[Browsable(false)]
					public string SMClSerialize {	get { return Serialize.BrushToString(pShortMarkerColor); } set { pShortMarkerColor = Serialize.StringToBrush(value); }}

        [Display(Order = 50, Name = "Marker Separation", GroupName = "Visuals - Entry Markers", Description = "Ticks between marker and price bar")]
		public int MarkerSeparation
		{
			get { return pMarkerSeparation; }
			set { pMarkerSeparation = value; }
		}

		
		private ARC_CycleForecaster_RacingStripeType pRacingStripeType = ARC_CycleForecaster_RacingStripeType.Subpanel;
        [Display(Order = 60, Name = "RacingStripe Type", GroupName = "Visuals - Entry Markers", Description = "")]
		public ARC_CycleForecaster_RacingStripeType RacingStripeType {  
			get { return pRacingStripeType; }    
			set { pRacingStripeType = value; } 
		}

		private ARC_CycleForecaster_MarkerDirection pRacingStripeDirection = ARC_CycleForecaster_MarkerDirection.None;
        [Display(Order = 70, Name = "RacingStripe Direction", GroupName = "Visuals - Entry Markers", Description = "")]
		public ARC_CycleForecaster_MarkerDirection RacingStripeDirection {  
			get { return pRacingStripeDirection; }    
			set { pRacingStripeDirection = value; } 
		}

		private Brush pLongRacingStripeColor = Brushes.Lime;
		[XmlIgnore()]
        [Display(Order = 80, Name = "Long RacingStripe Color", GroupName = "Visuals - Entry Markers", Description = "")]
		public Brush LongRacingStripeColor{	get { return pLongRacingStripeColor; }	set { pLongRacingStripeColor = value; }		}
					[Browsable(false)]
					public string pLongRacingStripeColorClSerialize	{	get { return Serialize.BrushToString(pLongRacingStripeColor); } set { pLongRacingStripeColor = Serialize.StringToBrush(value); }}

		private double pLongRacingStripeOpacity = 30;
        [Display(Order = 90, Name = "Long RacingStripe Opacity", GroupName = "Visuals - Entry Markers", Description = "0 to 100, set to 0 to be transparent, 100 is full color")]
		public double LongRacingStripeOpacity
		{	get { return pLongRacingStripeOpacity; }
			set { pLongRacingStripeOpacity = Math.Max(0,Math.Min(100,value)); }		}

		private Brush pShortRacingStripeColor = Brushes.Magenta;
		[XmlIgnore()]
        [Display(Order = 100, Name = "Short RacingStripe Color", GroupName = "Visuals - Entry Markers", Description = "")]
		public Brush ShortRacingStripeColor{	get { return pShortRacingStripeColor; }	set { pShortRacingStripeColor = value; }		}
					[Browsable(false)]
					public string pShortRacingStripeColorClSerialize	{	get { return Serialize.BrushToString(pShortRacingStripeColor); } set { pShortRacingStripeColor = Serialize.StringToBrush(value); }}

		private double pShortRacingStripeOpacity = 30;
        [Display(Order = 110, Name = "Short RacingStripe Opacity", GroupName = "Visuals - Entry Markers", Description = "0 to 100, set to 0 to be transparent, 100 is full color")]
		public double ShortRacingStripeOpacity
		{	get { return pShortRacingStripeOpacity; }
			set { pShortRacingStripeOpacity = Math.Max(0,Math.Min(100,value)); }		}

		private bool pEnableMomentumBkg = false;
        [Display(Order = 120, Name = "Enable Momentum bkg", GroupName = "Visuals - Entry Markers", Description = "Colorize the background when oscillator is above zero, or below zero")]
		public bool EnableMomentumBkg
		{	get { return pEnableMomentumBkg; }
			set { pEnableMomentumBkg = value; }		}

		private Brush pUpMomentumBkgBrush = Brushes.Blue;
		[XmlIgnore()]
        [Display(Order = 130, Name = "Up momentum background", GroupName = "Visuals - Entry Markers", Description = "")]
		public Brush UpMomentumBkgBrush{	get { return pUpMomentumBkgBrush; }	set { pUpMomentumBkgBrush = value; }		}
					[Browsable(false)]
					public string UpMomentumBkgBrushClSerialize	{	get { return Serialize.BrushToString(pUpMomentumBkgBrush); } set { pUpMomentumBkgBrush = Serialize.StringToBrush(value); }}

		private int pUpBkgOpacity = 30;
        [Display(Order = 140, Name = "Up Momentum Opacity", GroupName = "Visuals - Entry Markers", Description = "0 to 100, set to 0 to be transparent, 100 is full color")]
		public int UpBkgOpacity
		{	get { return pUpBkgOpacity; }
			set { pUpBkgOpacity = Math.Max(0,Math.Min(100,value)); }		}

		private Brush pDownMomentumBkgBrush = Brushes.Maroon;
		[XmlIgnore()]
        [Display(Order = 150, Name = "Down momentum background", GroupName = "Visuals - Entry Markers", Description = "")]
		public Brush DownMomentumBkgBrush{	get { return pDownMomentumBkgBrush; }	set { pDownMomentumBkgBrush = value; }		}
					[Browsable(false)]
					public string DownMomentumBkgBrushClSerialize	{	get { return Serialize.BrushToString(pDownMomentumBkgBrush); } set { pDownMomentumBkgBrush = Serialize.StringToBrush(value); }}

		private int pDownBkgOpacity = 30;
        [Display(Order = 160, Name = "Down Momentum Opacity", GroupName = "Visuals - Entry Markers", Description = "0 to 100, set to 0 to be transparent, 100 is full color")]
		public int DownBkgOpacity
		{	get { return pDownBkgOpacity; }
			set { pDownBkgOpacity = Math.Max(0,Math.Min(100,value)); }		}

		#endregion
		//==================================
		#region -- Visuals - Global Entry Markers --
		private bool pGlobalizeMarkers = true;
		[RefreshProperties(RefreshProperties.All)]
        [Display(Order = 10, Name = "Globalize Markers", GroupName = "Visuals - Global Entry Markers", Description = "Send marker long/short dots to all charts?")]
		public bool GlobalizeMarkers
		{
			get { return pGlobalizeMarkers; }
			set { pGlobalizeMarkers = value; }
		}

		private string pLongMarker_Template = "Default";
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadDrawingTemplates))]
        [Display(Order = 20, Name = "Long Marker Template", GroupName = "Visuals - Global Entry Markers", Description = "Drawing template for globalized LONG signal")]
		public string LongMarker_Template
		{
			get { return pLongMarker_Template; }
			set { pLongMarker_Template = value; }
		}
		private string pShortMarker_Template = "Default";
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadDrawingTemplates))]
        [Display(Order = 30, Name = "Short Marker Template", GroupName = "Visuals - Global Entry Markers", Description = "Drawing template for globalized SHORT signal")]
		public string ShortMarker_Template
		{
			get { return pShortMarker_Template; }
			set { pShortMarker_Template = value; }
		}
		#endregion

		#region Audio
		private string pLongWAV = "SOUND OFF";
		[Description("WAV file for long signals")]
		[Category("Audio")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string LongWAV
		{
			get { return pLongWAV; }
			set { pLongWAV = value; }
		}
		private string pShortWAV = "SOUND OFF";
		[Description("WAV file for short signals")]
		[Category("Audio")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string ShortWAV
		{
			get { return pShortWAV; }
			set { pShortWAV = value; }
		}

		#endregion

		#endregion
//==================================================================
    }
    public class CycleForecasterConverter : IndicatorBaseConverter // or StrategyBaseConverter
    {
		#region CycleForecasterConverter
        public override PropertyDescriptorCollection GetProperties(ITypeDescriptorContext context, object component, Attribute[] attrs)
        {
            // we need the indicator instance which actually exists on the grid
            ARC_CycleForecaster indicator = component as ARC_CycleForecaster;

            // base.GetProperties ensures we have all the properties (and associated property grid editors)
            // NinjaTrader internal logic determines for a given indicator
            PropertyDescriptorCollection propertyDescriptorCollection = base.GetPropertiesSupported(context)
                                                                        ? base.GetProperties(context, component, attrs)
                                                                        : TypeDescriptor.GetProperties(component, attrs);

			if (indicator == null || propertyDescriptorCollection == null)
			    return propertyDescriptorCollection;


			// These values are will be shown/hidden (toggled) based on "ShowHideToggle" bool value
			List<PropertyDescriptor> toggles = new List<PropertyDescriptor>();
			try{ toggles.Add(propertyDescriptorCollection["AutoPeakPercentile"]);}        catch(Exception e){indicator.Print(e.ToString());}
			try{ toggles.Add(propertyDescriptorCollection["HighPeakMinForValidMarker"]);} catch(Exception e){indicator.Print(e.ToString());}
			try{ toggles.Add(propertyDescriptorCollection["LowPeakMaxForValidMarker"]);}  catch(Exception e){indicator.Print(e.ToString());}

			if (indicator.pUseAutoPeakCalculation){
			    if(toggles[1] != null) propertyDescriptorCollection.Remove(toggles[1]);
			    if(toggles[2] != null) propertyDescriptorCollection.Remove(toggles[2]);
			}else{
			    if(toggles[0] != null) propertyDescriptorCollection.Remove(toggles[0]);
			}
			toggles.Clear();

			if(indicator.GlobalizeMarkers){
				try{ toggles.Add(propertyDescriptorCollection["BMC"]);} catch(Exception e){indicator.Print(e.ToString());}
				if(toggles[0] != null) propertyDescriptorCollection.Remove(toggles[0]);
				toggles.Clear();
				try{ toggles.Add(propertyDescriptorCollection["SMC"]);} catch(Exception e){indicator.Print(e.ToString());}
				if(toggles[0] != null) propertyDescriptorCollection.Remove(toggles[0]);
			}else{
				try{ toggles.Add(propertyDescriptorCollection["LongMarker_Template"]);}  catch(Exception e){indicator.Print(e.ToString());}
				if(toggles[0] != null) propertyDescriptorCollection.Remove(toggles[0]);
				toggles.Clear();
				try{ toggles.Add(propertyDescriptorCollection["ShortMarker_Template"]);} catch(Exception e){indicator.Print(e.ToString());}
				if(toggles[0] != null) propertyDescriptorCollection.Remove(toggles[0]);
			}

			return propertyDescriptorCollection;
        }

        // Important: This must return true otherwise the type convetor will not be called
        public override bool GetPropertiesSupported(ITypeDescriptorContext context)
        { return true; }
		#endregion
    }

}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_CycleForecaster[] cacheARC_CycleForecaster;
		public ARC.ARC_CycleForecaster ARC_CycleForecaster(bool pUseAutoPeakCalculation, int autoPeakPercentile, string highPeakMinForValidMarker, string lowPeakMaxForValidMarker, ARC_CycleForecaster_AnalysisType analysisType, bool isMultiSignal, int rSIperiod, int fisherPeriod, int cCIperiod, int mACDfast, int mACDslow, int mACDsmooth, int stochDperiod, int stochKperiod, int maxWeeks)
		{
			return ARC_CycleForecaster(Input, pUseAutoPeakCalculation, autoPeakPercentile, highPeakMinForValidMarker, lowPeakMaxForValidMarker, analysisType, isMultiSignal, rSIperiod, fisherPeriod, cCIperiod, mACDfast, mACDslow, mACDsmooth, stochDperiod, stochKperiod, maxWeeks);
		}

		public ARC.ARC_CycleForecaster ARC_CycleForecaster(ISeries<double> input, bool pUseAutoPeakCalculation, int autoPeakPercentile, string highPeakMinForValidMarker, string lowPeakMaxForValidMarker, ARC_CycleForecaster_AnalysisType analysisType, bool isMultiSignal, int rSIperiod, int fisherPeriod, int cCIperiod, int mACDfast, int mACDslow, int mACDsmooth, int stochDperiod, int stochKperiod, int maxWeeks)
		{
			if (cacheARC_CycleForecaster != null)
				for (int idx = 0; idx < cacheARC_CycleForecaster.Length; idx++)
					if (cacheARC_CycleForecaster[idx] != null && cacheARC_CycleForecaster[idx].pUseAutoPeakCalculation == pUseAutoPeakCalculation && cacheARC_CycleForecaster[idx].AutoPeakPercentile == autoPeakPercentile && cacheARC_CycleForecaster[idx].HighPeakMinForValidMarker == highPeakMinForValidMarker && cacheARC_CycleForecaster[idx].LowPeakMaxForValidMarker == lowPeakMaxForValidMarker && cacheARC_CycleForecaster[idx].AnalysisType == analysisType && cacheARC_CycleForecaster[idx].IsMultiSignal == isMultiSignal && cacheARC_CycleForecaster[idx].RSIperiod == rSIperiod && cacheARC_CycleForecaster[idx].FisherPeriod == fisherPeriod && cacheARC_CycleForecaster[idx].CCIperiod == cCIperiod && cacheARC_CycleForecaster[idx].MACDfast == mACDfast && cacheARC_CycleForecaster[idx].MACDslow == mACDslow && cacheARC_CycleForecaster[idx].MACDsmooth == mACDsmooth && cacheARC_CycleForecaster[idx].StochDperiod == stochDperiod && cacheARC_CycleForecaster[idx].StochKperiod == stochKperiod && cacheARC_CycleForecaster[idx].MaxWeeks == maxWeeks && cacheARC_CycleForecaster[idx].EqualsInput(input))
						return cacheARC_CycleForecaster[idx];
			return CacheIndicator<ARC.ARC_CycleForecaster>(new ARC.ARC_CycleForecaster(){ pUseAutoPeakCalculation = pUseAutoPeakCalculation, AutoPeakPercentile = autoPeakPercentile, HighPeakMinForValidMarker = highPeakMinForValidMarker, LowPeakMaxForValidMarker = lowPeakMaxForValidMarker, AnalysisType = analysisType, IsMultiSignal = isMultiSignal, RSIperiod = rSIperiod, FisherPeriod = fisherPeriod, CCIperiod = cCIperiod, MACDfast = mACDfast, MACDslow = mACDslow, MACDsmooth = mACDsmooth, StochDperiod = stochDperiod, StochKperiod = stochKperiod, MaxWeeks = maxWeeks }, input, ref cacheARC_CycleForecaster);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_CycleForecaster ARC_CycleForecaster(bool pUseAutoPeakCalculation, int autoPeakPercentile, string highPeakMinForValidMarker, string lowPeakMaxForValidMarker, ARC_CycleForecaster_AnalysisType analysisType, bool isMultiSignal, int rSIperiod, int fisherPeriod, int cCIperiod, int mACDfast, int mACDslow, int mACDsmooth, int stochDperiod, int stochKperiod, int maxWeeks)
		{
			return indicator.ARC_CycleForecaster(Input, pUseAutoPeakCalculation, autoPeakPercentile, highPeakMinForValidMarker, lowPeakMaxForValidMarker, analysisType, isMultiSignal, rSIperiod, fisherPeriod, cCIperiod, mACDfast, mACDslow, mACDsmooth, stochDperiod, stochKperiod, maxWeeks);
		}

		public Indicators.ARC.ARC_CycleForecaster ARC_CycleForecaster(ISeries<double> input , bool pUseAutoPeakCalculation, int autoPeakPercentile, string highPeakMinForValidMarker, string lowPeakMaxForValidMarker, ARC_CycleForecaster_AnalysisType analysisType, bool isMultiSignal, int rSIperiod, int fisherPeriod, int cCIperiod, int mACDfast, int mACDslow, int mACDsmooth, int stochDperiod, int stochKperiod, int maxWeeks)
		{
			return indicator.ARC_CycleForecaster(input, pUseAutoPeakCalculation, autoPeakPercentile, highPeakMinForValidMarker, lowPeakMaxForValidMarker, analysisType, isMultiSignal, rSIperiod, fisherPeriod, cCIperiod, mACDfast, mACDslow, mACDsmooth, stochDperiod, stochKperiod, maxWeeks);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_CycleForecaster ARC_CycleForecaster(bool pUseAutoPeakCalculation, int autoPeakPercentile, string highPeakMinForValidMarker, string lowPeakMaxForValidMarker, ARC_CycleForecaster_AnalysisType analysisType, bool isMultiSignal, int rSIperiod, int fisherPeriod, int cCIperiod, int mACDfast, int mACDslow, int mACDsmooth, int stochDperiod, int stochKperiod, int maxWeeks)
		{
			return indicator.ARC_CycleForecaster(Input, pUseAutoPeakCalculation, autoPeakPercentile, highPeakMinForValidMarker, lowPeakMaxForValidMarker, analysisType, isMultiSignal, rSIperiod, fisherPeriod, cCIperiod, mACDfast, mACDslow, mACDsmooth, stochDperiod, stochKperiod, maxWeeks);
		}

		public Indicators.ARC.ARC_CycleForecaster ARC_CycleForecaster(ISeries<double> input , bool pUseAutoPeakCalculation, int autoPeakPercentile, string highPeakMinForValidMarker, string lowPeakMaxForValidMarker, ARC_CycleForecaster_AnalysisType analysisType, bool isMultiSignal, int rSIperiod, int fisherPeriod, int cCIperiod, int mACDfast, int mACDslow, int mACDsmooth, int stochDperiod, int stochKperiod, int maxWeeks)
		{
			return indicator.ARC_CycleForecaster(input, pUseAutoPeakCalculation, autoPeakPercentile, highPeakMinForValidMarker, lowPeakMaxForValidMarker, analysisType, isMultiSignal, rSIperiod, fisherPeriod, cCIperiod, mACDfast, mACDslow, mACDsmooth, stochDperiod, stochKperiod, maxWeeks);
		}
	}
}

#endregion
