#define DoLicense
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion
using System.Windows.Controls;

public enum ARC_AT_Trader_InputType { High_Low, Close}
public enum ARC_AT_Trader_ZoneType { ATR, Ticks}
public enum ARC_AT_Trader_BarRequirement { Full, Partial}
public enum ARC_AT_Trader_SignalType {None, ATRmult, Ticks}
public enum ARC_AT_Trader_MarkerType {None, Arrow, Dot, Square, Diamond, Triangle}

namespace NinjaTrader.NinjaScript.Indicators.ARC
{
    [CategoryOrder("Parameters", 10)]
    [CategoryOrder("Custom Visuals", 20)]
    [CategoryOrder("Zone Termination", 30)]
    [CategoryOrder("Break Signals", 40)]
    [CategoryOrder("Trend Signals", 50)]
	[CategoryOrder("Indicator Version", 1100)]
	public class ARC_AT_Trader : Indicator
	{

        public override string DisplayName {	get{return "ARC_AT Trader";}	}

        private const string VERSION = "v1.2 24.Apr.2022";
		//1.11 introduced the Infusionsoft licensing system (transitioning away from the fixed license key system)
		//1.2  Added Breakout TriggerDots, and changed ZoneTermination logic to match that of the BreakAlert logic (a bar closing in the direction of the breakout is now required to terminate the zone)
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

        #region -- zigzag indicator -- 
        private int lastHighIdx = 0;
        private int lastLowIdx = 0;
        private int priorSwingHighIdx = 0;
        private int priorSwingLowIdx = 0;
        private int highCount = 0;
        private int lowCount = 0;
        private int preLastHighIdx = 0;
        private int preLastLowIdx = 0;
        private double zigzagDeviation = 0.0;
        private double currentHigh = 0.0;
        private double currentLow = 0.0;
        private double swingMax = 0.0;
        private double swingMin = 0.0;
        private double preCurrentHigh = 0.0;
        private double preCurrentLow = 0.0;
        private bool addHigh = false;
        private bool updateHigh = false;
        private bool addLow = false;
        private bool updateLow = false;
        private bool intraBarAddHigh = false;
        private bool intraBarUpdateHigh = false;
        private bool intraBarAddLow = false;
        private bool intraBarUpdateLow = false;

        private NinjaTrader.Gui.Tools.SimpleFont labelFont = null;
        private NinjaTrader.Gui.Tools.SimpleFont swingDotFont = null;
        private int pixelOffset1 = 10;               //##HARD CODED##
        private int pixelOffset2 = 10;               //##HARD CODED##
        private Brush upColor = Brushes.LimeGreen;//##HARD CODED##
        private Brush downColor = Brushes.Red;      //##HARD CODED##
        private Brush doubleTopBottomColor = Brushes.Yellow;   //##HARD CODED##
        private string dotString = "n";              //##HARD CODED##

        private Series<double> swingInput;
//        private Series<int> pre_swingHighType;
//        private Series<int> pre_swingLowType;
//        private Series<int> swingHighType;
//        private Series<int> swingLowType;
        private Series<bool> upTrend;
        #endregion

		private string totime(int abar){
			return Times[0].GetValueAt(abar).ToString();
		}
		#region -- TLData class and support methods --
		private string TLToString(TLData tl){
			string r = "Slope: "+tl.Slope.ToString("0.00");
			r = string.Format("{0}\nStart price: ${1}   End price: ${2}",r, tl.StartPrice, tl.EndPrice);
			r = string.Format("{0}\nCurrentBar: {1}  ${2}",r,    totime(tl.CurrentBar), tl.CurrentBarPrice);
			r = string.Format("{0}\nIsBroken: {1}",r,            tl.IsBroken.ToString());
			r = string.Format("{0}\nIsValidated: {1}",r,         tl.IsValidated.ToString());
			r = string.Format("{0}\nValidationABar: {1}",r,      tl.ValidationABar>0? totime(tl.ValidationABar):"");
			r = string.Format("{0}\nAlertedABar: {1}",r,         tl.AlertedABar > 0? totime(tl.AlertedABar):"");
			r = string.Format("{0}\nPriceAtValidation: {1}",r,   tl.PriceAtValidation.ToString());
			r = string.Format("{0}\nTL_DeviationPts: {1}",r,     tl.TL_DeviationPts.ToString());
			r = string.Format("{0}\nMaxABar: {1}",r,             tl.MaxABar.ToString());
			r = string.Format("{0}\nTouchAlertPrice: {1}",r,     tl.TouchAlertPrice.ToString());
			r = string.Format("{0}\nBreakAlertPrice: {1}",r,     tl.BreakAlertPrice.ToString());
			r = string.Format("{0}\nIsTouchAlertEnabled: {1}",r, tl.IsTouchAlertEnabled.ToString());
			r = string.Format("{0}\nIsBreakAlertEnabled: {1}",r, tl.IsBreakAlertEnabled.ToString());
			r = string.Format("{0}\nBreakAlertFired: {1}",r,     tl.BreakAlertFired.ToString());
			r = string.Format("{0}\nIsZoneTerminated: {1}",r,    tl.IsZoneTerminated.ToString());
			r = string.Format("{0}\n  CurrentPriceAtTermination: {1}",r,    tl.CurrentPriceAtTermination.ToString());
			r = string.Format("{0}\n  ZoneTerminationPrice: {1}",r,     tl.ZoneTerminationPrice.ToString());
			r = string.Format("{0}\n  ZoneTerminatedABar: {1}  {2}",r,  tl.ZoneTerminatedABar.ToString(), tl.ZoneTerminatedABar >0 ? totime(tl.ZoneTerminatedABar):"");
			r = string.Format("{0}\nIsLineEnabled: {1}",r,       tl.IsLineEnabled.ToString());
			r = string.Format("{0}\nTouchAlertABars.Count: {1}",r, tl.TouchAlertABars.Count.ToString());
			try{
				foreach(var x in tl.TouchAlertABars)
					r = string.Format("{0}\n   : {1}",r, x);
			}catch(Exception e){Print(e.ToString());}
			r = string.Format("{0}\nAlertStatus: {1}",r, tl.AlertStatus);
			return r;
		}
		private SortedDictionary<int,double> HighSwings          = new SortedDictionary<int,double>();
		private SortedDictionary<int,double> LowSwings           = new SortedDictionary<int,double>();
		private SortedDictionary<Tuple<int,int>, TLData> UpTLs   = new SortedDictionary<Tuple<int,int>, TLData>();//the key is a Point(StartABar, EndABar)
		private SortedDictionary<Tuple<int,int>, TLData> DownTLs = new SortedDictionary<Tuple<int,int>, TLData>();//the key is a Point(StartABar, EndABar)
		private class TLData{
			#region -- TLData --
			public double Slope      = 0;
			public double StartPrice = 0;
			public double EndPrice   = 0;
			public int    CurrentBar = 0;
			public double CurrentBarPrice     = 0;
			public bool   IsBroken            = false;//failed rising trendlines are those who were broken when price bars closed below the trendline value
			public bool   IsValidated         = false;//if 3 or more points are required, then the line is not validated until all points are checked
			public int    ValidationABar      = -1;
			public int    AlertedABar         = -1;
			public double PriceAtValidation   = 0;
			public double TL_DeviationPts     = 0;
			public int    MaxABar             = -1;
			public double TouchDistancePts    = 0;
			public double BreakDistancePts    = 0;
			public double TerminationDistancePts = 0;
			public double TouchAlertPrice     = double.NaN;//if the market exceeds this price, the signal is to be played
			public double BreakAlertPrice     = double.NaN;//if the market exceeds this price, the signal is to be played
			public double ZoneTerminationPrice= double.NaN;
			public bool   IsTouchAlertEnabled = false;
			public bool   IsBreakAlertEnabled = false;
			public double TriggerDotPrice = double.NaN;
			public bool   BreakAlertFired     = false;
			public bool   IsZoneTerminated    = false;
			public int    ZoneTerminatedABar   = -1;
			public double CurrentPriceAtTermination = double.NaN;
			public bool   IsLineEnabled       = true;//enabled means the zone is not terminated, and it means that a BreakAlert has not been fired
			public List<int> TouchAlertABars  = new List<int>();
			public char   AlertStatus = ' ';//'T' for play touch alert now, 'B' for play break alert not, ' ' for no alert
			public TLData(double startPrice, double endPrice, Tuple<int,int> abars, int CurrentBar){//'abars' is of the form Point(StartABar, EndABar)
				StartPrice = startPrice;
				EndPrice   = endPrice;
				AlertedABar = CurrentBar;
				double run = abars.Item2 - abars.Item1;
				if(run < 0){
					StartPrice = endPrice;
					EndPrice   = startPrice;
				}else{
					StartPrice = startPrice;
					EndPrice   = endPrice;
				}
				Slope = (EndPrice - StartPrice)/Math.Abs(run);
				CalcPrice(CurrentBar, abars);
			}
			public void CalcPrice(int cabar, Tuple<int,int> abars){
				//if(this.IsZoneTerminated) return;
				this.CurrentBar = cabar;
				this.CurrentBarPrice = this.Slope * (cabar - abars.Item2) + this.EndPrice;
			}
			public string CalcIsLineEnabled(int abar){
				//be sure to have called this.CalcBreakAlert and CalcZoneTermination BEFORE calling this method
				string res = "";//string.Format("Cur$: {0}  H: {1}  L:{2}  Break$: {3}", CurrentBarPrice, H, L, BreakDistancePts);
				if(abar > this.MaxABar && MaxABar>0) {
					IsZoneTerminated = true; 
					ZoneTerminatedABar = abar;
					CurrentPriceAtTermination = this.CurrentBarPrice;
					IsLineEnabled = false;
				}else
					IsLineEnabled = !(this.BreakAlertFired && this.IsZoneTerminated);//disable once BreakAlertFired and Zone is terminated
				return res;
			}
			#endregion
		}
//			private void CheckEnableTouchAlert(TLData tl, double O, double H, double L, double C, double CurrentBarPrice){
//				if(tl.Slope < 0){
//					bool IsBarInZone = H >= CurrentBarPrice - tl.TouchDistancePts && L<= CurrentBarPrice + tl.TouchDistancePts;
//					bool IsBarDownClosing = C < O;
//					if(!tl.IsTouchAlertEnabled && H < CurrentBarPrice - tl.TouchDistancePts) tl.IsTouchAlertEnabled = true;
//					if(tl.IsTouchAlertEnabled && IsBarInZone && IsBarDownClosing){//downward sloping trendline...touch alert if the bar is in the zone, and bar closes down.
//						tl.TouchAlertPrice     = CurrentBarPrice + tl.TouchDistancePts;//simple, the alert price is top of the zone
//						tl.IsTouchAlertEnabled = false;//price must move away from trendline for a reset
//					}
//				}else{
//					bool IsBarInZone = H >= CurrentBarPrice - tl.TouchDistancePts && L<= CurrentBarPrice + tl.TouchDistancePts;
//					bool IsBarUpClosing = C > O;
//					if(!tl.IsTouchAlertEnabled && L > CurrentBarPrice + tl.TouchDistancePts) tl.IsTouchAlertEnabled = true;
//					if(tl.IsTouchAlertEnabled && IsBarInZone && IsBarUpClosing){//upward sloping trendline...touch alert if the bar is in the zone, and bar closes up
//						tl.TouchAlertPrice     = CurrentBarPrice - tl.TouchDistancePts;
//						tl.IsTouchAlertEnabled = false;//price must move away from trendline for a reset
//						//res = string.Format("{0}  TouchAlertPrice: {1}",res,TouchAlertPrice.ToString());
//					}
//				}
//			}
			private string CalcTouchAlert(TLData tl, double O, double H, double L, double C, int CurrentBar, int MaxTouchAlerts){
				//be sure to have called this.CalcPrice prior to calling this method
				if(!tl.IsValidated)     return "Not a validated line";
				if(tl.IsZoneTerminated) return "Line is not printing the zone, no touch alerts possible";
				if(!tl.IsLineEnabled)   return "Line is not enabled";
				if(tl.TouchAlertABars.Count>= MaxTouchAlerts) return "Max trend alerts achieved on this bar";
				if(tl.TouchDistancePts < 0) return "Touch alerts not enabled";
				string res = "";//string.Format("Cur$: {0}  H: {1}  L:{2}  Break$: {3}", CurrentBarPrice, H, L, BreakDistancePts);
				if(tl.Slope < 0){
					bool IsBarInZone = H >= tl.CurrentBarPrice - tl.TouchDistancePts && L<= tl.CurrentBarPrice + tl.TouchDistancePts;
					bool IsBarDownClosing = C < O;
					if(!tl.IsTouchAlertEnabled && H < tl.CurrentBarPrice - tl.TouchDistancePts) tl.IsTouchAlertEnabled = true;
					if(tl.IsTouchAlertEnabled && IsBarInZone && IsBarDownClosing){//downward sloping trendline...touch alert if the bar is in the zone, and bar closes down.
						tl.TouchAlertPrice     = tl.CurrentBarPrice + tl.TouchDistancePts;//simple, the alert price is top of the zone
						tl.IsTouchAlertEnabled = false;//price must move away from trendline for a reset
					}
					if(!double.IsNaN(tl.TouchAlertPrice) && L <= tl.TouchAlertPrice) {tl.AlertStatus = 'T'; tl.AlertedABar = CurrentBar; tl.TouchAlertABars.Add(tl.AlertedABar);}
				}else{
					bool IsBarInZone = H >= tl.CurrentBarPrice - tl.TouchDistancePts && L<= tl.CurrentBarPrice + tl.TouchDistancePts;
					bool IsBarUpClosing = C > O;
					if(!tl.IsTouchAlertEnabled && L > tl.CurrentBarPrice + tl.TouchDistancePts) tl.IsTouchAlertEnabled = true;
					if(tl.IsTouchAlertEnabled && IsBarInZone && IsBarUpClosing){//upward sloping trendline...touch alert if the bar is in the zone, and bar closes up
						tl.TouchAlertPrice     = tl.CurrentBarPrice - tl.TouchDistancePts;
						tl.IsTouchAlertEnabled = false;//price must move away from trendline for a reset
						//res = string.Format("{0}  TouchAlertPrice: {1}",res,TouchAlertPrice.ToString());
					}
					if(!double.IsNaN(tl.TouchAlertPrice) && H >= tl.TouchAlertPrice) {tl.AlertStatus = 'T'; tl.AlertedABar = CurrentBar; tl.TouchAlertABars.Add(tl.AlertedABar);}//only valid touch when price moves upward again, exceeding the TouchAlertPrice
				}
				return res;
			}
//			private void CheckEnableBreakAlert(TLData tl, double H, double L, double CurrentBarPrice){
//				if(tl.Slope < 0){
//					if(!tl.IsBreakAlertEnabled && H < CurrentBarPrice - tl.BreakDistancePts){
//						tl.IsBreakAlertEnabled = true;
//						tl.BreakAlertPrice     = CurrentBarPrice + tl.BreakDistancePts;
////						if(PrintDetail) res = string.Format("{0}  BreakIsRESET at High: {1}",res,H.ToString());
//					}
//				}else{
//					if(!tl.IsBreakAlertEnabled && L > CurrentBarPrice + tl.BreakDistancePts) {
//						tl.IsBreakAlertEnabled = true;
//						tl.BreakAlertPrice     = CurrentBarPrice - tl.BreakDistancePts;
////						if(PrintDetail) res = string.Format("{0}  BreakIsRESET at Low: {1}",res,L.ToString());
//					}
//				}
//			}
			private string CalcBreakAlert(TLData tl, double O, double H, double L, double C, char BreakAlertType, int CurrentBar, bool PrintDetail){
				//be sure to have called this.CalcPrice prior to calling this method
				if(!tl.IsValidated)   return "Not a validated line";
				if(!tl.IsLineEnabled) return "Line is not enabled, no alerts possible";
				if(tl.BreakAlertFired) return "Break has already occurred";
				if(tl.BreakDistancePts < 0) {tl.BreakAlertFired = true; return "Break alerts not enabled";}//IsBreakAlert fired is true if no break alerts are permitted.  This is used in CalcIsLineEnabled
				string res = "";//string.Format("Cur$: {0}  H: {1}  L:{2}  Break$: {3}", tl.CurrentBarPrice, H, L, tl.BreakDistancePts);
				if(tl.Slope < 0){
					if(!tl.IsBreakAlertEnabled && H < tl.CurrentBarPrice - tl.BreakDistancePts){
						tl.IsBreakAlertEnabled = true;
						tl.BreakAlertPrice     = tl.CurrentBarPrice + tl.BreakDistancePts;
						if(PrintDetail) res = string.Format("{0}  BreakIsRESET at High: {1}",res,H.ToString());
					}
					if(tl.IsBreakAlertEnabled){
						tl.BreakAlertPrice = tl.CurrentBarPrice + tl.BreakDistancePts;
						if(PrintDetail) res = string.Format("{0}  BreakAlertPrice: {1}",res, tl.BreakAlertPrice.ToString());
						bool IsBarExitedZone = BreakAlertType == 'F' ? L > tl.BreakAlertPrice : H > tl.BreakAlertPrice;
							//'F' means the full bar must be above the BreakValidation price.  Otherwise, just the high must be above that BreakValidation price
						bool IsBarUpClosing = C > O;
						if(PrintDetail) res = string.Format("{0}  BarExitedZone? {1}  Up-closing bar? {2}", res, IsBarExitedZone.ToString(), IsBarUpClosing.ToString());
						if(IsBarExitedZone && IsBarUpClosing){//downward sloping trendline...break alert if the market low is above the trendline.
							tl.IsBreakAlertEnabled = false;//price must move away from trendline for a reset
							tl.AlertStatus = 'B';
							tl.AlertedABar = CurrentBar;
							tl.BreakAlertFired = true;
							if(PrintDetail) res = string.Format("{0}  Break occurred!",res);
						}
//						else
//							tl.BreakAlertPrice = tl.CurrentBarPrice + tl.BreakDistancePts;
					}
				}else{//rising trendline, supportive trendline
					if(!tl.IsBreakAlertEnabled && L > tl.CurrentBarPrice + tl.BreakDistancePts) {
						tl.IsBreakAlertEnabled = true;
						tl.BreakAlertPrice     = tl.CurrentBarPrice - tl.BreakDistancePts;
						if(PrintDetail) res = string.Format("{0}  BreakIsRESET at Low: {1}",res,L.ToString());
					}
					if(tl.IsBreakAlertEnabled){
						tl.BreakAlertPrice = tl.CurrentBarPrice - tl.BreakDistancePts;
						if(PrintDetail) res = string.Format("{0}  BreakAlertPrice: {1}",res, tl.BreakAlertPrice.ToString());
						bool IsBarExitedZone = BreakAlertType == 'F' ? H < tl.BreakAlertPrice : L < tl.BreakAlertPrice;
							//'F' means the full bar must be below the BreakValidation price.  Otherwise, just the high must be above that BreakValidation price
						bool IsBarDownClosing = C < O;
						if(PrintDetail) res = string.Format("{0}  BarExitedZone? {1}  Down-closing bar? {2}", res, IsBarExitedZone.ToString(), IsBarDownClosing.ToString());
						if(IsBarExitedZone && IsBarDownClosing){//upward sloping trendline...break alert if the market high is below the trendline.
							tl.IsBreakAlertEnabled = false;//price must move away from trendline for a reset
							tl.AlertStatus = 'B';
							tl.AlertedABar = CurrentBar;
							tl.BreakAlertFired = true;
							if(PrintDetail) res = string.Format("{0}  Break occurred!",res);
						}
//						else
//							tl.BreakAlertPrice     = tl.CurrentBarPrice - tl.BreakDistancePts;
					}
				}
				return res;
			}
			private string CalcZoneTermination(TLData tl, double O, double H, double L, double C, char ZoneTerminationType, int CurrentBar, bool PrintDetail){
				//be sure to have called this.CalcPrice prior to calling this method
				if(!tl.IsValidated)     return "Not a validated line";
				if(tl.IsZoneTerminated) return "Zone is terminated";
				if(!tl.IsLineEnabled)   return "Line is not enabled, no alerts possible";
				string res = PrintDetail ? string.Format("Cur$: {0}  H: {1}  L:{2}  Break$: {3}", tl.CurrentBarPrice, H, L, tl.TerminationDistancePts) : "";
				if(tl.Slope < 0){
					tl.ZoneTerminationPrice = tl.CurrentBarPrice + tl.TerminationDistancePts;
					if(PrintDetail) res = string.Format("{0}\nZoneTerminationPrice: {1}  dist {2} ",res, tl.ZoneTerminationPrice, tl.TerminationDistancePts);
					bool IsBarExitedZone = ZoneTerminationType == 'F' ? L > tl.ZoneTerminationPrice : H > tl.ZoneTerminationPrice;
						//'F' means the full bar must be above the ZoneTerminationPrice.  Otherwise, just the high must be above that TerminationDistancePts price
					bool IsBarUpClosing = C > O;
					if(IsBarExitedZone && IsBarUpClosing){
						tl.IsZoneTerminated = true;
						tl.ZoneTerminatedABar = CurrentBar;// the zone graphic will stop printing on this bar
						tl.CurrentPriceAtTermination = tl.CurrentBarPrice;
						if(PrintDetail) res = string.Format("{0}\n  ZoneTerminated, Low: {1}",res,L.ToString());
					}
				}else{
					tl.ZoneTerminationPrice = tl.CurrentBarPrice - tl.TerminationDistancePts;
					if(PrintDetail) res = string.Format("{0}\nZoneTerminationPrice: {1}  dist {2} ",res, tl.ZoneTerminationPrice, tl.TerminationDistancePts);
					bool IsBarExitedZone = ZoneTerminationType == 'F' ? H < tl.ZoneTerminationPrice : L < tl.ZoneTerminationPrice;
						//'F' means the full bar must be above the ZoneTerminationPrice.  Otherwise, just the high must be above that TerminationDistancePts price
					bool IsBarDownClosing = C < O;
					if(IsBarExitedZone && IsBarDownClosing) {
						tl.IsZoneTerminated = true;
						tl.ZoneTerminatedABar = CurrentBar;// the zone graphic will stop printing on this bar
						tl.CurrentPriceAtTermination = tl.CurrentBarPrice;
						if(PrintDetail) res = string.Format("{0}\n  ZoneTermination, Low: {1}",res,L.ToString());
					}
				}
				return res;
			}
		#endregion

		private int    COBCoffset = 0;
		private int    pMaxAgeInBars = 99999999;
		private double TouchDistancePts = -1;
		private double BreakDistancePts = -1;
		private double TerminationDistancePts = -1;
		private char   TerminationBarRequirementChar = 'F';//Full or Partial
		private char   BreakBarRequirementChar = 'F';//Full or Partial

		static bool IsDebug        = false;
		private bool ValidLicense  = false;
		private bool IsExpired     = true;

		private bool LicenseChecked = false;
		private string UserId       = string.Empty;
		private string MachineId    = string.Empty;
		string ModuleName = "ATTrader";

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			public static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			public static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "19320","25900", "27405"};//27405 is Annual Membership and PropTrader Mastermind 21868
		#region ARCLicense
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
				if (System.IO.Directory.Exists(folder))
				{
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
					search = "nscid_*.txt";
					filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
					if(filCustom!=null){
						foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
							var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
							if(elements.Length>1)
								ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
						}
					}
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private string GetMD5(string input){
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                // Convert the byte array to a hexadecimal string
                StringBuilder sb = new StringBuilder();
                foreach (byte b in hashBytes){
                    sb.Append(b.ToString("x2")); // "x2" formats each byte as a two-character hexadecimal
                }
				return sb.ToString().ToUpper();
            }
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			NewCustId = GetCustID();
			if(System.IO.File.Exists(System.IO.Path.Combine(ARCConfigDirectory,"licensesystem1.txt") )){
				#region -- machine id based on MAC Address and CustId --
				if(NewCustId<0) {
					Log("ARC_LicenseActivator needs to be run on this platform", LogLevel.Information);
					return false;
				}
				foreach (System.Net.NetworkInformation.NetworkInterface nic in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces())
				{
					if (nic.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback && nic.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up)
						MachineId = string.Format("{0}*{1}",nic.GetPhysicalAddress(), NewCustId);
				}
				MachineId = GetMD5(MachineId);
				Log("Your Licensesystem1 ARC Machine Id is: "+MachineId,LogLevel.Information);
				#endregion
			}else{
				MachineId = NinjaTrader.Cbi.License.MachineId;
			}
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");

//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
				bool IsConnectionIssue = UserId.CompareTo("253729")==0 || MachineId.CompareTo("0DE7B460EE7C494980DC065DDE946572")==0;//Chris Zolton
				if(IsConnectionIssue) return true;
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}
		#endregion


		private int FirstABar_TrendContinuingSignals = 0;
		private int FirstABar_BreakSignals = 0;
		protected override void OnStateChange()
		{
			#region -- OnStateChange --
			if (State == State.SetDefaults)
			{
				Description						= @"";
				Name							= "ARC_AT Trader";
				Calculate						= Calculate.OnBarClose;
				IsOverlay						= true;
				DisplayInDataBox				= true;
				DrawOnPricePanel				= true;
				DrawHorizontalGridLines			= true;
				DrawVerticalGridLines			= true;
				PaintPriceMarkers				= true;
				ScaleJustification				= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive		= false;
				pSwingStrength					= 4;
				pMinTouchPoints					= 2;
				pZoneType = ARC_AT_Trader_ZoneType.ATR;
				pTLTouchPointsTicks		= 5;
				pTLTouchPointsATRMult	= 0.5;
				pTouchZoneOpacity		= 20f;
//				pRisingLineColor	= Brushes.Lime;
//				pFallingLineColor	= Brushes.DeepPink;
				pShowUpwardLines       = true;
				pShowDownwardLines     = true;
				pShowFreshLines        = true;
				pShowBrokenLines       = false;
				pShowHistoricalSignals = false;
				pBuyMarkerBrush        = Brushes.Lime;
				pSellMarkerBrush       = Brushes.Magenta;
				pTrendContinuingMarkerType	= ARC_AT_Trader_MarkerType.Arrow;
				pBreakMarkerType			= ARC_AT_Trader_MarkerType.Arrow;
				AddPlot(new Stroke(Brushes.DarkGreen, 1), PlotStyle.Line, "RisingLines");
				AddPlot(new Stroke(Brushes.DarkRed, 1),   PlotStyle.Line, "FallingLines");
				AddPlot(new Stroke(Brushes.Transparent, 1),   PlotStyle.Dot, "TriggerDotAbovePrice");
				AddPlot(new Stroke(Brushes.Transparent, 1),   PlotStyle.Dot, "TriggerDotBelowPrice");

				pBreakTriggerDotBrush = Brushes.Orange;
				pBreakSignalTriggerWidth = 3f;
				pShowBreakSignalTriggerDot = true;

                pSwingLegWidth  = 2;
                pShowZigzagLegs = false;
				pMultiplierMD   = 0;
				pTrendContinuingBarsLookback = 2000;
				pBreakBarsLookback = 2000;
				pTrendContinuingSignalType = ARC_AT_Trader_SignalType.None;
				pMaxTrendContinuingSignals = 1;
				pBreakSignalType       = ARC_AT_Trader_SignalType.None;
				pZoneTerminationType   = ARC_AT_Trader_ZoneType.ATR;
				pRisingZZlegBrush  = Brushes.Blue;
				pFallingZZlegBrush = Brushes.Red;
				pZoneTerminationDistanceATRMult = 1;
				pZoneTerminationDistanceTicks   = 5;
				pTrendContinuingDistanceATRMult = 1;
				pTrendContinuingDistanceTicks   = 5;
				pBreakDistanceATRMult	= 1;
				pBreakDistanceTicks		= 15;
				pTrendContinuingBuyWAV  = "SOUND OFF";
				pTrendContinuingSellWAV = "SOUND OFF";
				pBreakBuyWAV			= "SOUND OFF";
				pBreakSellWAV			= "SOUND OFF";
				pBreakBarRequirement		= ARC_AT_Trader_BarRequirement.Partial;
				pTerminationBarRequirement	= ARC_AT_Trader_BarRequirement.Partial;
			}
			else if (State == State.Configure)
			{
				if(this.Calculate!=Calculate.OnBarClose) COBCoffset=1; else COBCoffset=0;
				uID = Guid.NewGuid().ToString().Replace("-",string.Empty);
				IsDebug = System.IO.File.Exists("c:\\222222222222.txt") && (
					NinjaTrader.Cbi.License.MachineId=="CB15E08BE30BC80628CFF6010471FA2A" || NinjaTrader.Cbi.License.MachineId=="766C8CD2AD83CA787BCA6A2A76B2303B");
				#region DoLicense call
#if DoLicense
//				NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Getting "+ModuleName+" license info",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center);
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				IsVisible = true;
//				RemoveDrawObject("lictext");
#endif
				#endregion
			}
			else if (State == State.DataLoaded){

				if(ChartPanel!=null && IsDebug){
					ChartPanel.MouseMove  += OnMouseMove;
					ChartPanel.MouseUp    += OnMouseUp;
				}
				#region -- Add Custom Toolbar --
				if (!isToolBarButtonAdded && ChartControl != null)
				{
					Dispatcher.BeginInvoke(new Action(() =>
					{
						ChartControl.AllowDrop = false;
						chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
						if (chartWindow == null) return;

						foreach (DependencyObject item in chartWindow.MainMenu) if (System.Windows.Automation.AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

						if (!isToolBarButtonAdded)
						{
							indytoolbar = new System.Windows.Controls.Grid { Visibility = Visibility.Collapsed };

							addToolBar();

							chartWindow.MainMenu.Add(indytoolbar);
							chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

							foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
							System.Windows.Automation.AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
						}
					}));
				}
				#endregion

				BreakBarRequirementChar = pBreakBarRequirement.ToString()[0];
				TerminationBarRequirementChar = pTerminationBarRequirement.ToString()[0];

				FirstABar_TrendContinuingSignals = BarsArray[0].Count-pTrendContinuingBarsLookback;
				FirstABar_BreakSignals = BarsArray[0].Count-pBreakBarsLookback;
				deviationPts = pTLTouchPointsTicks * TickSize;
				atr = new Series<double>(this);
if(IsDebug) ClearOutputWindow();

				swingInput = new Series<double>(this);
				upTrend    = new Series<bool>(this);

				TouchDistancePts = -1;
				BreakDistancePts = -1;
				if(pTrendContinuingSignalType == ARC_AT_Trader_SignalType.Ticks)
					TouchDistancePts = TickSize * this.pTrendContinuingDistanceTicks/2;
				if(pBreakSignalType == ARC_AT_Trader_SignalType.Ticks)
					BreakDistancePts = TickSize * this.pBreakDistanceTicks/2;
				if(pZoneTerminationType == ARC_AT_Trader_ZoneType.Ticks)
					TerminationDistancePts = TickSize * this.pZoneTerminationDistanceTicks/2;
			}else if(State == State.Terminated){
				if(ChartPanel!=null && IsDebug){
					ChartPanel.MouseMove -= OnMouseMove;
					ChartPanel.MouseUp -= OnMouseUp;
				}
				if (chartWindow != null && indytoolbar != null)
				{
					if (ChartControl.Dispatcher.CheckAccess()) {
						chartWindow.MainMenu.Remove(indytoolbar);
						indytoolbar = null;

						chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
						chartWindow = null;
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							chartWindow.MainMenu.Remove(indytoolbar);
							indytoolbar = null;

							chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
							chartWindow = null;
						}));
					}
				}
			}
			#endregion
		}

		private double deviationPts = 0;
		private int start_barsago   = 0;
		private int end_barsago     = 0;
		private List<Tuple<int,double>> SwingHighABars = new List<Tuple<int,double>>(){new Tuple<int,double>(0,0)};
		private List<Tuple<int,double>> SwingLowABars = new List<Tuple<int,double>>(){new Tuple<int,double>(0,0)};
		Series<double> atr;
		int pATRperiod = 14;
		bool z = false;

		#region -- Toolbar variables --
		private string toolbarname = "ARC_ATTrader_TB", uID;
		private bool isToolBarButtonAdded = false;
		private Chart chartWindow;
		private Grid indytoolbar;

		private Menu MenuControlContainer;
		private MenuItem MenuControl, miUpLinesOnOff, miDownLinesOnOff, miBrokenOnOff, miFreshOnOff, miZigZagOnOff;
		private Label   lbl_SwingStrength, lbl_TouchZoneOpacity;
		private TextBox nud_SwingStrength, nud_TouchZoneOpacity;
		private MenuItem miTrendContinuingSignalType;
		private Label   lbl_TrendContinuingDistanceATRMult, lbl_TrendContinuingDistanceTicks;
		private TextBox nud_TrendContinuingDistanceATRMult, nud_TrendContinuingDistanceTicks;
		private MenuItem miZoneTerminationType;
		private Label   lbl_ZoneTerminationDistanceATRMult, lbl_ZoneTerminationDistanceTicks;
		private TextBox nud_ZoneTerminationDistanceATRMult, nud_ZoneTerminationDistanceTicks;
		private MenuItem miBreakSignalType;
		private Label   lbl_BreakDistanceATRMult, lbl_BreakDistanceTicks;
		private TextBox nud_BreakDistanceATRMult, nud_BreakDistanceTicks;
		private MenuItem miShowBreakSignalTriggerDot;
		private Label   lbl_MinTouchPoints;
		private TextBox nud_MinTouchPoints;
		private MenuItem miZoneType;
		private Label   lbl_TLTouchPointsATRMult, lbl_TLTouchPointsTicks;
		private TextBox nud_TLTouchPointsATRMult, nud_TLTouchPointsTicks;
		private MenuItem miHistoricalSignalsOnOff;

		private MenuItem miRecalculate1;
		#endregion

	#region -- addToolBar --
		private void addToolBar()
		{
			int rHeight = 26;
			MenuControlContainer = new Menu { Background = Brushes.Orange, VerticalAlignment = VerticalAlignment.Center };
			MenuControl = new MenuItem { BorderThickness = new Thickness(2), BorderBrush = Brushes.Pink, Header = pButtonText, Foreground = Brushes.Pink, Background = Brushes.Black, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			MenuControlContainer.Items.Add(MenuControl);

			miUpLinesOnOff   = new MenuItem { Header = "Up Lines "+(pShowUpwardLines ? "ON":"OFF"),         Name = "UpLinesOnOff"+uID,       Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pShowUpwardLines,   StaysOpenOnClick = true };
			miDownLinesOnOff = new MenuItem { Header = "Down Lines "+(pShowDownwardLines ? "ON":"OFF"),     Name = "DownLinesOnOff"+uID,     Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pShowDownwardLines, StaysOpenOnClick = true };
			miBrokenOnOff    = new MenuItem { Header = "Broken Lines "+(pShowBrokenLines ? "ON":"OFF"),     Name = "BrokenLinesOnOff"+uID,   Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pShowBrokenLines,   StaysOpenOnClick = true };
			miFreshOnOff     = new MenuItem { Header = "Fresh Lines "+(pShowFreshLines ? "ON":"OFF"),       Name = "FreshLinesOnOff"+uID,    Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pShowFreshLines, StaysOpenOnClick = true };
			miZigZagOnOff    = new MenuItem { Header = "ZigZag "+(pShowZigzagLegs ? "ON":"OFF"),            Name = "ZigZagOnOff"+uID,        Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pShowZigzagLegs,    StaysOpenOnClick = true };

			#region -- Up lines On/Off switch --
			miUpLinesOnOff.Click += delegate (object o, RoutedEventArgs e)
			{
				this.pShowUpwardLines = !this.pShowUpwardLines;
				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						//InformUserAboutRecalculation();
						miUpLinesOnOff.IsChecked = pShowUpwardLines;
						miUpLinesOnOff.Header = "Up Lines "+(pShowUpwardLines ? "ON":"OFF");
						ForceRefresh();
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							//InformUserAboutRecalculation();
							miUpLinesOnOff.IsChecked = pShowUpwardLines;
							miUpLinesOnOff.Header = "Up Lines "+(pShowUpwardLines ? "ON":"OFF");
							ForceRefresh();
						}));
					}
				}
			};
			MenuControl.Items.Add(miUpLinesOnOff);
			#endregion

			#region -- Down lines On/Off switch --
			miDownLinesOnOff.Click += delegate (object o, RoutedEventArgs e)
			{
				this.pShowDownwardLines = !this.pShowDownwardLines;
				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						//InformUserAboutRecalculation();
						miDownLinesOnOff.IsChecked = pShowDownwardLines;
						miDownLinesOnOff.Header = "Down Lines "+(pShowDownwardLines ? "ON":"OFF");
						ForceRefresh();
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							//InformUserAboutRecalculation();
							miDownLinesOnOff.IsChecked = pShowDownwardLines;
							miDownLinesOnOff.Header = "Down Lines "+(pShowDownwardLines ? "ON":"OFF");
							ForceRefresh();
						}));
					}
				}
			};
			MenuControl.Items.Add(miDownLinesOnOff);
			#endregion

			#region -- Broken lines On/Off switch --
			miBrokenOnOff.Click += delegate (object o, RoutedEventArgs e)
			{
				this.pShowBrokenLines = !this.pShowBrokenLines;
				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						//InformUserAboutRecalculation();
						miBrokenOnOff.IsChecked = pShowBrokenLines;
						miBrokenOnOff.Header = "Broken Lines "+(pShowBrokenLines ? "ON":"OFF");
						ForceRefresh();
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							//InformUserAboutRecalculation();
							miBrokenOnOff.IsChecked = pShowBrokenLines;
							miBrokenOnOff.Header = "Broken Lines "+(pShowBrokenLines ? "ON":"OFF");
							ForceRefresh();
						}));
					}
				}
			};
			MenuControl.Items.Add(miBrokenOnOff);
			#endregion

			#region -- Fresh lines On/Off switch --
			miFreshOnOff.Click += delegate (object o, RoutedEventArgs e)
			{
				this.pShowFreshLines = !this.pShowFreshLines;
				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						//InformUserAboutRecalculation();
						miFreshOnOff.IsChecked = pShowFreshLines;
						miFreshOnOff.Header = "Fresh Lines "+(pShowFreshLines ? "ON":"OFF");
						ForceRefresh();
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							//InformUserAboutRecalculation();
							miFreshOnOff.IsChecked = pShowFreshLines;
							miFreshOnOff.Header = "Fresh Lines "+(pShowFreshLines ? "ON":"OFF");
							ForceRefresh();
						}));
					}
				}
			};
			MenuControl.Items.Add(miFreshOnOff);
			#endregion

			#region -- Zigzag lines On/Off switch --
			miZigZagOnOff.Click += delegate (object o, RoutedEventArgs e)
			{
				this.pShowZigzagLegs = !this.pShowZigzagLegs;
				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						//InformUserAboutRecalculation();
						miZigZagOnOff.IsChecked = pShowZigzagLegs;
						miZigZagOnOff.Header = "ZigZag "+(pShowZigzagLegs ? "ON":"OFF");
						ForceRefresh();
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							//InformUserAboutRecalculation();
							miZigZagOnOff.IsChecked = pShowZigzagLegs;
							miZigZagOnOff.Header = "ZigZag "+(pShowZigzagLegs ? "ON":"OFF");
							ForceRefresh();
						}));
					}
				}
			};
			MenuControl.Items.Add(miZigZagOnOff);
			#endregion

			MenuControl.Items.Add(new Separator());

			int row = 0;
			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width  = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width  = new GridLength(40) });
			grid.RowDefinitions.Add(   new RowDefinition    { Height = new GridLength(rHeight) });

			#region -- MinTouchPoints numerical box --
            lbl_MinTouchPoints = new Label() { Name = "lbl_MinTouchPoints"+uID,  Content = "Min Swing Points ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_MinTouchPoints.SetValue(Grid.ColumnProperty, 0);
            lbl_MinTouchPoints.SetValue(Grid.RowProperty, row);

			nud_MinTouchPoints = new TextBox() { Name = "nud_MinTouchPoints"+uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            nud_MinTouchPoints.Text = pMinTouchPoints.ToString();
			nud_MinTouchPoints.KeyDown += menuTxtbox_KeyDownInteger;
            nud_MinTouchPoints.TextChanged += delegate(object o, TextChangedEventArgs e){
				InformUserAboutRecalculation();
				int max = 4;
				int min = 2;
				int x = nud_MinTouchPoints.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_MinTouchPoints.Text);
				if(x>max) {
					nud_MinTouchPoints.Text = max.ToString();
					x=max;
				}
				if(x<min) {
					nud_MinTouchPoints.Text = min.ToString();
					x=min;
				}
				this.pMinTouchPoints = x;
				ForceRefresh();
			};
			nud_MinTouchPoints.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				int max = 4;
				int min = 2;
				int x = nud_MinTouchPoints.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_MinTouchPoints.Text);
				if(e.Delta<0){
					x = x - 1;
					x = Math.Max(min, Math.Min(max,x));
					pMinTouchPoints = x;
					nud_MinTouchPoints.Text = x.ToString();
				}else if(e.Delta>0){
					x = x + 1;
					x = Math.Max(min, Math.Min(max,x));
					pMinTouchPoints = x;
					nud_MinTouchPoints.Text = x.ToString();
				}
				ForceRefresh();
			};
			nud_MinTouchPoints.SetValue(Grid.ColumnProperty, 1);
            nud_MinTouchPoints.SetValue(Grid.RowProperty, row);
            grid.Children.Add(lbl_MinTouchPoints);
            grid.Children.Add(nud_MinTouchPoints);
			#endregion
			MenuControl.Items.Add(grid); row=0;

			#region -- Swing Strength numerical box --
			grid = new Grid(); row = 0;
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width  = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width  = new GridLength(40) });
			grid.RowDefinitions.Add(   new RowDefinition    { Height = new GridLength(rHeight) });

			lbl_SwingStrength = new Label() { Name = "lbl_SwingStrength"+uID,  Content = "Swing Strength ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_SwingStrength.SetValue(Grid.ColumnProperty, 0);
            lbl_SwingStrength.SetValue(Grid.RowProperty, row);

			nud_SwingStrength = new TextBox() { Name = "nud_SwingStrength"+uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            nud_SwingStrength.Text = pSwingStrength.ToString();
			nud_SwingStrength.KeyDown += menuTxtbox_KeyDownInteger;
            nud_SwingStrength.TextChanged += delegate(object o, TextChangedEventArgs e){
				InformUserAboutRecalculation();
				int max = 1000;
				int min = 1;
				int x = nud_SwingStrength.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_SwingStrength.Text);
				if(x>max) {
					nud_SwingStrength.Text = max.ToString();
					x=max;
				}
				if(x<min) {
					nud_SwingStrength.Text = min.ToString();
					x=min;
				}
				this.pSwingStrength = x;
				ForceRefresh();
			};
			nud_SwingStrength.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				int max = 1000;
				int min = 1;
				int x = nud_SwingStrength.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_SwingStrength.Text);
				if(e.Delta<0){
					x = x - 1;
					x = Math.Max(min, Math.Min(max,x));
					pSwingStrength = x;
					nud_SwingStrength.Text = x.ToString();
				}else if(e.Delta>0){
					x = x + 1;
					x = Math.Max(min, Math.Min(max,x));
					pSwingStrength = x;
					nud_SwingStrength.Text = x.ToString();
				}
				ForceRefresh();
			};
			nud_SwingStrength.SetValue(Grid.ColumnProperty, 1);
            nud_SwingStrength.SetValue(Grid.RowProperty, row);
            grid.Children.Add(lbl_SwingStrength);
            grid.Children.Add(nud_SwingStrength);
			#endregion
			MenuControl.Items.Add(grid);

			#region -- TouchZoneOpacity numerical box --
			grid = new Grid(); row = 0;
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width  = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width  = new GridLength(40) });
			grid.RowDefinitions.Add(   new RowDefinition    { Height = new GridLength(rHeight) });

			lbl_TouchZoneOpacity = new Label() { Name = "lbl_TouchZoneOpacity"+uID,  Content = "Zone Opacity ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_TouchZoneOpacity.SetValue(Grid.ColumnProperty, 0);
            lbl_TouchZoneOpacity.SetValue(Grid.RowProperty, row);

			nud_TouchZoneOpacity = new TextBox() { Name = "nud_TouchZoneOpacity"+uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            nud_TouchZoneOpacity.Text = pTouchZoneOpacity.ToString();
			nud_TouchZoneOpacity.KeyDown += menuTxtbox_KeyDownInteger;
            nud_TouchZoneOpacity.TextChanged += delegate(object o, TextChangedEventArgs e){
				//InformUserAboutRecalculation();
				int max = 100;
				int min = 0;
				int x = nud_TouchZoneOpacity.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_TouchZoneOpacity.Text);
				if(x>max) {
					nud_TouchZoneOpacity.Text = max.ToString();
					x=max;
				}
				if(x<min) {
					nud_TouchZoneOpacity.Text = min.ToString();
					x=min;
				}
				this.pTouchZoneOpacity = x;
				ForceRefresh();
			};
			nud_TouchZoneOpacity.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				//InformUserAboutRecalculation();
				int max = 100;
				int min = 0;
				int x = nud_TouchZoneOpacity.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_TouchZoneOpacity.Text);
				if(e.Delta<0){
					x = x - 1;
					x = Math.Max(min, Math.Min(max,x));
					pTouchZoneOpacity = x;
					nud_TouchZoneOpacity.Text = x.ToString();
				}else if(e.Delta>0){
					x = x + 1;
					x = Math.Max(min, Math.Min(max,x));
					pTouchZoneOpacity = x;
					nud_TouchZoneOpacity.Text = x.ToString();
				}
				ForceRefresh();
			};
			nud_TouchZoneOpacity.SetValue(Grid.ColumnProperty, 1);
            nud_TouchZoneOpacity.SetValue(Grid.RowProperty, row);
            grid.Children.Add(lbl_TouchZoneOpacity);
            grid.Children.Add(nud_TouchZoneOpacity);
			row++;
			#endregion
			MenuControl.Items.Add(grid);

			MenuControl.Items.Add(new Separator());

			#region -- Additional Points settings --
			miZoneType   = new MenuItem { Header = string.Format("Trendline Zone Type:  {0}",pZoneType).Replace("ATRmult","ATR"), Name = "ZoneType"+uID,       Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = false, StaysOpenOnClick = true };
			miZoneType.Click += delegate (object o, RoutedEventArgs e)
			{
				int type = (int)pZoneType;
				type++;
				var list = new List<int>();
				foreach(int i in Enum.GetValues(typeof(ARC_AT_Trader_ZoneType)))
					list.Add(i);
				if(!Enum.IsDefined(typeof(ARC_AT_Trader_ZoneType), type)){
					if(type<0) type = list.Max();
					else type = 0;
				}
				pZoneType = (ARC_AT_Trader_ZoneType)type;
				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						InformUserAboutRecalculation();
						miZoneType.Header = string.Format("Trendline Zone Type:  {0}",pZoneType).Replace("ATRmult","ATR");
						if(pZoneType == ARC_AT_Trader_ZoneType.ATR){
							nud_TLTouchPointsATRMult.Background = Brushes.DarkCyan;
							lbl_TLTouchPointsATRMult.Visibility = Visibility.Visible;
							nud_TLTouchPointsATRMult.Visibility = Visibility.Visible;

//							nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
							lbl_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
							nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
						}else if(pZoneType == ARC_AT_Trader_ZoneType.Ticks){
							nud_TLTouchPointsTicks.Background = Brushes.DarkCyan;
//							nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;

							lbl_TLTouchPointsTicks.Visibility = Visibility.Visible;
							nud_TLTouchPointsTicks.Visibility = Visibility.Visible;
							lbl_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
							nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
						}else{
//							nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
//							nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
							lbl_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
							nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
							lbl_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
							nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
						}
						ForceRefresh();
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							InformUserAboutRecalculation();
							miZoneType.Header = string.Format("Trendline Zone Type:  {0}",pTrendContinuingSignalType).Replace("ATRmult","ATR");
							if(pZoneType == ARC_AT_Trader_ZoneType.ATR){
								nud_TLTouchPointsATRMult.Background = Brushes.DarkCyan;
								lbl_TLTouchPointsATRMult.Visibility = Visibility.Visible;
								nud_TLTouchPointsATRMult.Visibility = Visibility.Visible;

//								nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
								lbl_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
								nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
							}else if(pZoneType == ARC_AT_Trader_ZoneType.Ticks){
								nud_TLTouchPointsTicks.Background = Brushes.DarkCyan;
//								nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;

								lbl_TLTouchPointsTicks.Visibility = Visibility.Visible;
								nud_TLTouchPointsTicks.Visibility = Visibility.Visible;
								lbl_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
								nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
							}else{
//								nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
//								nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
								lbl_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
								nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
								lbl_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
								nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
							}
							ForceRefresh();
						}));
					}
				}
			};
			miZoneType.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				int type = (int)pZoneType;
				if(e.Delta>0)
					type++;
				else type--;
				var list = new List<int>();
				foreach(int i in Enum.GetValues(typeof(ARC_AT_Trader_ZoneType)))
					list.Add(i);
				if(!Enum.IsDefined(typeof(ARC_AT_Trader_ZoneType), type)){
					if(type<0) type = list.Max();
					else type = 0;
				}
				pZoneType = (ARC_AT_Trader_ZoneType)type;
				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						InformUserAboutRecalculation();
						miZoneType.Header = string.Format("Trendline Zone Type:  {0}",pZoneType).Replace("ATRmult","ATR");
						if(pZoneType == ARC_AT_Trader_ZoneType.ATR){
							nud_TLTouchPointsATRMult.Background = Brushes.DarkCyan;
							lbl_TLTouchPointsATRMult.Visibility = Visibility.Visible;
							nud_TLTouchPointsATRMult.Visibility = Visibility.Visible;

//							nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
							lbl_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
							nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
						}else if(pZoneType == ARC_AT_Trader_ZoneType.Ticks){
							nud_TLTouchPointsTicks.Background = Brushes.DarkCyan;
//							nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;

							lbl_TLTouchPointsTicks.Visibility = Visibility.Visible;
							nud_TLTouchPointsTicks.Visibility = Visibility.Visible;
							lbl_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
							nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
						}else{
//							nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
//							nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
							lbl_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
							nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
							lbl_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
							nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
						}
						ForceRefresh();
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							InformUserAboutRecalculation();
							miZoneType.Header = string.Format("Trendline Zone Type:  {0}",pZoneType).Replace("ATRmult","ATR");
							if(pZoneType == ARC_AT_Trader_ZoneType.ATR){
								nud_TLTouchPointsATRMult.Background = Brushes.DarkCyan;
								lbl_TLTouchPointsATRMult.Visibility = Visibility.Visible;
								nud_TLTouchPointsATRMult.Visibility = Visibility.Visible;

//								nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
								lbl_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
								nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
							}else if(pZoneType == ARC_AT_Trader_ZoneType.Ticks){
								nud_TLTouchPointsTicks.Background = Brushes.DarkCyan;
//								nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;

								lbl_TLTouchPointsTicks.Visibility = Visibility.Visible;
								nud_TLTouchPointsTicks.Visibility = Visibility.Visible;
								lbl_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
								nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
							}else{
//								nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
//								nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
								lbl_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
								nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
								lbl_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
								nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
							}
							ForceRefresh();
						}));
					}
				}
			};
			MenuControl.Items.Add(miZoneType);
			#endregion

			grid = new Grid(); row = 0;
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width  = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width  = new GridLength(40) });
			grid.RowDefinitions.Add(   new RowDefinition    { Height = new GridLength(rHeight) });
//			grid.RowDefinitions.Add(   new RowDefinition    { Height = new GridLength(rHeight) });

			#region -- TLTouchPoints ATRmult numerical box --
            lbl_TLTouchPointsATRMult = new Label() { Name = "lbl_TLTouchPointsATRMult"+uID,  Content = "TL Zone (ATR) ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_TLTouchPointsATRMult.SetValue(Grid.ColumnProperty, 0);
            lbl_TLTouchPointsATRMult.SetValue(Grid.RowProperty, row);

			nud_TLTouchPointsATRMult = new TextBox() { Name = "nud_TLTouchPointsATRMult"+uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            nud_TLTouchPointsATRMult.Text = pTLTouchPointsATRMult.ToString();
			nud_TLTouchPointsATRMult.KeyDown += menuTxtbox_KeyDownDouble;
            nud_TLTouchPointsATRMult.TextChanged += delegate(object o, TextChangedEventArgs e){
				InformUserAboutRecalculation();
				double max = 1000;
				double min = 0;
				double x = nud_TLTouchPointsATRMult.Text.Trim().Length==0 ? min : Convert.ToDouble(nud_TLTouchPointsATRMult.Text);
				if(x>max) {
					nud_TLTouchPointsATRMult.Text = max.ToString();
					x=max;
				}
				if(x<min) {
					nud_TLTouchPointsATRMult.Text = min.ToString();
					x=min;
				}
				this.pTLTouchPointsATRMult = x;
				ForceRefresh();
			};
			nud_TLTouchPointsATRMult.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				double max = 1000;
				double min = 0;
				double x = nud_TLTouchPointsATRMult.Text.Trim().Length==0 ? min : Convert.ToDouble(nud_TLTouchPointsATRMult.Text);
				if(e.Delta<0){
					x = x - 0.1;
					x = Math.Max(min, Math.Min(max,x));
					pTLTouchPointsATRMult = x;
					nud_TLTouchPointsATRMult.Text = x.ToString();
				}else if(e.Delta>0){
					x = x + 0.1;
					x = Math.Max(min, Math.Min(max,x));
					pTLTouchPointsATRMult = x;
					nud_TLTouchPointsATRMult.Text = x.ToString();
				}
				ForceRefresh();
			};
			nud_TLTouchPointsATRMult.SetValue(Grid.ColumnProperty, 1);
            nud_TLTouchPointsATRMult.SetValue(Grid.RowProperty, row);
            grid.Children.Add(lbl_TLTouchPointsATRMult);
            grid.Children.Add(nud_TLTouchPointsATRMult);
			#endregion
			#region -- TLTouchPointsTicks numerical box --
//			row++;
            lbl_TLTouchPointsTicks = new Label() { Name = "lbl_TLTouchPointsTicks"+uID,  Content = "TL Zone (Ticks) ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_TLTouchPointsTicks.SetValue(Grid.ColumnProperty, 0);
            lbl_TLTouchPointsTicks.SetValue(Grid.RowProperty, row);

			nud_TLTouchPointsTicks = new TextBox() { Name = "nud_TLTouchPointsTicks"+uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            nud_TLTouchPointsTicks.Text = pTLTouchPointsTicks.ToString();
			nud_TLTouchPointsTicks.KeyDown += menuTxtbox_KeyDownInteger;
            nud_TLTouchPointsTicks.TextChanged += delegate(object o, TextChangedEventArgs e){
				InformUserAboutRecalculation();
				int max = int.MaxValue;
				int min = 0;
				int x = nud_TLTouchPointsTicks.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_TLTouchPointsTicks.Text);
				if(x>max) {
					nud_TLTouchPointsTicks.Text = max.ToString();
					x=max;
				}
				if(x<min) {
					nud_TLTouchPointsTicks.Text = min.ToString();
					x=min;
				}
				this.pTLTouchPointsTicks = x;
				ForceRefresh();
			};
			nud_TLTouchPointsTicks.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				int max = int.MaxValue;
				int min = 0;
				int x = nud_TLTouchPointsTicks.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_TLTouchPointsTicks.Text);
				if(e.Delta<0){
					x = x - 1;
					x = Math.Max(min, Math.Min(max,x));
					pTLTouchPointsTicks = x;
					nud_TLTouchPointsTicks.Text = x.ToString();
				}else if(e.Delta>0){
					x = x + 1;
					x = Math.Max(min, Math.Min(max,x));
					pTLTouchPointsTicks = x;
					nud_TLTouchPointsTicks.Text = x.ToString();
				}
				ForceRefresh();
			};
			#region -- Set default visibility --
				if(pZoneType == ARC_AT_Trader_ZoneType.ATR){
					nud_TLTouchPointsATRMult.Background = Brushes.DarkCyan;
					lbl_TLTouchPointsATRMult.Visibility = Visibility.Visible;
					nud_TLTouchPointsATRMult.Visibility = Visibility.Visible;

//					nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
					lbl_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
					nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
				}else if(pZoneType == ARC_AT_Trader_ZoneType.Ticks){
					nud_TLTouchPointsTicks.Background = Brushes.DarkCyan;
//					nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;

					lbl_TLTouchPointsTicks.Visibility = Visibility.Visible;
					nud_TLTouchPointsTicks.Visibility = Visibility.Visible;
					lbl_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
					nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
				}else{
//					nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
//					nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
					lbl_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
					nud_TLTouchPointsATRMult.Visibility = Visibility.Collapsed;
					lbl_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
					nud_TLTouchPointsTicks.Visibility = Visibility.Collapsed;
				}
			#endregion

			nud_TLTouchPointsTicks.SetValue(Grid.ColumnProperty, 1);
            nud_TLTouchPointsTicks.SetValue(Grid.RowProperty, row);
            grid.Children.Add(lbl_TLTouchPointsTicks);
            grid.Children.Add(nud_TLTouchPointsTicks);
			#endregion
			MenuControl.Items.Add(grid);

			MenuControl.Items.Add(new Separator());

			#region -- Trend Signals --
			miTrendContinuingSignalType   = new MenuItem { Header = string.Format("Trend Signal Type:  {0}",pTrendContinuingSignalType).Replace("ATRmult","ATR"), Name = "TrendContinuingSignalType"+uID,       Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = false, StaysOpenOnClick = true };
			miTrendContinuingSignalType.Click += delegate (object o, RoutedEventArgs e)
			{
				int type = (int)pTrendContinuingSignalType;
				type++;
				var list = new List<int>();
				foreach(int i in Enum.GetValues(typeof(ARC_AT_Trader_SignalType)))
					list.Add(i);
				if(!Enum.IsDefined(typeof(ARC_AT_Trader_SignalType), type)){
					if(type<0) type = list.Max();
					else type = 0;
				}
				pTrendContinuingSignalType = (ARC_AT_Trader_SignalType)type;
				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						InformUserAboutRecalculation();
						miTrendContinuingSignalType.Header = string.Format("Trend Signal Type:  {0}",pTrendContinuingSignalType).Replace("ATRmult","ATR");
						if(pTrendContinuingSignalType == ARC_AT_Trader_SignalType.ATRmult){
							lbl_TrendContinuingDistanceATRMult.Visibility = Visibility.Visible;
							nud_TrendContinuingDistanceATRMult.Visibility = Visibility.Visible;
							nud_TrendContinuingDistanceATRMult.Background = Brushes.DarkCyan;
							lbl_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
							nud_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
						}else if(pTrendContinuingSignalType == ARC_AT_Trader_SignalType.Ticks){
							lbl_TrendContinuingDistanceTicks.Visibility = Visibility.Visible;
							nud_TrendContinuingDistanceTicks.Visibility = Visibility.Visible;
							nud_TrendContinuingDistanceTicks.Background = Brushes.DarkCyan;
							lbl_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
							nud_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
						}else{
							lbl_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
							nud_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
							lbl_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
							nud_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
						}
						ForceRefresh();
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							InformUserAboutRecalculation();
							miTrendContinuingSignalType.Header = string.Format("Trend Signal Type:  {0}",pTrendContinuingSignalType).Replace("ATRmult","ATR");
							if(pTrendContinuingSignalType == ARC_AT_Trader_SignalType.ATRmult){
								lbl_TrendContinuingDistanceATRMult.Visibility = Visibility.Visible;
								nud_TrendContinuingDistanceATRMult.Visibility = Visibility.Visible;
								nud_TrendContinuingDistanceATRMult.Background = Brushes.DarkCyan;
								lbl_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
								nud_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
							}else if(pTrendContinuingSignalType == ARC_AT_Trader_SignalType.Ticks){
								lbl_TrendContinuingDistanceTicks.Visibility = Visibility.Visible;
								nud_TrendContinuingDistanceTicks.Visibility = Visibility.Visible;
								nud_TrendContinuingDistanceTicks.Background = Brushes.DarkCyan;
								lbl_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
								nud_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
							}else{
								lbl_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
								nud_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
								lbl_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
								nud_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
							}
							ForceRefresh();
						}));
					}
				}
			};
			miTrendContinuingSignalType.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				int type = (int)pTrendContinuingSignalType;
				if(e.Delta>0)
					type++;
				else type--;
				var list = new List<int>();
				foreach(int i in Enum.GetValues(typeof(ARC_AT_Trader_SignalType)))
					list.Add(i);
				if(!Enum.IsDefined(typeof(ARC_AT_Trader_SignalType), type)){
					if(type<0) type = list.Max();
					else type = 0;
				}
				pTrendContinuingSignalType = (ARC_AT_Trader_SignalType)type;
				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						InformUserAboutRecalculation();
						miTrendContinuingSignalType.Header = string.Format("Trend Signal Type:  {0}",pTrendContinuingSignalType).Replace("ATRmult","ATR");
						if(pTrendContinuingSignalType == ARC_AT_Trader_SignalType.ATRmult){
							lbl_TrendContinuingDistanceATRMult.Visibility = Visibility.Visible;
							nud_TrendContinuingDistanceATRMult.Visibility = Visibility.Visible;
							nud_TrendContinuingDistanceATRMult.Background = Brushes.DarkCyan;
							lbl_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
							nud_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
						}else if(pTrendContinuingSignalType == ARC_AT_Trader_SignalType.Ticks){
							lbl_TrendContinuingDistanceTicks.Visibility = Visibility.Visible;
							nud_TrendContinuingDistanceTicks.Visibility = Visibility.Visible;
							nud_TrendContinuingDistanceTicks.Background = Brushes.DarkCyan;
							lbl_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
							nud_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
						}else{
							lbl_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
							nud_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
							lbl_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
							nud_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
						}
						ForceRefresh();
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							InformUserAboutRecalculation();
							miTrendContinuingSignalType.Header = string.Format("Trend Signal Type:  {0}",pTrendContinuingSignalType).Replace("ATRmult","ATR");
							if(pTrendContinuingSignalType == ARC_AT_Trader_SignalType.ATRmult){
								lbl_TrendContinuingDistanceATRMult.Visibility = Visibility.Visible;
								nud_TrendContinuingDistanceATRMult.Visibility = Visibility.Visible;
								nud_TrendContinuingDistanceATRMult.Background = Brushes.DarkCyan;
								lbl_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
								nud_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
							}else if(pTrendContinuingSignalType == ARC_AT_Trader_SignalType.Ticks){
								lbl_TrendContinuingDistanceTicks.Visibility = Visibility.Visible;
								nud_TrendContinuingDistanceTicks.Visibility = Visibility.Visible;
								nud_TrendContinuingDistanceTicks.Background = Brushes.DarkCyan;
								lbl_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
								nud_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
							}else{
								lbl_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
								nud_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
								lbl_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
								nud_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
							}
							ForceRefresh();
						}));
					}
				}
			};
			MenuControl.Items.Add(miTrendContinuingSignalType);

			grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width  = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width  = new GridLength(40) });
			grid.RowDefinitions.Add(   new RowDefinition    { Height = new GridLength(rHeight) });
//			grid.RowDefinitions.Add(   new RowDefinition    { Height = new GridLength(rHeight) });
			//grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });

			row = 0;
			#region -- TrendContinuingDistanceATRMult numerical box --
            lbl_TrendContinuingDistanceATRMult = new Label() { Name = "lbl_TrendContinuingATRmult"+uID,  Content = "ATR multiplier ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_TrendContinuingDistanceATRMult.SetValue(Grid.ColumnProperty, 0);
            lbl_TrendContinuingDistanceATRMult.SetValue(Grid.RowProperty, row);

			nud_TrendContinuingDistanceATRMult = new TextBox() { Name = "nud_TrendContinuingATRmult"+uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            nud_TrendContinuingDistanceATRMult.Text = pTrendContinuingDistanceATRMult.ToString();
			nud_TrendContinuingDistanceATRMult.KeyDown += menuTxtbox_KeyDownDouble;
            nud_TrendContinuingDistanceATRMult.TextChanged += delegate(object o, TextChangedEventArgs e){
				InformUserAboutRecalculation();
				double max = 1000;
				double min = 0;
				double x = nud_TrendContinuingDistanceATRMult.Text.Trim().Length==0 ? min : Convert.ToDouble(nud_TrendContinuingDistanceATRMult.Text);
				if(x>max) {
					nud_TrendContinuingDistanceATRMult.Text = max.ToString();
					x=max;
				}
				if(x<min) {
					nud_TrendContinuingDistanceATRMult.Text = min.ToString();
					x=min;
				}
				this.pTrendContinuingDistanceATRMult = x;
				ForceRefresh();
			};
			nud_TrendContinuingDistanceATRMult.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				double max = 1000;
				double min = 0;
				double x = nud_TrendContinuingDistanceATRMult.Text.Trim().Length==0 ? min : Convert.ToDouble(nud_TrendContinuingDistanceATRMult.Text);
				if(e.Delta<0){
					x = x - 0.1;
					x = Math.Max(min, Math.Min(max,x));
					pTrendContinuingDistanceATRMult = x;
					nud_TrendContinuingDistanceATRMult.Text = x.ToString();
				}else if(e.Delta>0){
					x = x + 0.1;
					x = Math.Max(min, Math.Min(max,x));
					pTrendContinuingDistanceATRMult = x;
					nud_TrendContinuingDistanceATRMult.Text = x.ToString();
				}
				ForceRefresh();
			};
			nud_TrendContinuingDistanceATRMult.SetValue(Grid.ColumnProperty, 1);
            nud_TrendContinuingDistanceATRMult.SetValue(Grid.RowProperty, row);
            grid.Children.Add(lbl_TrendContinuingDistanceATRMult);
            grid.Children.Add(nud_TrendContinuingDistanceATRMult);
			#endregion
			#region -- TrendContinuingDistanceTicks numerical box --
			//row++;
            lbl_TrendContinuingDistanceTicks = new Label() { Name = "lbl_TrendContinuingTicks"+uID,  Content = "Ticks ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_TrendContinuingDistanceTicks.SetValue(Grid.ColumnProperty, 0);
            lbl_TrendContinuingDistanceTicks.SetValue(Grid.RowProperty, row);

			nud_TrendContinuingDistanceTicks = new TextBox() { Name = "nud_TrendContinuingDistanceTicks"+uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            nud_TrendContinuingDistanceTicks.Text = pTrendContinuingDistanceTicks.ToString();
			nud_TrendContinuingDistanceTicks.KeyDown += menuTxtbox_KeyDownInteger;
            nud_TrendContinuingDistanceTicks.TextChanged += delegate(object o, TextChangedEventArgs e){
				InformUserAboutRecalculation();
				int max = int.MaxValue;
				int min = 0;
				int x = nud_TrendContinuingDistanceTicks.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_TrendContinuingDistanceTicks.Text);
				if(x>max) {
					nud_TrendContinuingDistanceTicks.Text = max.ToString();
					x=max;
				}
				if(x<min) {
					nud_TrendContinuingDistanceTicks.Text = min.ToString();
					x=min;
				}
				this.pTrendContinuingDistanceTicks = x;
				ForceRefresh();
			};
			nud_TrendContinuingDistanceTicks.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				int max = int.MaxValue;
				int min = 0;
				int x = nud_TrendContinuingDistanceTicks.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_TrendContinuingDistanceTicks.Text);
				if(e.Delta<0){
					x = x - 1;
					x = Math.Max(min, Math.Min(max,x));
					pTrendContinuingDistanceTicks = x;
					nud_TrendContinuingDistanceTicks.Text = x.ToString();
				}else if(e.Delta>0){
					x = x + 1;
					x = Math.Max(min, Math.Min(max,x));
					pTrendContinuingDistanceTicks = x;
					nud_TrendContinuingDistanceTicks.Text = x.ToString();
				}
				ForceRefresh();
			};
			if(pTrendContinuingSignalType == ARC_AT_Trader_SignalType.ATRmult){
				lbl_TrendContinuingDistanceATRMult.Visibility = Visibility.Visible;
				nud_TrendContinuingDistanceATRMult.Visibility = Visibility.Visible;
				nud_TrendContinuingDistanceATRMult.Background = Brushes.DarkCyan;
				lbl_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
				nud_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
			}else if(pTrendContinuingSignalType == ARC_AT_Trader_SignalType.Ticks){
				lbl_TrendContinuingDistanceTicks.Visibility = Visibility.Visible;
				nud_TrendContinuingDistanceTicks.Visibility = Visibility.Visible;
				nud_TrendContinuingDistanceTicks.Background = Brushes.DarkCyan;
				lbl_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
				nud_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
			}else{
				lbl_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
				nud_TrendContinuingDistanceTicks.Visibility = Visibility.Collapsed;
				lbl_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
				nud_TrendContinuingDistanceATRMult.Visibility = Visibility.Collapsed;
			}
			nud_TrendContinuingDistanceTicks.SetValue(Grid.ColumnProperty, 1);
            nud_TrendContinuingDistanceTicks.SetValue(Grid.RowProperty, row);
            grid.Children.Add(lbl_TrendContinuingDistanceTicks);
            grid.Children.Add(nud_TrendContinuingDistanceTicks);
			//row++;
			#endregion

			MenuControl.Items.Add(grid);
			#endregion

			MenuControl.Items.Add(new Separator());
			#region -- Break Signals --
			miBreakSignalType   = new MenuItem { Header = string.Format("Break Signal Type:  {0}",pBreakSignalType).Replace("ATRmult","ATR"), Name = "miBreakSignalType"+uID,       Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = false, StaysOpenOnClick = true };
			miBreakSignalType.Click += delegate (object o, RoutedEventArgs e)
			{
				int type = (int)pBreakSignalType;
				type++;
				var list = new List<int>();
				foreach(int i in Enum.GetValues(typeof(ARC_AT_Trader_SignalType)))
					list.Add(i);
				if(!Enum.IsDefined(typeof(ARC_AT_Trader_SignalType), type)){
					if(type<0) type = list.Max();
					else type = 0;
				}
				pBreakSignalType = (ARC_AT_Trader_SignalType)type;
				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						InformUserAboutRecalculation();
						miBreakSignalType.Header = string.Format("Break Signal Type:  {0}",pBreakSignalType).Replace("ATRmult","ATR");
						if(pBreakSignalType == ARC_AT_Trader_SignalType.ATRmult){
							lbl_BreakDistanceATRMult.Visibility = Visibility.Visible;
							nud_BreakDistanceATRMult.Visibility = Visibility.Visible;
							nud_BreakDistanceATRMult.Background = Brushes.DarkCyan;
							lbl_BreakDistanceTicks.Visibility = Visibility.Collapsed;
							nud_BreakDistanceTicks.Visibility = Visibility.Collapsed;
						}else if(pBreakSignalType == ARC_AT_Trader_SignalType.Ticks){
							lbl_BreakDistanceTicks.Visibility = Visibility.Visible;
							nud_BreakDistanceTicks.Visibility = Visibility.Visible;
							nud_BreakDistanceTicks.Background = Brushes.DarkCyan;
							lbl_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
							nud_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
						}else{
							lbl_BreakDistanceTicks.Visibility = Visibility.Collapsed;
							nud_BreakDistanceTicks.Visibility = Visibility.Collapsed;
							lbl_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
							nud_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
						}
						ForceRefresh();
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							InformUserAboutRecalculation();
							miBreakSignalType.Header = string.Format("Break Signal Type:  {0}",pBreakSignalType).Replace("ATRmult","ATR");
							if(pBreakSignalType == ARC_AT_Trader_SignalType.ATRmult){
								lbl_BreakDistanceATRMult.Visibility = Visibility.Visible;
								nud_BreakDistanceATRMult.Visibility = Visibility.Visible;
								nud_BreakDistanceATRMult.Background = Brushes.DarkCyan;
								lbl_BreakDistanceTicks.Visibility = Visibility.Collapsed;
								nud_BreakDistanceTicks.Visibility = Visibility.Collapsed;
							}else if(pBreakSignalType == ARC_AT_Trader_SignalType.Ticks){
								lbl_BreakDistanceTicks.Visibility = Visibility.Visible;
								nud_BreakDistanceTicks.Visibility = Visibility.Visible;
								nud_BreakDistanceTicks.Background = Brushes.DarkCyan;
								lbl_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
								nud_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
							}else{
								lbl_BreakDistanceTicks.Visibility = Visibility.Collapsed;
								nud_BreakDistanceTicks.Visibility = Visibility.Collapsed;
								lbl_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
								nud_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
							}
							ForceRefresh();
						}));
					}
				}
//				ForceRefresh();
			};
			miBreakSignalType.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				int type = (int)pBreakSignalType;
				if(e.Delta>0)
					type++;
				else type--;
				var list = new List<int>();
				foreach(int i in Enum.GetValues(typeof(ARC_AT_Trader_SignalType)))
					list.Add(i);
				if(!Enum.IsDefined(typeof(ARC_AT_Trader_SignalType), type)){
					if(type<0) type = list.Max();
					else type = 0;
				}
				pBreakSignalType = (ARC_AT_Trader_SignalType)type;
				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						InformUserAboutRecalculation();
						miBreakSignalType.Header = string.Format("Break Signal Type:  {0}",pBreakSignalType).Replace("ATRmult","ATR");
						if(pBreakSignalType == ARC_AT_Trader_SignalType.ATRmult){
							lbl_BreakDistanceATRMult.Visibility = Visibility.Visible;
							nud_BreakDistanceATRMult.Visibility = Visibility.Visible;
							nud_BreakDistanceATRMult.Background = Brushes.DarkCyan;
							lbl_BreakDistanceTicks.Visibility = Visibility.Collapsed;
							nud_BreakDistanceTicks.Visibility = Visibility.Collapsed;
						}else if(pBreakSignalType == ARC_AT_Trader_SignalType.Ticks){
							lbl_BreakDistanceTicks.Visibility = Visibility.Visible;
							nud_BreakDistanceTicks.Visibility = Visibility.Visible;
							nud_BreakDistanceTicks.Background = Brushes.DarkCyan;
							lbl_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
							nud_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
						}else{
							lbl_BreakDistanceTicks.Visibility = Visibility.Collapsed;
							nud_BreakDistanceTicks.Visibility = Visibility.Collapsed;
							lbl_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
							nud_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
						}
						ForceRefresh();
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							InformUserAboutRecalculation();
							miBreakSignalType.Header = string.Format("Break Signal Type:  {0}",pBreakSignalType).Replace("ATRmult","ATR");
							if(pBreakSignalType == ARC_AT_Trader_SignalType.ATRmult){
								lbl_BreakDistanceATRMult.Visibility = Visibility.Visible;
								nud_BreakDistanceATRMult.Visibility = Visibility.Visible;
								nud_BreakDistanceATRMult.Background = Brushes.DarkCyan;
								lbl_BreakDistanceTicks.Visibility = Visibility.Collapsed;
								nud_BreakDistanceTicks.Visibility = Visibility.Collapsed;
							}else if(pBreakSignalType == ARC_AT_Trader_SignalType.Ticks){
								lbl_BreakDistanceTicks.Visibility = Visibility.Visible;
								nud_BreakDistanceTicks.Visibility = Visibility.Visible;
								nud_BreakDistanceTicks.Background = Brushes.DarkCyan;
								lbl_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
								nud_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
							}else{
								lbl_BreakDistanceTicks.Visibility = Visibility.Collapsed;
								nud_BreakDistanceTicks.Visibility = Visibility.Collapsed;
								lbl_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
								nud_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
							}
							ForceRefresh();
						}));
					}
				}
//				ForceRefresh();
			};
			MenuControl.Items.Add(miBreakSignalType);
			miShowBreakSignalTriggerDot   = new MenuItem { Header = string.Format("Break TriggerDot:  {0}",(pShowBreakSignalTriggerDot?"ON":"OFF")), Name = "miBreakSignalTriggerDot"+uID,       Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = false, StaysOpenOnClick = true };
			miShowBreakSignalTriggerDot.Click += delegate (object o, RoutedEventArgs e){
				pShowBreakSignalTriggerDot = !pShowBreakSignalTriggerDot;
				miShowBreakSignalTriggerDot.Header = string.Format("Break TriggerDot:  {0}",(pShowBreakSignalTriggerDot?"ON":"OFF"));
				ForceRefresh();
			};
			MenuControl.Items.Add(miShowBreakSignalTriggerDot);

			grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width  = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width  = new GridLength(40) });
			grid.RowDefinitions.Add(   new RowDefinition    { Height = new GridLength(rHeight) });
//			grid.RowDefinitions.Add(   new RowDefinition    { Height = new GridLength(rHeight) });
			//grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });

			row = 0;
			#region -- BreakDistanceATRMult numerical box --
            lbl_BreakDistanceATRMult = new Label() { Name = "lbl_BreakATRmult"+uID,  Content = "ATR multiplier ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_BreakDistanceATRMult.SetValue(Grid.ColumnProperty, 0);
            lbl_BreakDistanceATRMult.SetValue(Grid.RowProperty, row);

			nud_BreakDistanceATRMult = new TextBox() { Name = "nud_BreakATRmult"+uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White};
            nud_BreakDistanceATRMult.Text = pBreakDistanceATRMult.ToString();
			nud_BreakDistanceATRMult.KeyDown += delegate(object o, KeyEventArgs e){
				e.Handled = true;
				double max = 1000;
				double min = 0;
				var str = nud_BreakDistanceATRMult.Text;
				try{
					var val = Math.Max(min,Math.Min(max,Convert.ToDouble(nud_BreakDistanceATRMult.Text)));
					Print("'"+str+"':   val: "+val);
				}catch{
					nud_BreakDistanceATRMult.Text = str;
				}
			};
			//menuTxtbox_KeyDownDouble;

            nud_BreakDistanceATRMult.TextChanged += delegate(object o, TextChangedEventArgs e){
				double max = 1000;
				double min = 0;
				var str = nud_BreakDistanceATRMult.Text;
				try{
					double x = nud_BreakDistanceATRMult.Text.Trim().Length==0 ? min : Convert.ToDouble(nud_BreakDistanceATRMult.Text);
					if(x>max) {
						nud_BreakDistanceATRMult.Text = max.ToString();
						x=max;
					}
					if(x<min) {
						nud_BreakDistanceATRMult.Text = min.ToString();
						x=min;
					}
					this.pBreakDistanceATRMult = x;
					InformUserAboutRecalculation();
				}catch{
					nud_BreakDistanceATRMult.Text = str;
				}
				ForceRefresh();
			};
			nud_BreakDistanceATRMult.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				double max = 1000;
				double min = 0;
				double x = nud_BreakDistanceATRMult.Text.Trim().Length==0 ? min : Convert.ToDouble(nud_BreakDistanceATRMult.Text);
				if(e.Delta<0){
					x = x - 0.1;
					x = Math.Max(min, Math.Min(max,x));
					pBreakDistanceATRMult = x;
					nud_BreakDistanceATRMult.Text = x.ToString();
				}else if(e.Delta>0){
					x = x + 0.1;
					x = Math.Max(min, Math.Min(max,x));
					pBreakDistanceATRMult = x;
					nud_BreakDistanceATRMult.Text = x.ToString();
				}
				ForceRefresh();
			};
			nud_BreakDistanceATRMult.SetValue(Grid.ColumnProperty, 1);
            nud_BreakDistanceATRMult.SetValue(Grid.RowProperty, row);
            grid.Children.Add(lbl_BreakDistanceATRMult);
            grid.Children.Add(nud_BreakDistanceATRMult);
			#endregion
			#region -- BreakDistanceTicks numerical box --
//			row++;
            lbl_BreakDistanceTicks = new Label() { Name = "lbl_BreakTicks"+uID,  Content = "Ticks ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_BreakDistanceTicks.SetValue(Grid.ColumnProperty, 0);
            lbl_BreakDistanceTicks.SetValue(Grid.RowProperty, row);

			nud_BreakDistanceTicks = new TextBox() { Name = "nud_BreakDistanceTicks"+uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            nud_BreakDistanceTicks.Text = pBreakDistanceTicks.ToString();
			nud_BreakDistanceTicks.KeyDown += menuTxtbox_KeyDownInteger;
            nud_BreakDistanceTicks.TextChanged += delegate(object o, TextChangedEventArgs e){
				InformUserAboutRecalculation();
				int max = int.MaxValue;
				int min = 0;
				int x = nud_BreakDistanceTicks.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_BreakDistanceTicks.Text);
				if(x>max) {
					nud_BreakDistanceTicks.Text = max.ToString();
					x=max;
				}
				if(x<min) {
					nud_BreakDistanceTicks.Text = min.ToString();
					x=min;
				}
				this.pBreakDistanceTicks = x;
				ForceRefresh();
			};
			nud_BreakDistanceTicks.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				int max = int.MaxValue;
				int min = 0;
				int x = nud_BreakDistanceTicks.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_BreakDistanceTicks.Text);
				if(e.Delta<0){
					x = x - 1;
					x = Math.Max(min, Math.Min(max,x));
					pBreakDistanceTicks = x;
					nud_BreakDistanceTicks.Text = x.ToString();
				}else if(e.Delta>0){
					x = x + 1;
					x = Math.Max(min, Math.Min(max,x));
					pBreakDistanceTicks = x;
					nud_BreakDistanceTicks.Text = x.ToString();
				}
				ForceRefresh();
			};
			if(pBreakSignalType == ARC_AT_Trader_SignalType.ATRmult){
				lbl_BreakDistanceATRMult.Visibility = Visibility.Visible;
				nud_BreakDistanceATRMult.Visibility = Visibility.Visible;
				nud_BreakDistanceATRMult.Background = Brushes.DarkCyan;
				lbl_BreakDistanceTicks.Visibility = Visibility.Collapsed;
				nud_BreakDistanceTicks.Visibility = Visibility.Collapsed;
			}else if(pBreakSignalType == ARC_AT_Trader_SignalType.Ticks){
				lbl_BreakDistanceTicks.Visibility = Visibility.Visible;
				nud_BreakDistanceTicks.Visibility = Visibility.Visible;
				nud_BreakDistanceTicks.Background = Brushes.DarkCyan;
				lbl_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
				nud_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
			}else{
				lbl_BreakDistanceTicks.Visibility = Visibility.Collapsed;
				nud_BreakDistanceTicks.Visibility = Visibility.Collapsed;
				lbl_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
				nud_BreakDistanceATRMult.Visibility = Visibility.Collapsed;
			}

			nud_BreakDistanceTicks.SetValue(Grid.ColumnProperty, 1);
            nud_BreakDistanceTicks.SetValue(Grid.RowProperty, row);
            grid.Children.Add(lbl_BreakDistanceTicks);
            grid.Children.Add(nud_BreakDistanceTicks);
			#endregion

			MenuControl.Items.Add(grid);
			#endregion

			MenuControl.Items.Add(new Separator());

			#region -- ZoneTermination --
			miZoneTerminationType   = new MenuItem { Header = string.Format("Zone Termination Type:  {0}",pZoneTerminationType).Replace("ATRmult","ATR"), Name = "miZoneTerminationType"+uID,       Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = false, StaysOpenOnClick = true };
			miZoneTerminationType.Click += delegate (object o, RoutedEventArgs e)
			{
				int type = (int)pZoneTerminationType;
				type++;
				var list = new List<int>();
				foreach(int i in Enum.GetValues(typeof(ARC_AT_Trader_ZoneType)))
					list.Add(i);
				if(!Enum.IsDefined(typeof(ARC_AT_Trader_ZoneType), type)){
					if(type<0) type = list.Max();
					else type = 0;
				}
				pZoneTerminationType = (ARC_AT_Trader_ZoneType)type;
				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						InformUserAboutRecalculation();
						miZoneTerminationType.Header = string.Format("Zone Termination Type:  {0}",pZoneTerminationType).Replace("ATRmult","ATR");
						if(pZoneTerminationType == ARC_AT_Trader_ZoneType.ATR){
							lbl_ZoneTerminationDistanceATRMult.Visibility = Visibility.Visible;
							nud_ZoneTerminationDistanceATRMult.Visibility = Visibility.Visible;
							nud_ZoneTerminationDistanceATRMult.Background = Brushes.DarkCyan;
							lbl_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
							nud_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
						}else if(pZoneTerminationType == ARC_AT_Trader_ZoneType.Ticks){
							lbl_ZoneTerminationDistanceTicks.Visibility = Visibility.Visible;
							nud_ZoneTerminationDistanceTicks.Visibility = Visibility.Visible;
							nud_ZoneTerminationDistanceTicks.Background = Brushes.DarkCyan;
							lbl_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
							nud_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
						}else{
							lbl_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
							nud_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
							lbl_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
							nud_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
						}
						ForceRefresh();
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							InformUserAboutRecalculation();
							miZoneTerminationType.Header = string.Format("Zone Termination Type:  {0}",pZoneTerminationType).Replace("ATRmult","ATR");
							if(pZoneTerminationType == ARC_AT_Trader_ZoneType.ATR){
								lbl_ZoneTerminationDistanceATRMult.Visibility = Visibility.Visible;
								nud_ZoneTerminationDistanceATRMult.Visibility = Visibility.Visible;
								nud_ZoneTerminationDistanceATRMult.Background = Brushes.DarkCyan;
								lbl_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
								nud_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
							}else if(pZoneTerminationType == ARC_AT_Trader_ZoneType.Ticks){
								lbl_ZoneTerminationDistanceTicks.Visibility = Visibility.Visible;
								nud_ZoneTerminationDistanceTicks.Visibility = Visibility.Visible;
								nud_ZoneTerminationDistanceTicks.Background = Brushes.DarkCyan;
								lbl_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
								nud_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
							}else{
								lbl_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
								nud_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
								lbl_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
								nud_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
							}
							ForceRefresh();
						}));
					}
				}
//				ForceRefresh();
			};
			miZoneTerminationType.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				int type = (int)pZoneTerminationType;
				if(e.Delta>0)
					type++;
				else type--;
				var list = new List<int>();
				foreach(int i in Enum.GetValues(typeof(ARC_AT_Trader_ZoneType)))
					list.Add(i);
				if(!Enum.IsDefined(typeof(ARC_AT_Trader_ZoneType), type)){
					if(type<0) type = list.Max();
					else type = 0;
				}
				pZoneTerminationType = (ARC_AT_Trader_ZoneType)type;
				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						InformUserAboutRecalculation();
						miZoneTerminationType.Header = string.Format("Zone Termination Type:  {0}",pZoneTerminationType).Replace("ATRmult","ATR");
						if(pZoneTerminationType == ARC_AT_Trader_ZoneType.ATR){
							lbl_ZoneTerminationDistanceATRMult.Visibility = Visibility.Visible;
							nud_ZoneTerminationDistanceATRMult.Visibility = Visibility.Visible;
							nud_ZoneTerminationDistanceATRMult.Background = Brushes.DarkCyan;
							lbl_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
							nud_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
						}else if(pZoneTerminationType == ARC_AT_Trader_ZoneType.Ticks){
							lbl_ZoneTerminationDistanceTicks.Visibility = Visibility.Visible;
							nud_ZoneTerminationDistanceTicks.Visibility = Visibility.Visible;
							nud_ZoneTerminationDistanceTicks.Background = Brushes.DarkCyan;
							lbl_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
							nud_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
						}else{
							lbl_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
							nud_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
							lbl_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
							nud_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
						}
						ForceRefresh();
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							InformUserAboutRecalculation();
							miZoneTerminationType.Header = string.Format("Zone Termination Type:  {0}",pZoneTerminationType).Replace("ATRmult","ATR");
							if(pZoneTerminationType == ARC_AT_Trader_ZoneType.ATR){
								lbl_ZoneTerminationDistanceATRMult.Visibility = Visibility.Visible;
								nud_ZoneTerminationDistanceATRMult.Visibility = Visibility.Visible;
								nud_ZoneTerminationDistanceATRMult.Background = Brushes.DarkCyan;
								lbl_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
								nud_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
							}else if(pZoneTerminationType == ARC_AT_Trader_ZoneType.Ticks){
								lbl_ZoneTerminationDistanceTicks.Visibility = Visibility.Visible;
								nud_ZoneTerminationDistanceTicks.Visibility = Visibility.Visible;
								nud_ZoneTerminationDistanceTicks.Background = Brushes.DarkCyan;
								lbl_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
								nud_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
							}else{
								lbl_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
								nud_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
								lbl_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
								nud_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
							}
							ForceRefresh();
						}));
					}
				}
//				ForceRefresh();
			};
			MenuControl.Items.Add(miZoneTerminationType);

			grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width  = GridLength.Auto });
			grid.ColumnDefinitions.Add(new ColumnDefinition { Width  = new GridLength(40) });
			grid.RowDefinitions.Add(   new RowDefinition    { Height = new GridLength(rHeight) });
//			grid.RowDefinitions.Add(   new RowDefinition    { Height = new GridLength(rHeight) });
			//grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(rHeight) });

			row = 0;
			#region -- ZoneTerminationDistanceATRMult numerical box --
            lbl_ZoneTerminationDistanceATRMult = new Label() { Name = "lbl_ZoneTerminationDistanceATRmult"+uID,  Content = "ATR multiplier ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_ZoneTerminationDistanceATRMult.SetValue(Grid.ColumnProperty, 0);
            lbl_ZoneTerminationDistanceATRMult.SetValue(Grid.RowProperty, row);

			nud_ZoneTerminationDistanceATRMult = new TextBox() { Name = "nud_ZoneTerminationDistanceATRmult"+uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            nud_ZoneTerminationDistanceATRMult.Text = pZoneTerminationDistanceATRMult.ToString();
			nud_ZoneTerminationDistanceATRMult.KeyDown += menuTxtbox_KeyDownDouble;
            nud_ZoneTerminationDistanceATRMult.TextChanged += delegate(object o, TextChangedEventArgs e){
				InformUserAboutRecalculation();
				double max = 1000;
				double min = 0;
				double x = nud_ZoneTerminationDistanceATRMult.Text.Trim().Length==0 ? min : Convert.ToDouble(nud_ZoneTerminationDistanceATRMult.Text);
				if(x>max) {
					nud_ZoneTerminationDistanceATRMult.Text = max.ToString();
					x=max;
				}
				if(x<min) {
					nud_ZoneTerminationDistanceATRMult.Text = min.ToString();
					x=min;
				}
				this.pZoneTerminationDistanceATRMult = x;
				ForceRefresh();
			};
			nud_ZoneTerminationDistanceATRMult.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				double max = 1000;
				double min = 0;
				double x = nud_ZoneTerminationDistanceATRMult.Text.Trim().Length==0 ? min : Convert.ToDouble(nud_ZoneTerminationDistanceATRMult.Text);
				if(e.Delta<0){
					x = x - 0.1;
					x = Math.Max(min, Math.Min(max,x));
					pZoneTerminationDistanceATRMult = x;
					nud_ZoneTerminationDistanceATRMult.Text = x.ToString();
				}else if(e.Delta>0){
					x = x + 0.1;
					x = Math.Max(min, Math.Min(max,x));
					pZoneTerminationDistanceATRMult = x;
					nud_ZoneTerminationDistanceATRMult.Text = x.ToString();
				}
				ForceRefresh();
			};
			nud_ZoneTerminationDistanceATRMult.SetValue(Grid.ColumnProperty, 1);
            nud_ZoneTerminationDistanceATRMult.SetValue(Grid.RowProperty, row);
            grid.Children.Add(lbl_ZoneTerminationDistanceATRMult);
            grid.Children.Add(nud_ZoneTerminationDistanceATRMult);
			#endregion
			#region -- ZoneTerminationDistanceTicks numerical box --
//			row++;
            lbl_ZoneTerminationDistanceTicks = new Label() { Name = "lbl_ZoneTerminationDistanceTicks"+uID,  Content = "Ticks ", HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0), FontWeight = FontWeights.Normal };
            lbl_ZoneTerminationDistanceTicks.SetValue(Grid.ColumnProperty, 0);
            lbl_ZoneTerminationDistanceTicks.SetValue(Grid.RowProperty, row);

			nud_ZoneTerminationDistanceTicks = new TextBox() { Name = "nud_ZoneTerminationDistanceTicks"+uID,  Background=Brushes.Silver, Foreground=Brushes.Black,MinWidth = 75, Width = 75, MaxWidth = 75, Height = 20, Margin = new Thickness(5, 0, 0, 0), BorderBrush = Brushes.White };
            nud_ZoneTerminationDistanceTicks.Text = pZoneTerminationDistanceTicks.ToString();
			nud_ZoneTerminationDistanceTicks.KeyDown += menuTxtbox_KeyDownInteger;
            nud_ZoneTerminationDistanceTicks.TextChanged += delegate(object o, TextChangedEventArgs e){
				InformUserAboutRecalculation();
				int max = int.MaxValue;
				int min = 0;
				int x = nud_ZoneTerminationDistanceTicks.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_ZoneTerminationDistanceTicks.Text);
				if(x>max) {
					nud_ZoneTerminationDistanceTicks.Text = max.ToString();
					x=max;
				}
				if(x<min) {
					nud_ZoneTerminationDistanceTicks.Text = min.ToString();
					x=min;
				}
				this.pZoneTerminationDistanceTicks = x;
				ForceRefresh();
			};
			nud_ZoneTerminationDistanceTicks.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e){
				InformUserAboutRecalculation();
				int max = int.MaxValue;
				int min = 0;
				int x = nud_ZoneTerminationDistanceTicks.Text.Trim().Length==0 ? min : Convert.ToInt32(nud_ZoneTerminationDistanceTicks.Text);
				if(e.Delta<0){
					x = x - 1;
					x = Math.Max(min, Math.Min(max,x));
					pZoneTerminationDistanceTicks = x;
					nud_ZoneTerminationDistanceTicks.Text = x.ToString();
				}else if(e.Delta>0){
					x = x + 1;
					x = Math.Max(min, Math.Min(max,x));
					pZoneTerminationDistanceTicks = x;
					nud_ZoneTerminationDistanceTicks.Text = x.ToString();
				}
				ForceRefresh();
			};
			if(pZoneTerminationType == ARC_AT_Trader_ZoneType.ATR){
				lbl_ZoneTerminationDistanceATRMult.Visibility = Visibility.Visible;
				nud_ZoneTerminationDistanceATRMult.Visibility = Visibility.Visible;
				nud_ZoneTerminationDistanceATRMult.Background = Brushes.DarkCyan;
				lbl_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
				nud_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
			}else if(pZoneTerminationType == ARC_AT_Trader_ZoneType.Ticks){
				lbl_ZoneTerminationDistanceTicks.Visibility = Visibility.Visible;
				nud_ZoneTerminationDistanceTicks.Visibility = Visibility.Visible;
				nud_ZoneTerminationDistanceTicks.Background = Brushes.DarkCyan;
				lbl_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
				nud_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
			}else{
				lbl_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
				nud_ZoneTerminationDistanceTicks.Visibility = Visibility.Collapsed;
				lbl_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
				nud_ZoneTerminationDistanceATRMult.Visibility = Visibility.Collapsed;
			}

			nud_ZoneTerminationDistanceTicks.SetValue(Grid.ColumnProperty, 1);
            nud_ZoneTerminationDistanceTicks.SetValue(Grid.RowProperty, row);
            grid.Children.Add(lbl_ZoneTerminationDistanceTicks);
            grid.Children.Add(nud_ZoneTerminationDistanceTicks);
			#endregion

			MenuControl.Items.Add(grid);
			#endregion

			MenuControl.Items.Add(new Separator());

			#region -- Show Historical Signals --
			miHistoricalSignalsOnOff   = new MenuItem { Header = "Historical Signals? "+(pShowHistoricalSignals ? "ON":"OFF"),         Name = "ShowHistoricalSignals"+uID,       Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.pShowHistoricalSignals,   StaysOpenOnClick = true };
			miHistoricalSignalsOnOff.Click += delegate (object o, RoutedEventArgs e)
			{
				this.pShowHistoricalSignals = !this.pShowHistoricalSignals;
				if(ChartControl != null){
					if (ChartControl.Dispatcher.CheckAccess()) {
						InformUserAboutRecalculation();
						miHistoricalSignalsOnOff.IsChecked = pShowHistoricalSignals;
						miHistoricalSignalsOnOff.Header = "Historical Signals? "+(pShowHistoricalSignals ? "ON":"OFF");
						ForceRefresh();
					}else{
						Dispatcher.BeginInvoke(new Action(() =>
						{
							InformUserAboutRecalculation();
							miHistoricalSignalsOnOff.IsChecked = pShowHistoricalSignals;
							miHistoricalSignalsOnOff.Header = "Historical Signals? "+(pShowHistoricalSignals ? "ON":"OFF");
							ForceRefresh();
						}));
					}
				}
			};
			MenuControl.Items.Add(miHistoricalSignalsOnOff);
			#endregion

			MenuControl.Items.Add(new Separator());

			#region -- Recalc --
			miRecalculate1 = new MenuItem { Header = "RE-CALCULATE", HorizontalAlignment = HorizontalAlignment.Center , Foreground = Brushes.Black, FontWeight = FontWeights.Normal , StaysOpenOnClick = false };
			miRecalculate1.Click += delegate (object o, RoutedEventArgs e){
				e.Handled = true;
				ResetRecalculationUI();
				System.Windows.Forms.SendKeys.SendWait("{F5}");
			};
			MenuControl.Items.Add(miRecalculate1);
			#endregion

			indytoolbar.Children.Add(MenuControlContainer);
		}

        #region private void menuTxtbox_KeyDownInteger()
        private void menuTxtbox_KeyDownInteger(object sender, System.Windows.Input.KeyEventArgs e)
        {
            e.Handled = true;
            TextBox txtBoxSender = sender as TextBox;
			int max = int.MaxValue;
			int min = 0;
			string startval = txtBoxSender.Text;

//Print("      max: "+max+"  min: "+min);
			try{
	            int keyVal = (int)e.Key;
	            int value = -1;
	            if (keyVal >= (int)System.Windows.Input.Key.D0 && keyVal <= (int)System.Windows.Input.Key.D9) 
					value = keyVal - (int)System.Windows.Input.Key.D0;
	            else if (keyVal >= (int)System.Windows.Input.Key.NumPad0 && keyVal <= (int)System.Windows.Input.Key.NumPad9) 
					value = keyVal - (int)System.Windows.Input.Key.NumPad0;

	            bool isNumeric = (e.Key >= System.Windows.Input.Key.D0 && e.Key <= System.Windows.Input.Key.D9) || (e.Key >= System.Windows.Input.Key.NumPad0 && e.Key <= System.Windows.Input.Key.NumPad9);

//Print("IsNumberic: "+isNumeric.ToString());

				if (isNumeric || e.Key == System.Windows.Input.Key.Back)
    	        {
	                string newText    = value != -1 ? value.ToString() : "";
    	            int tbPosition    = txtBoxSender.SelectionStart;
        	        txtBoxSender.Text = txtBoxSender.SelectedText == "" ? txtBoxSender.Text.Insert(tbPosition, newText) : txtBoxSender.Text.Replace(txtBoxSender.SelectedText, newText);
            	    txtBoxSender.Select(tbPosition + 1, 0);
					int x = string.IsNullOrEmpty(txtBoxSender.Text.Trim()) ? min : Convert.ToInt32(txtBoxSender.Text);
					x = Math.Max(min, Math.Min(max,x));
					txtBoxSender.Text = x.ToString();
//Print("     text: "+txtBoxSender.Text);
				}
			}catch{
				txtBoxSender.Text = startval;
            }
        }
        #endregion
        #region private void menuTxtbox_KeyDownDouble()
        private void menuTxtbox_KeyDownDouble(object sender, System.Windows.Input.KeyEventArgs e)
        {
            e.Handled = true;
            TextBox txtBoxSender = sender as TextBox;
			double max = double.MaxValue;
			double min = 0;
			string startval = txtBoxSender.Text;

//Print("      max: "+max+"  min: "+min);
			try{
	            int keyVal = (int)e.Key;
	            double value = -1;
	            if (keyVal >= (int)System.Windows.Input.Key.D0 && keyVal <= (int)System.Windows.Input.Key.D9) 
					value = keyVal - (int)System.Windows.Input.Key.D0;
	            else if (keyVal >= (int)System.Windows.Input.Key.NumPad0 && keyVal <= (int)System.Windows.Input.Key.NumPad9) 
					value = keyVal - (int)System.Windows.Input.Key.NumPad0;

	            bool isNumeric = (e.Key >= System.Windows.Input.Key.D0 && e.Key <= System.Windows.Input.Key.D9) || (e.Key >= System.Windows.Input.Key.NumPad0 && e.Key <= System.Windows.Input.Key.NumPad9);

//Print("IsNumeric: "+isNumeric.ToString()+"  e.Key: "+e.Key.ToString());

				if (isNumeric || e.Key == System.Windows.Input.Key.OemPeriod || e.Key == System.Windows.Input.Key.Back)
    	        {
	                string newText    = e.Key == System.Windows.Input.Key.OemPeriod ? "." : (value != -1 ? value.ToString() : "");
//    	            int tbPosition    = txtBoxSender.SelectionStart;
//        	        txtBoxSender.Text = txtBoxSender.SelectedText == "" ? txtBoxSender.Text.Insert(tbPosition, newText) : txtBoxSender.Text.Replace(txtBoxSender.SelectedText, newText);
//            	    txtBoxSender.Select(tbPosition + 1, 0);
					double x = string.IsNullOrEmpty(txtBoxSender.Text.Trim()) ? min : Convert.ToDouble(txtBoxSender.Text);
//					x = Math.Max(min, Math.Min(max,x));
//					txtBoxSender.Text = x.ToString();
//Print("     text: "+txtBoxSender.Text);
				}
			}catch{
				txtBoxSender.Text = startval;
            }
        }
        #endregion
//=====================================================================================================
		private void InformUserAboutRecalculation(){
			if(ChartControl != null){
				if (ChartControl.Dispatcher.CheckAccess()) {
					miRecalculate1.Background = Brushes.Yellow;
					miRecalculate1.FontWeight = FontWeights.Bold;
					miRecalculate1.FontStyle  = FontStyles.Italic;
				}else{
					Dispatcher.BeginInvoke(new Action(() =>
					{
						miRecalculate1.Background = Brushes.Yellow;
						miRecalculate1.FontWeight = FontWeights.Bold;
						miRecalculate1.FontStyle  = FontStyles.Italic;
					}));
				}
			}
		}
		private void ResetRecalculationUI(){
			if(ChartControl != null){
				if (ChartControl.Dispatcher.CheckAccess()) {
					miRecalculate1.FontWeight = FontWeights.Normal;
					miRecalculate1.FontStyle  = FontStyles.Normal;
					miRecalculate1.Background = null;
				}else{
					Dispatcher.BeginInvoke(new Action(() =>
					{
						miRecalculate1.FontWeight = FontWeights.Normal;
						miRecalculate1.FontStyle  = FontStyles.Normal;
						miRecalculate1.Background = null;
					}));
				}
			}
		}
//=====================================================================================================
		#region private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0) return;
			TabItem tabItem = e.AddedItems[0] as System.Windows.Controls.TabItem;
			if (tabItem == null) return;
			ChartTab temp = tabItem.Content as ChartTab;
			if (temp != null && indytoolbar != null)
				indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
		}
		#endregion

		#endregion
//===========================================================================================================
		#region -- DrawSpecificMarkerType --
		private string DrawSpecificMarkerType(string tag, ARC_AT_Trader_MarkerType MarkerType, char TrendOrBreak, char Dir, int abar, double price, Brush clr){
			if(ChartControl == null) return null;
//			MarkersThisBar = MarkersThisBar+1;
//			if(MarkersThisBar>1){//stagger multiple arrows on same bar
//				if(Dir=='L') price = price - MarkersThisBar * Math.Max(1,this.pMarkerSeparation)*TickSize;
//				else price = price + MarkersThisBar * Math.Max(1,this.pMarkerSeparation)*TickSize;
//			}
			var t = Times[0].GetValueAt(abar);
			var info = TrendOrBreak == 'T'? "Trend":"Break";
			tag = string.Format("att_{0}-{1}-{2}-{3}", tag, info, abar, Dir);
			if (ChartControl.Dispatcher.CheckAccess()) {
//Print("CheckAccess = true  Dir: "+Dir);
				if(MarkerType == ARC_AT_Trader_MarkerType.Dot)
					Draw.Dot(this, tag, true, t, price, clr);
				else if(MarkerType == ARC_AT_Trader_MarkerType.Diamond)
					Draw.Diamond(this, tag, true, t, price, clr);
				else if(MarkerType == ARC_AT_Trader_MarkerType.Square)
					Draw.Square(this, tag, true, t, price, clr);
				else if(MarkerType == ARC_AT_Trader_MarkerType.Arrow){
					if(Dir=='L')
						Draw.ArrowUp(this, tag, true, t, price, clr);
					else
						Draw.ArrowDown(this, tag, true, t, price, clr);
				}else if(MarkerType == ARC_AT_Trader_MarkerType.Triangle){
					if(Dir=='L')
						Draw.TriangleUp(this, tag, true, t, price, clr);
					else
						Draw.TriangleDown(this, tag, true, t, price, clr);
				}
			}else{
				Dispatcher.BeginInvoke(new Action(() =>
				{
//Print("CheckAccess = false  Dir: "+Dir);
					if(MarkerType == ARC_AT_Trader_MarkerType.Dot)
						TriggerCustomEvent(o2 =>{	
							Draw.Dot(this, tag, true, t, price, clr);
						},0,null);
					else if(MarkerType == ARC_AT_Trader_MarkerType.Diamond)
						TriggerCustomEvent(o2 =>{	
							Draw.Diamond(this, tag, true, t, price, clr);
						},0,null);
					else if(MarkerType == ARC_AT_Trader_MarkerType.Square)
						TriggerCustomEvent(o2 =>{	
							Draw.Square(this, tag, true, t, price, clr);
						},0,null);
					else if(MarkerType == ARC_AT_Trader_MarkerType.Arrow){
						if(Dir=='L')
							TriggerCustomEvent(o2 =>{	
								Draw.ArrowUp(this, tag, true, t, price, clr);
							},0,null);
						else
							TriggerCustomEvent(o2 =>{	
								Draw.ArrowDown(this, tag, true, t, price, clr);
							},0,null);
					}else if(MarkerType == ARC_AT_Trader_MarkerType.Triangle){
						if(Dir=='L')
							TriggerCustomEvent(o2 =>{	
								Draw.TriangleUp(this, tag, true, t, price, clr);
							},0,null);
						else
							TriggerCustomEvent(o2 =>{	
								Draw.TriangleDown(this, tag, true, t, price, clr);
							},0,null);
					}
				}));
			}

			return tag;
		}
		#endregion
//===========================================================================================================
		#region -- Mouse handler --
		int MouseX=0;
//		int MouseY=0;
		int MouseABar = -1;
        private void OnMouseMove(object sender, MouseEventArgs e)
        {
			#region -- OnMouseMove -----------------------------------------------------------
			Point coords = e.GetPosition(ChartPanel);
			MouseX = ChartingExtensions.ConvertToHorizontalPixels(coords.X, ChartControl.PresentationSource);//+ barwidth_int;
//			MouseY = ChartingExtensions.ConvertToVerticalPixels(coords.Y, ChartControl.PresentationSource);
			MouseABar = ChartBars.GetBarIdxByX(ChartControl, MouseX);
			if(Keyboard.IsKeyDown(Key.LeftShift)) {
				if(IsDebug) Print("Cleared the viewers");
				view_these_keys.Clear();
			}
			#endregion

		}
		private List<Tuple<int,int>> view_these_keys = new List<Tuple<int,int>> ();
		//=========================================================================================
		private void OnMouseUp(object sender, MouseButtonEventArgs e)
		{
			if(MouseABar>0 && Keyboard.IsKeyDown(Key.LeftShift)){
				view_these_keys.Clear();
				var printed_blank_line = false;
				var keys = UpTLs.Keys.Where(k=>k.Item1<=MouseABar && k.Item2>=MouseABar).ToList();
				if(keys!=null)
					foreach(var k in keys){
						view_these_keys.Add(k);
						if(!printed_blank_line){Print("");	printed_blank_line = true;}
//						TriggerCustomEvent(o1 =>{  
//							Draw.Dot(this,"Up",false,Times[0].GetValueAt(k.Item1), UpTLs[k].StartPrice,Brushes.Yellow);
//						},0,null);
						Print("Up TL "+k.ToString()+"\n"+TLToString(UpTLs[k]));
					}
				printed_blank_line = false;
				keys = DownTLs.Keys.Where(k=>k.Item1<=MouseABar && k.Item2>=MouseABar).ToList();
				if(keys!=null)
					foreach(var k in keys){
						view_these_keys.Add(k);
						if(!printed_blank_line){Print("");	printed_blank_line = true;}
//						TriggerCustomEvent(o1 =>{  
//							Draw.Dot(this,"Down",false,Times[0].GetValueAt(k.Item1), DownTLs[k].StartPrice,Brushes.Yellow);
//						},0,null);
						Print("Down TL "+k.ToString()+"\n"+TLToString(DownTLs[k]));
					}
				MouseABar = -1;
			}
			ForceRefresh();
		}
		#endregion
//===========================================================================================================

		private DateTime t = DateTime.MinValue;
		private List<Tuple<int,int>> KeysOfLinesToDelete = new List<Tuple<int,int>>();
		protected override void OnBarUpdate()
		{
#if DoLicense
			if(!ValidLicense) {
				this.IsVisible = false;
				if(this.NewCustId<=0)
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Your ARCAI Contact Id is not present\n"+MachineId+"\n\nPlease run the latest ARC_LicenseActivator indicator\n\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			#region -- ATR --
			if (CurrentBar < pATRperiod)
				atr[0] = High[0] - Low[0];
			else
			{
				double trueRange = Math.Max(Math.Abs(Low[0] - Close[1]), Math.Max(High[0] - Low[0], Math.Abs(High[0] - Close[1])));
				atr[0]			 = ((Math.Min(CurrentBar + 1, pATRperiod) - 1 ) * atr[1] + trueRange) / Math.Min(CurrentBar + 1, pATRperiod);
			}
			#endregion

			if(CurrentBar<pSwingStrength*2) return;
try{
            #region --- Calculate and Draw ZigZag ---

			if (pThisInputType == ARC_AT_Trader_InputType.High_Low)
                swingInput[0] = Input[0];
            else if (pThisInputType == ARC_AT_Trader_InputType.Close)
                swingInput[0] = Close[0];

            #region -- Init zigzag states --    
            if (CurrentBar < 2)
            {
                upTrend[0] = true;
            }
            #endregion

            #region else if (Calculate == Calculate.OnBarClose)
            else if (Calculate == Calculate.OnBarClose)
            {
                bool useHL = pThisInputType == ARC_AT_Trader_InputType.High_Low;

                zigzagDeviation = pMultiplierMD * atr[0];
                swingMax = MAX(useHL ? High : Input, pSwingStrength)[1];
                swingMin = MIN(useHL ? Low  : Input, pSwingStrength)[1];

				updateHigh =  upTrend[1] && (useHL ? High[0]   : swingInput[0]) > currentHigh;
                updateLow  = !upTrend[1] && (useHL ? Low[0]    : swingInput[0]) < currentLow;
                addHigh    = !upTrend[1] && !((useHL ? Low[0]  : swingInput[0]) < currentLow)  && (useHL ? High[0] : swingInput[0]) > Math.Max(swingMax, currentLow + zigzagDeviation);
                addLow     =  upTrend[1] && !((useHL ? High[0] : swingInput[0]) > currentHigh) && (useHL ? Low[0]  : swingInput[0]) < Math.Min(swingMin, currentHigh - zigzagDeviation);

                upTrend[0] = upTrend[1];

                #region -- New High --
                if (addHigh)
                {
                    upTrend[0] = true;
                    int lookback = CurrentBar - lastLowIdx;
//                    swingLowType[lookback] = pre_swingLowType[lookback];
                    double newHigh = double.MinValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBar - lastLowIdx; i++)
                    {
                        if ((useHL ? High[i] : swingInput[i]) > newHigh)
                        {
                            newHigh = (useHL ? High[i] : swingInput[i]);
                            j = i;
                        }
                    }
					newHigh = Instrument.MasterInstrument.RoundToTickSize(newHigh);
                    currentHigh = newHigh;
                    priorSwingHighIdx = lastHighIdx;
                    lastHighIdx = CurrentBar - j;
					SwingHighABars.Insert(0, new Tuple<int,double>(lastHighIdx, newHigh));
                }
                #endregion

                #region -- uptrend --
                else if (updateHigh)
                {
                    upTrend[0] = true;
                    currentHigh = Instrument.MasterInstrument.RoundToTickSize(useHL ? High[0] : swingInput[0]);
                    lastHighIdx = CurrentBar;
					SwingHighABars[0] = new Tuple<int,double>(lastHighIdx, currentHigh);
                }
                #endregion

                #region -- New Low --
                else if (addLow)
                {
                    upTrend[0] = false;
                    int lookback = CurrentBar - lastHighIdx;
//                    swingHighType[lookback] = pre_swingHighType[lookback];
                    double newLow = double.MaxValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBar - lastHighIdx; i++)
                    {
                        if ((useHL ? Low[i] : swingInput[i]) < newLow)
                        {
                            newLow = (useHL ? Low[i] : swingInput[i]);
                            j = i;
                        }
                    }
					newLow = Instrument.MasterInstrument.RoundToTickSize(newLow);
                    currentLow = newLow;
                    priorSwingLowIdx = lastLowIdx;
                    lastLowIdx = CurrentBar - j;
					SwingLowABars.Insert(0, new Tuple<int,double>(lastLowIdx, newLow));
                }
                #endregion

                #region -- dwtrend --
                else if (updateLow)
                {
                    upTrend[0] = false;
                    currentLow = Instrument.MasterInstrument.RoundToTickSize(useHL ? Low[0] : swingInput[0]);
                    lastLowIdx = CurrentBar;
					SwingLowABars[0] = new Tuple<int,double>(lastLowIdx, currentLow);
                }
                #endregion

                #region -- BUY || HH --
                if (addHigh || updateHigh)
                {
                    int priorHighCount = CurrentBar - priorSwingHighIdx;
                    int priorLowCount = CurrentBar - priorSwingLowIdx;
                    highCount = CurrentBar - lastHighIdx;
                    lowCount = CurrentBar - lastLowIdx;
                }
                #endregion

                #region -- DW || LL --
                else if (addLow || updateLow)
                {
                    int priorLowCount = CurrentBar - priorSwingLowIdx;
                    int priorHighCount = CurrentBar - priorSwingHighIdx;
                    lowCount = CurrentBar - lastLowIdx;
                    highCount = CurrentBar - lastHighIdx;
                }
                #endregion

            }
            #endregion

            #region else if (IsFirstTickOfBar)
            else if (IsFirstTickOfBar)
            {
                bool useHL = pThisInputType == ARC_AT_Trader_InputType.High_Low;
                zigzagDeviation = pMultiplierMD * atr[1];
                swingMax = MAX(useHL ? High : Input, pSwingStrength)[2];
                swingMin = MIN(useHL ? Low : Input, pSwingStrength)[2];

                updateHigh = upTrend[1] && (useHL ? High[1] : swingInput[1]) > currentHigh;
                updateLow = !upTrend[1] && (useHL ? Low[1] : swingInput[1]) < currentLow;
                addHigh = !upTrend[1] && !((useHL ? Low[1] : swingInput[1]) < currentLow) && (useHL ? High[1] : swingInput[1]) > Math.Max(swingMax, currentLow + zigzagDeviation);
                addLow = upTrend[1] && !((useHL ? High[1] : swingInput[1]) > currentHigh) && (useHL ? Low[1] : swingInput[1]) < Math.Min(swingMin, currentHigh - zigzagDeviation);

                upTrend[0] = upTrend[1];

                #region -- New High --
                if (addHigh)
                {
                    upTrend[0] = true;
                    int lookback = CurrentBar - lastLowIdx;
                    double newHigh = double.MinValue;
                    int j = 0;
                    for (int i = 1; i < CurrentBar - lastLowIdx; i++)
                    {
                        if ((useHL ? High[i] : swingInput[i]) > newHigh)
                        {
                            newHigh = (useHL ? High[i] : swingInput[i]);
                            j = i;
                        }
                    }
					newHigh = Instrument.MasterInstrument.RoundToTickSize(newHigh);
                    currentHigh = newHigh;
                    priorSwingHighIdx = lastHighIdx;
                    lastHighIdx = CurrentBar - j;
					SwingHighABars.Insert(0, new Tuple<int,double>(lastHighIdx, newHigh));
                }
                #endregion

                #region -- UPtrend --
                else if (updateHigh)
                {
                    upTrend[0] = true;
                    currentHigh = Instrument.MasterInstrument.RoundToTickSize(useHL ? High[1] : swingInput[1]);
                    lastHighIdx = CurrentBar - 1;
					SwingHighABars[0] = new Tuple<int,double>(lastHighIdx, currentHigh);
                }
                #endregion

                #region -- New Low --
                else if (addLow)
                {
                    upTrend[0] = false;
                    int lookback = CurrentBar - lastHighIdx;
//                    swingHighType[lookback] = pre_swingHighType[lookback];
                    double newLow = double.MaxValue;
                    int j = 0;
                    for (int i = 1; i < CurrentBar - lastHighIdx; i++)
                    {
                        if ((useHL ? Low[i] : swingInput[i]) < newLow)
                        {
                            newLow = (useHL ? Low[i] : swingInput[i]);
                            j = i;
                        }
                    }
					newLow = Instrument.MasterInstrument.RoundToTickSize(newLow);
                    currentLow = newLow;
                    priorSwingLowIdx = lastLowIdx;
                    lastLowIdx = CurrentBar - j;
					SwingLowABars.Insert(0, new Tuple<int,double>(lastLowIdx, currentLow));
                }
                #endregion

                #region -- DWtrend --
                else if (updateLow)
                {
                    upTrend[0] = false;
                    currentLow = Instrument.MasterInstrument.RoundToTickSize(useHL ? Low[1] : swingInput[1]);
                    lastLowIdx = CurrentBar - 1;
					SwingLowABars[0] = new Tuple<int,double>(lastLowIdx, currentLow);
                }
                #endregion

                #region -- BUY || HH --
                if (addHigh || updateHigh)
                {
                    int priorHighCount = CurrentBar - priorSwingHighIdx;
                    highCount = CurrentBar - lastHighIdx;
                    lowCount = CurrentBar - lastLowIdx;
                }
                #endregion

                #region -- DW || LL --
                else if (addLow || updateLow)
                {
                    int priorLowCount = CurrentBar - priorSwingLowIdx;
                    lowCount = CurrentBar - lastLowIdx;
                    highCount = CurrentBar - lastHighIdx;
                }
                #endregion
            }
            #endregion

			#region if (Calculate != Calculate.OnBarClose)
            if (Calculate != Calculate.OnBarClose)
            {
                bool useHL = pThisInputType == ARC_AT_Trader_InputType.High_Low;

                intraBarUpdateHigh = upTrend[0]  && (useHL ? High[0] :   swingInput[0]) > currentHigh;
                intraBarUpdateLow  = !upTrend[0] && (useHL ? Low[0] :    swingInput[0]) < currentLow;
                intraBarAddHigh    = !upTrend[0] && !((useHL ? Low[0] :  swingInput[0]) < currentLow) && (useHL ? High[0] : swingInput[0]) > Math.Max(swingMax, currentLow + zigzagDeviation);
                intraBarAddLow     = upTrend[0]  && !((useHL ? High[0] : swingInput[0]) > currentHigh) && (useHL ? Low[0] : swingInput[0]) < Math.Min(swingMin, currentHigh - zigzagDeviation);

                #region -- new HH --
                if (intraBarAddHigh)
                {
                    double newHigh = double.MinValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBar - lastLowIdx; i++)
                    {
                        if ((useHL ? High[i] : swingInput[i]) > newHigh)
                        {
                            newHigh = (useHL ? High[i] : swingInput[i]);
                            j = i;
                        }
                    }
                    preCurrentHigh = newHigh;
                    preLastHighIdx = CurrentBar - j;
                }
                #endregion

                #region -- uptrend --
                else if (intraBarUpdateHigh)
                {
                    preCurrentHigh = (useHL ? High[0] : swingInput[0]);
                    preLastHighIdx = CurrentBar;
                }
                #endregion

                #region -- new LL --
                if (intraBarAddLow)
                {
                    double newLow = double.MaxValue;
                    int j = 0;
                    for (int i = 0; i < CurrentBar - lastHighIdx; i++)
                    {
                        if ((useHL ? Low[i] : swingInput[i]) < newLow)
                        {
                            newLow = useHL ? Low[i] : swingInput[i];
                            j = i;
                        }
                    }
                    preCurrentLow = newLow;
                    preLastLowIdx = CurrentBar - j;
                }
                #endregion

                #region -- dwtrend --
                else if (intraBarUpdateLow)
                {
                    preCurrentLow = (useHL ? Low[0] : swingInput[0]);
                    preLastLowIdx = CurrentBar;
                }
                #endregion

                #region -- BUY || HH --
                if (intraBarAddHigh || intraBarUpdateHigh)
                {
                    int prePriorHighCount = intraBarAddHigh ? CurrentBar - lastHighIdx : CurrentBar - priorSwingHighIdx;
                    int preHighCount     = CurrentBar - preLastHighIdx;
                    int prePriorLowCount = CurrentBar - priorSwingLowIdx;
                    int preLowCount      = CurrentBar - lastLowIdx;
                }
                #endregion

                #region -- DW || LL --
                else if (intraBarAddLow || intraBarUpdateLow)
                {
                    int prePriorLowCount = intraBarAddLow ? CurrentBar - lastLowIdx : CurrentBar - priorSwingLowIdx;
                    int preLowCount = CurrentBar - preLastLowIdx;
                    int prePriorHighCount = CurrentBar - priorSwingHighIdx;
                    int preHighCount = CurrentBar - lastHighIdx;
                }
                #endregion

            }
            #endregion

			int cutoffIdx = int.MinValue;
			int cb = CurrentBar;
			if(State==State.Historical) cb = Bars.Count;

            #endregion

			if(CurrentBar < Math.Min(FirstABar_TrendContinuingSignals, FirstABar_BreakSignals)) return;
			bool ShowSignals = State == State.Realtime || pShowHistoricalSignals;
			if(IsFirstTickOfBar){
				if(pTrendContinuingSignalType == ARC_AT_Trader_SignalType.ATRmult)
					TouchDistancePts = atr[0] * this.pTrendContinuingDistanceATRMult/2;
				if(pBreakSignalType == ARC_AT_Trader_SignalType.ATRmult)
					BreakDistancePts = atr[0] * this.pBreakDistanceATRMult/2;
				if(pZoneTerminationType == ARC_AT_Trader_ZoneType.ATR)
					TerminationDistancePts = atr[0] * this.pZoneTerminationDistanceATRMult/2;
				if(upTrend[0] && SwingLowABars.Count>2){
					#region -- Create Up trendlines --
					start_barsago   = CurrentBar-SwingLowABars[1].Item1;
					end_barsago 	= CurrentBar-SwingLowABars[0].Item1;
					if(end_barsago != start_barsago && start_barsago>0 && end_barsago>0){
						var point = Tuple.Create(SwingLowABars[1].Item1, SwingLowABars[0].Item1);
						if(!UpTLs.ContainsKey(point)){
							double p0 = SwingLowABars[1].Item2;//Instrument.MasterInstrument.RoundToTickSize(Low.GetValueAt(point.Item1));
							double p1 = SwingLowABars[0].Item2;//Instrument.MasterInstrument.RoundToTickSize(Low.GetValueAt(point.Item2));
							LowSwings[point.Item1] = p0;
							LowSwings[point.Item2] = p1;
							if(p0 < p1){
//Print(point.ToString()+"    start rbar: "+start_barsago+"   end rbar: "+end_barsago+"   Start price: "+p0+"  end: "+p1);
								UpTLs[point] = new TLData(p0, p1, point, CurrentBar);//line is created, but not validated yet
								UpTLs[point].TL_DeviationPts   = (pZoneType==ARC_AT_Trader_ZoneType.Ticks ? deviationPts : atr.GetValueAt(point.Item2) * this.pTLTouchPointsATRMult);
								if(pMinTouchPoints == 2){
									UpTLs[point].IsValidated       = true;
									UpTLs[point].ValidationABar    = CurrentBar;//point.Item2;
									UpTLs[point].PriceAtValidation = UpTLs[point].CurrentBarPrice;
									UpTLs[point].MaxABar           = point.Item2 + pMaxAgeInBars;
									UpTLs[point].TouchDistancePts  = TouchDistancePts;
									UpTLs[point].BreakDistancePts  = BreakDistancePts;
									UpTLs[point].TerminationDistancePts  = TerminationDistancePts;
//									Draw.Line(this, point.ToString(), false, Time.GetValueAt(point.Item1), UpTLs[point].StartPrice, Time.GetValueAt(point.Item2), UpTLs[point].EndPrice, Brushes.Red, DashStyleHelper.Solid, 3);
//								}else{
//									Draw.Line(this, point.ToString(), false, Time.GetValueAt(point.Item1), UpTLs[point].StartPrice, Time.GetValueAt(point.Item2), UpTLs[point].EndPrice, Brushes.Yellow, DashStyleHelper.Solid, 3);
								}
							}
						}
					}
					#endregion
				}
//var dt = new DateTime(2022,4,21,9,30,0);
				#region -- Update existing Up Trendlines --
				var TLs = UpTLs.Where(k=> /*Time.GetValueAt(k.Key.Item1)>=dt && */k.Value.IsLineEnabled).Select(k=>k.Key).ToList();
				if(TLs != null && TLs.Count>0){
					KeysOfLinesToDelete.Clear();
					foreach(var k in TLs){
						int confirmedtouches = pMinTouchPoints == 2 ? 0 : 2;//do not count touches if pMinTouchPoints==2
						for(int abar = (pMinTouchPoints==2 ? k.Item2 : Math.Max(CurrentBar-10,UpTLs[k].AlertedABar)); abar <= CurrentBar; abar++)
						{
//t = Times[0].GetValueAt(abar);
//z = t>=dt && (t.Minute>=32 || t.Minute<=33) && UpTLs[k].EndPrice == 78.58;
							double H = High.GetValueAt(abar);
							double L = Low.GetValueAt(abar);
							UpTLs[k].CalcPrice(abar, k);
							if(abar==CurrentBar){//determine Touch or Break signal
								double O = Open.GetValueAt(abar);
								double C = Close.GetValueAt(abar);
								string res = CalcTouchAlert(UpTLs[k], O, H, L, C, CurrentBar, this.pMaxTrendContinuingSignals);
								res = CalcBreakAlert(UpTLs[k], O, H, L, C, BreakBarRequirementChar, CurrentBar, z);
//if(z){
//	Print(Environment.NewLine+t.ToString()+"   "+res);
//	if(!double.IsNaN(UpTLs[k].BreakAlertPrice) && UpTLs[k].IsBreakAlertEnabled)
//		Draw.Dot(this,string.Format("br{0}{1}",k.ToString(),abar), false, 0, UpTLs[k].BreakAlertPrice, Brushes.Yellow);
//	if(UpTLs[k].IsBreakAlertEnabled) Draw.Diamond(this,string.Format("bae{0}{1}",k.ToString(),abar), false, 0, Lows[0].GetValueAt(abar)-0.1, Brushes.Yellow);
//}
								res = CalcZoneTermination(UpTLs[k], O, H, L, C, TerminationBarRequirementChar, CurrentBar, z);
//if(z){
////	Print(Environment.NewLine+t.ToString()+"   "+TLToString(UpTLs[k]));
//	Print("3386  "+res);
//	Print("IsZoneTerminated: "+UpTLs[k].IsZoneTerminated.ToString()+"  BreakAlertFired: "+UpTLs[k].BreakAlertFired.ToString()+"      IsLineEnabled?: "+UpTLs[k].IsLineEnabled.ToString());
//	if(!double.IsNaN(UpTLs[k].ZoneTerminationPrice))
//		Draw.Dot(this,string.Format("zt{0}{1}",k.ToString(),abar), false, 0, UpTLs[k].ZoneTerminationPrice, Brushes.Red);
//	Print("");
//}
								res = UpTLs[k].CalcIsLineEnabled(abar);
//if(z){
//	Print("2773  "+res);
//	Print("IsZoneTerminated: "+UpTLs[k].IsZoneTerminated.ToString()+"  BreakAlertFired: "+UpTLs[k].BreakAlertFired.ToString()+"      IsLineEnabled?: "+UpTLs[k].IsLineEnabled.ToString());
//	Print("");
//}
								if(UpTLs[k].AlertStatus == 'T'){
									UpTLs[k].TouchAlertPrice = double.NaN;
									UpTLs[k].AlertStatus = ' ';
									if(State==State.Realtime) Alert(CurrentBar.ToString(), Priority.High, "AT_Trader upward TL Touched", AddSoundFolder(this.pTrendContinuingBuyWAV), 0, Brushes.Green, Brushes.White);
//if(z)Print(1997);
									if(ShowSignals && CurrentBar > FirstABar_TrendContinuingSignals) DrawSpecificMarkerType(totime(k.Item1), this.pTrendContinuingMarkerType, 'T', 'L', abar, L-TickSize, pBuyMarkerBrush);
								}
								if(UpTLs[k].AlertStatus == 'B'){
									UpTLs[k].AlertStatus = ' ';
									UpTLs[k].IsBroken = true;
									if(State==State.Realtime) Alert(CurrentBar.ToString(), Priority.High, "AT_Trader upward TL Broken", AddSoundFolder(this.pBreakSellWAV), 0, Brushes.Red, Brushes.White);
//if(z)Print(2005);
									if(ShowSignals && CurrentBar > FirstABar_BreakSignals) {
										DrawSpecificMarkerType(totime(k.Item1), this.pBreakMarkerType, 'B', 'S', abar, H+TickSize, pSellMarkerBrush);
										UpTLs[k].TriggerDotPrice = UpTLs[k].BreakAlertPrice; 
									}
									UpTLs[k].BreakAlertPrice = double.NaN;
								}
							}
//z = t.Day==26 && t.Hour>14;
							double devpts = UpTLs[k].TL_DeviationPts;
							double lvl1 = UpTLs[k].CurrentBarPrice + devpts/2;
							double lvl2 = UpTLs[k].CurrentBarPrice - devpts/2;
							if(pMinTouchPoints>2 && L < lvl1 && !UpTLs[k].IsValidated){
								confirmedtouches++;
//if(z) Print(t.ToString()+"  "+k.ToString()+"  Confirmed upTL touch "+confirmedtouches);
							}
//Print("   TL$: "+UpTLs[k].CurrentBarPrice+"   L: "+L);
//							if(Close.GetValueAt(abar) < lvl2){// || (UpTLs[k].MaxABar>0 && CurrentBar > UpTLs[k].MaxABar)){
////Print(t.ToString()+"   upTL broken!  cb: "+CurrentBar+"  maxabar: "+UpTLs[k].MaxABar);
//								UpTLs[k].IsBroken = true;
//								break;
//							}else 
							if(pMinTouchPoints>2 && confirmedtouches >= pMinTouchPoints){
//if(z) Print(t.ToString()+"   Validated upTL - DevPts "+devpts);
								//RemoveDrawObject(k.ToString());
								UpTLs[k].IsValidated        = true;
								UpTLs[k].ValidationABar     = abar;
								UpTLs[k].PriceAtValidation  = UpTLs[k].CurrentBarPrice;
								UpTLs[k].MaxABar			= abar + pMaxAgeInBars;
								UpTLs[k].TouchDistancePts	= TouchDistancePts;
								UpTLs[k].BreakDistancePts   = BreakDistancePts;
								UpTLs[k].TerminationDistancePts = TerminationDistancePts;
//								UpTLs[k].TL_DeviationPts	= devpts;
								#region -- If any new trendlines start at one of these touchpoints of an older trendline, then remove that new trendline
								var deletethese = UpTLs.Where(a=>a.Key.Item1 == k.Item2).Select(a=>a.Key).ToList();
								foreach(var tl in deletethese) KeysOfLinesToDelete.Add(tl);
								#endregion
//if(z) Print(t.ToString()+"   "+TLToString(UpTLs[k]));
								break;//this is a validated line, stop indexing thru the subsequent price bars
							}
						}
					}
				}
				foreach(var tl in KeysOfLinesToDelete) UpTLs.Remove(tl);
				#endregion

				if(!upTrend[0] && SwingHighABars.Count>2){
					#region -- Create Down trendlines --
					start_barsago = CurrentBar-SwingHighABars[1].Item1;//swing.SwingHighBar(COBCoffset, 2, CurrentBar);
					end_barsago   = CurrentBar-SwingHighABars[0].Item1;//swing.SwingHighBar(COBCoffset, 1, CurrentBar);
					if(end_barsago != start_barsago && start_barsago>0 && end_barsago>0){
						var point = Tuple.Create(SwingHighABars[1].Item1, SwingHighABars[0].Item1);
						if(!DownTLs.ContainsKey(point)){
							double p0 = SwingHighABars[1].Item2;//Instrument.MasterInstrument.RoundToTickSize(High.GetValueAt(point.Item1));
							double p1 = SwingHighABars[0].Item2;//Instrument.MasterInstrument.RoundToTickSize(High.GetValueAt(point.Item2));
							HighSwings[point.Item1] = p0;
							HighSwings[point.Item2] = p1;
							if(p0 > p1){
//if(p0 == 87.95) {
//	Draw.VerticalLine(this,"VLStart"+point.ToString(),Times[0][0], Brushes.Red);
//	Print(point.ToString()+"    start rbar: "+start_barsago+"   end rbar: "+end_barsago+"   Start price: "+p0+"  end: "+p1);
//}
								DownTLs[point] = new TLData(p0, p1, point, CurrentBar);//line is created, but not validated yet
								DownTLs[point].TL_DeviationPts	 = (pZoneType==ARC_AT_Trader_ZoneType.Ticks ? deviationPts : atr.GetValueAt(point.Item2) * this.pTLTouchPointsATRMult);
								if(pMinTouchPoints == 2){
									DownTLs[point].IsValidated        = true;
									DownTLs[point].ValidationABar     = CurrentBar;//point.Item2;
									DownTLs[point].PriceAtValidation  = DownTLs[point].CurrentBarPrice;
									DownTLs[point].MaxABar            = point.Item2 + pMaxAgeInBars;
									DownTLs[point].TouchDistancePts   = TouchDistancePts;
									DownTLs[point].BreakDistancePts   = BreakDistancePts;
									DownTLs[point].TerminationDistancePts  = TerminationDistancePts;
//									for(int abar0 = point.Item2; abar0 < CurrentBar; abar0++){
//										if(BreakDistancePts) CheckEnableBreakAlert(DownTLs[point], abar0);
//										if(TouchDistancePts) CheckEnableTouchAlert(DownTLs[point], abar0);
//									}
								}
//if(p0 == 87.95) {
//	Print("----------------------------");
//	Print(TLToString(DownTLs[point]));
//	Print("----------------------------");
//}
							}
						}
					}
					#endregion
				}
				#region -- Update existing Down Trendlines --
				TLs = DownTLs.Where(k=> /*Time.GetValueAt(k.Key.Item1)>=dt && */k.Value.IsLineEnabled).Select(k=>k.Key).ToList();
				if(TLs != null && TLs.Count>0){
					KeysOfLinesToDelete.Clear();
					foreach(var k in TLs){
						int confirmedtouches = pMinTouchPoints == 2 ? 0 : 2;//do not count touches if pMinTouchPoints==2
						for(int abar = (pMinTouchPoints==2 ? k.Item2 : Math.Max(CurrentBar-10,DownTLs[k].AlertedABar)); abar <= CurrentBar; abar++)
						{
//t = Times[0].GetValueAt(abar);
//z = DownTLs[k].StartPrice == 87.95;
							double H = High.GetValueAt(abar);
							double L = Low.GetValueAt(abar);
							DownTLs[k].CalcPrice(abar, k);
							if(abar==CurrentBar){//determine Touch or Break signal
								double O = Open.GetValueAt(abar);
								double C = Close.GetValueAt(abar);
								string res = CalcTouchAlert(DownTLs[k], O, H, L, C, CurrentBar, this.pMaxTrendContinuingSignals);
								res = CalcBreakAlert(DownTLs[k], O, H, L, C, BreakBarRequirementChar, CurrentBar, z);
//if(z){
//	Print(Times[0][0].ToString()+"  IsZoneTerminated: "+DownTLs[k].IsZoneTerminated.ToString()+"  BreakAlertFired: "+DownTLs[k].BreakAlertFired.ToString()+"      IsLineEnabled?: "+DownTLs[k].IsLineEnabled.ToString());
//	Print(k.ToString()+"  "+t.ToString()+" DOWN Status: "+DownTLs[k].AlertStatus+"  IsTerminated?: "+DownTLs[k].IsZoneTerminated.ToString()+"   res: "+res);
//    if(!double.IsNaN(DownTLs[k].BreakAlertPrice))
//		Draw.Dot(this,string.Format("{0}{1}",k.ToString(),abar), false, 0, DownTLs[k].BreakAlertPrice, Brushes.Yellow);
		//Draw.Dot(this,string.Format("{0}{1}cbp",k.ToString(),abar), false, 0, DownTLs[k].CurrentBarPrice, Brushes.Yellow);
//	Draw.Dot(this,string.Format("{0}{1}patv",k.ToString(),abar), false, 0, DownTLs[k].TerminationDistancePts, Brushes.Blue);
//}
								res = CalcZoneTermination(DownTLs[k], O, H, L, C, TerminationBarRequirementChar, CurrentBar, z);
//if(z){
//	Print("    IsZoneTerminated: "+DownTLs[k].IsZoneTerminated.ToString()+"  BreakAlertFired: "+DownTLs[k].BreakAlertFired.ToString()+"      IsLineEnabled?: "+DownTLs[k].IsLineEnabled.ToString()+"   res: "+res);
//}
								res = DownTLs[k].CalcIsLineEnabled(abar);
								if(DownTLs[k].AlertStatus == 'T'){
									DownTLs[k].TouchAlertPrice = double.NaN;
									DownTLs[k].AlertStatus = ' ';
									if(State==State.Realtime) Alert(CurrentBar.ToString(), Priority.High, "AT_Trader downward TL Touched", AddSoundFolder(this.pTrendContinuingSellWAV), 0, Brushes.Red, Brushes.White);
									if(ShowSignals && CurrentBar > FirstABar_TrendContinuingSignals) DrawSpecificMarkerType(totime(k.Item1), this.pTrendContinuingMarkerType, 'T', 'S', abar, H+TickSize, pSellMarkerBrush);
								}
								if(DownTLs[k].AlertStatus == 'B'){
									DownTLs[k].AlertStatus = ' ';
									DownTLs[k].IsBroken = true;
									if(State==State.Realtime) Alert(CurrentBar.ToString(), Priority.High, "AT_Trader downward TL Broken", AddSoundFolder(this.pBreakBuyWAV), 0, Brushes.Green, Brushes.White);
									if(ShowSignals && CurrentBar > FirstABar_BreakSignals) {
										DrawSpecificMarkerType(totime(k.Item1), this.pBreakMarkerType, 'B', 'L', abar, L-TickSize, pBuyMarkerBrush);
										DownTLs[k].TriggerDotPrice = DownTLs[k].BreakAlertPrice; 
									}
									DownTLs[k].BreakAlertPrice = double.NaN;
								}
							}
							double devpts = DownTLs[k].TL_DeviationPts;
							double lvl1 = DownTLs[k].CurrentBarPrice - devpts/2;
							double lvl2 = DownTLs[k].CurrentBarPrice + devpts/2;
							if(pMinTouchPoints>2 && H > lvl1 && !DownTLs[k].IsValidated){
								confirmedtouches++;
//Draw.Dot(this,string.Format("1 {0}{1}",k.ToString(),abar), false, 0, lvl1, Brushes.Cyan);
//Draw.Dot(this,string.Format("2 {0}{1}",k.ToString(),abar), false, 0, lvl2, Brushes.Cyan);
//if(z)Print(t.ToString()+"  Confirmed downTL touch "+confirmedtouches);
							}
//							if(Close.GetValueAt(abar) > lvl2){// || (DownTLs[k].MaxABar>0 && CurrentBar > DownTLs[k].MaxABar)){
////if(z)Print(t.ToString()+"   downTL broken!  ");
////Draw.Diamond(this,string.Format("3 {0}{1}",k.ToString(),abar), false, 0, lvl2, Brushes.Orange);
//								DownTLs[k].IsBroken = true;
//								break;
//							}else 
							if(pMinTouchPoints>2 && confirmedtouches >= pMinTouchPoints){
//if(z)Print(t.ToString()+"   Validated downTL ");
//Draw.Diamond(this,string.Format("4 {0}{1}",k.ToString(),abar), false, 0, DownTLs[k].CurrentBarPrice, Brushes.Green);
								//RemoveDrawObject(k.ToString());
								DownTLs[k].IsValidated       = true;
								DownTLs[k].ValidationABar    = abar;
								DownTLs[k].PriceAtValidation = DownTLs[k].CurrentBarPrice;
								DownTLs[k].MaxABar			 = abar + pMaxAgeInBars;
								DownTLs[k].TouchDistancePts  = TouchDistancePts;
								DownTLs[k].BreakDistancePts  = BreakDistancePts;
								DownTLs[k].TerminationDistancePts = TerminationDistancePts;
								#region -- If any new trendlines start at one of these touchpoints of an older trendline, then remove that new trendline
								var deletethese = DownTLs.Where(a=>a.Key.Item1 == k.Item2).Select(a=>a.Key).ToList();
								foreach(var tl in deletethese) KeysOfLinesToDelete.Add(tl);
								#endregion
								break;//this is a validated line, stop indexing thru the subsequent price bars
							}
						}
					}
				}
				foreach(var tl in KeysOfLinesToDelete) DownTLs.Remove(tl);
				#endregion
				if(ChartControl==null){
					var HighestTriggerDot = double.MinValue;
					foreach(var kvp in UpTLs.Where(k=> k.Value.IsValidated && 
								((this.pShowBrokenLines && k.Value.IsBroken) || (pShowFreshLines && !k.Value.IsBroken))
						)) {
							HighestTriggerDot = Math.Max(HighestTriggerDot, kvp.Value.TriggerDotPrice);
						}
					TriggerDotBelowPrice[0] = HighestTriggerDot;
					var LowestTriggerDot = double.MaxValue;
					foreach(var kvp in DownTLs.Where(k=> k.Value.IsValidated && 
								((this.pShowBrokenLines && k.Value.IsBroken) || (pShowFreshLines && !k.Value.IsBroken))
						)) {
							LowestTriggerDot = Math.Min(LowestTriggerDot, kvp.Value.TriggerDotPrice);
						}
					TriggerDotAbovePrice[0] = LowestTriggerDot;
				}
			}
}catch(Exception e){Print(e.ToString());}
		}
//===================================================================================================
		private SharpDX.Direct2D1.Brush MagentaBrushDX, BreakTriggerDotBrush, ZigZagUpBrushDX, ZigZagDnBrushDX;
		public override void OnRenderTargetChanged()
		{
			#region -- OnRenderTargetChanged --
			if(MagentaBrushDX!=null && !MagentaBrushDX.IsDisposed) MagentaBrushDX.Dispose(); MagentaBrushDX = null;
			if(RenderTarget!=null)
				MagentaBrushDX = Brushes.Magenta.ToDxBrush(RenderTarget);
			
			if(BreakTriggerDotBrush!=null && !BreakTriggerDotBrush.IsDisposed) BreakTriggerDotBrush.Dispose(); BreakTriggerDotBrush = null;
			if(RenderTarget!=null)
				BreakTriggerDotBrush = pBreakTriggerDotBrush.ToDxBrush(RenderTarget);

			if(ZigZagUpBrushDX!=null && !ZigZagUpBrushDX.IsDisposed) ZigZagUpBrushDX.Dispose(); ZigZagUpBrushDX = null;
			if(RenderTarget!=null)
				ZigZagUpBrushDX = pRisingZZlegBrush.ToDxBrush(RenderTarget);

			if(ZigZagDnBrushDX!=null && !ZigZagDnBrushDX.IsDisposed) ZigZagDnBrushDX.Dispose(); ZigZagDnBrushDX = null;
			if(RenderTarget!=null)
				ZigZagDnBrushDX = pFallingZZlegBrush.ToDxBrush(RenderTarget);

			#endregion
		}
//===================================================================================================
	SharpDX.Vector2 v0 = new SharpDX.Vector2(0,0);
	SharpDX.Vector2 v1 = new SharpDX.Vector2(0,0);
	SharpDX.Vector2 tpv = new SharpDX.Vector2(0,0);
	protected override void OnRender(ChartControl chartControl, ChartScale chartScale) {
		#region -- OnRender --
		if (!IsVisible) return;
#if DoLicense
		if (!ValidLicense) return;
#endif
		double minPrice = chartScale.MinValue; double maxPrice = chartScale.MaxValue;
		SharpDX.Direct2D1.AntialiasMode OSM = RenderTarget.AntialiasMode;
		RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

		base.OnRender(chartControl, chartScale);
		int lmab = Math.Max(1, ChartBars.FromIndex);
		int rmab = Math.Min(BarsArray[0].Count, ChartBars.ToIndex);

		var y0 = chartScale.GetYByValue(0);
		var y1 = chartScale.GetYByValue(deviationPts);
		int x0 = 0;
		int x1 = 0;
		x0 = ChartControl.GetXByBarIndex(ChartBars, 0);
		x1 = ChartControl.GetXByBarIndex(ChartBars, 1);
		float halfbarWidth = (x1-x0)/2f;

//		Print("1 tick = "+(y0-y1).ToString());
		var thickness = y0-y1;
		if(pShowZigzagLegs && SwingHighABars!=null && SwingLowABars!=null){
			#region -- Show zigzag lines --
			int idxH = SwingHighABars.Count-1;
			int idxL = SwingLowABars.Count-1;
			var SwingH = SwingHighABars.Where(k=>k.Item1 < lmab).ToList();//this selects the swing abar which is just off the left edge of the chart
			var SwingL = SwingLowABars.Where(k=>k.Item1 < lmab).ToList();//this selects the swing abar which is just off the left edge of the chart
			if(SwingH != null) idxH = idxH-(SwingH.Count-1);
			if(SwingL != null) idxL = idxL-(SwingL.Count-1);
			var Dict = new SortedDictionary<int,Tuple<char,double>>();
			for(int i = 0; i<=idxH; i++) Dict[SwingHighABars[i].Item1] = new Tuple<char,double>('H',SwingHighABars[i].Item2);
			for(int i = 0; i<=idxL; i++) Dict[SwingLowABars[i].Item1]  = new Tuple<char,double>('L',SwingLowABars[i].Item2);
			
			char type = SwingHighABars[idxH].Item1 < SwingLowABars[idxL].Item1 ? 'H' : 'L';//the first swing node, is it a High swing or a Low swing?
			try{
			v0.X = 0; v0.Y=0;
			v1.X = float.MinValue; v1.Y=0;
			foreach(var kvp in Dict){
				if(kvp.Value.Item1 == 'H'){//this is an uptrending swing line
					v0.X = v1.X;
					v0.Y = v1.Y;
					v1.X = ChartControl.GetXByBarIndex (ChartBars, kvp.Key);
					v1.Y = chartScale.GetYByValue      (kvp.Value.Item2);
					if(v0.X != float.MinValue) RenderTarget.DrawLine(v0, v1, ZigZagUpBrushDX, pSwingLegWidth);
				}else{//this is a downtrending swing line
					v0.X = v1.X;
					v0.Y = v1.Y;
					v1.X = ChartControl.GetXByBarIndex (ChartBars, kvp.Key);
					v1.Y = chartScale.GetYByValue      (kvp.Value.Item2);
					if(v0.X != float.MinValue) RenderTarget.DrawLine(v0, v1, ZigZagDnBrushDX, pSwingLegWidth);
				}
				if(kvp.Key > rmab) break;
			}
			}catch(Exception dd){Print(dd.ToString());}
			#endregion --------------------------------------------
		}
		//display the TL if it's validated...and if either: 1) current price is in the range of min/max chart price OR 2) it's validation bar is in the visible range of the chart
		var price_buffer = (maxPrice-minPrice)/2.0;
		if(pShowUpwardLines){
			foreach(var kvp in UpTLs.Where(k=> (view_these_keys.Count>0 ? view_these_keys.Contains(k.Key) 
				: 	(	k.Value.IsValidated && 
						((this.pShowBrokenLines && k.Value.IsBroken) || (pShowFreshLines && !k.Value.IsBroken)) &&
						((k.Value.CurrentBarPrice > minPrice-price_buffer && k.Value.CurrentBarPrice < maxPrice+price_buffer) || k.Value.ValidationABar > lmab && k.Key.Item1 < rmab)
					)
				))) {
				if(kvp.Value.IsZoneTerminated){
					y0 = chartScale.GetYByValue(kvp.Value.CurrentPriceAtTermination);
					x0 = ChartControl.GetXByBarIndex(ChartBars, kvp.Value.ZoneTerminatedABar);
//if(kvp.Value.StartPrice == 34134)Print("Terminated  CurrentPriceAtTermination: "+kvp.Value.CurrentPriceAtTermination+" ZoneTerminatedABar: "+kvp.Value.ZoneTerminatedABar);
				}else{
					y0 = chartScale.GetYByValue(kvp.Value.CurrentBarPrice);
					x0 = ChartControl.GetXByBarIndex(ChartBars, kvp.Value.CurrentBar);
//if(kvp.Value.StartPrice == 34134)Print("CurrentBarPrice: "+kvp.Value.CurrentBarPrice+" CBar: "+kvp.Value.CurrentBar);
				}
				if(pShowBreakSignalTriggerDot && pBreakSignalType != ARC_AT_Trader_SignalType.None){
					if(!double.IsNaN(kvp.Value.TriggerDotPrice)){
						tpv.X = ChartControl.GetXByBarIndex(ChartBars, kvp.Value.AlertedABar)+halfbarWidth;
						tpv.Y = chartScale.GetYByValue(kvp.Value.TriggerDotPrice);
					}else if(!double.IsNaN(kvp.Value.BreakAlertPrice)){
						tpv.X = ChartControl.GetXByBarIndex(ChartBars, kvp.Value.CurrentBar)+halfbarWidth;
						tpv.Y = chartScale.GetYByValue(kvp.Value.BreakAlertPrice);
					}else tpv.Y = float.MinValue;
					if(tpv.Y!=float.MinValue) RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(tpv, pBreakSignalTriggerWidth, pBreakSignalTriggerWidth), BreakTriggerDotBrush);
				}
				v0.X = x0; v0.Y = y0;
				if(pTouchZoneOpacity>0){
					x1 = ChartControl.GetXByBarIndex(ChartBars, kvp.Value.ValidationABar);
					y1 = chartScale.GetYByValue(kvp.Value.PriceAtValidation);
					v1.X = x1; v1.Y = y1;
					Plots[0].BrushDX.Opacity = pTouchZoneOpacity/100f;
					if(pZoneType == ARC_AT_Trader_ZoneType.ATR)//determine zone thickness by the size of the ATR zone at the time when the trendline was verified
						thickness = chartScale.GetYByValue(0)-chartScale.GetYByValue(kvp.Value.TL_DeviationPts);
					RenderTarget.DrawLine(v0, v1, Plots[0].BrushDX, thickness);
				}
				y1 = chartScale.GetYByValue(kvp.Value.StartPrice);
				x1 = ChartControl.GetXByBarIndex(ChartBars, kvp.Key.Item1);
				v1.X = x1; v1.Y = y1;
//if(kvp.Value.StartPrice == 34134)Print("x0:y0: "+x0+" : "+y0+"   x1:y1: "+x1+" : "+y1);
				Plots[0].BrushDX.Opacity = 1f;
				RenderTarget.DrawLine(v0, v1, Plots[0].BrushDX, Plots[0].Width);
			}
		}
		if(pShowDownwardLines){
//			foreach(var kvp in DownTLs.Where(k=>k.Value.IsValidated &&
//					((this.pShowBrokenLines && k.Value.IsBroken) || (pShowFreshLines && !k.Value.IsBroken)) &&
//					((k.Value.CurrentBarPrice > minPrice-price_buffer && k.Value.CurrentBarPrice < maxPrice+price_buffer) || k.Value.ValidationABar > lmab && k.Key.Item1 < rmab))){
			foreach( var kvp in DownTLs.Where(k=> (view_these_keys.Count>0 ? view_these_keys.Contains(k.Key)
				: 	(k.Value.IsValidated &&
					((this.pShowBrokenLines && k.Value.IsBroken) || (pShowFreshLines && !k.Value.IsBroken)) &&
					((k.Value.CurrentBarPrice > minPrice-price_buffer && k.Value.CurrentBarPrice < maxPrice+price_buffer) || k.Value.ValidationABar > lmab && k.Key.Item1 < rmab))
				))) {
				if(kvp.Value.IsZoneTerminated){
					y0 = chartScale.GetYByValue(kvp.Value.CurrentPriceAtTermination);
					x0 = ChartControl.GetXByBarIndex(ChartBars, kvp.Value.ZoneTerminatedABar);
				}else{
					y0 = chartScale.GetYByValue(kvp.Value.CurrentBarPrice);
					x0 = ChartControl.GetXByBarIndex(ChartBars, kvp.Value.CurrentBar);
				}
				if(pShowBreakSignalTriggerDot && pBreakSignalType != ARC_AT_Trader_SignalType.None){
					if(!double.IsNaN(kvp.Value.TriggerDotPrice)){
						tpv.X = ChartControl.GetXByBarIndex(ChartBars, kvp.Value.AlertedABar)+halfbarWidth;
						tpv.Y = chartScale.GetYByValue(kvp.Value.TriggerDotPrice);
					}else if(!double.IsNaN(kvp.Value.BreakAlertPrice)){
						tpv.X = ChartControl.GetXByBarIndex(ChartBars, kvp.Value.CurrentBar)+halfbarWidth;
						tpv.Y = chartScale.GetYByValue(kvp.Value.BreakAlertPrice);
					}else tpv.Y = float.MinValue;
					if(tpv.Y!=float.MinValue) RenderTarget.FillEllipse(new SharpDX.Direct2D1.Ellipse(tpv, pBreakSignalTriggerWidth, pBreakSignalTriggerWidth), BreakTriggerDotBrush);
				}
				v0.X = x0; v0.Y = y0;
				if(pTouchZoneOpacity>0){
					x1 = ChartControl.GetXByBarIndex(ChartBars, kvp.Value.ValidationABar);
					y1 = chartScale.GetYByValue(kvp.Value.PriceAtValidation);
					v1.X = x1; v1.Y = y1;
					Plots[1].BrushDX.Opacity = pTouchZoneOpacity/100f;
					if(pZoneType == ARC_AT_Trader_ZoneType.ATR)//determine zone thickness by the size of the ATR zone at the time when the trendline was verified
						thickness = chartScale.GetYByValue(0)-chartScale.GetYByValue(kvp.Value.TL_DeviationPts);
					RenderTarget.DrawLine(v0, v1, Plots[1].BrushDX, thickness);
				}
				y1 = chartScale.GetYByValue(kvp.Value.StartPrice);
				x1 = ChartControl.GetXByBarIndex(ChartBars, kvp.Key.Item1);
				v1.X = x1; v1.Y = y1;
				Plots[1].BrushDX.Opacity = 1f;
				RenderTarget.DrawLine(v0, v1, Plots[1].BrushDX, Plots[1].Width);
			}
		}
		#endregion
		RenderTarget.AntialiasMode = OSM;
	}
//===================================================================================================
		internal class LoadSoundFileList : StringConverter
		{
			#region LoadSoundFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";

				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("SOUND OFF");
				if(IsDebug){
					list.Add("<inst>_BuyEntry.wav");
					list.Add("<inst>_SellEntry.wav");
				}
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
        }
		#region -- Properties --
		private string AddSoundFolder(string wav){
			return System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", wav.Replace("<inst>",Instruments[0].MasterInstrument.Name));
		}

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Order=10, Name="Swing Strength", GroupName="Parameters", Description="Min swing strength for determining swing bars")]
		public int pSwingStrength
		{ get; set; }

        [NinjaScriptProperty]
        [Range(0, double.MaxValue)]
        [Display(Name = "Swing Deviation mult", GroupName = "Parameters", Description = "Multiplier used to calculate minimum deviation as an ATR multiple", Order = 11)]
        public double pMultiplierMD { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Select data input for swings", GroupName = "Parameters", Description = "Select data input for swing highs and lows", Order = 12)]
        public ARC_AT_Trader_InputType pThisInputType { get; set; }

		[NinjaScriptProperty]
		[Range(2, 4)]
		[Display(Order=20, Name="Min Touch Points", GroupName="Parameters", Description="Min number of trendline touchpoints for validating trendlines")]
		public int pMinTouchPoints
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order=30, Name="Trendline Zone Type", GroupName="Parameters", Description="")]
		public ARC_AT_Trader_ZoneType pZoneType
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Order = 33, Name="Trendline Zone (ATR mult)", GroupName="Parameters", Description="")]
		public double pTLTouchPointsATRMult
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Order=35, Name="Trendline Zone (ticks)", GroupName="Parameters", Description="")]
		public int pTLTouchPointsTicks
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0f, 100f)]
		[Display(Order=10, Name="Trendline Zone Opacity", Description="Opacity of region around a trendline for a valid touch", GroupName="Custom Visuals")]
		public float pTouchZoneOpacity
		{ get; set; }

        [Display(Order=20, Name = "Show swing legs", GroupName = "Custom Visuals", Description = "Show swing legs connecting swing highs and lows")]
        public bool pShowZigzagLegs { get; set; }

        [Range(1, int.MaxValue)]
        [Display(Order=30, Name = "Width swing legs", GroupName = "Custom Visuals", Description = "Select thickness of swing legs connecting swing highs and lows")]
        public int pSwingLegWidth { get; set; }

		[XmlIgnore]
		[Display(Name = "Rising leg color", GroupName = "Custom Visuals", Description = "Select Color of a rising swing leg line", Order = 33)]
		public Brush pRisingZZlegBrush { get; set; }
				[Browsable(false)]
				public string RisingZZlegBrushSerialize {get { return Serialize.BrushToString(pRisingZZlegBrush); }set { pRisingZZlegBrush = Serialize.StringToBrush(value); } }

		[XmlIgnore]
		[Display(Name = "Falling leg color", GroupName = "Custom Visuals", Description = "Select Color of a falling swing leg line", Order = 36)]
		public Brush pFallingZZlegBrush { get; set; }
				[Browsable(false)]
				public string FallingZZlegBrushSerialize {get { return Serialize.BrushToString(pFallingZZlegBrush); }set { pFallingZZlegBrush = Serialize.StringToBrush(value); } }


        [Display(Order=40, Name = "Show upward lines",   GroupName = "Custom Visuals", Description = "Show rising trendlines")]
        public bool pShowUpwardLines { get; set; }
        [Display(Order=50, Name = "Show downward lines", GroupName = "Custom Visuals", Description = "Show falling trendlines")]
        public bool pShowDownwardLines { get; set; }
        [Display(Order=60, Name = "Show broken lines",   GroupName = "Custom Visuals", Description = "Show lines that are established AND have been broken thru by price action")]
        public bool pShowBrokenLines { get; set; }
        [Display(Order=70, Name = "Show fresh lines", GroupName = "Custom Visuals", Description = "Show lines that are established, but have not been broken thru by price action")]
        public bool pShowFreshLines { get; set; }

//		[XmlIgnore]
//		[Display(Order=80, Name="Rising Trendline Color", GroupName="Custom Visuals", Description="Color of rising trendlines")]
//		public Brush pRisingLineColor
//		{ get; set; }

//				[Browsable(false)]
//				public string PRisingLineColorSerializable{get { return Serialize.BrushToString(pRisingLineColor); }set { pRisingLineColor = Serialize.StringToBrush(value); }}			

//		[XmlIgnore]
//		[Display(Order=90, Name="Falling Trendline Color", GroupName="Custom Visuals", Description="Color of falling trendlines")]
//		public Brush pFallingLineColor
//		{ get; set; }

//				[Browsable(false)]
//				public string PFallingLineColorSerializable{get { return Serialize.BrushToString(pFallingLineColor); } set { pFallingLineColor = Serialize.StringToBrush(value); }}			

		[XmlIgnore]
		[Display(Order=100, Name="Up Marker Color", GroupName="Custom Visuals", Description="Color of upward signals")]
		public Brush pBuyMarkerBrush
		{ get; set; }

				[Browsable(false)]
				public string pBuyMarkerBrushSerializable{get { return Serialize.BrushToString(pBuyMarkerBrush); } set { pBuyMarkerBrush = Serialize.StringToBrush(value); }}			

		[XmlIgnore]
		[Display(Order=110, Name="Down Marker Color", GroupName="Custom Visuals", Description="Color of downward signals")]
		public Brush pSellMarkerBrush
		{ get; set; }

				[Browsable(false)]
				public string pSellMarkerBrushSerializable{get { return Serialize.BrushToString(pSellMarkerBrush); } set { pSellMarkerBrush = Serialize.StringToBrush(value); }}			

		[Display(Order=120, Name="Show historical markers", GroupName="Custom Visuals", Description="Save runtime by hiding historical chart marker signals")]
		public bool pShowHistoricalSignals
		{get;set;}

		private string pButtonText = "AT_Trader";
        [Display(Order=1000, Name = "Button text", GroupName="Custom Visuals", Description = "")]       
		public string ButtonText
        {
            get { return pButtonText; }
            set { pButtonText = value; }
        }
		#endregion

		#region -- Signals --
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="Max Bars Lookback", Description="", Order=5, GroupName="Trend Signals")]
		public int pTrendContinuingBarsLookback
		{ get; set; }

		[Display(Name="Signal Type", Description="Trend are signals in the direction of the trendline", Order=10, GroupName="Trend Signals")]
		public ARC_AT_Trader_SignalType pTrendContinuingSignalType
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Signal distance (ATR mult)", Description="", Order=20, GroupName="Trend Signals")]
		public double pTrendContinuingDistanceATRMult
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="Signal distance (ticks)", Description="", Order=30, GroupName="Trend Signals")]
		public int pTrendContinuingDistanceTicks
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Signals per trendline", Description="", Order=35, GroupName="Trend Signals")]
		public int pMaxTrendContinuingSignals
		{ get; set; }

		[Display(Name="Up signal WAV", Description="", Order=40, GroupName="Trend Signals")]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string pTrendContinuingBuyWAV
		{ get; set; }

		[Display(Name="Down signal WAV", Description="", Order=50, GroupName="Trend Signals")]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string pTrendContinuingSellWAV
		{ get; set; }

		[Display(Name="Marker Type", Description="", Order=60, GroupName="Trend Signals")]
		public ARC_AT_Trader_MarkerType pTrendContinuingMarkerType
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="Max Bars Lookback", Description="", Order=5, GroupName="Break Signals")]
		public int pBreakBarsLookback
		{ get; set; }

		[Display(Name="Signal Type", Description="Breaks are reversal signals", Order=40, GroupName="Break Signals")]
		public ARC_AT_Trader_SignalType pBreakSignalType
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Signal distance (ATR mult)", Description="", Order=50, GroupName="Break Signals")]
		public double pBreakDistanceATRMult
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="Signal distance (ticks)", Description="", Order=60, GroupName="Break Signals")]
		public int pBreakDistanceTicks
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Bar requirement", Order=65, GroupName="Break Signals", Description="Does the full bar need to be outside of the break zone, or just a part of the bar" )]
		public ARC_AT_Trader_BarRequirement pBreakBarRequirement
		{ get; set; }

		[Display(Name="Up signal WAV", Description="", Order=70, GroupName="Break Signals")]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string pBreakBuyWAV
		{ get; set; }

		[Display(Name="Down signal WAV", Description="", Order=80, GroupName="Break Signals")]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string pBreakSellWAV
		{ get; set; }

		[Display(Name="Marker Type", Description="", Order=90, GroupName="Break Signals")]
		public ARC_AT_Trader_MarkerType pBreakMarkerType
		{ get; set; }

		[Display(Name="Show TriggerDot", Description="Show signal level trigger price", Order=95, GroupName="Break Signals")]
		public bool pShowBreakSignalTriggerDot
		{get;set;}

		[Range(1f,100f)]
		[Display(Name="TriggerDot Width", Description="Width of signal level trigger price", Order=100, GroupName="Break Signals")]
		public float pBreakSignalTriggerWidth
		{get;set;}
		
		[XmlIgnore]
		[Display(Name = "TriggerDot Color", GroupName = "Break Signals", Description = "Color of signal level trigger dot", Order = 110)]
		public Brush pBreakTriggerDotBrush { get; set; }
				[Browsable(false)]
				public string pBreakTriggerDotBrushSerialize {get { return Serialize.BrushToString(pBreakTriggerDotBrush); }set { pBreakTriggerDotBrush = Serialize.StringToBrush(value); } }

		[Display(Name="Type", Description="When does the zone stop printing", Order=10, GroupName="Zone Termination")]
		public ARC_AT_Trader_ZoneType pZoneTerminationType
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Distance (ATR mult)", Description="", Order=20, GroupName="Zone Termination")]
		public double pZoneTerminationDistanceATRMult
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="Distance (ticks)", Description="", Order=30, GroupName="Zone Termination")]
		public int pZoneTerminationDistanceTicks
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Bar requirement", Order=40, GroupName="Zone Termination", Description="Does the full bar need to be outside of the break zone, or just a part of the bar" )]
		public ARC_AT_Trader_BarRequirement pTerminationBarRequirement
		{ get; set; }

		#endregion

		#region Plots
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> RisingLinesPlot
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> FallingLinesPlot
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> TriggerDotAbovePrice
		{
			get { return Values[2]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> TriggerDotBelowPrice
		{
			get { return Values[3]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ARC.ARC_AT_Trader[] cacheARC_AT_Trader;
		public ARC.ARC_AT_Trader ARC_AT_Trader(int pSwingStrength, double pMultiplierMD, ARC_AT_Trader_InputType pThisInputType, int pMinTouchPoints, ARC_AT_Trader_ZoneType pZoneType, double pTLTouchPointsATRMult, int pTLTouchPointsTicks, float pTouchZoneOpacity, int pTrendContinuingBarsLookback, double pTrendContinuingDistanceATRMult, int pTrendContinuingDistanceTicks, int pMaxTrendContinuingSignals, int pBreakBarsLookback, double pBreakDistanceATRMult, int pBreakDistanceTicks, ARC_AT_Trader_BarRequirement pBreakBarRequirement, double pZoneTerminationDistanceATRMult, int pZoneTerminationDistanceTicks, ARC_AT_Trader_BarRequirement pTerminationBarRequirement)
		{
			return ARC_AT_Trader(Input, pSwingStrength, pMultiplierMD, pThisInputType, pMinTouchPoints, pZoneType, pTLTouchPointsATRMult, pTLTouchPointsTicks, pTouchZoneOpacity, pTrendContinuingBarsLookback, pTrendContinuingDistanceATRMult, pTrendContinuingDistanceTicks, pMaxTrendContinuingSignals, pBreakBarsLookback, pBreakDistanceATRMult, pBreakDistanceTicks, pBreakBarRequirement, pZoneTerminationDistanceATRMult, pZoneTerminationDistanceTicks, pTerminationBarRequirement);
		}

		public ARC.ARC_AT_Trader ARC_AT_Trader(ISeries<double> input, int pSwingStrength, double pMultiplierMD, ARC_AT_Trader_InputType pThisInputType, int pMinTouchPoints, ARC_AT_Trader_ZoneType pZoneType, double pTLTouchPointsATRMult, int pTLTouchPointsTicks, float pTouchZoneOpacity, int pTrendContinuingBarsLookback, double pTrendContinuingDistanceATRMult, int pTrendContinuingDistanceTicks, int pMaxTrendContinuingSignals, int pBreakBarsLookback, double pBreakDistanceATRMult, int pBreakDistanceTicks, ARC_AT_Trader_BarRequirement pBreakBarRequirement, double pZoneTerminationDistanceATRMult, int pZoneTerminationDistanceTicks, ARC_AT_Trader_BarRequirement pTerminationBarRequirement)
		{
			if (cacheARC_AT_Trader != null)
				for (int idx = 0; idx < cacheARC_AT_Trader.Length; idx++)
					if (cacheARC_AT_Trader[idx] != null && cacheARC_AT_Trader[idx].pSwingStrength == pSwingStrength && cacheARC_AT_Trader[idx].pMultiplierMD == pMultiplierMD && cacheARC_AT_Trader[idx].pThisInputType == pThisInputType && cacheARC_AT_Trader[idx].pMinTouchPoints == pMinTouchPoints && cacheARC_AT_Trader[idx].pZoneType == pZoneType && cacheARC_AT_Trader[idx].pTLTouchPointsATRMult == pTLTouchPointsATRMult && cacheARC_AT_Trader[idx].pTLTouchPointsTicks == pTLTouchPointsTicks && cacheARC_AT_Trader[idx].pTouchZoneOpacity == pTouchZoneOpacity && cacheARC_AT_Trader[idx].pTrendContinuingBarsLookback == pTrendContinuingBarsLookback && cacheARC_AT_Trader[idx].pTrendContinuingDistanceATRMult == pTrendContinuingDistanceATRMult && cacheARC_AT_Trader[idx].pTrendContinuingDistanceTicks == pTrendContinuingDistanceTicks && cacheARC_AT_Trader[idx].pMaxTrendContinuingSignals == pMaxTrendContinuingSignals && cacheARC_AT_Trader[idx].pBreakBarsLookback == pBreakBarsLookback && cacheARC_AT_Trader[idx].pBreakDistanceATRMult == pBreakDistanceATRMult && cacheARC_AT_Trader[idx].pBreakDistanceTicks == pBreakDistanceTicks && cacheARC_AT_Trader[idx].pBreakBarRequirement == pBreakBarRequirement && cacheARC_AT_Trader[idx].pZoneTerminationDistanceATRMult == pZoneTerminationDistanceATRMult && cacheARC_AT_Trader[idx].pZoneTerminationDistanceTicks == pZoneTerminationDistanceTicks && cacheARC_AT_Trader[idx].pTerminationBarRequirement == pTerminationBarRequirement && cacheARC_AT_Trader[idx].EqualsInput(input))
						return cacheARC_AT_Trader[idx];
			return CacheIndicator<ARC.ARC_AT_Trader>(new ARC.ARC_AT_Trader(){ pSwingStrength = pSwingStrength, pMultiplierMD = pMultiplierMD, pThisInputType = pThisInputType, pMinTouchPoints = pMinTouchPoints, pZoneType = pZoneType, pTLTouchPointsATRMult = pTLTouchPointsATRMult, pTLTouchPointsTicks = pTLTouchPointsTicks, pTouchZoneOpacity = pTouchZoneOpacity, pTrendContinuingBarsLookback = pTrendContinuingBarsLookback, pTrendContinuingDistanceATRMult = pTrendContinuingDistanceATRMult, pTrendContinuingDistanceTicks = pTrendContinuingDistanceTicks, pMaxTrendContinuingSignals = pMaxTrendContinuingSignals, pBreakBarsLookback = pBreakBarsLookback, pBreakDistanceATRMult = pBreakDistanceATRMult, pBreakDistanceTicks = pBreakDistanceTicks, pBreakBarRequirement = pBreakBarRequirement, pZoneTerminationDistanceATRMult = pZoneTerminationDistanceATRMult, pZoneTerminationDistanceTicks = pZoneTerminationDistanceTicks, pTerminationBarRequirement = pTerminationBarRequirement }, input, ref cacheARC_AT_Trader);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ARC.ARC_AT_Trader ARC_AT_Trader(int pSwingStrength, double pMultiplierMD, ARC_AT_Trader_InputType pThisInputType, int pMinTouchPoints, ARC_AT_Trader_ZoneType pZoneType, double pTLTouchPointsATRMult, int pTLTouchPointsTicks, float pTouchZoneOpacity, int pTrendContinuingBarsLookback, double pTrendContinuingDistanceATRMult, int pTrendContinuingDistanceTicks, int pMaxTrendContinuingSignals, int pBreakBarsLookback, double pBreakDistanceATRMult, int pBreakDistanceTicks, ARC_AT_Trader_BarRequirement pBreakBarRequirement, double pZoneTerminationDistanceATRMult, int pZoneTerminationDistanceTicks, ARC_AT_Trader_BarRequirement pTerminationBarRequirement)
		{
			return indicator.ARC_AT_Trader(Input, pSwingStrength, pMultiplierMD, pThisInputType, pMinTouchPoints, pZoneType, pTLTouchPointsATRMult, pTLTouchPointsTicks, pTouchZoneOpacity, pTrendContinuingBarsLookback, pTrendContinuingDistanceATRMult, pTrendContinuingDistanceTicks, pMaxTrendContinuingSignals, pBreakBarsLookback, pBreakDistanceATRMult, pBreakDistanceTicks, pBreakBarRequirement, pZoneTerminationDistanceATRMult, pZoneTerminationDistanceTicks, pTerminationBarRequirement);
		}

		public Indicators.ARC.ARC_AT_Trader ARC_AT_Trader(ISeries<double> input , int pSwingStrength, double pMultiplierMD, ARC_AT_Trader_InputType pThisInputType, int pMinTouchPoints, ARC_AT_Trader_ZoneType pZoneType, double pTLTouchPointsATRMult, int pTLTouchPointsTicks, float pTouchZoneOpacity, int pTrendContinuingBarsLookback, double pTrendContinuingDistanceATRMult, int pTrendContinuingDistanceTicks, int pMaxTrendContinuingSignals, int pBreakBarsLookback, double pBreakDistanceATRMult, int pBreakDistanceTicks, ARC_AT_Trader_BarRequirement pBreakBarRequirement, double pZoneTerminationDistanceATRMult, int pZoneTerminationDistanceTicks, ARC_AT_Trader_BarRequirement pTerminationBarRequirement)
		{
			return indicator.ARC_AT_Trader(input, pSwingStrength, pMultiplierMD, pThisInputType, pMinTouchPoints, pZoneType, pTLTouchPointsATRMult, pTLTouchPointsTicks, pTouchZoneOpacity, pTrendContinuingBarsLookback, pTrendContinuingDistanceATRMult, pTrendContinuingDistanceTicks, pMaxTrendContinuingSignals, pBreakBarsLookback, pBreakDistanceATRMult, pBreakDistanceTicks, pBreakBarRequirement, pZoneTerminationDistanceATRMult, pZoneTerminationDistanceTicks, pTerminationBarRequirement);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ARC.ARC_AT_Trader ARC_AT_Trader(int pSwingStrength, double pMultiplierMD, ARC_AT_Trader_InputType pThisInputType, int pMinTouchPoints, ARC_AT_Trader_ZoneType pZoneType, double pTLTouchPointsATRMult, int pTLTouchPointsTicks, float pTouchZoneOpacity, int pTrendContinuingBarsLookback, double pTrendContinuingDistanceATRMult, int pTrendContinuingDistanceTicks, int pMaxTrendContinuingSignals, int pBreakBarsLookback, double pBreakDistanceATRMult, int pBreakDistanceTicks, ARC_AT_Trader_BarRequirement pBreakBarRequirement, double pZoneTerminationDistanceATRMult, int pZoneTerminationDistanceTicks, ARC_AT_Trader_BarRequirement pTerminationBarRequirement)
		{
			return indicator.ARC_AT_Trader(Input, pSwingStrength, pMultiplierMD, pThisInputType, pMinTouchPoints, pZoneType, pTLTouchPointsATRMult, pTLTouchPointsTicks, pTouchZoneOpacity, pTrendContinuingBarsLookback, pTrendContinuingDistanceATRMult, pTrendContinuingDistanceTicks, pMaxTrendContinuingSignals, pBreakBarsLookback, pBreakDistanceATRMult, pBreakDistanceTicks, pBreakBarRequirement, pZoneTerminationDistanceATRMult, pZoneTerminationDistanceTicks, pTerminationBarRequirement);
		}

		public Indicators.ARC.ARC_AT_Trader ARC_AT_Trader(ISeries<double> input , int pSwingStrength, double pMultiplierMD, ARC_AT_Trader_InputType pThisInputType, int pMinTouchPoints, ARC_AT_Trader_ZoneType pZoneType, double pTLTouchPointsATRMult, int pTLTouchPointsTicks, float pTouchZoneOpacity, int pTrendContinuingBarsLookback, double pTrendContinuingDistanceATRMult, int pTrendContinuingDistanceTicks, int pMaxTrendContinuingSignals, int pBreakBarsLookback, double pBreakDistanceATRMult, int pBreakDistanceTicks, ARC_AT_Trader_BarRequirement pBreakBarRequirement, double pZoneTerminationDistanceATRMult, int pZoneTerminationDistanceTicks, ARC_AT_Trader_BarRequirement pTerminationBarRequirement)
		{
			return indicator.ARC_AT_Trader(input, pSwingStrength, pMultiplierMD, pThisInputType, pMinTouchPoints, pZoneType, pTLTouchPointsATRMult, pTLTouchPointsTicks, pTouchZoneOpacity, pTrendContinuingBarsLookback, pTrendContinuingDistanceATRMult, pTrendContinuingDistanceTicks, pMaxTrendContinuingSignals, pBreakBarsLookback, pBreakDistanceATRMult, pBreakDistanceTicks, pBreakBarRequirement, pZoneTerminationDistanceATRMult, pZoneTerminationDistanceTicks, pTerminationBarRequirement);
		}
	}
}

#endregion
