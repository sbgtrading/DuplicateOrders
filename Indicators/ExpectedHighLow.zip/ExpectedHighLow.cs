#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using SBG;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
public enum ExpectedHighLow_Basis {Open, Typical, Mid, PriorDayHL};
public enum ExpectedHighLow_Timeframe {Day, Week, Month, TradeStartTime};
namespace NinjaTrader.NinjaScript.Indicators
{

	public class ExpectedHighLow : Indicator
	{
		double StdDev1 = 0;
		bool IsStdDevMultBand = false;
		bool IsPointsBand = false;
		bool IsTicksBand = false;
		SBG.TradeManager tm;
		Pivots pivot;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Calculate the average high-to-priordayclose and the average low-to-priordayclose, for each day of the week, and project those expected highs/lows based on yesterdays close.";
				Name										= "ExpectedHighLow";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				IsAutoScale = false;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= false;
				pDifferentiateDOW = true;
				StdDev1	= 0.5;
				BandSizeStr = "0.5";
				pShowDOW = true;
				pDaysInAverage = 4;
				pStartTime = 600;
				pStopTime = 1600;
				pGoFlatTime = 1600;
				sDaysOfWeek = "M Tu W Th F Today";
				pEnableSoundAlerts = false;
				pCalculateLongTrades = false;
				pCalculateShortTrades = false;
				pShowHrOfDayTable = false;
				pGlobalizeLevels = true;
				pWAVOnBuyEntry = "<inst>_BuySetup.wav";
				pWAVOnSellEntry = "<inst>_SellSetup.wav";

				pBasis = ExpectedHighLow_Basis.Open;
				AddPlot(Brushes.OrangeRed, "ExpectedHigh");
				AddPlot(Brushes.Blue, "ExpectedHighA");
				AddPlot(Brushes.Blue, "ExpectedHighB");
				AddPlot(Brushes.MediumSpringGreen, "ExpectedLow");
				AddPlot(Brushes.DarkGreen, "ExpectedLowA");
				AddPlot(Brushes.DarkGreen, "ExpectedLowB");
			}
			else if (State == State.Configure)
			{
				ClearOutputWindow();
//				AddDataSeries(Data.BarsPeriodType.Day, 1);
				StdDev1 = ToDouble(BandSizeStr);
				if(BandSizeStr.ToLower().Contains("p")) IsPointsBand = true;
				else if(BandSizeStr.ToLower().Contains("t")) IsTicksBand = true;
				else IsStdDevMultBand = true;
				string s = string.Empty;
				string sU = sDaysOfWeek.ToUpper();
				if (sU.Contains("ALL")) s = "All";
				else{
					if(sU.Contains("TODAY")) {
						sU = DateTime.Now.DayOfWeek.ToString().Substring(0,2);
						sDaysOfWeek = "Today";
					}else{
						if(sU.Contains("M"))   s = s+"M ";
						if(sU.Contains("TU"))  s = s+"Tu ";
						if(sU.Contains("W"))   s = s+"W ";
						if(sU.Contains("TH"))  s = s+"Th ";
						if(sU.Contains("F"))   s = s+"F ";
						if(sU.Contains("SA"))  s = s+"Sa ";
						if(sU.Contains("SU"))  s = s+"Su ";
						sDaysOfWeek = s.Trim();
					}
				}

				tm = new SBG.TradeManager(this, "ExpectedHighLow", "", Instrument, sDaysOfWeek, pStartTime, pStopTime, pGoFlatTime, pShowHrOfDayTable);
				pivot = Pivots(PivotRange.Daily, HLCCalculationMode.DailyBars, 0,0,0,1);
			}
			else if (State == State.DataLoaded)
			{
			}
		}
		private double ToDouble(string s){
//			var ca = s.ToCharArray();
			s = new string(s.ToCharArray()
				.Where(k => (k>='0' && k<= '9') || k=='.' || k=='-')
				.ToArray());
			double d = 0;
			if(double.TryParse(s, out d)) return d; return 0;
		}

		double avgH = double.MinValue;
		double avgL = double.MinValue;
		double C1 = 0;
		double stddevH = 0;
		double stddevL = 0;
		private SortedDictionary<DateTime, double> KeyPrices = new SortedDictionary<DateTime, double>();
		private SortedDictionary<DayOfWeek, List<double>> H = new SortedDictionary<DayOfWeek, List<double>>();
		private SortedDictionary<DayOfWeek, List<double>> L = new SortedDictionary<DayOfWeek, List<double>>();
		private double HH = double.MinValue;
		private double LL = double.MaxValue;
		DayOfWeek dow1 = DayOfWeek.Sunday;
		DayOfWeek dow = DayOfWeek.Sunday;
		int bip = 0;
		List<double> ranges = new List<double>();
		double KeyPrice = double.MinValue;
		double PriorDayH = double.MinValue;
		double PriorDayL = double.MinValue;
		int ABar_NewSession = 0;
		protected override void OnBarUpdate()
		{
			bip = 0;
			if(CurrentBars[bip]<2) return;
			ranges.Add(Highs[bip][0]-Lows[bip][0]);
			while(ranges.Count>10) ranges.RemoveAt(0);
//			if(BarsInProgress==1)
			{
				dow1 = Times[bip][1].DayOfWeek;
				dow = Times[bip][0].DayOfWeek;
				if(!H.ContainsKey(dow1)) H[dow1] = new List<double>();
				if(!L.ContainsKey(dow1)) L[dow1] = new List<double>();
				if(!H.ContainsKey(dow)) H[dow] = new List<double>();
				if(!L.ContainsKey(dow)) L[dow] = new List<double>();
			}
//			else
			{
				bool new_session = false;
				var t1 = ToTime(Times[0][1])/100;
				var t0 = ToTime(Times[0][0])/100;
				if(pTimeframe == ExpectedHighLow_Timeframe.TradeStartTime){
					if(t1<pStartTime && t0>=pStartTime){
						new_session = true;
						if(!pDifferentiateDOW) dow = DayOfWeek.Monday;
					}
				}else if(pTimeframe == ExpectedHighLow_Timeframe.Day && dow1 != dow){
					new_session = true;
					if(!pDifferentiateDOW) dow = DayOfWeek.Monday;
				}else if(pTimeframe == ExpectedHighLow_Timeframe.Week && dow1 > dow){
					new_session = true;
					dow = DayOfWeek.Monday;
				}else if(pTimeframe == ExpectedHighLow_Timeframe.Month && Times[0][0].Day < Times[0][1].Day){
					new_session = true;
					dow = DayOfWeek.Monday;
				}
				if(new_session && CurrentBars[0]>ABar_NewSession){
					ABar_NewSession = CurrentBars[0];
					if(pBasis == ExpectedHighLow_Basis.Open){
						if(KeyPrice!=double.MinValue)
							C1 = KeyPrice;
						else C1 = Opens[bip][0];
						KeyPrice = Opens[bip][0];
					}else if(pBasis == ExpectedHighLow_Basis.Mid){
						if(KeyPrice!=double.MinValue)
							C1 = KeyPrice;
						else C1 = (HH+LL)/2.0;
						KeyPrice = (HH+LL)/2.0;
					}else if(pBasis == ExpectedHighLow_Basis.Typical){
						if(KeyPrice!=double.MinValue)
							C1 = KeyPrice;
						else C1 = (HH+LL+Closes[bip][1])/3.0;
						KeyPrice = (HH+LL+Closes[bip][1])/3.0;
					}else if(pBasis == ExpectedHighLow_Basis.PriorDayHL){
						avgH = 0;
						PriorDayH = HH;
						PriorDayL = LL;
						C1 = (HH+LL)/2.0;
						KeyPrices[Times[bip][1].Date] = C1;
					}else{
						KeyPrices[Times[bip][1].Date] = C1;
						if(State==State.Historical){
							H[dow1].Add(HH - C1);
							L[dow1].Add(LL - C1);
						}
						if(pDaysInAverage>0){
							while(H[dow1].Count>pDaysInAverage) H[dow1].RemoveAt(0);
							while(L[dow1].Count>pDaysInAverage) L[dow1].RemoveAt(0);
						}
						if(H[dow].Count>0 && L[dow].Count>0){
							avgH = H[dow].Average();//avgH is now the average distance of H[0]-C[1]
							avgL = L[dow].Average();//avgL is now the average distance of L[0]-C[1]
						}
					}
					if(IsStdDevMultBand){
						stddevH = StdDeviation(H[dow], avgH) * StdDev1;
						stddevL = StdDeviation(L[dow], avgL) * StdDev1;
						var minimumavg = ranges.Average();
						stddevH = Math.Max(stddevH, minimumavg);
						stddevL = Math.Max(stddevL, minimumavg);
					}else if(IsTicksBand){
						stddevH = StdDev1 * TickSize;
						stddevL = StdDev1 * TickSize;
					}else if(IsPointsBand){
						stddevH = StdDev1;
						stddevL = StdDev1;
					}
					if(KeyPrices.Count>0){
						Draw.Dot(this, string.Format("{0}{1}  {2}-{3}", pBasis.ToString(),CurrentBars[0].ToString(),HH,LL), false, 0, KeyPrices.Last().Value, Brushes.Yellow);
						if(pShowDOW && tm.DOW.Contains(Times[0][0].DayOfWeek)){
							Draw.Text(this, "txt"+CurrentBars[0].ToString(), false, 
								dow.ToString()+"\n"+Times[bip][0].ToShortDateString()
//									+"\navgH: "+Instrument.MasterInstrument.FormatPrice(avgH)+" avgL: "+Instrument.MasterInstrument.FormatPrice(avgL)+"\n H: "+Instrument.MasterInstrument.FormatPrice(stddevH)+" L: "+Instrument.MasterInstrument.FormatPrice(stddevL)
								, 0, KeyPrices.Last().Value, 0, Brushes.White, new SimpleFont("Arial",12), TextAlignment.Right, Brushes.Transparent, Brushes.Black,100);
						}
					}
					HH = Highs[bip][0];
					LL = Lows[bip][0];
				}else{
					HH = Math.Max(HH,Highs[bip][0]);
					LL = Math.Min(LL,Lows[bip][0]);
				}
//				if(CurrentBars[0]>BarsArray[0].Count-5)Draw.Text(this,"XXX","你明白这个翻译吗?",15,Closes[0][0],Brushes.Yellow);
				if(avgH!=double.MinValue){
					if(pPivotLevels==0){
						if(pBasis == ExpectedHighLow_Basis.PriorDayHL && PriorDayH != double.MinValue){
							ExpectedHigh[0] = PriorDayH;
							ExpectedLow[0] = PriorDayL;
						}else{
							ExpectedHigh[0] = C1 + avgH;
							ExpectedLow[0] = C1 + avgL;
						}
						if(State==State.Realtime){
							if(this.pCalculateShortTrades)Draw.Text(this,"SellLvl","Sell",15,ExpectedHigh[0], pGlobalizeLevels, "Default");
							if(this.pCalculateLongTrades)Draw.Text(this,"BuyLvl","Buy",15,ExpectedLow[0], pGlobalizeLevels, "Default");
						}
					}else{
						if(pPivotLevels==1){
							ExpectedHigh[0] = pivot.R1[0];
							ExpectedLow[0] = pivot.S1[0];
							if(State==State.Realtime){
								if(this.pCalculateShortTrades) Draw.Text(this,"SellLvl","R1 sell",15,ExpectedHigh[0], pGlobalizeLevels, "Default");
								if(this.pCalculateLongTrades)Draw.Text(this,"BuyLvl","S1 buy",15,ExpectedLow[0], pGlobalizeLevels, "Default");
							}
						}else if(pPivotLevels==2){
							ExpectedHigh[0] = pivot.R2[0];
							ExpectedLow[0] = pivot.S2[0];
							if(State==State.Realtime){
								if(this.pCalculateShortTrades) Draw.Text(this,"SellLvl","R2 sell",15,ExpectedHigh[0], pGlobalizeLevels, "Default");
								if(this.pCalculateLongTrades)Draw.Text(this,"BuyLvl","S2 buy",15,ExpectedLow[0], pGlobalizeLevels, "Default");
							}
						}else if(pPivotLevels==3){
							ExpectedHigh[0] = pivot.R3[0];
							ExpectedLow[0] = pivot.S3[0];
							if(State==State.Realtime){
								if(this.pCalculateShortTrades) Draw.Text(this,"SellLvl","R3 sell",15,ExpectedHigh[0], pGlobalizeLevels, "Default");
								if(this.pCalculateLongTrades)Draw.Text(this,"BuyLvl","S3 buy",15,ExpectedLow[0], pGlobalizeLevels, "Default");
							}
						}
					}
					ExpectedHighA[0] = ExpectedHigh[0]+stddevH;
					ExpectedHighB[0] = ExpectedHigh[0]-stddevH;
					var t = Times[0].GetValueAt(1);
					Draw.Region(this, "regionH", t, Times[0][0], ExpectedHighA, ExpectedHighB, Brushes.Transparent, Plots[0].Brush, 20);
					ExpectedLowA[0] = ExpectedLow[0]+stddevL;
					ExpectedLowB[0] = ExpectedLow[0]-stddevL;
					Draw.Region(this, "regionL", t, Times[0][0], ExpectedLowA, ExpectedLowB, Brushes.Transparent, Plots[3].Brush, 20);

					if(pCalculateLongTrades || pCalculateShortTrades){
						tm.ExitforEOD(Times[0][0], Times[0][1], Closes[0][1]);
						var c1 = tm.IsValidTimeAndDay('S', Times[0][0], Times[0][1], CurrentBars[0]);
						var c2 = Highs[0][1]<ExpectedHigh[0] && Highs[0][0] >= ExpectedHigh[0];
						var c3 = Lows[0][1]>ExpectedHigh[0] && Lows[0][0] <= ExpectedHigh[0];
						if(pCalculateShortTrades && c1 && (c2 || c3)){
							if(State==State.Realtime && pEnableSoundAlerts && tm.AlertBar!=CurrentBar){
								Alert(DateTime.Now.ToString(), Priority.Medium, "ExpectedHighLow Sell level hit at "+Instrument.MasterInstrument.FormatPrice(ExpectedHigh[0]), AddSoundFolder(pWAVOnSellEntry), 1, Brushes.Magenta,Brushes.White);
								tm.AlertBar = CurrentBars[0];
							}
							tm.DTofLastShort = Times[0][0];//one short trade per day
							tm.Trades.Add(new SBG.TradeManager.info('S', ExpectedHigh[0], Times[0][0], double.MaxValue, ExpectedLow[0]));
							BackBrushes[0] = Brushes.Magenta;
						}
						c1 = tm.IsValidTimeAndDay('L', Times[0][0], Times[0][1], CurrentBars[0]);
						c2 = Lows[0][1]>ExpectedLow[0] && Lows[0][0] <= ExpectedLow[0];
						c3 = Highs[0][1]<ExpectedLow[0] && Highs[0][0] >= ExpectedLow[0];
						if(pCalculateLongTrades && c1 && (c2 || c3)){
							if(State==State.Realtime && pEnableSoundAlerts && tm.AlertBar!=CurrentBar){
								Alert(DateTime.Now.ToString(), Priority.Medium, "ExpectedHighLow Buy level hit at "+Instrument.MasterInstrument.FormatPrice(ExpectedLow[0]), AddSoundFolder(pWAVOnBuyEntry), 1, Brushes.Lime,Brushes.White);
								tm.AlertBar = CurrentBars[0];
							}
							tm.DTofLastLong = Times[0][0];//one long trade per day
							tm.Trades.Add(new SBG.TradeManager.info('L', ExpectedLow[0], Times[0][0], double.MinValue, ExpectedHigh[0]));
							BackBrushes[0] = Brushes.Lime;
						}
						tm.ExitforSLTP(Times[0][0], Highs[0][0], Lows[0][0], false);
						tm.UpdateMinMaxPrices(Highs[0][0], Lows[0][0]);
						tm.PrintResults(Bars.Count, CurrentBars[0], this);
					}
				}
			}
		}
//		private SharpDX.Direct2D1.Brush GreenTxtBrushDX = null;
//		private SharpDX.Direct2D1.Brush MagentaTxtBrushDX = null;
//		private SharpDX.Direct2D1.Brush CyanTxtBrushDX = null;
//		private SharpDX.Direct2D1.Brush txtFillBrushDX = null;
		public override void OnRenderTargetChanged()
		{
			tm.InitializeBrushes(RenderTarget);
		}
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
            #region -- conditions to return --
            if (!IsVisible || ChartBars.ToIndex < BarsRequiredToPlot) return;
            if (Bars == null || BarsArray[0]==null || chartControl == null) return;
            if (ChartBars.FromIndex == -1 || ChartBars.ToIndex == -1) return;
            #endregion

			if(tm.Output.Count>0){
				tm.OnRender(RenderTarget, ChartPanel, 14, 10);
			}
		}
		double StdDeviation(List<double> L, double mean){
			double sumOfSquaresOfDifferences = L.Sum(val => (val - mean) * (val - mean));
			return Math.Sqrt(sumOfSquaresOfDifferences / L.Count);
		}

		#region Properties
		[NinjaScriptProperty]
		[Display(Name="Band Size", Order=10, GroupName="Parameters", Description="Enter '20t' for 20-ticks, enter '3.5p' for 3.5-points, enter '1.2' for 1.2 standard deviations", ResourceType = typeof(Custom.Resource))]
		public string BandSizeStr
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Differentiate DOW", Order=20, GroupName="Parameters", ResourceType = typeof(Custom.Resource))]
		public bool pDifferentiateDOW
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 25, Name = "PP levels?", Description="Enter 1, 2 or 3 for using Pivot R1/S1, R2/S2 or R3/S3", GroupName = "Parameters", ResourceType = typeof(Custom.Resource))]
		public int pPivotLevels
		{ get; set; }

		[Range(0,int.MaxValue)]
		[Display(Name="Max days lookback", Order=30, Description="Set to '0' to use all days on chart, any other number will limit the calculation of the average H and L distances", GroupName="Parameters", ResourceType = typeof(Custom.Resource))]
		public int pDaysInAverage
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Basis", Order=40, GroupName="Parameters", ResourceType = typeof(Custom.Resource))]
		public ExpectedHighLow_Basis pBasis
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Timeframe", Order=50, GroupName="Parameters", ResourceType = typeof(Custom.Resource))]
		public ExpectedHighLow_Timeframe pTimeframe
		{get;set;}

		[Display(Name="Show Current DOW", Order=60, GroupName="Parameters", ResourceType = typeof(Custom.Resource))]
		public bool pShowDOW
		{ get; set; }
		
		[Display(Name="Globalize buy/sell levels?", Order=70, GroupName="Parameters", ResourceType = typeof(Custom.Resource))]
		public bool pGlobalizeLevels
		{get;set;}

		#region -- Strategy params --
		[Display(Name="Permit LONG trades", Order=10, GroupName="Strategy", ResourceType = typeof(Custom.Resource))]
		public bool pCalculateLongTrades
		{ get; set; }

		[Display(Name="Permit SHORT trades", Order=20, GroupName="Strategy", ResourceType = typeof(Custom.Resource))]
		public bool pCalculateShortTrades
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Order = 30, Name = "Days of week", GroupName = "Strategy", ResourceType = typeof(Custom.Resource))]
		public string sDaysOfWeek
		{ get; set; }

		[Display(Order = 40, Name="Trade Start time", GroupName="Strategy", Description="Trading is permitted after this time",  ResourceType = typeof(Custom.Resource))]
		public int pStartTime
		{get;set;}

		[Display(Order = 50, Name="Trade Stop time", GroupName="Strategy", Description="No more trades initiated after this time", ResourceType = typeof(Custom.Resource))]
		public int pStopTime
		{get;set;}

		[Display(Order = 60, Name="Trade Exit time", GroupName="Strategy",  Description="All open trades are flattened at this time", ResourceType = typeof(Custom.Resource))]
		public int pGoFlatTime
		{get;set;}

		[Display(Order = 10, Name="Show 'Hr of Day' Table?", GroupName="Strategy Visuals",  Description="", ResourceType = typeof(Custom.Resource))]
		public bool pShowHrOfDayTable
		{get;set;}

		#endregion
		#endregion

		#region -- Alerts --
		private string AddSoundFolder(string wav){
			wav = wav.Replace("<inst>",Instrument.MasterInstrument.Name);
			wav = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", wav);
			if(!System.IO.File.Exists(wav)) {
				Log("ExpectedHighLow could not find wav: "+wav,LogLevel.Information);
				return "";
			}else
				return wav;
		}
		internal class LoadSoundFileList : StringConverter
		{
			#region LoadSoundFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string dir = NinjaTrader.Core.Globals.InstallDir;
//				string dir = WAVDirectory;
//				if(dir.Trim().Length==0) dir = NinjaTrader.Core.Globals.InstallDir;
//				if(dir.ToLower().Contains("<default>")) dir = NinjaTrader.Core.Globals.InstallDir;
				string folder = System.IO.Path.Combine(dir, "sounds");
				string search = "*.wav";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles(search);
				}catch{}

				var list = new System.Collections.Generic.List<string>();//new string[filCustom.Length+1];
				list.Add("none");
				list.Add("<inst>_BuySetup.wav");
				list.Add("<inst>_SellSetup.wav");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
        }

		[Display(Order = 10, ResourceType = typeof(Custom.Resource), Name = "Enable sound alerts?", GroupName = "Alerts")]
		public bool pEnableSoundAlerts {get;set;}

		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		[Display(Order = 20, ResourceType = typeof(Custom.Resource), Name = "Wav on Buy Entry", GroupName = "Alerts")]
		public string pWAVOnBuyEntry {get;set;}

		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		[Display(Order = 30, ResourceType = typeof(Custom.Resource), Name = "Wav on Sell Entry", GroupName = "Alerts")]
		public string pWAVOnSellEntry {get;set;}
		#endregion

		#region Plots
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> ExpectedHigh
		{
			get { return Values[0]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> ExpectedHighA
		{
			get { return Values[1]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> ExpectedHighB
		{
			get { return Values[2]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> ExpectedLow
		{
			get { return Values[3]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> ExpectedLowA
		{
			get { return Values[4]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> ExpectedLowB
		{
			get { return Values[5]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ExpectedHighLow[] cacheExpectedHighLow;
		public ExpectedHighLow ExpectedHighLow(string bandSizeStr, bool pDifferentiateDOW, int pPivotLevels, ExpectedHighLow_Basis pBasis, ExpectedHighLow_Timeframe pTimeframe, string sDaysOfWeek)
		{
			return ExpectedHighLow(Input, bandSizeStr, pDifferentiateDOW, pPivotLevels, pBasis, pTimeframe, sDaysOfWeek);
		}

		public ExpectedHighLow ExpectedHighLow(ISeries<double> input, string bandSizeStr, bool pDifferentiateDOW, int pPivotLevels, ExpectedHighLow_Basis pBasis, ExpectedHighLow_Timeframe pTimeframe, string sDaysOfWeek)
		{
			if (cacheExpectedHighLow != null)
				for (int idx = 0; idx < cacheExpectedHighLow.Length; idx++)
					if (cacheExpectedHighLow[idx] != null && cacheExpectedHighLow[idx].BandSizeStr == bandSizeStr && cacheExpectedHighLow[idx].pDifferentiateDOW == pDifferentiateDOW && cacheExpectedHighLow[idx].pPivotLevels == pPivotLevels && cacheExpectedHighLow[idx].pBasis == pBasis && cacheExpectedHighLow[idx].pTimeframe == pTimeframe && cacheExpectedHighLow[idx].sDaysOfWeek == sDaysOfWeek && cacheExpectedHighLow[idx].EqualsInput(input))
						return cacheExpectedHighLow[idx];
			return CacheIndicator<ExpectedHighLow>(new ExpectedHighLow(){ BandSizeStr = bandSizeStr, pDifferentiateDOW = pDifferentiateDOW, pPivotLevels = pPivotLevels, pBasis = pBasis, pTimeframe = pTimeframe, sDaysOfWeek = sDaysOfWeek }, input, ref cacheExpectedHighLow);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ExpectedHighLow ExpectedHighLow(string bandSizeStr, bool pDifferentiateDOW, int pPivotLevels, ExpectedHighLow_Basis pBasis, ExpectedHighLow_Timeframe pTimeframe, string sDaysOfWeek)
		{
			return indicator.ExpectedHighLow(Input, bandSizeStr, pDifferentiateDOW, pPivotLevels, pBasis, pTimeframe, sDaysOfWeek);
		}

		public Indicators.ExpectedHighLow ExpectedHighLow(ISeries<double> input , string bandSizeStr, bool pDifferentiateDOW, int pPivotLevels, ExpectedHighLow_Basis pBasis, ExpectedHighLow_Timeframe pTimeframe, string sDaysOfWeek)
		{
			return indicator.ExpectedHighLow(input, bandSizeStr, pDifferentiateDOW, pPivotLevels, pBasis, pTimeframe, sDaysOfWeek);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ExpectedHighLow ExpectedHighLow(string bandSizeStr, bool pDifferentiateDOW, int pPivotLevels, ExpectedHighLow_Basis pBasis, ExpectedHighLow_Timeframe pTimeframe, string sDaysOfWeek)
		{
			return indicator.ExpectedHighLow(Input, bandSizeStr, pDifferentiateDOW, pPivotLevels, pBasis, pTimeframe, sDaysOfWeek);
		}

		public Indicators.ExpectedHighLow ExpectedHighLow(ISeries<double> input , string bandSizeStr, bool pDifferentiateDOW, int pPivotLevels, ExpectedHighLow_Basis pBasis, ExpectedHighLow_Timeframe pTimeframe, string sDaysOfWeek)
		{
			return indicator.ExpectedHighLow(input, bandSizeStr, pDifferentiateDOW, pPivotLevels, pBasis, pTimeframe, sDaysOfWeek);
		}
	}
}

#endregion
