#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class AlwaysIn : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "Always-In";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive = false;
				pRangeSizeStr	= "atr 2.5";
				StartTime		= 930;
				StopTime		= 1550;
				pPermittedDOW	= "1,2,3,4,5";
				pTargetDistStr = "t 8";
				pDailyTgtDollars = 1000;
				AddPlot(new Stroke(Brushes.YellowGreen, 4), PlotStyle.Bar, "Equity");
				AddPlot(new Stroke(Brushes.Blue, 2), PlotStyle.Line, "OpenEquity");
				AddPlot(new Stroke(Brushes.White, 2), PlotStyle.Dot, "Direction");
				AddLine(Brushes.DarkGray, 0, Custom.Resource.NinjaScriptIndicatorZeroLine);
			}
			else if (State == State.Configure)
			{
				PV = Instrument.MasterInstrument.PointValue;
//				equity_tgt = DollarsTarget;
				ClearOutputWindow();
				if(pRangeSizeStr.ToLower().Contains("a")) {
					ATRmultRange = StrToDouble(pRangeSizeStr);
					TksRange = 0;
					RangeBasisStr = ATRmultRange+"x ATR";
				}else if(pRangeSizeStr.ToLower().Contains("$")) {
					double DollarsRange = StrToDouble(pRangeSizeStr);
					TksRange = Convert.ToInt32(DollarsRange / PV / TickSize);
					ATRmultRange = 0;
					RangeBasisStr = string.Format("${0}", DollarsRange);
				}
				else{
					TksRange = StrToInt(pRangeSizeStr);
					ATRmultRange = 0;
					RangeBasisStr = TksRange+"-ticks";
				}

				if(pTargetDistStr.ToLower().Contains("a")) {
					ATRmultTarget = StrToDouble(pTargetDistStr);
					DollarsTarget = 0;
					TargetBasisStr = ATRmultTarget+"x ATR based tgt";
				}else if(pTargetDistStr.ToLower().Contains("$")) {
					DollarsTarget = StrToDouble(pTargetDistStr);
					ATRmultTarget = 0;
					TargetBasisStr = string.Format("${0}", DollarsTarget);
				}
				else{
					int tks = StrToInt(pTargetDistStr);
					DollarsTarget = tks * TickSize * PV;
					ATRmultTarget = 0;
					TargetBasisStr = tks+"-ticks";
				}
			}
			else if(State == State.DataLoaded){
				atr = ATR(14);
			}
		}
		private double StrToDouble(string s){
			var ch = s.ToCharArray();
			string result = "";
			foreach(var c in ch) if((c>='0' && c<='9') || c=='.' || c=='-') result = string.Format("{0}{1}",result,c);
			if(result.Length==0) return 0;
			return Convert.ToDouble(result);
		}
		private int StrToInt(string s){
			var ch = s.ToCharArray();
			string result = "";
			foreach(var c in ch) if((c>='0' && c<='9') || c=='-') result = string.Format("{0}{1}",result,c);
			if(result.Length==0) return 0;
			return Convert.ToInt32(result);
		}

		ATR atr;
		double PV = 0;
		int Pos = 0;
		int LONG = 1;
		int SHORT = -1;
		int FLAT = 0;
		double EntryPrice = double.MinValue;
		int TksRange		= 3;
		double ATRmultRange	= 2.5;

		double DollarsTarget = 200;
		double ATRmultTarget = 2.5;

		double LongEntry = 0;
		double ShortEntry = 0;
		double TgtPrice = 0;
		double equity_pts = 0;
		int tradestartabar = 0;
//		int sessionlastabar = 0;
		bool Reset = false;
		double equity_tgt = 0;
		int day = 0;
		double pnl = 0;
		bool InSession = false;
		#region -- Supporting methods --
		private void Printit(string s){
			if(Times[0][0].Day==16) Print(s);
		}
		private void GoFlat(ref double equity_pts, double exitprice = 0, string Disposition=""){
			if(Pos==FLAT) return;
			if(exitprice!=0){
				if(Pos==LONG)  pnl = (exitprice - EntryPrice) * PV;
				if(Pos==SHORT) pnl = (EntryPrice - exitprice) * PV;
				equity_pts = (pnl + Equity[1])/ PV;
			}else{
				if(Pos==LONG)  pnl = (Highs[0][0] - EntryPrice) * PV;
				if(Pos==SHORT) pnl = (EntryPrice - Lows[0][0]) * PV;
				equity_pts = (pnl + Equity[1])/ PV;
			}
			if(tradestartabar>0){
				Draw.Line(this,string.Format("bl{0}", tradestartabar), CurrentBars[0]-tradestartabar, LongEntry, 1, LongEntry, Brushes.Blue);
				Draw.Line(this,string.Format("sl{0}", tradestartabar), CurrentBars[0]-tradestartabar, ShortEntry, 1, ShortEntry, Brushes.Red);
			}
			tradestartabar = 0;
			Printit(Instrument.MasterInstrument.FormatPrice(equity_pts)+"\t"+Times[0][0].ToString()+"  "+Disposition+", trade net: "+Instrument.MasterInstrument.FormatPrice(pnl));
//			equity_tgt += DollarsTarget;
			Pos = FLAT;
			pnl = 0;
			EntryPrice = double.MinValue;
		}
		private double CalcTgt(int Pos, double EntryPrice, double CurrentClosedEquity){
			double t1 = 0;
			double t2 = 0;
//			if(pDailyTgtDollars > 0){
//				t1 = Instrument.MasterInstrument.RoundToTickSize((pDailyTgtDollars - CurrentClosedEquity) / PV);
//				Printit(Times[0][0].ToString()+"Closed Eqty: "+CurrentClosedEquity.ToString("C")+"  Tgt pts: "+t1);
//			}else{
//				t2 = atr[0]*ATRmultTarget;
//				//t2 = Math.Max(t2, this.DollarsTarget / PV);
//			}
			if(DollarsTarget>0)
				t2 = Instrument.MasterInstrument.RoundToTickSize(this.DollarsTarget / PV);
			else if(ATRmultTarget>0)
				t2 = Instrument.MasterInstrument.RoundToTickSize(atr[0]*ATRmultTarget);

			if(Pos==LONG)
				return Instrument.MasterInstrument.RoundToTickSize(EntryPrice + Math.Max(t1,t2));
			else 
				return Instrument.MasterInstrument.RoundToTickSize(EntryPrice - Math.Max(t1,t2));
		}
		#endregion
		private void AddToTODList(int tod, double pnl, bool InZone=false){
			var hr = (int)Math.Truncate(tod/10000.0);
			var min = (int)Math.Truncate(tod/100.0 - hr*100);
			int t = 0;
			if(min<30) t = hr*100;
			else t = hr*100+30;
			if(!PnLByTOD.ContainsKey(t)) PnLByTOD[t] = new List<double>();
			else PnLByTOD[t].Add(pnl);
			if(InZone) Print(tod+"  "+t+"  "+pnl);
		}

		DateTime DateTgtAchieved = DateTime.MinValue;
		SortedDictionary<DayOfWeek, List<double>> PnLByDOW = new SortedDictionary<DayOfWeek,List<double>>();
		SortedDictionary<DateTime, List<double>> PnLByDate = new SortedDictionary<DateTime,List<double>>();
		SortedDictionary<DayOfWeek, List<DateTime>> DaysCounter = new SortedDictionary<DayOfWeek, List<DateTime>>();
		SortedDictionary<int, List<double>> PnLByTOD = new SortedDictionary<int, List<double>>();//TOD is time of day
		int LastEntryTime = -1;
		bool DailyTgtAchieved = false;
		string RangeBasisStr = "";
		string TargetBasisStr = "";

		protected override void OnBarUpdate()
		{
			if(CurrentBar<5) return;
			var t1 = ToTime(Times[0][1])/100;
			var t = ToTime(Times[0][0])/100;
			var dow = Times[0][0].DayOfWeek;
			var date = Times[0][0].Date;

			if(!PnLByDOW.ContainsKey(Times[0][0].DayOfWeek)){
				PnLByDOW[dow] = new List<double>();
				DaysCounter[dow] = new List<DateTime>();
			}

			var ts = new TimeSpan(Times[0][0].Ticks - Times[0][1].Ticks);
			bool SlowEnough = true;//ts.TotalSeconds >= 3;
			bool TradeToday = pPermittedDOW.Contains(((int)dow).ToString());
			if(day != Times[0][0].Day)
				DailyTgtAchieved = false;
			else if(pDailyTgtDollars>0 && equity_pts*PV > pDailyTgtDollars)
				DailyTgtAchieved = true;

			if(DailyTgtAchieved && Times[0][0].Date != DateTgtAchieved){
				InSession = false;
				DateTgtAchieved = Times[0][0].Date;
				GoFlat(ref equity_pts, Closes[0][0], "Daily Tgt achieved");
				Equity[1] = equity_pts*PV;
				if(Equity[1] < 0) PlotBrushes[0][1] = Brushes.Magenta;
				Equity[0] = 0;
				equity_pts = 0;
//				sessionlastabar = CurrentBars[0];
				return;
			}
			if(Times[0][0].Date != DateTgtAchieved){
				bool HitStartTime = TradeToday && t1 < StartTime && t >= StartTime;
				if(SlowEnough && HitStartTime || Reset)
				{
					if(HitStartTime){
						Draw.VerticalLine(this,"VL"+CurrentBar.ToString(), Times[0][0], Brushes.Lime);
						InSession = true;
					}
					if(InSession){
						if(tradestartabar>0 && LongEntry!=0 && ShortEntry!=0){
							Draw.Line(this,string.Format("bl{0}", tradestartabar), CurrentBars[0]-tradestartabar, LongEntry, 1, LongEntry, Brushes.Blue);
							Draw.Line(this,string.Format("sl{0}", tradestartabar), CurrentBars[0]-tradestartabar, ShortEntry, 1, ShortEntry, Brushes.Red);
						}
						tradestartabar = CurrentBars[0];
						day = Times[0][0].Day;
						if(ATRmultRange>0){
							LongEntry = Closes[0][0] + atr[0]*ATRmultRange;
							ShortEntry = Closes[0][0] - atr[0]*ATRmultRange;
						}else{
							LongEntry = Closes[0][0] + TksRange*TickSize;
							ShortEntry = Closes[0][0] - TksRange*TickSize;
						}
						Draw.Dot(this,string.Format("b{0}", CurrentBars[0]), false,0,LongEntry,Brushes.Blue);
						Draw.Dot(this,string.Format("s{0}", CurrentBars[0]), false,0,ShortEntry,Brushes.Red);
						Reset = false;
					}
				}
//				if(DailyTgtAchieved){
//					DateTgtAchieved = Times[0][0].Date;
//					GoFlat(ref equity_pts, Closes[0][0], "Daily Tgt achieved");
//					Equity[1] = equity_pts*PV;
//					Equity[0] = 0;
//					equity_pts = 0;
//					sessionlastabar = CurrentBars[0];
//					InSession = false;
//				}else
			}
			if(InSession && t1 < StopTime && t >= StopTime || !TradeToday) {
				GoFlat(ref equity_pts, Closes[0][0], "EndOfDay");
				Equity[1] = equity_pts*PV;
				if(Equity[1] < 0) PlotBrushes[0][1] = Brushes.Magenta;
				Equity[0] = 0;
				equity_pts = 0;
//				sessionlastabar = CurrentBars[0];
				InSession = false;
//				equity_tgt = this.DollarsTarget;
			}else{
				Equity[0] = equity_pts*PV;
				if(Equity[0] < 0) PlotBrushes[0][0] = Brushes.Magenta;
			}
			if(!InSession) PlotBrushes[0][0] = Brushes.DimGray;

			if(day != 0 && InSession && CurrentBars[0]>tradestartabar){
				if(Highs[0][0] > LongEntry && Pos != LONG){
					if(Pos == SHORT){//exit the short and go long
						var e = EntryPrice - LongEntry;
						PnLByDOW[dow].Add(e);
						if(!DaysCounter[dow].Contains(Times[0][0].Date)) DaysCounter[dow].Add(Times[0][0].Date);
						if(!PnLByDate.ContainsKey(Times[0][0].Date)) PnLByDate[date] = new List<double>(); PnLByDate[date].Add(e);
						Printit(Instrument.MasterInstrument.FormatPrice(equity_pts)+"\t"+Times[0][0].ToString()+"  Reversing from short to long, trade net: "+Instrument.MasterInstrument.FormatPrice(e));
						equity_pts += e;
						if(LastEntryTime>0) AddToTODList(LastEntryTime, e);//, Times[0][0].Month==4 && Times[0][0].Day==19);
						LastEntryTime = ToTime(Times[0][0]);
					}
					if(InSession && SlowEnough){
						Pos = LONG;
						EntryPrice = LongEntry;
						TgtPrice = CalcTgt(LONG, EntryPrice, Equity[0]);
						Printit("------  Now LONG, Tgt: "+TgtPrice);
						LastEntryTime = ToTime(Times[0][0]);
					}
				}
				else if(Lows[0][0] < ShortEntry && Pos != SHORT){
					if(Pos == LONG){//exit the long and go short
						var e = ShortEntry - EntryPrice;
						PnLByDOW[dow].Add(e);
						if(!DaysCounter[dow].Contains(Times[0][0].Date)) DaysCounter[dow].Add(Times[0][0].Date);
						if(!PnLByDate.ContainsKey(Times[0][0].Date)) PnLByDate[date] = new List<double>(); PnLByDate[date].Add(e);
						Printit(Instrument.MasterInstrument.FormatPrice(equity_pts)+"\t"+Times[0][0].ToString()+"  Reversing from long to short, trade net: "+Instrument.MasterInstrument.FormatPrice(e));
						equity_pts += e;
						if(LastEntryTime>0) AddToTODList(LastEntryTime, e);//, Times[0][0].Month==4 && Times[0][0].Day==19);
						LastEntryTime = ToTime(Times[0][0]);
					}
					if(InSession && SlowEnough){
						Pos = SHORT;
						EntryPrice = ShortEntry;
						TgtPrice = CalcTgt(SHORT, EntryPrice, Equity[0]);
						Printit("------  Now SHORT, Tgt: "+TgtPrice);
						LastEntryTime = ToTime(Times[0][0]);
					}
				}
				if(Pos != FLAT){
					Direction[0] = 0;
					if(Pos==LONG) PlotBrushes[2][0] = Brushes.Green;
					else if(Pos==SHORT) PlotBrushes[2][0] = Brushes.Red;
					else PlotBrushes[2][0] = Brushes.Transparent;
					pnl = 0;
					if(Pos==LONG){
						string tg = string.Format("btarg{0}", tradestartabar);
						RemoveDrawObject(tg);
						Draw.Diamond(this,tg, false,0,TgtPrice,Brushes.Yellow);
						if(Highs[0][0]>TgtPrice){
							double e = TgtPrice - EntryPrice;
							PnLByDOW[dow].Add(e);
							if(!DaysCounter[dow].Contains(Times[0][0].Date)) DaysCounter[dow].Add(Times[0][0].Date);
							if(!PnLByDate.ContainsKey(Times[0][0].Date)) PnLByDate[date] = new List<double>(); PnLByDate[date].Add(TgtPrice - EntryPrice);
							AddToTODList(LastEntryTime, e);//, Times[0][0].Month==4 && Times[0][0].Day==19);
							LastEntryTime = -1;
							GoFlat(ref equity_pts, TgtPrice, "Going flat at profit target");
							Reset = true;
						}
						else pnl = (Highs[0][0] - EntryPrice) * PV;
					}
					if(Pos==SHORT){
						string tg = string.Format("starg{0}", tradestartabar);
						RemoveDrawObject(tg);
						Draw.Diamond(this,tg, false,0,TgtPrice,Brushes.Yellow);
						if(Lows[0][0]<TgtPrice){
							var e = EntryPrice - TgtPrice;
							PnLByDOW[dow].Add(e);
							if(!DaysCounter[dow].Contains(Times[0][0].Date)) DaysCounter[dow].Add(Times[0][0].Date);
							if(!PnLByDate.ContainsKey(Times[0][0].Date)) PnLByDate[date] = new List<double>(); PnLByDate[date].Add(EntryPrice - TgtPrice);
							AddToTODList(LastEntryTime, e);//, Times[0][0].Month==4 && Times[0][0].Day==19);
							LastEntryTime = -1;
							GoFlat(ref equity_pts, TgtPrice, "Going flat at profit target");
							Reset = true;
						}
						else pnl = (EntryPrice - Lows[0][0]) * PV;
					}
					OpenEquity[0] = pnl;
				}

//				if(pnl+Equity[0] > equity_tgt){
//					Printit(Times[0][0].ToString());
//					Printit("Trade PNL of "+pnl.ToString("C")+" achieved, closed PnL of "+Equity[0].ToString("C")+"  Target achieved, going flat now");
//					GoFlat();
//					Printit("New closed equity (in pts): "+Instrument.MasterInstrument.FormatPrice(equity_pts));
//					Reset = true;
//				}
				//EquityTgt[0] = equity_tgt;
			}
			if(!SlowEnough && Pos == FLAT){
				if(ATRmultRange>0){
					LongEntry = Closes[0][0] + atr[0]*ATRmultRange;
					ShortEntry = Closes[0][0] - atr[0]*ATRmultRange;
				}else{
					LongEntry = Closes[0][0] + TksRange*TickSize;
					ShortEntry = Closes[0][0] - TksRange*TickSize;
				}
			}
			if(CurrentBars[0] > BarsArray[0].Count-3 && PnLByDOW.Count>0){
				if(!PrintedResults){
					PrintedResults = true;
					Print("\n"+Instrument.MasterInstrument.Name+" "+BarsArray[0].BarsPeriod.ToString());
					Print("\nPnL By DayOfWeek");
					foreach(var kvp in PnLByDOW){
						if(kvp.Value.Count>0){
							var tot = kvp.Value.Sum() * PV;
							var avgtrade = kvp.Value.Average() * PV;
							var avgperday = tot/DaysCounter[kvp.Key].Count;
							double wincount = kvp.Value.Count(k=>k>0);
							var winpct = wincount/kvp.Value.Count;
							Print(kvp.Key.ToString().Substring(0,3)+"("+DaysCounter[kvp.Key].Count+")\t  pnl: "+tot.ToString("C")+"\t avg/Trade: "+avgtrade.ToString("C")+"  \t avg/Day: "+avgperday.ToString("C")+"\t "+winpct.ToString("0%")+"  "+wincount+" of "+kvp.Value.Count);
							foreach(var pnld in PnLByDate){
								if(pnld.Key.DayOfWeek == kvp.Key) Print("  "+pnld.Key.ToShortDateString()+"  "+(pnld.Value.Sum()*PV).ToString("C")+" on "+pnld.Value.Count+"-trades");
							}
						}
					}

					int wcount = 0;
					Print("\nPnL By Time of Day");
					foreach(var tod in PnLByTOD){
						if(tod.Value.Count>0){
							wcount = tod.Value.Count(k=>k>0);
							var lcount = tod.Value.Count-wcount;
							Print(tod.Key+":  w:"+wcount+" / L: "+lcount+",   sum = "+(tod.Value.Sum() * PV).ToString("C"));
						}
					}
					DoMonteCarlo(100, 150);

					var bestdt = DateTime.MinValue;
					var worstdt = DateTime.MinValue;
					double bestpnl = double.MinValue;
					double worstpnl = double.MaxValue;
					double sumofalldates = 0;
					foreach(var kvp in PnLByDate){
						double sum = kvp.Value.Sum();
						kvp.Value.Clear();
						kvp.Value.Add(sum);
						sumofalldates += sum;
						if(sum > bestpnl){
							bestpnl = sum;
							bestdt = kvp.Key;
						}
						if(sum < worstpnl){
							worstpnl = sum;
							worstdt = kvp.Key;
						}
					}
					Print("\nBest day: "+bestdt.ToShortDateString()+" with "+(PV*bestpnl).ToString("C"));
					Print("Worst day: "+worstdt.ToShortDateString()+" with "+(PV*worstpnl).ToString("C"));
					double avg = sumofalldates/PnLByDate.Count;
					Print("Avg day: "+(PV*avg).ToString("C"));

					wcount = 0;
					sumofalldates = 0;
					foreach(var kvp in PnLByDate){
						double diff = kvp.Value[0] - avg;
						if(kvp.Value[0]>0) wcount++;
						sumofalldates += diff*diff;
					}
					Print("Daily StdDev: "+(PV*Math.Sqrt(sumofalldates/PnLByDate.Count)).ToString("C"));
					Print("Winning days: "+wcount+"  losing days: "+(PnLByDate.Count-wcount));
					Print("Range Basis: "+RangeBasisStr);
					Print("Target Basis: "+TargetBasisStr);
				}
				PnLByDOW.Clear();
			}
		}
		private void DoMonteCarlo(int BatchesCount, int MaxSamplesCountPerBatch){
			var distribution = new List<double>();
			var r = new Random();

			var pnl_table = new List<double>();
			var list = PnLByTOD.SelectMany(k=> k.Value).ToList();
			for(int batch = 0; batch< BatchesCount; batch++){
				int samples = Math.Min(MaxSamplesCountPerBatch, list.Count/2);
				var randoms = Enumerable.Range(0, list.Count).OrderBy(_ => r.Next()).Take(samples).ToList();//guarantees unique random numbers in this list
				pnl_table.Clear();//calc the PnL for each batch of samples...100 batches
				for(int i = 0;i<randoms.Count; i++){//number of samples is list.Count/2
					int idx = Convert.ToInt32(randoms[i]);
					pnl_table.Add(list[idx]);
				}
				distribution.Add(pnl_table.Sum());
			}
//			distribution.Sort();
//			Print("distribution:");
//			for(int kk = 0; kk<distribution.Count; kk++) Print(kk+":  "+distribution[kk].ToString("C"));
			var winning_iterations = distribution.Count(k=>k>0);
			Print("Monte Carlo:  You have a "+(winning_iterations*1.0/distribution.Count).ToString("0%")+ " of a positive balance");
			Print("Worst Monte Carlo balance:  "+(distribution.Min()*PV).ToString("C")+"   Best: "+(distribution.Max()*PV).ToString("C")+"  Avg: "+distribution.Average().ToString("C"));
		}
		
		bool PrintedResults = false;
		#region Properties
		[NinjaScriptProperty]
		[Display(Name="Range Size and type", Description="'$100', 'atr 3.5' or 't 15'", Order=10, GroupName="Parameters")]
		public string pRangeSizeStr
		{ get; set; }

//		[NinjaScriptProperty]
//		[Range(1, int.MaxValue)]
//		[Display(Name="Tks Range", Order=10, GroupName="Parameters")]
//		public int TksRange
//		{ get; set; }
		
//		[NinjaScriptProperty]
//		[Range(0, double.MaxValue)]
//		[Display(Name="ATR Mult Range", Order=11, GroupName="Parameters", Description="")]
//		public double ATRmultRange
//		{get;set;}

		[NinjaScriptProperty]
		[Range(1, 2359)]
		[Display(Name="Start Time", Order=20, GroupName="Parameters")]
		public int StartTime
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(1, 2359)]
		[Display(Name="Stop Time", Order=21, GroupName="Parameters")]
		public int StopTime
		{ get; set; }
		
		[Display(Name="Days of week", Order=40, GroupName="Parameters")]
		public string pPermittedDOW
		{get;set;}

		[NinjaScriptProperty]
		[Display(Name="Target Size and type", Description="'$100', 'atr 3.5' or 't 15'", Order=10, GroupName="Target")]
		public string pTargetDistStr
		{get;set;}

//		[NinjaScriptProperty]
//		[Range(0, double.MaxValue)]
//		[Display(Name="Target $", Order=10, GroupName="Target")]
//		public double DollarsTarget
//		{get;set;}
//		[NinjaScriptProperty]
//		[Range(0, double.MaxValue)]
//		[Display(Name="Target ATR Mult", Order=20, GroupName="Target", Description="")]
//		public double ATRmultTarget
//		{get;set;}

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Daily Profit Stop $", Order=30, GroupName="Target", Description="")]
		public double pDailyTgtDollars
		{get;set;}
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Equity
		{
			get { return Values[0]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> OpenEquity
		{
			get { return Values[1]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Direction
		{
			get { return Values[2]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private AlwaysIn[] cacheAlwaysIn;
		public AlwaysIn AlwaysIn(string pRangeSizeStr, int startTime, int stopTime, string pTargetDistStr, double pDailyTgtDollars)
		{
			return AlwaysIn(Input, pRangeSizeStr, startTime, stopTime, pTargetDistStr, pDailyTgtDollars);
		}

		public AlwaysIn AlwaysIn(ISeries<double> input, string pRangeSizeStr, int startTime, int stopTime, string pTargetDistStr, double pDailyTgtDollars)
		{
			if (cacheAlwaysIn != null)
				for (int idx = 0; idx < cacheAlwaysIn.Length; idx++)
					if (cacheAlwaysIn[idx] != null && cacheAlwaysIn[idx].pRangeSizeStr == pRangeSizeStr && cacheAlwaysIn[idx].StartTime == startTime && cacheAlwaysIn[idx].StopTime == stopTime && cacheAlwaysIn[idx].pTargetDistStr == pTargetDistStr && cacheAlwaysIn[idx].pDailyTgtDollars == pDailyTgtDollars && cacheAlwaysIn[idx].EqualsInput(input))
						return cacheAlwaysIn[idx];
			return CacheIndicator<AlwaysIn>(new AlwaysIn(){ pRangeSizeStr = pRangeSizeStr, StartTime = startTime, StopTime = stopTime, pTargetDistStr = pTargetDistStr, pDailyTgtDollars = pDailyTgtDollars }, input, ref cacheAlwaysIn);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.AlwaysIn AlwaysIn(string pRangeSizeStr, int startTime, int stopTime, string pTargetDistStr, double pDailyTgtDollars)
		{
			return indicator.AlwaysIn(Input, pRangeSizeStr, startTime, stopTime, pTargetDistStr, pDailyTgtDollars);
		}

		public Indicators.AlwaysIn AlwaysIn(ISeries<double> input , string pRangeSizeStr, int startTime, int stopTime, string pTargetDistStr, double pDailyTgtDollars)
		{
			return indicator.AlwaysIn(input, pRangeSizeStr, startTime, stopTime, pTargetDistStr, pDailyTgtDollars);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.AlwaysIn AlwaysIn(string pRangeSizeStr, int startTime, int stopTime, string pTargetDistStr, double pDailyTgtDollars)
		{
			return indicator.AlwaysIn(Input, pRangeSizeStr, startTime, stopTime, pTargetDistStr, pDailyTgtDollars);
		}

		public Indicators.AlwaysIn AlwaysIn(ISeries<double> input , string pRangeSizeStr, int startTime, int stopTime, string pTargetDistStr, double pDailyTgtDollars)
		{
			return indicator.AlwaysIn(input, pRangeSizeStr, startTime, stopTime, pTargetDistStr, pDailyTgtDollars);
		}
	}
}

#endregion
