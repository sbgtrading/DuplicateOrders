using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.NinjaScript.Strategies.Licensing;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_SpringboardAlgo : ARC_SpringboardAlgo_ARCStrategyBase
	{
		public override string ProductVersion => "v1.0.2 (3/18/2024)";
		public override string ProductInfusionSoftTag => "27685";
		protected override bool AllowIntrabarEntries => true;
		public override bool HasStrategyBasedStops => true;

		private readonly ARC_SpringboardAlgo_DefaultingDictionary<int, int> consecutiveCount = new ARC_SpringboardAlgo_DefaultingDictionary<int, int>();
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_SpringboardAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "Springboard Algo";

				MinConsecutiveBars = 1;
				EntryOffset = 0;

				StopLossOffset = 0;
				StopLossLookback = 1;
			}
			else if (State == State.Configure)
			{
				consecutiveCount.Clear();
			}
		}
		
		protected override void OnTickBar()
		{
			if (CurrentBars[0] < 0)
				return;

			var barDir = Closes[tickBarsIdx][0].ApproxCompare(Closes[tickBarsIdx][1]);
			for (var dir = -1; dir <= 1; dir += 2)
			{
				if (consecutiveCount[dir] < MinConsecutiveBars)
					continue;
		
				if (barDir != 0 && barDir != dir)
					continue;

				var entryPrice = (dir == 1 ? Highs : Lows)[0][0] + dir * EntryOffset * TickSize;
				if (!Closes[tickBarsIdx].ARC_SpringboardAlgo_Crossed(entryPrice))
					continue;

				if (!TradeAllowed(dir))
					continue;

				var sl = (double?)null;
				if (EnableAlgoDefinedStopLosses)
				{
					sl = dir == 1 ? CurBarLow : CurBarHigh;
					var stopSeries = (dir == 1 ? Lows : Highs)[0];
					var lookback = Math.Min(consecutiveCount[dir], StopLossLookback);
					if (lookback == 0 && stopSeries[0].ApproxCompare(sl.Value) == -dir)
						lookback++;

					for (var i = 0; i < lookback; i++)
						if (stopSeries[i].ApproxCompare(sl.Value) == -dir)
							sl = stopSeries[i];

					sl -= dir * StopLossOffset * (StopLossOffsetType == ARC_SpringboardAlgo_SpringboardStopLossOffsetType.Ticks ? TickSize : (GetRange(lookback) / 100));
					if (!TradeAllowedWithStop(Close[0], sl.Value))
						continue;
				}

				QueueEntry(dir, 1, stopLossPrice: sl);
				break;
			}
		}

		protected override void OnPrimaryBar()
		{
			if (CurrentBar == 0)
				return;

			for (var side = -1; side <= 1; side += 2)
			{
				var compSeries = side == 1 ? High : Low;
				var extremeComparison = compSeries[0].ApproxCompare(compSeries[1]);
				if (extremeComparison == side || (!AllowEqualHighLows && extremeComparison == 0))
					consecutiveCount[side] = 0;
				else
					consecutiveCount[side]++;
			}
		}

		#region Parameters
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "Min Consecutive Bars", GroupName = StrategyParameterGroupName, Order = 0)]
		public int MinConsecutiveBars { get; set; }

		[NinjaScriptProperty, Range(int.MinValue, int.MaxValue)]
		[Display(Name = "Entry Offset (Ticks)", GroupName = StrategyParameterGroupName, Order = 1)]
		public int EntryOffset { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Allow Equal Highs/Lows?", GroupName = StrategyParameterGroupName, Order = 2)]
		public bool AllowEqualHighLows { get; set; }

		#region Stop Loss
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_SpringboardAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_SpringboardAlgo_PropComparisonType.EQ, ARC_SpringboardAlgo_BoolEnum.True)]
		[Display(Name = "Stop Loss Offset Type", GroupName = StopLossGroupName, Order = 1)]
		public ARC_SpringboardAlgo_SpringboardStopLossOffsetType StopLossOffsetType { get; set; }
		
		[NinjaScriptProperty, Range(int.MinValue, int.MaxValue)]
		[ARC_SpringboardAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_SpringboardAlgo_PropComparisonType.EQ, ARC_SpringboardAlgo_BoolEnum.True)]
		[ARC_SpringboardAlgo_Rename("Stop Loss Offset (Ticks)", nameof(StopLossOffsetType), ARC_SpringboardAlgo_PropComparisonType.EQ, ARC_SpringboardAlgo_SpringboardStopLossOffsetType.Ticks)]
		[ARC_SpringboardAlgo_Rename("Stop Loss Offset (% Lookback Range)", nameof(StopLossOffsetType), ARC_SpringboardAlgo_PropComparisonType.EQ, ARC_SpringboardAlgo_SpringboardStopLossOffsetType.PercentOfLookbackRange)]
		[Display(Name = "Stop Loss Offset", GroupName = StopLossGroupName, Order = 2)]
		public int StopLossOffset { get; set; }
		
		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[ARC_SpringboardAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_SpringboardAlgo_PropComparisonType.EQ, ARC_SpringboardAlgo_BoolEnum.True)]
		[Display(Name = "Bars Back for Stop Loss Placement", GroupName = StopLossGroupName, Order = 3)]
		public int StopLossLookback { get; set; }
		#endregion
		#endregion
	}

	public enum ARC_SpringboardAlgo_SpringboardStopLossOffsetType
	{
		Ticks,
		PercentOfLookbackRange
	}
}