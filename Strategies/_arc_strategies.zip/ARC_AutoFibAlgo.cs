using System;
using System.Collections.Generic;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.Indicators.ARC;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript.Indicators;
using SharpDX;
using SharpDX.Direct2D1;
using Brush = System.Windows.Media.Brush;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	[ARC_AutoFibAlgo_CoLicenses(typeof(ARC_AutoFibAlgo_ARC_GoldenFibsSys))]
	public class ARC_AutoFibAlgo : ARC_AutoFibAlgo_ARCStrategyBase
	{
		public override string ProductVersion { get { return "v1.0.10 (9/13/2023)"; } }
		public override string ProductInfusionSoftTag { get { return "26194"; } }
		protected override bool AllowIntrabarEntries { get { return true; } }

		internal int LookbackMinutes { get { return 24 * 60 * LookBackMinute / BarPeriod; } }

		private class EntryZoneActivePeriod
		{
			public int StartBar { get; set; }
			public int? EndBar { get; set; }
			public int Side { get; set; }
		}

		private class EntryZone
		{
			public bool IsActive { get { return ActivePeriods.Count != 0 && ActivePeriods.Last().EndBar == null; } }
			public int Side { get { return InitialSide * (Flips.Count % 2 == 0 ? 1 : -1); } }
			public int InitialSide { get; set; }
			public double FibLevel { get; set; }
			public int StartBar { get; set; }
			public int? EndBar { get; set; }
			public int Entries { get; set; }
			public List<int> Flips { get; private set; }
			public List<EntryZoneActivePeriod> ActivePeriods { get; private set; }
			private readonly SortedDictionary<int, double> zoneSizeAtBar = new SortedDictionary<int, double>();

			public EntryZone()
			{
				Flips = new List<int>();
				ActivePeriods = new List<EntryZoneActivePeriod>();
			}

			public void FlipDir(int currentBar)
			{
				Flips.Add(currentBar);
				Entries = 0;
			}
			
			public void ToggleActiveState(int currentBar)
			{
				if (IsActive)
					ActivePeriods.Last().EndBar = currentBar;
				else
					ActivePeriods.Add(new EntryZoneActivePeriod { Side = Side, StartBar = currentBar });
			}

			/// <summary>
			/// Get or set the size of the zone at the specified bar
			/// </summary>
			/// <param name="bar"></param>
			/// <returns></returns>
			public double this[int bar]
			{
				get
				{
					if (zoneSizeAtBar.Count == 0)
						throw new KeyNotFoundException();

					double zoneSize;
					if (zoneSizeAtBar.TryGetValue(bar, out zoneSize))
						return zoneSize;

					return bar < zoneSizeAtBar.Keys.First() ? zoneSizeAtBar.Values.First() : zoneSizeAtBar.Values.Last();
				}
				set { zoneSizeAtBar[bar] = value; }
			}
		}

		private double CurrentZoneSize
		{
			get
			{
				return (ZoneSizeType == ARC_AutoFibAlgo_AutoFibAlgoZoneSizeType.Ticks ? TickSize : zoneSizeAtr[0]) * ZoneSize;
			}
		}

		private ARC_AutoFibAlgo_ARC_GoldenFibsSys fibs;
		private readonly List<EntryZone> deadZones = new List<EntryZone>();
		private readonly List<EntryZone> inactiveZones = new List<EntryZone>();
		private readonly List<EntryZone> activeZones = new List<EntryZone>();
		private double currentPrimaryBarOpen;
		private bool pendingPrimaryBarFirstTick;
		private bool isFirstTickAfterPrimaryBar;
		private ATR levelBreakAtr;
		private ATR zoneSizeAtr;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_AutoFibAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "Auto Fib Algo";

				BarPeriod = 5;
				LineDensity = ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution.Default;
				ConfluenceZone = ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth.Strong;
				Threshold = 100;
				LookBackMinute = 300;
				MaxEntriesPerZone = 3;
				ZoneTradeEdge = ARC_AutoFibAlgo_AutoFibAlgoZoneTradeEdge.MidPoint;
				ZoneSizeType = ARC_AutoFibAlgo_AutoFibAlgoZoneSizeType.Ticks;
				ZoneSizeAtrPeriod = 14;
				ZoneSize = 5;
				LevelBreakThresholdType = ARC_AutoFibAlgo_AutoFibAlgoBreakThreshType.Ticks;
				LevelBreakThresholdAtrPeriod = 14;
				LevelBreakThreshold = 1;
				MinPreTradeBarsOutsideZone = 3;
				MinBarsSinceZoneFormation = 0;
				ResetLevelEntryCountOnDeactivate = false;

				ResistanceColor = Brushes.Maroon;
				SupportColor = Brushes.Blue;
				LongTradeLineColor = Brushes.Aqua;
				ShortTradeLineColor = Brushes.Fuchsia;
				LineWidth = 2;
				ZoneOpacity = 25;
			}
			else if (State == State.Configure)
			{
				isFirstTickAfterPrimaryBar = true;
				pendingPrimaryBarFirstTick = false;
				currentPrimaryBarOpen = 0d;

				//var bp = (BarsPeriod)BarsPeriod.Clone();
				//bp.BarsPeriodType = BarsPeriodType.Minute;
				//bp.Value = BarPeriod;
				//var instrument = Instrument ?? Instrument.All.First(i => i.FullName == InstrumentOrInstrumentList);
				//var tradingHoursTuple = TradingHours.GetEthRth(instrument.MasterInstrument);
				//AddDataSeries(instrument.FullName, bp, (int)(To - From).TotalMinutes + LookbackMinutes, tradingHoursTuple.Item1.Name, IsResetOnNewTradingDays[0]);
				AddDataSeries(BarsPeriodType.Minute, BarPeriod);

				deadZones.Clear();
				inactiveZones.Clear();
				activeZones.Clear();
			}
			else if (State == State.DataLoaded)
			{
				fibs = ARC_AutoFibAlgo_ARC_GoldenFibsSys(BarPeriod, LineDensity, ConfluenceZone, Threshold, LookBackMinute);
				if (LevelBreakThresholdType == ARC_AutoFibAlgo_AutoFibAlgoBreakThreshType.ATR)
					levelBreakAtr = ATR(LevelBreakThresholdAtrPeriod);
				if (ZoneSizeType == ARC_AutoFibAlgo_AutoFibAlgoZoneSizeType.ATR)
					zoneSizeAtr = ATR(ZoneSizeAtrPeriod);
			}
		}

		private double GetTradeEdge(EntryZone zone)
		{
			switch (ZoneTradeEdge)
			{
			case ARC_AutoFibAlgo_AutoFibAlgoZoneTradeEdge.FibLevel: return zone.FibLevel;
			case ARC_AutoFibAlgo_AutoFibAlgoZoneTradeEdge.MidPoint: return (zone.FibLevel + GetZoneEdge(zone)) / 2;
			case ARC_AutoFibAlgo_AutoFibAlgoZoneTradeEdge.ZoneEdge: return GetZoneEdge(zone);
			default: throw new ArgumentOutOfRangeException();
			}
		}
		
		private double GetZoneEdge(EntryZone zone)
		{
			return zone.FibLevel - zone.Side * zone[CurrentBars[0]];
		}

		private void ScanEntries()
		{
			if (CurrentBars[0] == 0 || lastSignalBar == CurrentBars[0] + 1)
				return;

			// Prevent session gaps from causing trades
			if ((Time[0] - Time[1]).TotalMinutes >= 30)
				return;

			// Verify no active zones overlap
			if (activeZones.Count > 1)
			{
				var azBounds = activeZones
					.SelectMany(z => new[] { z.FibLevel, GetZoneEdge(z) })
					.ToArray();

				// Verify that no zone border is inside another zones borders
				foreach (var boundTriplet in new [] { new [] { 0, 2, 3 }, new [] { 1, 2, 3 }, new [] { 2, 0, 1 }, new [] { 3, 0, 1 } }) 
					if (azBounds[boundTriplet[0]].ARC_AutoFibAlgo_InRange(azBounds[boundTriplet[1]], azBounds[boundTriplet[2]]))
						return;
			}

			// Find the active zone crossed most closely to the current close
			var tradeZone = activeZones
				.Where(z =>
				{
					var edge = GetTradeEdge(z);
					return Close.ARC_AutoFibAlgo_Crossed(edge) && Close[1].ApproxCompare(edge) == -z.Side;
				})
				.OrderBy(z => Math.Abs(GetTradeEdge(z) - Close[0]))
				.FirstOrDefault();
			if (tradeZone == null)
				return;

			if (tradeZone.Entries >= MaxEntriesPerZone)
				return;

			var dir = -tradeZone.Side;
			if (!TradeAllowed(dir))
				return;

			var zoneStartBar = tradeZone.ActivePeriods
				.Skip(tradeZone.ActivePeriods.Count - 1)
				.Select(p => p.StartBar)
				.Prepend(tradeZone.StartBar)
				.Last();
			if (CurrentBars[0] - zoneStartBar + 1 < MinBarsSinceZoneFormation)
				return;

			// Ensure that we had a primary open outside of the zone after it formed, and that our last open outside the
			// zone happened more recently then our last trade edge touch. To avoid issues with the order of events of
			// the primary bar and the tick that formed it, skip the current bars open if we're on the first tick of that bar
			var rangeEnd = CurrentBars[0] - zoneStartBar;
			var zoneEdge = GetZoneEdge(tradeZone);
			var tradeEdge = GetTradeEdge(tradeZone);
			var inZoneCompSeriesArr = tradeZone.Side == 1 ? Highs : Lows;
			var openedOutsideZone = false;
			for (var i = isFirstTickAfterPrimaryBar ? 1 : -1; i <= Math.Min(CurrentBars[0], rangeEnd); i++)
			{
				// If we've touched the trade more recently then we've opened outside the zone, return
				if (i >= 0 && inZoneCompSeriesArr[0][i].ApproxCompare(tradeEdge) == tradeZone.Side)
					break;

				// If our current open is outside the zone stop looking
				var open = i == -1 ? currentPrimaryBarOpen : Opens[0][i];
				if (open.ARC_AutoFibAlgo_InRange(tradeZone.Side == 1 ? double.MinValue : double.MaxValue, zoneEdge))
					openedOutsideZone = true;
			}

			if (!openedOutsideZone)
				return;
				
			// Ensure a min number of bars occurred on the wrong side of the zone
			for (var i = 0; i <= Math.Min(Math.Min(CurrentBars[0], rangeEnd), MinPreTradeBarsOutsideZone - 1); i++)
				if (inZoneCompSeriesArr[0][i].ApproxCompare(tradeEdge) != -tradeZone.Side)
					return;

			tradeZone.Entries++;
			QueueEntry(dir, 1);
		}
		
		private void UpdateEntryZones()
		{
			if (CurrentBars[0] < 0)
				return;

			var activeLevels = fibs.Confluences
				.Concat(fibs.WeakConfluences)
				.Where(c => c.IsValidDataPoint(0) && c[0].ApproxCompare(0) != 0)
				.Select(c => c[0])
				.ToArray();

			// Loop through our active/inactive zones, looking for flips, discontinuities and breaks
			foreach (var zones in new [] { inactiveZones, activeZones })
			{
				// Remove zones that discontinued
				var removedZones = zones
					.Where(z => !activeLevels.Contains(z.FibLevel))
					.ToArray();
				foreach (var z in removedZones)
				{
					zones.Remove(z);
					z.EndBar = CurrentBars[0];
					if (zones != activeZones)
						continue;

					z.ToggleActiveState(CurrentBars[0]);
					if (ResetLevelEntryCountOnDeactivate)
						z.Entries = 0;
				}
				deadZones.AddRange(removedZones);

				// Handle zones that flipped to the current side
				foreach (var z in zones.ToArray())
				{
					double zoneThreshBasis;
					switch (LevelBreakThresholdType)
					{
					case ARC_AutoFibAlgo_AutoFibAlgoBreakThreshType.Ticks:
						zoneThreshBasis = TickSize;
						break;
					case ARC_AutoFibAlgo_AutoFibAlgoBreakThreshType.ATR: 
						zoneThreshBasis = levelBreakAtr[0];
						break;
					case ARC_AutoFibAlgo_AutoFibAlgoBreakThreshType.ZoneSizeMultiple: 
						zoneThreshBasis = z[CurrentBars[0]];
						break;
					default: 
						throw new ArgumentOutOfRangeException();
					}

					var flipThresh = z.FibLevel + z.Side * zoneThreshBasis * LevelBreakThreshold;
					if (Close[0].ApproxCompare(flipThresh) == -z.Side || Close[1].ApproxCompare(flipThresh) == z.Side)
						continue;

					z.FlipDir(CurrentBars[0]);

					if (!z.IsActive)
						continue;

					z.ToggleActiveState(CurrentBars[0]);
					if (ResetLevelEntryCountOnDeactivate)
						z.Entries = 0;
					activeZones.Remove(z);
					inactiveZones.Add(z);
				}
			}

			if (activeLevels.Length == 0)
				return;

			// For each dir, find the new closest level which isn't the opposite sides active level
			var levelsPerSide = activeLevels
				.GroupBy(l => l.ApproxCompare(Close[0]) == 1 ? 1 : -1)
				.ToDictionary(g => g.Key, g => g
					// Remove levels corresponding to opposite side	active zones
					.Where(l => activeZones.All(z => z.Side != -g.Key || z.FibLevel.ApproxCompare(l) != 0))
					// Append active zones which are on the wrong side, but are still unflipped
					.Concat(activeZones
						.Where(z => z.Side == g.Key)
						.Select(z => z.FibLevel))
					.OrderBy(l => g.Key * (l - Close[0]))
					.ToList());
			for (var side = -1; side <= 1; side += 2)
			{
				List<double> sideLevels;
				if (!levelsPerSide.TryGetValue(side, out sideLevels))
					continue;

				// Handle no values case
				if (sideLevels.Count == 0)
					continue;

				// If we already have an active zone for the level, stop here
				var closestLevel = sideLevels[0];
				if (activeZones.Any(z => z.FibLevel.ApproxCompare(closestLevel) == 0))
					continue;

				// Look for a newly activated zone from the currently inactive ones
				var zone = inactiveZones.FirstOrDefault(z => z.FibLevel.ApproxCompare(closestLevel) == 0 && z.Side == side);

				// Inactive zone corresponding to level found then activate it, otherwise create a new zone
				if (zone != null)
					inactiveZones.Remove(zone);
				else
					zone = new EntryZone { StartBar = CurrentBars[0], FibLevel = closestLevel, InitialSide = side };

				// Ensure there's only one ever one active zone per direction
				foreach (var z in activeZones.Where(z => z != zone && z.Side == side).ToList())
				{
					z.ToggleActiveState(CurrentBars[0]);
					if (ResetLevelEntryCountOnDeactivate)
						z.Entries = 0;
					inactiveZones.Add(z);
					activeZones.Remove(z);
				}

				zone[CurrentBars[0]] = CurrentZoneSize;
				zone.ToggleActiveState(CurrentBars[0]);
				activeZones.Add(zone);
			}

			// For any inactive levels without a corresponding zone, add one
			var nonDeadFibLevels = inactiveZones
				.Concat(activeZones)
				.Select(z => z.FibLevel);
			foreach (var noZoneLevel in activeLevels.Except(nonDeadFibLevels))
			{
				var zone = new EntryZone
				{
					InitialSide = noZoneLevel.ApproxCompare(Close[0]) == 1 ? 1 : -1, 
					StartBar = CurrentBars[0], 
					FibLevel = noZoneLevel
				};
				zone[0] = CurrentZoneSize;
				inactiveZones.Add(zone);
			}
		}

		protected override void OnTickBar()
		{
			if (CurrentBars[0] < 0)
				return;
			
			if (pendingPrimaryBarFirstTick)
			{
				isFirstTickAfterPrimaryBar = true;
				pendingPrimaryBarFirstTick = false;
				currentPrimaryBarOpen = Close[0];
			}

			ScanEntries();
			isFirstTickAfterPrimaryBar = false;
		}

		protected override void OnPrimaryBar()
		{
			foreach (var zone in activeZones) 
				zone[CurrentBar] = CurrentZoneSize;
			pendingPrimaryBarFirstTick = true;
			UpdateEntryZones();
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			var priorAaMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = AntialiasMode.PerPrimitive;
			try
			{
				base.OnRender(chartControl, chartScale);
				var visibleZones = deadZones
					.Concat(inactiveZones)
					.Concat(activeZones)
					.Where(z => z.StartBar <= ChartBars.ToIndex && (z.EndBar ?? int.MaxValue) >= ChartBars.FromIndex)
					.ToArray();

				var tradeLineStrokeStyle = new Stroke(Brushes.Transparent, DashStyleHelper.Dash, LineWidth).StrokeStyle;

				using (var supportBrush = SupportColor.ToDxBrush(RenderTarget))
				using (var resistanceBrush = ResistanceColor.ToDxBrush(RenderTarget))
				using (var longTradeLineBrush = LongTradeLineColor.ToDxBrush(RenderTarget))
				using (var shortTradeLineBrush = ShortTradeLineColor.ToDxBrush(RenderTarget))
				using (var supportFillBrush = SupportColor.ToDxBrush(RenderTarget, ZoneOpacity / 100f))
				using (var resistanceFillBrush = ResistanceColor.ToDxBrush(RenderTarget, ZoneOpacity / 100f))
				{
					foreach (var z in visibleZones)
					{
						var inViewActivePeriods = z.ActivePeriods
							.Where(p => p.StartBar <= ChartBars.ToIndex && (p.EndBar ?? ChartBars.ToIndex + 1) >= ChartBars.FromIndex)
							.OrderByDescending(p => p.EndBar ?? ChartBars.ToIndex + 1)
							.ToArray();
						var fibY = chartScale.GetYByValue(z.FibLevel);
						foreach (var p in inViewActivePeriods)
						{
							var vectors = Enumerable.Range(p.StartBar, (p.EndBar ?? ChartBars.ToIndex + 1) - p.StartBar + 1)
								.Select(i => new Vector2(chartControl.GetXByBarIndex(ChartBars, i), chartScale.GetYByValue(z.FibLevel - p.Side * z[i])))
								.ToList();
							vectors.Insert(0, new Vector2(chartControl.GetXByBarIndex(ChartBars, p.StartBar), fibY));
							vectors.Add(new Vector2(vectors.Last().X, fibY));

							using (var pathGeometry = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory))
							using (var geometrySink = pathGeometry.Open())
							{
								geometrySink.BeginFigure(vectors[0], FigureBegin.Filled);
								geometrySink.AddLines(vectors.ToArray());
								geometrySink.EndFigure(FigureEnd.Open);
								geometrySink.Close();
								RenderTarget.FillGeometry(pathGeometry, p.Side == 1 ? resistanceFillBrush : supportFillBrush);
							}
						}

						// Paint the fib levels themselves (we paint rather then use the indicator as our levels don't flip until a buffer distance is passed))
						for (var i = 0; i <= z.Flips.Count; i++)
						{
							var startBar = i == 0 ? z.StartBar : z.Flips[i - 1];
							var endBar = i == z.Flips.Count ? z.EndBar ?? ChartBars.ToIndex + 1 : z.Flips[i];
							var startX = chartControl.GetXByBarIndex(ChartBars, startBar);
							var endX = chartControl.GetXByBarIndex(ChartBars, endBar);
							RenderTarget.DrawLine(new Vector2(startX, fibY), new Vector2(endX, fibY), (z.InitialSide * (i % 2 == 0 ? 1 : -1)) == 1 ? resistanceBrush : supportBrush, LineWidth);
						}

						// Paint the trade line last so it's topmost
						foreach (var p in inViewActivePeriods)
						{
							var zoneEdgeWeight = ZoneTradeEdge == ARC_AutoFibAlgo_AutoFibAlgoZoneTradeEdge.FibLevel ? 0 : ZoneTradeEdge == ARC_AutoFibAlgo_AutoFibAlgoZoneTradeEdge.MidPoint ? .5 : 1;
							var vectors = Enumerable.Range(p.StartBar, (p.EndBar ?? ChartBars.ToIndex + 1) - p.StartBar + 1)
								.Select(i => new Vector2(chartControl.GetXByBarIndex(ChartBars, i), chartScale.GetYByValue(z.FibLevel - p.Side * z[i] * zoneEdgeWeight)))
								.ToArray();

							using (var pathGeometry = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory))
							using (var geometrySink = pathGeometry.Open())
							{
								geometrySink.BeginFigure(vectors[0], FigureBegin.Filled);
								geometrySink.AddLines(vectors.ToArray());
								geometrySink.EndFigure(FigureEnd.Open);
								geometrySink.Close();
								RenderTarget.DrawGeometry(pathGeometry, p.Side == 1 ? shortTradeLineBrush : longTradeLineBrush, LineWidth, tradeLineStrokeStyle);
							}
						}
					}
				}
			}
			finally
			{
				RenderTarget.AntialiasMode = priorAaMode;
			}
		}

		#region Parameters
		[Range(1, int.MaxValue)]
		[Display(Name = "Bar period for minute bars", GroupName = StrategyParameterGroupName, Description = "Bar period for minute bars which are used to calculate the Fibonacci confluence lines", Order = 0)]
		public int BarPeriod { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Fibonacci swing timeframe", GroupName = StrategyParameterGroupName, Description = "Time frames used to identify Fibonacci swings", Order = 1)]
		public ARC_AutoFibAlgo_ARC_GoldenFibs_FibLineResolution LineDensity { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Grid strength", GroupName = StrategyParameterGroupName, Description = "Width of the grid used for summing up Fibonacci lines", Order = 2)]
		public ARC_AutoFibAlgo_ARC_GoldenFibs_ConfluenceWidth ConfluenceZone { get; set; }

		[NinjaScriptProperty]
		[Range(0.0, double.MaxValue)]
		[Display(Name = "Threshold for confluence lines", GroupName = StrategyParameterGroupName, Description = "The threshold set the minimum statistical weight required for a confluence line. Confluence lines with a weight below the threshold value will not be shown.", Order = 3)]
		public double Threshold { get; set; }
		
		[Range(30, int.MaxValue)]
		[Display(Name = "Total lookback (days)", GroupName = StrategyParameterGroupName, Description = "Lookback period for data used for calculating Fibonacci lines", Order = 4)]
		public int LookBackMinute { get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Max Entries Per Zone", GroupName = StrategyParameterGroupName, Order = 4)]
		public int MaxEntriesPerZone { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Zone Trade Edge", GroupName = StrategyParameterGroupName, Order = 5)]
		public ARC_AutoFibAlgo_AutoFibAlgoZoneTradeEdge ZoneTradeEdge { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Zone Size Type", GroupName = StrategyParameterGroupName, Order = 6)]
		public ARC_AutoFibAlgo_AutoFibAlgoZoneSizeType ZoneSizeType { get; set; }
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[ARC_AutoFibAlgo_HideUnless("ZoneSizeType", ARC_AutoFibAlgo_PropComparisonType.EQ, ARC_AutoFibAlgo_AutoFibAlgoZoneSizeType.ATR)]
		[Display(Name = "ATR Period (Zone Size)", GroupName = StrategyParameterGroupName, Order = 7)]
		public int ZoneSizeAtrPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(1e-2, int.MaxValue)]
		[ARC_AutoFibAlgo_Rename("Zone Size (Tick)", "ZoneSizeType", ARC_AutoFibAlgo_PropComparisonType.EQ, ARC_AutoFibAlgo_AutoFibAlgoZoneSizeType.Ticks)]
		[ARC_AutoFibAlgo_Rename("Zone Size (ATRs)", "ZoneSizeType", ARC_AutoFibAlgo_PropComparisonType.EQ, ARC_AutoFibAlgo_AutoFibAlgoZoneSizeType.ATR)]
		[Display(Name = "Zone Size", GroupName = StrategyParameterGroupName, Order = 8)]
		public double ZoneSize { get; set; }
		
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Level Break Thresh Type", GroupName = StrategyParameterGroupName, Order = 9)]
		public ARC_AutoFibAlgo_AutoFibAlgoBreakThreshType LevelBreakThresholdType { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[ARC_AutoFibAlgo_HideUnless("LevelBreakThresholdType", ARC_AutoFibAlgo_PropComparisonType.EQ, ARC_AutoFibAlgo_AutoFibAlgoBreakThreshType.ATR)]
		[Display(Name = "ATR Period (Level Break Thresh)", GroupName = StrategyParameterGroupName, Order = 10)]
		public int LevelBreakThresholdAtrPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(1e-2, int.MaxValue)]
		[ARC_AutoFibAlgo_Rename("Level Break Thresh (Tick)", "LevelBreakThresholdType", ARC_AutoFibAlgo_PropComparisonType.EQ, ARC_AutoFibAlgo_AutoFibAlgoBreakThreshType.Ticks)]
		[ARC_AutoFibAlgo_Rename("Level Break Thresh (ATRs)", "LevelBreakThresholdType", ARC_AutoFibAlgo_PropComparisonType.EQ, ARC_AutoFibAlgo_AutoFibAlgoBreakThreshType.ATR)]
		[ARC_AutoFibAlgo_Rename("Level Break Thresh (Zone Size Multiple)", "LevelBreakThresholdType", ARC_AutoFibAlgo_PropComparisonType.EQ, ARC_AutoFibAlgo_AutoFibAlgoBreakThreshType.ZoneSizeMultiple)]
		[Display(Name = "Level Break Threshold", GroupName = StrategyParameterGroupName, Order = 11)]
		public double LevelBreakThreshold { get; set; }
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "Min Bars Outside Entry Level Before Trade", GroupName = StrategyParameterGroupName, Order = 12)]
		public int MinPreTradeBarsOutsideZone { get; set; }
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "Min Bars Since Zone Formation", GroupName = StrategyParameterGroupName, Order = 13)]
		public int MinBarsSinceZoneFormation { get; set; }

		[Display(Name = "Reset Entry Count On Zone Shift", Order = 14, GroupName = StrategyParameterGroupName)]
		public bool ResetLevelEntryCountOnDeactivate { get; set; }
		#endregion

		#region Plots
		[XmlIgnore]
		[Display(Name = "Resistance Color", GroupName = "Plots", Order = 0)]
		public Brush ResistanceColor { get; set; }

		[Browsable(false)]
		public string ResistanceColorSerialize
		{
			get { return Serialize.BrushToString(ResistanceColor); }
			set { ResistanceColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Support Color", GroupName = "Plots", Order = 1)]
		public Brush SupportColor { get; set; }

		[Browsable(false)]
		public string SupportColorSerialize
		{
			get { return Serialize.BrushToString(SupportColor); }
			set { SupportColor = Serialize.StringToBrush(value); }
		}

		[Range(1, int.MaxValue)]
		[Display(Name = "Line width", GroupName = "Plots", Order = 2)]
		public int LineWidth { get; set; }
		
		[Range(0, 100)]
		[Display(Name = "Zone Opacity", GroupName = "Plots", Order = 3)]
		public int ZoneOpacity { get; set; }

		[XmlIgnore]
		[Display(Name = "Long Trade Line Color", GroupName = "Plots", Order = 4)]
		public Brush LongTradeLineColor { get; set; }

		[Browsable(false)]
		public string LongTradeLineColorSerialize
		{
			get { return Serialize.BrushToString(LongTradeLineColor); }
			set { LongTradeLineColor = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(Name = "Short Trade Line Color", GroupName = "Plots", Order = 5)]
		public Brush ShortTradeLineColor { get; set; }

		[Browsable(false)]
		public string ShortTradeLineColorSerialize
		{
			get { return Serialize.BrushToString(ShortTradeLineColor); }
			set { ShortTradeLineColor = Serialize.StringToBrush(value); }
		}
		#endregion
	}

	public enum ARC_AutoFibAlgo_AutoFibAlgoZoneSizeType { Ticks, ATR }

	public enum ARC_AutoFibAlgo_AutoFibAlgoBreakThreshType { Ticks, ATR, ZoneSizeMultiple }

	public enum ARC_AutoFibAlgo_AutoFibAlgoZoneTradeEdge
	{
		FibLevel,
		MidPoint,
		ZoneEdge
	}
}