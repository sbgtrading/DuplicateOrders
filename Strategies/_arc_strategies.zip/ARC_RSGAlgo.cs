﻿using System.ComponentModel.DataAnnotations;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using System.ComponentModel;
using System;
using System.Windows.Media;
using System.Linq;
using NinjaTrader.Gui;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_RSGAlgo : ARC_RSGAlgo_ARCStrategyBase
	{
		public override string ProductVersion => "v1.0.3 (5/23/2024)";
		public override string ProductInfusionSoftTag => "37695";
		public override bool HasStrategyBasedStops => true;
		protected override bool AllowIntrabarEntries => EntryType == ARC_RSGAlgo_TwoBicEntryType.Intrabar;

		private EMA ema;
		private ATR maxRangeAtr;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_RSGAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "RSG Algo";

				EmaPeriod = 20;
				EntryType = ARC_RSGAlgo_TwoBicEntryType.Intrabar;
				EntryOffset = 0;
				AllowCandle2Doji = true;
				Bar2LLHH = true;
				AllowEqualClose = true;
				RequireEma = true;
				BarCloseType = ARC_RSGAlgo_TwoBicBar2CloseType.InBody;
				MaxAllowablePatternRangeType = ARC_RSGAlgo_AtrOrTicks.ATR;
				StopAtrPeriod = 14;
				MaxAllowablePatternRange = 100;
				AllowOutsideBar2 = true;

				StopLossOffsetType = ARC_RSGAlgo_TwoBicStopOffsetType.Ticks;
				StopLossOffset = 1;
				EmaStroke = new Stroke(Brushes.AliceBlue, 3);
			}
			else if (State == State.DataLoaded)
			{
				AddChartIndicator(ema = EMA(EmaPeriod));
				ema.Plots[0].DashStyleHelper = EmaStroke.DashStyleHelper;
				ema.Plots[0].Brush = EmaStroke.Brush;
				ema.Plots[0].Width = EmaStroke.Width;	

				maxRangeAtr = ATR(StopAtrPeriod);
			}
		}

		private void ScanEntries()
		{
			if (CurrentBars.Any(cb => cb <= 1))
				return;

			var dir = Closes[0][0].ApproxCompare(Opens[0][0]);
			if (!AllowCandle2Doji && dir == 0)
				return;

			if (dir == 0)
				dir = Closes[0][0].ApproxCompare((Highs[0][0] + Lows[0][0]) / 2);

			if (dir == 0)
				return;

			if (Closes[0][1].ApproxCompare(Opens[0][1]) != -dir)
				return;

			var oppExtremeSeries = (dir == 1 ? Lows : Highs)[0];
			if (Bar2LLHH && oppExtremeSeries[0].ApproxCompare(oppExtremeSeries[1]) != -dir)
				return;

			var extremeSeries = (dir == 1 ? Highs : Lows)[0];
			if (!AllowOutsideBar2 && extremeSeries[0].ApproxCompare(extremeSeries[1]) == dir && oppExtremeSeries[0].ApproxCompare(oppExtremeSeries[1]) == -dir)
				return;

			if (RequireEma && Closes[0][0].ApproxCompare(ema[0]) != dir)
				return;

			var inRange = BarCloseType == ARC_RSGAlgo_TwoBicBar2CloseType.InRange 
				? Closes[0][0].ARC_RSGAlgo_InRange(Lows[0][1], Highs[0][1], AllowEqualClose)
				: Closes[0][0].ARC_RSGAlgo_InRange(Math.Min(Opens[0][1], Closes[0][1]), Math.Max(Opens[0][1], Closes[0][1]), AllowEqualClose);
			if (!inRange)
				return;

			if (EntryType == ARC_RSGAlgo_TwoBicEntryType.Intrabar)
			{
				var entryPrice = (dir == 1 ? Highs : Lows)[0][0] + dir * EntryOffset * TickSize;
				if (!Closes[tickBarsIdx].ARC_RSGAlgo_Crossed(entryPrice))
					return;
			}
			
			var (min, max) = GetRangeMinMax(1);
			if (max - min > MaxAllowablePatternRange * (MaxAllowablePatternRangeType == ARC_RSGAlgo_AtrOrTicks.ATR ? maxRangeAtr[0] : TickSize))
				return;

			var sl = (double?)null;
			if (EnableAlgoDefinedStopLosses)
			{
				sl = (dir == 1 ? min : max) - dir * (StopLossOffsetType == ARC_RSGAlgo_TwoBicStopOffsetType.Ticks ? TickSize : (max - min) / 100) * StopLossOffset;
				if (!TradeAllowedWithStop(dir, Close[0], sl.Value))
					return;
			}

			if (!TradeAllowed(dir))
				return;

			QueueEntry(dir, 1, stopLossPrice: sl);
		}

		protected override void OnTickBar()
		{
			if (EntryType != ARC_RSGAlgo_TwoBicEntryType.Intrabar || lastEntryBar >= CurrentBars[0])
				return;
			
			ScanEntries();
		}

		protected override void OnPrimaryBar()
		{
			if (EntryType == ARC_RSGAlgo_TwoBicEntryType.BarClose)
				ScanEntries();
		}

		#region Parameters
		#region General
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "EMA Period", GroupName = StrategyParameterGroupName, Order = 0)]
		public int EmaPeriod { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Entry Type", GroupName = StrategyParameterGroupName, Order = 1)]
		public ARC_RSGAlgo_TwoBicEntryType EntryType { get; set; }
		
		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[ARC_RSGAlgo_HideUnless(nameof(EntryType), ARC_RSGAlgo_PropComparisonType.EQ, ARC_RSGAlgo_TwoBicEntryType.Intrabar)]
		[Display(Name = "Entry Offset (Ticks)", GroupName = StrategyParameterGroupName, Order = 2)]
		public int EntryOffset { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Allow Candle 2 Doji", GroupName = StrategyParameterGroupName, Order = 3)]
		public bool AllowCandle2Doji { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Require Bar 2 LL/HH", GroupName = StrategyParameterGroupName, Order = 4)]
		public bool Bar2LLHH { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Allow Equal Close", GroupName = StrategyParameterGroupName, Order = 5)]
		public bool AllowEqualClose { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Require EMA", GroupName = StrategyParameterGroupName, Order = 6)]
		public bool RequireEma { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Bar 2 Close Type", GroupName = StrategyParameterGroupName, Order = 7)]
		public ARC_RSGAlgo_TwoBicBar2CloseType BarCloseType { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Max Allowable Pattern Range Type", GroupName = StrategyParameterGroupName, Order = 8)]
		public ARC_RSGAlgo_AtrOrTicks MaxAllowablePatternRangeType { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[ARC_RSGAlgo_HideUnless(nameof(MaxAllowablePatternRangeType), ARC_RSGAlgo_PropComparisonType.EQ, ARC_RSGAlgo_AtrOrTicks.ATR)]
		[Display(Name = "Max Allowable Pattern Range ATR Period", GroupName = StrategyParameterGroupName, Order = 9)]
		public int StopAtrPeriod { get; set; }

		[NinjaScriptProperty, Range(0.001, double.MaxValue)]
		[ARC_RSGAlgo_Rename("Max Allowable Pattern Range (Ticks)", nameof(MaxAllowablePatternRangeType), ARC_RSGAlgo_PropComparisonType.EQ, ARC_RSGAlgo_AtrOrTicks.Ticks)]
		[ARC_RSGAlgo_Rename("Max Allowable Pattern Range (ATRs)", nameof(MaxAllowablePatternRangeType), ARC_RSGAlgo_PropComparisonType.EQ, ARC_RSGAlgo_AtrOrTicks.ATR)]
		[Display(Name = "Max Allowable Pattern Range", GroupName = StrategyParameterGroupName, Order = 10)]
		public double MaxAllowablePatternRange { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Allow Outside Bar 2", GroupName = StrategyParameterGroupName, Order = 11)]
		public bool AllowOutsideBar2 { get; set; }
		#endregion

		#region Stop Loss
		[NinjaScriptProperty]
		[ARC_RSGAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_RSGAlgo_PropComparisonType.EQ, ARC_RSGAlgo_BoolEnum.True)]
		[Display(Name = "Stop Loss Type", GroupName = StopLossGroupName, Order = 1)]
		public ARC_RSGAlgo_TwoBicStopOffsetType StopLossOffsetType { get; set; }

		[NinjaScriptProperty, Range(double.MinValue, double.MaxValue)]
		[ARC_RSGAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_RSGAlgo_PropComparisonType.EQ, ARC_RSGAlgo_BoolEnum.True)]
		[ARC_RSGAlgo_Rename("Stop Loss Offset (Ticks)", nameof(StopLossOffsetType), ARC_RSGAlgo_PropComparisonType.EQ, ARC_RSGAlgo_TwoBicStopOffsetType.Ticks)]
		[ARC_RSGAlgo_Rename("Stop Loss Offset (% of HL Range)", nameof(StopLossOffsetType), ARC_RSGAlgo_PropComparisonType.EQ, ARC_RSGAlgo_TwoBicStopOffsetType.PercentOfPatternHLRange)]
		[Display(Name = "Stop Loss Offset", GroupName = StopLossGroupName, Order = 2)]
		public double StopLossOffset { get; set; }
		#endregion

		[Display(Name = "EMA Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 0)]
		public Stroke EmaStroke { get; set; }
		#endregion
	}

	public enum	ARC_RSGAlgo_TwoBicStopOffsetType
	{
		Ticks,
		PercentOfPatternHLRange
	}
	
	public enum	ARC_RSGAlgo_TwoBicBar2CloseType
	{
		InRange,
		InBody
	}
	
	public enum	ARC_RSGAlgo_TwoBicEntryType
	{
		BarClose,
		Intrabar
	}
}