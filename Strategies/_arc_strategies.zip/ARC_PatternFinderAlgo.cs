using System.ComponentModel;
using NinjaTrader.NinjaScript.Indicators.ARC;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Gui;
using MWPattern = NinjaTrader.NinjaScript.Indicators.ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder.MWPattern;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	[ARC_PatternFinderAlgo_CoLicenses(typeof(ARC_PatternFinderAlgo_ARC_MWPatternFinder))]
	public class ARC_PatternFinderAlgo : ARC_PatternFinderAlgo_ARCStrategyBase
	{
		public override string ProductVersion { get { return "v1.0.7 (7/7/2023)"; } }
		public override string ProductInfusionSoftTag { get { return "24675"; } }
		
		[SuppressMessage("ReSharper", "CollectionNeverUpdated.Local")]
		private readonly ARC_PatternFinderAlgo_DefaultingDictionary<int, ARC_PatternFinderAlgo_DefaultingDictionary<ARC_PatternFinderAlgo_ARC_MWPatternFinder.MWPatternType, bool>> patternEnabled = new ARC_PatternFinderAlgo_DefaultingDictionary<int, ARC_PatternFinderAlgo_DefaultingDictionary<ARC_PatternFinderAlgo_ARC_MWPatternFinder.MWPatternType, bool>>(_ => new ARC_PatternFinderAlgo_DefaultingDictionary<ARC_PatternFinderAlgo_ARC_MWPatternFinder.MWPatternType, bool>(true));
		
		private int lastVmBias;
		private int secondLastVmBiasChange;
		private int lastVmBiasChange;
		private int signalsSinceMomoShift;
		private MWPattern lastTradedPattern;
		private ARC_PatternFinderAlgo_ARC_MWPatternFinder patternFinder;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_PatternFinderAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "Pattern Finder Algo";
				SwingStrength = 3;
				IncludeWicks = true;
				DoubleTopOrBottomTolerance = 0.1;
				MinBarsSinceMomoShift = 0;
				MaxBarsSinceMomoShift = 50;
				MaxSignalsSinceMomoShift = 5;
				MinOpposingVMBarsToSignal = 0;

				ShowZigZags = false;
				NeutralZigZagBrushBrush = Brushes.Black;
				LongPatternBrush = Brushes.Lime;
				ShortPatternBrush = Brushes.Red;
				ZigZagLineThickness = 3;
				VConnectorLineThickness = 2;
			}
			else if (State == State.Configure)
			{
				signalsSinceMomoShift = 0;
				lastVmBias = 0;
				secondLastVmBiasChange = 0;
				lastVmBiasChange = 0;
				lastTradedPattern = null;
			}
			else if (State == State.DataLoaded)
			{
				AddChartIndicator(patternFinder = ARC_PatternFinderAlgo_ARC_MWPatternFinder(SwingStrength, IncludeWicks, DoubleTopOrBottomTolerance));
				patternFinder.ShowZigZags = ShowZigZags;
				patternFinder.NeutralZigZagBrushBrush = NeutralZigZagBrushBrush;
				patternFinder.LongPatternBrush = LongPatternBrush;
				patternFinder.ShortPatternBrush = ShortPatternBrush;
				patternFinder.ZigZagLineThickness = ZigZagLineThickness;
				patternFinder.VConnectorLineThickness = VConnectorLineThickness;
			}
		}

		protected override void OnPrimaryBar()
		{
			var newVmBias = indMomo.Histogram[0].ApproxCompare(0);
			if (newVmBias == 0)
				return;

			if (newVmBias != lastVmBias)
			{
				lastVmBias = newVmBias;
				secondLastVmBiasChange = lastVmBiasChange;
				lastVmBiasChange = CurrentBar;
				signalsSinceMomoShift = 0;
			}

			if (signalsSinceMomoShift >= MaxSignalsSinceMomoShift)
				return;

			var lastPattern = patternFinder.Patterns.LastOrDefault();
			if (lastPattern == null || lastPattern == lastTradedPattern || lastPattern.EndBar != CurrentBar)
				return;

			var dir = lastPattern.Side;
			if (!patternEnabled[dir][lastPattern.Type])
				return;
			
			// Reject the trade if we're below the threshold point (one of the Vs outer points)
			if (Close[0].ApproxCompare((lastPattern.Side == 1 ? High : Low).GetValueAt(lastPattern.ThreshPoint.Bar)) == -lastPattern.Side)
				return;

			if (Close[0].ApproxCompare(Open[0]) != dir)
				return;
			
			if (CurrentBar - lastVmBiasChange < MinBarsSinceMomoShift || CurrentBar - lastVmBiasChange > MaxBarsSinceMomoShift)
				return;

			if (lastVmBiasChange - secondLastVmBiasChange < MinOpposingVMBarsToSignal)
				return;

			if (!TradeAllowed(dir))
				return;

			signalsSinceMomoShift++;
			lastTradedPattern = lastPattern;
			QueueEntry(dir);
		}

		#region Properties
		#region Parameters
		#region Long Setup Toggles Toggles
		[NinjaScriptProperty]
		[Display(Order = 0, Name = "Enable LH Breakout Longs", GroupName = StrategyParameterGroupName)]
		public bool EnableLhLong
		{
			get { return patternEnabled[1][Indicators.ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder.MWPatternType.FirstPointOutermost]; } 
			set { patternEnabled[1][Indicators.ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder.MWPatternType.FirstPointOutermost] = value; } 
		}
		
		[NinjaScriptProperty]
		[Display(Order = 1, Name = "Enable HH Breakout Longs", GroupName = StrategyParameterGroupName)]
		public bool EnableHhLong
		{
			get { return patternEnabled[1][Indicators.ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder.MWPatternType.SecondPointOutermost]; } 
			set { patternEnabled[1][Indicators.ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder.MWPatternType.SecondPointOutermost] = value; } 
		}
		
		[NinjaScriptProperty]
		[Display(Order = 2, Name = "Enable Equal High Breakout Longs", GroupName = StrategyParameterGroupName)]
		public bool EnableEqualLong
		{
			get { return patternEnabled[1][Indicators.ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder.MWPatternType.PointsEven]; } 
			set { patternEnabled[1][Indicators.ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder.MWPatternType.PointsEven] = value; } 
		}
		#endregion

		#region Short Setup Toggles Toggles
		[NinjaScriptProperty]
		[Display(Order = 100, Name = "Enable HL Breakout Shorts", GroupName = StrategyParameterGroupName)]
		public bool EnableLhShort
		{
			get { return patternEnabled[-1][Indicators.ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder.MWPatternType.FirstPointOutermost]; } 
			set { patternEnabled[-1][Indicators.ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder.MWPatternType.FirstPointOutermost] = value; } 
		}
		
		[NinjaScriptProperty]
		[Display(Order = 101, Name = "Enable LL Breakout Shorts", GroupName = StrategyParameterGroupName)]
		public bool EnableHhShort
		{
			get { return patternEnabled[-1][Indicators.ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder.MWPatternType.SecondPointOutermost]; } 
			set { patternEnabled[-1][Indicators.ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder.MWPatternType.SecondPointOutermost] = value; } 
		}
		
		[NinjaScriptProperty]
		[Display(Order = 102, Name = "Enable Equal Low Breakout Shorts", GroupName = StrategyParameterGroupName)]
		public bool EnableEqualShort
		{
			get { return patternEnabled[-1][Indicators.ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder.MWPatternType.PointsEven]; } 
			set { patternEnabled[-1][Indicators.ARC.ARC_PatternFinderAlgo_ARC_MWPatternFinder.MWPatternType.PointsEven] = value; } 
		}
		#endregion

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Order = 200, Name = "Swing Strength", GroupName = StrategyParameterGroupName, Description = "Number of bars used to identify a swing high or low")]
		public int SwingStrength { get; set; }

		[NinjaScriptProperty]
		[Display(Order = 201, Name = "Include Wicks in Pivots", GroupName = StrategyParameterGroupName, Description = "Whether or not to use wicks (vs closes) for pivot points")]
		public bool IncludeWicks { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Order = 202, Name = "Double Tops/Bottoms Sensitivity", GroupName = StrategyParameterGroupName, Description = "Fraction of ATR ignored when detecting double tops or bottoms")]
		public double DoubleTopOrBottomTolerance { get; set; }
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Order = 204, Name = "Min Bars Since VM Histo Shift", GroupName = StrategyParameterGroupName)]
		public int MinBarsSinceMomoShift { get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Order = 205, Name = "Max Bars Since VM Histo Shift", GroupName = StrategyParameterGroupName)]
		public int MaxBarsSinceMomoShift { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Order = 206, Name = "Max Signals Per VM Histo Shift", GroupName = StrategyParameterGroupName)]
		public int MaxSignalsSinceMomoShift { get; set; }

		[NinjaScriptProperty]
		[Range(0, 256)]
		[Display(Name = "Min Opposing VM Histo Bars", Order = 207, GroupName = StrategyParameterGroupName)]
		public int MinOpposingVMBarsToSignal { get; set; }
		#endregion

		#region Visual Parameters
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Show Zig Zags", Order = 0, GroupName = StrategyVisualsParameterGroupName)]
		public bool ShowZigZags { get; set; }
		
		[XmlIgnore]
		[ARC_PatternFinderAlgo_HideUnless("ShowZigZags", ARC_PatternFinderAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Zig Zag Brush", Order = 1, GroupName = StrategyVisualsParameterGroupName)]
		public Brush NeutralZigZagBrushBrush { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string NeutralZigZagBrushBrushSerializable
		{
			get { return Serialize.BrushToString(NeutralZigZagBrushBrush); }
			set { NeutralZigZagBrushBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(Name = "Long Pattern Brush", Order = 2, GroupName = StrategyVisualsParameterGroupName)]
		public Brush LongPatternBrush { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string LongPatternBrushSerializable
		{
			get { return Serialize.BrushToString(LongPatternBrush); }
			set { LongPatternBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(Name = "Short Pattern Color", Order = 3, GroupName = StrategyVisualsParameterGroupName)]
		public Brush ShortPatternBrush { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ShortPatternBrushSerializable
		{
			get { return Serialize.BrushToString(ShortPatternBrush); }
			set { ShortPatternBrush = Serialize.StringToBrush(value); }
		}
		
		[Range(1e-5f, float.MaxValue)]
		[Display(Name = "Zig Zag Line Thickness", Order = 4, GroupName = StrategyVisualsParameterGroupName)]
		public float ZigZagLineThickness { get; set; }
		
		[Range(1e-5f, float.MaxValue)]
		[Display(Name = "Connector Line Thickness", Order = 5, GroupName = StrategyVisualsParameterGroupName)]
		public float VConnectorLineThickness { get; set; }
		#endregion
		#endregion
	}
}