using System;
using NinjaTrader.NinjaScript.Indicators.ARC;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using System.ComponentModel.DataAnnotations;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using SharpDX;
using SharpDX.Direct2D1;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript.DrawingTools;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	[ARC_BOSFibAlgo_HideParameters(Properties = new []{ nameof(DistanceToTargetMultiple) })]
	[ARC_BOSFibAlgo_CoLicenses(typeof(ARC_BOSFibAlgo_ARC_MWPatternFinderZigZag))]
	public class ARC_BOSFibAlgo : ARC_BOSFibAlgo_ARCStrategyBase
	{
		public override string ProductVersion => "v1.0.1 (11/15/2024)";
		public override string ProductInfusionSoftTag => "41069";
		protected override bool AllowIntrabarEntries => true;
		public override bool HasStrategyBasedStops => true;
		public override bool HasStrategyBasedTargets => true;

		private class StructureLine
		{
			public ARC_BOSFibAlgo_ZigZagPoint Anchor { get; set; }
			public int? EndBar { get; set; }
		}

		private class Retracement
		{
			public DateTime LastUpdate
			{
				get => Drawing.EndAnchor.Time;
				set => Drawing.EndAnchor.Time = value;
			}

			public double MaxExcursion
			{
				get => Drawing.EndAnchor.Price;
				set => Drawing.EndAnchor.Price = value;
			}

			public int Length => EndBar - BosLine.EndBar.Value;

			public double BasePrice => Drawing.StartAnchor.Price;
			public int StartBar => Drawing.StartAnchor.DrawnOnBar;
			public int EndBar { get; set; }
			public int Direction { get; set; }
			public FibonacciRetracements Drawing { get; set; }
			public bool Traded { get; set; }
			public StructureLine BosLine { get; set; }

			private readonly ARC_BOSFibAlgo_ARCStrategyBase strategy;
			public Retracement(ARC_BOSFibAlgo_ARCStrategyBase strategy)
			{
				this.strategy = strategy;
			}

			public double GetRetracement(double percent)
			{
				return MaxExcursion * (1 - percent / 100) + BasePrice * (percent / 100);
			}

			public void AddSample(int offset)
			{
				var newMfe = (Direction == 1 ? strategy.High : strategy.Low)[offset];
				if (newMfe.ApproxCompare(MaxExcursion) == Direction)
					MaxExcursion = newMfe;

				if (strategy.Time[offset] > LastUpdate)
					LastUpdate = strategy.Time[offset];

				EndBar = Math.Max(EndBar, strategy.CurrentBars[0] - offset);
				
				if (strategy.Time[offset] >= Drawing.StartAnchor.Time)
					return;

				var newMae = (Direction == 1 ? strategy.Low : strategy.High)[offset];
				if (newMae.ApproxCompare(Drawing.StartAnchor.Price) == -Direction)
					Drawing.StartAnchor.Price = newMae;

				Drawing.StartAnchor.Time = strategy.Time[offset];
			}
		}

		private enum ValueType
		{
			StdDev,
			Value
		}
		
		private SessionIterator sessionIterator;
		private ARC_BOSFibAlgo_ARC_MWPatternFinderZigZag zigZag;
		private readonly List<StructureLine> brokenStructureLines = new List<StructureLine>();
		private readonly List<StructureLine> freshStructureLines = new List<StructureLine>();
		private readonly List<Retracement> freshRetracements = new List<Retracement>();
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_BOSFibAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "BOS Fib Algo";
				SwingStrength = 10;
				IncludeWicks = true;
				MinBarsOutsideBarAndBos = 1;
				MinBosLineLength = 10;
				MaxFibBarsAfterBOSBreak = 1000;
				EntryFibLevel = 38.2;

				StopLossFibLevel = 61.8;

				ProfitTarget1MaxExcursionMultiple = 1;

				ShowUntradedFibs = false;
			}
			else if (State == State.Configure)
			{
				freshStructureLines.Clear();
				brokenStructureLines.Clear();
				freshRetracements.Clear();
			}
			else if (State == State.DataLoaded)
			{
				sessionIterator = new SessionIterator(BarsArray[tickBarsIdx]);
				AddChartIndicator(zigZag = ARC_BOSFibAlgo_ARC_MWPatternFinderZigZag(SwingStrength, IncludeWicks));
				zigZag.ZigZagStroke = ZigZagStroke;
			}
		}

		private void UpdateStructureLines()
		{
			zigZag.Update();
			var barDir = Close[0].ApproxCompare(Open[0]);

			// Look for BOS breaks
			if (barDir != 0)
			{
				foreach (var structureLine in freshStructureLines.Where(l => l.Anchor.Side == barDir).ToList())
				{
					if (Close[0].ApproxCompare(structureLine.Anchor.Price) != barDir) 
						continue;

					structureLine.EndBar = CurrentBar;
					freshStructureLines.Remove(structureLine);

					brokenStructureLines.Add(structureLine);
				}
			}

			// Do nothing if no points
			if (zigZag.SwingPoints.Count == 0)
				return;

			for (var i = Math.Max(0, zigZag.SwingPoints.Count - 2); i < zigZag.SwingPoints.Count; i++)
			{
				// Skip the second last point if it isn't on the same bar as the last
				if (i == zigZag.SwingPoints.Count - 2 && zigZag.SwingPoints.Skip(zigZag.SwingPoints.Count - 2).Select(s => s.Bar).Distinct().Count() == 2)
					continue;

				// Kill fresh lines who haven't broken while a new anchor formed on their side
				if (i >= 3)
					freshStructureLines.RemoveAll(l => l.Anchor == zigZag.SwingPoints[i - 3]);

				freshStructureLines.Add(new StructureLine { Anchor = zigZag.SwingPoints[i] });
			}
		}

		private void TerminateRetracement(Retracement retracement)
		{
			if (!retracement.Traded && !ShowUntradedFibs)
				RemoveDrawObject(retracement.Drawing.Tag);

			freshRetracements.Remove(retracement);
		}

		private void UpdateFibs()
		{
			if (BarsInProgress == 0)
			{
				// Check if fib is 
				foreach (var retracement in freshRetracements.ToArray())
				{
					// Check if max excursion exceeded
					retracement.AddSample(0);
					
					// Remove if we've completed another zig-zag leg
					if (zigZag.SwingPoints.Last().Side == -retracement.Direction
						|| retracement.Length >= MaxFibBarsAfterBOSBreak 
						|| Time[0] >= sessionIterator.ActualSessionEnd)
					{
						TerminateRetracement(retracement);
					}
				}
			}

			sessionIterator.GetNextSession(Time[0], true);

			// If no BOS this bar, don't reset fib
			var lineOverriddenThisBar = brokenStructureLines.LastOrDefault(l => l.EndBar == CurrentBar);
			if (lineOverriddenThisBar == null)
				return;

			if (lineOverriddenThisBar.EndBar - lineOverriddenThisBar.Anchor.Bar < MinBosLineLength)
				return;

			// Find the fib anchor point
			var fibAnchorSide = -lineOverriddenThisBar.Anchor.Side;
			var anchorPoint = zigZag.SwingPoints
				.OfType<ARC_BOSFibAlgo_ZigZagPoint>()
				.Reverse()
				.TakeWhile(p => p.Bar.ARC_BOSFibAlgo_InRange(lineOverriddenThisBar.Anchor.Bar, CurrentBar))
				.FirstOrDefault(p => p.Side == fibAnchorSide);

			// If no anchor point within our BOS, don't reset fib
			if (anchorPoint == null)
				return;

			// If fib is redundant, do nothing
			if (freshRetracements.Any(c => c.StartBar == anchorPoint.Bar))
				return;

			// Reset fib by back filling StdDev to the anchor point
			var dir = -anchorPoint.Side;
			var p1 = dir == -1 ? CurBarHigh : CurBarLow;
			var p2 = dir == -1 ? CurBarLow : CurBarHigh;
			var newRetracement = new Retracement(this)
			{
				Drawing = Draw.FibonacciRetracements(this, Guid.NewGuid().ToString(), true, Time[0], p1, Time[0], p2),
				Direction = -anchorPoint.Side,
				BosLine = lineOverriddenThisBar
			};

			newRetracement.Drawing.PriceLevelOpacity = 0;
			newRetracement.Drawing.TextLocation = TextLocation.Off;
			newRetracement.Drawing.IsExtendedLinesLeft = false;
			newRetracement.Drawing.IsExtendedLinesRight = false;

			newRetracement.Drawing.PriceLevels = new [] { 0, 25, 50, 75, 100 }
				.Select(l => new PriceLevel
				{ 
					Value = l,
					Stroke = newRetracement.Direction == 1 ? FibGridUpStroke : FibGridDownStroke,
					IsValueVisible = true
				})
				.ToList();

			newRetracement.Drawing.PriceLevels.Add(new PriceLevel
			{
				Value = StopLossFibLevel,
				Stroke = StopLossFibColor
			});

			newRetracement.Drawing.PriceLevels.Add(new PriceLevel
			{
				Value = EntryFibLevel,
				Stroke = EntryFibColor
			});

			freshRetracements
				.Where(r => r.Direction == newRetracement.Direction)
				.ToList()
				.ForEach(TerminateRetracement);
			freshRetracements.Add(newRetracement);
			for (var i = anchorPoint.Bar; i <= CurrentBar; i++)
				newRetracement.AddSample(CurrentBar - i);
		}

		private int firstTickOfCurrentPrimaryBar = -1;
		protected override void OnPrimaryBar()
		{
            firstTickOfCurrentPrimaryBar = CurrentBars[tickBarsIdx] + 1;
			UpdateStructureLines();
			UpdateFibs();
		}

		protected override void OnTickBar()
		{
			//UpdateFibs();
			var touchedRetracements = freshRetracements
				.Where(r =>
				{
					var thresh = r.GetRetracement(EntryFibLevel);
					return Close[0].ApproxCompare(thresh) != Close[1].ApproxCompare(thresh);
				})
				.ToArray();

			if (touchedRetracements.Length == 0)
				return;

			// Start with the direction in which the most CWAPs were touched, and look for a valid trade
			foreach (var group in touchedRetracements.GroupBy(c => c.Direction).OrderByDescending(g => g.Count()))
			{
				// Find the CWAPs for which this tick triggered a trade
				var validTradeRetracements = new List<Retracement>();
				foreach (var retracement in group.ToList())
				{
					// Ensure the tick came to the trade zone from outside it
					var tradePrice = retracement.GetRetracement(EntryFibLevel);
					if (Close[0].ApproxCompare(tradePrice) == retracement.Direction)
						continue;

					var barsOutsideBarAndBos = 0;
					for (var i = 0; i < CurrentBars[0] - retracement.BosLine.EndBar && barsOutsideBarAndBos < MinBarsOutsideBarAndBos; i++)
					{
						// Ensure the bar is fully on the other side of the BOS
						if ((retracement.Direction == 1 ? Lows : Highs)[0][i].ApproxCompare(retracement.BosLine.Anchor.Price) == retracement.Direction)
							barsOutsideBarAndBos++;
					}

					if (barsOutsideBarAndBos >= MinBarsOutsideBarAndBos)
						validTradeRetracements.Add(retracement);
				}
				
				// Unmark any CWAPs as valid if their BOS lines are beneath the requirement
				validTradeRetracements.RemoveAll(c => c.BosLine.EndBar - c.BosLine.Anchor.Bar < MinBosLineLength + 1);

				if (validTradeRetracements.Count == 0)
					continue;

				var entryRetracement = validTradeRetracements[0];

				var tradeDir = group.Key;
				if (!TradeAllowed(tradeDir))
				{
					TerminateRetracement(entryRetracement);
					continue; 
				}

				// Get and validate the SL
				var dir = entryRetracement.Direction;
				var sl = EnableAlgoDefinedStopLosses ? entryRetracement.GetRetracement(StopLossFibLevel) : (double?)null;
				if (sl != null && !TradeAllowedWithStop(dir, Close[0], sl.Value))
				{
					TerminateRetracement(entryRetracement);
					continue; 
				}

				// Get and validate the TP
				var tp = (double?)null;
				if (EnableAlgoDefinedTargets)
				{
					tp = Close[0] + dir * ProfitTarget1MaxExcursionMultiple * Math.Abs(entryRetracement.MaxExcursion - Close[0]);
					if (!TradeAllowedWithTakeProfit(dir, Close[0], tp.Value))
					{
						TerminateRetracement(entryRetracement);
						continue;
					}
				}

				QueueEntry(entryRetracement.Direction, stopLossPrice: sl, profitTargetPrice: tp);
				entryRetracement.Traded = true;
				TerminateRetracement(entryRetracement);
				return;
			}
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);

			BosUpStroke.RenderTarget = RenderTarget;
			BosDownStroke.RenderTarget = RenderTarget;

			// Draw BOS structure lines
			foreach (var line in brokenStructureLines)
			{
				var y = chartScale.GetYByValue(line.Anchor.Price);
				var pts = new[] { line.Anchor.Bar, line.EndBar ?? (ChartBars.ToIndex + 1) }
					.Select(b => new Vector2(chartControl.GetXByBarIndex(ChartBars, b), y))
					.ToArray();
				var stroke = line.Anchor.Side == 1 ? BosUpStroke : BosDownStroke;
				RenderTarget.DrawLine(pts[0], pts[1], stroke.BrushDX, stroke.Width, stroke.StrokeStyle);
			}
		}

		#region Parameters
		#region Strategy Parameters
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Order = 0, Name = "Swing Strength", GroupName = StrategyParameterGroupName, Description = "Number of bars used to identify a swing high or low")]
		public int SwingStrength { get; set; }

		[NinjaScriptProperty]
		[Display(Order = 1, Name = "Include Wicks in Pivots", GroupName = StrategyParameterGroupName, Description = "Whether or not to use wicks (vs closes) for pivot points")]
		public bool IncludeWicks { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Order = 2, Name = "Min BOS Line Length", GroupName = StrategyParameterGroupName)]
		public int MinBosLineLength { get; set; }
		
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Order = 3, Name = "Max Fib Length After BOS", GroupName = StrategyParameterGroupName)]
		public int MaxFibBarsAfterBOSBreak { get; set; }

		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[Display(Order = 4, Name = "Min Bars Outside BOS", GroupName = StrategyParameterGroupName)]
		public int MinBarsOutsideBarAndBos { get; set; }

		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[Display(Order = 5, Name = "Entry Fib Level", GroupName = StrategyParameterGroupName)]
		public double EntryFibLevel { get; set; }
		
		[NinjaScriptProperty, Range(1e-5, double.MaxValue)]
		[ARC_BOSFibAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_BOSFibAlgo_PropComparisonType.EQ, ARC_BOSFibAlgo_BoolEnum.True)]
		[Display(Order = 1, Name = "Stop Loss Fib Level", GroupName = StopLossGroupName)]
		public double StopLossFibLevel { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_BOSFibAlgo_HideUnless(nameof(EnableAlgoDefinedTargetsEnum), ARC_BOSFibAlgo_PropComparisonType.EQ, ARC_BOSFibAlgo_BoolEnum.True)]
		[Display(Name = "Profit Target 1 (Max Excursion Mult.)", Order = 0, GroupName = TargetsGroupName)]
		public double ProfitTarget1MaxExcursionMultiple { get; set; }
		#endregion

		#region Visual Parameters
		[Display(Name = "BOS Up Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 0)]
		public Stroke BosUpStroke { get; set; } = new Stroke(Brushes.Blue, DashStyleHelper.Dash, 3);
		
		[Display(Name = "BOS Down Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 1)]
		public Stroke BosDownStroke { get; set; } = new Stroke(Brushes.Maroon, DashStyleHelper.Dash, 3);

		[Display(Name = "Zig Zag Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 2)]
		public Stroke ZigZagStroke { get; set; } = new Stroke(Brushes.White, DashStyleHelper.Solid, 2);

		[Display(Name = "Show Untraded Fibs", GroupName = StrategyVisualsParameterGroupName, Order = 3)]
		public bool ShowUntradedFibs { get; set; }

		[Display(Name = "Fib Grid Up Color", GroupName = StrategyVisualsParameterGroupName, Order = 4)]
		public Stroke FibGridUpStroke { get; set; } = new Stroke(Brushes.DarkGreen, DashStyleHelper.Solid, 2);

		[Display(Name = "Fib Grid Down Color", GroupName = StrategyVisualsParameterGroupName, Order = 5)]
		public Stroke FibGridDownStroke { get; set; } = new Stroke(Brushes.Maroon, DashStyleHelper.Solid, 2);

		[Display(Name = "Entry Fib Color", GroupName = StrategyVisualsParameterGroupName, Order = 6)]
		public Stroke EntryFibColor { get; set; } = new Stroke(Brushes.Yellow, DashStyleHelper.Dash, 3);
		
		[Display(Name = "Stop Loss Fib Color", GroupName = StrategyVisualsParameterGroupName, Order = 7)]
		public Stroke StopLossFibColor { get; set; } = new Stroke(Brushes.Red, DashStyleHelper.Dash, 3);
		#endregion
		#endregion
	}
}