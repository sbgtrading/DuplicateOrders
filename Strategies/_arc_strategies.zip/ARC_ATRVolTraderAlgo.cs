using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.Indicators.ARC;
using NinjaTrader.NinjaScript.Strategies.Licensing;

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	[ARC_ATRVolTraderAlgo_CoLicenses(typeof(ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands), typeof(ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop))]
	public class ARC_ATRVolTraderAlgo : ARC_ATRVolTraderAlgo_ARCStrategyBase
	{
		public override string ProductVersion { get { return "v1.0.9 (7/7/2023)"; } }
		public override string ProductInfusionSoftTag { get { return "24402"; } }
		protected override bool AllowIntrabarEntries { get { return EnableRetestSignals; } }
		protected override string ProductName { get { return "ARC_ATRVolAlgo"; } }
		public override string ModuleName { get { return "ARC_ATRVolAlgo"; } }

		private int retestSignalsSinceBreak;
		private ATR bandOffsetAtr;
		private ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop trailStop;
		private ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands bands;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_ATRVolTraderAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
				ButtonText = "ATR Vol";
				EnableBreakSignals = true;
				EnableRetestSignals = true;
				MaxRetestSignalsPerBreak = 3;
				MinPreRetestOutsideBandBars = 1;
				Period = 10;
				Multiplier = 3;
				AtrStopBandPeriod = 14;
				BandMultiplier = 1;
				UptrendBrush = Brushes.Blue;
				DowntrendBrush = Brushes.Maroon;
				BandBrush = Brushes.Blue;
				BandOpacity = 25;
				DotSize = 3;
			}
			else if (State == State.Configure)
			{
				retestSignalsSinceBreak = 0;
				if (!EnableBreakSignals && !EnableRetestSignals && Category != Category.MultiObjective && Category != Category.Optimize && Category != Category.WalkForward)
					throw new Exception("Must enable either Break or Retest signals");
			}
			else if (State == State.DataLoaded)
			{
				bandOffsetAtr = ATR(AtrStopBandPeriod);
				AddChartIndicator(trailStop = ARC_ATRVolTraderAlgo_ARC_ATRTrailingStop(Period, Multiplier, RoundToNearestTick));
				trailStop.Plots[0].Width = DotSize;
				trailStop.UptrendBrush = UptrendBrush;
				trailStop.DowntrendBrush = DowntrendBrush;
				bands = ARC_ATRVolTraderAlgo_ARC_ATRTrailingStopBands(Period, Multiplier, RoundToNearestTick, AtrStopBandPeriod, BandMultiplier);
				bands.BandBrush = BandBrush;
				bands.BandOpacity = BandOpacity;
				AddChartIndicator(bands);
			}
		}

		// Handle retest signals
		protected override void OnTickBar()
		{
			if (!EnableRetestSignals)
				return;

			if (CurrentBar == 0 || CurrentBars[0] < 0)
				return;

			if (retestSignalsSinceBreak >= MaxRetestSignalsPerBreak)
				return;

			if (lastSignalBar >= CurrentBars[0])
				return;

			var dir = trailStop.Bias[0];
			if (dir == 0)
				return;

			// We must be moving towards the band line, and either touch or cross it
			var bandThresh = trailStop[0] + dir * bandOffsetAtr[0] * BandMultiplier;
			var threshComparisons = Enumerable.Range(0, 2)
				.Select(i => Close[i].ApproxCompare(bandThresh))
				.ToArray();
			if (threshComparisons[0].CompareTo(threshComparisons[1]) != -dir)
				return;
			
			// Verify we have sufficient primary bars outside the band prior to our signal
			for (var i = 0; i < MinPreRetestOutsideBandBars; i++)
				if (Highs[0][i].ApproxCompare(bandThresh) != dir || Lows[0][i].ApproxCompare(bandThresh) != dir)
					return;

			if (!TradeAllowed(dir))
				return;

			if (PendingEntryDir != dir)
				retestSignalsSinceBreak++;
			QueueEntry(dir, signalBarOffset: Time[0] > Times[0][0] ? 1 : 0);
		}

		// Handle ATR flip entries
		protected override void OnPrimaryBar()
		{
			trailStop.Update();
			bands.Update();
			if (CurrentBar == 0)
				return;

			if (trailStop.Bias[0] == trailStop.Bias[1])
				return;

			retestSignalsSinceBreak = 0;
			
			if (lastSignalBar >= CurrentBars[0])
				return;

			if (!EnableBreakSignals)
				return;

			var dir = trailStop.Bias[0];
			if (dir == 0)
				return;

			if (!TradeAllowed(dir))
				return;

			QueueEntry(dir);
		}

		#region Properties
		#region Parameters
		[NinjaScriptProperty]
		[Display(Name = "Enable Break Signals", Order = 0, GroupName = StrategyParameterGroupName)]
		public bool EnableBreakSignals { get; set; }
		
		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_ATRVolTraderAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_ATRVolTraderAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Enable Retest Signals", Order = 1, GroupName = StrategyParameterGroupName)]
		public ARC_ATRVolTraderAlgo_BoolEnum EnableRetestSignalsEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool EnableRetestSignals
		{
			get { return EnableRetestSignalsEnum == ARC_ATRVolTraderAlgo_BoolEnum.True; }
			set { EnableRetestSignalsEnum = value ? ARC_ATRVolTraderAlgo_BoolEnum.True : ARC_ATRVolTraderAlgo_BoolEnum.False; }
		}
		
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[ARC_ATRVolTraderAlgo_HideUnless("EnableRetestSignalsEnum", ARC_ATRVolTraderAlgo_PropComparisonType.EQ, ARC_ATRVolTraderAlgo_BoolEnum.True)]
		[Display(Name = "Max Retest Signals Per Break", Order = 2, GroupName = StrategyParameterGroupName)]
		public int MaxRetestSignalsPerBreak { get; set; }
		
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[ARC_ATRVolTraderAlgo_HideUnless("EnableRetestSignalsEnum", ARC_ATRVolTraderAlgo_PropComparisonType.EQ, ARC_ATRVolTraderAlgo_BoolEnum.True)]
		[Display(Name = "Min Pre Retest Bars Outside Bands", Order = 3, GroupName = StrategyParameterGroupName)]
		public int MinPreRetestOutsideBandBars { get; set; }
		
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "ATR Period", Order = 4, GroupName = StrategyParameterGroupName)]
		public int Period { get; set; }

		[NinjaScriptProperty, Range(double.Epsilon, double.MaxValue)]
		[Display(Name = "ATR Multiplier", Order = 5, GroupName = StrategyParameterGroupName)]
		public double Multiplier { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Round to Tick", Order = 6, GroupName = StrategyParameterGroupName, Description = "Round the band levels to the nearest tick?")]
		public bool RoundToNearestTick { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "Band ATR Period", Order = 7, GroupName = StrategyParameterGroupName, Description = "Lookback period for the ATR for band calculation")]
		public int AtrStopBandPeriod { get; set; }

		[NinjaScriptProperty, Range(double.Epsilon, double.MaxValue)]
		[Display(Name = "Band ATR Multiplier", Order = 8, GroupName = StrategyParameterGroupName)]
		public double BandMultiplier { get; set; }
		#endregion

		#region Visual Parameters
		[XmlIgnore]
		[Display(Name = "Downtrend Color", Order = 0, GroupName = StrategyVisualsParameterGroupName)]
		public Brush DowntrendBrush { get; set; }

		[Browsable(false)]
		public string DowntrendBrushSerializable
		{
			get { return Serialize.BrushToString(DowntrendBrush); }
			set { DowntrendBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(Name = "Uptrend Color", Order = 1, GroupName = StrategyVisualsParameterGroupName)]
		public Brush UptrendBrush { get; set; }

		[Browsable(false)]
		public string UptrendBrushSerializable
		{
			get { return Serialize.BrushToString(UptrendBrush); }
			set { UptrendBrush = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Band Color", Order = 2, GroupName = StrategyVisualsParameterGroupName)]
		public Brush BandBrush { get; set; }

		[Browsable(false)]
		public string BandBrushSerializable
		{
			get { return Serialize.BrushToString(BandBrush); }
			set { BandBrush = Serialize.StringToBrush(value); }
		}

		[Range(0, 100)]
		[Display(Name = "Band Opacity", Order = 3, GroupName = StrategyVisualsParameterGroupName)]
		public int BandOpacity { get; set; }
		
		[Range(float.Epsilon, float.MaxValue)]
		[Display(Name = "Dot Size", Order = 4, GroupName = StrategyVisualsParameterGroupName)]
		public float DotSize { get; set; }
		#endregion
		#endregion
	}
}
