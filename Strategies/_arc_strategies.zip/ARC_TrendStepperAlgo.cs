#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.Indicators.ARC;
using NinjaTrader.NinjaScript.Strategies.Licensing;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	[ARC_TrendStepperAlgo_CoLicenses(typeof(ARC_TrendStepperAlgo_ARC_TrendStepper))]
	public class ARC_TrendStepperAlgo : ARC_TrendStepperAlgo_ARCStrategyBase
	{
		public override string ProductVersion { get { return "v1.0.13 (4/21/2023)"; } }
		public override string ProductInfusionSoftTag { get { return "17549"; } }

		private ARC_TrendStepperAlgo_ARC_TrendStepper microTrendStepper;
		private ARC_TrendStepperAlgo_ARC_TrendStepper macroTrendStepper;
		private EMA smoothStepper;
		
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State == State.SetDefaults)
			{
				ButtonText = "Trend Stepper Algo";

				MicroStepSize = 20;
				MacroStepSize = 50;
				SmoothingFactor = 10;
				SignalType = TsSignalType.MICRO_AND_MACRO;
				TrendFilter = TsTrendFilter.CLOSE_MACRO;

				MicroStepColor = Brushes.Gold;
				MacroStepColor = Brushes.MidnightBlue;
				SmoothStepColor = Brushes.SkyBlue;

				ShowMA = false;
			}
			else if (State == State.DataLoaded)
			{
				microTrendStepper = ARC_TrendStepperAlgo_ARC_TrendStepper(MicroStepSize, 0);
				microTrendStepper.Plots[0].PlotStyle = PlotStyle.Square;
				microTrendStepper.Plots[0].Brush = MicroStepColor;
				microTrendStepper.Name = string.Empty;
				AddChartIndicator(microTrendStepper);

				var smoothStepperBasis = ARC_TrendStepperAlgo_ARC_TrendStepper(MicroStepSize, 0);
				smoothStepper = EMA(smoothStepperBasis, SmoothingFactor);
				smoothStepper.Plots[0].Pen = new Pen(SmoothStepColor, 2);
				smoothStepper.Plots[0].Brush = SmoothStepColor;
				smoothStepper.Name = string.Empty;
				AddChartIndicator(smoothStepper);

				macroTrendStepper = ARC_TrendStepperAlgo_ARC_TrendStepper(MacroStepSize, 0);
				macroTrendStepper.Plots[0].PlotStyle = PlotStyle.Square;
				macroTrendStepper.Plots[0].Brush = MacroStepColor;
				macroTrendStepper.Name = string.Empty;
				AddChartIndicator(macroTrendStepper);
			}
		}

		protected override void OnPrimaryBar()
		{
			if (CurrentBars[0] < BarsRequiredToTrade)
				return;

			var dir = Close[0].ApproxCompare(Open[0]);
			if (dir == 0)
				return;

			bool trendFilter;
			switch (TrendFilter)
			{
			case TsTrendFilter.OFF:
				trendFilter = true;
				break;
			case TsTrendFilter.CLOSE_MACRO:
				trendFilter = Close[0].ApproxCompare(macroTrendStepper[0]) == dir;
				break;
			case TsTrendFilter.MICRO_MACRO:
				trendFilter = microTrendStepper[0].ApproxCompare(macroTrendStepper[0]) == dir;
				break;
			default:
				throw new ArgumentOutOfRangeException();
			}

			if (!trendFilter)
				return;

			var validSetup = false;
			if (SignalType == TsSignalType.MICRO_ONLY || SignalType == TsSignalType.MICRO_AND_MACRO)
				validSetup |= microTrendStepper[0].ApproxCompare(smoothStepper[0]) == dir
							  && microTrendStepper[1].ApproxCompare(smoothStepper[1]) != dir;

			if (!validSetup && (SignalType == TsSignalType.MACRO_ONLY || SignalType == TsSignalType.MICRO_AND_MACRO))
				validSetup |= microTrendStepper[0].ApproxCompare(macroTrendStepper[0]) == dir
							  && microTrendStepper[1].ApproxCompare(macroTrendStepper[1]) != dir;

			if (!validSetup)
				return;

			QueueEntry(dir);
		}

		protected override void OnBarUpdate()
		{
			try
			{
				base.OnBarUpdate();
			}
			catch (Exception ex)
			{
				Log(ex.Message, LogLevel.Error);
				Log(ex.StackTrace, LogLevel.Error);
				throw;
			}
		}

		[SuppressMessage("ReSharper", "InconsistentNaming")]
		public enum TsSignalType
		{
			MICRO_ONLY,
			MACRO_ONLY,
			MICRO_AND_MACRO
		}

		[SuppressMessage("ReSharper", "InconsistentNaming")]
		public enum TsTrendFilter
		{
			OFF,
			CLOSE_MACRO,
			MICRO_MACRO
		}

		#region Properties
		#region General
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Micro Step Size", Order = 0, GroupName = StrategyParameterGroupName)]
		public int MicroStepSize { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Macro Step Size", Order = 1, GroupName = StrategyParameterGroupName)]
		public int MacroStepSize { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Smoothing Factor", Order = 2, GroupName = StrategyParameterGroupName)]
		public int SmoothingFactor { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Signal Type", Order = 3, GroupName = StrategyParameterGroupName)]
		public TsSignalType SignalType { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Trend Filter", Order = 4, GroupName = StrategyParameterGroupName)]
		public TsTrendFilter TrendFilter { get; set; }
		#endregion

		#region Visuals
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Micro Step Color", Order = 0, GroupName = StrategyVisualsParameterGroupName)]
		public Brush MicroStepColor { get; set; }

		[Browsable(false)]
		public string MicroStepColorSerializable
		{
			get { return Serialize.BrushToString(MicroStepColor); }
			set { MicroStepColor = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Macro Step Color", Order = 1, GroupName = StrategyVisualsParameterGroupName)]
		public Brush MacroStepColor { get; set; }

		[Browsable(false)]
		public string MacroStepColorSerializable
		{
			get { return Serialize.BrushToString(MacroStepColor); }
			set { MacroStepColor = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Smooth Step Color", Order = 2, GroupName = StrategyVisualsParameterGroupName)]
		public Brush SmoothStepColor { get; set; }

		[Browsable(false)]
		public string SmoothStepColorSerializable
		{
			get { return Serialize.BrushToString(SmoothStepColor); }
			set { SmoothStepColor = Serialize.StringToBrush(value); }
		}
		#endregion
		#endregion

	}
}
