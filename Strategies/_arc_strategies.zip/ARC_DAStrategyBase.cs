#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators.ARC.AlgoSup;
//using NinjaTrader.NinjaScript.Indicators.ARC;
//using ;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_DAStrategyBase : Strategy
	{
		#region Enums
		public enum eStopTargMode
		{
			TICKS,
			PRICE,
			PERCENT,
		}

		public enum eRunType
		{
			BackTest,
			RealTime,
			Combined
		}

		public enum eOrderType
		{
			MARKET,
			LIMITBIDASK,
			LIMITSPREAD,
			LIMITFIXED,
			STOPFIXED,
			STOPLIMIT,
		}

		public enum eHighWaterMarkType
		{
			OFF,
			REALIZED,
			REALIZED_PLUS_UNREALIZED,
		}

		#endregion

		#region Variables
		private int iMaxNumLosingTrades = 0;
		private int iMaxNumWinningTrades = 0;
		private int iMaxNumTotalTrades = 0;

		private bool iShowPnlGraphic = true;
		private bool iShowPnl = true;

		#region xHiddenInputsRegion

		public int xQuantity1 = 0;
		public int xQuantity2 = 0;
		public int xQuantity3 = 0;

		public int xCancelNumBars = 0;

		public eOrderType xOrderType = eOrderType.MARKET;

		public double xOrderStopValue = 0;
		public double xOrderLimitValue = 0;
		public BarsPeriodType xFillPeriodType = BarsPeriodType.Tick;
		public bool xUseHiLoPriceIntrabar = false;
		public bool xDisableOnRejectedOrder = true;
		#endregion

		//*************************************
		//**   STRATEGY PUBLIC VARIABLES     **
		//*************************************		
		public bool bSystemReadyToProcess;
		protected bool IsAllowedToTrade;

		//*************************************
		//**   STRATEGY PRIVATE VARIABLES    **
		//*************************************
		private OrderControl orderControls;

		private PositionSizing positionSize;

		private EquityCurveManager equityCurveManager;
		public const int pBIP   = 0;
		public const int ordBIP = 1;

		private string gExitName = string.Empty;

		protected ARC_DAChartPnl   indPnlChart;
		private ARC_DAPositionInfo indPnL;
		private ARC_DAOrderSingle  indOrder;
		private ARC_DATargStop     indStopTrg;

		private Series<bool> sTime, sTimeBar;
		private Series<int> sBarDirection;

		private double parentStopValue;
		#endregion

		public class OnExecutionUpdateDetails {
			public Execution execution;
			public double price;
			public int quantity;
			public Cbi.MarketPosition marketPosition;
			public string orderId;
			public DateTime time;
			public OnExecutionUpdateDetails(Execution ex, double p, int q, Cbi.MarketPosition mp, string oId, DateTime t){
				execution = ex; price = p; quantity = q; marketPosition = mp; orderId = oId; time = t;
			}
		}
		[XmlIgnore]
		public SortedDictionary<string, OnExecutionUpdateDetails> ExecutionsToUpdate = new SortedDictionary<string, OnExecutionUpdateDetails>();
		//**********************************************************
		// 							Local Class 
		//**********************************************************
		#region RegClasses

		#region RegOrderManagement

		internal class OrderControl
		{
			// Private members			
			private int numOrders;
			private double tickSize;
			private bool bUseSingleStop;

			private eStopTargMode stopMode, targMode;

			public int[] bPendingLogikFill;

			// Public members
			public double lLow;
			public double hHigh;

			public int bOfFill;

			public int bSinceFill;
			//public int bSinceOrder;
			public int bOrder;

			public double[] trgValue;
			public double[] stpValue;
			public double[] stpValueL;
			public double[] stpValueS;

			public Order[] iOrder;
			public Order[] iOrderL;
			public Order[] iOrderS;
			public Order[] iTargOrder;
			public Order[] iStopOrder;

			public double[] orderEntryPrice;
			public double[] orderEntryPriceL;
			public double[] orderEntryPriceS;
			public double[] hPriceSinceEntry;
			public double[] lPriceSinceEntry;
			public string[] bExitOnCancelStop;

			public bool bPendingFill;

			// Break Even Params
			public double[] beTrig, bePlus;

			// Trail Params
			public int[] lastStep;
			public double[] lastPrice;
			public double[] iStepProfTrig, iStepProfFreq, iStepStopLoss;

			public bool bReverseAtPendingStop;

			public OrderControl(
								int iNumOrders,
								double iTickSize
								)
			{
				this.bUseSingleStop = false;
				this.numOrders = iNumOrders;
				this.tickSize = iTickSize;

				this.stopMode = eStopTargMode.TICKS;
				this.targMode = eStopTargMode.TICKS;

				this.iOrder = new Order[this.numOrders];
				this.iOrderL = new Order[this.numOrders];
				this.iOrderS = new Order[this.numOrders];

				this.orderEntryPrice = new double[this.numOrders];
				this.orderEntryPriceL = new double[this.numOrders];
				this.orderEntryPriceS = new double[this.numOrders];

				this.iStopOrder = new Order[this.numOrders];
				this.iTargOrder = new Order[this.numOrders];

				this.trgValue = new double[this.numOrders];
				this.stpValueL = new double[this.numOrders];
				this.stpValueS = new double[this.numOrders];

				this.lastStep = new int[this.numOrders];
				this.lastPrice = new double[this.numOrders];

				this.iStepProfTrig = new double[this.numOrders];
				this.iStepProfFreq = new double[this.numOrders];
				this.iStepStopLoss = new double[this.numOrders];

				this.bPendingLogikFill = new int[this.numOrders];

				this.beTrig = new double[this.numOrders];
				this.bePlus = new double[this.numOrders];

				this.hPriceSinceEntry = new double[this.numOrders];
				this.lPriceSinceEntry = new double[this.numOrders];

				this.bExitOnCancelStop = new string[this.numOrders];
				for (int i = 0; i < this.numOrders; i++)
					this.bExitOnCancelStop[i] = string.Empty;
			}

			public double ComputeStopLossPrice(int index, MarketPosition iMp, double iFillPrice)
			{
				double value = 0;
				if (iMp == MarketPosition.Long)
				{
					if (this.stopMode == eStopTargMode.TICKS)
						value = iFillPrice - this.stpValueL[index] * this.tickSize;
					else if (this.stopMode == eStopTargMode.PERCENT)
						value = iFillPrice - (iFillPrice * (this.stpValueL[index] / 100));
					else if (this.stopMode == eStopTargMode.PRICE)
						value = this.stpValueL[index];
				}
				if (iMp == MarketPosition.Short)
				{
					if (this.stopMode == eStopTargMode.TICKS)
						value = iFillPrice + this.stpValueS[index] * this.tickSize;
					else if (this.stopMode == eStopTargMode.PERCENT)
						value = iFillPrice + (iFillPrice * (this.stpValueS[index] / 100));
					else if (this.stopMode == eStopTargMode.PRICE)
						value = this.stpValueS[index];
				}
				return value;
			}

			public double ComputeTargetPrice(int index, MarketPosition iMp, double iFillPrice)
			{
				double value = 0;
				if (iMp == MarketPosition.Long)
				{
					if (this.targMode == eStopTargMode.TICKS)
						value = iFillPrice + this.trgValue[index] * this.tickSize;
					else if (this.targMode == eStopTargMode.PERCENT)
						value = iFillPrice + (iFillPrice * (this.trgValue[index] / 100));
					else if (this.targMode == eStopTargMode.PRICE)
						value = this.trgValue[index];
				}
				if (iMp == MarketPosition.Short)
				{
					if (this.targMode == eStopTargMode.TICKS)
						value = iFillPrice - this.trgValue[index] * this.tickSize;
					else if (this.targMode == eStopTargMode.PERCENT)
						value = iFillPrice - (iFillPrice * (this.trgValue[index] / 100));
					else if (this.targMode == eStopTargMode.PRICE)
						value = this.trgValue[index];
				}

				return value;
			}

			#region RegGetSet

			public string GetOcoString()
			{
				return string.Empty;
			}

			public void SetPendingLogikFill(int index, int iQuantity)
			{
				this.bPendingLogikFill[index] = iQuantity;
			}
			public int GetPendingLogikFill(int index)
			{
				return this.bPendingLogikFill[index];
			}

			public void ClearPendingLogikFill()
			{
				for (int i = 0; i < this.numOrders; i++)
					this.bPendingLogikFill[i] = 0;
			}

			public bool GetTargActive(int index)
			{
				if (this.trgValue[index] != 0)
					return true;

				return false;
			}

			public double GetTargPrice(int index)
			{
				if (this.iTargOrder[index] != null)
					return this.iTargOrder[index].LimitPrice;

				return -1;
			}

			public bool GetStopActive(int index)
			{
				if (this.stpValueL[index] != 0 || this.stpValueS[index] != 0)
					return true;

				return false;
			}

			public double GetStopLossInTicks(int index, double iEntryPrice)
			{
				if (this.stopMode == eStopTargMode.TICKS)
					return this.stpValueL[index];
				else if (this.stopMode == eStopTargMode.PRICE)
					return (Math.Abs(this.stpValueL[index] - iEntryPrice) / this.tickSize);
				else if (this.stopMode == eStopTargMode.PERCENT)
					return (Math.Abs((iEntryPrice + (iEntryPrice * (this.stpValueL[index] / 100))) - iEntryPrice) / this.tickSize);

				return 0;
			}

			public void SetStopType(eStopTargMode iStopTargMode)
			{
				this.stopMode = iStopTargMode;
			}
			public void SetTargetType(eStopTargMode iStopTargMode)
			{
				this.targMode = iStopTargMode;
			}

			public void SetStopValue(int idx, int direction, double iStopLossValue)
			{
				if (idx == 0)
				{
					for (int i = 1; i < this.numOrders; i++)
					{
						if (direction == 1)
							this.stpValueL[i] = iStopLossValue;
						if (direction == -1)
							this.stpValueS[i] = iStopLossValue;
					}
				}
				else
				{
					if (direction == 1)
						this.stpValueL[idx] = iStopLossValue;
					if (direction == -1)
						this.stpValueS[idx] = iStopLossValue;
				}
			}

			public void SetTargetValue(int idx, double iValue)
			{
				this.trgValue[idx] = iValue;
			}

			public void SetTrailParameters(int idx, double iStepStopLoss, double iStepFrequency, double iStepProfitTrigger)
			{
				this.iStepStopLoss[idx] = iStepStopLoss;
				this.iStepProfFreq[idx] = iStepFrequency;
				this.iStepProfTrig[idx] = iStepProfitTrigger;
			}

			public void SetBreakEvenParameters(int idx, double iBreakEvenTrigger, double iBreakEvenPlus)
			{
				this.bePlus[idx] = iBreakEvenPlus;
				this.beTrig[idx] = iBreakEvenTrigger;
			}

			public bool IsPendingExitOrders()
			{
				for (int j = 0; j < this.numOrders; j++)
				{
					if (this.iStopOrder[j] != null)
						return true;
					if (this.iTargOrder[j] != null)
						return true;
				}

				return false;
			}

			public bool IsPendingEntryOrders(ref string status)
			{
				status = string.Empty;
				for (int i = 1; i < this.numOrders; i++)
				{
					if (this.iOrder[i] != null && iOrder[i].OrderState != OrderState.Filled){
						status = string.Format(i+"{0}: This order existed: ({1}) {2}",i,numOrders,iOrder[i].ToString());
						return true;
					}
					if (this.iOrderL[i] != null && iOrderL[i].OrderState != OrderState.Filled){
						status = string.Format(i+"{0}: This LONGorder existed: ({1}) {2}",i,numOrders,iOrderL[i].ToString());
						return true;
					}
					if (this.iOrderS[i] != null && iOrderS[i].OrderState != OrderState.Filled){
						status = string.Format(i+"{0}: This SHORT order existed: ({1}) {2}",i,numOrders,iOrderS[i].ToString());
						return true;
					}
				}

				return false;
			}
			public bool IsPendingEntryOrders()
			{
				for (int i = 1; i < this.numOrders; i++)
				{
					if (this.iOrder[i] != null && iOrder[i].OrderState != OrderState.Filled){
						return true;
					}
					if (this.iOrderL[i] != null && iOrderL[i].OrderState != OrderState.Filled){
						return true;
					}
					if (this.iOrderS[i] != null && iOrderS[i].OrderState != OrderState.Filled){
						return true;
					}
				}

				return false;
			}

			public int GetNumOrders()
			{
				return this.numOrders;
			}

			public void SetUseSingleStop(bool iUseSingleStop)
			{
				this.bUseSingleStop = iUseSingleStop;
			}

			public bool GetUseSingleStop()
			{
				return this.bUseSingleStop;
			}

			#endregion;

		}

		#endregion

		#region RegMoneyManagement

		internal class PositionSizing
		{

			#region RegVariables

			private int[] iQty;

			// public variables
			public int quantity { get; set; }

			#endregion

			public PositionSizing(int iQuantity1, int iQuantity2, int iQuantity3)
			{
				int num = 0;
				if (iQuantity1 != 0)
					num++;
				if (iQuantity2 != 0)
					num++;
				if (iQuantity3 != 0)
					num++;

				this.iQty = new int[num];
				if (iQuantity1 != 0)
					this.iQty[0] = iQuantity1;
				if (iQuantity2 != 0)
					this.iQty[1] = iQuantity2;
				if (iQuantity3 != 0)
					this.iQty[2] = iQuantity3;
			}

			public void UpdateQuantity(int idx, int iQuantity)
			{
				int i = idx - 1;
				if (i >= this.iQty.Length)
					return;

				this.iQty[i] = iQuantity;
			}

			#region RegHelperMethods

			public int GetNumQuantities()
			{
				return this.iQty.Length;
			}

			public int GetQuantity(int i)
			{
				if (i < this.iQty.Length)
					return this.iQty[i];

				return 0;
			}

			#endregion
		}


		#endregion

		#region RegEquityCurveManager

		internal class EquityCurveManager
		{
			public DateTime dtTradeRef { get; set; }

			private bool maxProfitReached;
			private bool maxLossReached;
			private bool maxTradesReached;

			private bool bCanTrade;
			private bool bExitPosition;
			private bool bExitAtMaxProfit;

			public int numLosingTrades;
			private int numWinningTrades;
			private int numTotalTrades;

			private double maxLossAllowed;
			private double maxGainAllowed;

			private double highWaterMarkPercent;
			private eHighWaterMarkType highWaterMarkType;
			private double maxGain, cutOff;

			private int maxLosingTradesAllowed;
			private int maxWinningTradesAllowed;
			private int maxTotalTradesAllowed;

			private string exitString;

			public EquityCurveManager(
										int iMaxLosingTradesAllowed,
										int iMaxWinningTradesAllowed,
										int iMaxTotalTradesAllowed,
										double iDailyHighWaterMarkPct, eHighWaterMarkType iHighWaterMarkType,
										double iMaxLossAllowed, double iMaxGainAllowed
										)
			{
				this.maxLosingTradesAllowed = iMaxLosingTradesAllowed;
				this.maxWinningTradesAllowed = iMaxWinningTradesAllowed;
				this.maxTotalTradesAllowed = iMaxTotalTradesAllowed;

				this.maxGain = 0;
				this.maxGainAllowed = iMaxGainAllowed;
				this.maxLossAllowed = iMaxLossAllowed;

				this.highWaterMarkType = iHighWaterMarkType;
				this.highWaterMarkPercent = iDailyHighWaterMarkPct;

				this.exitString = string.Empty;

				this.bCanTrade = true;
				this.bExitPosition = false;
				this.bExitAtMaxProfit = true;
			}

			public void ResetValues(DateTime iDtRef)
			{
				this.dtTradeRef = iDtRef;

				this.maxLossReached = false;
				this.maxProfitReached = false;
				this.maxTradesReached = false;

				this.maxGain = 0;
				this.numTotalTrades = 0;
				this.numLosingTrades = 0;
				this.numWinningTrades = 0;

				this.bCanTrade = true;
				this.bExitPosition = false;
			}

			public void UpdatePnl(double iRealizedPnl, double iUnRealizedPnl)
			{
				double pnl = 0;
				if (this.highWaterMarkType == eHighWaterMarkType.REALIZED)
				{
					pnl = iRealizedPnl;
					this.maxGain = Math.Max(this.maxGain, iRealizedPnl);
				}
				else if (this.highWaterMarkType == eHighWaterMarkType.REALIZED_PLUS_UNREALIZED && iRealizedPnl != 0)
				{
					pnl = iRealizedPnl + iUnRealizedPnl;
					this.maxGain = Math.Max(this.maxGain, iRealizedPnl + iUnRealizedPnl);
				}

				if (this.highWaterMarkType != eHighWaterMarkType.OFF)
				{
					this.cutOff = this.maxGain - (this.maxGain * (highWaterMarkPercent / 100));
					if (this.maxGain > 0 && pnl < cutOff)
					{
						this.bCanTrade = false;
						this.maxProfitReached = true;
						this.bExitPosition = true;

						this.exitString = "HWM";
					}
				}

				if (this.maxGainAllowed != 0 && (iRealizedPnl + iUnRealizedPnl) >= this.maxGainAllowed)
				{
					this.bCanTrade = false;
					this.maxProfitReached = true;
					if (this.bExitAtMaxProfit)
						this.bExitPosition = true;

					this.exitString = "DailyMaxGoal";
				}

				if (this.maxLossAllowed != 0 && (iRealizedPnl + iUnRealizedPnl) <= -this.maxLossAllowed)
				{
					this.bCanTrade = false;
					this.bExitPosition = this.maxLossReached = true;
					this.exitString = "DailyMaxLoss";
				}
			}

			public void UpdateLosingTradeNumber()
			{
				this.numLosingTrades++;
				if (this.numLosingTrades >= this.maxLosingTradesAllowed && this.maxLosingTradesAllowed != 0)
				{
					this.bCanTrade = false;
					this.bExitPosition = true;
					this.maxTradesReached = true;
					this.exitString = "DailyMaxLosingTrades";
				}
			}

			public void UpdateWinningTradeNumber()
			{
				this.numWinningTrades++;
				if (this.numWinningTrades >= this.maxWinningTradesAllowed && this.maxWinningTradesAllowed != 0)
				{
					this.bCanTrade = false;
					this.bExitPosition = true;
					this.maxTradesReached = true;
					this.exitString = "DailyMaxWinningTrades";
				}
			}

			public void UpdateTotalTradeNumber()
			{
				this.numTotalTrades++;
				if (this.numTotalTrades >= this.maxTotalTradesAllowed && this.maxTotalTradesAllowed != 0)
				{
					this.bCanTrade = false;
					this.bExitPosition = true;
					this.maxTradesReached = true;
					this.exitString = "DailyMaxTrades";
				}
			}

			public bool GetCanTrade()
			{
				return this.bCanTrade;
			}

			public bool GetExitPosition(ref string rExitReason)
			{
				//				if(this.maxProfitReached || this.maxLossReached || this.maxTradesReached)
				//					this.bCanTrade = false;

				rExitReason = this.exitString;
				return this.bExitPosition;
			}

			public void SetExitAtMaxProfitReached(bool iValue)
			{
				this.bExitAtMaxProfit = iValue;
			}
		}

		#endregion

		#endregion

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"ARC Strategy Framework";
				Name										= "ARC_DAStrategyBase";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 3;
				EntryHandling								= EntryHandling.UniqueEntries;
				RealtimeErrorHandling = RealtimeErrorHandling.StopCancelCloseIgnoreRejects;
				IsExitOnSessionCloseStrategy				= false;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= true;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= true;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				XRunType					= eRunType.BackTest;
				StartTime					= 600;
				EndTime						= 1600;
				ExitAtEndTime				= false;
				ExitOnMaxProfitReached		= false;
				RestartPnlOnSession			= false;
				DayMaxGain					= 0;
				DayMaxLoss					= 0;
				HighWaterMarkType			= eHighWaterMarkType.OFF;
				DailyHighWaterMarkPct		= 0;
				IgnoreTradeTime				= true;
				StopDotColor = Brushes.Red;
				TargetDotColor = Brushes.Lime;

			}
			else if (State == State.Configure)
			{
				sTime = new Series<bool>(this);
				sTimeBar = new Series<bool>(this);
				sBarDirection = new Series<int>(this);

				indStopTrg = ARC_DATargStop();
				for (int i = 0; i < this.indStopTrg.Plots.Length; i++)
				{
					this.indStopTrg.Plots[i].Width = 2;
					this.indStopTrg.Plots[i].PlotStyle = PlotStyle.Dot;
				}
				indStopTrg.Plots[0].Brush = StopDotColor;
				indStopTrg.Plots[1].Brush = StopDotColor;
				indStopTrg.Plots[2].Brush = StopDotColor;
				indStopTrg.Plots[3].Brush = StopDotColor;
				indStopTrg.Plots[4].Brush = TargetDotColor;
				indStopTrg.Plots[5].Brush = TargetDotColor;
				indStopTrg.Plots[6].Brush = TargetDotColor;
				indStopTrg.Plots[7].Brush = TargetDotColor;
				this.indStopTrg.Name = string.Empty;
				AddChartIndicator(indStopTrg);

				this.indOrder = ARC_DAOrderSingle();
				this.indOrder.Plots[0].Brush = Brushes.Cyan;
				this.indOrder.Plots[1].Brush = Brushes.Magenta;
				this.indOrder.Name = string.Empty;
				AddChartIndicator(this.indOrder);

				this.indPnlChart = ARC_DAChartPnl(2);
				this.indPnlChart.Name = string.Empty;

				if (this.iShowPnlGraphic)
					AddChartIndicator(this.indPnlChart);

				this.bSystemReadyToProcess = false;

				AddDataSeries(this.xFillPeriodType, 1);   // BIP = 1										

				this.bSystemReadyToProcess = false;

			}
			else if (State == State.DataLoaded)
            {

				this.orderControls = new OrderControl(6, TickSize);
				this.positionSize = new PositionSizing(this.xQuantity1, this.xQuantity2, this.xQuantity3);

				this.equityCurveManager = new EquityCurveManager(
																	this.iMaxNumLosingTrades, this.iMaxNumWinningTrades, this.iMaxNumTotalTrades,
																	this.DailyHighWaterMarkPct, this.HighWaterMarkType,
																	this.DayMaxLoss, this.DayMaxGain);

				this.equityCurveManager.SetExitAtMaxProfitReached(this.ExitOnMaxProfitReached);
			}
			else if (State == State.Historical)
			{
				if (this.XRunType == eRunType.RealTime)
				{
					IsAllowedToTrade = false;
				}
				else
				{
					IsAllowedToTrade = true;
				}
			}
			else if (State == State.Realtime)
			{
				if (this.XRunType == eRunType.BackTest)
				{
					IsAllowedToTrade = false;
				}
				else
				{
					IsAllowedToTrade = true;
				}
				ExecutionsToUpdate.Clear();
				if (this.orderControls.GetNumOrders() > 0)
				{
					for (int i = 0; i < this.orderControls.GetNumOrders(); i++)
					{
						if (orderControls.iOrder[i] != null)
						{
							orderControls.iOrder[i] = GetRealtimeOrder(orderControls.iOrder[i]);
						}
						if (orderControls.iOrderL[i] != null)
						{
							orderControls.iOrderL[i] = GetRealtimeOrder(orderControls.iOrderL[i]);
						}
						if (orderControls.iOrderS[i] != null)
						{
							orderControls.iOrderS[i] = GetRealtimeOrder(orderControls.iOrderS[i]);
						}
						if (orderControls.iStopOrder[i] != null)
						{
							orderControls.iStopOrder[i] = GetRealtimeOrder(orderControls.iStopOrder[i]);
						}
						if (orderControls.iTargOrder[i] != null)
						{
							orderControls.iTargOrder[i] = GetRealtimeOrder(orderControls.iTargOrder[i]);
						}
					}

				}

				this.equityCurveManager.ResetValues(Time[0]);
			}
		}

		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, 
			Cbi.MarketPosition marketPosition, string orderId, DateTime time)
		{
			//Log("Strategy Base OnExecutionUpdate, Order: " + execution.Order.Name + ", Execution: " + execution.ToString(), LogLevel.Information);
			//Print("Strategy Base OnExecutionUpdate, Order: " + execution.Order.Name + ", Execution: " + execution.ToString());
			bool AreStopsSubmitted = false;
			bool AreTargetsSubmitted = false;
			if(!ExecutionsToUpdate.ContainsKey(executionId)) ExecutionsToUpdate[executionId] = new OnExecutionUpdateDetails(execution, price, quantity, marketPosition, orderId, time);

			string orderPrint = "";
			for (int i = 0; i < this.orderControls.GetNumOrders(); i++)
			{
				// ENTRY / EXIT ORDER
				if (orderControls.iOrder[i] != null)
				{
					orderPrint += "      " + i + ", " + orderControls.iOrder[i].Id;
					if (orderControls.iOrder[i] == execution.Order)
					{
						if (execution.Order.OrderState == OrderState.Filled || execution.Order.OrderState == OrderState.PartFilled)
						{

							// Exit Order
							if (i == 0)
							{
								//Log("Order Execution i == 0", LogLevel.Information);
								//Print("Order Execution i == 0, " + Time[0].ToString());
								for (int j = 0; j < this.orderControls.GetNumOrders(); j++)
									orderControls.orderEntryPrice[j] = 0;

								if (execution.Order.OrderState == OrderState.Filled)
								{
									orderControls.iOrder[0] = null;

									double fPrice = Closes[0][0];
									if (this.LogikGetCanTrade())
									{
										//Print(execution.Order.Name + ", " + this.parentStopValue);
										if (execution.Order.Name == "revShort")
										{
											// Force Stop loss value from parent class.  This is used when the stop loss is a price value dictated by an 
											// indicator from the parent class
											if (this.parentStopValue != 0)
												this.LogikSetStopLossValue(this.parentStopValue);

											for (int j = 0; j < this.positionSize.GetNumQuantities(); j++)
												this.LogikSubmitOrder(j + 1, "S" + (j + 1).ToString(), fPrice, this.positionSize.GetQuantity(j), this.xOrderType);
										}

										if (execution.Order.Name == "revLong")
										{
											// Force Stop loss value from parent class.  This is used when the stop loss is a price value dictated by an 
											// indicator from the parent class
											if (this.parentStopValue != 0)
												this.LogikSetStopLossValue(this.parentStopValue);

											for (int j = 0; j < this.positionSize.GetNumQuantities(); j++)
												this.LogikSubmitOrder(j + 1, "L" + (j + 1).ToString(), fPrice, this.positionSize.GetQuantity(j), this.xOrderType);
										}
									}
								}
							}
							// Entry Order
							else
							{
								//Log("Order Execution i == " + i, LogLevel.Information);
								//Print("Order Execution i > 0, Targets: " + AreTargetsSubmitted + ", Stops: " + AreStopsSubmitted);
								orderControls.hHigh = orderControls.lLow = execution.Order.AverageFillPrice;

								orderControls.lastStep[i] = -1;
								orderControls.lastPrice[i] = execution.Order.AverageFillPrice;

								this.orderControls.orderEntryPrice[i] = execution.Order.AverageFillPrice;
								this.orderControls.hPriceSinceEntry[i] = execution.Order.AverageFillPrice;
								this.orderControls.lPriceSinceEntry[i] = execution.Order.AverageFillPrice;

								double trgPrice = 0;
								double stpPrice = 0;
								// Disabled stop / target via 0 setting?
								if(!AreTargetsSubmitted){
									trgPrice = orderControls.ComputeTargetPrice(i, execution.MarketPosition, execution.Order.AverageFillPrice);
									if (!orderControls.GetTargActive(i))
										trgPrice = 0;
								}
								if(!AreStopsSubmitted){
									stpPrice = orderControls.ComputeStopLossPrice(i, execution.MarketPosition, execution.Order.AverageFillPrice);
									if (!orderControls.GetStopActive(i) || (orderControls.GetUseSingleStop() && i != 1))
										stpPrice = 0;
								}
								//Print("Order Execution i > 0, " + Time[0].ToString() + ", targetPrice: " + trgPrice + ", stpPrice: " + stpPrice);
								LogikSubmitTargStop(i, execution.Name, execution.Order.Filled, trgPrice, stpPrice);
								AreStopsSubmitted = true;
								AreTargetsSubmitted = true;
								if(ExecutionsToUpdate.ContainsKey(executionId)) ExecutionsToUpdate.Remove(executionId);
							}

							if (execution.Order.OrderState == OrderState.Filled)
							{
								orderControls.iOrder[i] = null;
							}
						}
					}
				}
				else
                {
					orderPrint += "      " + i + ", null";
				}
				// Target Order
				if (orderControls.iTargOrder[i] != null)
				{
					if (orderControls.iTargOrder[i] == execution.Order)
					{
						if (execution.Order.OrderState == OrderState.Filled || execution.Order.OrderState == OrderState.PartFilled)
						{
							// Clear reversal flag
							this.orderControls.bReverseAtPendingStop = false;

							// Partial fill of target, adjust stop
							if (execution.Order.OrderState == OrderState.PartFilled)
							{
								if (orderControls.iStopOrder[i] != null)
									LogikSubmitTargStop(i, execution.Order.FromEntrySignal, execution.Order.Quantity - execution.Order.Filled, 0, orderControls.iStopOrder[i].StopPrice);
							}
							else
							{
								LogikCancelStop(i);
								orderControls.orderEntryPrice[i] = 0;
								orderControls.iTargOrder[i] = null;
							}
						}
					}
				}
				// Stop Order
				if (orderControls.iStopOrder[i] != null)
				{
					if (orderControls.iStopOrder[i] == execution.Order)
					{
						if (execution.Order.OrderState == OrderState.Filled || execution.Order.OrderState == OrderState.PartFilled)
						{
							// Partial fill of stop, adjust target
							if (execution.Order.OrderState == OrderState.PartFilled)
							{
								if (orderControls.iTargOrder[i] != null)
									LogikSubmitTargStop(i, execution.Order.FromEntrySignal, execution.Order.Quantity - execution.Order.Filled, orderControls.iTargOrder[i].LimitPrice, 0);
							}
							else
							{
								LogikCancelTarget(i);

								if (this.orderControls.bReverseAtPendingStop)
									this.orderControls.iTargOrder[i] = null;

								Order o = orderControls.iStopOrder[i];
								orderControls.iStopOrder[i] = null;
								orderControls.orderEntryPrice[i] = 0;

								// reverse at stop loss being filled
								if (
									this.orderControls.bReverseAtPendingStop
									&& !this.orderControls.IsPendingExitOrders()
									&& !this.orderControls.IsPendingEntryOrders()
									)
								{
									this.orderControls.bReverseAtPendingStop = false;
									this.orderControls.bPendingFill = true;

									if (o.OrderAction == OrderAction.Buy || o.OrderAction == OrderAction.BuyToCover)
									{
										// Force Stop loss value from parent class.  This is used when the stop loss is a price value dictated by an 
										// indicator from the parent class
										if (this.parentStopValue != 0)
											this.LogikSetStopLossValue(this.parentStopValue);

										for (int j = 0; j < this.positionSize.GetNumQuantities(); j++)
											this.LogikSubmitOrder(j + 1, "L" + (j + 1).ToString(), execution.Order.AverageFillPrice, this.positionSize.GetQuantity(j), eOrderType.MARKET);
									}

									if (o.OrderAction == OrderAction.Sell || o.OrderAction == OrderAction.SellShort)
									{
										// Force Stop loss value from parent class.  This is used when the stop loss is a price value dictated by an 
										// indicator from the parent class
										if (this.parentStopValue != 0)
											this.LogikSetStopLossValue(this.parentStopValue);

										for (int j = 0; j < this.positionSize.GetNumQuantities(); j++)
											this.LogikSubmitOrder(j + 1, "S" + (j + 1).ToString(), execution.Order.AverageFillPrice, this.positionSize.GetQuantity(j), eOrderType.MARKET);
									}
								}
							}
						}
					}
				}
			}
			//Print("OrderPrint: " + orderPrint);
			//Log("OrderPrint: " + orderPrint, LogLevel.Information);
		}

		protected override void OnMarketData(MarketDataEventArgs marketDataUpdate)
		{
			if (marketDataUpdate.MarketDataType != MarketDataType.Last)
				return;

			if (Position.MarketPosition != MarketPosition.Flat)
			{
				this.indPnlChart.OpenPl = Position.GetUnrealizedProfitLoss(PerformanceUnit.Currency, marketDataUpdate.Price);
				this.indPnlChart.Value[0] = this.LogikGetChartPnl(Closes[0][0]);
				this.indPnlChart.PlotBrushes[0][0] = Brushes.Green;
				if (this.indPnlChart.Value[0] < 0)
					this.indPnlChart.PlotBrushes[0][0] = Brushes.Red;

			}

			if (!LogikCheckDayPnl(marketDataUpdate.Price))
				return;

		}

		protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, 
			int quantity, int filled, double averageFillPrice, 
			Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
		{
			if (order.OrderState == OrderState.Rejected)
			{
				this.LogikExitPosition("clearReject");
			}

			if (order.OrderState == OrderState.Cancelled)
			{
				if (order == orderControls.iOrder[0])
					orderControls.iOrder[0] = null;
			}
			// Check for canceled stop loss orders
			for (int i = 1; i < orderControls.GetNumOrders(); i++)
			{
				if (orderControls.iStopOrder[i] != null && orderControls.iStopOrder[i] == order)
				{
					if (order.OrderState == OrderState.Cancelled)
					{
						/*if (orderControls.bExitOnCancelStop[i] != string.Empty && orderControls.iTargOrder[i] == null)
						{
							// Long exit
							if (
								orderControls.iStopOrder[i].OrderAction == OrderAction.Sell
								|| orderControls.iStopOrder[i].OrderAction == OrderAction.SellShort
								)
								ExitLong(1, orderControls.iStopOrder[i].Quantity, orderControls.bExitOnCancelStop[i], orderControls.iStopOrder[i].FromEntrySignal);

							// Short exit
							if (
								orderControls.iStopOrder[i].OrderAction == OrderAction.Buy
								|| orderControls.iStopOrder[i].OrderAction == OrderAction.BuyToCover
								)
								ExitShort(1, orderControls.iStopOrder[i].Quantity, orderControls.bExitOnCancelStop[i], orderControls.iStopOrder[i].FromEntrySignal);

							orderControls.bExitOnCancelStop[i] = string.Empty;
						}*/

						orderControls.iStopOrder[i] = null;

						// No pending orders, exit the position																														
						//if (!this.orderControls.IsPendingExitOrders() && gExitName != string.Empty)
							//this.LogikExitPosition(gExitName);
					}
				}

				if (orderControls.iTargOrder[i] != null && orderControls.iTargOrder[i] == order)
				{
					if (order.OrderState == OrderState.Cancelled)
					{
						/*if (orderControls.bExitOnCancelStop[i] != string.Empty && orderControls.iStopOrder[i] == null)
						{
							// Long exit
							if (
								orderControls.iTargOrder[i].OrderAction == OrderAction.Sell
								|| orderControls.iTargOrder[i].OrderAction == OrderAction.SellShort
								)
								ExitLong(1, orderControls.iTargOrder[i].Quantity, orderControls.bExitOnCancelStop[i], orderControls.iTargOrder[i].FromEntrySignal);

							// Short exit
							if (
								orderControls.iTargOrder[i].OrderAction == OrderAction.Buy
								|| orderControls.iTargOrder[i].OrderAction == OrderAction.BuyToCover
								)
								ExitShort(1, orderControls.iTargOrder[i].Quantity, orderControls.bExitOnCancelStop[i], orderControls.iTargOrder[i].FromEntrySignal);

							orderControls.bExitOnCancelStop[i] = string.Empty;
						}*/

						orderControls.iTargOrder[i] = null;

						// No pending orders, exit the position					
						//if (!this.orderControls.IsPendingExitOrders() && gExitName != string.Empty)
							//this.LogikExitPosition(gExitName);
					}
				}

				if (orderControls.iOrder[i] != null && orderControls.iOrder[i] == order)
				{
					if (order.OrderState == OrderState.Cancelled)
						orderControls.iOrder[i] = null;
				}
				if (orderControls.iOrderL[i] != null && orderControls.iOrderL[i] == order)
				{
					if (order.OrderState == OrderState.Cancelled)
						orderControls.iOrderL[i] = null;
				}
				if (orderControls.iOrderS[i] != null && orderControls.iOrderS[i] == order)
				{
					if (order.OrderState == OrderState.Cancelled)
						orderControls.iOrderS[i] = null;
				}
			}

		}

		protected override void OnPositionUpdate(Cbi.Position position, double averagePrice, 
			int quantity, Cbi.MarketPosition marketPosition)
		{
			if (position.MarketPosition == MarketPosition.Flat)
			{

				this.indPnlChart.OpenPl = 0;

				this.indPnlChart.TodayPl = this.LogikGetRealizedPnl();
				this.indPnlChart.TrackedPl = this.LogikGetTrackedPnl();

				this.indPnlChart.Value[0] = this.LogikGetChartPnl(Closes[0][0]);
				this.indPnlChart.PlotBrushes[0][0] = Brushes.Green;
				if (this.indPnlChart.Value[0] < 0)
					this.indPnlChart.PlotBrushes[0][0] = Brushes.Red;

				return;
			}
			else
			{
//if (IsDebug){
//	Print("1112...just entered base.OnPositionUpdate");
//	Print("Position is now: "+position.MarketPosition.ToString());
//	for (int i = 0; i < this.orderControls.GetNumOrders(); i++){
//		if(orderControls.iOrder[i] == null) Print("   "+i+" order is null");
//		else Print("   "+i+": "+orderControls.iOrder[i].ToString());
//	}
//}
				this.orderControls.bOfFill = CurrentBars[0];
				this.orderControls.bPendingFill = false;
			}

			this.indPnlChart.OpenPl = position.GetUnrealizedProfitLoss(PerformanceUnit.Currency, Closes[0][0]);
			this.indPnlChart.Value[0] = this.LogikGetChartPnl(Closes[0][0]);
			this.indPnlChart.PlotBrushes[0][0] = Brushes.Green;
			if (this.indPnlChart.Value[0] < 0)
				this.indPnlChart.PlotBrushes[0][0] = Brushes.Red;

		}


private bool IsDebug = false;
		protected override void OnBarUpdate()
		{
			if (CurrentBars[0] < 1 || CurrentBars[1] < 5)
				return;

			#region RegSetupDataSeries

			/*if (sTimeBar == null && BarsInProgress == 1)
				sTimeBar = new BoolSeries(SMA(BarsArray[0], 1));

			if (sTime == null && BarsInProgress == 1)
				sTime = new BoolSeries(SMA(BarsArray[ordBIP], 1));

			if (this.sBarDirection == null)
				this.sBarDirection = new DataSeries(SMA(BarsArray[0], 1));*/

			#endregion

			if (sTime == null)
				return;

			this.bSystemReadyToProcess = true;

			#region InitialTimeCheck	

			bool t1Sum = false;
			if (LogikSweetTime(ordBIP, this.StartTime, this.EndTime, 2500) && LogikSweetTime(0, this.StartTime, this.EndTime, 2500))
				t1Sum = true;
			bool t2Sum = false;
			//if (LogikSweetTime(ordBIP, this.iStartTime2, this.iEndTime2, 2500) && LogikSweetTime(0, this.iStartTime2, this.iEndTime2, 2500))
				//t2Sum = true;
			bool t3Sum = false;
			//if (LogikSweetTime(ordBIP, this.iStartTime3, this.iEndTime3, 2500) && LogikSweetTime(0, this.iStartTime3, this.iEndTime3, 2500))
				//t3Sum = true;
			bool t4Sum = false;
			//if (LogikSweetTime(ordBIP, this.iStartTime4, this.iEndTime4, 2500) && LogikSweetTime(0, this.iStartTime4, this.iEndTime4, 2500))
				//t4Sum = true;

			sTime[0] = (t1Sum | t2Sum | t3Sum | t4Sum) || IgnoreTradeTime;


			// End Exit by time
			if (
				(sTime[1] && !sTime[0])
				|| (this.LogikGetTradeWithoutTime() && Time[0].Date != Time[1].Date)
				)
			{
				// Cancel any pending orders
				if (!LogikGetTradeWithoutTime())
				{
					for (int i = 1; i < this.orderControls.GetNumOrders(); i++)
						LogikCancelOrder(i);

					this.LogikSetReverseAtPendingStop(false);
					this.orderControls.ClearPendingLogikFill();
					this.LogikCancelBracketComplete(MarketPosition.Long);
					this.LogikCancelBracketComplete(MarketPosition.Short);
				}
				if (this.ExitAtEndTime)
					this.LogikExitPosition("endTime");


				if (Time[0].Date == Time[1].Date)
                {
                    Draw.VerticalLine(this, CurrentBars[0].ToString() + "d", 0, Brushes.Red, DashStyleHelper.Dash, 2);
                }
            }

			// First time passing bar
			if (
				(sTime[0] && !sTime[1])
				|| (this.LogikGetTradeWithoutTime() && Time[0].Date != Time[1].Date)
				)
			{
				if (Time[0].Date == Time[1].Date)
                {
					Draw.VerticalLine(this, CurrentBars[0].ToString() + "d", 0, Brushes.LimeGreen, DashStyleHelper.Dash, 2);
                }

                if (this.RestartPnlOnSession)
                {
                    this.equityCurveManager.ResetValues(Times[1][0]);
                }
            }

			/*if (BarsInProgress == 0 && this.RestartPnlOnSession && Time[0].Date != Time[1].Date && this.IgnoreTradeTime)
				this.equityCurveManager.ResetValues(Times[1][0]);*/


			#endregion

			for (int i = 1; i < this.orderControls.GetNumOrders(); i++)
			{
				this.orderControls.lPriceSinceEntry[i] = Math.Min(this.orderControls.lPriceSinceEntry[i], Closes[1][0]);
				this.orderControls.hPriceSinceEntry[i] = Math.Max(this.orderControls.hPriceSinceEntry[i], Closes[1][0]);
			}

			// Update H/L based on INTRA bar	
			if (
				this.xUseHiLoPriceIntrabar
				&& this.xFillPeriodType == BarsPeriodType.Minute
				)
			{
				orderControls.lLow = Math.Min(orderControls.lLow, Lows[1][0]);
				orderControls.hHigh = Math.Max(orderControls.hHigh, Highs[1][0]);
			}
			else
			{
				orderControls.lLow = Math.Min(orderControls.lLow, Closes[1][0]);
				orderControls.hHigh = Math.Max(orderControls.hHigh, Closes[1][0]);
			}

			#region RegHistoricalPnlCheck

			double chartPnl = 0;
			if (Historical)
			{
				if (!LogikCheckDayPnl(Closes[1][0]))
				{
					// return;
				}
			}
			#endregion

			#region RegTrailingExits

			// LONG
			if (Position.MarketPosition == MarketPosition.Long)
			{

				//*****************************
				// 	 Setup Trail Step
				//*****************************				 																																										
				int step = 0;
				double freq = 0;
				double stop = 0;
				for (int i = 1; i < this.orderControls.GetNumOrders(); i++)
				{
					if (
						orderControls.iStepProfTrig[i] != 0
						&& orderControls.hHigh >= Position.AveragePrice + orderControls.iStepProfTrig[i] * TickSize
						)
					{
						step = i;
						stop = orderControls.iStepStopLoss[i];
						freq = orderControls.iStepProfFreq[i];
					}
				}

				for (int i = 1; i < this.orderControls.GetNumOrders(); i++)
				{
					//*****************************
					// 			BreakEven
					//*****************************					
					double bePrice = Position.AveragePrice + orderControls.beTrig[i] * TickSize;

					if (
						// BE turned on via input
						orderControls.beTrig[i] != 0
						// price moved for breakeven						
						&& Close[0] >= bePrice
						)
					{
						double nPrice = Instrument.MasterInstrument.RoundToTickSize(Position.AveragePrice + orderControls.bePlus[i] * TickSize);
						if (orderControls.iStopOrder[i] != null)
						{
							if (nPrice > orderControls.iStopOrder[i].StopPrice)
								LogikSubmitTargStop(i, orderControls.iStopOrder[i].FromEntrySignal, orderControls.iStopOrder[i].Quantity, 0, nPrice);
						}
					}

					// Updating Stop
					if (
						stop != 0
						&& freq != 0
						&& orderControls.iStopOrder[i] != null
						)
					{
						double cStopPrice = orderControls.iStopOrder[i].StopPrice;

						// Potential new stop price
						double nPrice = 0;

						// New step.  Simply update stop to new price					
						if (orderControls.lastStep[i] != step)
						{
							// Save the step
							orderControls.lastStep[i] = step;
							// Set the new stop price
							orderControls.lastPrice[i] = orderControls.hHigh;
							nPrice = Instrument.MasterInstrument.RoundToTickSize(orderControls.lastPrice[i] - stop * TickSize);
						}
						else
						{
							// Moving on Freq.
							if (Math.Abs(orderControls.hHigh - orderControls.lastPrice[i]) >= freq * TickSize)
							{
								nPrice = Instrument.MasterInstrument.RoundToTickSize(orderControls.hHigh - stop * TickSize); //cStopPrice+ freq * TickSize;
								orderControls.lastPrice[i] = orderControls.hHigh;
							}
						}

						// Update stop on last price 
						if (nPrice != 0)
						{
							if (nPrice > orderControls.iStopOrder[i].StopPrice)
							{
								orderControls.lastPrice[i] = orderControls.lLow;
								this.LogikSubmitTargStop(i, "L" + i.ToString(), orderControls.iStopOrder[i].Quantity, 0, nPrice);
							}
						}
					}
				}
			}

			// SHORT
			if (Position.MarketPosition == MarketPosition.Short)
			{

				//*****************************
				// 	 Setup Trail Step
				//*****************************				 																																										
				int step = 0;
				double freq = 0;
				double stop = 0;
				for (int i = 1; i < this.orderControls.GetNumOrders(); i++)
				{
					if (
						orderControls.iStepProfTrig[i] != 0
						&& orderControls.lLow <= Position.AveragePrice - orderControls.iStepProfTrig[i] * TickSize
						)
					{
						step = i;
						stop = orderControls.iStepStopLoss[i];
						freq = orderControls.iStepProfFreq[i];
					}
				}

				for (int i = 1; i < this.orderControls.GetNumOrders(); i++)
				{

					//*****************************
					// 			BreakEven
					//*****************************
					double bePrice = Position.AveragePrice - orderControls.beTrig[i] * TickSize;

					if (
						// BE turned on via input
						orderControls.beTrig[i] != 0
						// price moved for breakeven						
						&& Close[0] <= bePrice
						)
					{
						double nPrice = Instrument.MasterInstrument.RoundToTickSize(Position.AveragePrice - orderControls.bePlus[i] * TickSize);
						if (orderControls.iStopOrder[i] != null)
						{
							if (nPrice < orderControls.iStopOrder[i].StopPrice)
								LogikSubmitTargStop(i, orderControls.iStopOrder[i].FromEntrySignal, orderControls.iStopOrder[i].Quantity, 0, nPrice);
						}
					}


					// Updating Stop
					if (
						stop != 0
						&& freq != 0
						&& orderControls.iStopOrder[i] != null
						)
					{
						double cStopPrice = orderControls.iStopOrder[i].StopPrice;

						// Potential new stop price
						double nPrice = 0;

						// New step.  Simply update stop to new price					
						if (orderControls.lastStep[i] != step)
						{
							// Save the step
							orderControls.lastStep[i] = step;
							// Set the new stop price
							orderControls.lastPrice[i] = orderControls.lLow;
							nPrice = Instrument.MasterInstrument.RoundToTickSize(orderControls.lastPrice[i] + stop * TickSize);
						}

						// Moving on Freq.
						if (Math.Abs(orderControls.lLow - orderControls.lastPrice[i]) >= freq * TickSize)
						{
							nPrice = Instrument.MasterInstrument.RoundToTickSize(orderControls.lLow + stop * TickSize); //cStopPrice - freq * TickSize;
							orderControls.lastPrice[i] = orderControls.lLow;
						}

						// Update stop on last price 
						if (nPrice != 0)
						{
							if (nPrice < orderControls.iStopOrder[i].StopPrice)
							{
								orderControls.lastPrice[i] = orderControls.lLow;
								LogikSubmitTargStop(i, "S" + i.ToString(), orderControls.iStopOrder[i].Quantity, 0, nPrice);
							}
						}
					}
				}
			}

			#endregion


			// Don't process anything other than base TF after this point
			if (BarsInProgress != pBIP)
				return;

			this.indPnlChart.Value[0] = this.LogikGetChartPnl(Close[0]);
			this.indPnlChart.PlotBrushes[0][0] = Brushes.Green;
			if (this.indPnlChart.Value[0] < 0)
				this.indPnlChart.PlotBrushes[0][0] = Brushes.Red;

			this.sTimeBar[0] = this.sTime[0];

			this.sBarDirection[0] = sBarDirection[1];
			if (Close[0] > Open[0])
				this.sBarDirection[0] = 1;
			if (Close[0] < Open[0])
				this.sBarDirection[0] = -1;

			//			if(IsFirstTickOfBar)
			//				orderControls.bSinceOrder++;
			//if(IsDebug) Print(BarsInProgress+":   cb: "+CurrentBars[BarsInProgress]+"  bsinceorder: "+orderControls.bSinceOrder);
			//Print(BarsInProgress + ":   cb: " + CurrentBars[BarsInProgress] + "  bsinceorder: " + orderControls.bOrder);
			string status="";
			if (
				this.xOrderType != eOrderType.MARKET
				&& this.xCancelNumBars != 0
				&& this.orderControls.IsPendingEntryOrders(ref status)
				&& orderControls.bOrder < CurrentBars[0] - this.xCancelNumBars
				)
			{
if(IsDebug) Print("Background set to Yellow, pending order: "+status);
				Log("Background set to Yellow, pending order: " + status + "  bsinceorder: " + orderControls.bOrder + "  cb: " + CurrentBars[BarsInProgress], LogLevel.Information);
				BackBrush = Brushes.Yellow;
				LogikCancelPendingEntryOrder();
			}

			#region RegTrgStopPlots

			if (this.orderControls.GetNumOrders() > 1)
			{
				if (orderControls.iStopOrder[1] != null)
					indStopTrg.Values[0][0] = orderControls.iStopOrder[1].StopPrice;
				if (orderControls.iTargOrder[1] != null)
					indStopTrg.Values[4][0] = orderControls.iTargOrder[1].LimitPrice;
			}

			if (this.orderControls.GetNumOrders() > 2)
			{
				if (orderControls.iStopOrder[2] != null)
					indStopTrg.Values[1][0] = orderControls.iStopOrder[2].StopPrice;
				if (orderControls.iTargOrder[2] != null)
					indStopTrg.Values[5][0] = orderControls.iTargOrder[2].LimitPrice;
			}

			if (this.orderControls.GetNumOrders() > 3)
			{
				if (orderControls.iStopOrder[3] != null)
					indStopTrg.Values[2][0] = orderControls.iStopOrder[3].StopPrice;
				if (orderControls.iTargOrder[3] != null)
					indStopTrg.Values[6][0] = orderControls.iTargOrder[3].LimitPrice;
			}

			#endregion

			#region RegEntryPlots

			if (this.orderControls.iOrder[1] != null)
			{
				if (
					this.orderControls.iOrder[1].OrderAction == OrderAction.Buy
					|| this.orderControls.iOrder[1].OrderAction == OrderAction.BuyToCover
					)
				{
					if (this.orderControls.iOrder[1].OrderType == OrderType.Limit)
						this.indOrder.EntryOrderL[1] = this.orderControls.iOrder[1].LimitPrice;
					if (this.orderControls.iOrder[1].OrderType == OrderType.StopMarket || this.orderControls.iOrder[1].OrderType == OrderType.StopLimit)
						this.indOrder.EntryOrderL[1] = this.orderControls.iOrder[1].StopPrice;
				}

				if (
					this.orderControls.iOrder[1].OrderAction == OrderAction.Sell
					|| this.orderControls.iOrder[1].OrderAction == OrderAction.SellShort
					)
				{
					if (this.orderControls.iOrder[1].OrderType == OrderType.Limit)
						this.indOrder.EntryOrderS[1] = this.orderControls.iOrder[1].LimitPrice;
					if (this.orderControls.iOrder[1].OrderType == OrderType.StopMarket || this.orderControls.iOrder[1].OrderType == OrderType.StopLimit)
						this.indOrder.EntryOrderS[1] = this.orderControls.iOrder[1].StopPrice;
				}
			}
			if (this.orderControls.iOrderL[1] != null)
			{
				if (this.orderControls.iOrderL[1].OrderType == OrderType.Limit)
					this.indOrder.EntryOrderL[1] = this.orderControls.iOrderL[1].LimitPrice;
				if (this.orderControls.iOrderL[1].OrderType == OrderType.StopMarket || this.orderControls.iOrderL[1].OrderType == OrderType.StopLimit)
					this.indOrder.EntryOrderL[1] = this.orderControls.iOrderL[1].StopPrice;
			}

			if (this.orderControls.iOrderS[1] != null)
			{
				if (this.orderControls.iOrderS[1].OrderType == OrderType.Limit)
					this.indOrder.EntryOrderS[1] = this.orderControls.iOrderS[1].LimitPrice;
				if (this.orderControls.iOrderS[1].OrderType == OrderType.StopMarket || this.orderControls.iOrderS[1].OrderType == OrderType.StopLimit)
					this.indOrder.EntryOrderS[1] = this.orderControls.iOrderS[1].StopPrice;
			}

			#endregion
		}

		protected bool Historical { get { return State != State.Realtime; } }

		#region RegOrderMethods

		//************************************************************************************
		//************************************************************************************	
		//************************************************************************************
		//************************************************************************************	
		public void LogikSubmitOrder(
										int index,
										string iOrderString,
										double iPrice,
										int iQuantity
									)
		{

			// Don't process if quantity = 0
			if (iQuantity == 0)
				return;

			double price = iPrice;
			eOrderType oType = this.xOrderType;

			if (this.FillType.ToString().Contains("Logik") && this.xOrderType == eOrderType.MARKET)
			{
				price = Closes[ordBIP][0];
				oType = eOrderType.STOPLIMIT;

				if (iOrderString.Contains("L"))
					this.orderControls.SetPendingLogikFill(index, iQuantity);
				if (iOrderString.Contains("S"))
					this.orderControls.SetPendingLogikFill(index, -iQuantity);

				return;
			}

			this.ProcessOrder(index, iOrderString, price, iQuantity, oType);

		}

		private void LogikSubmitOrder(
										int index,
										string iOrderString,
										double iPrice,
										int iQuantity,
										eOrderType iLocOrderType
									)
		{

			// Don't process if quantity = 0
			if (iQuantity == 0)
				return;

			double price = iPrice;
			eOrderType oType = iLocOrderType;

			if (this.FillType.ToString().Contains("Logik") && this.xOrderType == eOrderType.MARKET)
			{
				price = Closes[ordBIP][0];
				oType = eOrderType.STOPLIMIT;

				if (iOrderString.Contains("L"))
					this.orderControls.SetPendingLogikFill(index, iQuantity);
				if (iOrderString.Contains("S"))
					this.orderControls.SetPendingLogikFill(index, -iQuantity);

				return;
			}

			this.ProcessOrder(index, iOrderString, price, iQuantity, oType);
		}


		private void ProcessOrder(
									int index,
									string iOrderString,
									double iPrice,
									int iQuantity,
									eOrderType iLocOrderType)
		{

			if (!this.equityCurveManager.GetCanTrade())
			{
				Draw.Text(this, CurrentBar.ToString() + "nono", "!CanTrade", 0, Median[0], Brushes.Blue);
				return;
			}

			double price = iPrice;
			eOrderType oType = iLocOrderType;

			// LONG ORDER
			if (iOrderString.Contains("L") || iOrderString.Contains("l"))
			{

				// Check if pending order in opposite direction.  If it does, we cancel it b/c you cannot have a bracket entry in managed mode
				if (orderControls.iOrder[index] != null)
				{
					if (
						orderControls.iOrder[index].OrderAction == OrderAction.Sell
						|| orderControls.iOrder[index].OrderAction == OrderAction.SellShort
						|| (orderControls.iOrder[index].OrderType == OrderType.StopMarket && orderControls.iOrder[index].StopPrice != price && this.xOrderType != eOrderType.STOPFIXED)
						|| (orderControls.iOrder[index].OrderType == OrderType.Limit && orderControls.iOrder[index].LimitPrice != price && this.xOrderType != eOrderType.LIMITFIXED)
						)
					{
						CancelOrder(orderControls.iOrder[index]);
						orderControls.iOrder[index] = null;
						Draw.Dot(this, CurrentBar.ToString(), true, 0, High[0], Brushes.White);
					}
				}

				if (oType == eOrderType.MARKET)
				{
					if (orderControls.iOrder[index] == null)
						orderControls.iOrder[index] = EnterLong(ordBIP, iQuantity, iOrderString);
				}
				else if (oType == eOrderType.LIMITFIXED)
				{
					double p = price - this.xOrderLimitValue * TickSize;
					//if(p > GetCurrentBid())
     //               {
					//	p = GetCurrentBid();
     //               }
					if (orderControls.iOrder[index] == null)
					{
						orderControls.bOrder = CurrentBars[0];
						//orderControls.bSinceOrder = 0;
						orderControls.iOrder[index] = EnterLongLimit(ordBIP, true, iQuantity, p, iOrderString);
					}
					else
					{
						// Determine if this is a switch from stop to limit at the same price
						if (orderControls.iOrder[index].OrderType == OrderType.StopMarket)
						{
							if (orderControls.iOrder[index].StopPrice == price)
								return;
						}

						if (orderControls.iOrder[index].LimitPrice != p)
							orderControls.iOrder[index] = EnterLongLimit(ordBIP, true, iQuantity, p, iOrderString);
					}
				}
				else if (oType == eOrderType.LIMITBIDASK)
				{
					if (orderControls.iOrder[index] == null)
						orderControls.bOrder = CurrentBars[0];
					//orderControls.bSinceOrder = 0;
					orderControls.iOrder[index] = EnterLongLimit(ordBIP, true, iQuantity, GetCurrentAsk(), iOrderString);
				}
				else if (oType == eOrderType.LIMITSPREAD)
				{
					if (orderControls.iOrder[index] == null)
						orderControls.bOrder = CurrentBars[0];
					//orderControls.bSinceOrder = 0;

					orderControls.iOrder[index] = EnterLongLimit(ordBIP, true, iQuantity, GetCurrentBid(), iOrderString);
				}
				else if (oType == eOrderType.STOPFIXED)
				{
					if (orderControls.iOrder[index] == null)
					{
						orderControls.bOrder = CurrentBars[0];
						//orderControls.bSinceOrder = 0;
						orderControls.iOrder[index] = EnterLongStopMarket(ordBIP, true, iQuantity, price + this.xOrderStopValue * TickSize, iOrderString);
					}
					else
					{
						// Determine if this is a switch from stop to limit at the same price
						if (orderControls.iOrder[index].OrderType == OrderType.Limit)
						{
							if (orderControls.iOrder[index].LimitPrice == price)
								return;
						}

						if (price + this.xOrderStopValue * TickSize != orderControls.iOrder[index].StopPrice)
							orderControls.iOrder[index] = EnterLongStopMarket(ordBIP, true, iQuantity, price + this.xOrderStopValue * TickSize, iOrderString);
					}

				}
				else if (oType == eOrderType.STOPLIMIT)
				{
					double lim = price - this.xOrderLimitValue * TickSize;
					double stp = price + this.xOrderStopValue * TickSize;

					if (orderControls.iOrder[index] == null)
					{
						orderControls.bOrder = CurrentBars[0];
						//orderControls.bSinceOrder = 0;
						orderControls.iOrder[index] = EnterLongStopLimit(ordBIP, true, iQuantity, lim, stp, iOrderString);
					}
					else
					{
						if (lim != orderControls.iOrder[index].LimitPrice || stp != orderControls.iOrder[index].StopPrice)
							orderControls.iOrder[index] = EnterLongStopLimit(ordBIP, true, iQuantity, lim, stp, iOrderString);
					}
				}
			}

			// SHORT ORDER
			if (iOrderString.Contains("S") || iOrderString.Contains("s"))
			{
				// Check if pending order in opposite direction.  If it does, we cancel it b/c you cannot have a bracket entry in managed mode
				if (orderControls.iOrder[index] != null)
				{
					if (
						orderControls.iOrder[index].OrderAction == OrderAction.Buy
						|| orderControls.iOrder[index].OrderAction == OrderAction.BuyToCover
						|| (orderControls.iOrder[index].OrderType == OrderType.StopMarket && orderControls.iOrder[index].StopPrice != price && this.xOrderType != eOrderType.STOPFIXED)
						|| (orderControls.iOrder[index].OrderType == OrderType.Limit && orderControls.iOrder[index].LimitPrice != price && this.xOrderType != eOrderType.LIMITFIXED)
						)
					{
						CancelOrder(orderControls.iOrder[index]);
						orderControls.iOrder[index] = null;
					}
				}

				if (oType == eOrderType.MARKET)
				{
					if (orderControls.iOrder[index] == null)
						orderControls.iOrder[index] = EnterShort(ordBIP, iQuantity, iOrderString);
				}
				else if (oType == eOrderType.LIMITFIXED)
				{
					double p = price + this.xOrderLimitValue * TickSize;
                    if (p <= GetCurrentAsk())
                    {
                        p = GetCurrentAsk();
                    }
                    if (IsDebug)Print("price: "+price+"  ticks: "+xOrderLimitValue+":   limit entry at: "+p);
					if (orderControls.iOrder[index] == null)
					{
						orderControls.bOrder = CurrentBars[0];
						//orderControls.bSinceOrder = 0;
						orderControls.iOrder[index] = EnterShortLimit(ordBIP, true, iQuantity, p, iOrderString);
if(IsDebug && orderControls.iOrder[index] != null) Print("1744  Limit short entry order placed: ("+index+") "+orderControls.iOrder[index].ToString());
					}
					else
					{
						// Determine if this is a switch from stop to limit at the same price
						if (orderControls.iOrder[index].OrderType == OrderType.StopMarket)
						{
							if (orderControls.iOrder[index].StopPrice == price)
								return;
						}

						if (orderControls.iOrder[index].LimitPrice != p)
							orderControls.iOrder[index] = EnterShortLimit(ordBIP, true, iQuantity, p, iOrderString);
					}
				}
				else if (oType == eOrderType.LIMITBIDASK)
				{
					if (orderControls.iOrder[index] == null)
						orderControls.bOrder = CurrentBars[0];
					//orderControls.bSinceOrder = 0;

					orderControls.iOrder[index] = EnterShortLimit(ordBIP, true, iQuantity, GetCurrentBid(), iOrderString);
if(IsDebug) Print("1765  Limit short entry order placed: ("+index+") "+orderControls.iOrder[index].ToString());
				}
				else if (oType == eOrderType.LIMITSPREAD)
				{
					if (orderControls.iOrder[index] == null)
						orderControls.bOrder = CurrentBars[0];
					//orderControls.bSinceOrder = 0;

					orderControls.iOrder[index] = EnterShortLimit(ordBIP, true, iQuantity, GetCurrentAsk(), iOrderString);
if(IsDebug) Print("1773  Limit short entry order placed: ("+index+") "+orderControls.iOrder[index].ToString());
				}
				else if (oType == eOrderType.STOPFIXED)
				{
					if (orderControls.iOrder[index] == null)
					{
						orderControls.bOrder = CurrentBars[0];
						//orderControls.bSinceOrder = 0;
						orderControls.iOrder[index] = EnterShortStopMarket(ordBIP, true, iQuantity, price - this.xOrderStopValue * TickSize, iOrderString);
					}
					else
					{
						// Determine if this is a switch from stop to limit at the same price
						if (orderControls.iOrder[index].OrderType == OrderType.Limit)
						{
							if (orderControls.iOrder[index].LimitPrice == price)
								return;
						}

						if (price + this.xOrderStopValue * TickSize != orderControls.iOrder[index].StopPrice)
							orderControls.iOrder[index] = EnterShortStopMarket(ordBIP, true, iQuantity, price - this.xOrderStopValue * TickSize, iOrderString);
					}
				}
				else if (oType == eOrderType.STOPLIMIT)
				{
					double lim = price + this.xOrderLimitValue * TickSize;
					double stp = price - this.xOrderStopValue * TickSize;

					if (orderControls.iOrder[index] == null)
					{
						orderControls.bOrder = CurrentBars[0];
						//orderControls.bSinceOrder = 0;
						orderControls.iOrder[index] = EnterShortStopLimit(ordBIP, true, iQuantity, lim, stp, iOrderString);
					}
					else
					{
						if (lim != orderControls.iOrder[index].LimitPrice || stp != orderControls.iOrder[index].StopPrice)
							orderControls.iOrder[index] = EnterShortStopLimit(ordBIP, true, iQuantity, lim, stp, iOrderString);
					}
				}
			}

		}

		private void LogikSubmitMarketLogikFillOrder(
											int index,
											string iOrderString,
											int iQuantity
											)
		{

			// Don't process if quantity = 0
			if (iQuantity == 0)
				return;

			double price = Closes[ordBIP][0];

			// LONG ORDER
			if (iOrderString.Contains("L") || iOrderString.Contains("l"))
			{
				orderControls.bOrder = CurrentBars[0];
				//orderControls.bSinceOrder = 0;
				orderControls.iOrder[index] = EnterLongStopLimit(ordBIP, true, iQuantity, price + this.xOrderLimitValue * TickSize, price + this.xOrderStopValue * TickSize + TickSize, iOrderString);
			}

			// SHORT ORDER
			if (iOrderString.Contains("S") || iOrderString.Contains("s"))
			{
				orderControls.bOrder = CurrentBars[0];
				//orderControls.bSinceOrder = 0;
				orderControls.iOrder[index] = EnterShortStopLimit(ordBIP, true, iQuantity, price - this.xOrderLimitValue * TickSize, price - this.xOrderStopValue * TickSize - TickSize, iOrderString);
			}
		}


		//************************************************************************************
		//************************************************************************************	
		//************************************************************************************
		//************************************************************************************	

		private void LogikSubmitTargStop(
										int index,
										string iOrderString,
										int iQuantity,
										double iTargetPrice, double iStopPrice
										)
		{
			// LONG ORDER
			if (iOrderString.Contains("L") || iOrderString.Contains("l"))
			{
				// Submit the target
				if (iTargetPrice != 0)
				{
					int q = iQuantity;
					orderControls.iTargOrder[index] = ExitLongLimit(ordBIP, true, q, iTargetPrice, "trgL" + index.ToString(), iOrderString);
				}

				// Submit the stop
				if (iStopPrice != 0)
				{
					int q = iQuantity;
					// Protect against stop order error
					if (Closes[ordBIP][0] <= iStopPrice)
						iStopPrice = Historical ? Closes[1][0] - (1 * TickSize) : GetCurrentBid() - TickSize;
					orderControls.iStopOrder[index] = ExitLongStopMarket(ordBIP, true, iQuantity, iStopPrice, "stpL" + index.ToString(), iOrderString);
				}

				return;
			}

			// SHORT ORDER
			if (iOrderString.Contains("S") || iOrderString.Contains("s"))
			{
				// Submit the target
				if (iTargetPrice != 0)
				{
					int q = iQuantity;
					orderControls.iTargOrder[index] = ExitShortLimit(ordBIP, true, q, iTargetPrice, "trgS" + index.ToString(), iOrderString);
				}

				// Submit the stop
				if (iStopPrice != 0)
				{
					int q = iQuantity;
					// Protect against stop order error
					if (Closes[ordBIP][0] >= iStopPrice)
						iStopPrice = Historical ? Closes[1][0] + (1 * TickSize) : GetCurrentAsk() + TickSize;
					orderControls.iStopOrder[index] = ExitShortStopMarket(ordBIP, true, iQuantity, iStopPrice, "stpS" + index.ToString(), iOrderString);
				}
			}
		}


		public void LogikExitOrder(
									int index,
									string iOrderString
								   )
		{
			// Check for pending order to cancel.
			if (this.orderControls.iStopOrder[index] != null || this.orderControls.iTargOrder[index] != null)
			{
				this.orderControls.bExitOnCancelStop[index] = iOrderString;
				if (this.orderControls.iStopOrder[index] != null)
					CancelOrder(this.orderControls.iStopOrder[index]);
				if (this.orderControls.iTargOrder[index] != null)
					CancelOrder(this.orderControls.iTargOrder[index]);
			}
			else
			{
				// No order, exit the portion
				if (Position.MarketPosition == MarketPosition.Long)
					ExitLong(ordBIP, Math.Min(Position.Quantity, this.positionSize.GetQuantity(index)), iOrderString, string.Empty);
				if (Position.MarketPosition == MarketPosition.Short)
					ExitShort(ordBIP, Math.Min(Position.Quantity, this.positionSize.GetQuantity(index)), iOrderString, string.Empty);
			}
		}

		//************************************************************************************
		//************************************************************************************		
		public void LogikExitPosition(string iName)
		{
			gExitName = iName;
			//Print(iName + ", " + CurrentBar + ", " + BarsInProgress);
			//Print(Environment.StackTrace);

			// Cleanup post reject
			if (
				iName == "clearReject"
				&& this.orderControls.IsPendingEntryOrders()
				)
				this.LogikCancelPendingEntryOrder();

			// If there are pending exit orders, cancel them.  This is called again once all cancelled
			if (orderControls.IsPendingExitOrders())
			{
				this.LogikCancelAllTargetsStops();
				//return;
			}

			if (Position.MarketPosition == MarketPosition.Long)
			{
				if (orderControls.iOrder[0] == null)
                {
                    orderControls.iOrder[0] = ExitLong(ordBIP, Position.Quantity, gExitName, string.Empty);
                }
				else
                {
					//Print(orderControls.iOrder[0].Name + ", " + orderControls.iOrder[0].OrderState.ToString());
                }
            }

			if (Position.MarketPosition == MarketPosition.Short)
			{
				if (orderControls.iOrder[0] == null)
                {
                    orderControls.iOrder[0] = ExitShort(ordBIP, Position.Quantity, gExitName, string.Empty);
				}
				else
				{
					//Print(orderControls.iOrder[0].Name + ", " + orderControls.iOrder[0].OrderState.ToString());
				}
			}

			gExitName = string.Empty;
		}


		public void LogikCancelBracket(int index, MarketPosition iMp)
		{
			if (iMp == MarketPosition.Long && index < this.orderControls.iOrderL.Length)
				if (this.orderControls.iOrderL[index] != null)
					CancelOrder(this.orderControls.iOrderL[index]);
			if (iMp == MarketPosition.Short && index < this.orderControls.iOrderS.Length)
				if (this.orderControls.iOrderS[index] != null)
					CancelOrder(this.orderControls.iOrderS[index]);
		}

		public void LogikCancelBracketComplete(MarketPosition iMp)
		{
			if (iMp == MarketPosition.Long)
			{
				for (int i = 0; i < this.orderControls.iOrderL.Length; i++)
					if (this.orderControls.iOrderL[i] != null)
						CancelOrder(this.orderControls.iOrderL[i]);
			}
			if (iMp == MarketPosition.Short)
			{
				for (int i = 0; i < this.orderControls.iOrderS.Length; i++)
					if (this.orderControls.iOrderS[i] != null)
						CancelOrder(this.orderControls.iOrderS[i]);
			}
		}

		public void LogikCancelPendingEntryOrder()
		{
			// Enabled 11/6/2015
			for (int i = 0; i < this.orderControls.iOrder.Length; i++)
				this.LogikCancelPendingEntryOrder(i);
			this.LogikCancelBracketComplete(MarketPosition.Long);
			this.LogikCancelBracketComplete(MarketPosition.Short);
		}

		public void LogikCancelPendingEntryOrder(int index)
		{
			if (index == 0)
				return;

			if (this.orderControls.iOrder[index] != null)
			{
				if (this.orderControls.iOrder[index].OrderType != OrderType.Market)
					CancelOrder(this.orderControls.iOrder[index]);

				this.orderControls.iOrder[index] = null;
			}

			if (this.orderControls.iOrderL[index] != null)
			{
				if (this.orderControls.iOrderL[index].OrderType != OrderType.Market)
					CancelOrder(this.orderControls.iOrderL[index]);

				this.orderControls.iOrderL[index] = null;
			}
			if (this.orderControls.iOrderS[index] != null)
			{
				if (this.orderControls.iOrderS[index].OrderType != OrderType.Market)
					CancelOrder(this.orderControls.iOrderS[index]);


				this.orderControls.iOrderS[index] = null;
			}
		}

		public Order LogikGetOrderPending(int index)
		{
			return this.orderControls.iOrder[index];
		}

		public Order LogikGetOrderPendingBracket(int index, MarketPosition iMp)
		{
			if (iMp == MarketPosition.Long)
				return this.orderControls.iOrderL[index];
			if (iMp == MarketPosition.Short)
				return this.orderControls.iOrderS[index];

			return null;
		}

		public void LogikSetUseSingleStopFlag()
		{
			this.orderControls.SetUseSingleStop(true);
		}

		#endregion

		#region RegStopFunctions

		public void LogikUpdateSingleStopValue(
											int index,
											double iPrice
											)
		{
			if (index >= this.orderControls.iStopOrder.Length)
				return;

			if (this.orderControls.iStopOrder[index] != null)
			{
				if (Position.MarketPosition == MarketPosition.Long)
				{
					if (iPrice > this.orderControls.iStopOrder[index].StopPrice)
						this.LogikSubmitTargStop(index, "L" + index.ToString(), orderControls.iStopOrder[index].Quantity, 0, iPrice);
				}
				if (Position.MarketPosition == MarketPosition.Short)
				{
					if (iPrice < this.orderControls.iStopOrder[index].StopPrice)
						this.LogikSubmitTargStop(index, "S" + index.ToString(), orderControls.iStopOrder[index].Quantity, 0, iPrice);
				}
			}
		}

		public void LogikUpdateSingleStopValue(
											int index,
											double iPrice,
											bool iOverrideCheck
											)
		{
			if (index >= this.orderControls.iStopOrder.Length)
				return;

			if (this.orderControls.iStopOrder[index] != null)
			{
				if (Position.MarketPosition == MarketPosition.Long)
				{
					if (iPrice > this.orderControls.iStopOrder[index].StopPrice || iOverrideCheck)
						this.LogikSubmitTargStop(index, "L" + index.ToString(), orderControls.iStopOrder[index].Quantity, 0, iPrice);
				}
				if (Position.MarketPosition == MarketPosition.Short)
				{
					if (iPrice < this.orderControls.iStopOrder[index].StopPrice || iOverrideCheck)
						this.LogikSubmitTargStop(index, "S" + index.ToString(), orderControls.iStopOrder[index].Quantity, 0, iPrice);
				}
			}
		}


		public void LogikUpdateStopOrder(int idx, int iQuantity)
		{
			if (this.orderControls.iStopOrder[idx] != null)
				this.LogikSubmitTargStop(idx, this.orderControls.iStopOrder[idx].FromEntrySignal, iQuantity, 0, this.orderControls.iStopOrder[idx].StopPrice);
		}
		public void LogikUpdateStopOrder(int idx, double iPrice, int iQuantity)
		{
			if (this.orderControls.iStopOrder[idx] != null)
				this.LogikSubmitTargStop(idx, this.orderControls.iStopOrder[idx].FromEntrySignal, iQuantity, 0, iPrice);
		}

		public void LogikUpdateStopValue(double iPrice, bool iOverrideCheck)
		{
			for (int index = 1; index < this.orderControls.GetNumOrders(); index++)
			{
				if (this.orderControls.iStopOrder[index] != null)
				{
					if (Position.MarketPosition == MarketPosition.Long)
					{
						if (iPrice > this.orderControls.iStopOrder[index].StopPrice || iOverrideCheck)
							this.LogikSubmitTargStop(index, "L" + index.ToString(), orderControls.iStopOrder[index].Quantity, 0, iPrice);
					}
					if (Position.MarketPosition == MarketPosition.Short)
					{
						if (iPrice < this.orderControls.iStopOrder[index].StopPrice || iOverrideCheck)
							this.LogikSubmitTargStop(index, "S" + index.ToString(), orderControls.iStopOrder[index].Quantity, 0, iPrice);
					}
				}
			}
		}
		public void LogikUpdateStopValue(double iPrice)
		{
			for (int index = 1; index < this.orderControls.GetNumOrders(); index++)
			{
				if (this.orderControls.iStopOrder[index] != null)
				{
					if (Position.MarketPosition == MarketPosition.Long)
					{
						if (iPrice > this.orderControls.iStopOrder[index].StopPrice)
							this.LogikSubmitTargStop(index, "L" + index.ToString(), orderControls.iStopOrder[index].Quantity, 0, iPrice);
					}
					if (Position.MarketPosition == MarketPosition.Short)
					{
						if (iPrice < this.orderControls.iStopOrder[index].StopPrice)
							this.LogikSubmitTargStop(index, "S" + index.ToString(), orderControls.iStopOrder[index].Quantity, 0, iPrice);
					}
				}
			}
		}

		public Order LogikGetStopLossOrder(int index)
		{
			if (index >= this.orderControls.iStopOrder.Length)
				return null;

			return this.orderControls.iStopOrder[index];
		}

		public bool LogikGetStopLossActive(int index)
		{
			if (this.orderControls.iStopOrder[index] != null)
				return true;

			return false;
		}

		public void LogikSetReverseAtPendingStop(bool iValue)
		{
			this.orderControls.bReverseAtPendingStop = iValue;
		}


		public void LogikSetStopLossValueByIdx(int idx, double iValue)
		{
			this.orderControls.SetStopValue(idx, 1, iValue);
			this.orderControls.SetStopValue(idx, -1, iValue);
		}

		public void LogikSetStopLossValue(double iValue)
		{
			this.orderControls.SetStopValue(0, 1, iValue);
			this.orderControls.SetStopValue(0, -1, iValue);
		}
		public void LogikSetStopLossValue(int iDirection, double iValue)
		{
			this.orderControls.SetStopValue(0, iDirection, iValue);
		}
		public void LogikSetStopLossValue(int idx, int iDirection, double iValue)
		{
			this.orderControls.SetStopValue(idx, iDirection, iValue);
		}

		public void LogikSetStopLossType(eStopTargMode iType)
		{
			this.orderControls.SetStopType(iType);
		}

		public void LogikSetTrailParams(int iValue, double iStepStopLoss, double iStepFrequency, double iStepProfitTrigger)
		{
			this.orderControls.SetTrailParameters(iValue, iStepStopLoss, iStepFrequency, iStepProfitTrigger);
		}

		public void LogikSetBreakEvenParams(int iValue, double iBreakEvenTrigger, double iBreakEvenPlus)
		{
			this.orderControls.SetBreakEvenParameters(iValue, iBreakEvenTrigger, iBreakEvenPlus);
		}

		#endregion

		#region RegTargetFunctions

		public void LogikSetTargetValue(int iIdx, double iValue)
		{
			this.orderControls.SetTargetValue(iIdx, iValue);
		}

		public void LogikSetTargetType(eStopTargMode iType)
		{
			this.orderControls.SetTargetType(iType);
		}

		public bool LogikGetTargetActive(int index)
		{
			if (this.orderControls.iTargOrder[index] != null)
				return true;

			return false;
		}

		public double LogikGetTargetPrice(int iIdx)
		{
			return this.orderControls.GetTargPrice(iIdx);
		}

		public void LogikUpdateTargetOrder(int idx, double iValue)
		{
			if (this.orderControls.iTargOrder[idx] != null)
				this.LogikSubmitTargStop(idx, this.orderControls.iTargOrder[idx].FromEntrySignal, this.orderControls.iTargOrder[idx].Quantity, iValue, 0);
		}

		public void LogikUpdateTargetOrder(int idx, int iQuantity)
		{
			if (this.orderControls.iTargOrder[idx] != null)
				this.LogikSubmitTargStop(idx, this.orderControls.iTargOrder[idx].FromEntrySignal, iQuantity, this.orderControls.iTargOrder[idx].LimitPrice, 0);
		}

		public void LogikUpdateTargetOrder(int idx, double iValue, int iQuantity)
		{
			if (this.orderControls.iTargOrder[idx] != null)
				this.LogikSubmitTargStop(idx, this.orderControls.iTargOrder[idx].FromEntrySignal, iQuantity, iValue, 0);
		}

		#endregion

		#region RegPositionManagement

		public double LogikGetMaxPriceMovementAvgEntryTicks()
		{
			if (Position.MarketPosition == MarketPosition.Long)
				return (this.orderControls.hHigh - Position.AveragePrice) / TickSize;
			if (Position.MarketPosition == MarketPosition.Short)
				return (Position.AveragePrice - this.orderControls.lLow) / TickSize;

			return 0;
		}

		public double LogikGetMaxPriceMovementAvgEntryTicks(int index)
		{
			if (Position.MarketPosition == MarketPosition.Long)
				return (this.orderControls.hPriceSinceEntry[index] - this.orderControls.orderEntryPrice[index]) / TickSize;
			if (Position.MarketPosition == MarketPosition.Short)
				return (this.orderControls.orderEntryPrice[index] - this.orderControls.lPriceSinceEntry[index]) / TickSize;

			return 0;
		}

		public double LogikGetMaxPriceMovementAvgEntryTicks(int index, double iRefPrice)
		{
			if (Position.MarketPosition == MarketPosition.Long)
				return (this.orderControls.hPriceSinceEntry[index] - iRefPrice) / TickSize;
			if (Position.MarketPosition == MarketPosition.Short)
				return (iRefPrice - this.orderControls.lPriceSinceEntry[index]) / TickSize;

			return 0;
		}

		public double LogikGetHighestHighSinceFill()
		{
			return MAX(Highs[0], CurrentBars[0] - this.orderControls.bOfFill)[0];
		}

		public double LogikGetHighestHighSinceFill(int index)
		{
			return this.orderControls.hPriceSinceEntry[index];
		}

		public double LogikGetLowestLowSinceFill()
		{
			return MIN(Lows[0], CurrentBars[0] - this.orderControls.bOfFill)[0];
		}

		public double LogikGetLowestLowSinceFill(int index)
		{
			return this.orderControls.lPriceSinceEntry[index];
		}

		public int LogikGetBarsSinceFill()
		{
			return CurrentBars[0] - this.orderControls.bOfFill;
		}

		public double LogikGetOrderEntryPrice(int index)
		{
			return this.orderControls.orderEntryPrice[index];
		}

		public bool LogikGetPendingReversal()
		{
			return this.orderControls.bPendingFill;
		}

		private void LogikCancelOrder(int index)
		{
			if (index == 0)
				return;
			//Log("Cancel Order: " + index + " because of the time constrains", LogLevel.Information);
			this.LogikCancelPendingEntryOrder(index);
		}

		private void LogikCancelTarget(int index)
		{
			if (orderControls.iTargOrder[index] != null)
				CancelOrder(orderControls.iTargOrder[index]);
		}
		private void LogikCancelStop(int index)
		{
			if (orderControls.iStopOrder[index] != null)
				CancelOrder(orderControls.iStopOrder[index]);
		}

		private void LogikCancelAllTargetsStops()
		{
			for (int i = 1; i < orderControls.GetNumOrders(); i++)
			{
				this.LogikCancelStop(i);
				this.LogikCancelTarget(i);
			}
		}


		#endregion

		#region RegPnLMethods

		public bool LogikGetCanTrade()
		{
			if (!this.equityCurveManager.GetCanTrade())
				BarBrush = Brushes.DimGray;

			return this.equityCurveManager.GetCanTrade() && CurrentBars[0] > BarsRequiredToTrade;
		}

		private bool LogikCheckDayPnl(double iPrice)
		{
			// This is where we check prior trades.  First, ensure there are trades to check
			double realizedPnl = this.LogikGetRealizedPnl();
			double unRealizedPnl = 0;
			// Add current position
			if (Position.MarketPosition != MarketPosition.Flat)
				unRealizedPnl = Position.GetUnrealizedProfitLoss(PerformanceUnit.Currency, iPrice);

			//Print("Unrealized PnL: " + unRealizedPnl + ", Realized PnL: " + realizedPnl);
			this.equityCurveManager.UpdatePnl(realizedPnl, unRealizedPnl);
			if (Position.MarketPosition != MarketPosition.Flat)
			{
				string exitReason = string.Empty;
				if (this.equityCurveManager.GetExitPosition(ref exitReason))
                {
					Print(exitReason);
					this.LogikExitPosition(exitReason);
                }
            }

			return this.equityCurveManager.GetCanTrade();
		}

		private double LogikGetChartPnl(double iPrice)
		{
			double pnl = this.LogikGetRealizedPnl();
			if (Position.MarketPosition != MarketPosition.Flat)
				pnl += Position.GetUnrealizedProfitLoss(PerformanceUnit.Currency, iPrice);

			return pnl;
		}

		public double LogikGetTrackedPnl()
		{
			// This is where we check prior trades.  First, ensure there are trades to check
			if (SystemPerformance.AllTrades.Count != 0)
			{
				double pnl = 0;

				// Now, loop through all completed trades. 
				for (int i = 0; i < SystemPerformance.AllTrades.Count; i++)
				{
					Trade trd = SystemPerformance.AllTrades[i];
					pnl += trd.ProfitCurrency;
				}

				return Math.Round(pnl, 2);
			}

			return 0;
		}

		public double LogikGetRealizedPnl()
		{
			// This is where we check prior trades.  First, ensure there are trades to check
			if (SystemPerformance.AllTrades.Count != 0)
			{
				double pnl = 0;

				// Now, loop through all completed trades. 
				for (int i = 0; i < SystemPerformance.AllTrades.Count; i++)
				{
					Trade trd = SystemPerformance.AllTrades[i];

					// Check trades AFTER the starting reference time
					if (trd.Entry.Time >= this.equityCurveManager.dtTradeRef)
						pnl += trd.ProfitCurrency;
				}

				return Math.Round(pnl, 2);
			}

			return 0;
		}

		#endregion
		#region RegGetMethods

		public bool LogikGetActiveTradeTime(int idx)
		{
			return this.sTime[idx];
		}

		public bool LogikGetTradeWithoutTime()
		{
			if (this.StartTime == 0 && this.EndTime == 0)
				return true;

			return false;
		}

		public bool LogikGetActiveTradeTimeBar(int idx)
		{
			return this.sTimeBar[idx];
		}

		public int LogikGetBarDirection(int idx)
		{
			return (int)this.sBarDirection[idx];
		}

		#endregion

		#region HelperMethods				

		public double LogikTruncateToDataBoxValue(double iValue)
		{
			int decRnd = Math.Max(TickSize.ToString().Length - 2, 1);
			string[] vals = iValue.ToString().Split('.');
			if (vals.Length > 1)
			{
				double rValue = Math.Floor(iValue) + Convert.ToDouble("." + vals[1].Substring(0, Math.Min(vals[1].Length, decRnd)));
				return rValue;
			}

			return Math.Floor(iValue);
		}

		private bool LogikSweetTime(int iBar, int iStartTime, int iEndTime, int iEndTimeFriday)
		{
			int time = Times[iBar][0].Hour * 100 + Times[iBar][0].Minute;

			// Disabled
			if (iStartTime == -1 || iEndTime == -1)
				return false;
			// 24/7
			if (iStartTime == 0 && iEndTime == 0)
				return true;

			// Friday End Time Check
			if (time >= iEndTimeFriday && Times[iBar][0].Date.DayOfWeek == DayOfWeek.Friday)
				return false;

			int sHr = 0;
			int sMn = 0;
			int sSc = 0;

			int eHr = 0;
			int eMn = 0;
			int eSc = 0;

			if (iStartTime.ToString().Length < 5)
			{
				sHr = (int)Math.Truncate((double)(iStartTime / 100.0));
				sMn = iStartTime - sHr * 100;
			}
			else
			{
				sHr = (int)Math.Truncate((double)(iStartTime / 10000.0));
				sMn = (int)(Math.Truncate((double)(iStartTime / 100.0)) - Math.Truncate((double)(sHr * 100)));
				sSc = iStartTime - (((sHr * 10000) + (sMn * 100)));
			}

			if (iEndTime.ToString().Length < 5)
			{
				eHr = (int)Math.Truncate((double)(iEndTime / 100.0));
				eMn = iEndTime - eHr * 100;
			}
			else
			{
				eHr = (int)Math.Truncate((double)(iEndTime / 10000.0));
				eMn = (int)(Math.Truncate((double)(iEndTime / 100.0)) - Math.Truncate((double)(eHr * 100)));
				eSc = iEndTime - (((eHr * 10000) + (eMn * 100)));
			}

			if(eHr > 23)
            {
				eHr = 23;
				eMn = 59;
				eSc = 59;
            }

			DateTime dtStart = new DateTime(Times[iBar][0].Year, Times[iBar][0].Month, Times[iBar][0].Day, sHr, sMn, sSc, 0);
			DateTime dtEnd = new DateTime(Times[iBar][0].Year, Times[iBar][0].Month, Times[iBar][0].Day, eHr, eMn, eSc, 0);

			if (iEndTime < iStartTime)
            {
				if(Times[iBar][0] < dtStart)
                {
					dtStart = dtStart.AddDays(-1);
				}
				else
                {
					dtEnd = dtEnd.AddDays(1);
                }
            }

			if (Times[iBar][0] >= dtStart && Times[iBar][0] < dtEnd)
				return true;

			return false;
		}

		//*************************************************************
		//*************************************************************
		#endregion


		#region Properties

		#region RegMainInputs
		[NinjaScriptProperty]
		[Display(Name="RunType", Description="Set to Backtest when backtesting, Real-Time when trading in real-time", Order=1, GroupName="aTimeControlParameters")]
		public eRunType XRunType
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="TradeStartTime", Description="Time in hhmm 24-hour format", Order=2, GroupName="aTimeControlParameters")]
		public int StartTime
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="TradeEndTime", Description="Time in hhmm 24-hour format", Order=3, GroupName="aTimeControlParameters")]
		public int EndTime
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="ExitAtEndTime", Description="Set to true to exit at the end time, false otherwise", Order=4, GroupName="aTimeControlParameters")]
		public bool ExitAtEndTime
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Ignore Trade Time", Description = "Set true to trade all the time", Order = 5, GroupName = "aTimeControlParameters")]
		public bool IgnoreTradeTime
		{ get; set; }

		#endregion

		#region RegDayGainLoss

		[NinjaScriptProperty]
		[Display(Name="Exit at Goal Reached", Description="Set the strategy to close the position when the pnl goal is reached.", Order=1, GroupName="bMoneyManagementParameters")]
		public bool ExitOnMaxProfitReached
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Reset Pnl On Time Slot", Description="Restart Pnl Calculation at each time slot", Order=2, GroupName="bMoneyManagementParameters")]
		public bool RestartPnlOnSession
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="DayMaxGoal $", Description="Day Gain when achieved stop trading.  0 to disable", Order=3, GroupName="bMoneyManagementParameters")]
		public int DayMaxGain
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="DayMaxLoss $", Description="Day Loss when achieved stop trading.  0 to disable", Order=4, GroupName="bMoneyManagementParameters")]
		public int DayMaxLoss
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="High Water Mark", Description="Day High Water Mark", Order=5, GroupName="bMoneyManagementParameters")]
		public eHighWaterMarkType HighWaterMarkType
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="High Water Mark %", Description="Day High Water Mark % DrawDown.  0 to disable", Order=6, GroupName="bMoneyManagementParameters")]
		public double DailyHighWaterMarkPct
		{ get; set; }

		#endregion

		#region Visuals

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Stop Dot Color", Order = 101, GroupName = "bVisualParameters")]
		public Brush StopDotColor
		{ get; set; }

		[Browsable(false)]
		public string StopDotColorSerializable
		{
			get { return Serialize.BrushToString(StopDotColor); }
			set { StopDotColor = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Target Dot Color", Order = 102, GroupName = "bVisualParameters")]
		public Brush TargetDotColor
		{ get; set; }

		[Browsable(false)]
		public string TargetDotColorSerializable
		{
			get { return Serialize.BrushToString(TargetDotColor); }
			set { TargetDotColor = Serialize.StringToBrush(value); }
		}

		#endregion
		#endregion

	}
}
