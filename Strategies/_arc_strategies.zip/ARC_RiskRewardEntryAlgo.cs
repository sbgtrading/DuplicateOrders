#define DoLicense		//Uncomment to add NT licensing code at compilation for production only
#define MODERATORS


#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
using System.IO;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARCRiskRewardEAV23 : Strategy
	{
		#region -- Variables --
		private bool NakedPosition = false;
		private bool FileNotRead = true;
		private bool EntryOrderPlaced = false;


		private System.Windows.Controls.Grid   myLeftGrid;
		
		private System.Windows.Controls.Button myExitButton;
		private System.Windows.Controls.Button myAutotraderButton;
		private System.Windows.Controls.Button myT1Button;
		private System.Windows.Controls.Button myT2Button;
		private System.Windows.Controls.Button myT3Button;
		private System.Windows.Controls.Button myT4Button;
		private System.Windows.Controls.Button myBEButton;
		private System.Windows.Controls.Button myMMModeButton;
		
	    private DateTime TimeNewSignal;
		
		private DateTime TimeLastStopModification;
		
		private double TotalPnL = 0.0;
		private double TotalRealizedPnL = 0.0;
		private double TotalUnrealizedPnL = 0.0;
		private double TotalAccountValue = 0.0;
		
		private bool NewSignal = false;
			
		DateTime TimeLastText;
		
		DateTime TimeTimeExitExecuted;
		DateTime TimeMaxDailyGainExitExecuted;
		DateTime TimeMaxDailyLossExitExecuted;
		DateTime TimeMaxAccountValueExitExecuted;
		DateTime TimeTrailExitExecuted;
		DateTime TimeEntryOrderExecuted;
		DateTime TimeStopOrderExecuted;
		DateTime TimeTargetOrderExecuted;
		DateTime TimeEntryOrderCancelledByStrategy;
		DateTime TimeEntryOrderCancelledManually;
		DateTime TimeExitManually;
		DateTime TimeEntryOrderRejected;
		DateTime TimeManualExitClicked;
		DateTime TimeStopOrderModified;
		
		DateTime TimeEntryOrderFilled;
		DateTime TimeStopOrderFilled;
		
		DateTime TimeLastOrderUpdated;
		
		DateTime TimeNakedExitExecuted;
		
		DateTime TimeEntryPriceDefined;
		
		
		private bool GotInitialPnL = false;
		
		private bool BreakEvenReached = false;
		
		private bool ButtonsCreated = false;
		
		private int TradeMode = 0;
		
		private double ProfitPerTick = 0.0;
		
		private double RewardT1 = 0.0;
		private double RiskT1 = 0.0;
		private double RewardT2 = 0.0;
		private double RiskT2 = 0.0;
		private double RewardT3 = 0.0;
		private double RiskT3 = 0.0;
		private double RewardT4 = 0.0;
		private double RiskT4 = 0.0;
		
		private double TotalReward = 0.0;
		private double TotalRisk = 0.0;
		
		private bool EntryOrderFilled = false;
		private bool StopOrderFilled = false;
		private bool TargetOrderFilled = false;
		private bool EntryOrderCancelledByStrategy = false;
		private bool EntryOrderCancelledManually = false;
		private bool EntryOrderRejected = false;
		
		private bool ExitManually = false;
		
		private string Status = "Flat";
	
		private double StopContracts = 0.0;
		private double TargetContracts = 0.0;
		private bool NakedExitExecuted = false;
	
		private int NakedCounter = 0;
		
		private string path;
		private StreamWriter sw;
		
		private List<double> UsedHighLevels = new List<double>();
		private List<double> UsedLowLevels = new List<double>();
		
		private bool TargetHitT1 = false;
		private bool TargetHitT2 = false;
		private bool TargetHitT3 = false;
		private bool TargetHitT4 = false;
		
		private bool BreakEvenT1Triggered = false;
		private bool BreakEvenT2Triggered = false;
		private bool BreakEvenT3Triggered = false;
		private bool BreakEvenT4Triggered = false;
		
		private string TradedInstrument = string.Empty;
		
		private bool ProfitPerTickDefined = false;
		
		private int BarNewSignal = 0;
		private int BarMaxDailyGainExitExecuted = 0;
		private int BarMaxDailyLossExitExecuted = 0;
		private int BarMaxAccountValueExitExecuted = 0;
		private int BarTimeExitExecuted = 0;
		private int BarManualExitExecuted = 0;
		
		
		private double RREntry = 0.0;
		private double SMCStop = 0.0;
		private double RRTarget1 = 0.0;
		private double RRTarget2 = 0.0;
		private double RRTarget3 = 0.0;
		private double RRTarget4 = 0.0;
		
		private bool RRToolOnChart = false;
		
		private int EntryBar = 0;
		
		private bool ManualExitClicked = false;
		
		private Order myOrder;
		
		private double MaxQ = 0.0;
		private double TotalRiskInTicks = 0;
		
		private long MaxQuantityToTrade = 0;
		
		private double MaxRiskAmountUSD = 0.0;
		
		private long ContractsR = 0;
		
		private CalcTypes calcType	= CalcTypes.Dollar_Value;
		
		private TargetsForBE targetForBE	= TargetsForBE.T1;
		
		private PositionsForStrategyControls  positionForStrategyControls = PositionsForStrategyControls.TopLeft;
		
		private PositionsForInfoWindow  positionForInfoWindow = PositionsForInfoWindow.BottomLeft;
		
		private int RRToolsOnChartQuantity = 0;
		
		private string textToRender = string.Empty;
		
		private SimpleFont	infoWindowFont;
		private SimpleFont	messageTextFont;
		private SimpleFont  buttonStrategyControlBoxFont;
		private SimpleFont  rRToolWarningFont;
		
		private string ContentForBEButtonON = string.Empty;
		private string ContentForBEButtonOFF = string.Empty;
		
		private float a = 0.0F;
		private float b = 0.0F;
		private float c = 0.0F;
		private float d = 0.0F;
		private float e = 0.0F;
		private float f = 0.0F;
		
		private double PositionContracts = 0.0;
		
		DateTime TimeTargetOrderFilled;
		DateTime TimeTargetOrderModified;
		
		private string oco = "";
		private int PositionQuantity = 0;
		#endregion
		
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId    = string.Empty;
		private string MachineId = string.Empty;
		bool IsDebug = false;
		string ModuleName = "RiskRewardEA";
		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			public static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			public static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22610", "22344", "27405"};//27405 is Annual Membership and 22344 is All Access
		#region ARCLicense
		#region --  Registry class  --
		public class ModifyRegistry
		{
			public int NO_KEY_DEFINED = -1;
			public int ERROR_READING_KEY = -2;
			public string ErrorStatus = string.Empty;

			private bool showError = true;
			/// <summary>
			/// A property to show or hide error messages 
			/// (default = false)
			/// </summary>
			public bool ShowError
			{
				get { return showError; }
				set	{ showError = value; }
			}

			private string subKey = "Software\\NeuroStreet\\Settings";
			/// <summary>
			/// A property to set the SubKey value
			/// (default = "SOFTWARE\\" + Application.ProductName.ToUpper())
			/// </summary>
			public string SubKey
			{
				get { return subKey; }
				set	{ subKey = value; }
			}

			private Microsoft.Win32.RegistryKey baseRegistryKey = Microsoft.Win32.Registry.CurrentUser;
			/// <summary>
			/// A property to set the BaseRegistryKey value.
			/// (default = Registry.LocalMachine)
			/// </summary>
			public Microsoft.Win32.RegistryKey BaseRegistryKey
			{
				get { return baseRegistryKey; }
				set	{ baseRegistryKey = value; }
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// To read a registry key.
			/// input: KeyName (string)
			/// output: value (string) 
			/// </summary>
			public int Read(string KeyName, NinjaTrader.NinjaScript.StrategyBase parent)
			{
				// Opening the registry key
				var rk = baseRegistryKey ;
				// Open a subKey as read-only
				var sk1 = rk.OpenSubKey(subKey);
				// If the RegistrySubKey doesn't exist -> (null)
				if ( sk1 == null )
				{
					return NO_KEY_DEFINED;
				}
				else
				{
					try 
					{
						// If the RegistryKey exists I get its value
						// or null is returned.
						return Convert.ToInt32(sk1.GetValue(KeyName));
					}
					catch (Exception e)
					{
						ErrorStatus = e.ToString();
						// AAAAAAAAAAARGH, an error!
						if(parent!=null) ShowErrorMessage(e, "Reading registry " + KeyName, parent);
						return ERROR_READING_KEY;
					}
				}
			}	

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// To write into a registry key.
			/// input: KeyName (string) , Value (object)
			/// output: true or false 
			/// </summary>
			public bool Write(string KeyName, object Value, NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					// I have to use CreateSubKey 
					// (create or open it if already exits), 
					// 'cause OpenSubKey open a subKey as read-only
					var sk1 = rk.CreateSubKey(subKey);
					// Save the value
					sk1.SetValue(KeyName, Value);

					return true;
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					//ShowErrorMessage(e, "Writing registry " + KeyName, parent);
					return false;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// To delete a registry key.
			/// input: KeyName (string)
			/// output: true or false 
			/// </summary>
			public bool DeleteKey(string KeyName, NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					var sk1 = rk.CreateSubKey(subKey);
					// If the RegistrySubKey doesn't exists -> (true)
					if ( sk1 == null )
						return true;
					else
						sk1.DeleteValue(KeyName);

					return true;
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					//ShowErrorMessage(e, "Deleting SubKey " + subKey, parent);
					return false;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// To delete a sub key and any child.
			/// input: void
			/// output: true or false 
			/// </summary>
			public bool DeleteSubKeyTree(NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					var sk1 = rk.OpenSubKey(subKey);
					// If the RegistryKey exists, I delete it
					if ( sk1 != null )
						rk.DeleteSubKeyTree(subKey);

					return true;
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					//ShowErrorMessage(e, "Deleting SubKey " + subKey, parent);
					return false;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// Retrive the count of subkeys at the current key.
			/// input: void
			/// output: number of subkeys
			/// </summary>
			public int SubKeyCount(NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					var sk1 = rk.OpenSubKey(subKey);
					// If the RegistryKey exists...
					if ( sk1 != null )
						return sk1.SubKeyCount;
					else
						return 0; 
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					//ShowErrorMessage(e, "Retriving subkeys of " + subKey, parent);
					return 0;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// Retrive the count of values in the key.
			/// input: void
			/// output: number of keys
			/// </summary>
			public int ValueCount(NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					var sk1 = rk.OpenSubKey(subKey);
					// If the RegistryKey exists...
					if ( sk1 != null )
						return sk1.ValueCount;
					else
						return 0; 
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					//ShowErrorMessage(e, "Retriving keys of " + subKey, parent);
					return 0;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/
			
			private void ShowErrorMessage(Exception e, string Title, NinjaTrader.NinjaScript.StrategyBase parent)
			{
				if (showError)
					parent.Print(e.Message);
			}
		}
		#endregion ----------------------------------------
		ModifyRegistry Reg = new ModifyRegistry();
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);
//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(bool PingRegistry){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
				search = "nscid_*.txt";
				filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
				if(filCustom!=null){
					foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
						var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
						if(elements.Length>1)
							ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
					}
				}
			}
			if(ret_custid == -1 && PingRegistry){
				//the config file doesn't exist, create one based on what is recovered from the registry
				try{
if(IsDebug) Print(" ARCCID file is getting custid from registry because of file missing");
					ret_custid = Reg.Read("custid", this);
				}catch(Exception ex2){
if(IsDebug) Print("Registry read error: "+ex2.ToString());
					if(!LicErrorMessageHandler.IsDuplicate(ex2.ToString())) LogMsg("Please run your 'ARC_LicenseActivator v1' and supply your ARCAI Contact ID number", Cbi.LogLevel.Alert);
					return -1;
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			MachineId = NinjaTrader.Cbi.License.MachineId;
if(IsDebug)Print("\n\n\nRunning ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				NewCustId = GetCustID(true);
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				NewCustId = GetCustID(true);
				UserId = NewCustId.ToString();
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");
				NewCustId = GetCustID(true);
				#region -- Read config folder for ContactID --
//				string folder = ARCConfigDirectory;
//				string search = "arccid_*.txt";
//				var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
//				if(filCustom!=null){
//					foreach(System.IO.FileInfo fi in filCustom){
//						var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
//						if(elements.Length>1)
//							NewCustId = int.Parse(elements[1]);
//					}
//				}else{//the config file doesn't exist, create one based on what is recovered from the registry
//					try{
//if(IsDebug) Print(" ARCCID file is getting custid from registry because of file missing");
//						NewCustId = Reg.Read("custid", this);
//					}catch(Exception ex2){
//if(IsDebug) Print("Registry read error: "+ex2.ToString());
//						if(!LicErrorMessageHandler.IsDuplicate(ex2.ToString())) LogMsg("Please run your 'ARC_LicenseActivator v1' and supply your ARCAI Contact ID number", Cbi.LogLevel.Alert);
//						return false;
//					}
//					if(NewCustId>0){
//						System.IO.File.WriteAllText(
//							System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+NewCustId.ToString().Trim()+".txt"),
//							NewCustId.ToString()
//						);
//					}
//				}
				#endregion
//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, NinjaTrader.Cbi.License.MachineId, ModuleName, keyString, UserId);
if(IsDebug) Print("   URL: "+URL);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+productVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).Ticks.ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}

		#endregion
	
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			
		 if(ShowInfoWindow)
		 {

     	    textToRender = "Account: "+ Account.Name  + 
			Environment.NewLine + "Balance: $" + String.Format("{0:n}",Math.Round(Account.Get(AccountItem.CashValue, Currency.UsDollar),2)) + 
			Environment.NewLine + "Stop Price:  " + Instrument.MasterInstrument.FormatPrice(SMCStop) +
			Environment.NewLine + "Entry Price: " + Instrument.MasterInstrument.FormatPrice(RREntry) +
			Environment.NewLine + "T1 Price: " + Instrument.MasterInstrument.FormatPrice(RRTarget1) +
			Environment.NewLine + "T2 Price: " + Instrument.MasterInstrument.FormatPrice(RRTarget2) +
			Environment.NewLine + "T3 Price: " + Instrument.MasterInstrument.FormatPrice(RRTarget3) +
			Environment.NewLine + "T4 Price: " + Instrument.MasterInstrument.FormatPrice(RRTarget4) +
			Environment.NewLine + "Max Risk: $" + String.Format("{0:0.00}",Math.Round(MaxRiskAmountUSD,2)) +
			Environment.NewLine + "Quantity to Trade: "  + MaxQuantityToTrade +
			Environment.NewLine + "Risk:   $" + String.Format("{0:0.00}",Math.Round(TotalRisk,2)) + 
			Environment.NewLine + "Reward: $" + String.Format("{0:0.00}",Math.Round(TotalReward,2)) + 
			Environment.NewLine + "RR Ratio: " + String.Format("{0:0.00}",Math.Round(TotalReward/TotalRisk,2));
			//Environment.NewLine + "TradedInstrument: " + TradedInstrument;
			//Environment.NewLine + "Status: " + Status +
			//Environment.NewLine + "ContractsR: " + ContractsR;
			//Environment.NewLine + "StopContracts: " + StopContracts + 
			//Environment.NewLine + "Position.Quantity: " + Position.Quantity +
			//Environment.NewLine + "StopOrderFilled: " + StopOrderFilled;
				
		
		  if(positionForInfoWindow.ToString() == "TopLeft") {a = 5.0F ; b = 0.0F ; c = 0.0F ; d = 5.0F ; e = 0.0F ; f = 0.0F ;}
		  if(positionForInfoWindow.ToString() == "TopCenter") {a = 0.0F ; b = 0.5F ; c = 0.0F ; d = 5.0F ; e = 0.0F ; f = 0.0F ;}
		  if(positionForInfoWindow.ToString() == "TopRight") {a = -15.0F ; b = 1.0F ; c = -1.0F ; d = 5.0F ; e = 0.0F ; f = 0.0F ;}
		  if(positionForInfoWindow.ToString() == "MidLeft") {a = 5.0F ; b = 0.0F ; c = 0.0F ; d = 0.0F ; e = 0.5F ; f = 0.0F ;}
		  if(positionForInfoWindow.ToString() == "MidCenter") {a = 0.0F ; b = 0.5F ; c = 0.0F ; d = 0.0F ; e = 0.33F ; f = 0.0F ;}
		  if(positionForInfoWindow.ToString() == "MidRight") {a = -15.0F ; b = 1.0F ; c = -1.0F ; d = 0.0F ; e = 0.5F ; f = 0.0F ;}
		  if(positionForInfoWindow.ToString() == "BottomLeft") {a = 5.0F ; b = 0.0F ; c = 0.0F ; d = -28.0F ; e = 1.0F ; f = -1.0F ;}
		  if(positionForInfoWindow.ToString() == "BottomCenter") {a = 0.0F ; b = 0.5F ; c = 0.0F ; d = -28.0F ; e = 1.0F ; f = -1.0F ;}
		  if(positionForInfoWindow.ToString() == "BottomRight") {a = -15.0F ; b = 1.0F ; c = -1.0F ; d = -28.0F ; e = 1.0F ; f = -1.0F ;}
		  
		  
		  #region CreateText
		  SharpDX.DirectWrite.TextFormat textFormat = InfoWindowFont.ToDirectWriteTextFormat();
		  SharpDX.DirectWrite.TextLayout textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory,
          textToRender, textFormat, 2000, 2000);
		  
		  SharpDX.Vector2 startPoint = new SharpDX.Vector2(a + b*ChartPanel.W + c*textLayout.Metrics.Width+3, d + e*ChartPanel.H + f*textLayout.Metrics.Height+2);
		  
		  
		  SolidColorBrush TextBrush = InfoWindowTextColor as SolidColorBrush;
		  SharpDX.Color4 InfoWindowTextColor4 = new SharpDX.Color4(TextBrush.Color.R, TextBrush.Color.G, TextBrush.Color.B, TextBrush.Color.A);
		
          #endregion
				
		  #region CreateSolidBox
		  SolidColorBrush sBrush = InfoWindowBackgroundColor as SolidColorBrush;
		  SharpDX.Color4 InfoWindowBackgroundColor4 = new SharpDX.Color4(sBrush.Color.R, sBrush.Color.G, sBrush.Color.B, sBrush.Color.A);
		
			
		  using (SharpDX.Direct2D1.SolidColorBrush dxBrush = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, InfoWindowBackgroundColor4))
		  {
		    dxBrush.Opacity = (float)(InfoWindowOpacity/100.0);
			RenderTarget.FillRectangle(new SharpDX.RectangleF(a + b*ChartPanel.W + c*textLayout.Metrics.Width, d + e*ChartPanel.H + f*textLayout.Metrics.Height, textLayout.Metrics.Width + 10, textLayout.Metrics.Height + 5), dxBrush);
			
		  }
		  #endregion
		  
		  #region CreateBorderBox
		  SolidColorBrush bBrush = InfoWindowBorderColor as SolidColorBrush;
		  SharpDX.Color4 InfoWindowBorderColor4 = new SharpDX.Color4(bBrush.Color.R, bBrush.Color.G, bBrush.Color.B, bBrush.Color.A);
			
		  using (SharpDX.Direct2D1.SolidColorBrush dxBrush2 = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, InfoWindowBorderColor4))
		  {
		    
			RenderTarget.DrawRectangle(new SharpDX.RectangleF(a + b*ChartPanel.W + c*textLayout.Metrics.Width, d + e*ChartPanel.H + f*textLayout.Metrics.Height, textLayout.Metrics.Width + 10, textLayout.Metrics.Height + 5), dxBrush2);
			
		  }
		  #endregion
		  
		 
		  using (SharpDX.Direct2D1.SolidColorBrush dxBrush3 = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, InfoWindowTextColor4))
		  {
			  
		    RenderTarget.DrawTextLayout(startPoint, textLayout, dxBrush3);
			  
		  }
		  
		  textLayout.Dispose();
		  textFormat.Dispose();
		 
		  
		 }
		 
		  
		}

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"ARC RISKREWARD EA";
				Name										= "ARC_RiskReward EA";
				Calculate									= Calculate.OnEachTick;
				EntriesPerDirection							= 4;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= false;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				//RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 30;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
		        ErrorHandling_IgnoreAllErrors               = false;
			    ErrorHandling_StopCancelClose               = false;
				ErrorHandling_StopCancelCloseIgnoreRejects  = true;
				IsUnmanaged = true;

		

				ShowInfoWindow = true;
				
				PrintOrdersOutputWindow = false;
				
				InfoWindowBackgroundColor = Brushes.White;
				InfoWindowTextColor = Brushes.Black;
				InfoWindowBorderColor = Brushes.Magenta;
				
				EnabledButtonStrategyControlBoxBackgroundColor = Brushes.Lime;
				EnabledButtonStrategyControlBoxTextColor = Brushes.Blue;
				DisabledButtonStrategyControlBoxBackgroundColor = Brushes.Black;
				DisabledButtonStrategyControlBoxTextColor = Brushes.White;
				EnabledButtonStrategyControlBoxBorderColor = Brushes.Lime;
				DisabledButtonStrategyControlBoxBorderColor = Brushes.White;
				
				EntryWarningWindowTextColorForLongs = Brushes.Black;
				EntryWarningWindowTextColorForShorts = Brushes.White;
				EntryWarningWindowBackgroundColorForLongs = Brushes.Lime;
				EntryWarningWindowBackgroundColorForShorts = Brushes.Red;
				EntryWarningWindowBorderColorForLongs = Brushes.Lime;
				EntryWarningWindowBorderColorForShorts = Brushes.Red;
        
		
				RRWarningWindowTextColor = Brushes.White;
				RRWarningWindowBackgroundColor = Brushes.Red;
				RRWarningWindowBorderColor = Brushes.Red;
			
				path = NinjaTrader.Core.Globals.UserDataDir + "ARCRiskRewardEALog.txt";
			
				
				ContractsT1 = 0;
				ContractsT2 = 0;
				ContractsT3 = 0;
				ContractsT4 = 0;
				
			
				TradeT1 = false;
				TradeT2 = false;
				TradeT3 = false;
				TradeT4 = false;
							
				TicksDiffStop = 0;
				
				UserInputMaxRiskAmountUSD = 200.0;
				MaxRiskPercentage = 1.0;

				UseBE = false;
				
				BEOffset = 1;
				
				infoWindowFont = new Gui.Tools.SimpleFont("Consolas", 14);
				messageTextFont = new Gui.Tools.SimpleFont("Arial",20) { Size = 20, Bold = true };
				buttonStrategyControlBoxFont = new Gui.Tools.SimpleFont("Arial",15);
				rRToolWarningFont = new Gui.Tools.SimpleFont("Arial",20) { Size = 20, Bold = true };
				
				
				WriteEntryOnLog = false;
				
				InfoWindowOpacity = 90.0;
		
			}
			
			else if (State == State.Configure)
			{
				if(ErrorHandling_IgnoreAllErrors) RealtimeErrorHandling = RealtimeErrorHandling.IgnoreAllErrors;
				if(ErrorHandling_StopCancelClose) RealtimeErrorHandling = RealtimeErrorHandling.StopCancelClose;
				if(ErrorHandling_StopCancelCloseIgnoreRejects) RealtimeErrorHandling = RealtimeErrorHandling.StopCancelCloseIgnoreRejects;
				Account.PositionUpdate += OnPositionUpdate;
				Account.OrderUpdate += OnOrderUpdate;
				Account.ExecutionUpdate += OnExecutionUpdate;
				Account.AccountItemUpdate += OnAccountItemUpdate;
				#region DoLicense call
				IsDebug = System.IO.File.Exists("c:\\222222222222.txt");
#if DoLicense
				if(Account.Name != "Backtest")
				{
					if(!LicenseChecked){
						ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
						LicenseChecked = true;
					}
					IsVisible = true;
				}
				else
					ValidLicense = true;
#endif
				#endregion
			}
			
			else if (State == State.DataLoaded)
			{	
				
			    
			}
			
			
			
			
			else if(State == State.Terminated)	
			{
				if (sw != null)
				{
					sw.Close();
					sw.Dispose();
					sw = null;
				}
				
				
				 if(Account != null) 
				 {
					 Account.PositionUpdate -= OnPositionUpdate;
					 Account.OrderUpdate -= OnOrderUpdate;
					 Account.ExecutionUpdate -= OnExecutionUpdate;
					 Account.AccountItemUpdate -= OnAccountItemUpdate;
				 }
				
				 if (ChartControl == null)
				        return;
				 
				
				    ChartControl.Dispatcher.InvokeAsync((() =>
				    {
						

						if (myLeftGrid != null)
				        {
						  if (myAutotraderButton != null)
				          {
				              myLeftGrid.Children.Remove(myAutotraderButton);
				              myAutotraderButton.Click -= OnMyButtonClick;
				              myAutotraderButton = null;
				          }
						  
						  
						  if (myT1Button != null)
				          {
				              myLeftGrid.Children.Remove(myT1Button);
				              myT1Button.Click -= OnMyButtonClick;
				              myT1Button = null;
				          }
						  
						  
						  if (myT2Button != null)
				          {
				              myLeftGrid.Children.Remove(myT2Button);
				              myT2Button.Click -= OnMyButtonClick;
				              myT2Button = null;
				          }
						  
						  if (myT3Button != null)
				          {
				              myLeftGrid.Children.Remove(myT3Button);
				              myT3Button.Click -= OnMyButtonClick;
				              myT3Button = null;
				          }
						  
						  if (myT4Button != null)
				          {
				              myLeftGrid.Children.Remove(myT4Button);
				              myT4Button.Click -= OnMyButtonClick;
				              myT4Button = null;
				          }
						  
						  if (myExitButton != null)
				          {
				              myLeftGrid.Children.Remove(myExitButton);
				              myExitButton.Click -= OnMyButtonClick;
				              myExitButton = null;
				          }
						  
						  if (myBEButton != null)
				          {
				              myLeftGrid.Children.Remove(myBEButton);
				              myBEButton.Click -= OnMyButtonClick;
				              myBEButton = null;
				          }
						  
						   if (myMMModeButton != null)
				          {
				              myLeftGrid.Children.Remove(myMMModeButton);
				              myMMModeButton.Click -= OnMyButtonClick;
				              myMMModeButton = null;
				          }
						  
							
						}
				    }));
			   }
		}
			
		public void OnMyButtonClick(object sender, RoutedEventArgs rea)
		{
		  System.Windows.Controls.Button button = sender as System.Windows.Controls.Button;
		  if (button != null)
		  {
			  
	
			if(button.Name == "MyAutotraderButton")
			{
				
				if(TradeMode == 0) TradeMode = 1;
				else if(TradeMode == 1) TradeMode = 0;
				
							
				if(TradeMode == 0) 
				{
					button.Content = "AUTOTRADER OFF"; button.Foreground = DisabledButtonStrategyControlBoxTextColor; button.Background = DisabledButtonStrategyControlBoxBackgroundColor;
					

					if(WriteEntryOnLog) WriteLog(DateTime.Now.ToString() + "/AUTOTRADER BUTTON HIT TURNED OFF "+TradedInstrument);
				}
				if(TradeMode == 1) 
				{
					button.Content = "AUTOTRADER ON"; button.Foreground = EnabledButtonStrategyControlBoxTextColor; button.Background = EnabledButtonStrategyControlBoxBackgroundColor;
					
					if(WriteEntryOnLog) WriteLog(DateTime.Now.ToString() + "/AUTOTRADER BUTTON HIT TURNED ON "+TradedInstrument);
				}
				
			}
			
		
			
			if(button.Name == "MyT1Button")
			{
				
				if(TradeT1 == true) TradeT1 = false;
				else if (TradeT1 == false) TradeT1 = true;
				
				
				if(TradeT1 == true) {button.Content = "T1 ON Q: " + ContractsT1; button.Foreground = EnabledButtonStrategyControlBoxTextColor; button.Background = EnabledButtonStrategyControlBoxBackgroundColor;
					}
				if(TradeT1 == false) {button.Content = "T1 OFF Q: " + ContractsT1; button.Foreground = DisabledButtonStrategyControlBoxTextColor; button.Background = DisabledButtonStrategyControlBoxBackgroundColor;
					}
			}
			
			if(button.Name == "MyT2Button")
			{
				
				if(TradeT2 == true) TradeT2 = false;
				else if (TradeT2 == false) TradeT2 = true;
				
				
				if(TradeT2 == true) {button.Content = "T2 ON Q: " + ContractsT2; button.Foreground = EnabledButtonStrategyControlBoxTextColor; button.Background = EnabledButtonStrategyControlBoxBackgroundColor;
					}
				if(TradeT2 == false) {button.Content = "T2 OFF Q: " + ContractsT2; button.Foreground = DisabledButtonStrategyControlBoxTextColor; button.Background = DisabledButtonStrategyControlBoxBackgroundColor;
					}
			}

			if(button.Name == "MyT3Button")
			{
				
				
				if(TradeT3== true) TradeT3= false;
				else if (TradeT3== false) TradeT3= true;
				
				
				if(TradeT3== true) {button.Content = "T3 ON Q: " + ContractsT3; button.Foreground = EnabledButtonStrategyControlBoxTextColor; button.Background = EnabledButtonStrategyControlBoxBackgroundColor;
					}
				if(TradeT3== false) {button.Content = "T3 OFF Q: " + ContractsT3; button.Foreground = DisabledButtonStrategyControlBoxTextColor; button.Background = DisabledButtonStrategyControlBoxBackgroundColor;
					}
			}
			
			if(button.Name == "MyT4Button")
			{
				
				if(TradeT4 == true) TradeT4 = false;
				else if (TradeT4 == false) TradeT4 = true;
				
				
				if(TradeT4 == true) {button.Content = "T4 ON Q: " + ContractsT4; button.Foreground = EnabledButtonStrategyControlBoxTextColor; button.Background = EnabledButtonStrategyControlBoxBackgroundColor;
					}
				if(TradeT4 == false) {button.Content = "T4 OFF Q: " + ContractsT4; button.Foreground = DisabledButtonStrategyControlBoxTextColor; button.Background = DisabledButtonStrategyControlBoxBackgroundColor;
					}
			}
			

			
			if(button.Name == "MyExitButton")
			{
				

					
					if(Status == "Long") 
					{
						foreach(Order order in Account.Orders)
						{
							if((order.OrderState == OrderState.Accepted || order.OrderState == OrderState.Working) && order.Instrument.ToString() == TradedInstrument)
							{
								Account.CancelAllOrders(order.Instrument);
							}
						}
						SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Market, PositionQuantity, 0, 0, "", "Exit Long Manual");
						TimeManualExitClicked = DateTime.Now;
						ManualExitClicked = true;
						if(PrintOrdersOutputWindow) Print("ARC_RiskRewardEA Manual EXIT Long Button Pressed at: " + DateTime.Now.ToString());
						if(WriteEntryOnLog) WriteLog(DateTime.Now.ToString() + "/EXIT Button Pressed to close long "+TradedInstrument);
						
					    
					}
					if(Status == "Short") 
					{
						foreach(Order order in Account.Orders)
						{
							if((order.OrderState == OrderState.Accepted || order.OrderState == OrderState.Working) && order.Instrument.ToString() == TradedInstrument)
							{
								Account.CancelAllOrders(order.Instrument);
							}
						}
						SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Market, PositionQuantity, 0, 0, "", "Exit Short Manual");
						TimeManualExitClicked = DateTime.Now;
						ManualExitClicked = true;
						if(PrintOrdersOutputWindow) Print("ARC_RiskRewardEA Manual EXIT Button Pressed at: " + DateTime.Now.ToString());
						if(WriteEntryOnLog) WriteLog(DateTime.Now.ToString() + "/EXIT Button Pressed to close short "+TradedInstrument);
						
					}
					
					TradeMode = 0;
					
					
				
			}
			
			if(button.Name == "MyBEButton")
			{
				
				if(UseBE == true) UseBE = false;
				else if (UseBE == false) UseBE = true;
				
				if(TargetForBE.ToString() == "T1") ContentForBEButtonON = "BE T1 ON Offset: " + BEOffset;
				if(TargetForBE.ToString() == "T2") ContentForBEButtonON = "BE T2 ON Offset: " + BEOffset;
				if(TargetForBE.ToString() == "T3") ContentForBEButtonON = "BE T3 ON Offset: " + BEOffset;
				if(TargetForBE.ToString() == "T4") ContentForBEButtonON = "BE T4 ON Offset: " + BEOffset;
				
				if(TargetForBE.ToString() == "T1") ContentForBEButtonOFF = "BE T1 OFF";
				if(TargetForBE.ToString() == "T2") ContentForBEButtonOFF = "BE T2 OFF";
				if(TargetForBE.ToString() == "T3") ContentForBEButtonOFF = "BE T3 OFF";
				if(TargetForBE.ToString() == "T4") ContentForBEButtonOFF = "BE T4 OFF";
				
				
				if(UseBE == true) {button.Content = ContentForBEButtonON; button.Foreground = EnabledButtonStrategyControlBoxTextColor; button.Background = EnabledButtonStrategyControlBoxBackgroundColor;
					}
				if(UseBE == false) {button.Content = ContentForBEButtonOFF; button.Foreground = DisabledButtonStrategyControlBoxTextColor; button.Background = DisabledButtonStrategyControlBoxBackgroundColor;
					}
			}
			
			if(button.Name == "MyMMModeButton")
			{
				
				if(calcType.ToString() == "Dollar_Value") calcType = CalcTypes.Percentage_Account_Balance;
				else if(calcType.ToString() == "Percentage_Account_Balance") calcType = CalcTypes.Static_Lotsize;
				else if(calcType.ToString() == "Static_Lotsize") calcType = CalcTypes.Dollar_Value;
			
				if(calcType.ToString() == "Dollar_Value") {button.Content = "Risk:DollarValue:   $" + UserInputMaxRiskAmountUSD; button.Foreground = EnabledButtonStrategyControlBoxTextColor; button.Background = EnabledButtonStrategyControlBoxBackgroundColor;
					}
				if(calcType.ToString() == "Percentage_Account_Balance") {button.Content = "Risk:%AcctBal:   " + Math.Round(MaxRiskPercentage,1) + " %"; button.Foreground = EnabledButtonStrategyControlBoxTextColor; button.Background = EnabledButtonStrategyControlBoxBackgroundColor;
					}
				if(calcType.ToString() == "Static_Lotsize") {button.Content = "Risk:StaticLotsize: " + MaxQuantityToTrade; button.Foreground = EnabledButtonStrategyControlBoxTextColor; button.Background = EnabledButtonStrategyControlBoxBackgroundColor;
					}
				
			}
			
					  
		  
		  }
		}
		
		public void WriteLog(string TextToWrite)
		{
			sw = File.AppendText(path);
			sw.WriteLine(TextToWrite);
			sw.Close();
		}
		
		private void OnPositionUpdate(object sender, PositionEventArgs e)
	    {
			if(e.MarketPosition == MarketPosition.Flat && e.Position.Instrument.ToString() == TradedInstrument) {Status = "Flat"; PositionQuantity = 0;}
			if(e.MarketPosition == MarketPosition.Long && e.Position.Instrument.ToString() == TradedInstrument) Status = "Long";
			if(e.MarketPosition == MarketPosition.Short && e.Position.Instrument.ToString() == TradedInstrument) Status = "Short";
			PositionQuantity = e.Quantity;
			//NewSignalTime = DateTime.Now;
			//NewSignal = true;
		}
		
		private void OnExecutionUpdate(object sender, ExecutionEventArgs e)
		{
			
		  if ((e.Execution.Order.Name == "Short-T1-Target" || e.Execution.Order.Name == "Long-T1-Target")
			  && e.Execution.Order.OrderState == OrderState.Filled 
			  && TargetHitT1 == false)
		      
		  {
			  if(PrintOrdersOutputWindow) Print("ARC_RiskRewardEA Profit Target T1 Order Filled at: " + DateTime.Now.ToString());
			  TimeTargetOrderFilled = DateTime.Now;
			  TargetHitT1 = true;
		  }
		  
		  if ((e.Execution.Order.Name == "Short-T2-Target" || e.Execution.Order.Name == "Long-T2-Target")
			  && e.Execution.Order.OrderState == OrderState.Filled 
			  && TargetHitT2 == false)
		      
		  {
			  if(PrintOrdersOutputWindow) Print("ARC_RiskRewardEA Profit Target T2 Order Filled at: " + DateTime.Now.ToString());
			  TimeTargetOrderFilled = DateTime.Now;
			  TargetHitT2 = true;
		  }
		  
		  if ((e.Execution.Order.Name == "Short-T3-Target" || e.Execution.Order.Name == "Long-T3-Target")
			  && e.Execution.Order.OrderState == OrderState.Filled 
			  && TargetHitT3 == false)
		      
		  {
			  if(PrintOrdersOutputWindow) Print("ARC_RiskRewardEA Profit Target T3 Order Filled at: " + DateTime.Now.ToString());
			  TimeTargetOrderFilled = DateTime.Now;
			  TargetHitT3 = true;
		  }
		  
		  if ((e.Execution.Order.Name == "Short-T4-Target" || e.Execution.Order.Name == "Long-T4-Target")
			  && e.Execution.Order.OrderState == OrderState.Filled 
			  && TargetHitT4 == false)
		      
		  {
			  if(PrintOrdersOutputWindow) Print("ARC_RiskRewardEA Profit Target T4 Order Filled at: " + DateTime.Now.ToString());
			  TimeTargetOrderFilled = DateTime.Now;
			  TargetHitT4 = true;
		  }
		  
		   
		  
		 
	    }
		
		private void OnOrderUpdate(object sender, OrderEventArgs e)
	    {
			
	    }
		
		private void OnAccountItemUpdate(object sender, AccountItemEventArgs e)
	    {	
			
		/*
         if(e.AccountItem.ToString() == "RealizedProfitLoss")
		 {
		  TotalRealizedPnL = e.Value;
		 
		 }
	  
		 
	 	 if(e.AccountItem.ToString() == "UnrealizedProfitLoss")
		 {
		  TotalUnrealizedPnL = e.Value;
		 
		 }
		 */
	 
	    }
		
		public string Truncate(string value, int maxLength)
		{
		    if (!string.IsNullOrEmpty(value) && value.Length > maxLength)
		    {
		        return value.Substring(0, maxLength);
		    }

		    return value;
		}
			
		public void CreateButtons()
		{
			 ChartControl.Dispatcher.InvokeAsync((() =>
				    {
				        
				        if (UserControlCollection.Contains(myLeftGrid))
				          return;

						if(positionForStrategyControls.ToString() == "TopLeft")
						{
						myLeftGrid = new System.Windows.Controls.Grid
				        {
				          Name = "MyLeftGrid",
				          HorizontalAlignment = HorizontalAlignment.Left,
				          VerticalAlignment = VerticalAlignment.Top,
				        };
						}
						
						if(positionForStrategyControls.ToString() == "TopCenter")
						{
						myLeftGrid = new System.Windows.Controls.Grid
				        {
				          Name = "MyLeftGrid",
				          HorizontalAlignment = HorizontalAlignment.Center,
				          VerticalAlignment = VerticalAlignment.Top,
				        };
						}
						
						if(positionForStrategyControls.ToString() == "TopRight")
						{
						myLeftGrid = new System.Windows.Controls.Grid
				        {
				          Name = "MyLeftGrid",
				          HorizontalAlignment = HorizontalAlignment.Right,
				          VerticalAlignment = VerticalAlignment.Top,
				        };
						}
						if(positionForStrategyControls.ToString() == "MidLeft")
						{
						myLeftGrid = new System.Windows.Controls.Grid
				        {
				          Name = "MyLeftGrid",
				          HorizontalAlignment = HorizontalAlignment.Left,
				          VerticalAlignment = VerticalAlignment.Center,
				        };
						}
						if(positionForStrategyControls.ToString() == "MidCenter")
						{
						myLeftGrid = new System.Windows.Controls.Grid
				        {
				          Name = "MyLeftGrid",
				          HorizontalAlignment = HorizontalAlignment.Center,
				          VerticalAlignment = VerticalAlignment.Center,
				        };
						}
						if(positionForStrategyControls.ToString() == "MidRight")
						{
						myLeftGrid = new System.Windows.Controls.Grid
				        {
				          Name = "MyLeftGrid",
				          HorizontalAlignment = HorizontalAlignment.Right,
				          VerticalAlignment = VerticalAlignment.Center,
				        };
						}
						if(positionForStrategyControls.ToString() == "BottomLeft")
						{
						myLeftGrid = new System.Windows.Controls.Grid
				        {
				          Name = "MyLeftGrid",
				          HorizontalAlignment = HorizontalAlignment.Left,
				          VerticalAlignment = VerticalAlignment.Bottom,
				        };
						}
						if(positionForStrategyControls.ToString() == "BottomCenter")
						{
						myLeftGrid = new System.Windows.Controls.Grid
				        {
				          Name = "MyLeftGrid",
				          HorizontalAlignment = HorizontalAlignment.Center,
				          VerticalAlignment = VerticalAlignment.Bottom,
				        };
						}
						if(positionForStrategyControls.ToString() == "BottomRight")
						{
						myLeftGrid = new System.Windows.Controls.Grid
				        {
				          Name = "MyLeftGrid",
				          HorizontalAlignment = HorizontalAlignment.Right,
				          VerticalAlignment = VerticalAlignment.Bottom,
				        };
						}
						
						
	
			

						
						System.Windows.Controls.RowDefinition row1LeftGrid = new System.Windows.Controls.RowDefinition();
						System.Windows.Controls.RowDefinition row2LeftGrid = new System.Windows.Controls.RowDefinition();
						System.Windows.Controls.RowDefinition row3LeftGrid = new System.Windows.Controls.RowDefinition();
						System.Windows.Controls.RowDefinition row4LeftGrid = new System.Windows.Controls.RowDefinition();
						System.Windows.Controls.RowDefinition row5LeftGrid = new System.Windows.Controls.RowDefinition();
						System.Windows.Controls.RowDefinition row6LeftGrid = new System.Windows.Controls.RowDefinition();
						System.Windows.Controls.RowDefinition row7LeftGrid = new System.Windows.Controls.RowDefinition();
						System.Windows.Controls.RowDefinition row8LeftGrid = new System.Windows.Controls.RowDefinition();
			
				   
						
						myLeftGrid.RowDefinitions.Add(row1LeftGrid);
						myLeftGrid.RowDefinitions.Add(row2LeftGrid);
						myLeftGrid.RowDefinitions.Add(row3LeftGrid);
						myLeftGrid.RowDefinitions.Add(row4LeftGrid);
						myLeftGrid.RowDefinitions.Add(row5LeftGrid);
						myLeftGrid.RowDefinitions.Add(row6LeftGrid);
						myLeftGrid.RowDefinitions.Add(row7LeftGrid);
						myLeftGrid.RowDefinitions.Add(row8LeftGrid);
		
				

				       
						
						if(TradeMode == 0)
						{
							myAutotraderButton = new System.Windows.Controls.Button
					        {
					          Name = "MyAutotraderButton",
					          Content = "AUTOTRADER OFF",
					          Foreground = DisabledButtonStrategyControlBoxTextColor,
					          Background = DisabledButtonStrategyControlBoxBackgroundColor,
							  FontFamily = ButtonStrategyControlBoxFont.Family,
					          FontSize = ButtonStrategyControlBoxFont.Size,
							  BorderBrush = DisabledButtonStrategyControlBoxBorderColor
							  
					        };
						}
						
						if(TradeMode == 1)
						{
							myAutotraderButton = new System.Windows.Controls.Button
					        {
					          Name = "MyAutotraderButton",
					          Content = "AUTOTRADER ON",
					          Foreground = EnabledButtonStrategyControlBoxTextColor,
					          Background = EnabledButtonStrategyControlBoxBackgroundColor,
							  FontFamily = ButtonStrategyControlBoxFont.Family,
					          FontSize = ButtonStrategyControlBoxFont.Size,
							  BorderBrush = EnabledButtonStrategyControlBoxBorderColor
					        };
						}
						
						
						
						myExitButton = new System.Windows.Controls.Button
				        {
				          Name = "MyExitButton",
				          Content = "EXIT",
				          Foreground = DisabledButtonStrategyControlBoxTextColor,
					      Background = DisabledButtonStrategyControlBoxBackgroundColor,
						  FontFamily = ButtonStrategyControlBoxFont.Family,
					      FontSize = ButtonStrategyControlBoxFont.Size,
						  BorderBrush = DisabledButtonStrategyControlBoxBorderColor
				        };
						
						if(TradeT1 == true)
						{
							myT1Button= new System.Windows.Controls.Button
					        {
					          Name = "MyT1Button",
					          Content = "T1 ON Q: " + ContractsT1,
					          Foreground = EnabledButtonStrategyControlBoxTextColor,
					          Background = EnabledButtonStrategyControlBoxBackgroundColor,
							  FontFamily = ButtonStrategyControlBoxFont.Family,
					          FontSize = ButtonStrategyControlBoxFont.Size,
							  BorderBrush = EnabledButtonStrategyControlBoxBorderColor
					        };
						}
						
						if(TradeT1 == false)
						{
							myT1Button= new System.Windows.Controls.Button
					        {
					          Name = "MyT1Button",
					          Content = "T1 OFF Q: " + ContractsT1,
					          Foreground = DisabledButtonStrategyControlBoxTextColor,
					          Background = DisabledButtonStrategyControlBoxBackgroundColor,
							  FontFamily = ButtonStrategyControlBoxFont.Family,
					          FontSize = ButtonStrategyControlBoxFont.Size,
							  BorderBrush = DisabledButtonStrategyControlBoxBorderColor
							
					        };
						}
						
						if(TradeT2 == true)
						{
							myT2Button= new System.Windows.Controls.Button
					        {
					          Name = "MyT2Button",
					          Content = "T2 ON Q: " + ContractsT2,
					          Foreground = EnabledButtonStrategyControlBoxTextColor,
					          Background = EnabledButtonStrategyControlBoxBackgroundColor,
							  FontFamily = ButtonStrategyControlBoxFont.Family,
					          FontSize = ButtonStrategyControlBoxFont.Size,
							  BorderBrush = EnabledButtonStrategyControlBoxBorderColor
					        };
						}
						
						if(TradeT2 == false)
						{
							myT2Button= new System.Windows.Controls.Button
					        {
					          Name = "MyT2Button",
					          Content = "T2 OFF Q: " + ContractsT2,
					          Foreground = DisabledButtonStrategyControlBoxTextColor,
					          Background = DisabledButtonStrategyControlBoxBackgroundColor,
							  FontFamily = ButtonStrategyControlBoxFont.Family,
					          FontSize = ButtonStrategyControlBoxFont.Size,
							  BorderBrush = DisabledButtonStrategyControlBoxBorderColor
					        };
						}
						
					
						if(TradeT3== true)
						{
							myT3Button = new System.Windows.Controls.Button
					        {
					          Name = "MyT3Button",
					          Content = "T3 ON Q: " + ContractsT3,
					          Foreground = EnabledButtonStrategyControlBoxTextColor,
					          Background = EnabledButtonStrategyControlBoxBackgroundColor,
							  FontFamily = ButtonStrategyControlBoxFont.Family,
					          FontSize = ButtonStrategyControlBoxFont.Size,
							  BorderBrush = EnabledButtonStrategyControlBoxBorderColor
					        };
						}
						
						if(TradeT3== false)
						{
							myT3Button = new System.Windows.Controls.Button
					        {
					          Name = "MyT3Button",
					          Content = "T3 OFF Q: " + ContractsT3,
					          Foreground = DisabledButtonStrategyControlBoxTextColor,
					          Background = DisabledButtonStrategyControlBoxBackgroundColor,
							  FontFamily = ButtonStrategyControlBoxFont.Family,
					          FontSize = ButtonStrategyControlBoxFont.Size,
							  BorderBrush = DisabledButtonStrategyControlBoxBorderColor
					        };
						}
						
						if(TradeT4 == true)
						{
							myT4Button= new System.Windows.Controls.Button
					        {
					          Name = "MyT4Button",
					          Content = "T4 ON Q: " + ContractsT4,
					          Foreground = EnabledButtonStrategyControlBoxTextColor,
					          Background = EnabledButtonStrategyControlBoxBackgroundColor,
							  FontFamily = ButtonStrategyControlBoxFont.Family,
					          FontSize = ButtonStrategyControlBoxFont.Size,
							  BorderBrush = EnabledButtonStrategyControlBoxBorderColor
					        };
						}
						
						if(TradeT4 == false)
						{
							myT4Button = new System.Windows.Controls.Button
					        {
					          Name = "MyT4Button",
					          Content = "T4 OFF Q: " + ContractsT4,
					          Foreground = DisabledButtonStrategyControlBoxTextColor,
					          Background = DisabledButtonStrategyControlBoxBackgroundColor,
							  FontFamily = ButtonStrategyControlBoxFont.Family,
					          FontSize = ButtonStrategyControlBoxFont.Size,
							  BorderBrush = DisabledButtonStrategyControlBoxBorderColor
					        };
						}
						
						if(UseBE == true)
						{
							if(TargetForBE.ToString() == "T1") ContentForBEButtonON = "BE T1 ON Offset: " + BEOffset;
							if(TargetForBE.ToString() == "T2") ContentForBEButtonON = "BE T2 ON Offset: " + BEOffset;
							if(TargetForBE.ToString() == "T3") ContentForBEButtonON = "BE T3 ON Offset: " + BEOffset;
							if(TargetForBE.ToString() == "T4") ContentForBEButtonON = "BE T4 ON Offset: " + BEOffset;
							
							myBEButton= new System.Windows.Controls.Button
					        {
					          Name = "MyBEButton",
					          Content = ContentForBEButtonON,
					          Foreground = EnabledButtonStrategyControlBoxTextColor,
					          Background = EnabledButtonStrategyControlBoxBackgroundColor,
							  FontFamily = ButtonStrategyControlBoxFont.Family,
					          FontSize = ButtonStrategyControlBoxFont.Size,
							  BorderBrush = EnabledButtonStrategyControlBoxBorderColor
					        };
							
							
						}
						
						if(UseBE == false)
						{
							if(TargetForBE.ToString() == "T1") ContentForBEButtonOFF = "BE T1 OFF";
							if(TargetForBE.ToString() == "T2") ContentForBEButtonOFF = "BE T2 OFF";
							if(TargetForBE.ToString() == "T3") ContentForBEButtonOFF = "BE T3 OFF";
							if(TargetForBE.ToString() == "T4") ContentForBEButtonOFF = "BE T4 OFF";
							
							myBEButton = new System.Windows.Controls.Button
					        {
					          Name = "MyBEButton",
					          Content = ContentForBEButtonOFF,
					          Foreground = DisabledButtonStrategyControlBoxTextColor,
					          Background = DisabledButtonStrategyControlBoxBackgroundColor,
							  FontFamily = ButtonStrategyControlBoxFont.Family,
					          FontSize = ButtonStrategyControlBoxFont.Size,
							  BorderBrush = DisabledButtonStrategyControlBoxBorderColor
					        };
							
						}
						
						if(calcType.ToString() == "Static_Lotsize")
						{
							myMMModeButton = new System.Windows.Controls.Button
					        {
					          Name = "MyMMModeButton",
					          Content = "Risk:StaticLotsize: "+ MaxQuantityToTrade,
					          Foreground = EnabledButtonStrategyControlBoxTextColor,
					          Background = EnabledButtonStrategyControlBoxBackgroundColor,
							  FontFamily = ButtonStrategyControlBoxFont.Family,
					          FontSize = ButtonStrategyControlBoxFont.Size,
							  BorderBrush = EnabledButtonStrategyControlBoxBorderColor
					        };
						}
						
						if(calcType.ToString() == "Dollar_Value")
						{
							myMMModeButton = new System.Windows.Controls.Button
					        {
					          Name = "MyMMModeButton",
					          Content = "Risk:DollarValue:   $" + UserInputMaxRiskAmountUSD,
					          Foreground = EnabledButtonStrategyControlBoxTextColor,
					          Background = EnabledButtonStrategyControlBoxBackgroundColor,
							  FontFamily = ButtonStrategyControlBoxFont.Family,
					          FontSize = ButtonStrategyControlBoxFont.Size,
							  BorderBrush = EnabledButtonStrategyControlBoxBorderColor
					        };
						}
						
						if(calcType.ToString() == "Percentage_Account_Balance")
						{
							myMMModeButton = new System.Windows.Controls.Button
					        {
					          Name = "MyMMModeButton",
					          Content = "Risk:%AcctBal:   " + Math.Round(MaxRiskPercentage,1) + " %",
					          Foreground = EnabledButtonStrategyControlBoxTextColor,
					          Background = EnabledButtonStrategyControlBoxBackgroundColor,
							  FontFamily = ButtonStrategyControlBoxFont.Family,
					          FontSize = ButtonStrategyControlBoxFont.Size,
							  BorderBrush = EnabledButtonStrategyControlBoxBorderColor
					        };
						}
						


						myExitButton.Click += OnMyButtonClick;
						myAutotraderButton.Click += OnMyButtonClick;
						myT1Button.Click += OnMyButtonClick;
						myT2Button.Click += OnMyButtonClick;
						myT4Button.Click += OnMyButtonClick;
						myT3Button.Click += OnMyButtonClick;
						myBEButton.Click += OnMyButtonClick;
						myMMModeButton.Click += OnMyButtonClick;
						
					
		
				        System.Windows.Controls.Grid.SetRow(myAutotraderButton, 0);
						System.Windows.Controls.Grid.SetRow(myExitButton, 1);
						System.Windows.Controls.Grid.SetRow(myT1Button, 2);
						System.Windows.Controls.Grid.SetRow(myT2Button, 3);
						System.Windows.Controls.Grid.SetRow(myT3Button, 4);
						System.Windows.Controls.Grid.SetRow(myT4Button, 5);
						System.Windows.Controls.Grid.SetRow(myBEButton, 6);
						System.Windows.Controls.Grid.SetRow(myMMModeButton, 7);
						

				     
						myLeftGrid.Children.Add(myExitButton);
						myLeftGrid.Children.Add(myAutotraderButton);
						myLeftGrid.Children.Add(myT1Button);
						myLeftGrid.Children.Add(myT2Button);
						myLeftGrid.Children.Add(myT3Button);
						myLeftGrid.Children.Add(myT4Button);
						myLeftGrid.Children.Add(myBEButton);
						myLeftGrid.Children.Add(myMMModeButton);
						
			
						UserControlCollection.Add(myLeftGrid);
						
						
						
						myBEButton.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e)
						{
							if(e.Delta > 0)
							{
								if(UseBE) BEOffset++;
								if(TargetForBE.ToString() == "T1")
								{
								if(UseBE == true) {myBEButton.Content = "BE T1 ON Offset: " + BEOffset; myBEButton.Foreground = EnabledButtonStrategyControlBoxTextColor; myBEButton.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(UseBE == false) {myBEButton.Content = "BE T1 OFF"; myBEButton.Foreground = DisabledButtonStrategyControlBoxTextColor; myBEButton.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
								}
								if(TargetForBE.ToString() == "T2")
								{
								if(UseBE == true) {myBEButton.Content = "BE T2 ON Offset: " + BEOffset; myBEButton.Foreground = EnabledButtonStrategyControlBoxTextColor; myBEButton.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(UseBE == false) {myBEButton.Content = "BE T2 OFF"; myBEButton.Foreground = DisabledButtonStrategyControlBoxTextColor; myBEButton.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
								}
								if(TargetForBE.ToString() == "T3")
								{
								if(UseBE == true) {myBEButton.Content = "BE T3 ON Offset: " + BEOffset; myBEButton.Foreground = EnabledButtonStrategyControlBoxTextColor; myBEButton.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(UseBE == false) {myBEButton.Content = "BE T3 OFF"; myBEButton.Foreground = DisabledButtonStrategyControlBoxTextColor; myBEButton.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
								}
								if(TargetForBE.ToString() == "T4")
								{
								if(UseBE == true) {myBEButton.Content = "BE T4 ON Offset: " + BEOffset; myBEButton.Foreground = EnabledButtonStrategyControlBoxTextColor; myBEButton.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(UseBE == false) {myBEButton.Content = "BE T4 OFF"; myBEButton.Foreground = DisabledButtonStrategyControlBoxTextColor; myBEButton.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
								}
								e.Handled = true;
							}
							
							else if (e.Delta < 0)
							{
								if(UseBE && BEOffset > 0) BEOffset--;
								if(TargetForBE.ToString() == "T1")
								{
								if(UseBE == true) {myBEButton.Content = "BE T1 ON Offset: " + BEOffset; myBEButton.Foreground = EnabledButtonStrategyControlBoxTextColor; myBEButton.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(UseBE == false) {myBEButton.Content = "BE T1 OFF"; myBEButton.Foreground = DisabledButtonStrategyControlBoxTextColor; myBEButton.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
								}
								if(TargetForBE.ToString() == "T2")
								{
								if(UseBE == true) {myBEButton.Content = "BE T2 ON Offset: " + BEOffset; myBEButton.Foreground = EnabledButtonStrategyControlBoxTextColor; myBEButton.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(UseBE == false) {myBEButton.Content = "BE T2 OFF"; myBEButton.Foreground = DisabledButtonStrategyControlBoxTextColor; myBEButton.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
								}
								if(TargetForBE.ToString() == "T3")
								{
								if(UseBE == true) {myBEButton.Content = "BE T3 ON Offset: " + BEOffset; myBEButton.Foreground = EnabledButtonStrategyControlBoxTextColor; myBEButton.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(UseBE == false) {myBEButton.Content = "BE T3 OFF"; myBEButton.Foreground = DisabledButtonStrategyControlBoxTextColor; myBEButton.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
								}
								if(TargetForBE.ToString() == "T4")
								{
								if(UseBE == true) {myBEButton.Content = "BE T4 ON Offset: " + BEOffset; myBEButton.Foreground = EnabledButtonStrategyControlBoxTextColor; myBEButton.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(UseBE == false) {myBEButton.Content = "BE T4 OFF"; myBEButton.Foreground = DisabledButtonStrategyControlBoxTextColor; myBEButton.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
								}
								e.Handled = true;
							}
							
						};
						
						myT1Button.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e)
						{
							if(e.Delta > 0)
							{
								if(ContractsT1 < MaxQuantityToTrade - ContractsT2 - ContractsT3 - ContractsT4 && TradeT1) ContractsT1++;
								if(TradeT1 == true) {myT1Button.Content = "T1 ON Q: " + ContractsT1; myT1Button.Foreground = EnabledButtonStrategyControlBoxTextColor; myT1Button.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(TradeT1 == false) {myT1Button.Content = "T1 OFF Q: " + ContractsT1; myT1Button.Foreground = DisabledButtonStrategyControlBoxTextColor; myT1Button.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
								e.Handled = true;
							}
							
							else if (e.Delta < 0)
							{
								if(ContractsT1 > 0 && TradeT1) ContractsT1--;
								if(TradeT1 == true) {myT1Button.Content = "T1 ON Q: " + ContractsT1; myT1Button.Foreground = EnabledButtonStrategyControlBoxTextColor; myT1Button.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(TradeT1 == false) {myT1Button.Content = "T1 OFF Q: " + ContractsT1; myT1Button.Foreground = DisabledButtonStrategyControlBoxTextColor; myT1Button.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
								e.Handled = true;
							}
							
						};
						
						myT2Button.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e)
						{
							if(e.Delta > 0)
							{
								if(ContractsT2 < MaxQuantityToTrade - ContractsT1 - ContractsT3 - ContractsT4 && TradeT2) ContractsT2++;
								if(TradeT2 == true) {myT2Button.Content = "T2 ON Q: " + ContractsT2; myT2Button.Foreground = EnabledButtonStrategyControlBoxTextColor; myT2Button.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(TradeT2 == false) {myT2Button.Content = "T2 OFF Q: " + ContractsT2; myT2Button.Foreground = DisabledButtonStrategyControlBoxTextColor; myT2Button.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
								e.Handled = true;
							}
							
							else if (e.Delta < 0)
							{
								if(ContractsT2 > 0 && TradeT2) ContractsT2--;
								if(TradeT2 == true) {myT2Button.Content = "T2 ON Q: " + ContractsT2; myT2Button.Foreground = EnabledButtonStrategyControlBoxTextColor; myT2Button.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(TradeT2 == false) {myT2Button.Content = "T2 OFF Q: " + ContractsT2; myT2Button.Foreground = DisabledButtonStrategyControlBoxTextColor; myT2Button.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
								e.Handled = true;
							}
							
						};
						
						myT3Button.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e)
						{
							if(e.Delta > 0)
							{
								if(ContractsT3 < MaxQuantityToTrade - ContractsT1 - ContractsT2 - ContractsT4 && TradeT3) ContractsT3++;
								if(TradeT3 == true) {myT3Button.Content = "T3 ON Q: " + ContractsT3; myT3Button.Foreground = EnabledButtonStrategyControlBoxTextColor; myT3Button.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(TradeT3 == false) {myT3Button.Content = "T3 OFF Q: " + ContractsT3; myT3Button.Foreground = DisabledButtonStrategyControlBoxTextColor; myT3Button.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
								e.Handled = true;
							}
							
							else if (e.Delta < 0)
							{
								if(ContractsT3 > 0 && TradeT3) ContractsT3--;
								if(TradeT3 == true) {myT3Button.Content = "T3 ON Q: " + ContractsT3; myT3Button.Foreground = EnabledButtonStrategyControlBoxTextColor; myT3Button.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(TradeT3 == false) {myT3Button.Content = "T3 OFF Q: " + ContractsT3; myT3Button.Foreground = DisabledButtonStrategyControlBoxTextColor; myT3Button.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
								e.Handled = true;
							}
							
						};
						
						myT4Button.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e)
						{
							if(e.Delta > 0)
							{
								if(ContractsT4 < MaxQuantityToTrade - ContractsT1 - ContractsT2 - ContractsT3 && TradeT4) ContractsT4++;
								if(TradeT4 == true) {myT4Button.Content = "T4 ON Q: " + ContractsT4; myT4Button.Foreground = EnabledButtonStrategyControlBoxTextColor; myT4Button.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(TradeT4 == false) {myT4Button.Content = "T4 OFF Q: " + ContractsT4; myT4Button.Foreground = DisabledButtonStrategyControlBoxTextColor; myT4Button.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
								e.Handled = true;
							}
							
							else if (e.Delta < 0)
							{
								if(ContractsT4 > 0 && TradeT4) ContractsT4--;
								if(TradeT4 == true) {myT4Button.Content = "T4 ON Q: " + ContractsT4; myT4Button.Foreground = EnabledButtonStrategyControlBoxTextColor; myT4Button.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(TradeT4 == false) {myT4Button.Content = "T4 OFF Q: " + ContractsT4; myT4Button.Foreground = DisabledButtonStrategyControlBoxTextColor; myT4Button.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
								e.Handled = true;
							}
							
						};
						
						myMMModeButton.MouseWheel += delegate(object o, System.Windows.Input.MouseWheelEventArgs e)
						{
							
							
							if(e.Delta > 0)
							{
								
							    if(calcType.ToString() == "Dollar_Value") UserInputMaxRiskAmountUSD = UserInputMaxRiskAmountUSD + 10.0;
								if(calcType.ToString() == "Percentage_Account_Balance") MaxRiskPercentage = MaxRiskPercentage + 0.1;
								if(calcType.ToString() == "Static_Lotsize") {MaxQuantityToTrade = MaxQuantityToTrade + 1;myMMModeButton.Content = "Risk:StaticLotsize: "+MaxQuantityToTrade; myMMModeButton.Foreground = EnabledButtonStrategyControlBoxTextColor; myMMModeButton.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(calcType.ToString() == "Dollar_Value") {myMMModeButton.Content = "Risk:DollarValue:   $" + UserInputMaxRiskAmountUSD; myMMModeButton.Foreground = EnabledButtonStrategyControlBoxTextColor; myMMModeButton.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(calcType.ToString() == "Percentage_Account_Balance") {myMMModeButton.Content = "Risk:%AcctBal:   " + Math.Round(MaxRiskPercentage,1) + " %"; myMMModeButton.Foreground = EnabledButtonStrategyControlBoxTextColor; myMMModeButton.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								e.Handled = true;
							}
							
							else if (e.Delta < 0)
							{
							
							    if(calcType.ToString() == "Dollar_Value" && UserInputMaxRiskAmountUSD >= 10.0) UserInputMaxRiskAmountUSD = UserInputMaxRiskAmountUSD - 10.0;
								if(calcType.ToString() == "Percentage_Account_Balance" && MaxRiskPercentage >= 0.1) MaxRiskPercentage = MaxRiskPercentage - 0.1;
								if(calcType.ToString() == "Static_Lotsize" && MaxQuantityToTrade >= 1) {MaxQuantityToTrade = MaxQuantityToTrade - 1;myMMModeButton.Content = "Risk:StaticLotsize: "+MaxQuantityToTrade; myMMModeButton.Foreground = EnabledButtonStrategyControlBoxTextColor; myMMModeButton.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(calcType.ToString() == "Dollar_Value") {myMMModeButton.Content = "Risk:DollarValue:   $"+UserInputMaxRiskAmountUSD; myMMModeButton.Foreground = EnabledButtonStrategyControlBoxTextColor; myMMModeButton.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								if(calcType.ToString() == "Percentage_Account_Balance") {myMMModeButton.Content = "Risk:%AcctBal:   " +Math.Round(MaxRiskPercentage,1)+" %"; myMMModeButton.Foreground = EnabledButtonStrategyControlBoxTextColor; myMMModeButton.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
								e.Handled = true;
							}
							
						};
				 
				    }));
		}
					
		protected override void OnBarUpdate()
		{
#if DoLicense
			if(!ValidLicense) {
				this.IsVisible = false;
				if(this.NewCustId<=0)
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Your ARCAI Contact Id is not present\n"+MachineId+"\n\nPlease run the latest ARC_LicenseActivator indicator\n\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif

			if (BarsInProgress != 0) 
				return;
			
			if (CurrentBars[0] < 10)
				return;
		
			
			if (State == State.Historical)
			{
				if(ButtonsCreated == false)
				{
					CreateButtons();
					ButtonsCreated = true;

			
					TradedInstrument =  Position.Instrument.ToString();
					
					
					if(WriteEntryOnLog) WriteLog(DateTime.Now.ToString() + "/STRATEGY ENABLED INSTRUMENT: "+TradedInstrument + " TRADE MODE: "+TradeMode + " Q1: "+ContractsT1 + " Q2: "+ContractsT2 + " Q3: "+ContractsT3+ " Q4: " + ContractsT4);
					
					if(ProfitPerTickDefined == false)
					{
						 ProfitPerTickDefined = true;
						 
						 ProfitPerTick = Instrument.MasterInstrument.PointValue*Instrument.MasterInstrument.TickSize;
						
					}
					
				}
				
					
			}
			
			if(State == State.Realtime)
			{
				
				
				if(PositionAccount.MarketPosition == MarketPosition.Flat && PositionAccount.Instrument.ToString().Contains(TradedInstrument)) Status = "Flat";
				else if(PositionAccount.MarketPosition == MarketPosition.Short && PositionAccount.Instrument.ToString().Contains(TradedInstrument)) Status = "Short";
				else if(PositionAccount.MarketPosition == MarketPosition.Long && PositionAccount.Instrument.ToString().Contains(TradedInstrument)) Status = "Long";
				else Status = "UNDEFINED";
				

				
				if(RRToolOnChart)
				{
					
					
					if(calcType.ToString() == "Dollar_Value")
					{
						MaxRiskAmountUSD = UserInputMaxRiskAmountUSD;
						if(SMCStop != RREntry) TotalRiskInTicks = Math.Abs((SMCStop - RREntry)/TickSize);
						if(TotalRiskInTicks != 0) MaxQ = MaxRiskAmountUSD/(ProfitPerTick*TotalRiskInTicks);
						if(MaxQ < 1.0) MaxQ = 0.0;
						if(MaxQ >= 1.0) MaxQ = MaxQ;
						MaxQ = Math.Floor(MaxQ);
						
						MaxQuantityToTrade = Convert.ToInt64(MaxQ);
					}
					
					if(calcType.ToString() == "Percentage_Account_Balance")
					{
						MaxRiskAmountUSD = (MaxRiskPercentage/100.0)*Account.Get(AccountItem.CashValue, Currency.UsDollar);
						if(SMCStop != RREntry) TotalRiskInTicks = Math.Abs((SMCStop - RREntry)/TickSize);
						if(TotalRiskInTicks != 0) MaxQ = MaxRiskAmountUSD/(ProfitPerTick*TotalRiskInTicks);
						if(MaxQ < 1.0) MaxQ = 0.0;
						if(MaxQ >= 1.0) MaxQ = MaxQ;
						MaxQ = Math.Floor(MaxQ);
						
						MaxQuantityToTrade = Convert.ToInt64(MaxQ);
					}
					
					
					
					if(ContractsT1+ContractsT2+ContractsT3+ContractsT4 > MaxQuantityToTrade && TradeT4 && ContractsT4 > 0 
						&& (MaxQuantityToTrade - ContractsT3 - ContractsT2 - ContractsT1) >= 0) ContractsT4 = MaxQuantityToTrade - ContractsT3 - ContractsT2 - ContractsT1;
					
					if(ContractsT1+ContractsT2+ContractsT3+ContractsT4 > MaxQuantityToTrade && TradeT4 && ContractsT4 > 0 
						&& (MaxQuantityToTrade - ContractsT3 - ContractsT2 - ContractsT1) < 0) ContractsT4 = 0;
					
					if(ContractsT1+ContractsT2+ContractsT3+ContractsT4 > MaxQuantityToTrade && TradeT3 && ContractsT3 > 0 
						&& (MaxQuantityToTrade - ContractsT4 - ContractsT2 - ContractsT1) >= 0) ContractsT3 = MaxQuantityToTrade - ContractsT4 - ContractsT2 - ContractsT1;
					
					if(ContractsT1+ContractsT2+ContractsT3+ContractsT4 > MaxQuantityToTrade && TradeT3 && ContractsT3 > 0 
						&& (MaxQuantityToTrade - ContractsT4 - ContractsT2 - ContractsT1) < 0) ContractsT3 = 0;
					
					if(ContractsT1+ContractsT2+ContractsT3+ContractsT4 > MaxQuantityToTrade && TradeT2 && ContractsT2 > 0 
						&& (MaxQuantityToTrade - ContractsT4 - ContractsT3 - ContractsT1) >= 0) ContractsT2 = MaxQuantityToTrade - ContractsT4 - ContractsT3 - ContractsT1;
					
					if(ContractsT1+ContractsT2+ContractsT3+ContractsT4 > MaxQuantityToTrade && TradeT2 && ContractsT2 > 0 
						&& (MaxQuantityToTrade - ContractsT4 - ContractsT3 - ContractsT1) < 0) ContractsT2 = 0;
					
					if(ContractsT1+ContractsT2+ContractsT3+ContractsT4 > MaxQuantityToTrade && TradeT1 && ContractsT1 > 0 
						&& (MaxQuantityToTrade - ContractsT4 - ContractsT3 - ContractsT2) >= 0) ContractsT1 = MaxQuantityToTrade - ContractsT4 - ContractsT3 - ContractsT2;
					
					if(ContractsT1+ContractsT2+ContractsT3+ContractsT4 > MaxQuantityToTrade && TradeT1 && ContractsT1 > 0 
						&& (MaxQuantityToTrade - ContractsT4 - ContractsT3 - ContractsT2) < 0) ContractsT1 = 0;
					
					
					
				}
				
				if(RRToolOnChart == false)
				{
					ContractsT1 = 0;
					ContractsT2 = 0;
					ContractsT3 = 0;
					ContractsT4 = 0;
					
					RREntry = 0.0;
					SMCStop = 0.0;
					RRTarget1 = 0.0;
					RRTarget2 = 0.0;
					RRTarget3 = 0.0;
					RRTarget4 = 0.0;
					
				
				}
				
				if(RRTarget1 == 0.0) TradeT1 = false;
				if(RRTarget2 == 0.0) TradeT2 = false;
				if(RRTarget3 == 0.0) TradeT3 = false;
				if(RRTarget4 == 0.0) TradeT4 = false;
				
				if(TradeT1 == false) ContractsT1 = 0;
				if(TradeT2 == false) ContractsT2 = 0;
				if(TradeT3 == false) ContractsT3 = 0;
				if(TradeT4 == false) ContractsT4 = 0;
				
				
				if(myT1Button != null && myT2Button != null && myT3Button != null && myT4Button != null && myAutotraderButton != null)
				{
				
				this.Dispatcher.Invoke(() => 
				{
    			if(TradeT1 == true) {myT1Button.Content = "T1 ON Q: " + ContractsT1; myT1Button.Foreground = EnabledButtonStrategyControlBoxTextColor; myT1Button.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
				if(TradeT1 == false) {myT1Button.Content = "T1 OFF Q: " + ContractsT1; myT1Button.Foreground = DisabledButtonStrategyControlBoxTextColor; myT1Button.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
				
				if(TradeT2 == true) {myT2Button.Content = "T2 ON Q: " + ContractsT2; myT2Button.Foreground = EnabledButtonStrategyControlBoxTextColor; myT2Button.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
				if(TradeT2 == false) {myT2Button.Content = "T2 OFF Q: " + ContractsT2; myT2Button.Foreground = DisabledButtonStrategyControlBoxTextColor; myT2Button.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
				
				if(TradeT3 == true) {myT3Button.Content = "T3 ON Q: " + ContractsT3; myT3Button.Foreground = EnabledButtonStrategyControlBoxTextColor; myT3Button.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
				if(TradeT3 == false) {myT3Button.Content = "T3 OFF Q: " + ContractsT3; myT3Button.Foreground = DisabledButtonStrategyControlBoxTextColor; myT3Button.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
				
				if(TradeT4 == true) {myT4Button.Content = "T4 ON Q: " + ContractsT4; myT4Button.Foreground = EnabledButtonStrategyControlBoxTextColor; myT4Button.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
				if(TradeT4 == false) {myT4Button.Content = "T4 OFF Q: " + ContractsT4; myT4Button.Foreground = DisabledButtonStrategyControlBoxTextColor; myT4Button.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
				
				if(TradeMode == 1) {myAutotraderButton.Content = "AUTOTRADER ON"; myAutotraderButton.Foreground = EnabledButtonStrategyControlBoxTextColor; myAutotraderButton.Background = EnabledButtonStrategyControlBoxBackgroundColor;}
				if(TradeMode == 0) {myAutotraderButton.Content = "AUTOTRADER OFF"; myAutotraderButton.Foreground = DisabledButtonStrategyControlBoxTextColor; myAutotraderButton.Background = DisabledButtonStrategyControlBoxBackgroundColor;}
				});
					
				}

		
				if(Status == "Flat"  && ManualExitClicked && DateTime.Now >= TimeManualExitClicked.AddSeconds(2))
				{
					foreach(Order order in Account.Orders)
					{
						if((order.OrderState == OrderState.Accepted || order.OrderState == OrderState.Working) && order.Instrument.ToString().Contains(TradedInstrument))
						{
							Account.CancelAllOrders(order.Instrument);
						}
					}
				}
				
				if(Status == "Flat"  && ManualExitClicked && DateTime.Now >= TimeManualExitClicked.AddSeconds(4))
				{
					ManualExitClicked = false;
				}

				
				RRToolsOnChartQuantity = 0;
				
				foreach(DrawingTool draw in DrawObjects.ToList())
				{
					
					if(draw.Name == "ARC RR" || draw.Name == "ARC_RR")
					{
						
						RRToolsOnChartQuantity++;
					}
					

				}
				
				foreach(DrawingTool draw in DrawObjects.ToList())
				{
					
					if(draw.Name == "ARC RR" || draw.Name == "ARC_RR")
					{
						RRToolOnChart = true;
						
						foreach(ChartAnchor anchor in draw.Anchors)
						{
							
							if(anchor.DisplayName == "Entry anchor" && anchor.Price != RREntry) { RREntry = anchor.Price; TimeEntryPriceDefined = DateTime.Now;}
							if(anchor.DisplayName == "Risk anchor" && anchor.Price != SMCStop) SMCStop = anchor.Price;
							if(anchor.DisplayName == "Reward1 Anchor" && anchor.Price != RRTarget1) RRTarget1 = anchor.Price;
							if(anchor.DisplayName == "Reward2 Anchor" && anchor.Price != RRTarget2) RRTarget2 = anchor.Price;
							if(anchor.DisplayName == "Reward3 Anchor" && anchor.Price != RRTarget3) RRTarget3 = anchor.Price;
							if(anchor.DisplayName == "Reward4 Anchor" && anchor.Price != RRTarget4) RRTarget4 = anchor.Price;
							
						}
						
						if(Math.Abs(RRTarget1 - RREntry) <= 1*TickSize) RRTarget1 = 0.0;
						if(Math.Abs(RRTarget2 - RREntry) <= 1*TickSize) RRTarget2 = 0.0;
						if(Math.Abs(RRTarget3 - RREntry) <= 1*TickSize) RRTarget3 = 0.0;
						if(Math.Abs(RRTarget4 - RREntry) <= 1*TickSize) RRTarget4 = 0.0;
						
					
						break;

					}
					
					else RRToolOnChart = false;
	
				}
				
							
				#region BreakEvenLogic
				
					
			    	if(Status == "Short" && TargetHitT1 && Close[0] < (Position.AveragePrice - BEOffset*TickSize) && UseBE && BreakEvenT1Triggered == false && TargetForBE.ToString() == "T1") 
					{
						foreach(Order order in Account.Orders)
						{
							if(order.Name == "Short-T2-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice - BEOffset*TickSize);
							if(order.Name == "Short-T3-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice - BEOffset*TickSize);
							if(order.Name == "Short-T4-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice - BEOffset*TickSize);
							if(order.Name == "Short-R-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice - BEOffset*TickSize);
						}
						BreakEvenT1Triggered = true;
						if(WriteEntryOnLog) WriteLog(DateTime.Now.ToString() + " " + "BreakEvenT1Triggered: "+ BreakEvenT1Triggered + " ON " + Status + " Position.AveragePrice: " +Position.AveragePrice + " Offset: " + BEOffset);
					}
					
					if(Status == "Long" && TargetHitT1 && Close[0] > (Position.AveragePrice + BEOffset*TickSize) && UseBE && BreakEvenT1Triggered == false && TargetForBE.ToString() == "T1") 
					{
						foreach(Order order in Account.Orders)
						{
							if(order.Name == "Long-T2-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice + BEOffset*TickSize);
							if(order.Name == "Long-T3-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice + BEOffset*TickSize);
							if(order.Name == "Long-T4-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice + BEOffset*TickSize);
							if(order.Name == "Long-R-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice + BEOffset*TickSize);
						}
						BreakEvenT1Triggered = true;
						if(WriteEntryOnLog) WriteLog(DateTime.Now.ToString() + " " + "BreakEvenT1Triggered: "+ BreakEvenT1Triggered + " ON " + Status + " Position.AveragePrice: " +Position.AveragePrice + " Offset: " + BEOffset);
						
					}
					
					
					if(Status == "Short" && TargetHitT2 && Close[0] < (Position.AveragePrice - BEOffset*TickSize) && UseBE && BreakEvenT2Triggered == false && TargetForBE.ToString() == "T2") 
					{
						foreach(Order order in Account.Orders)
						{
							if(order.Name == "Short-T1-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice - BEOffset*TickSize);
							if(order.Name == "Short-T3-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice - BEOffset*TickSize);
							if(order.Name == "Short-T4-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice - BEOffset*TickSize);
							if(order.Name == "Short-R-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice - BEOffset*TickSize);
						}
						BreakEvenT2Triggered = true;
						if(WriteEntryOnLog) WriteLog(DateTime.Now.ToString() + " " + "BreakEvenT2Triggered: "+ BreakEvenT2Triggered + " ON " + Status + " Position.AveragePrice: " +Position.AveragePrice + " Offset: " + BEOffset);
					}
					
					if(Status == "Long" && TargetHitT2 && Close[0] > (Position.AveragePrice + BEOffset*TickSize) && UseBE && BreakEvenT2Triggered == false && TargetForBE.ToString() == "T2") 
					{
						foreach(Order order in Account.Orders)
						{
							if(order.Name == "Long-T1-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice + BEOffset*TickSize);
							if(order.Name == "Long-T3-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice + BEOffset*TickSize);
							if(order.Name == "Long-T4-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice + BEOffset*TickSize);
							if(order.Name == "Long-R-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice + BEOffset*TickSize);
						}
						BreakEvenT2Triggered = true;
						if(WriteEntryOnLog) WriteLog(DateTime.Now.ToString() + " " + "BreakEvenT2Triggered: "+ BreakEvenT2Triggered + " ON " + Status + " Position.AveragePrice: " +Position.AveragePrice + " Offset: " + BEOffset);
						
					}
					
					if(Status == "Short" && TargetHitT3 && Close[0] < (Position.AveragePrice - BEOffset*TickSize) && UseBE && BreakEvenT3Triggered == false && TargetForBE.ToString() == "T3") 
					{
						foreach(Order order in Account.Orders)
						{
							if(order.Name == "Short-T1-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice - BEOffset*TickSize);
							if(order.Name == "Short-T2-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice - BEOffset*TickSize);
							if(order.Name == "Short-T4-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice - BEOffset*TickSize);
							if(order.Name == "Short-R-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice - BEOffset*TickSize);
						}
						BreakEvenT3Triggered = true;
						if(WriteEntryOnLog) WriteLog(DateTime.Now.ToString() + " " + "BreakEvenT3Triggered: "+ BreakEvenT3Triggered + " ON " + Status + " Position.AveragePrice: " +Position.AveragePrice + " Offset: " + BEOffset);
					}
					
					if(Status == "Long" && TargetHitT3 && Close[0] > (Position.AveragePrice + BEOffset*TickSize) && UseBE && BreakEvenT3Triggered == false && TargetForBE.ToString() == "T3") 
					{
						foreach(Order order in Account.Orders)
						{
							if(order.Name == "Long-T1-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice + BEOffset*TickSize);
							if(order.Name == "Long-T2-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice + BEOffset*TickSize);
							if(order.Name == "Long-T4-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice + BEOffset*TickSize);
							if(order.Name == "Long-R-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice + BEOffset*TickSize);
						}
						BreakEvenT3Triggered = true;
						if(WriteEntryOnLog) WriteLog(DateTime.Now.ToString() + " " + "BreakEvenT3Triggered: "+ BreakEvenT3Triggered + " ON " + Status + " Position.AveragePrice: " +Position.AveragePrice + " Offset: " + BEOffset);
						
					}
					
					if(Status == "Short" && TargetHitT4 && Close[0] < (Position.AveragePrice - BEOffset*TickSize) && UseBE && BreakEvenT4Triggered == false && TargetForBE.ToString() == "T4") 
					{
						foreach(Order order in Account.Orders)
						{
							if(order.Name == "Short-T1-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice - BEOffset*TickSize);
							if(order.Name == "Short-T2-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice - BEOffset*TickSize);
							if(order.Name == "Short-T4-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice - BEOffset*TickSize);
							if(order.Name == "Short-R-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice - BEOffset*TickSize);
						}
						BreakEvenT4Triggered = true;
						if(WriteEntryOnLog) WriteLog(DateTime.Now.ToString() + " " + "BreakEvenT4Triggered: "+ BreakEvenT4Triggered + " ON " + Status + " Position.AveragePrice: " +Position.AveragePrice + " Offset: " + BEOffset);
					}
					
					if(Status == "Long" && TargetHitT4 && Close[0] > (Position.AveragePrice + BEOffset*TickSize) && UseBE && BreakEvenT4Triggered == false && TargetForBE.ToString() == "T4") 
					{
						foreach(Order order in Account.Orders)
						{
							if(order.Name == "Long-T1-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice + BEOffset*TickSize);
							if(order.Name == "Long-T2-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice + BEOffset*TickSize);
							if(order.Name == "Long-T4-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice + BEOffset*TickSize);
							if(order.Name == "Long-R-Stop" && order.Instrument.ToString() == TradedInstrument) ChangeOrder(order,order.Quantity,0,Position.AveragePrice + BEOffset*TickSize);
						}
						BreakEvenT4Triggered = true;
						if(WriteEntryOnLog) WriteLog(DateTime.Now.ToString() + " " + "BreakEvenT4Triggered: "+ BreakEvenT4Triggered + " ON " + Status + " Position.AveragePrice: " +Position.AveragePrice + " Offset: " + BEOffset);
						
					}
					
				
					
					
					
					
					
					
				#endregion
					
				#region EntryExecution Logic			
                if(Math.Round((Close[0] - RREntry)/TickSize,0,MidpointRounding.ToEven) == 0 
					&& Status == "Flat"
					&& UsedLowLevels.Contains(RREntry) == false
					&& TradeMode == 1
					&& DateTime.Now > TimeEntryPriceDefined.AddSeconds(1))
					{
						EntryBar = CurrentBar;
						
						if(ContractsT1 == 0 && ContractsT2 == 0 && ContractsT3 == 0 && ContractsT4 == 0 && calcType.ToString() != "Static_Lotsize") ContractsR = MaxQuantityToTrade;
						
						if(ContractsT1 > 0 && RREntry < SMCStop && RREntry > RRTarget1 && RRTarget1 != 0.0 && TradeT1)
						{
						
						UsedLowLevels.Add(RREntry);
						oco = GetAtmStrategyUniqueId();
						oco = Truncate(oco,30);
						SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Market, Convert.ToInt32(ContractsT1), 0, 0, "","Short-T1");
						SubmitOrderUnmanaged(0, OrderAction.BuyToCover, OrderType.StopMarket, Convert.ToInt32(ContractsT1), 0, SMCStop, oco, "Short-T1-Stop");
                        SubmitOrderUnmanaged(0, OrderAction.BuyToCover, OrderType.Limit, Convert.ToInt32(ContractsT1), RRTarget1, 0, oco, "Short-T1-Target");
					
						ContractsR = MaxQuantityToTrade - ContractsT1;
						TradeMode = 0;
						
						}
						
						if(ContractsT2 > 0 && RREntry < SMCStop && RREntry > RRTarget2 && RRTarget2 != 0.0 && TradeT2)
						{
						
						UsedLowLevels.Add(RREntry);
						oco = GetAtmStrategyUniqueId();
						oco = Truncate(oco,30);
						SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Market, Convert.ToInt32(ContractsT2), 0, 0, "","Short-T2");
						SubmitOrderUnmanaged(0, OrderAction.BuyToCover, OrderType.StopMarket, Convert.ToInt32(ContractsT2), 0, SMCStop, oco, "Short-T2-Stop");
                        SubmitOrderUnmanaged(0, OrderAction.BuyToCover, OrderType.Limit, Convert.ToInt32(ContractsT2), RRTarget2, 0, oco, "Short-T2-Target");
						
						ContractsR = ContractsR - ContractsT2;
						
						}
						
						if(ContractsT3 > 0 && RREntry < SMCStop && RREntry > RRTarget3 && RRTarget3 != 0.0 && TradeT3)
						{
						
						UsedLowLevels.Add(RREntry);
						oco = GetAtmStrategyUniqueId();
						oco = Truncate(oco,30);
						SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Market, Convert.ToInt32(ContractsT3), 0, 0, "","Short-T3");
						SubmitOrderUnmanaged(0, OrderAction.BuyToCover, OrderType.StopMarket, Convert.ToInt32(ContractsT3), 0, SMCStop, oco, "Short-T3-Stop");
                        SubmitOrderUnmanaged(0, OrderAction.BuyToCover, OrderType.Limit, Convert.ToInt32(ContractsT3), RRTarget3, 0, oco, "Short-T3-Target");
						
						ContractsR = ContractsR - ContractsT3;
						
						}
						
						if(ContractsT4 > 0 && RREntry < SMCStop && RREntry > RRTarget4 && RRTarget4 != 0.0 && TradeT4)
						{
						
						UsedLowLevels.Add(RREntry);
						oco = GetAtmStrategyUniqueId();
						oco = Truncate(oco,30);
						SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Market, Convert.ToInt32(ContractsT4), 0, 0, "","Short-T4");
						SubmitOrderUnmanaged(0, OrderAction.BuyToCover, OrderType.StopMarket, Convert.ToInt32(ContractsT4), 0, SMCStop, oco, "Short-T4-Stop");
                        SubmitOrderUnmanaged(0, OrderAction.BuyToCover, OrderType.Limit, Convert.ToInt32(ContractsT4), RRTarget4, 0, oco, "Short-T4-Target");
						
						ContractsR = ContractsR - ContractsT4;
						
						}
						
						if(ContractsR > 0 && RREntry < SMCStop)
						{
							
						UsedLowLevels.Add(RREntry);
						oco = GetAtmStrategyUniqueId();
						oco = Truncate(oco,30);
						SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Market, Convert.ToInt32(ContractsR), 0, 0, "","Short-R");
						SubmitOrderUnmanaged(0, OrderAction.BuyToCover, OrderType.StopMarket, Convert.ToInt32(ContractsR), 0, SMCStop, oco, "Short-R-Stop");
 
						
						ContractsR = 0;
						}
					}
				
				if(Math.Round((Close[0] - RREntry)/TickSize,0,MidpointRounding.ToEven) == 0 
						&& Status == "Flat"
						&& UsedHighLevels.Contains(RREntry) == false
						&& TradeMode == 1
					    && DateTime.Now > TimeEntryPriceDefined.AddSeconds(1))
						{
							if(ContractsT1 == 0 && ContractsT2 == 0 && ContractsT3 == 0 && ContractsT4 == 0 && calcType.ToString() != "Static_Lotsize") ContractsR = MaxQuantityToTrade;
							
							if(ContractsT1 > 0 && RREntry > SMCStop && RREntry < RRTarget1 && RRTarget1 != 0.0 && TradeT1)
							{
							
							UsedHighLevels.Add(RREntry);
							oco = GetAtmStrategyUniqueId();
							oco = Truncate(oco,30);
							SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Market, Convert.ToInt32(ContractsT1), 0, 0, "","Long-T1");
							SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.StopMarket, Convert.ToInt32(ContractsT1), 0, SMCStop, oco, "Long-T1-Stop");
	                        SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Limit, Convert.ToInt32(ContractsT1), RRTarget1, 0, oco, "Long-T1-Target");
							
								
							ContractsR = MaxQuantityToTrade - ContractsT1;
								
							TradeMode = 0;
							
							}
							
							if(ContractsT2 > 0 && RREntry > SMCStop && RREntry < RRTarget2 && RRTarget2 != 0.0 && TradeT2)
							{
							
							UsedHighLevels.Add(RREntry);
							oco = GetAtmStrategyUniqueId();
							oco = Truncate(oco,30);
							SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Market, Convert.ToInt32(ContractsT2), 0, 0, "","Long-T2");
							SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.StopMarket, Convert.ToInt32(ContractsT2), 0, SMCStop, oco, "Long-T2-Stop");
	                        SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Limit, Convert.ToInt32(ContractsT2), RRTarget2, 0, oco, "Long-T2-Target");
							
								
							ContractsR = ContractsR - ContractsT2;
							}
							
							if(ContractsT3 > 0 && RREntry > SMCStop && RREntry < RRTarget3 && RRTarget3 != 0.0 && TradeT3)
							{
							
							UsedHighLevels.Add(RREntry);
							oco = GetAtmStrategyUniqueId();
							oco = Truncate(oco,30);
							SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Market, Convert.ToInt32(ContractsT3), 0, 0, "","Long-T3");
							SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.StopMarket, Convert.ToInt32(ContractsT3), 0, SMCStop, oco, "Long-T3-Stop");
	                        SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Limit, Convert.ToInt32(ContractsT3), RRTarget3, 0, oco, "Long-T3-Target");
								
							ContractsR = ContractsR - ContractsT3;
								
							}
							
							if(ContractsT4 > 0 && RREntry > SMCStop && RREntry < RRTarget4 && RRTarget4 != 0.0 && TradeT4)
							{
							
							UsedHighLevels.Add(RREntry);
							oco = GetAtmStrategyUniqueId();
							oco = Truncate(oco,30);
							SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Market, Convert.ToInt32(ContractsT4), 0, 0, "","Long-T4");
							SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.StopMarket, Convert.ToInt32(ContractsT4), 0, SMCStop, oco, "Long-T4-Stop");
	                        SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.Limit, Convert.ToInt32(ContractsT4), RRTarget4, 0, oco, "Long-T4-Target");
								
							ContractsR = ContractsR - ContractsT4;
							}
							
							if(ContractsR > 0 && RREntry > SMCStop)
							{
							
							UsedHighLevels.Add(RREntry);
							oco = GetAtmStrategyUniqueId();
							oco = Truncate(oco,30);
							SubmitOrderUnmanaged(0, OrderAction.Buy, OrderType.Market, Convert.ToInt32(ContractsR), 0, 0, "","Long-R");
							SubmitOrderUnmanaged(0, OrderAction.Sell, OrderType.StopMarket, Convert.ToInt32(ContractsR), 0, SMCStop, oco, "Long-R-Stop");
	                       
						
							ContractsR = 0;
							}
						}
	            

					#endregion			
				
				#region CalculateRisk
					 if(RREntry < SMCStop) 
					 {	
						
						 if(RRTarget1 != 0.0 && TradeT1)
						 {
						 RewardT1 = ((RREntry - RRTarget1)/TickSize)*ContractsT1*ProfitPerTick;
						 
						 }
						 
						 else
						 {
						 	RewardT1 = 0.0;	
						 }
						 
						 if(RRTarget2 != 0.0 && TradeT2)
						 {
						 RewardT2 = ((RREntry - RRTarget2)/TickSize)*ContractsT2*ProfitPerTick;
						 
						 }
						 
						 else
						 {
						 	RewardT2 = 0.0;
							
						 }
						 
						 if(RRTarget3 != 0.0 && TradeT3)
						 {
						 RewardT3 = ((RREntry - RRTarget3)/TickSize)*ContractsT3*ProfitPerTick;
						 
						 }
						 
						 else
						 {
						 	RewardT3 = 0.0;
							
						 }
						 
						 if(RRTarget4 != 0.0 && TradeT4)
						 {
						 RewardT4 = ((RREntry - RRTarget4)/TickSize)*ContractsT4*ProfitPerTick;
						 
						 }
						 
						 else
						 {
						 	RewardT4 = 0.0;
							
						 }
						 
						
						 TotalReward = RewardT1 + RewardT2 + RewardT3 + RewardT4;
						
					 }
					 
					 if(RREntry > SMCStop)
					 {
						
					
						 if(RRTarget1 != 0.0 && TradeT1)
						 {
						 RewardT1 = ((RRTarget1 - RREntry)/TickSize)*ContractsT1*ProfitPerTick;
						 }
						 else
						 {
						 RewardT1 = 0.0;
						 }
						 
						 if(RRTarget2 != 0.0 && TradeT2)
						 {
						 RewardT2 = ((RRTarget2 - RREntry)/TickSize)*ContractsT2*ProfitPerTick;
						 }
						 else
						 {
						 RewardT2 = 0.0;
						 }
						 
						 if(RRTarget3 != 0.0 && TradeT3)
						 {
						 RewardT3 = ((RRTarget3 - RREntry)/TickSize)*ContractsT3*ProfitPerTick;
						 
						 }
						 else
						 {
						 RewardT3 = 0.0;
						 }
						 
						 if(RRTarget4 != 0.0 && TradeT4)
						 {
						 RewardT4 = ((RRTarget4 - RREntry)/TickSize)*ContractsT4*ProfitPerTick;
						 
						 }
						 else
						 {
						 RewardT4 = 0.0;
						 }
						
						
						 TotalReward = RewardT1 + RewardT2 + RewardT3 + RewardT4;
						 //TotalRisk = RiskT1 + RiskT2 + RiskT3 + RiskT4;
					 }
					 
					 if(RRToolOnChart == false)
					 {
					 	TotalReward = 0.0;
						TotalRisk = 0.0;
						
					 }
					 
					 
					 	TotalRisk = (Math.Abs(RREntry - SMCStop)/TickSize)*MaxQuantityToTrade*ProfitPerTick;
					 
					 
					 #endregion
					  
				 if(Status == "Flat") 
				 {
					
					 TargetHitT1 = false;
					 TargetHitT2 = false;
					 TargetHitT3 = false;
				     TargetHitT4 = false;
					 
					 BreakEvenT1Triggered = false;
	                 BreakEvenT2Triggered = false;
	                 BreakEvenT3Triggered = false;
	                 BreakEvenT4Triggered = false;

				 }
					  

				
			if(TradeMode == 1 && RREntry > SMCStop && Status == "Flat" && RREntry != 0.0 && MaxQuantityToTrade > 0)
			{
				RemoveDrawObject("ReadyToShort");
				Draw.TextFixed(this, "ReadyToLong", "READY TO GO LONG " + MaxQuantityToTrade + " @ " + Position.Instrument.MasterInstrument.RoundToTickSize(RREntry)
					, 
					TextPosition.BottomRight, EntryWarningWindowTextColorForLongs,messageTextFont, EntryWarningWindowBorderColorForLongs,EntryWarningWindowBackgroundColorForLongs, 100);
					
			}
			
			
			
			if(TradeMode == 1 && RREntry < SMCStop && Status == "Flat" && RREntry != 0.0 && MaxQuantityToTrade > 0)
			{
				RemoveDrawObject("ReadyToLong");
				Draw.TextFixed(this, "ReadyToShort", "READY TO GO SHORT " + MaxQuantityToTrade + " @ " + Position.Instrument.MasterInstrument.RoundToTickSize(RREntry)
					, 
					TextPosition.BottomRight, EntryWarningWindowTextColorForShorts,messageTextFont, EntryWarningWindowBorderColorForShorts,EntryWarningWindowBackgroundColorForShorts, 100);
				
			}
			
			if(TradeMode == 1 && RREntry != SMCStop && Status != "Flat" && RREntry != 0.0 && MaxQuantityToTrade > 0)
			{
				RemoveDrawObject("ReadyToShort");
				RemoveDrawObject("ReadyToLong");
				
			}
			
			if(TradeMode == 0)
			{
				RemoveDrawObject("ReadyToShort");
				RemoveDrawObject("ReadyToLong");
			}
			
			if(TradeMode == 1 && RRToolOnChart == false)
			{
				RemoveDrawObject("ReadyToShort");
				RemoveDrawObject("ReadyToLong");
			}
				
	
			if(RRToolOnChart == true && (UsedLowLevels.Contains(RREntry) || UsedHighLevels.Contains(RREntry)))
			{
				RemoveDrawObject("ReadyToShort");
				RemoveDrawObject("ReadyToLong");
			}
			
			if(RRToolOnChart == true && MaxQuantityToTrade == 0)
			{
				RemoveDrawObject("ReadyToShort");
				RemoveDrawObject("ReadyToLong");
			}
			
			if(RRToolsOnChartQuantity >= 2)
			{
			
				Draw.TextFixed(this, "Warning", "YOU HAVE "  + RRToolsOnChartQuantity.ToString() + " ARCRR DRAW TOOLS ON CHART, ONLY 1 IS ALLOWED "
					, 
					TextPosition.TopRight, RRWarningWindowTextColor,messageTextFont, RRWarningWindowBorderColor,RRWarningWindowBackgroundColor, 100);
				TradeMode = 0;
			}
			
			if(RRToolsOnChartQuantity <= 1)
			{
				RemoveDrawObject("Warning");
			}
			
			}

		}
		
		public override string DisplayName {get {return Name;}}
		
		#region Properties
		
		public enum PositionsForInfoWindow
	    {
	        
	        TopLeft,
			TopCenter,
	        TopRight,
			MidLeft,
			MidCenter,
			MidRight,
			BottomLeft,
			BottomCenter,
			BottomRight
	    }
		
		[NinjaScriptProperty]
		[Display(Name="InfoWindow Box Position on Chart", Description="InfoWindow Box Position on Chart", Order=1, GroupName="InfoWindow")]
		public PositionsForInfoWindow PositionForInfoWindow
		{
			get { return positionForInfoWindow; }
			set { positionForInfoWindow = value; }
		}
		
		[XmlIgnore]
        [Display(Name="Color for InfoWindow Background", Description="Set the background color for the InfoWindow", Order=2, GroupName="InfoWindow")]
        public Brush InfoWindowBackgroundColor
        { get; set; }

		[Browsable(false)]
        public string InfoWindowBackgroundColorSerializable
        {
            get { return Serialize.BrushToString(InfoWindowBackgroundColor); }
            set { InfoWindowBackgroundColor = Serialize.StringToBrush(value); }
        }
		
		[NinjaScriptProperty]
		[Range(0.0, 100.0)]
		[Display(Name="Opacity for InfoWindow Background", Description="Set the background color opacity for the InfoWindow 0: transparent 100: full solid color", Order=3, GroupName="InfoWindow")]
		public double InfoWindowOpacity
		{ get; set; }
		
		
		[XmlIgnore]
        [Display(Name="Color for InfoWindow Text", Description="Set the text color for the InfoWindow", Order=4, GroupName="InfoWindow")]
        public Brush InfoWindowTextColor
        { get; set; }

		[Browsable(false)]
        public string InfoWindowTextColorSerializable
        {
            get { return Serialize.BrushToString(InfoWindowTextColor); }
            set { InfoWindowTextColor = Serialize.StringToBrush(value); }
        }
		
		[XmlIgnore]
        [Display(Name="Color for InfoWindow Border", Description="Set the border color for the InfoWindow", Order=5, GroupName="InfoWindow")]
        public Brush InfoWindowBorderColor
        { get; set; }


		[Browsable(false)]
        public string InfoWindowBorderColorSerializable
        {
            get { return Serialize.BrushToString(InfoWindowBorderColor); }
            set { InfoWindowBorderColor = Serialize.StringToBrush(value); }
        }
		
		[NinjaScriptProperty]
		[Display(Name="InfoWindow Text Font", Description="InfoWindow Text Font", Order=6, GroupName="InfoWindow")]
		public SimpleFont InfoWindowFont
		{
			get{return infoWindowFont;}
			set{infoWindowFont = value;}
		}
		
		[NinjaScriptProperty]
		[Browsable(false)]
		[Display(Name="Write activity on Customized Log", Description="Write activity on Customized Log", Order=7, GroupName="InfoWindow")]
		public bool WriteEntryOnLog
		{ get; set; }
		
		public enum PositionsForStrategyControls
	    {
	        
	        TopLeft,
			TopCenter,
	        TopRight,
			MidLeft,
			MidCenter,
			MidRight,
			BottomLeft,
			BottomCenter,
			BottomRight
	    }

		[NinjaScriptProperty]
		[Display(Name="Strategy Control Box Position on Chart", Description="Strategy Control Box Position on Chart", Order=8, GroupName="Strategy Control Box")]
		public PositionsForStrategyControls PositionForStrategyControls
		{
			get { return positionForStrategyControls; }
			set { positionForStrategyControls = value; }
		}
		
		
		[XmlIgnore]
        [Display(Name="Color for Button Background when Enabled", Description="Color for Button Background when Enabled", Order=9, GroupName="Strategy Control Box")]
        public Brush EnabledButtonStrategyControlBoxBackgroundColor
        { get; set; }

		[Browsable(false)]
        public string EnabledButtonStrategyControlBoxBackgroundColorSerializable
        {
            get { return Serialize.BrushToString(EnabledButtonStrategyControlBoxBackgroundColor); }
            set { EnabledButtonStrategyControlBoxBackgroundColor = Serialize.StringToBrush(value); }
        }
		
		[XmlIgnore]
        [Display(Name="Color for Button Text when Enabled", Description="Color for Button Text when Enabled", Order=10, GroupName="Strategy Control Box")]
        public Brush EnabledButtonStrategyControlBoxTextColor
        { get; set; }

		[Browsable(false)]
        public string EnabledButtonStrategyControlBoxTextColorSerializable
        {
            get { return Serialize.BrushToString(EnabledButtonStrategyControlBoxTextColor); }
            set { EnabledButtonStrategyControlBoxTextColor = Serialize.StringToBrush(value); }
        }
		
		[XmlIgnore]
        [Display(Name="Color for Button Border when Enabled", Description="Color for Button Border when Enabled", Order=11, GroupName="Strategy Control Box")]
        public Brush EnabledButtonStrategyControlBoxBorderColor
        { get; set; }


		[Browsable(false)]
        public string EnabledButtonStrategyControlBoxBorderColorSerializable
        {
            get { return Serialize.BrushToString(EnabledButtonStrategyControlBoxBorderColor); }
            set { EnabledButtonStrategyControlBoxBorderColor = Serialize.StringToBrush(value); }
        }
		
		[NinjaScriptProperty]
		[Display(Name="Text Font for Strategy Control Box", Description="Text Font for Strategy Control Box", Order=12, GroupName="Strategy Control Box")]
		public SimpleFont ButtonStrategyControlBoxFont
		{
			get{return buttonStrategyControlBoxFont;}
			set{buttonStrategyControlBoxFont = value;}
		}
		
		
		
		[XmlIgnore]
        [Display(Name="Color for Button Background when Disabled", Description="Color for Button Background when Disabled", Order=13, GroupName="Strategy Control Box")]
        public Brush DisabledButtonStrategyControlBoxBackgroundColor
        { get; set; }

		[Browsable(false)]
        public string DisabledButtonStrategyControlBoxBackgroundColorSerializable
        {
            get { return Serialize.BrushToString(DisabledButtonStrategyControlBoxBackgroundColor); }
            set { DisabledButtonStrategyControlBoxBackgroundColor = Serialize.StringToBrush(value); }
        }
		
		[XmlIgnore]
        [Display(Name="Color for Button Text when Disabled", Description="Color for Button Text when Disabled", Order=14, GroupName="Strategy Control Box")]
        public Brush DisabledButtonStrategyControlBoxTextColor
        { get; set; }

		[Browsable(false)]
        public string DisabledButtonStrategyControlBoxTextColorSerializable
        {
            get { return Serialize.BrushToString(DisabledButtonStrategyControlBoxTextColor); }
            set { DisabledButtonStrategyControlBoxTextColor = Serialize.StringToBrush(value); }
        }
		
		[XmlIgnore]
        [Display(Name="Color for Button Border when Disabled", Description="Color for Button Border when Disabled", Order=15, GroupName="Strategy Control Box")]
        public Brush DisabledButtonStrategyControlBoxBorderColor
        { get; set; }


		[Browsable(false)]
        public string DisabledButtonStrategyControlBoxBorderColorSerializable
        {
            get { return Serialize.BrushToString(DisabledButtonStrategyControlBoxBorderColor); }
            set { DisabledButtonStrategyControlBoxBorderColor = Serialize.StringToBrush(value); }
        }
		
		
		
		[NinjaScriptProperty]
		[Browsable(false)]
		[Display(Name="Ignore All Errors", Description="Error Handling: Ignore All Errors", Order=16, GroupName="Error Handling")]
		public bool ErrorHandling_IgnoreAllErrors
		{ get; set; }
		
		[NinjaScriptProperty]
		[Browsable(false)]
		[Display(Name="StopCancelClose", Description="Error Handling: StopCancelClose", Order=17, GroupName="Error Handling")]
		public bool ErrorHandling_StopCancelClose
		{ get; set; }
		
		[NinjaScriptProperty]
		[Browsable(false)]
		[Display(Name="StopCancelClose Ignore Rejects", Description="Error Handling: StopCancelClose Ignore Rejects", Order=18, GroupName="Error Handling")]
		public bool ErrorHandling_StopCancelCloseIgnoreRejects
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Show Information Window", Description="Show Information Window", Order=19, GroupName="General Settings")]
		public bool ShowInfoWindow
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Entry Warning Window Text Font", Description="Entry Warning Window Text Font", Order=20, GroupName="Warning Messages")]
		public SimpleFont MessageTextFont
		{
			get{return messageTextFont;}
			set{messageTextFont = value;}
		}
		
		[NinjaScriptProperty]
		[Display(Name="RR Tool Quantity Warning Window Text Font", Description="RR Tool Quantity Warning Window Text Font", Order=21, GroupName="Warning Messages")]
		public SimpleFont RRToolWarningFont
		{
			get{return rRToolWarningFont;}
			set{rRToolWarningFont = value;}
		}
		
		[XmlIgnore]
        [Display(Name="RR Tool Quantity Warning Window Text Color", Description="RR Tool Quantity Warning Window Text Color", Order=22, GroupName="Warning Messages")]
        public Brush RRWarningWindowTextColor
        { get; set; }

		[Browsable(false)]
        public string RRWarningWindowTextColorSerializable
        {
            get { return Serialize.BrushToString(RRWarningWindowTextColor); }
            set { RRWarningWindowTextColor = Serialize.StringToBrush(value); }
        }
		
		[XmlIgnore]
        [Display(Name="RR Tool Quantity Warning Window Background Color", Description="RR Tool Quantity Warning Window Background Color", Order=23, GroupName="Warning Messages")]
        public Brush RRWarningWindowBackgroundColor
        { get; set; }

		[Browsable(false)]
        public string RRWarningWindowBackgroundColorSerializable
        {
            get { return Serialize.BrushToString(RRWarningWindowBackgroundColor); }
            set { RRWarningWindowBackgroundColor = Serialize.StringToBrush(value); }
        }
		
		[XmlIgnore]
        [Display(Name="RR Tool Quantity Warning Window Border Color", Description="RR Tool Quantity Warning Window Border Color", Order=24, GroupName="Warning Messages")]
        public Brush RRWarningWindowBorderColor
        { get; set; }

		[Browsable(false)]
        public string RRWarningWindowBorderColorSerializable
        {
            get { return Serialize.BrushToString(RRWarningWindowBorderColor); }
            set { RRWarningWindowBorderColor = Serialize.StringToBrush(value); }
        }
		
		
		[XmlIgnore]
        [Display(Name="Entry Warning Window Text Color for Longs", Description="Entry Warning Window Text Color for Longs", Order=25, GroupName="Warning Messages")]
        public Brush EntryWarningWindowTextColorForLongs
        { get; set; }

		[Browsable(false)]
        public string EntryWarningWindowTextColorForLongsSerializable
        {
            get { return Serialize.BrushToString(EntryWarningWindowTextColorForLongs); }
            set { EntryWarningWindowTextColorForLongs = Serialize.StringToBrush(value); }
        }
		
		[XmlIgnore]
        [Display(Name="Entry Warning Window Text Color for Shorts", Description="Entry Warning Window Text Color for Shorts", Order=26, GroupName="Warning Messages")]
        public Brush EntryWarningWindowTextColorForShorts
        { get; set; }

		[Browsable(false)]
        public string EntryWarningWindowTextColorForShortsSerializable
        {
            get { return Serialize.BrushToString(EntryWarningWindowTextColorForShorts); }
            set { EntryWarningWindowTextColorForShorts = Serialize.StringToBrush(value); }
        }
		
		[XmlIgnore]
        [Display(Name="Entry Warning Window Background Color for Longs", Description="Entry Warning Window Background Color for Longs", Order=27, GroupName="Warning Messages")]
        public Brush EntryWarningWindowBackgroundColorForLongs
        { get; set; }

		[Browsable(false)]
        public string EntryWarningWindowBackgroundColorForLongsSerializable
        {
            get { return Serialize.BrushToString(EntryWarningWindowBackgroundColorForLongs); }
            set { EntryWarningWindowBackgroundColorForLongs = Serialize.StringToBrush(value); }
        }
		
		[XmlIgnore]
        [Display(Name="Entry Warning Window Background Color for Shorts", Description="Entry Warning Window Background Color for Shorts", Order=28, GroupName="Warning Messages")]
        public Brush EntryWarningWindowBackgroundColorForShorts
        { get; set; }

		[Browsable(false)]
        public string EntryWarningWindowBackgroundColorForShortsSerializable
        {
            get { return Serialize.BrushToString(EntryWarningWindowBackgroundColorForShorts); }
            set { EntryWarningWindowBackgroundColorForShorts = Serialize.StringToBrush(value); }
        }
		
		
		[XmlIgnore]
        [Display(Name="Entry Warning Window Border Color for Longs", Description="Entry Warning Window Border Color for Longs", Order=29, GroupName="Warning Messages")]
        public Brush EntryWarningWindowBorderColorForLongs
        { get; set; }

		[Browsable(false)]
        public string EntryWarningWindowBorderColorForLongsSerializable
        {
            get { return Serialize.BrushToString(EntryWarningWindowBorderColorForLongs); }
            set { EntryWarningWindowBorderColorForLongs = Serialize.StringToBrush(value); }
        }
		
		[XmlIgnore]
        [Display(Name="Entry Warning Window Border Color for Shorts", Description="Entry Warning Window Border Color for Shorts", Order=30, GroupName="Warning Messages")]
        public Brush EntryWarningWindowBorderColorForShorts
        { get; set; }

		[Browsable(false)]
        public string EntryWarningWindowBorderColorForShortsSerializable
        {
            get { return Serialize.BrushToString(EntryWarningWindowBorderColorForShorts); }
            set { EntryWarningWindowBorderColorForShorts = Serialize.StringToBrush(value); }
        }
		

		[NinjaScriptProperty]
		[Display(Name="Use Breakeven", Description="Use Breakeven", Order=11, GroupName="Entry Rules")]
		public bool UseBE
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Target for Breakeven", Description="Choose which Target must be hit top move stop on breakeven", Order=31, GroupName="Entry Rules")]
		public TargetsForBE TargetForBE
		{
			get { return targetForBE; }
			set { targetForBE = value; }
		}
		
		public enum TargetsForBE
	    {
	        
	        T1,
			T2,
	        T3,
			T4
	    }
		
		
		
	
		[NinjaScriptProperty]
		[Display(Name="Breakeven Offset in ticks", Description="Breakeven Offset in ticks", Order=32, GroupName="Entry Rules")]
		public int BEOffset
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Trade T1", Description="Trade T1 of RiskReward Tool", Order=33, GroupName="Entry Rules")]
		public bool TradeT1
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Trade T2", Description="Trade T2 of RiskReward Tool", Order=34, GroupName="Entry Rules")]
		public bool TradeT2
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Trade T3", Description="Trade T3 of RiskReward Tool", Order=35, GroupName="Entry Rules")]
		public bool TradeT3
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Trade T4", Description="Trade T4 of RiskReward Tool", Order=36, GroupName="Entry Rules")]
		public bool TradeT4
		{ get; set; }
		
		[NinjaScriptProperty]
		[Browsable(false)]
		[Display(Name="Print Orders on Output Window", Description="Print Orders on Output Window", Order=37, GroupName="General Settings")]
		public bool PrintOrdersOutputWindow
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Sizing Method", Description="Choose method of defining the amount of risk per trade", Order=38, GroupName="Risk Management")]
		public CalcTypes CalcType
		{
			get { return calcType; }
			set { calcType = value; }
		}
		
		[NinjaScriptProperty]
		[Display(Name="Dollar Amount", Description="Define a fixed dollar amount to risk per trade", Order=39, GroupName="Risk Management")]
		public double UserInputMaxRiskAmountUSD
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="% of Account Balance", Description="Define a fixed percent of the account balance to risk per trade", Order=40, GroupName="Risk Management")]
		public double MaxRiskPercentage
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Number of contracts T1", Description="Target 1 Quantity", Order=41, GroupName="Risk Management")]
		public long ContractsT1
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Number of contracts T2", Description="Target 2 Quantity", Order=42, GroupName="Risk Management")]
		public long ContractsT2
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Number of contracts T3", Description="Target 3 Quantity", Order=43, GroupName="Risk Management")]
		public long ContractsT3
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Number of contracts T4", Description="Target 4 Quantity", Order=44, GroupName="Risk Management")]
		public long ContractsT4
		{ get; set; }
		
		[NinjaScriptProperty]
		[Browsable(false)]
		[Display(Name="Differiantiate Stop Price by This Amount (Ticks)", Description="Differiantiate Stop Price by This Amount (Ticks)", Order=45, GroupName="Risk Management")]
		public int TicksDiffStop
		{ get; set; }
			
		public enum CalcTypes
	    {
	        
	        Static_Lotsize,
			Dollar_Value,
	        Percentage_Account_Balance
	    }
		
		private const string VERSION = "v2.3 13.Mar.2023";
        [Display(Name = "Strategy Version", GroupName = "Strategy Version", Description = "Strategy Version", Order = 46)]
        public string productVersion { get { return VERSION; } }
		
		#endregion
				

	}
}