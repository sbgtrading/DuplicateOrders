﻿using System;
using System.ComponentModel;
using NinjaTrader.NinjaScript.Indicators.ARC;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using System.ComponentModel.DataAnnotations;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using SharpDX;
using SharpDX.Direct2D1;
using System.Xml.Serialization;
using NinjaTrader.Data;
using System.Collections.Concurrent;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	[ARC_CWAPAlgo_CoLicenses(typeof(ARC_CWAPAlgo_ARC_MWPatternFinderZigZag), typeof(ARC_CWAPAlgo_ARC_VolumeCluster))]
	public class ARC_CWAPAlgo : ARC_CWAPAlgo_ARCStrategyBase
	{
		public override string ProductVersion => "v1.0.8 (3/18/2024)";
		public override string ProductInfusionSoftTag => "27867";
		protected override bool AllowIntrabarEntries => true;
		public override bool HasStrategyBasedStops => true;
		public override bool HasStrategyBasedTargets => true;

		private class StructureLine
		{
			public ARC_CWAPAlgo_ZigZagPoint Anchor { get; set; }
			public int? EndBar { get; set; }
		}

		private class CWAP
		{
			public int Bias { get; set; }
			public int StartBar { get; private set; } = -1;
			public StructureLine BosLine { get; set; }
			public int EndBar { get; private set; } = -1;

			private ARC_CWAPAlgo_AverageTracker midlineTracker = new ARC_CWAPAlgo_AverageTracker(int.MaxValue);
			private ARC_CWAPAlgo_StdDevTracker stdDevTracker = new ARC_CWAPAlgo_StdDevTracker(int.MaxValue);

            private readonly ConcurrentDictionary<int, double> value = new ConcurrentDictionary<int, double>();
            private readonly ConcurrentDictionary<int, double> stdDev = new ConcurrentDictionary<int, double>();
            private readonly ISeries<double> clusterCenters;
			public CWAP(ISeries<double> clusterCenters)
			{
				this.clusterCenters = clusterCenters;
			}

			public void AddSample(int bar)
			{
				if (!clusterCenters.IsValidDataPointAt(bar))
					return;

				if (StartBar == -1 || StartBar > bar)
					StartBar = bar;
				if (EndBar == -1 || EndBar < bar)
					EndBar = bar;

				if (value.ContainsKey(bar))
					return;

				midlineTracker.AddSample(clusterCenters.GetValueAt(bar));
				value[bar] = midlineTracker;

				stdDevTracker.AddSample(midlineTracker - clusterCenters.GetValueAt(bar));
				stdDev[bar] = stdDevTracker;
			}

			/// <summary>
			/// Allows resources to be garbage collected
			/// </summary>
			public void Terminate()
			{
				stdDevTracker = null;
				midlineTracker = null;
			}

			private double GetEdge(double stdDevMultiplier, int sideVsBias, int bar = -1)
			{
				if (bar == -1)
					bar = EndBar;

				return bar == -1 ? double.NaN : this[bar, ValueType.Value] + sideVsBias * Bias * stdDevMultiplier * this[bar, ValueType.StdDev];
			}

			public double GetTerminationValue(double stdDevMultiplier, int bar = -1)
			{
				return GetEdge(stdDevMultiplier, -1, bar);
			}
			
			public double GetTradeEdge(double stdDevMultiplier, int bar = -1)
			{
				return GetEdge(stdDevMultiplier, 1, bar);
			}

			public double this[int bar, ValueType valueType]
			{
				get 
				{
					var valDict = valueType == ValueType.Value ? value : stdDev;
                    for (; bar >= StartBar; bar--)
                        if (valDict.TryGetValue(bar, out var barValue))
                            return barValue;

                    return double.NaN;
                }
			}
		}

		private enum ValueType
		{
			StdDev,
			Value
		}
		
		private SessionIterator sessionIterator;
		private ARC_CWAPAlgo_ARC_MWPatternFinderZigZag zigZag;
		private ARC_CWAPAlgo_ARC_VolumeCluster volCluster;
		private readonly List<StructureLine> brokenStructureLines = new List<StructureLine>();
		private readonly List<StructureLine> freshStructureLines = new List<StructureLine>();
		private readonly List<CWAP> terminatedCwap = new List<CWAP>();
		private readonly List<CWAP> freshCwap = new List<CWAP>();
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_CWAPAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "CWAP Algo";
				SwingStrength = 10;
				IncludeWicks = true;
				CWAPStdDevMult = 0.5;
				MinBarsOutsideBarAndBos = 1;
				MinBosLineLength = 10;
				TicksPerCluster = 1;
				MaxCWAPBarsAfterBOSBreak = 1000;

				StopLossBandWidthMultiple = 1;

				ProfitTarget1MaxExcursionMultiple = 1;
				MinTakeProfit = 1;
				MaxTakeProfit = 10000;
			}
			else if (State == State.Configure)
			{
				freshStructureLines.Clear();
				brokenStructureLines.Clear();
				terminatedCwap.Clear();
				freshCwap.Clear();
			}
			else if (State == State.DataLoaded)
			{
				sessionIterator = new SessionIterator(BarsArray[tickBarsIdx]);
				volCluster = ARC_CWAPAlgo_ARC_VolumeCluster(TicksPerCluster);
				AddChartIndicator(zigZag = ARC_CWAPAlgo_ARC_MWPatternFinderZigZag(SwingStrength, IncludeWicks));
				zigZag.ZigZagStroke = ZigZagStroke;
			}
		}

		private void UpdateStructureLines()
		{
			zigZag.Update();
			var barDir = Close[0].ApproxCompare(Open[0]);

			// Look for BOS breaks
			if (barDir != 0)
			{
				foreach (var structureLine in freshStructureLines.Where(l => l.Anchor.Side == barDir).ToList())
				{
					if (Close[0].ApproxCompare(structureLine.Anchor.Price) != barDir) 
						continue;

					structureLine.EndBar = CurrentBar;
					freshStructureLines.Remove(structureLine);

					brokenStructureLines.Add(structureLine);
				}
			}

			// Do nothing if no points
			if (zigZag.SwingPoints.Count == 0)
				return;

			for (var i = Math.Max(0, zigZag.SwingPoints.Count - 2); i < zigZag.SwingPoints.Count; i++)
			{
				// Skip the second last point if it isn't on the same bar as the last
				if (i == zigZag.SwingPoints.Count - 2 && zigZag.SwingPoints.Skip(zigZag.SwingPoints.Count - 2).Select(s => s.Bar).Distinct().Count() == 2)
					continue;

				// Kill fresh lines who haven't broken while a new anchor formed on their side
				if (i >= 3)
					freshStructureLines.RemoveAll(l => l.Anchor == zigZag.SwingPoints[i - 3]);

				freshStructureLines.Add(new StructureLine { Anchor = zigZag.SwingPoints[i] });
			}
		}

		private void UpdateCWAP()
		{
			volCluster.Update();
			if (BarsInProgress == 0)
				freshCwap.ForEach(c => c.AddSample(CurrentBar));

			if (Time[0] >= sessionIterator.ActualSessionEnd)
				TerminateCWAPs(freshCwap.ToArray());

			sessionIterator.GetNextSession(Time[0], true);

			if (BarsInProgress == tickBarsIdx)
			{
				// Terminate CWAPS that traded through their termination value
				var newTerminatedCwaps = freshCwap
						.Where(cwap => !double.IsNaN(cwap.GetTerminationValue(CWAPStdDevMult)) && Close[0].ApproxCompare(cwap.GetTerminationValue(CWAPStdDevMult)) == -cwap.Bias)
						.ToArray();
				TerminateCWAPs(newTerminatedCwaps);
				return;
			}

			if (BarsInProgress == 0)
				TerminateCWAPs(freshCwap
					.Where(c => CurrentBar - c.BosLine.EndBar.Value + 1 > MaxCWAPBarsAfterBOSBreak)
					.ToArray());

			// If no BOS this bar, don't reset CWAP
			var lineOverriddenThisBar = brokenStructureLines.LastOrDefault(l => l.EndBar == CurrentBar);
			if (lineOverriddenThisBar == null)
				return;

			// Find the CWAP anchor point
			var cwapAnchorSide = -lineOverriddenThisBar.Anchor.Side;
			var anchorPoint = zigZag.SwingPoints
				.OfType<ARC_CWAPAlgo_ZigZagPoint>()
				.Reverse()
				.TakeWhile(p => p.Bar.ARC_CWAPAlgo_InRange(lineOverriddenThisBar.Anchor.Bar, CurrentBar))
				.FirstOrDefault(p => p.Side == cwapAnchorSide);

			// If no anchor point within our BOS, don't reset CWAP
			if (anchorPoint == null)
				return;

			// If CWAP is redundant, do nothing
			if (freshCwap.Any(c => c.StartBar == anchorPoint.Bar))
				return;

			// Reset CWAP by back filling StdDev to the anchor point
			var newCwap = new CWAP(volCluster.ClusterCenter)
			{
				Bias = -anchorPoint.Side,
				BosLine = lineOverriddenThisBar
			};
			freshCwap.Add(newCwap);
			for (var i = anchorPoint.Bar; i <= CurrentBar; i++)
				newCwap.AddSample(i);
		}

		private void TerminateCWAPs(params CWAP[] cwaps)
		{
			foreach (var cwap in cwaps)
			{
				cwap.Terminate();
				terminatedCwap.Add(cwap);
				freshCwap.Remove(cwap);
			}
		}

		private int firstTickOfCurrentPrimaryBar = -1;
		protected override void OnPrimaryBar()
		{
			volCluster.Update(CurrentBar, BarsInProgress);
            firstTickOfCurrentPrimaryBar = CurrentBars[tickBarsIdx] + 1;
			UpdateStructureLines();
			UpdateCWAP();
		}

		protected override void OnTickBar()
		{
			volCluster.Update(CurrentBar, BarsInProgress);
			UpdateCWAP();
			var touchedCwaps = freshCwap
				.Where(c =>
				{
					var thresh = c.GetTradeEdge(CWAPStdDevMult);
					return Close[0].ApproxCompare(thresh) != Close[1].ApproxCompare(thresh);
				})
				.ToArray();
			if (touchedCwaps.Length == 0)
				return;

			// Start with the direction in which the most CWAPs were touched, and look for a valid trade
			foreach (var group in touchedCwaps.GroupBy(c => c.Bias).OrderByDescending(g => g.Count()))
			{
				// Find the CWAPs for which this tick triggered a trade
				var validTradeCwaps = new List<CWAP>();
				foreach (var cwap in group.ToList())
				{
					// Ensure the tick came to the trade zone from outside it
					var tradePrice = cwap.GetTradeEdge(CWAPStdDevMult);
					if (Close[0].ApproxCompare(tradePrice) == cwap.Bias)
						continue;

					var barsOutsideBandAndBos = 0;
					for (var i = 0; i < CurrentBars[0] - cwap.BosLine.EndBar && barsOutsideBandAndBos < MinBarsOutsideBarAndBos; i++)
					{
						// Ensure the bar is fully on the other side of the BOS
						if ((cwap.Bias == 1 ? Lows : Highs)[0][i].ApproxCompare(cwap.BosLine.Anchor.Price) != cwap.Bias)
							continue;

						// Ensure the bar isn't touching the band at all
						var cwapRange = new []
						{
							cwap.GetTerminationValue(CWAPStdDevMult, CurrentBars[0] - i),
							cwap.GetTradeEdge(CWAPStdDevMult, CurrentBars[0] - i)
						};
						var outsideBand = new[] { Lows, Highs }
							.Select(s => s[0][i])
							.All(c => !c.ARC_CWAPAlgo_InRange(cwapRange[0], cwapRange[1]));
						if (!outsideBand)
							continue;

						barsOutsideBandAndBos++;
					}

					if (barsOutsideBandAndBos >= MinBarsOutsideBarAndBos)
						validTradeCwaps.Add(cwap);
				}
				
				// Terminate the valid trade CWAPs (valid other than min bos line len) and queue the entry
				TerminateCWAPs(validTradeCwaps.ToArray());

				// Unmark any CWAPs as valid if their BOS lines are beneath the requirement
				validTradeCwaps.RemoveAll(c => c.BosLine.EndBar - c.BosLine.Anchor.Bar < MinBosLineLength + 1);

				var tradeDir = group.Key;
				if (!TradeAllowed(tradeDir))
					continue;

				// Skip entry if no valid CWAPs found
				if (validTradeCwaps.Count == 0)
					continue;

				// Get and validate the SL
				var dir = validTradeCwaps[0].Bias;
				var sl = EnableAlgoDefinedStopLosses ? Close[0] - dir * validTradeCwaps[0][CurrentBars[0], ValueType.StdDev] * StopLossBandWidthMultiple * CWAPStdDevMult * 2 : (double?) null;
				if (sl != null && !TradeAllowedWithStop(Close[0], sl.Value))
					continue;

				// Get and validate the TP
				var tp = (double?)null;
				if (EnableAlgoDefinedTargets)
				{
					// Iterate through tick then primary bars looking for the max excursion since BOS
					var mfe = Close[0];
					for (var i = 1; i < CurrentBar - firstTickOfCurrentPrimaryBar; i++)
						if (Close[i].ApproxCompare(mfe) == dir)
							mfe = Close[i];
					var primaryBarsCompSeries = dir == 1 ? Highs[0] : Lows[0];
					for (var i = 0; i < CurrentBars[0] - validTradeCwaps[0].BosLine.EndBar; i++)
						if (primaryBarsCompSeries[i].ApproxCompare(mfe) == dir)
							mfe = primaryBarsCompSeries[i];
					tp = Close[0] + dir * ProfitTarget1MaxExcursionMultiple * Math.Abs(Close[0] - mfe);
				}
				if (tp != null && !(Math.Abs(Close[0] - tp.Value) / TickSize).ARC_CWAPAlgo_InRange(MinTakeProfit, MaxTakeProfit))
					continue;

				QueueEntry(validTradeCwaps[0].Bias, stopLossPrice: sl, profitTargetPrice: tp);
				return;
			}
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);

			BosUpStroke.RenderTarget = RenderTarget;
			BosDownStroke.RenderTarget = RenderTarget;
			CwapOutlineStroke.RenderTarget = RenderTarget;
			CwapMidlineStroke.RenderTarget = RenderTarget;

			// Draw BOS structure lines
			foreach (var line in brokenStructureLines)
			{
				var y = chartScale.GetYByValue(line.Anchor.Price);
				var pts = new[] { line.Anchor.Bar, line.EndBar ?? (ChartBars.ToIndex + 1) }
					.Select(b => new Vector2(chartControl.GetXByBarIndex(ChartBars, b), y))
					.ToArray();
				var stroke = line.Anchor.Side == 1 ? BosUpStroke : BosDownStroke;
				RenderTarget.DrawLine(pts[0], pts[1], stroke.BrushDX, stroke.Width, stroke.StrokeStyle);
			}

			// Draw regions
			var oldAaMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = AntialiasMode.PerPrimitive;
			try
			{
				foreach (var cwap in freshCwap.Concat(terminatedCwap).Where(c => c.StartBar != -1).ToArray())
				{

					var cwapPoints = new List<ARC_CWAPAlgo_ZigZagPoint>();
					var lowBoundingPoints = new List<Vector2>();
					var highBoundingPoints = new List<Vector2>();
					for (var bar = cwap.StartBar; bar <= cwap.EndBar; bar++)
					{
						if (!bar.ARC_CWAPAlgo_InRange(ChartBars.FromIndex - 1, ChartBars.ToIndex + 1))
							continue;

						var offsetVector = new Vector2(0, chartScale.GetPixelsForDistance(cwap[bar, ValueType.StdDev] * CWAPStdDevMult));
						var midlinePoint = new Vector2(chartControl.GetXByBarIndex(ChartBars, bar), chartScale.GetYByValue(cwap[bar, ValueType.Value]));
						highBoundingPoints.Add(midlinePoint + offsetVector);
						lowBoundingPoints.Insert(0, midlinePoint - offsetVector);
						cwapPoints.Add(new ARC_CWAPAlgo_ZigZagPoint(0, bar, cwap[bar, ValueType.Value]));
					}

					if (highBoundingPoints.Count <= 2)
						continue;

					// Draw midline
					RenderTarget.ARC_CWAPAlgo_DrawZigZag(this, chartScale, cwapPoints, CwapMidlineStroke.BrushDX, CwapMidlineStroke.Width, CwapMidlineStroke.DashStyleHelper, true);

					// Fill region
					using var fillBrush = ((System.Windows.Media.Brush)CwapFill).ToDxBrush(RenderTarget);
					RenderTarget.ARC_CWAPAlgo_DrawRegion(false, CwapOutlineStroke.BrushDX, fillBrush, lowBoundingPoints.Concat(highBoundingPoints).ToArray());
				}
			}
			finally
			{
				if (RenderTarget != null)
					RenderTarget.AntialiasMode = oldAaMode;
			}
		}

		#region Parameters
		#region Strategy Parameters
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Order = 0, Name = "Swing Strength", GroupName = StrategyParameterGroupName, Description = "Number of bars used to identify a swing high or low")]
		public int SwingStrength { get; set; }

		[NinjaScriptProperty]
		[Display(Order = 1, Name = "Include Wicks in Pivots", GroupName = StrategyParameterGroupName, Description = "Whether or not to use wicks (vs closes) for pivot points")]
		public bool IncludeWicks { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Order = 2, Name = "Min BOS Line Length", GroupName = StrategyParameterGroupName)]
		public int MinBosLineLength { get; set; }
		
		[NinjaScriptProperty, Range(1e-4, double.MaxValue)]
		[Display(Order = 3, Name = "CWAP Std Dev Mult.", GroupName = StrategyParameterGroupName)]
		public double CWAPStdDevMult { get; set; }
		
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Order = 4, Name = "Ticks per Cluster Price Levels", GroupName = StrategyParameterGroupName)]
		public int TicksPerCluster { get; set; }
		
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Order = 5, Name = "Max CWAP Length After BOS", GroupName = StrategyParameterGroupName)]
		public int MaxCWAPBarsAfterBOSBreak { get; set; }

		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[Display(Order = 6, Name = "Min Bars Outside Band and BOS", GroupName = StrategyParameterGroupName)]
		public int MinBarsOutsideBarAndBos { get; set; }
		
		[NinjaScriptProperty, Range(1e-5, double.MaxValue)]
		[ARC_CWAPAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_CWAPAlgo_PropComparisonType.EQ, ARC_CWAPAlgo_BoolEnum.True)]
		[Display(Order = 1, Name = "Stop Loss (Band Width Mult.)", GroupName = StopLossGroupName)]
		public double StopLossBandWidthMultiple { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_CWAPAlgo_HideUnless(nameof(EnableAlgoDefinedTargetsEnum), ARC_CWAPAlgo_PropComparisonType.EQ, ARC_CWAPAlgo_BoolEnum.True)]
		[Display(Name = "Profit Target 1 (Max Excursion Mult.)", Order = 0, GroupName = TargetsGroupName)]
		public double ProfitTarget1MaxExcursionMultiple { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[ARC_CWAPAlgo_HideUnless(nameof(EnableAlgoDefinedTargetsEnum), ARC_CWAPAlgo_PropComparisonType.EQ, ARC_CWAPAlgo_BoolEnum.True)]
		[Display(Order = 1, Name = "Min Take Profit (Ticks)", GroupName = TargetsGroupName)]
		public int MinTakeProfit { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[ARC_CWAPAlgo_HideUnless(nameof(EnableAlgoDefinedTargetsEnum), ARC_CWAPAlgo_PropComparisonType.EQ, ARC_CWAPAlgo_BoolEnum.True)]
		[Display(Order = 2, Name = "Max Take Profit (Ticks)", GroupName = TargetsGroupName)]
		public int MaxTakeProfit { get; set; }
		#endregion

		#region Visual Parameters
		[Display(Name = "BOS Up Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 0)]
		public Stroke BosUpStroke { get; set; } = new Stroke(Brushes.Blue, DashStyleHelper.Dash, 3);
		
		[Display(Name = "BOS Down Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 1)]
		public Stroke BosDownStroke { get; set; } = new Stroke(Brushes.Maroon, DashStyleHelper.Dash, 3);

		[Display(Name = "CWAP Outline Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 2)]
		public Stroke CwapOutlineStroke { get; set; } = new Stroke(Brushes.Lime, DashStyleHelper.Solid, 2);

		[Display(Name = "CWAP Midline Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 3)]
		public Stroke CwapMidlineStroke { get; set; } = new Stroke(Brushes.Lime, DashStyleHelper.Dash, 2);
		
		[XmlIgnore]
		[Display(Name = "CWAP Fill", GroupName = StrategyVisualsParameterGroupName, Order = 4)]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_CWAPAlgo_EnhancedBrushPicker")]
		public ARC_CWAPAlgo_EnhancedBrush CwapFill { get; set; } = new ARC_CWAPAlgo_EnhancedBrush(Brushes.Lime, 0.5f);

		[Browsable(false)]
		public string CwapFillSerializable
		{
			get => CwapFill;
			set => CwapFill = value;
		}

		[Display(Name = "Zig Zag Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 5)]
		public Stroke ZigZagStroke { get; set; } = new Stroke(Brushes.White, DashStyleHelper.Solid, 2);
		#endregion
		#endregion
	}
}

public enum ARC_CWAPAlgo_BOSPullbackThreshType
{
	Tick,
	ATR,
	Percent
}