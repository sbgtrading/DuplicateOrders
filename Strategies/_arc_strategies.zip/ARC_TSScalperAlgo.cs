using System;
using System.Collections.Generic;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using System.ComponentModel.DataAnnotations;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using System.Windows.Media;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using System.ComponentModel;
using System.Xml.Serialization;
using System.Linq;
using NinjaTrader.Core;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui.Tools;
using SharpDX;
using SharpDX.DirectWrite;
using Point = System.Windows.Point;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_TSScalperAlgo : ARC_TSScalperAlgo_ARCStrategyBase, ARC_TSScalperAlgo_IPaintsDomBars, ARC_TSScalperAlgo_ITracksDomBars
	{
		public override string ProductVersion => "v1.0.1 (12/16/2024)";
		public override string ProductInfusionSoftTag => "41293";
		protected override bool AllowIntrabarEntries => EnableBlockTrades;
		public override bool HasStrategyBasedStops => true;

		private Series<HashSet<Tuple<ARC_TSScalperAlgo_BidAsk, double>>> bigMoneyLevels;
		private HashSet<Tuple<ARC_TSScalperAlgo_BidAsk, double>> curBarBlockTrades;
		private Series<HashSet<Tuple<ARC_TSScalperAlgo_BidAsk, double>>> blockTrades;
		private ARC_TSScalperAlgo_DomBarTracker<ARC_TSScalperAlgo> domTracker;
		private Series<ARC_TSScalperAlgo_DomProfile> barSeries;
		private int tickDir;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_TSScalperAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "TS Scalper";
				MaximumBarsLookBack = MaximumBarsLookBack.Infinite;

				TicksPerDomLevel = 1;
				VolumeDivisor = 1;

				EnableBigMoney = true;
				AvgSizeAtPriceLookback = 3;
				MinTotalBigMoneyPrints = 4;
				MinBigMoneyPrintsPerSide = 1;
				BigMoneyHhLlLookback = 3;
				MinBodySize = 0;
				BigMoneyMultiplier = 1;

				EnableBlockTrades = true;
				BlockTradeMinSize = 100;

				StopLossOffsetType = ARC_TSScalperAlgo_TsScalperStopLossOffsetType.Ticks;
				StopLossOffset = 0;

				DomTextColor = Brushes.Black;
				BidBigMoneyColor = Brushes.PaleGreen;
				AskBigMoneyColor = Brushes.Tomato;
				BidBlockTradeColor = Brushes.LightGreen;
				AskBlockTradeColor = Brushes.Tomato;
			}
			else if (State == State.Configure)
			{
				curBarBlockTrades = new HashSet<Tuple<ARC_TSScalperAlgo_BidAsk, double>>();
				tickDir = 0;
			}
			else if (State == State.DataLoaded)
			{
				domTracker = new ARC_TSScalperAlgo_DomBarTracker<ARC_TSScalperAlgo>(this, tickBarsIdx);
				barSeries = new Series<ARC_TSScalperAlgo_DomProfile>(this, MaximumBarsLookBack.Infinite);
				bigMoneyLevels = new Series<HashSet<Tuple<ARC_TSScalperAlgo_BidAsk, double>>>(this, MaximumBarsLookBack.Infinite);
				blockTrades = new Series<HashSet<Tuple<ARC_TSScalperAlgo_BidAsk, double>>>(this, MaximumBarsLookBack.Infinite);
			}
		}

		protected override void OnPrimaryBar()
		{
			if (CurrentBar == 0)
				return;

			if (barSeries[0] == null)
				return;

			blockTrades[0] = curBarBlockTrades;
			curBarBlockTrades = new HashSet<Tuple<ARC_TSScalperAlgo_BidAsk, double>>();

			var avgSizeAtLevel = new Dictionary<ARC_TSScalperAlgo_BidAsk, double>
			{
				[ARC_TSScalperAlgo_BidAsk.Bid] = double.MaxValue, 
				[ARC_TSScalperAlgo_BidAsk.Ask] = double.MaxValue
			};
			if (CurrentBar > AvgSizeAtPriceLookback)
			{
				foreach (var side in (ARC_TSScalperAlgo_BidAsk[])Enum.GetValues(typeof(ARC_TSScalperAlgo_BidAsk)))

				{
					var validSizes = Enumerable.Range(1, AvgSizeAtPriceLookback)
						.Where(i => i <= CurrentBar)
						.Select(i => barSeries[i])
						.SelectMany(b => b.Values)
						.Select(r => side == ARC_TSScalperAlgo_BidAsk.Bid ? r.Bid : r.Ask)
						.Where(b => b > 0)
						.ToArray();

					avgSizeAtLevel[side] = validSizes.Length == 0 ? float.MaxValue : validSizes.Average();
				}
			}

			bigMoneyLevels[0] = new HashSet<Tuple<ARC_TSScalperAlgo_BidAsk, double>>();

			foreach (var row in barSeries[0])
			foreach (var side in (ARC_TSScalperAlgo_BidAsk[])Enum.GetValues(typeof(ARC_TSScalperAlgo_BidAsk)))
			{
				if (row.Value[side] > avgSizeAtLevel[side] * BigMoneyMultiplier)
					bigMoneyLevels[0].Add(new Tuple<ARC_TSScalperAlgo_BidAsk, double>(side, row.Key));
			}

			var dir = Close[0].ApproxCompare(Open[0]);
			if (dir == 0)
				return;

			if (GetBodyRatio(0) < MinBodySize / 100d)
				return;

			if (!EnableBigMoney)
				return;

			if (bigMoneyLevels[0].Count < MinTotalBigMoneyPrints || new [] { ARC_TSScalperAlgo_BidAsk.Bid, ARC_TSScalperAlgo_BidAsk.Ask }.Min(t => bigMoneyLevels[0].Count(l => l.Item1 == t)) < MinBigMoneyPrintsPerSide)
				return;

			var compareSeries = dir == 1 ? Low : High;
			for (var i = 1; i <= Math.Min(BigMoneyHhLlLookback, CurrentBar); i++)
			{
				if (compareSeries[0].ApproxCompare(compareSeries[i]) != -dir)
					return;
			}

			var sl = (double?)null;
			if (EnableAlgoDefinedStopLosses)
			{
				var offsetUnit = StopLossOffsetType == ARC_TSScalperAlgo_TsScalperStopLossOffsetType.Ticks ? TickSize : (High[0] - Low[0]) / 100;
				sl = (dir == 1 ? Low : High)[0] - dir * offsetUnit * StopLossOffset;
				if (!TradeAllowedWithStop(dir, Close[0], sl.Value))
					return;
			}

			if (!TradeAllowed(dir))
				return;

			QueueEntry(dir, stopLossPrice: sl);
		}

		protected override void OnTickBar()
		{
			var dir = Close[0].ApproxCompare(Close[1]);
			if (dir == 0)
				dir = tickDir;
			tickDir = dir;
			
			if (CurrentBar < 1 || Volume[0] < BlockTradeMinSize)
				return;

			if (dir == 0)
				return;

			var collection = (!domTracker.FirstTickOfNewDom && !domTracker.PendingReset) || BarsPeriods[0].BarsPeriodType.ARC_TSScalperAlgo_IsTimeBased() || Time[0] > Times[0][0] ? curBarBlockTrades : blockTrades[0];
			if (collection == null)
				return;

			collection.Add(new Tuple<ARC_TSScalperAlgo_BidAsk, double>(dir == 1 ? ARC_TSScalperAlgo_BidAsk.Ask : ARC_TSScalperAlgo_BidAsk.Bid, Close[0]));

			if (!EnableBlockTrades || !TradeAllowed(dir))
				return;
			
			QueueEntry(dir);
		}

		protected override void OnBarUpdate()
		{
			domTracker.HandleBarUpdate();
			
			if (BarsInProgress == 0)
				barSeries[0] = BarsPeriod.BarsPeriodType.ARC_TSScalperAlgo_IsTimeBased() ? domTracker.LastLeveledBarProfile : domTracker.LeveledBarProfile;
			else if (BarsInProgress == tickBarsIdx && CurrentBars[0] >= 0 && barSeries[0].ParentId == domTracker.CurrentBarProfileId)
				barSeries[0] = domTracker.LeveledBarProfile;

			base.OnBarUpdate();
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			for (var i = ChartBars.FromIndex; i <= ChartBars.ToIndex; i++)
			{
				var profile = i == ChartBars.Count - 1 ? domTracker.LeveledBarProfile : barSeries.GetValueAt(i);
				if (profile == null || profile.Count == 0)
					continue;

				var font = new SimpleFont("Consolas", 12);
				var domCellsSize = this.ARC_TSScalperAlgo_GetDomTargetCellSize(chartControl, chartScale);
				if (domCellsSize.Width.ApproxCompare(0) == 0)
					continue;

				domCellsSize = new Size2F
				{
					Width = domCellsSize.Width * 0.9f,
					Height = domCellsSize.Height
				};
				const float minFontSize = 5;
				profile.ARC_TSScalperAlgo_SizeFontToFit(this, font, domCellsSize, minFontSize);
				if (font.Size == 0)
					continue;

				var levels = bigMoneyLevels.GetValueAt(i);
				var trades = blockTrades.GetValueAt(i);
				if (levels == null && trades == null)
					continue;

				using var bidBigMoneyBrush = BidBigMoneyColor.ToDxBrush(RenderTarget);
				using var askBigMoneyBrush = AskBigMoneyColor.ToDxBrush(RenderTarget);
				using var bidBlockTradeColor = BidBlockTradeColor.ToDxBrush(RenderTarget);
				using var askBlockTradeColor = AskBlockTradeColor.ToDxBrush(RenderTarget);
				this.ARC_TSScalperAlgo_RenderDom(chartControl, chartScale, profile, i, domCellsSize, font, (tf, text, placement, row, price, side, textBrush) =>
				{
					tf.TextAlignment = side == ARC_TSScalperAlgo_BidAsk.Bid ? TextAlignment.Trailing : TextAlignment.Leading;
					using var tl = new TextLayout(Globals.DirectWriteFactory, text, tf, domCellsSize.Width, domCellsSize.Height);

					var dir = side == ARC_TSScalperAlgo_BidAsk.Bid ? 1 : -1; 
					if (levels?.Contains(new Tuple<ARC_TSScalperAlgo_BidAsk, double>(side, price)) ?? false)
					{
						RenderTarget.FillRectangle(new RectangleF
						{
							X = placement.X,
							Y = placement.Y,
							Width = domCellsSize.Width,
							Height = domCellsSize.Height
						}, dir == 1 ? bidBigMoneyBrush : askBigMoneyBrush);
					}

					if (trades?.Contains(new Tuple<ARC_TSScalperAlgo_BidAsk, double>(side, price)) ?? false)
					{
						var width = ChartBars.Properties.ChartStyle.BarWidth;
						var arrowSide = -dir;
						var trianglePlacement = new Point(chartControl.GetXByBarIndex(ChartBars, i) - dir * width / 2, placement.Y + domCellsSize.Height / 2);
						var color = dir == 1 ? bidBlockTradeColor : askBlockTradeColor;
						RenderTarget.ARC_TSScalperAlgo_DrawHorizontalTriangle(trianglePlacement, (float) width, color, 0, arrowSide, color);
					}

					RenderTarget.DrawTextLayout(placement, tl, textBrush);
				});
			}
		}

		#region Parameters
		#region General
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Ticks Per Level", Order = 0, GroupName = StrategyParameterGroupName)]
		public int TicksPerDomLevel { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Volume Divisor", Order = 1, GroupName = StrategyParameterGroupName, Description = "The number to divide all displayed volumes by")]
		public int VolumeDivisor { get; set; }

		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_TSScalperAlgo_HideOthersIf(ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_BoolEnum.False, Properties = new[] { nameof(MinTotalBigMoneyPrints), nameof(MinBigMoneyPrintsPerSide), nameof(BigMoneyHhLlLookback), nameof(MinBodySize) })]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Enable Big Money Prints", Order = 2, GroupName = StrategyParameterGroupName)]
		public ARC_TSScalperAlgo_BoolEnum EnableBigMoneyEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool EnableBigMoney
		{
			get => EnableBigMoneyEnum == ARC_TSScalperAlgo_BoolEnum.True;
			set => EnableBigMoneyEnum = value ? ARC_TSScalperAlgo_BoolEnum.True : ARC_TSScalperAlgo_BoolEnum.False;
		}
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Avg. Size At Price Lookback", Order = 3, GroupName = StrategyParameterGroupName)]
		public int AvgSizeAtPriceLookback { get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Min. Total Big Money Prints", Order = 4, GroupName = StrategyParameterGroupName)]
		public int MinTotalBigMoneyPrints { get; set; }
		
		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "Min. Big Money Prints Per Side", Order = 5, GroupName = StrategyParameterGroupName)]
		public int MinBigMoneyPrintsPerSide { get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Big Money HH/LL Lookback", Order = 6, GroupName = StrategyParameterGroupName)]
		public int BigMoneyHhLlLookback { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "Min Body Size %", Order = 7, GroupName = StrategyParameterGroupName)]
		public int MinBodySize { get; set; }
		
		[NinjaScriptProperty, Range(0.0001, double.MaxValue)]
		[Display(Name = "Big Money Multiplier", Order = 8, GroupName = StrategyParameterGroupName)]
		public double BigMoneyMultiplier { get; set; }

		[NinjaScriptProperty, XmlIgnore]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Enable Block Trades", Order = 9, GroupName = StrategyParameterGroupName)]
		public ARC_TSScalperAlgo_BoolEnum EnableBlockTradesEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool EnableBlockTrades
		{
			get => EnableBlockTradesEnum == ARC_TSScalperAlgo_BoolEnum.True;
			set => EnableBlockTradesEnum = value ? ARC_TSScalperAlgo_BoolEnum.True : ARC_TSScalperAlgo_BoolEnum.False;
		}

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Min Block Trade Size", Order = 10, GroupName = StrategyParameterGroupName)]
		public int BlockTradeMinSize { get; set; }
		#endregion

		#region Stop Loss Params
		[NinjaScriptProperty, ARC_TSScalperAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_BoolEnum.True)]
		[Display(Name = "SL Offset Type", Order = 0, GroupName = StopLossGroupName)]
		public ARC_TSScalperAlgo_TsScalperStopLossOffsetType StopLossOffsetType { get; set; }
		
		[NinjaScriptProperty, ARC_TSScalperAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_BoolEnum.True)]
		[Display(Name = "SL Offset", Order = 1, GroupName = StopLossGroupName)]
		public int StopLossOffset { get; set; }
		#endregion

		#region Visual Parameters
		private const string VisualParameterGroupName = "Visuals";

		[XmlIgnore]
		[Display(Name = "Text", Order = 0, GroupName = VisualParameterGroupName)]
		public Brush DomTextColor { get; set; }

		[Browsable(false)]
		public string DomTextColorSerialize
		{
			get => Serialize.BrushToString(DomTextColor);
			set => DomTextColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Big Money Bid Color", Order = 1, GroupName = VisualParameterGroupName)]
		public Brush BidBigMoneyColor { get; set; }

		[Browsable(false)]
		public string BidBigMoneyColorSerialize
		{
			get => Serialize.BrushToString(BidBigMoneyColor);
			set => BidBigMoneyColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Big Money Ask Color", Order = 2, GroupName = VisualParameterGroupName)]
		public Brush AskBigMoneyColor { get; set; }

		[Browsable(false)]
		public string AskBigMoneyColorSerialize
		{
			get => Serialize.BrushToString(AskBigMoneyColor);
			set => AskBigMoneyColor = Serialize.StringToBrush(value);
		}
		
		[XmlIgnore]
		[Display(Name = "Block Trade Bid Color", Order = 3, GroupName = VisualParameterGroupName)]
		public Brush BidBlockTradeColor { get; set; }

		[Browsable(false)]
		public string BidBlockTradeColorSerialize
		{
			get => Serialize.BrushToString(BidBlockTradeColor);
			set => BidBlockTradeColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Block Trade Ask Color", Order = 4, GroupName = VisualParameterGroupName)]
		public Brush AskBlockTradeColor { get; set; }

		[Browsable(false)]
		public string AskBlockTradeColorSerialize
		{
			get => Serialize.BrushToString(AskBlockTradeColor);
			set => AskBlockTradeColor = Serialize.StringToBrush(value);
		}
		#endregion
		#endregion
	}

	public enum	ARC_TSScalperAlgo_TsScalperStopLossOffsetType
	{
		Ticks,
		PercentOfHLRange
	}
}