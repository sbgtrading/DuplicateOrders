﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using NinjaTrader.Core.FloatingPoint;
using System.Collections.Generic;
using System.Windows.Media;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.NinjaScript.Indicators.ARC;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using NinjaTrader.Gui;
using System.Xml.Serialization;
using System.Linq;
using NinjaTrader.Data;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	[ARC_VABOAlgo_CoLicenses(typeof(ARC_VABOAlgo_ARC_PeriodicVolumeProfile))]
	public class ARC_VABOAlgo : ARC_VABOAlgo_ARCStrategyBase, ARC_VABOAlgo_ISupportsPeriodicVolumeProfile
	{
		public override string ProductVersion => "v1.0.5 (8/19/2024)";
		public override string ProductInfusionSoftTag => "37583";
		public override bool HasStrategyBasedStops => true;

		[Browsable(false), XmlIgnore]
		public Series<double> VAH => Values[0];

		[Browsable(false), XmlIgnore]
		public Series<double> POC => Values[1];

		[Browsable(false), XmlIgnore]
		public Series<double> VAL => Values[2];

		private ARC_VABOAlgo_PeriodicVolumeProfileTracker<ARC_VABOAlgo> profileTracker;
		private int tradesInZone;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_VABOAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "VABO Algo";

				MinutesPerVolumeProfile = 30;
				RecalculationFrequencyMinutes = 1;
				ValueAreaPercent = 70;
				MinBarsBeforeSignal = 5;
				MinVABoundEntryDistance = 2;
				MaxVABoundEntryDistance = 10;
				MaxSignalsPerZone = 3;
				FreezeVAPlots = false;
				MinClosesInsideValueArea = 1;
					 
				StopLossOffset = 0;

				SessionBreakStroke = new Stroke(Brushes.Yellow, DashStyleHelper.Solid, 2);
				ValueAreaHighStroke = new Stroke(Brushes.Red, DashStyleHelper.Solid, 2);
				PointOfControlStroke = new Stroke(Brushes.Yellow, DashStyleHelper.Solid, 2);
				ValueAreaLowStroke = new Stroke(Brushes.Blue, DashStyleHelper.Solid, 2);
			}
			else if (State == State.Configure)
			{
				AddPlot(ValueAreaHighStroke, PlotStyle.Hash, "VAH");
				AddPlot(PointOfControlStroke, PlotStyle.Hash, "POC");
				AddPlot(ValueAreaLowStroke, PlotStyle.Hash, "VAL");
				tradesInZone = 0;
				profileTracker = new ARC_VABOAlgo_PeriodicVolumeProfileTracker<ARC_VABOAlgo>(this, this.ARC_VABOAlgo_EnsureDataSeriesAdded(AddDataSeries, BarsPeriodType.Minute, 1), tickBarsIdx, () => DrawingTools.Draw.VerticalLine(this, $"Tag{Guid.NewGuid()}", 0, SessionBreakStroke.Brush, SessionBreakStroke.DashStyleHelper, (int) SessionBreakStroke.Width));
			}
		}

		private int closesInsideSinceEntry = 0;
		protected override void OnPrimaryBar()
		{
			if (CurrentBars.Any(cb => cb <= 0))
				return;

			if (profileTracker.ZoneStartPrimaryBar >= CurrentBar - 1)
			{
				tradesInZone = 0;
				closesInsideSinceEntry = 0;
			}

			var curClosesInsideSinceEntry = closesInsideSinceEntry;
			if (Close[0].ARC_VABOAlgo_InRange(VAL[0], VAH[0], false)) 
				curClosesInsideSinceEntry = closesInsideSinceEntry++;
			else
				closesInsideSinceEntry = 0;

			if (curClosesInsideSinceEntry < MinClosesInsideValueArea)
				return;

			if (tradesInZone >= MaxSignalsPerZone)
				return;

			if (CurrentBar - profileTracker.ZoneStartPrimaryBar < MinBarsBeforeSignal)
				return;

			var entryRange = new Dictionary<int, double>
			{
				[-1] = VAL[0] - MinVABoundEntryDistance * TickSize,
				[1] = VAH[0] + MinVABoundEntryDistance * TickSize
			};

			if (Close[0].ARC_VABOAlgo_InRange(entryRange[-1], entryRange[1], false))
				return;

			var dir = Close[0].ApproxCompare(entryRange[1]) != -1 ? 1 : -1;
			if (!TradeAllowed(dir))
				return;

			if (Math.Abs(Close[0] - (dir == 1 ? VAH : VAL)[0]) / TickSize > MaxVABoundEntryDistance)
				return;

			var sl = (double?)null;
			if (EnableAlgoDefinedStopLosses)
			{
				if (AlgoStopLossType == ARC_VABOAlgo_VABOAlgoStopLossType.POC)
					sl = POC[0];
				else
					sl = (dir == 1) == (AlgoStopLossType == ARC_VABOAlgo_VABOAlgoStopLossType.NearVABound) ? VAH[0] : VAL[0];

				sl -= dir * StopLossOffset * TickSize;
				if (!TradeAllowedWithStop(dir, Close[0], sl.Value))
					return;
			}

			closesInsideSinceEntry = 0;
			tradesInZone++;
			QueueEntry(dir, 1, stopLossPrice: sl);
		}

        protected override void OnBarUpdate()
        {
            profileTracker.OnBarUpdate();
            base.OnBarUpdate();
        }

        #region Parameters
        #region General
        [NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "Minutes Per Volume Profile", GroupName = StrategyParameterGroupName, Order = 0)]
		public int MinutesPerVolumeProfile { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "Recalculation Frequency (Minutes)", GroupName = StrategyParameterGroupName, Order = 1)]
		public int RecalculationFrequencyMinutes { get; set; }

		[NinjaScriptProperty, Range(0, 100)]
		[Display(Name = "Value Area (%)", GroupName = StrategyParameterGroupName, Order = 2)]
		public int ValueAreaPercent { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "Min Bars Before Signal", GroupName = StrategyParameterGroupName, Order = 3)]
		public int MinBarsBeforeSignal { get; set; }

		[NinjaScriptProperty, Range(int.MinValue, int.MaxValue)]
		[Display(Name = "Min VAH/VAL Entry Distance (Ticks)", GroupName = StrategyParameterGroupName, Order = 4)]
		[XmlElement("EntryOffset")]
		public int MinVABoundEntryDistance { get; set; }
		
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "Max VAH/VAL Entry Distance (Ticks)", GroupName = StrategyParameterGroupName, Order = 5)]
		public int MaxVABoundEntryDistance { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "Max Signals Per Value Area", GroupName = StrategyParameterGroupName, Order = 6)]
		public int MaxSignalsPerZone { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Freeze VA Plots", GroupName = StrategyParameterGroupName, Order = 7)]
		public bool FreezeVAPlots { get; set; }
		
		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[Display(Name = "Min. # Closes Inside Value Area", GroupName = StrategyParameterGroupName, Order = 8)]
		public int MinClosesInsideValueArea { get; set; }
		#endregion

		#region Stop Loss
		[NinjaScriptProperty]
		[ARC_VABOAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_VABOAlgo_PropComparisonType.EQ, ARC_VABOAlgo_BoolEnum.True)]
		[Display(Name = "Stop Loss Type", GroupName = StopLossGroupName, Order = 1)]
		public ARC_VABOAlgo_VABOAlgoStopLossType AlgoStopLossType { get; set; }

		[NinjaScriptProperty, Range(int.MinValue, int.MaxValue)]
		[ARC_VABOAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_VABOAlgo_PropComparisonType.EQ, ARC_VABOAlgo_BoolEnum.True)]
		[Display(Name = "Stop Loss Offset (Ticks)", GroupName = StopLossGroupName, Order = 2)]
		public int StopLossOffset { get; set; }
		#endregion

		#region Strategy Visuals
		[Display(Name = "Volume Profile Break", GroupName = StrategyVisualsParameterGroupName, Order = 0)]
		public Stroke SessionBreakStroke { get; set; }

		[Display(Name = "VAH Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 1)]
		public Stroke ValueAreaHighStroke { get; set; }
		
		[Display(Name = "POC Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 2)]
		public Stroke PointOfControlStroke { get; set; }

		[Display(Name = "VAL Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 3)]
		public Stroke ValueAreaLowStroke { get; set; }
		#endregion
		#endregion
	}

	public enum ARC_VABOAlgo_VABOAlgoStopLossType
	{
		NearVABound,
		POC,
		FarVABound
	}
}