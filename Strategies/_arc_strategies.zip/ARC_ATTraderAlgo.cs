using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Media;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.Indicators.ARC;
using NinjaTrader.NinjaScript.Strategies.Licensing;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	[ARC_ATTraderAlgo_CoLicenses(typeof(ARC_ATTraderAlgo_ARC_ATTrader))]
	public class ARC_ATTraderAlgo : ARC_ATTraderAlgo_ARCStrategyBase
	{
		public override string ProductVersion => "v1.0.1 (9/25/2024)";
		public override string ProductInfusionSoftTag => "39893";
		protected override bool AllowIntrabarEntries => BreakLogic == ARC_ATTraderAlgo_BreakLogic.Intrabar;
		public override bool HasStrategyBasedStops => true;

		private EMA ema;
		private ARC_ATTraderAlgo_ARC_MWPatternFinderZigZag zigZag;
		private ARC_ATTraderAlgo_ARC_ATTrader atTrader;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_ATTraderAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "AT Trader Algo";

				BreakLogic = ARC_ATTraderAlgo_BreakLogic.Close;
				Strength = 3;
				BufferZoneSizeType = ARC_ATTraderAlgo_AtrOrTicks.ATR;
				BufferZoneATRPeriod = 14;
				BufferZoneSize = 1;
				EmaPeriod = 20;
				RequireEma = true;
				MinBarsOutsideBufferZone = 0;
				AllowOlderLessSteepLines = true;
				trendStrokes.Clear();
				bufferZoneOpacity.Clear();

				EmaStroke = new Stroke(Brushes.AliceBlue, 3);
				ZigZagStroke = new Stroke(Brushes.White, DashStyleHelper.Dash, 3);
			}
			else if (State == State.DataLoaded)
			{
				AddChartIndicator(zigZag = ARC_ATTraderAlgo_ARC_MWPatternFinderZigZag(Strength, true));
				zigZag.ZigZagStroke = ZigZagStroke;
				
				AddChartIndicator(atTrader = ARC_ATTraderAlgo_ARC_ATTrader(BreakLogic, Strength, BufferZoneSizeType, BufferZoneATRPeriod, BufferZoneSize, AllowOlderLessSteepLines));
				for (var i = -1; i <= 1; i += 2)
				{
					atTrader.trendStrokes[i] = trendStrokes[i];
					atTrader.bufferZoneOpacity[i] = bufferZoneOpacity[i];
				}

				AddChartIndicator(ema = EMA(EmaPeriod));
				ema.Name = "";
				ema.Plots[0].DashStyleHelper = EmaStroke.DashStyleHelper;
				ema.Plots[0].Brush = EmaStroke.Brush;
				ema.Plots[0].Width = EmaStroke.Width;
			}
		}

		private void ScanEntries()
		{
			if (CurrentBars[0] <= 1)
				return;

			var trendsToCheck = BreakLogic == ARC_ATTraderAlgo_BreakLogic.Intrabar 
				? atTrader.UnbrokenTrends 
				: atTrader.JustBrokenTrends;
			var brokenLines = trendsToCheck.Where(t => Close[0].ApproxCompare(atTrader.GetBreakPrice(t, CurrentBars[0] + 1)) != -t.Side);
			
			foreach (var brokenLine in brokenLines)
			{
				var dir = brokenLine.Side;
				if (RequireEma && Closes[0][0].ApproxCompare(ema[0]) != dir)
					continue;

				if (!TradeAllowed(dir))
					continue;

				if (BreakLogic == ARC_ATTraderAlgo_BreakLogic.Intrabar && Close[1].ApproxCompare(atTrader.GetBreakPrice(brokenLine, CurrentBars[0] + 1)) != -brokenLine.Side)
					continue;

				var sl = (double?)null;
				if (EnableAlgoDefinedStopLosses)
				{
					sl = StopMethod == ARC_ATTraderAlgo_ATTraderStopMethod.Ema 
						? ema[0] 
						: zigZag.SwingPoints
							.Skip(zigZag.SwingPoints.Count - 2)
							.First(p => p.Side == -dir).Price;
					sl -= dir * StopLossOffset * (StopLossOffsetType == ARC_ATTraderAlgo_ATTraderStopOffsetMethod.PercentOfOriginalDistance ? Math.Abs(Close[0] - sl.Value) / 100 : TickSize);
					if (!TradeAllowedWithStop(dir, Close[0], sl.Value))
						continue;
				}

				var barsOutsideZone = 0;
				for (var i = brokenLine.P1.Bar; i <= CurrentBars[0] && barsOutsideZone < MinBarsOutsideBufferZone; i++)
				{
					var bufferZoneSize = atTrader.GetBufferZoneSize(i);
					var intercept = atTrader.GetIntercept(brokenLine, i);
					if ((dir == 1 ? Lows : Highs)[0].GetValueAt(i).ApproxCompare(intercept - dir * bufferZoneSize) != -dir)
						continue;

					barsOutsideZone++;
				}

				if (barsOutsideZone < MinBarsOutsideBufferZone)
					continue;

				QueueEntry(dir, BreakLogic == ARC_ATTraderAlgo_BreakLogic.Intrabar ? 1 : 0, stopLossPrice: sl);
				return;
			}
		}
		
		protected override void OnTickBar()
		{
			if (BreakLogic == ARC_ATTraderAlgo_BreakLogic.Intrabar)
				ScanEntries();
		}

		protected override void OnPrimaryBar()
		{
			zigZag.Update();
			if (BreakLogic != ARC_ATTraderAlgo_BreakLogic.Intrabar)
				ScanEntries();
		}

		#region Parameters
		[NinjaScriptProperty]
		[Display(Name = "Buffer Zone Break Logic", GroupName = StrategyParameterGroupName, Order = 0)]
		public ARC_ATTraderAlgo_BreakLogic BreakLogic { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Zig Zag Strength", GroupName = StrategyParameterGroupName, Order = 1)]
		public int Strength { get; set; }

		[NinjaScriptProperty, RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Buffer Zone Size Type", GroupName = StrategyParameterGroupName, Order = 2)]
		public ARC_ATTraderAlgo_AtrOrTicks BufferZoneSizeType { get; set; }
		
		[NinjaScriptProperty]
		[ARC_ATTraderAlgo_HideUnless(nameof(BufferZoneSizeType), ARC_ATTraderAlgo_PropComparisonType.EQ, ARC_ATTraderAlgo_AtrOrTicks.ATR)]
		[Display(Name = "Buffer Zone ATR Period", GroupName = StrategyParameterGroupName, Order = 3)]
		public int BufferZoneATRPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(0.001, int.MaxValue)]
		[Display(Name = "Buffer Zone Size", GroupName = StrategyParameterGroupName, Order = 4)]
		public double BufferZoneSize { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Require EMA", GroupName = StrategyParameterGroupName, Order = 5)]
		public bool RequireEma { get; set; }
		
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "EMA Period", GroupName = StrategyParameterGroupName, Order = 6)]
		public int EmaPeriod { get; set; }
		
		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[Display(Name = "Min Bars Outside Buffer Zone", GroupName = StrategyParameterGroupName, Order = 7)]
		public int MinBarsOutsideBufferZone { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Allow Older Less Steep Lines", GroupName = StrategyParameterGroupName, Order = 8)]
		public bool AllowOlderLessSteepLines { get; set; }

		#region Stop Loss
		[NinjaScriptProperty]
		[Display(Name = "Stop Method", GroupName = StopLossGroupName, Order = 0)]
		public ARC_ATTraderAlgo_ATTraderStopMethod StopMethod { get; set; }
		
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_ATTraderAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_ATTraderAlgo_PropComparisonType.EQ, ARC_ATTraderAlgo_BoolEnum.True)]
		[Display(Name = "Stop Loss Offset Type", GroupName = StopLossGroupName, Order = 1)]
		public ARC_ATTraderAlgo_ATTraderStopOffsetMethod StopLossOffsetType { get; set; }
		
		[NinjaScriptProperty, Range(int.MinValue, int.MaxValue)]
		[ARC_ATTraderAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_ATTraderAlgo_PropComparisonType.EQ, ARC_ATTraderAlgo_BoolEnum.True)]
		[ARC_ATTraderAlgo_Rename("Stop Loss Offset (Ticks)", nameof(StopLossOffsetType), ARC_ATTraderAlgo_PropComparisonType.EQ, ARC_ATTraderAlgo_ATTraderStopOffsetMethod.Ticks)]
		[ARC_ATTraderAlgo_Rename("Stop Loss Offset (% of Original Stop Distance)", nameof(StopLossOffsetType), ARC_ATTraderAlgo_PropComparisonType.EQ, ARC_ATTraderAlgo_ATTraderStopOffsetMethod.PercentOfOriginalDistance)]
		[Display(Name = "Stop Loss Offset", GroupName = StopLossGroupName, Order = 2)]
		public int StopLossOffset { get; set; }
		#endregion

		private readonly ARC_ATTraderAlgo_DefaultingDictionary<int, Stroke> trendStrokes = new ARC_ATTraderAlgo_DefaultingDictionary<int, Stroke>(dir => new Stroke(dir == 1 ? Brushes.Red : Brushes.Green, 3));
		private readonly ARC_ATTraderAlgo_DefaultingDictionary<int, float> bufferZoneOpacity = new ARC_ATTraderAlgo_DefaultingDictionary<int, float>(_ => 0.5f);

		[Display(Name = "EMA Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 0)]
		public Stroke EmaStroke { get; set; }
		
		[Display(Name = "Zig Zag Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 1)]
		public Stroke ZigZagStroke { get; set; }

		[Display(Name = "Bullish Stroke", GroupName = "Visuals", Order = 0)]
		public Stroke BullishTrendStroke { get => trendStrokes[1]; set => trendStrokes[1] = value; }
		
		[Display(Name = "Bearish Stroke", GroupName = "Visuals", Order = 1)]
		public Stroke BearishTrendStroke { get => trendStrokes[-1]; set => trendStrokes[-1] = value; }
		
		[Display(Name = "Bullish Buffer Zone Opacity", GroupName = "Visuals", Order = 2)]
		public float BullishBufferZoneOpacity { get => bufferZoneOpacity[1]; set => bufferZoneOpacity[1] = value; }
		
		[Display(Name = "Bearish Buffer Zone Opacity", GroupName = "Visuals", Order = 3)]
		public float BearishBufferZoneOpacity { get => bufferZoneOpacity[-1]; set => bufferZoneOpacity[-1] = value; }
		#endregion
	}

	public enum ARC_ATTraderAlgo_ATTraderStopMethod
	{
		LastSwing,
		Ema
	}
	
	public enum ARC_ATTraderAlgo_ATTraderStopOffsetMethod
	{
		Ticks,
		PercentOfOriginalDistance
	}
}