#region Using declarations
using NinjaTrader.Cbi;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.NinjaScript.Indicators.ARC;
using NinjaTrader.NinjaScript.Strategies.Licensing;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	[ARC_VWapperAlgo_CoLicenses(typeof(ARC_VWapperAlgo_VWAPPER))]
	[ARC_VWapperAlgo_RenameParameter("UseVMBias", "Require VM Bias Trend")]
	[ARC_VWapperAlgo_RenameParameter("UseVMConfluence", "Require VM Confluence Trend")]
	public class ARC_VWapperAlgo : ARC_VWapperAlgo_ARCStrategyBase
	{
		public override string ProductVersion { get { return "v3.0.11 (4/21/2023)"; } }
		public override string ProductInfusionSoftTag { get { return "18613"; } }
		protected override bool OverridesVMBiasAndConfluenceHandling { get { return true; } }

		private ARC_VWapperAlgo_VWAPPER vWapper;
		private readonly Dictionary<int, int> tradesAtLevels = new Dictionary<int, int>();
		private readonly Dictionary<int, TradeAtZone> tradesAllowedAtLevel = new Dictionary<int, TradeAtZone>();
		private readonly Dictionary<int, Series<double>> threshSeriesPerLevel = new Dictionary<int, Series<double>>();

		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State == State.SetDefaults)
			{
				TradeAtV0 = true;
				TradeAtV1 = TradeAtZone.TREND;
				TradeAtV2 = TradeAtZone.TREND;
				TradeAtV3 = TradeAtZone.TREND;
				BarsBetweenSignals = 2;
				MaxSignalsPerLevel = 2;
				UseVMBias = false;
				UseVMConfluence = false;
				UseVMBiasReversal = false;
				UseVMConfluenceReversal = false;

				ButtonText = "VWapper Algo";

				#region VWAPPER settings
				UseNTSessionTime = true;
				CustomSessionStartTime = 1800;
				Zone1Multiplier = 1.0;
				Zone2Multiplier = 2.0;
				Zone3Multiplier = 3.0;
				Zone1Color = Brushes.Green;
				Zone2Color = Brushes.Red;
				Zone3Color = Brushes.Blue;
				StepSize = 4;
				Zone1OpacityBkg = 10;
				Zone2OpacityBkg = 10;
				Zone3OpacityBkg = 10;
				DayWeekMonth = ARC_VWapperAlgo_DayWeekMonth.Day;
				#endregion
			}
			else if (State == State.Configure)
			{
				for (var i = -3; i <= 3; i++)
					tradesAtLevels[i] = 0;

				for (var dir = -1; dir <= 1; dir += 2)
				{
					tradesAllowedAtLevel[3 * dir] = TradeAtV3;
					tradesAllowedAtLevel[2 * dir] = TradeAtV2;
					tradesAllowedAtLevel[1 * dir] = TradeAtV1;
				}

				tradesAllowedAtLevel[0] = TradeAtV0 ? TradeAtZone.BOTH : TradeAtZone.OFF;
			}
			else if (State == State.DataLoaded)
			{
				vWapper = ARC_VWapperAlgo_VWAPPER(Zone1Multiplier, Zone2Multiplier, Zone3Multiplier, StepSize, CustomSessionStartTime);
				vWapper.pDayWeekMonth = DayWeekMonth;
				vWapper.pUseNTSessionTime = UseNTSessionTime;
				vWapper.Zone1Color = Zone1Color;
				vWapper.Zone2Color = Zone2Color;
				vWapper.Zone3Color = Zone3Color;
				vWapper.pStepSize = StepSize;
				vWapper.Zone1OpacityBkg = Zone1OpacityBkg;
				vWapper.Zone2OpacityBkg = Zone2OpacityBkg;
				vWapper.Zone3OpacityBkg = Zone3OpacityBkg;
				vWapper.Name = "";
				AddChartIndicator(vWapper);

				threshSeriesPerLevel[-3] = vWapper.PlotLower3;
				threshSeriesPerLevel[-2] = vWapper.PlotLower2;
				threshSeriesPerLevel[-1] = vWapper.PlotLower;
				threshSeriesPerLevel[0] = vWapper.PlotVWAP;
				threshSeriesPerLevel[1] = vWapper.PlotUpper;
				threshSeriesPerLevel[2] = vWapper.PlotUpper2;
				threshSeriesPerLevel[3] = vWapper.PlotUpper3;
			}
		}

		protected override void OnPrimaryBar()
		{
			// Every time we cross the midline, reset the trades per level tracker
			if (vWapper.PlotVWAP[0].ApproxCompare(vWapper.PlotVWAP[1]) != 0)
				for (var i = -3; i <= 3; i++)
					tradesAtLevels[i] = 0;

			// Reversal is our signal
			var dir = Close[0].ApproxCompare(Open[0]);
			if (dir == 0 || Close[1].ApproxCompare(Open[1]) != -dir)
				return;

			if (!TradeAllowedByFilters(dir))
				return;

			if (lastEntryBar != -1 && CurrentBar - lastEntryBar <= BarsBetweenSignals)
				return;

			// Whether our trade is trend or reversal is determined by whether our bar is toward or away from VWAP
			TradeAtZone tradeType;
			switch (Close[0].ApproxCompare(vWapper.PlotVWAP[0]) * dir)
			{
			case -1: 
				tradeType = TradeAtZone.REVERSAL; 
				break;
			case 0: 
				tradeType = TradeAtZone.OFF; 
				break;
			case 1: 
				tradeType = TradeAtZone.TREND; 
				break;
			default: 
				throw new ArgumentOutOfRangeException();
			}

			// Find the specific levels we've crossed
			var candidateLevels = threshSeriesPerLevel
				.Where(kvp => High[0] >= kvp.Value[0] && Low[0] <= kvp.Value[0])
				.Select(kvp => kvp.Key)
				.ToArray();

			if (candidateLevels.Length == 0)
				return;

			// Select the farthest level crossed in the direction of our trade
			var level = dir == 1 ? candidateLevels.Min() : candidateLevels.Max();

			// Ensure our trade type is allowed at the trade level
			if (tradesAllowedAtLevel[level] != TradeAtZone.BOTH && tradesAllowedAtLevel[level] != tradeType)
				return;

			// Verify our levels series isn't currently overlapping VWAP
			if (level != 0 && Math.Abs(threshSeriesPerLevel[level][0] - vWapper.PlotVWAP[0]).ApproxCompare(0) == 0)
				return;

			// Verify under max entries
			if (tradesAtLevels[level] >= MaxSignalsPerLevel)
				return;

			if ((level.CompareTo(0) == -dir ? UseVMConfluenceReversal : UseVMConfluence) && indMomo.BBMACD[0].ApproxCompare(0) != dir)
				return;

			if ((level.CompareTo(0) == -dir ? UseVMBiasReversal : UseVMBias) && (VMBiasType == ARC_VWapperAlgo_VMAlgo_BiasType.ZeroLine ? indMomo.Histogram : indMomo.StructureBiasState)[0].ApproxCompare(0) != dir)
				return;

			tradesAtLevels[level]++;
			QueueEntry(dir);
		}

		protected override void OnBarUpdate()
		{
			try
			{
				base.OnBarUpdate();
			}
			catch (Exception ex)
			{
				Log(ex.Message, LogLevel.Error);
				Log(ex.StackTrace, LogLevel.Error);
				throw;
			}
		}

		[SuppressMessage("ReSharper", "InconsistentNaming")]
		public enum TradeAtZone
		{
			OFF,
			TREND,
			REVERSAL,
			BOTH
		}

		#region Parameters
		#region General
		[NinjaScriptProperty]
		[Display(Name = "Trade At V0", GroupName = StrategyParameterGroupName, Order = 1)]
		public bool TradeAtV0 { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Trade At V1", GroupName = StrategyParameterGroupName, Order = 2)]
		public TradeAtZone TradeAtV1 { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Trade At V2", GroupName = StrategyParameterGroupName, Order = 3)]
		public TradeAtZone TradeAtV2 { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Trade At V3", GroupName = StrategyParameterGroupName, Order = 4)]
		public TradeAtZone TradeAtV3 { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "Bars Between Signals", GroupName = StrategyParameterGroupName, Order = 5, Description = "Signal must be preceded by this many consecutive NON-Candidate Bars)")]
		public int BarsBetweenSignals { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Max Signals Per Level", GroupName = StrategyParameterGroupName, Order = 6, Description = "Maximum Allowed Number of Signals per each horizontal segment of the V-Line")]
		public int MaxSignalsPerLevel { get; set; }

		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(Name = "Std. Dev. Multiplier 1", GroupName = StrategyParameterGroupName, Order = 7)]
		public double Zone1Multiplier { get; set; }

		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(Name = "Std. Dev. Multiplier 2", GroupName = StrategyParameterGroupName, Order = 8)]
		public double Zone2Multiplier { get; set; }

		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(Name = "Std. Dev. Multiplier 3", GroupName = StrategyParameterGroupName, Order = 9)]
		public double Zone3Multiplier { get; set; }

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(Name = "Step Size", GroupName = StrategyParameterGroupName, Order = 10)]
		public int StepSize { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Day/Week/Month", GroupName = StrategyParameterGroupName, Order = 11)]
		public ARC_VWapperAlgo_DayWeekMonth DayWeekMonth { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Use NT SessionStart", GroupName = StrategyParameterGroupName, Order = 12, Description = "If true, then use the NinjaTrader Session Start for this instrument.  If false, then use the 'Custom Session Start' parameter")]
		public bool UseNTSessionTime { get; set; }

		[Range(1, 2359), NinjaScriptProperty]
		[ARC_VWapperAlgo_HideUnless("UseNTSessionTime", ARC_VWapperAlgo_PropComparisonType.EQ, false)]
		[Display(Name = "Custom Session Start", GroupName = StrategyParameterGroupName, Order = 13, Description = "If 'Use NT SessionStart' is true, this parameter is ignored")]
		public int CustomSessionStartTime { get; set; }
		#endregion

		#region Visuals
		[XmlIgnore]
		[Display(Name = "Zone 1 Bkg color", GroupName = StrategyVisualsParameterGroupName, Order = 1, Description = "Background color for up-trending condition")]
		public Brush Zone1Color { get; set; }

		[Range(0, 100)]
		[Display(Name = "Zone 1 Opacity", GroupName = StrategyVisualsParameterGroupName, Order = 2, Description = "Opacity, 0=transparent, 100=opaque")]
		public int Zone1OpacityBkg { get; set; }

		[Browsable(false)]
		public string Zone1ColorSerialize
		{
			get { return Serialize.BrushToString(Zone1Color); }
			set { Zone1Color = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Zone 2 Bkg color", GroupName = StrategyVisualsParameterGroupName, Order = 3, Description = "Background color")]
		public Brush Zone2Color { get; set; }

		[Range(0, 100)]
		[Display(Name = "Zone 2 Opacity", GroupName = StrategyVisualsParameterGroupName, Order = 4, Description = "Opacity, 0=transparent, 100=opaque")]
		public int Zone2OpacityBkg { get; set; }

		[Browsable(false)]
		public string Zone2ColorSerialize
		{
			get { return Serialize.BrushToString(Zone2Color); }
			set { Zone2Color = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Zone 3 Bkg color", GroupName = StrategyVisualsParameterGroupName, Order = 5, Description = "Background color")]
		public Brush Zone3Color { get; set; }

		[Range(0, 100)]
		[Display(Name = "Zone 3 Opacity", GroupName = StrategyVisualsParameterGroupName, Order = 6, Description = "Opacity of the down-trend background color")]
		public int Zone3OpacityBkg { get; set; }

		[Browsable(false)]
		public string Zone3ColorSerialize
		{
			get { return Serialize.BrushToString(Zone3Color); }
			set { Zone3Color = Serialize.StringToBrush(value); }
		}
		#endregion

		#region VM Parameters
		[NinjaScriptProperty]
		[Display(Name = "Require VM Bias Reversal", Order = 11, GroupName = VMLeanGroupName)]
		public bool UseVMBiasReversal { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Require VM Confluence Reversal", Order = 12, GroupName = VMLeanGroupName)]
		public bool UseVMConfluenceReversal { get; set; }
		#endregion
		#endregion
	}
}