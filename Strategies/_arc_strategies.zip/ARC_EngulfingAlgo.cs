using System.ComponentModel.DataAnnotations;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using System.ComponentModel;
using System.Linq;
using System;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_EngulfingAlgo : ARC_EngulfingAlgo_ARCStrategyBase
	{
		public override string ProductVersion => "v1.0.0 (5/31/2024)";
		public override string ProductInfusionSoftTag => "37975";
		public override bool HasStrategyBasedStops => true;
		protected override bool AllowIntrabarEntries => EntryType == ARC_EngulfingAlgo_EngulfingAlgoEntryType.Intrabar;

		private ATR bar1MinSizeAtr;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_EngulfingAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "Engulfing Algo";

				EntryType = ARC_EngulfingAlgo_EngulfingAlgoEntryType.Intrabar;
				EntryOffset = 0;
				RequireOutsideBar2 = true;
				Bar1MinBodySize = 0;
				Bar1MinSizeType = ARC_EngulfingAlgo_AtrOrTicks.Ticks;
				Bar1MinSizeAtrPeriod = 14;
				Bar1MinSize = 0;

				StopLossOffsetType = ARC_EngulfingAlgo_EngulfingAlgoStopLossOffsetType.Ticks;
				StopLossOffset = 0;
			}
			else if (State == State.DataLoaded)
			{
				bar1MinSizeAtr = ATR(Bar1MinSizeAtrPeriod);
			}
		}

		private void ScanEntries()
		{
			if (CurrentBars.Any(cb => cb <= 1))
				return;

			var dir = Closes[0][0].ApproxCompare(Opens[0][0]);
			if (dir == 0)
				return;

			if (Closes[0][1].ApproxCompare(Opens[0][1]) != -dir)
				return;

			if (!Opens[0][1].ARC_EngulfingAlgo_InRange(Opens[0][0], Closes[0][0] - dir * TickSize) || !Closes[0][1].ARC_EngulfingAlgo_InRange(Opens[0][0], Closes[0][0] - dir * TickSize))
				return;

			var bar1BodySize = Math.Abs(Closes[0][1] - Opens[0][1]);
			var bar1Size = Highs[0][1] - Lows[0][1];
			if (bar1BodySize / bar1Size < Bar1MinBodySize / 100)
				return;

			if (bar1Size < Bar1MinSize * (Bar1MinSizeType == ARC_EngulfingAlgo_AtrOrTicks.Ticks ? TickSize : bar1MinSizeAtr[0]))
				return;

			var extremeSeries = (dir == 1 ? Highs : Lows)[0];
			if (RequireOutsideBar2 && (Highs[0][0].ApproxCompare(Highs[0][1]) != 1 || Lows[0][0].ApproxCompare(Lows[0][1]) != -1))
				return;

			if (EntryType == ARC_EngulfingAlgo_EngulfingAlgoEntryType.Intrabar)
			{
				var entryPrice = (dir == 1 ? Highs : Lows)[0][0] + dir * EntryOffset * TickSize;
				if (!Closes[tickBarsIdx].ARC_EngulfingAlgo_Crossed(entryPrice))
					return;
			}

			var sl = (double?)null;
			if (EnableAlgoDefinedStopLosses)
			{
				var (min, max) = GetRangeMinMax(1);
				sl = (dir == 1 ? min : max) - dir * (StopLossOffsetType == ARC_EngulfingAlgo_EngulfingAlgoStopLossOffsetType.Ticks ? TickSize : (max - min) / 100) * StopLossOffset;
				if (!TradeAllowedWithStop(dir, Close[0], sl.Value))
					return;
			}

			if (!TradeAllowed(dir))
				return;

			QueueEntry(dir, 1, stopLossPrice: sl, limitPrice: Closes[0][0]);
		}

		protected override void OnTickBar()
		{
			if (EntryType != ARC_EngulfingAlgo_EngulfingAlgoEntryType.Intrabar || lastEntryBar >= CurrentBars[0])
				return;
			
			ScanEntries();
		}

		protected override void OnPrimaryBar()
		{
			if (EntryType == ARC_EngulfingAlgo_EngulfingAlgoEntryType.BarClose)
				ScanEntries();
		}

		#region Parameters
		#region General
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Entry Type", GroupName = StrategyParameterGroupName, Order = 0)]
		public ARC_EngulfingAlgo_EngulfingAlgoEntryType EntryType { get; set; }
		
		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[ARC_EngulfingAlgo_HideUnless(nameof(EntryType), ARC_EngulfingAlgo_PropComparisonType.EQ, ARC_EngulfingAlgo_EngulfingAlgoEntryType.Intrabar)]
		[Display(Name = "Entry Offset (Ticks)", GroupName = StrategyParameterGroupName, Order = 1)]
		public int EntryOffset { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Require Outside Bar 2", GroupName = StrategyParameterGroupName, Order = 2)]
		public bool RequireOutsideBar2 { get; set; }

		[NinjaScriptProperty, Range(0, double.MaxValue)]
		[Display(Name = "Bar1 Min Body % HiLo Range", GroupName = StrategyParameterGroupName, Order = 3)]
		public double Bar1MinBodySize { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Bar 1 Min Size Type", GroupName = StrategyParameterGroupName, Order = 4)]
		public ARC_EngulfingAlgo_AtrOrTicks Bar1MinSizeType { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[ARC_EngulfingAlgo_HideUnless(nameof(Bar1MinSizeType), ARC_EngulfingAlgo_PropComparisonType.EQ, ARC_EngulfingAlgo_AtrOrTicks.ATR)]
		[Display(Name = "Bar 1 Min Size ATR Period", GroupName = StrategyParameterGroupName, Order = 5)]
		public int Bar1MinSizeAtrPeriod { get; set; }

		[NinjaScriptProperty, Range(0, double.MaxValue)]
		[ARC_EngulfingAlgo_Rename("Bar 1 Min Size (Ticks)", nameof(Bar1MinSizeType), ARC_EngulfingAlgo_PropComparisonType.EQ, ARC_EngulfingAlgo_AtrOrTicks.Ticks)]
		[ARC_EngulfingAlgo_Rename("Bar 1 Min Size (ATRs)", nameof(Bar1MinSizeType), ARC_EngulfingAlgo_PropComparisonType.EQ, ARC_EngulfingAlgo_AtrOrTicks.ATR)]
		[Display(Name = "Bar 1 Min Size", GroupName = StrategyParameterGroupName, Order = 6)]
		public double Bar1MinSize { get; set; }
		#endregion

		#region Stop Loss
		[NinjaScriptProperty]
		[ARC_EngulfingAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_EngulfingAlgo_PropComparisonType.EQ, ARC_EngulfingAlgo_BoolEnum.True)]
		[Display(Name = "Stop Loss Type", GroupName = StopLossGroupName, Order = 1)]
		public ARC_EngulfingAlgo_EngulfingAlgoStopLossOffsetType StopLossOffsetType { get; set; }

		[NinjaScriptProperty, Range(double.MinValue, double.MaxValue)]
		[ARC_EngulfingAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_EngulfingAlgo_PropComparisonType.EQ, ARC_EngulfingAlgo_BoolEnum.True)]
		[ARC_EngulfingAlgo_Rename("Stop Loss Offset (Ticks)", nameof(StopLossOffsetType), ARC_EngulfingAlgo_PropComparisonType.EQ, ARC_EngulfingAlgo_EngulfingAlgoStopLossOffsetType.Ticks)]
		[ARC_EngulfingAlgo_Rename("Stop Loss Offset (% of HL Range)", nameof(StopLossOffsetType), ARC_EngulfingAlgo_PropComparisonType.EQ, ARC_EngulfingAlgo_EngulfingAlgoStopLossOffsetType.PercentOfPatternHLRange)]
		[Display(Name = "Stop Loss Offset", GroupName = StopLossGroupName, Order = 2)]
		public double StopLossOffset { get; set; }
		#endregion
		#endregion
	}

	public enum	ARC_EngulfingAlgo_EngulfingAlgoEntryType
	{
		BarClose,
		Intrabar
	}

	public enum	ARC_EngulfingAlgo_EngulfingAlgoStopLossOffsetType
	{
		Ticks,
		PercentOfPatternHLRange
	}
}