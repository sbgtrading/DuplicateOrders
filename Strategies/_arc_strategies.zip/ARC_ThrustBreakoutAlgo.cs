using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.Strategies.Licensing;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_ThrustBreakoutAlgo : ARC_ThrustBreakoutAlgo_ARCStrategyBase
	{
		public override string ProductVersion => "v1.0.4 (3/18/2024)";
		public override string ProductInfusionSoftTag => "28315";
		protected override bool AllowIntrabarEntries => true;
		public override bool HasStrategyBasedStops => true;

		private int lastExtendedBar;
		private bool signalValid;
		private ATR ercThreshAtr;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_ThrustBreakoutAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "Thrust Breakout Algo";

				ExtendedBodyPercent = 50;
				NarrowBodyPercent = 50;
				PullbackThreshold = 50;
				MaxAllowedBasingBars = 1;
				ErcBarSizeATRPeriod = 14;
				ErcBarSizeThreshType = ARC_ThrustBreakoutAlgo_AtrOrTicks.ATR;
				ErcMinBarSize = 0;
				ErcMaxBarSize = 1000;
				AddPlot(new Stroke(Brushes.Transparent, 3), PlotStyle.Hash, "Pullback Thresh");
			}
			else if (State == State.Configure)
			{
				lastExtendedBar = -1;
				signalValid = false;
			}
			else if (State == State.DataLoaded)
			{
				if (ErcBarSizeThreshType == ARC_ThrustBreakoutAlgo_AtrOrTicks.ATR)
					ercThreshAtr = ATR(ErcBarSizeATRPeriod);
			}
		}
		
		protected override void OnTickBar()
		{
			if (CurrentBars[0] <= 1)
				return;

			if (!signalValid)
				return;

			var dir = Closes[0].GetValueAt(lastExtendedBar).ApproxCompare(Opens[0].GetValueAt(lastExtendedBar));
			if (dir == 0)
				return;

			// Avoid processing flat ticks unnecessarily
			var barDir = Closes[tickBarsIdx][0].ApproxCompare(Closes[tickBarsIdx][1]);
			if (barDir != 0 && barDir != dir)
				return;

			var (basingRangeMin, basingRangeMax) = GetRangeMinMax(CurrentBars[0] - lastExtendedBar - 1);
			if (!TradeAllowed(dir))
				return;

			if ((dir == 1 ? Math.Min(basingRangeMin, CurBarLow) : Math.Max(basingRangeMax, CurBarHigh)).ApproxCompare(Value.GetValueAt(lastExtendedBar)) == -dir)
				return;
			
			var entryPrice = (dir == 1 ? basingRangeMax : basingRangeMin) + dir * EntryOffset * TickSize;
			if (!Closes[tickBarsIdx].ARC_ThrustBreakoutAlgo_Crossed(entryPrice))
				return;

			var sl = (double?)null;
			if (EnableAlgoDefinedStopLosses)
			{
				sl = AlgoStopLossType == ARC_ThrustBreakoutAlgo_ThrustBreakoutStopLossType.ERC
					? (dir == 1 ? Lows : Highs)[0].GetValueAt(lastExtendedBar)
					: (dir == 1 ? basingRangeMin : basingRangeMax);

				sl -= dir * StopLossOffset * (StopLossOffsetType == ARC_ThrustBreakoutAlgo_ThrustBreakoutStopLossOffsetType.Ticks ? TickSize : (basingRangeMax - basingRangeMin) / 100);
				if (!TradeAllowedWithStop(Close[0], sl.Value))
					return;
			}

			signalValid = false;
			QueueEntry(dir, 1, stopLossPrice: sl);
		}

		protected override void OnPrimaryBar()
		{
			var bodyRatio = GetBodyRatio(0);
			if (bodyRatio > ExtendedBodyPercent / 100 && ((High[0] - Low[0]) / (ErcBarSizeThreshType == ARC_ThrustBreakoutAlgo_AtrOrTicks.ATR ? ercThreshAtr[0] : TickSize)).ARC_ThrustBreakoutAlgo_InRange(ErcMinBarSize, ErcMaxBarSize))
			{
				lastExtendedBar = CurrentBar;
				var dir = Close[0].ApproxCompare(Open[0]);
				Value[0] = (dir == -1 ? High : Low)[0] * PullbackThreshold / 100 + (dir == -1 ? Low : High)[0] * (1 - PullbackThreshold / 100);
			}

			if (bodyRatio >= NarrowBodyPercent / 100)
				signalValid = false;
			else if (lastExtendedBar == CurrentBar - 1 && lastExtendedBar != -1)
				signalValid = true;
			else if (CurrentBar - lastExtendedBar >= MaxAllowedBasingBars)
				signalValid = false;
		}

		#region Parameters
		[NinjaScriptProperty, Range(1, 99)]
		[Display(Name = "ERC Body %", GroupName = StrategyParameterGroupName, Order = 0)]
		public double ExtendedBodyPercent { get; set; }

		[NinjaScriptProperty, Range(1, 99)]
		[Display(Name = "NRC Body %", GroupName = StrategyParameterGroupName, Order = 1)]
		public double NarrowBodyPercent { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "Max Allowed Basing Bars", GroupName = StrategyParameterGroupName, Order = 2)]
		public int MaxAllowedBasingBars { get; set; }

		[NinjaScriptProperty, Range(1, double.MaxValue)]
		[Display(Name = "Pullback Threshold (%)", GroupName = StrategyParameterGroupName, Order = 3)]
		public double PullbackThreshold { get; set; }

		[NinjaScriptProperty, Range(int.MinValue, int.MaxValue)]
		[Display(Name = "Entry Offset (Ticks)", GroupName = StrategyParameterGroupName, Order = 4)]
		public int EntryOffset { get; set; }

		[NinjaScriptProperty, RefreshProperties(RefreshProperties.All)]
		[Display(Name = "ERC Min/Max Size Type", GroupName = StrategyParameterGroupName, Order = 5)]
		public ARC_ThrustBreakoutAlgo_AtrOrTicks ErcBarSizeThreshType { get; set; }
		
		[NinjaScriptProperty]
		[ARC_ThrustBreakoutAlgo_HideUnless(nameof(ErcBarSizeThreshType), ARC_ThrustBreakoutAlgo_PropComparisonType.EQ, ARC_ThrustBreakoutAlgo_AtrOrTicks.ATR)]
		[Display(Name = "ERC Min/Max Size ATR Period", GroupName = StrategyParameterGroupName, Order = 6)]
		public int ErcBarSizeATRPeriod { get; set; }
		
		[NinjaScriptProperty, Range(0, double.MaxValue)]
		[ARC_ThrustBreakoutAlgo_Rename("ERC Min Size (Ticks)", nameof(ErcBarSizeThreshType), ARC_ThrustBreakoutAlgo_PropComparisonType.EQ, ARC_ThrustBreakoutAlgo_AtrOrTicks.Ticks)]
		[ARC_ThrustBreakoutAlgo_Rename("ERC Min Size (ATRs)", nameof(ErcBarSizeThreshType), ARC_ThrustBreakoutAlgo_PropComparisonType.EQ, ARC_ThrustBreakoutAlgo_AtrOrTicks.ATR)]
		[Display(Name = "ERC Min Size", GroupName = StrategyParameterGroupName, Order = 7)]
		public double ErcMinBarSize { get; set; }

		[NinjaScriptProperty, Range(0, double.MaxValue)]
		[ARC_ThrustBreakoutAlgo_Rename("ERC Max Size (Ticks)", nameof(ErcBarSizeThreshType), ARC_ThrustBreakoutAlgo_PropComparisonType.EQ, ARC_ThrustBreakoutAlgo_AtrOrTicks.Ticks)]
		[ARC_ThrustBreakoutAlgo_Rename("ERC Max Size (ATRs)", nameof(ErcBarSizeThreshType), ARC_ThrustBreakoutAlgo_PropComparisonType.EQ, ARC_ThrustBreakoutAlgo_AtrOrTicks.ATR)]
		[Display(Name = "ERC Max Size", GroupName = StrategyParameterGroupName, Order = 8)]
		public double ErcMaxBarSize { get; set; }

		#region Stop Loss
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_ThrustBreakoutAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_ThrustBreakoutAlgo_PropComparisonType.EQ, ARC_ThrustBreakoutAlgo_BoolEnum.True)]
		[Display(Name = "Stop Loss Type", GroupName = StopLossGroupName, Order = 1)]
		public ARC_ThrustBreakoutAlgo_ThrustBreakoutStopLossType AlgoStopLossType { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_ThrustBreakoutAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_ThrustBreakoutAlgo_PropComparisonType.EQ, ARC_ThrustBreakoutAlgo_BoolEnum.True)]
		[Display(Name = "Stop Loss Offset Type", GroupName = StopLossGroupName, Order = 1)]
		public ARC_ThrustBreakoutAlgo_ThrustBreakoutStopLossOffsetType StopLossOffsetType { get; set; }
		
		[NinjaScriptProperty, Range(int.MinValue, int.MaxValue)]
		[ARC_ThrustBreakoutAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_ThrustBreakoutAlgo_PropComparisonType.EQ, ARC_ThrustBreakoutAlgo_BoolEnum.True)]
		[ARC_ThrustBreakoutAlgo_Rename("Stop Loss Offset (Ticks)", nameof(StopLossOffsetType), ARC_ThrustBreakoutAlgo_PropComparisonType.EQ, ARC_ThrustBreakoutAlgo_ThrustBreakoutStopLossOffsetType.Ticks)]
		[ARC_ThrustBreakoutAlgo_Rename("Stop Loss Offset (% Basing Bar Range)", nameof(StopLossOffsetType), ARC_ThrustBreakoutAlgo_PropComparisonType.EQ, ARC_ThrustBreakoutAlgo_ThrustBreakoutStopLossOffsetType.PercentOfBasingBarRange)]
		[Display(Name = "Stop Loss Offset", GroupName = StopLossGroupName, Order = 2)]
		public int StopLossOffset { get; set; }
		#endregion
		#endregion
	}

	public enum ARC_ThrustBreakoutAlgo_ThrustBreakoutStopLossOffsetType
	{
		Ticks,
		PercentOfBasingBarRange
	}

	public enum ARC_ThrustBreakoutAlgo_ThrustBreakoutStopLossType
	{
		BasingRange,
		ERC
	}
}