using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.Strategies.Licensing;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_VBandsAlgo : ARC_VBandsAlgo_ARCStrategyBase
	{
		public override string ProductVersion => "v1.0.2 (5/21/2025)";
		public override string ProductInfusionSoftTag => "44107";
		protected override bool AllowIntrabarEntries => _allowedEntries[ARC_VBandsAlgo_VBandsAlgoEntryType.IntrabarTouch] || _allowedEntries[ARC_VBandsAlgo_VBandsAlgoEntryType.IntrabarHhLl];
		public override bool HasStrategyBasedStops => true;

		[XmlIgnore]
		private Series<double> Upper => Values[0];

		[XmlIgnore]
		private Series<double> Middle => Values[1];

		[XmlIgnore]
		private Series<double> Lower => Values[2];

		private Indicator indicator;
		private int lastBandTouch;
		private bool touchedMidline;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_VBandsAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "VBands Algo";

				Indictor = ARC_VBandsAlgo_VBandsAlgoIndicator.DonchianChannel;
				Period = 14;
				VBandsMAType = ARC_VBandsAlgo_VBandsMaType.SMA;
				EnvelopePercentage = 1.5;
				OffsetMultiplier = 1.5;
				NumStdDev = 2;
				MaxBarDelay = 5;
				MaxEntryMultiple = 100;

				UpperStroke = new Stroke(Brushes.Aqua);
				MiddleStroke = new Stroke(Brushes.Blue, DashStyleHelper.Dash, 1);
				LowerStroke = new Stroke(Brushes.Aqua);

				StopLossBandWidthMultiple = 0.25;
			}
			else if (State == State.Configure)
			{
				for (var i = 0; i < 3; i++)
				{
					var stroke = i switch
					{
						0 => UpperStroke,
						1 => MiddleStroke,
						2 => LowerStroke
					};

					AddPlot(stroke, PlotStyle.Line, i switch
					{
						0 => "Upper",
						1 => "Middle",
						2 => "Lower"
					});
				}

				touchedMidline = true;
				lastBandTouch = -1;

				indicator = Indictor switch 
				{
					ARC_VBandsAlgo_VBandsAlgoIndicator.KeltnerChannel => KeltnerChannel(OffsetMultiplier, Period),
					ARC_VBandsAlgo_VBandsAlgoIndicator.BollingerBands => Bollinger(NumStdDev, Period),
					ARC_VBandsAlgo_VBandsAlgoIndicator.MaEnvelopes => MAEnvelopes(EnvelopePercentage, (int) VBandsMAType, Period),
					ARC_VBandsAlgo_VBandsAlgoIndicator.DonchianChannel => DonchianChannel(Period)
				};
			}
		}

		private bool IsMultiBar(ARC_VBandsAlgo_VBandsAlgoEntryType entryType)
		{
			return entryType is ARC_VBandsAlgo_VBandsAlgoEntryType.BarCloseTouchFlip or ARC_VBandsAlgo_VBandsAlgoEntryType.BarCloseHcLc or ARC_VBandsAlgo_VBandsAlgoEntryType.IntrabarHhLl;
		}

		public bool EntryValid(ARC_VBandsAlgo_VBandsAlgoEntryType entryType, int dir)
		{
			var isIntrabar = entryType is ARC_VBandsAlgo_VBandsAlgoEntryType.IntrabarHhLl or ARC_VBandsAlgo_VBandsAlgoEntryType.IntrabarTouch;
			if (BarsInProgress != (isIntrabar ? tickBarsIdx : 0))
				return false;

			if (IsMultiBar(entryType) && !lastBandTouch.ARC_VBandsAlgo_InRange(CurrentBars[0] - MaxBarDelay, CurrentBars[0]))
				return false;
			
			var dirOppositeBand = dir == -1 ? Upper : Lower;
			switch (entryType)
			{
				case ARC_VBandsAlgo_VBandsAlgoEntryType.IntrabarTouch:
					return Close[1].ApproxCompare(dirOppositeBand[0]) == -dir && Close[0].ApproxCompare(dirOppositeBand[0]) == -dir;
				case ARC_VBandsAlgo_VBandsAlgoEntryType.BarCloseTouch:
					return Low[1] > Lower[1] && High[1] < Upper[1] && (dir == -1 ? High : Low)[0].ApproxCompare(dirOppositeBand[0]) != dir;
				case ARC_VBandsAlgo_VBandsAlgoEntryType.BarCloseTouchFlip:
					return lastBandTouch < CurrentBar - 1 && Close[0].ApproxCompare(Open[0]) == dir;
				case ARC_VBandsAlgo_VBandsAlgoEntryType.IntrabarHhLl or ARC_VBandsAlgo_VBandsAlgoEntryType.BarCloseHcLc:
					return (dir == -1 ? Highs : Lows)[0][1].ApproxCompare(dirOppositeBand[1]) != dir && Close[0].ApproxCompare((dir == -1 ? Lows : Highs)[0][isIntrabar ? 0 : 1]) == dir;
				default:
					throw new NotImplementedException();
			}
		}

		private void ScanEntries()
		{
			if (!touchedMidline || lastBandTouch == -1)
				return;

			if (CurrentBar < 1 || CurrentBars[0] < 1)
				return;

			var dir = -Close[0].ApproxCompare(Middle[0]);
			if (dir == 0)
				return;

			foreach (var entryType in (ARC_VBandsAlgo_VBandsAlgoEntryType[]) Enum.GetValues(typeof(ARC_VBandsAlgo_VBandsAlgoEntryType)))
			{
				if (!_allowedEntries[entryType])
					continue;

				if (!EntryValid(entryType, dir))
					continue;

				touchedMidline = false;
				lastBandTouch = -1;

				if (!TradeAllowed(dir))
					return;

				var dirOppositeBand = dir == -1 ? Upper : Lower;
				if (IsMultiBar(entryType) && Close[0].ARC_VBandsAlgo_InRange(Upper[0], Lower[0]) && Math.Abs(Close[0] - dirOppositeBand[0]).ApproxCompare((MaxEntryOffsetType == ARC_VBandsAlgo_VBandsAlgoDistanceType.Ticks ? TickSize : (Upper[0] - Lower[0]) / 100) * MaxEntryMultiple) == 1)
					continue;

				if (CurrentBars[0] - lastEntryBar < MinBarsBetweenSignals + 1)
					continue;

				var sl = (double?)null;
				if (EnableAlgoDefinedStopLosses)
				{
					sl = Close[0] - dir * StopLossBandWidthMultiple * (Upper[0] - Lower[0]);
					if (!TradeAllowedWithStop(dir, Close[0], sl.Value))
						return;
				}

				QueueEntry(dir, BarsInProgress == tickBarsIdx ? 1 : 0, stopLossPrice: sl);
				return;
			}	
		}

		protected override void OnTickBar()
		{
			if (CurrentBars[0] < 0)
				return;

			if (CurrentBar >= 1 && Close[0].ApproxCompare(Middle[0]) != Close[1].ApproxCompare(Middle[0]))
			{
				touchedMidline = true;
				lastBandTouch = -1;
			}

			var side = Close[0].ApproxCompare(Middle[0]);
			if (side == 0)
				side = 1;

			var band = side == 1 ? Upper : Lower;
			if (touchedMidline && lastBandTouch == -1 && Close[0].ApproxCompare(band[0]) != Close[1].ApproxCompare(band[0]))
				lastBandTouch = CurrentBars[0];

			ScanEntries();
		}

		protected override void OnPrimaryBar()
		{
			UpdateSeries();
			ScanEntries();
		}

		private void UpdateSeries()
		{
			ISeries<double> upper;
			ISeries<double> lower;
			var mid = default(ISeries<double>);
			switch (indicator)
			{
			case KeltnerChannel keltner:
				upper = keltner.Upper;
				mid = keltner.Midline;
				lower = keltner.Lower;
				break;
			case Bollinger bollinger:
				upper = bollinger.Upper;
				mid = bollinger.Middle;
				lower = bollinger.Lower;
				break;
			case MAEnvelopes maEnvelope:
				upper = maEnvelope.Upper;
				mid = maEnvelope.Middle;
				lower = maEnvelope.Lower;
				break;
			case DonchianChannel donchian:
				upper = donchian.Upper;
				lower = donchian.Lower;
				break;
			default:
				throw new NotImplementedException();
			}

			Upper[0] = upper[0];
			Middle[0] = mid?[0] ?? ((lower[0] + upper[0]) / 2);
			Lower[0] = lower[0];
		}

		#region Parameters
		private readonly ARC_VBandsAlgo_DefaultingDictionary<ARC_VBandsAlgo_VBandsAlgoEntryType, bool> _allowedEntries = new(et => et == ARC_VBandsAlgo_VBandsAlgoEntryType.BarCloseTouch);

		[NinjaScriptProperty, RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Bands Indicator", GroupName = StrategyParameterGroupName, Order = 0)]
		public ARC_VBandsAlgo_VBandsAlgoIndicator Indictor { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "Period", GroupName = StrategyParameterGroupName, Order = 1)]
		public int Period { get; set; }

		[NinjaScriptProperty, Range(0.01, int.MaxValue)]
		[ARC_VBandsAlgo_HideUnless(nameof(Indictor), ARC_VBandsAlgo_PropComparisonType.EQ, ARC_VBandsAlgo_VBandsAlgoIndicator.MaEnvelopes)]
		[Display(Name = "Envelope Percentage", GroupName = StrategyParameterGroupName, Order = 2)]
		public double EnvelopePercentage { get; set; }

		[NinjaScriptProperty]
		[ARC_VBandsAlgo_HideUnless(nameof(Indictor), ARC_VBandsAlgo_PropComparisonType.EQ, ARC_VBandsAlgo_VBandsAlgoIndicator.MaEnvelopes)]
		[Display(Name = "MA Type", GroupName = StrategyParameterGroupName, Order = 3)]
		public ARC_VBandsAlgo_VBandsMaType VBandsMAType { get; set; }

		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[ARC_VBandsAlgo_HideUnless(nameof(Indictor), ARC_VBandsAlgo_PropComparisonType.EQ, ARC_VBandsAlgo_VBandsAlgoIndicator.BollingerBands)]
		[Display(Name = "Num Std. Dev.", GroupName = StrategyParameterGroupName, Order = 4)]
		public double NumStdDev { get; set; }

		[NinjaScriptProperty, Range(0.01, int.MaxValue)]
		[ARC_VBandsAlgo_HideUnless(nameof(Indictor), ARC_VBandsAlgo_PropComparisonType.EQ, ARC_VBandsAlgo_VBandsAlgoIndicator.KeltnerChannel)]
		[Display(Name = "Offset Multiplier", GroupName = StrategyParameterGroupName, Order = 5)]
		public double OffsetMultiplier { get; set; }

		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[Display(Name = "Min Bars Between Signals", GroupName = StrategyParameterGroupName, Order = 100)]
		public int MinBarsBetweenSignals { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Enable Intrabar Touch Entry", GroupName = StrategyParameterGroupName, Order = 200)]
		public bool EnableIntrabarTouchEntry { get => _allowedEntries[ARC_VBandsAlgo_VBandsAlgoEntryType.IntrabarTouch]; set => _allowedEntries[ARC_VBandsAlgo_VBandsAlgoEntryType.IntrabarTouch] = value; }

		[NinjaScriptProperty]
		[Display(Name = "Enable Bar Close Touch Entry", GroupName = StrategyParameterGroupName, Order = 201)]
		public bool EnableBarCloseTouchEntry { get => _allowedEntries[ARC_VBandsAlgo_VBandsAlgoEntryType.BarCloseTouch]; set => _allowedEntries[ARC_VBandsAlgo_VBandsAlgoEntryType.BarCloseTouch] = value; }

		[NinjaScriptProperty]
		[Display(Name = "Enable Bar Close Touch Flip Entry", GroupName = StrategyParameterGroupName, Order = 202)]
		public bool EnableBarCloseTouchFlipEntry { get => _allowedEntries[ARC_VBandsAlgo_VBandsAlgoEntryType.BarCloseTouchFlip]; set => _allowedEntries[ARC_VBandsAlgo_VBandsAlgoEntryType.BarCloseTouchFlip] = value; }

		[NinjaScriptProperty]
		[Display(Name = "Enable Intrabar HH/LL Entry", GroupName = StrategyParameterGroupName, Order = 203)]
		public bool EnableIntrabarHhLlEntry { get => _allowedEntries[ARC_VBandsAlgo_VBandsAlgoEntryType.IntrabarHhLl]; set => _allowedEntries[ARC_VBandsAlgo_VBandsAlgoEntryType.IntrabarHhLl] = value; }

		[NinjaScriptProperty]
		[Display(Name = "Enable Bar Close HC/LC Entry", GroupName = StrategyParameterGroupName, Order = 204)]
		public bool EnableBarCloseHcLcEntry { get => _allowedEntries[ARC_VBandsAlgo_VBandsAlgoEntryType.BarCloseHcLc]; set => _allowedEntries[ARC_VBandsAlgo_VBandsAlgoEntryType.BarCloseHcLc] = value; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "Max Bar Delay", GroupName = StrategyParameterGroupName, Order = 300)]
		public int MaxBarDelay { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Max Entry Offset Type", GroupName = StrategyParameterGroupName, Order = 400)]
		public ARC_VBandsAlgo_VBandsAlgoDistanceType MaxEntryOffsetType { get; set; }
		
		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[ARC_VBandsAlgo_Rename("Max Entry Offset (Ticks)", nameof(MaxEntryOffsetType), ARC_VBandsAlgo_PropComparisonType.EQ, ARC_VBandsAlgo_VBandsAlgoDistanceType.Ticks)]
		[ARC_VBandsAlgo_Rename("Max Entry Offset (Percent)", nameof(MaxEntryOffsetType), ARC_VBandsAlgo_PropComparisonType.EQ, ARC_VBandsAlgo_VBandsAlgoDistanceType.PercentOfBandWidth)]
		[Display(Name = "Max Entry Offset", GroupName = StrategyParameterGroupName, Order = 401)]
		public double MaxEntryMultiple { get; set; }

		#region 
		[Display(Name = "Upper Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 0)]
		public Stroke UpperStroke { get; set; }

		[Display(Name = "Middle Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 1)]
		public Stroke MiddleStroke { get; set; }

		[Display(Name = "Lower Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 2)]
		public Stroke LowerStroke { get; set; }
		#endregion

		#region Stop Loss
		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[ARC_VBandsAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_VBandsAlgo_PropComparisonType.EQ, ARC_VBandsAlgo_BoolEnum.True)]
		[Display(Name = "Stop Loss Band Width Multiple", GroupName = StopLossGroupName, Order = 2)]
		public double StopLossBandWidthMultiple { get; set; }
		#endregion
		#endregion
	}

	public enum ARC_VBandsAlgo_VBandsAlgoDistanceType
	{
		Ticks,
		PercentOfBandWidth
	}

	public enum ARC_VBandsAlgo_VBandsAlgoIndicator
	{
		KeltnerChannel,
		BollingerBands,
		DonchianChannel,
		MaEnvelopes
	}

	public enum ARC_VBandsAlgo_VBandsAlgoEntryType
	{
		IntrabarTouch,
		BarCloseTouch,
		BarCloseTouchFlip,
		IntrabarHhLl,
		BarCloseHcLc
	}

	public enum ARC_VBandsAlgo_VBandsMaType
	{
		EMA = 1,
		HMA = 2,
		SMA = 3,
		TMA = 4,
		TEMA = 5,
		WMA = 6
	}
}