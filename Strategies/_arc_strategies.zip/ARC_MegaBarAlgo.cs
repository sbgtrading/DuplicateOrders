using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.Strategies.Licensing;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_MegaBarAlgo : ARC_MegaBarAlgo_ARCStrategyBase
	{
		public override string ProductVersion => "v1.0.0 (7/23/2024)";
		public override string ProductInfusionSoftTag => "39347";
		protected override bool AllowIntrabarEntries => true;
		public override bool HasStrategyBasedStops => true;

		private EMA ema;
		private int lastExtendedBar;
		private bool signalValid;
		private ATR ercThreshAtr;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_MegaBarAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "Mega Bar Algo";

				ExtendedBodyPercent = 50;
				MaxAllowedBasingBars = 1;
				ErcBarSizeATRPeriod = 14;
				ErcBarSizeThreshType = ARC_MegaBarAlgo_AtrOrTicks.ATR;
				ErcMinBarSize = 0;
				ErcMaxBarSize = 1000;
				RequireEma = true;
				EmaPeriod = 20;
				EmaStroke = new Stroke(Brushes.AliceBlue, 3);
			}
			else if (State == State.Configure)
			{
				lastExtendedBar = -1;
				signalValid = false;
			}
			else if (State == State.DataLoaded)
			{
				AddChartIndicator(ema = EMA(EmaPeriod));
				ema.Name = "";
				ema.Plots[0].DashStyleHelper = EmaStroke.DashStyleHelper;
				ema.Plots[0].Brush = EmaStroke.Brush;
				ema.Plots[0].Width = EmaStroke.Width;	
				if (ErcBarSizeThreshType == ARC_MegaBarAlgo_AtrOrTicks.ATR)
					ercThreshAtr = ATR(ErcBarSizeATRPeriod);
			}
		}
		
		protected override void OnTickBar()
		{
			if (CurrentBars[0] <= 1)
				return;

			if (!signalValid)
				return;

			var dir = Closes[0].GetValueAt(lastExtendedBar).ApproxCompare(Opens[0].GetValueAt(lastExtendedBar));
			if (dir == 0)
				return;

			if (RequireEma && Close[0].ApproxCompare(ema[0]) != dir)
				return;
			
			if ((dir == 1 ? CurBarLow : CurBarHigh).ApproxCompare((dir == 1 ? Lows : Highs)[0].GetValueAt(lastExtendedBar)) == -dir)
			{
				signalValid = false;
				return;
			}

			// Avoid processing flat ticks unnecessarily
			var barDir = Closes[tickBarsIdx][0].ApproxCompare(Closes[tickBarsIdx][1]);
			if (barDir != 0 && barDir != dir)
				return;

			if (!TradeAllowed(dir))
				return;

			if (!Closes[tickBarsIdx].ARC_MegaBarAlgo_Crossed((dir == 1 ? Highs : Lows)[0].GetValueAt(lastExtendedBar) + dir * EntryOffset * TickSize))
				return;

			var sl = (double?)null;
			if (EnableAlgoDefinedStopLosses)
			{
				var ercRange = Highs[0].GetValueAt(lastExtendedBar) - Lows[0].GetValueAt(lastExtendedBar);
				sl = (dir == 1 ? Lows : Highs)[0].GetValueAt(lastExtendedBar) - dir * StopLossOffset * (StopLossOffsetType == ARC_MegaBarAlgo_MegaBarStopLossOffsetType.Ticks ? TickSize : ercRange / 100);
				if (!TradeAllowedWithStop(dir, Close[0], sl.Value))
					return;
			}

			signalValid = false;
			QueueEntry(dir, 1, stopLossPrice: sl);
		}

		protected override void OnPrimaryBar()
		{
			var bodyRatio = GetBodyRatio(0);
			if (bodyRatio > ExtendedBodyPercent / 100 && ((High[0] - Low[0]) / (ErcBarSizeThreshType == ARC_MegaBarAlgo_AtrOrTicks.ATR ? ercThreshAtr[0] : TickSize)).ARC_MegaBarAlgo_InRange(ErcMinBarSize, ErcMaxBarSize))
			{
				lastExtendedBar = CurrentBar;
				signalValid = true;
				return;
			}

			if (!signalValid) 
				return;

			if (CurrentBar - lastExtendedBar > MaxAllowedBasingBars)
			{
				signalValid = false;
				return;
			}

			var dir = Close.GetValueAt(lastExtendedBar).ApproxCompare(Open.GetValueAt(lastExtendedBar));
			if ((dir == 1 ? Low : High)[0].ApproxCompare((dir == 1 ? Low : High).GetValueAt(lastExtendedBar)) == -dir) 
				signalValid = false;
		}

		#region Parameters
		[NinjaScriptProperty, Range(1, 99)]
		[Display(Name = "ERC Body %", GroupName = StrategyParameterGroupName, Order = 0)]
		public double ExtendedBodyPercent { get; set; }

		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[Display(Name = "Max Allowed Pre-Entry Bars", GroupName = StrategyParameterGroupName, Order = 1)]
		public int MaxAllowedBasingBars { get; set; }

		[NinjaScriptProperty, Range(int.MinValue, int.MaxValue)]
		[Display(Name = "Entry Offset (Ticks)", GroupName = StrategyParameterGroupName, Order = 2)]
		public int EntryOffset { get; set; }

		[NinjaScriptProperty, RefreshProperties(RefreshProperties.All)]
		[Display(Name = "ERC Min/Max Size Type", GroupName = StrategyParameterGroupName, Order = 3)]
		public ARC_MegaBarAlgo_AtrOrTicks ErcBarSizeThreshType { get; set; }
		
		[NinjaScriptProperty]
		[ARC_MegaBarAlgo_HideUnless(nameof(ErcBarSizeThreshType), ARC_MegaBarAlgo_PropComparisonType.EQ, ARC_MegaBarAlgo_AtrOrTicks.ATR)]
		[Display(Name = "ERC Min/Max Size ATR Period", GroupName = StrategyParameterGroupName, Order = 4)]
		public int ErcBarSizeATRPeriod { get; set; }
		
		[NinjaScriptProperty, Range(0, double.MaxValue)]
		[ARC_MegaBarAlgo_Rename("ERC Min Size (Ticks)", nameof(ErcBarSizeThreshType), ARC_MegaBarAlgo_PropComparisonType.EQ, ARC_MegaBarAlgo_AtrOrTicks.Ticks)]
		[ARC_MegaBarAlgo_Rename("ERC Min Size (ATRs)", nameof(ErcBarSizeThreshType), ARC_MegaBarAlgo_PropComparisonType.EQ, ARC_MegaBarAlgo_AtrOrTicks.ATR)]
		[Display(Name = "ERC Min Size", GroupName = StrategyParameterGroupName, Order = 5)]
		public double ErcMinBarSize { get; set; }

		[NinjaScriptProperty, Range(0, double.MaxValue)]
		[ARC_MegaBarAlgo_Rename("ERC Max Size (Ticks)", nameof(ErcBarSizeThreshType), ARC_MegaBarAlgo_PropComparisonType.EQ, ARC_MegaBarAlgo_AtrOrTicks.Ticks)]
		[ARC_MegaBarAlgo_Rename("ERC Max Size (ATRs)", nameof(ErcBarSizeThreshType), ARC_MegaBarAlgo_PropComparisonType.EQ, ARC_MegaBarAlgo_AtrOrTicks.ATR)]
		[Display(Name = "ERC Max Size", GroupName = StrategyParameterGroupName, Order = 6)]
		public double ErcMaxBarSize { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Require EMA", GroupName = StrategyParameterGroupName, Order = 7)]
		public bool RequireEma { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "EMA Period", GroupName = StrategyParameterGroupName, Order = 8)]
		public int EmaPeriod { get; set; }

		#region Stop Loss

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_MegaBarAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_MegaBarAlgo_PropComparisonType.EQ, ARC_MegaBarAlgo_BoolEnum.True)]
		[Display(Name = "Stop Loss Offset Type", GroupName = StopLossGroupName, Order = 1)]
		public ARC_MegaBarAlgo_MegaBarStopLossOffsetType StopLossOffsetType { get; set; }
		
		[NinjaScriptProperty, Range(int.MinValue, int.MaxValue)]
		[ARC_MegaBarAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_MegaBarAlgo_PropComparisonType.EQ, ARC_MegaBarAlgo_BoolEnum.True)]
		[ARC_MegaBarAlgo_Rename("Stop Loss Offset (Ticks)", nameof(StopLossOffsetType), ARC_MegaBarAlgo_PropComparisonType.EQ, ARC_MegaBarAlgo_MegaBarStopLossOffsetType.Ticks)]
		[ARC_MegaBarAlgo_Rename("Stop Loss Offset (% Basing Bar Range)", nameof(StopLossOffsetType), ARC_MegaBarAlgo_PropComparisonType.EQ, ARC_MegaBarAlgo_MegaBarStopLossOffsetType.PercentOfErcRange)]
		[Display(Name = "Stop Loss Offset", GroupName = StopLossGroupName, Order = 2)]
		public int StopLossOffset { get; set; }
		#endregion

		[Display(Name = "EMA Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 0)]
		public Stroke EmaStroke { get; set; }
		#endregion
	}

	public enum ARC_MegaBarAlgo_MegaBarStopLossOffsetType
	{
		Ticks,
		PercentOfErcRange
	}
}