#region Using declarations
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript.DrawingTools;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
using System.Linq;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using SharpDX;
using RectangleF = SharpDX.RectangleF;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_VolDivAlgo : ARC_VolDivAlgo_ARCStrategyBase
	{
		#region Properties/Fields
		public override string ProductVersion { get { return "v3.1.37 (5/5/2023)"; } }
		public override string ProductInfusionSoftTag { get { return "20552"; } }

		private Series<double> clusterTop;
		private Series<double> clusterBottom;
		private Series<int> entrySignals;
		#endregion

		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_VolDivAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "VD Algo";
				TicksPerCluster = 3;

				ShowVolumeCluster = true;
				VolumeClusterOutlineColor = Brushes.Black;
				VolumeClusterFillColor = Brushes.LightGray;
				ClusterFillOpacity = 75;
				ClusterOutlineThickness = 1;
				LongSignalFillColor = Brushes.Lime;
				LongSignalOutlineColor = Brushes.Black;
				ShortSignalFillColor = Brushes.Red;
				ShortSignalOutlineColor = Brushes.Black;
				SignalFillOpacity = 100;
				SignalOutlineThickness = 1;
				SignalOffset = 0;
			}
			else if (State == State.DataLoaded)
			{
				clusterTop = new Series<double>(this, MaximumBarsLookBack.Infinite);
				clusterBottom = new Series<double>(this, MaximumBarsLookBack.Infinite);
				entrySignals = new Series<int>(this, MaximumBarsLookBack.Infinite);
			}
		}

		protected override void OnPrimaryBar()
		{
			CalculateCluster();
			if (!clusterTop.IsValidDataPoint(0))
				return;

			var signal = Closes[0][0].ApproxCompare(Opens[0][0]);
			if (signal == 0)
				return;

			if (clusterTop[0].ApproxCompare(Opens[0][0]) != -signal || clusterBottom[0].ApproxCompare(Opens[0][0]) != -signal)
				return;

			entrySignals[0] = signal;
			if (!mmCanTrade || !TradeAllowedByFilters(entrySignals[0]))
				return;
			
			QueueEntry(entrySignals[0]);
		}

		protected override void OnBarUpdate()
		{
			try
			{
				base.OnBarUpdate();
			}
			catch (Exception ex)
			{
				Log(ex.Message, LogLevel.Error);
				Log(ex.StackTrace, LogLevel.Error);
				throw;
			}
		}

		private bool hasPrintedBarSizeExceedsMaWarning;
		private void CalculateCluster()
		{
			var clusterHeight = (TicksPerCluster - 1) * TickSize;
			if (Highs[0][0] - Lows[0][0] < clusterHeight)
				return;

			if (CurrentBars[0] < 1)
				return;

			var curTime = Times[0][0];
			var lastDiffTimedBar = MRO(() => Times[0][0] != curTime, 1, Math.Min(255, CurrentBars[0]));
			if (lastDiffTimedBar == -1)
				return;

			if ((Highs[0][0] - Lows[0][0]) / TickSize > 1e5)
			{
				if (hasPrintedBarSizeExceedsMaWarning)
					return;

				hasPrintedBarSizeExceedsMaWarning = true;
				Log(string.Format("Bar at time {0} exceeded max ticks per bar of 10,000. All bars that exceed this threshold will be skipped.", Times[0][0]), LogLevel.Warning);
				return;
			}

			var volumes = new double[(int)Math.Round((Highs[0][0] - Lows[0][0]) / TickSize) + 1];
			for (var i = 0; i < CurrentBars[orderBarsIdx]; i++)
			{
				if (Times[orderBarsIdx][i] <= Times[0][lastDiffTimedBar])
					break;

				if (Times[orderBarsIdx][i] > Times[0][0])
					continue;

				if (Closes[orderBarsIdx][i].ApproxCompare(Highs[0][0]) == 1 || Closes[orderBarsIdx][i].ApproxCompare(Lows[0][0]) == -1)
					continue;

				var idx = (int)Math.Round((Closes[orderBarsIdx][i] - Lows[0][0]) / TickSize);
				volumes[idx] += Volumes[orderBarsIdx][i];
			}

			// No clusters on gap bars
			if (!volumes.Any() || volumes.Max().ApproxCompare(0) == 0)
				return;

			var maxClusterVolume = 0d;
			var clusterVolume = 0d;
			for (var i = 0; i < volumes.Length; i++)
			{
				clusterVolume += volumes[i];
				if (i < TicksPerCluster - 1)
					continue;

				if (i >= TicksPerCluster)
					clusterVolume -= volumes[i - TicksPerCluster];

				if (clusterVolume <= maxClusterVolume)
					continue;

				// TODO Go with the cluster closest to the body if two have the same max volume
				clusterTop[0] = Lows[0][0] + TickSize * i;
				clusterBottom[0] = clusterTop[0] - clusterHeight;
				maxClusterVolume = clusterVolume;
			}
		}

		#region Rendering
		private void DrawDiamond(ChartScale chartScale, float midX, float width, double price, SharpDX.Direct2D1.Brush fillBrush, SharpDX.Direct2D1.Brush outlineBrush, int outlineThickness)
		{
			var priorTransform = RenderTarget.Transform;
			try
			{
				var y = chartScale.GetYByValue(price) - width / 2;
				RenderTarget.Transform = Matrix3x2.Rotation(DrawingTool.MathHelper.DegreesToRadians(45), new Vector2(midX, y + width / 2));
				var rect = new RectangleF(midX - width / 2, y, width, width);
				RenderTarget.FillRectangle(rect, fillBrush);
				if (outlineBrush == null)
					return;

				var outlineRect = new RectangleF(midX - width / 2 + outlineThickness / 2, y + outlineThickness / 2, width - outlineThickness + 1, width - outlineThickness + 1);
				RenderTarget.DrawRectangle(outlineRect, outlineBrush, outlineThickness);
			}
			finally
			{
				RenderTarget.Transform = priorTransform;
			}
		}

		private void DrawRect(ChartScale chartScale, float midX, float width, double topPrice, double bottomPrice, SharpDX.Direct2D1.Brush outlineBrush, SharpDX.Direct2D1.Brush fillBrush, int outlineThickness)
		{
			var ys = new[] { topPrice, bottomPrice }
				.Select(chartScale.GetYByValue)
				.ToArray();
			var rect = new RectangleF(midX - width / 2, ys[1], width, ys[0] - ys[1]);
			RenderTarget.FillRectangle(rect, fillBrush);
			if (outlineBrush == null)
				return;

			var outlineRect = new RectangleF(midX - width / 2 + outlineThickness / 2, ys[1], width - outlineThickness, ys[0] - ys[1]);
			RenderTarget.DrawRectangle(outlineRect, outlineBrush, outlineThickness);
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			var shapeWidth = chartControl.GetBarPaintWidth(ChartBars);
			using (var clusterDxBrush = VolumeClusterOutlineColor.ToDxBrush(RenderTarget))
			using (var clusterDxFillBrush = VolumeClusterFillColor.ToDxBrush(RenderTarget, ClusterFillOpacity / 100f))
			using (var lSignalFillBrush = LongSignalFillColor.ToDxBrush(RenderTarget, ClusterFillOpacity / 100f))
			using (var sSignalFillBrush = ShortSignalFillColor.ToDxBrush(RenderTarget, ClusterFillOpacity / 100f))
			using (var lSignalOutlineBrush = LongSignalOutlineColor.ToDxBrush(RenderTarget, ClusterFillOpacity / 100f))
			using (var sSignalOutlineBrush = ShortSignalOutlineColor.ToDxBrush(RenderTarget, ClusterFillOpacity / 100f))
			{
				for (var i = ChartBars.FromIndex; i <= ChartBars.ToIndex; i++)
				{
					var midX = chartControl.GetXByBarIndex(ChartBars, i);
					if (clusterTop.IsValidDataPointAt(i) && ShowVolumeCluster)
						DrawRect(chartScale, midX, shapeWidth, clusterBottom.GetValueAt(i), clusterTop.GetValueAt(i), clusterDxBrush, clusterDxFillBrush, ClusterOutlineThickness);

					if (!entrySignals.IsValidDataPointAt(i))
						continue;

					var dir = entrySignals.GetValueAt(i);
					var fillBrush = dir == 1 ? lSignalFillBrush : sSignalFillBrush;
					var outlineBrush = dir == 1 ? lSignalOutlineBrush : sSignalOutlineBrush;
					DrawDiamond(chartScale, midX, shapeWidth, (dir == 1 ? Lows[0] : Highs[0]).GetValueAt(i) - dir * SignalOffset * TickSize, fillBrush, outlineBrush, SignalOutlineThickness);
				}
			}
		}
		#endregion

		#region Parameters
		#region General
		[NinjaScriptProperty]
		[Range(2, int.MaxValue)]
		[Display(Name = "Ticks Per Cluster", GroupName = StrategyParameterGroupName, Order = 0, Description = "The number of ticks that make up a cluster.")]
		public int TicksPerCluster { get; set; }
		#endregion

		#region Visuals
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Show Volume Clusters", GroupName = StrategyVisualsParameterGroupName, Order = 0)]
		public bool ShowVolumeCluster { get; set; }

		[XmlIgnore]
		[ARC_VolDivAlgo_HideUnless("ShowVolumeCluster", ARC_VolDivAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Volume Cluster (Fill)", GroupName = StrategyVisualsParameterGroupName, Order = 1)]
		public Brush VolumeClusterFillColor { get; set; }

		[Range(0, 100)]
		[ARC_VolDivAlgo_HideUnless("ShowVolumeCluster", ARC_VolDivAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Cluster - Opacity (%)", GroupName = StrategyVisualsParameterGroupName, Order = 2, Description = "In percent, the opacity of the cluster fill.")]
		public int ClusterFillOpacity { get; set; }

		[Browsable(false)]
		public string VolumeClusterFillColorSerialize
		{
			get { return Serialize.BrushToString(VolumeClusterFillColor); }
			set { VolumeClusterFillColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[ARC_VolDivAlgo_HideUnless("ShowVolumeCluster", ARC_VolDivAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Volume Cluster (Outline)", GroupName = StrategyVisualsParameterGroupName, Order = 3)]
		public Brush VolumeClusterOutlineColor { get; set; }

		[Browsable(false)]
		public string VolumeClusterOutlineColorSerialize
		{
			get { return Serialize.BrushToString(VolumeClusterOutlineColor); }
			set { VolumeClusterOutlineColor = Serialize.StringToBrush(value); }
		}

		[Range(0, int.MaxValue)]
		[ARC_VolDivAlgo_HideUnless("ShowVolumeCluster", ARC_VolDivAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Cluster - Outline Thickness (Pixels)", GroupName = StrategyVisualsParameterGroupName, Order = 4, Description = "In pixels, the thickness of the cluster outline.")]
		public int ClusterOutlineThickness { get; set; }

		[Range(0, 1000)]
		[Display(Name = "Signals - Offset (Pixels)", GroupName = StrategyVisualsParameterGroupName, Order = 5, Description = "Number of pixels distance between the high (long)/low (short) and the signal diamond.")]
		public int SignalOffset { get; set; }

		[XmlIgnore]
		[Display(Name = "Signals - Long (Fill)", GroupName = StrategyVisualsParameterGroupName, Order = 6)]
		public Brush LongSignalFillColor { get; set; }

		[Browsable(false)]
		public string LongSignalFillColorSerialize
		{
			get { return Serialize.BrushToString(LongSignalFillColor); }
			set { LongSignalFillColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Signals - Long (Outline)", GroupName = StrategyVisualsParameterGroupName, Order = 7)]
		public Brush LongSignalOutlineColor { get; set; }

		[Browsable(false)]
		public string LongSignalOutlineColorSerialize
		{
			get { return Serialize.BrushToString(LongSignalOutlineColor); }
			set { LongSignalOutlineColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Signals - Short (Fill)", GroupName = StrategyVisualsParameterGroupName, Order = 8)]
		public Brush ShortSignalFillColor { get; set; }

		[Browsable(false)]
		public string ShortSignalFillColorSerialize
		{
			get { return Serialize.BrushToString(ShortSignalFillColor); }
			set { ShortSignalFillColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Signals - Short (Outline)", GroupName = StrategyVisualsParameterGroupName, Order = 8)]
		public Brush ShortSignalOutlineColor { get; set; }

		[Browsable(false)]
		public string ShortSignalOutlineColorSerialize
		{
			get { return Serialize.BrushToString(ShortSignalOutlineColor); }
			set { ShortSignalOutlineColor = Serialize.StringToBrush(value); }
		}

		[Range(0, 100)]
		[Display(Name = "Signals - Opacity (%)", GroupName = StrategyVisualsParameterGroupName, Order = 9, Description = "In percent, the opacity of the diamond fill.")]
		public int SignalFillOpacity { get; set; }

		[Range(0, int.MaxValue)]
		[Display(Name = "Signals - Outline Thickness (Pixels)", GroupName = StrategyVisualsParameterGroupName, Order = 10, Description = "In pixels, the thickness of the diamond outline.")]
		public int SignalOutlineThickness { get; set; }
		#endregion
		#endregion
	}
}