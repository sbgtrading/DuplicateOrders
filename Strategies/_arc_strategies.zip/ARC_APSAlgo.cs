using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.NinjaScript.Strategies.Licensing;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_APSAlgo : ARC_APSAlgo_ARCStrategyBase
	{
		public override string ProductVersion => "v1.0.1 (3/18/2024)";
		public override string ProductInfusionSoftTag => "27517";
		protected override bool AllowIntrabarEntries => true;
		public override bool HasStrategyBasedStops => true;

		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_APSAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "APS Algo";

				MaxBarDelay = 0;
				EntryOffset = 1;
				RequireInsideBars = true;

				StopLossOffset = 0;
				StopLossOffset = 1;
				StopBasedOn = ARC_APSAlgo_APSStopBasedOn.FirstBar;
				MAColor2 = Brushes.DeepSkyBlue;
				VMFastEmaPeriod = 3;
				VMSlowEmaPeriod = 8;
				
				DotsUpRisingColor = Brushes.White;
				DotsDownFallingColor = Brushes.Black;
				BBUpperColor = Brushes.Transparent;
				BBLowerColor = Brushes.Transparent;
				ChannelColor = Brushes.Transparent;
				VMSlowEmaColor = Brushes.Magenta;
			}
		}
		
		protected override void OnTickBar()
		{
			if (CurrentBars[0] < 0)
				return;
			
			if (lastSignalBar == CurrentBars[0] + 1)
				return;

			for (var i = 0; i <= MaxBarDelay; i++)
			{
				if (CurrentBars[0] < i)
					return;

				// Decide direction based on tick (if tick was up, we're entering resistance blocks)
				var dir = -Closes[0][i].ApproxCompare(Opens[0][i]);
				if (dir == 0)
					continue;

				var entryPrice = (dir == 1 ? Highs : Lows)[0][i] + dir * EntryOffset * TickSize;
				if (Close[0].ApproxCompare(entryPrice) == -dir)
					continue;

				var nonInsideBarFound = false;
				for (var i2 = 0; i2 < i; i2++)
					if (Highs[0][i2].ApproxCompare(Highs[0][i]) == 1 || Lows[0][i2].ApproxCompare(Lows[0][i]) == -1)
					{
						nonInsideBarFound = true;
						break;
					}

				if (nonInsideBarFound)
					continue;
				
				if (!TradeAllowed(dir))
					continue;

				var sl = (double?)null;
				if (EnableAlgoDefinedStopLosses)
				{
					var stopBarIdx = StopBasedOn == ARC_APSAlgo_APSStopBasedOn.FirstBar ? i : 0;
					var slOffsetMultiple = StopLossOffsetType == ARC_APSAlgo_APSStopLossOffsetType.PercentOfBarRange ? (Highs[0][stopBarIdx] - Lows[0][stopBarIdx]) / 100 : TickSize;
					sl = (dir == 1 ? Lows : Highs)[0][stopBarIdx] - dir * slOffsetMultiple * StopLossOffset;
					if (!TradeAllowedWithStop(Close[0], sl.Value))
						continue;
				}

				QueueEntry(dir, 1, stopLossPrice: sl);
				break;
			}
		}

        #region Parameters
        [NinjaScriptProperty, Range(0, int.MaxValue)]
		[Display(Name = "Max Bar Delay", GroupName = StrategyParameterGroupName, Order = 0)]
		public int MaxBarDelay { get; set; }

		[NinjaScriptProperty, Range(int.MinValue, int.MaxValue)]
		[Display(Name = "Entry Price Offset", GroupName = StrategyParameterGroupName, Order = 1)]
		public int EntryOffset { get; set; }

		[NinjaScriptProperty]
		[ARC_APSAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_APSAlgo_PropComparisonType.EQ, ARC_APSAlgo_BoolEnum.True)]
		[Display(Name = "Require Inside Bars for Multibar Signals", GroupName = StrategyParameterGroupName, Order = 2)]
		public bool RequireInsideBars { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_APSAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_APSAlgo_PropComparisonType.EQ, ARC_APSAlgo_BoolEnum.True)]
		[Display(Name = "Stop Price Offset Method", GroupName = StopLossGroupName, Order = 1)]
		public ARC_APSAlgo_APSStopLossOffsetType StopLossOffsetType { get; set; }
		
		[NinjaScriptProperty, Range(int.MinValue, int.MaxValue)]
		[ARC_APSAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_APSAlgo_PropComparisonType.EQ, ARC_APSAlgo_BoolEnum.True)]
		[ARC_APSAlgo_Rename("Stop Loss Offset (Ticks)", nameof(StopLossOffsetType), ARC_APSAlgo_PropComparisonType.EQ, ARC_APSAlgo_APSStopLossOffsetType.Ticks)]
		[ARC_APSAlgo_Rename("Stop Loss Offset (% Bar Range)", nameof(StopLossOffsetType), ARC_APSAlgo_PropComparisonType.EQ, ARC_APSAlgo_APSStopLossOffsetType.PercentOfBarRange)]
		[Display(Name = "Stop Price Offset", GroupName = StopLossGroupName, Order = 1)]
		public int StopLossOffset { get; set; }

		[NinjaScriptProperty]
		[ARC_APSAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_APSAlgo_PropComparisonType.EQ, ARC_APSAlgo_BoolEnum.True)]
		[Display(Name = "Stop Based on", GroupName = StopLossGroupName, Order = 4)]
		public ARC_APSAlgo_APSStopBasedOn StopBasedOn { get; set; }
		#endregion
	}

	public enum ARC_APSAlgo_APSStopLossOffsetType
	{
		Ticks,
		PercentOfBarRange
	}
	
	public enum ARC_APSAlgo_APSStopBasedOn
	{
		BarBeforeBreak,
		FirstBar
	}
}