#define DoLicense		//Uncomment to add NT licensing code at compilation for production only
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
using System.IO;
using System.Reflection;
using NinjaTrader.NinjaScript.Indicators.ARC.AlgoSup;
using NinjaTrader.NinjaScript.Indicators.ARC;
using System.Windows.Controls;
using System.Windows.Automation;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_DeltaAlgo : ARC_DAStrategyBase
	{
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		bool IsDebug = false;
		string ModuleName = "DeltaAlgo";


		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			public static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			public static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "16821"};
		#region ARCLicense
		#region --  Registry class  --
		public class ModifyRegistry
		{
			public int NO_KEY_DEFINED = -1;
			public int ERROR_READING_KEY = -2;
			public string ErrorStatus = string.Empty;

			private bool showError = true;
			/// <summary>
			/// A property to show or hide error messages 
			/// (default = false)
			/// </summary>
			public bool ShowError
			{
				get { return showError; }
				set	{ showError = value; }
			}

			private string subKey = "Software\\NeuroStreet\\Settings";
			/// <summary>
			/// A property to set the SubKey value
			/// (default = "SOFTWARE\\" + Application.ProductName.ToUpper())
			/// </summary>
			public string SubKey
			{
				get { return subKey; }
				set	{ subKey = value; }
			}

			private Microsoft.Win32.RegistryKey baseRegistryKey = Microsoft.Win32.Registry.CurrentUser;
			/// <summary>
			/// A property to set the BaseRegistryKey value.
			/// (default = Registry.LocalMachine)
			/// </summary>
			public Microsoft.Win32.RegistryKey BaseRegistryKey
			{
				get { return baseRegistryKey; }
				set	{ baseRegistryKey = value; }
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// To read a registry key.
			/// input: KeyName (string)
			/// output: value (string) 
			/// </summary>
			public int Read(string KeyName, NinjaTrader.NinjaScript.StrategyBase parent)
			{
				// Opening the registry key
				var rk = baseRegistryKey ;
				// Open a subKey as read-only
				var sk1 = rk.OpenSubKey(subKey);
				// If the RegistrySubKey doesn't exist -> (null)
				if ( sk1 == null )
				{
					return NO_KEY_DEFINED;
				}
				else
				{
					try 
					{
						// If the RegistryKey exists I get its value
						// or null is returned.
						return Convert.ToInt32(sk1.GetValue(KeyName));
					}
					catch (Exception e)
					{
						ErrorStatus = e.ToString();
						// AAAAAAAAAAARGH, an error!
						if(parent!=null) ShowErrorMessage(e, "Reading registry " + KeyName, parent);
						return ERROR_READING_KEY;
					}
				}
			}	

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// To write into a registry key.
			/// input: KeyName (string) , Value (object)
			/// output: true or false 
			/// </summary>
			public bool Write(string KeyName, object Value, NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					// I have to use CreateSubKey 
					// (create or open it if already exits), 
					// 'cause OpenSubKey open a subKey as read-only
					var sk1 = rk.CreateSubKey(subKey);
					// Save the value
					sk1.SetValue(KeyName, Value);

					return true;
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					//ShowErrorMessage(e, "Writing registry " + KeyName, parent);
					return false;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// To delete a registry key.
			/// input: KeyName (string)
			/// output: true or false 
			/// </summary>
			public bool DeleteKey(string KeyName, NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					var sk1 = rk.CreateSubKey(subKey);
					// If the RegistrySubKey doesn't exists -> (true)
					if ( sk1 == null )
						return true;
					else
						sk1.DeleteValue(KeyName);

					return true;
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					//ShowErrorMessage(e, "Deleting SubKey " + subKey, parent);
					return false;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// To delete a sub key and any child.
			/// input: void
			/// output: true or false 
			/// </summary>
			public bool DeleteSubKeyTree(NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					var sk1 = rk.OpenSubKey(subKey);
					// If the RegistryKey exists, I delete it
					if ( sk1 != null )
						rk.DeleteSubKeyTree(subKey);

					return true;
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					//ShowErrorMessage(e, "Deleting SubKey " + subKey, parent);
					return false;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// Retrive the count of subkeys at the current key.
			/// input: void
			/// output: number of subkeys
			/// </summary>
			public int SubKeyCount(NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					var sk1 = rk.OpenSubKey(subKey);
					// If the RegistryKey exists...
					if ( sk1 != null )
						return sk1.SubKeyCount;
					else
						return 0; 
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					//ShowErrorMessage(e, "Retriving subkeys of " + subKey, parent);
					return 0;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// Retrive the count of values in the key.
			/// input: void
			/// output: number of keys
			/// </summary>
			public int ValueCount(NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					var sk1 = rk.OpenSubKey(subKey);
					// If the RegistryKey exists...
					if ( sk1 != null )
						return sk1.ValueCount;
					else
						return 0; 
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					//ShowErrorMessage(e, "Retriving keys of " + subKey, parent);
					return 0;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/
			
			private void ShowErrorMessage(Exception e, string Title, NinjaTrader.NinjaScript.StrategyBase parent)
			{
				if (showError)
					parent.Print(e.Message);
			}
		}
		#endregion ----------------------------------------
		ModifyRegistry Reg = new ModifyRegistry();
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);
//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(bool PingRegistry){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
				search = "nscid_*.txt";
				filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
				if(filCustom!=null){
					foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
						var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
						if(elements.Length>1)
							ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
					}
				}
			}
			if(ret_custid == -1 && PingRegistry){
				//the config file doesn't exist, create one based on what is recovered from the registry
				try{
if(IsDebug) Print(" ARCCID file is getting custid from registry because of file missing");
					ret_custid = Reg.Read("custid", this);
				}catch(Exception ex2){
if(IsDebug) Print("Registry read error: "+ex2.ToString());
					if(!LicErrorMessageHandler.IsDuplicate(ex2.ToString())) LogMsg("Please run your 'ARC_LicenseActivator v1' and supply your ARCAI Contact ID number", Cbi.LogLevel.Alert);
					return -1;
				}
			}
			if(ret_custid>0){
				var fname = System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt");
				if(!System.IO.File.Exists(fname)){
if(IsDebug) Print(" creating arccid_.txt file");
					System.IO.File.WriteAllText(
						fname,
						ret_custid.ToString()
					);
				}
			}
			return ret_custid;
			#endregion
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			MachineId = NinjaTrader.Cbi.License.MachineId;
if(IsDebug)Print("\n\n\nRunning ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				NewCustId = GetCustID(true);
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				NewCustId = GetCustID(true);
				UserId = NewCustId.ToString();
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");
				NewCustId = GetCustID(true);
				#region -- Read config folder for ContactID --
//				string folder = ARCConfigDirectory;
//				string search = "arccid_*.txt";
//				var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
//				if(filCustom!=null){
//					foreach(System.IO.FileInfo fi in filCustom){
//						var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
//						if(elements.Length>1)
//							NewCustId = int.Parse(elements[1]);
//					}
//				}else{//the config file doesn't exist, create one based on what is recovered from the registry
//					try{
//if(IsDebug) Print(" ARCCID file is getting custid from registry because of file missing");
//						NewCustId = Reg.Read("custid", this);
//					}catch(Exception ex2){
//if(IsDebug) Print("Registry read error: "+ex2.ToString());
//						if(!LicErrorMessageHandler.IsDuplicate(ex2.ToString())) LogMsg("Please run your 'ARC_LicenseActivator v1' and supply your ARCAI Contact ID number", Cbi.LogLevel.Alert);
//						return false;
//					}
//					if(NewCustId>0){
//						System.IO.File.WriteAllText(
//							System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+NewCustId.ToString().Trim()+".txt"),
//							NewCustId.ToString()
//						);
//					}
//				}
				#endregion
//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0 || UserId.CompareTo("176183")==0;//Gilbert Simpson
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, NinjaTrader.Cbi.License.MachineId, ModuleName, keyString, UserId);
if(IsDebug) Print("   URL: "+URL);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+productVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).Ticks.ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}

		#endregion

		#region TemplateManager

		#region RegObjectConverters

		#region Abstract StringListConverter
		/// <summary>
		/// Description of StringListConverter.
		/// </summary>
		internal abstract class StringListConverter : StringConverter
		{
			protected bool readOnly = true;
			protected abstract List<string> StandardValues { get; }

			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, but allow free-form entry
				return readOnly;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
			{
				return new StandardValuesCollection(StandardValues);
			}
		}
		#endregion

		#region Abstract FileListConverter
		internal abstract class FileListConverter : StringListConverter
		{
			protected string directoryName = "";

			protected abstract string AddFile(FileInfo file);

			protected override List<string> StandardValues
			{
				get
				{
					List<string> listFiles = new List<string>();

					DirectoryInfo dir = new DirectoryInfo(directoryName);
					if (!dir.Exists)
						dir.Create();

					FileInfo[] files = dir.GetFiles();
					foreach (FileInfo file in files)
					{
						string addFile = AddFile(file);
						if (addFile != null)
							listFiles.Add(addFile);
					}

					return listFiles;
				}
			}
		}
		#endregion

		#region FileListConverter
		internal class FileListConverterFilter : FileListConverter
		{
			protected string startsWith = "";
			protected string endsWidth = "";

			protected virtual string AddFileName(string fileName, int addFileLength)
			{
				return fileName.Substring(startsWith.Length, addFileLength);
			}

			protected override string AddFile(FileInfo file)
			{
				string fileName = file.Name;
				int addFileLength = fileName.Length - startsWith.Length - endsWidth.Length;
				bool startsWithFlag = ((startsWith.Length == 0) || fileName.StartsWith(startsWith));
				bool endsWithFlag = ((endsWidth.Length == 0) || fileName.EndsWith(endsWidth));
				if (startsWithFlag && endsWithFlag)
					return AddFileName(fileName, addFileLength);

				return null;
			}
		}
		#endregion

		#region PeriodTypeSupported
		internal sealed class PeriodTypeSupported
		{
			private static PeriodTypeSupported instance = new PeriodTypeSupported();

			private Dictionary<string, BarsPeriodType> dictionaryPeriodTypes;

			public static PeriodTypeSupported Instance
			{
				get
				{
					return instance;
				}
			}

			private PeriodTypeSupported()
			{
				dictionaryPeriodTypes = new Dictionary<string, BarsPeriodType>(BarsType.GetSupported().Length);
				foreach (BarsPeriodType b in BarsType.GetSupported())
				{
					try
					{
						dictionaryPeriodTypes.Add(BarsType.GetBarsPeriodTypeName(b), b);
					}
					catch (Exception)
					{

					}
				}
			}

			public List<string> Keys
			{
				get { return new List<string>(dictionaryPeriodTypes.Keys); }
			}

			public string PeriodType2String(BarsPeriodType type)
			{
				foreach (var pair in dictionaryPeriodTypes)
				{
					if (pair.Value == type)
						return pair.Key;
				}
				throw new ArgumentException(string.Format("PeriodType2String: key not found for value {0}", type));
			}

			public BarsPeriodType String2PeriodType(string value)
			{
				if (dictionaryPeriodTypes.ContainsKey(value))
					return dictionaryPeriodTypes[value];

				throw new ArgumentException(string.Format("String2PeriodType: value not found for key {0}", value));
			}

		}

		internal class PeriodTypeListConverter : StringListConverter
		{
			protected override List<string> StandardValues
			{
				get
				{
					return PeriodTypeSupported.Instance.Keys;
				}
			}
		}
		#endregion

		#region XmlSerializeProperties
		/// <summary>
		/// Description of XmlSerializeProperties.
		/// </summary>
		internal class XmlSerializeProperties
		{
			#region MethodInfoType internal class for setter
			public class MethodInfoType
			{
				private MethodInfo methodInfo;
				public MethodInfo MethodInfo
				{
					get { return methodInfo; }
				}

				private Type type;
				public Type Type
				{
					get { return type; }
				}

				public MethodInfoType(MethodInfo methodInfo, Type type)
				{
					this.methodInfo = methodInfo;
					this.type = type;
				}

				public void Clone(object src, object dest)
				{
					try
					{
						MethodInfo methodSrc = XmlSerializeProperties.GetMethodInfo(dest, "get_" + methodInfo.Name.Substring(4));
						if (methodSrc == null)
							return;

						object[] args = new object[1];
						args[0] = methodSrc.Invoke(src, null);
						methodInfo.Invoke(dest, args);
					}
					catch (Exception)
					{
						return;
					}
				}
			}
			#endregion

			#region Variables
			protected Object reflectOb = null;
			protected List<MethodInfo> getter = null;
			protected List<MethodInfoType> setter = null;
			public List<XmlSerializeProperties.MethodInfoType> Setter
			{
				get { return setter; }
			}
			#endregion

			#region Constructors
			public XmlSerializeProperties(Type type) : this(type, null)
			{
			}

			public XmlSerializeProperties(Type type, Type baseType)
			{
				try
				{
					getter = FillGetter(type, baseType);
					setter = FillSetter(type, baseType);
				}
				catch (Exception e)
				{
					string msg = e.Message;
					string stack = e.StackTrace;
					return;
				}
			}

			public XmlSerializeProperties(Object reflectOb) : this(reflectOb, null)
			{
			}

			public XmlSerializeProperties(Object reflectOb, Type baseType) : this(reflectOb.GetType(), baseType)
			{
				this.reflectOb = reflectOb;
			}
			#endregion

			#region Initialize
			protected virtual bool ValidType(Type type)
			{
				return true;
			}

			protected virtual bool IsType(MethodInfo mInfo, Type baseType)
			{
				if (baseType == null)
					return true;

				Type typeCompare = mInfo.DeclaringType;
				while (typeCompare != null)
				{
					if (typeCompare == baseType)
						return true;

					typeCompare = typeCompare.BaseType;
				}

				return false;
			}

			private bool ValidMethod(Type type, Type baseType, MethodInfo m, string start)
			{
				if (
					m.IsPublic &&
					m.IsSpecialName &&
					m.Name.StartsWith(start) &&
					IsType(m, baseType))
				{
					var property = type.GetProperty(m.Name.Substring(start.Length));
					var attributes = property.GetCustomAttributes(typeof(XmlIgnoreAttribute), false);
					return (attributes.Length == 0);
				}

				return false;
			}

			private List<MethodInfo> FillGetter(Type type, Type baseType)
			{
				MethodInfo[] mInfo = type.GetMethods();
				List<MethodInfo> listMethods = new List<MethodInfo>(mInfo.Length);
				for (int i = 0; i < mInfo.Length; i++)
				{
					if (ValidMethod(type, baseType, mInfo[i], "get_") &&
						ValidType(mInfo[i].ReturnType))
					{
						listMethods.Add(mInfo[i]);
					}
				}
				listMethods.TrimExcess();
				return listMethods;
			}

			private List<MethodInfoType> FillSetter(Type type, Type baseType)
			{
				MethodInfo[] mInfo = type.GetMethods();
				List<MethodInfoType> listMethods = new List<MethodInfoType>(mInfo.Length);
				for (int i = 0; i < mInfo.Length; i++)
				{
					if (ValidMethod(type, baseType, mInfo[i], "set_"))
					{
						ParameterInfo[] pi = mInfo[i].GetParameters();
						if (pi.Length > 0 && ValidType(pi[0].ParameterType))
							listMethods.Add(new MethodInfoType(mInfo[i], pi[0].ParameterType));
					}
				}
				listMethods.TrimExcess();
				return listMethods;
			}
			#endregion

			#region Properties Loader
			protected virtual object LoadValue(object value, MethodInfoType mit)
			{
				if (mit.Type.IsEnum)
					return Enum.Parse(mit.Type, (string)value);

				TypeCode typeCode = Type.GetTypeCode(mit.Type);
				switch (typeCode)
				{
					case TypeCode.Boolean:
						return Convert.ToBoolean(value);
					case TypeCode.Int32:
						return Convert.ToInt32(value);
					case TypeCode.Double:
						return Convert.ToDouble(value);
					case TypeCode.String:
						return value;
				}

				return null;
			}
			#endregion

			#region Properties storage
			protected virtual object SaveValue(object value, Type type)
			{
				if (ValidType(type))
				{
					return value;
				}
				return null;
			}
			#endregion

			#region static properties helper
			public static bool Save(string fileName, object o)
			{
				FileInfo fi = new FileInfo(fileName);
				try
				{
					DirectoryInfo di = fi.Directory;
					if (!di.Exists)
						di.Create();

					using (System.IO.StreamWriter sw = System.IO.File.CreateText(fileName))
					{
						XmlSerializer xs = new XmlSerializer(o.GetType());
						xs.Serialize(sw, o);
					}
					return true;
				}
				catch (Exception e)
				{
					//	            LogNT.PrintToOutput( e.ToString() );
					//				LogNT.PrintToOutput( e.StackTrace );
					try
					{
						fi.Delete();
					}
					catch (Exception)
					{
					}
					return false;
				}
			}


			public static object Load(string fileName, Type t)
			{
				try
				{
					FileInfo fi = new FileInfo(fileName);
					DirectoryInfo di = fi.Directory;
					if (!di.Exists)
						di.Create();

					if (!fi.Exists)
						return null;

					using (System.IO.StreamReader sr = System.IO.File.OpenText(fileName))
					{
						XmlSerializer xs = new XmlSerializer(t);
						object oLoad = xs.Deserialize(sr);
						sr.Close();

						return oLoad;
					}
				}
				catch (Exception e)
				{
					//	            LogNT.PrintToOutput( e.ToString() );
					//				LogNT.PrintToOutput( e.StackTrace );
					return null;
				}
			}

			public static bool Load(string fileName, object o)
			{
				try
				{
					object oLoad = Load(fileName, o.GetType());
					if (oLoad == null)
						return false;

					XmlSerializeProperties.Clone(oLoad, o);
				}
				catch (Exception)
				{
				}
				return false;
			}

			public static MethodInfo GetMethodInfo(Object obj, String methodName)
			{
				MethodInfo methodInfo = null;
				try
				{
					methodInfo = obj.GetType().GetMethod(methodName);
				}
				catch (Exception) { }

				return methodInfo;
			}

			public static object Clone(object toClone)
			{
				ConstructorInfo ci = toClone.GetType().GetConstructor(new Type[] { });
				object toLoad = ci.Invoke(new object[] { });
				Clone(toClone, toLoad);
				return toLoad;
			}

			public static void Clone(object src, object dest)
			{
				XmlSerializeProperties propertiesInOut = new XmlSerializeProperties(src);
				foreach (XmlSerializeProperties.MethodInfoType miType in propertiesInOut.Setter)
					miType.Clone(src, dest);
			}

			public static String GetStringProperty(Object obj, String methodName)
			{
				String value = null;
				try
				{
					MethodInfo methodInfo = obj.GetType().GetMethod(methodName);
					value = (String)methodInfo.Invoke(obj, new Object[0]);
				}
				catch (Exception) { }

				return value;
			}

			public static int GetInt32Property(Object obj, String methodName)
			{
				int value = 0;
				try
				{
					MethodInfo methodInfo = obj.GetType().GetMethod(methodName);
					value = (int)methodInfo.Invoke(obj, new Object[0]);
				}
				catch (Exception) { }

				return value;
			}

			public static object GetObjectProperty(Object obj, string methodName)
			{
				try
				{
					MethodInfo methodInfo = obj.GetType().GetMethod(methodName);
					return methodInfo.Invoke(obj, new Object[0]);
				}
				catch (Exception)
				{
				}

				return null;
			}

			public static object GetObjectProperty(Object obj, String methodName, string param)
			{
				try
				{
					MethodInfo methodInfo = obj.GetType().GetMethod(methodName);
					return methodInfo.Invoke(obj, new Object[] { param });
				}
				catch (Exception e)
				{
					string msg = e.Message;
					string stack = e.StackTrace;
				}

				return null;
			}
			#endregion

		}
		#endregion

		public class ObjectSerializer
		{
			#region PropertiesInOut
			/// <summary>
			/// Description of PropertiesInOut.
			/// </summary>
			public class PropertiesInOut
			{
				#region MethodInfoType internal class for setter
				public class MethodInfoType
				{
					private MethodInfo methodInfo;
					public MethodInfo MethodInfo
					{
						get { return methodInfo; }
					}

					private Type type;
					public Type Type
					{
						get { return type; }
					}

					public MethodInfoType(MethodInfo methodInfo, Type type)
					{
						this.methodInfo = methodInfo;
						this.type = type;
					}

					public void Clone(object src, object dest)
					{
						try
						{
							MethodInfo methodSrc = PropertiesInOut.GetMethodInfo(dest, "get_" + methodInfo.Name.Substring(4));
							if (methodSrc == null)
								return;

							object[] args = new object[1];
							args[0] = methodSrc.Invoke(src, null);
							methodInfo.Invoke(dest, args);
						}
						catch (Exception)
						{
							return;
						}
					}
				}
				#endregion

				#region Variables
				protected Object reflectOb = null;
				protected List<MethodInfo> getter = null;
				public List<MethodInfo> Getter
				{
					get { return getter; }
				}
				protected List<MethodInfoType> setter = null;
				public List<PropertiesInOut.MethodInfoType> Setter
				{
					get { return setter; }
				}
				#endregion

				#region Constructors
				public PropertiesInOut(Type type) : this(type, null)
				{
				}

				public PropertiesInOut(Type type, Type baseType)
				{
					try
					{
						getter = FillGetter(type, baseType);
						setter = FillSetter(type, baseType);
					}
					catch (Exception e)
					{
						string msg = e.Message;
						string stack = e.StackTrace;
						return;
					}
				}

				public PropertiesInOut(Object reflectOb) : this(reflectOb, null)
				{
				}

				public PropertiesInOut(Object reflectOb, Type baseType) : this(reflectOb.GetType(), baseType)
				{
					this.reflectOb = reflectOb;
				}
				#endregion

				#region Initialize
				protected virtual bool ValidType(Type type)
				{
					return true;
				}

				protected virtual bool IsType(MethodInfo mInfo, Type baseType)
				{
					if (baseType == null)
						return true;

					Type typeCompare = mInfo.DeclaringType;
					while (typeCompare != null)
					{
						if (typeCompare == baseType)
							return true;

						typeCompare = typeCompare.BaseType;
					}

					return false;
				}

				private bool ValidMethod(Type type, Type baseType, MethodInfo m, string start)
				{
					if (
						m.IsPublic &&
						m.IsSpecialName &&
						m.Name.StartsWith(start) &&
						IsType(m, baseType))
					{
						var property = type.GetProperty(m.Name.Substring(start.Length));
						var attributes = property.GetCustomAttributes(typeof(XmlIgnoreAttribute), false);
						return (attributes.Length == 0);
					}

					return false;
				}

				private List<MethodInfo> FillGetter(Type type, Type baseType)
				{
					MethodInfo[] mInfo = type.GetMethods();
					List<MethodInfo> listMethods = new List<MethodInfo>(mInfo.Length);
					for (int i = 0; i < mInfo.Length; i++)
					{
						if (ValidMethod(type, baseType, mInfo[i], "get_") &&
							ValidType(mInfo[i].ReturnType))
						{
							listMethods.Add(mInfo[i]);
						}
					}
					listMethods.TrimExcess();
					return listMethods;
				}

				private List<MethodInfoType> FillSetter(Type type, Type baseType)
				{
					MethodInfo[] mInfo = type.GetMethods();
					List<MethodInfoType> listMethods = new List<MethodInfoType>(mInfo.Length);
					for (int i = 0; i < mInfo.Length; i++)
					{
						if (ValidMethod(type, baseType, mInfo[i], "set_"))
						{
							ParameterInfo[] pi = mInfo[i].GetParameters();
							if (pi.Length > 0 && ValidType(pi[0].ParameterType))
								listMethods.Add(new MethodInfoType(mInfo[i], pi[0].ParameterType));
						}
					}
					listMethods.TrimExcess();
					return listMethods;
				}
				#endregion

				#region Properties Loader
				protected virtual object LoadValue(object value, MethodInfoType mit)
				{
					if (mit.Type.IsEnum)
						return Enum.Parse(mit.Type, (string)value);

					TypeCode typeCode = Type.GetTypeCode(mit.Type);
					switch (typeCode)
					{
						case TypeCode.Boolean:
							return Convert.ToBoolean(value);
						case TypeCode.Int32:
							return Convert.ToInt32(value);
						case TypeCode.Double:
							return Convert.ToDouble(value);
						case TypeCode.String:
							return value;
					}

					return null;
				}
				#endregion

				#region Properties storage
				protected virtual object SaveValue(object value, Type type)
				{
					if (ValidType(type))
					{
						return value;
					}
					return null;
				}
				#endregion

				#region static properties helper
				public static MethodInfo GetMethodInfo(Object obj, String methodName)
				{
					MethodInfo methodInfo = null;
					try
					{
						methodInfo = obj.GetType().GetMethod(methodName);
					}
					catch (Exception) { }

					return methodInfo;
				}

				public static object Clone(object toClone)
				{
					ConstructorInfo ci = toClone.GetType().GetConstructor(new Type[] { });
					object toLoad = ci.Invoke(new object[] { });
					Clone(toClone, toLoad);
					return toLoad;
				}

				public static void Clone(object src, object dest)
				{
					PropertiesInOut propertiesInOut = new PropertiesInOut(src);
					foreach (PropertiesInOut.MethodInfoType miType in propertiesInOut.Setter)
						miType.Clone(src, dest);
				}

				public static String GetStringProperty(Object obj, String methodName)
				{
					String value = null;
					try
					{
						MethodInfo methodInfo = obj.GetType().GetMethod(methodName);
						value = (String)methodInfo.Invoke(obj, new Object[0]);
					}
					catch (Exception) { }

					return value;
				}

				public static int GetInt32Property(Object obj, String methodName)
				{
					int value = 0;
					try
					{
						MethodInfo methodInfo = obj.GetType().GetMethod(methodName);
						value = (int)methodInfo.Invoke(obj, new Object[0]);
					}
					catch (Exception) { }

					return value;
				}

				public static object GetObjectProperty(Object obj, string methodName)
				{
					try
					{
						MethodInfo methodInfo = obj.GetType().GetMethod(methodName);
						return methodInfo.Invoke(obj, new Object[0]);
					}
					catch (Exception e)
					{
					}

					return null;
				}

				public static object GetObjectProperty(Object obj, String methodName, string param)
				{
					try
					{
						MethodInfo methodInfo = obj.GetType().GetMethod(methodName);
						return methodInfo.Invoke(obj, new Object[] { param });
					}
					catch (Exception e)
					{
						string msg = e.Message;
						string stack = e.StackTrace;
					}

					return null;
				}

				public static string Info(object obj, Type baseType)
				{
					StringBuilder sb = new StringBuilder();

					PropertiesInOut io = new PropertiesInOut(obj, baseType);
					foreach (MethodInfo mi in io.Getter)
					{
						try
						{
							object objGet = mi.Invoke(obj, new Object[0]);
							if (objGet != null)
							{
								sb.AppendFormat("{0}={1}", mi.Name, objGet.ToString());
								sb.AppendLine();
							}
						}
						catch (Exception e)
						{
						}
					}

					return sb.ToString();
				}
				#endregion

			}
			#endregion

			public static string SerializeFont(SimpleFont font)
			{
				return font.FamilySerialize + ":" + font.Size;
			}

			public static SimpleFont DeserializeFont(string value)
			{
				string[] parts = value.Split(':');
				if (parts.Length != 2)
					throw new ArgumentException("Not a valid font string", "font");

				return new SimpleFont(parts[0], float.Parse(parts[1]));
			}

			internal static object FromBinaryString(string s, Type t)
			{
				return DeserializeBase64(s, t);
			}

			internal static string ToBinaryString(object serializable)
			{
				return SerializeBase64(serializable);
			}

			public static string SerializeBase64(object o)
			{
				if (o == null)
					throw new ArgumentException("Could not serialize null object");

				try
				{
					// Serialize to a base 64 string
					byte[] bytes;
					long length = 0;
					using (MemoryStream ws = new MemoryStream())
					{
						XmlSerializer xs = new XmlSerializer(o.GetType());
						xs.Serialize(ws, o);
						length = ws.Length;
						bytes = ws.GetBuffer();
						return bytes.Length + ":" + Convert.ToBase64String(bytes, 0, bytes.Length, Base64FormattingOptions.None);
					}
				}
				catch (Exception e)
				{
					throw new ArgumentException(string.Format("Could not serialize {0}", o.GetType().Name), e);
				}
			}

			public static object DeserializeBase64(string s, Type t)
			{
				if (s == null)
					throw new ArgumentException("Could not deserialize null string");

				try
				{

					// We need to know the exact length of the string - Base64 can sometimes pad us by a byte or two
					int p = s.IndexOf(':');
					int length = (p == -1) ? s.Length : Convert.ToInt32(s.Substring(0, p));

					// Extract data from the base 64 string!
					byte[] memorydata = Convert.FromBase64String((p == -1) ? s : s.Substring(p + 1));
					MemoryStream rs = new MemoryStream(memorydata, 0, length);
					XmlSerializer xs = new XmlSerializer(t);
					object o = xs.Deserialize(rs);
					return o;
				}
				catch (Exception e)
				{
					throw new ArgumentException(string.Format("Could not deserialize {0}", s), e);
				}
			}
		}

		#endregion

		#region InheritedClasses
		internal class StrategySaveFilter : StrategyLoadFilter
		{
			public StrategySaveFilter() : base()
			{
				base.readOnly = false;
			}
		}

		internal class StrategyLoadFilter : FileListConverterFilter
		{
			public static bool useInstrument = false;
			public static bool UseInstrument
			{
				set { useInstrument = value; }
				get { return useInstrument; }
			}

			public static StrategyBase sb = null;
			public static StrategyBase Strategy
			{
				set { sb = value; }
			}

			public static string DirectoryName
			{
				get { return String.Format(@"{0}TemplateManager\Strategy", NinjaTrader.Core.Globals.UserDataDir); }
			}

			public static string Suffix
			{
				get { return @".xml"; }
			}

			private static string Prefix(bool flagUseInstrument)
			{
				if (sb == null)
					return "";

				if (flagUseInstrument)
					return string.Format("{0}_{1}_", sb.GetType().Name, sb.Instrument.MasterInstrument.Name);

				return string.Format("{0}_", sb.GetType().Name);
			}

			public static string LoadFileName(string name)
			{
				return LoadFileName(name, useInstrument);
			}

			public static string FileNameOnly(string name)
			{
				return String.Format(@"{0}\{1}{2}", DirectoryName, name, Suffix);
			}

			public static string LoadFileName(string name, bool flagUseInstrument)
			{
				if (flagUseInstrument)
				{
					if (sb != null && name.StartsWith(string.Format("{0}_", sb.Instrument.MasterInstrument.Name)))
					{
						flagUseInstrument = false;
					}
				}
				return String.Format(@"{0}\{1}{2}{3}", DirectoryName, Prefix(flagUseInstrument), name, Suffix);
			}

			public StrategyLoadFilter() : base()
			{
				directoryName = StrategyLoadFilter.DirectoryName;
				endsWidth = StrategyLoadFilter.Suffix;
				startsWith = StrategyLoadFilter.Prefix(useInstrument);
			}
		}
		#endregion

		private void SaveAs(string fname)
		{
			string fileName = StrategySaveFilter.LoadFileName(
				string.Format("{0}_{1}", Instrument.MasterInstrument.Name, fname),
				false);
			bool success = XmlSerializeProperties.Save(fileName, this);
		}

		protected void TemplateManagerOnStartUp()
		{
			if (Account.Name.StartsWith("Back"))
				SaveAs(string.Format("Back_{0}", DateTime.Now.ToString("yyyyMMdd_HHmmss")));
			else
				SaveAs("Last");
		}
/*
		[XmlIgnore()]
		[TypeConverter(typeof(StrategySaveFilter))]
		[Description("Save strategy parameter")]
		[NinjaScriptProperty]
		[Display(Name = "Save", Description = "Save strategy parameter", Order = 2, GroupName = "eTemplateManager")]
		public string SaveParams
		{
			get
			{
				StrategySaveFilter.Strategy = this;
				return "...";
			}
			set
			{
				if (value == "...")
					return;

				string fileName = StrategySaveFilter.LoadFileName(value);
				bool success = XmlSerializeProperties.Save(fileName, this);
			}
		}

		[XmlIgnore()]
		[TypeConverter(typeof(StrategyLoadFilter))]
		[Description("Load strategy parameter")]
		[NinjaScriptProperty]
		[Display(Name = "Load", Description = "Load strategy parameter", Order = 1, GroupName = "eTemplateManager")]
		public string LoadParams
		{
			get
			{
				StrategySaveFilter.Strategy = this;
				return "...";
			}
			set
			{
				if (value == "...")
					return;
				XmlSerializeProperties.Load(StrategySaveFilter.LoadFileName(value), this);
			}
		}


		[XmlIgnore()]
		[TypeConverter(typeof(StrategyLoadFilter))]
		[Description("Save strategy parameter")]
		[NinjaScriptProperty]
		[Display(Name = "Remove", Description = "Remove strategy parameter", Order = 3, GroupName = "eTemplateManager")]
		public string RemoveParams
		{
			get
			{
				StrategySaveFilter.Strategy = this;
				return "...";
			}
			set
			{
				if (value == "...")
					return;

				try
				{
					string fileName = StrategySaveFilter.LoadFileName(value);
					System.IO.FileInfo fi = new System.IO.FileInfo(fileName);
					fi.Delete();
				}
				catch (Exception)
				{

				}
			}
		}
#if InstrumentBased
        [XmlIgnore()]
        [Description("If true use instrument name for selecting strategy parameters")]
        [GridCategory("TemplateManager")]
        [Gui.Design.DisplayName("4. UseInstrumentName")]
        public bool FilterInstrumentName {
            get { 
                StrategySaveFilter.Strategy = this;
                return StrategyLoadFilter.UseInstrument; 
            }
            set { StrategyLoadFilter.UseInstrument = value; }
        }
#endif
*/
		#endregion

		#region RegInternalClasses

		internal class LoadSupportedBarsList : StringConverter
		{
			#region LoadSupportedBarsList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				Dictionary<string, BarsPeriodType> dictionaryPeriodTypes = new Dictionary<string, BarsPeriodType>(BarsType.GetSupported().Length);
				foreach (BarsPeriodType b in BarsType.GetSupported())
				{


					try
					{
						string displayName = BarsType.GetBarsPeriodTypeName(b);

						if (b != BarsPeriodType.Minute &&
							b != BarsPeriodType.Volume &&
							b != BarsPeriodType.Tick &&
							b != BarsPeriodType.Day &&
							b != BarsPeriodType.Week &&
							b != BarsPeriodType.Month &&
							b != BarsPeriodType.Year &&
							b != BarsPeriodType.Second &&
							b != BarsPeriodType.Range
							)
							continue;

						dictionaryPeriodTypes.Add(displayName, b);
					}
					catch (Exception)
					{

					}
				}

				string[] filteredlist = new string[dictionaryPeriodTypes.Count];
				int i = 0;
				foreach (string key in dictionaryPeriodTypes.Keys)
				{
					filteredlist[i] = key;
					i++;
				}
				return new StandardValuesCollection(filteredlist);
			}
			#endregion
		}

		internal class LoadSoundFileList : StringConverter
		{
			#region LoadSoundFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = NinjaTrader.Core.Globals.InstallDir + @"sounds";
				string search = "*.wav";
				System.IO.DirectoryInfo dirCustom = new System.IO.DirectoryInfo(folder);
				System.IO.FileInfo[] filCustom = dirCustom.GetFiles( search);

				string[] list = new string[filCustom.Length];
				int i = 0;
				foreach (System.IO.FileInfo fi in filCustom)
				{
					//					if(fi.Extension.ToLower().CompareTo(".exe")!=0 && fi.Extension.ToLower().CompareTo(".txt")!=0){
					list[i] = fi.Name;
					i++;
					//					}
				}
				string[] filteredlist = new string[i];
				for (i = 0; i < filteredlist.Length; i++) filteredlist[i] = list[i];
				return new StandardValuesCollection(filteredlist);
			}
			#endregion
		}


		#endregion

		#region -- Toolbar --
		private string toolbarname = "ARCDeltaAlgoToolBar", uID;
		private bool isToolBarButtonAdded = false;
		private Chart chartWindow;
		private Grid indytoolbar;

		private Menu MenuControlContainer;
		private MenuItem MenuControl, miDeltaOff, miDeltaBoth, miDeltaLong, miDeltaShort;
		#endregion

		private int cSameDirBars, pSameDirBars;
		private ARC_DACumulativeDelta indDelta;
		private ARC_DAVMAlgo indMomo;
		private int firstRealtimeBar = -1;
		private bool EnableStopAndReverse = false;
		private EMA ema;
		private SMA sma;
		private bool FullLogging = false;

		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "ARC_DeltaAlgo";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 3;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= false;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				EntryDirection					= eEntryDirection.LONG_AND_SHORT;
				MmQuantity1					= 1;
				MmQuantity2					= 0;
				MmQuantity3					= 0;
				EntryOrderType				= eEntryOrderType.LIMIT;
				EntryOffsetTicks			= 0;
				EnableStopAndReverse		= false;
				StopLossTicks				= 10;
				GoldenTargType				= eGoldenTargType.STATIC;
				ProfitTargetTicks1			= 8;
				ProfitTargetTicks2			= 0;
				ProfitTargetTicks3			= 0;
				TrailTriggerTicks			= 0;
				TrailLookbackBars			= 0;
				TrailTicks					= 0;
				BreakEvenTrigger1			= 0;
				BreakEvenPlus1				= 0;
				MinBarsBeforeRevReq			= 3;
				NumBarsRatioCompute			= 3;
				RevDeltaReqPct				= 50;
				UseVMBias					= false;
				UseVMConfluence				= false;
				BlockLevelEntry				= 0;
				VMBiasType					= ARC_Delta_BiasType.ZERO_LINE;
				VMHistogramBackground		= false;
				BandPeriod					= 10;
				Fast					= 12;
				Slow					= 26;
				StdDevNumber			= 1;
				VMSwingStrength			= 1;
				MultiplierMD			= 0;
				LongStripColor			= Brushes.Green;
				LongStripOpacity		= 50;
				ShortStripColor			= Brushes.Red;
				ShortStripOpacity		= 50;
				PositiveDeltaColor		= Brushes.Blue;
				NegativeDeltaColor		= Brushes.White;
				MAPeriod = 15;
				MATimeframe = 1;
				MAType = ARC_Delta_MA_Type.EMA;
				ShowMA = true;
				MAColor = Brushes.WhiteSmoke;
				MergePullbackDeltas = false;
				NetDeltaFontSize = 14;
				ChartPnLTextColor = Brushes.DimGray;
				ButtonText = "Delta Algo";

				#region Plot Colors 
				DotsUpRisingColor = Brushes.Green;
				DotsDownRisingColor = Brushes.Green;
				DotsDownFallingColor = Brushes.Red;
				DotsUpFallingColor = Brushes.Red;
				DotsRimColor = Brushes.Black;
				BBAverageColor = Brushes.Transparent;
				BBUpperColor = Brushes.Black;
				BBLowerColor = Brushes.Black;
				HistUpColor = Brushes.LimeGreen;
				HistDownColor = Brushes.Maroon;
				ZerolineColor = Brushes.Black;
				ConnectorColor = Brushes.White;
				DeepBullishBackgroundColor = Brushes.DarkGreen;
				BullishBackgroundColor = Brushes.Green;
				OppositeBackgroundColor = Brushes.Gray;
				BearishBackgroundColor = Brushes.Red;
				DeepBearishBackgroundColor = Brushes.DarkRed;
				ChannelColor = Brushes.DodgerBlue;
				ExcursionLevel1Color = Brushes.White;
				ExcursionLevel2Color = Brushes.Blue;
				ExcursionLevel3Color = Brushes.Red;
				#endregion
			}
			else if (State == State.Configure)
			{
				IsDebug = System.IO.File.Exists("c:\\222222222222.txt");
				#region DoLicense call
#if DoLicense
				if(Account.Name != "Backtest")
				{
					if(!LicenseChecked){
						ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
						LicenseChecked = true;
					}
					IsVisible = true;
				}
				else
					ValidLicense = true;
#endif
				#endregion

				AddPlot(MAColor, "HTF_MA");
				Plots[0].Width = 2;
				base.xOrderLimitValue = this.EntryOffsetTicks;
				base.xOrderType = eOrderType.MARKET;
				if (this.EntryOrderType == eEntryOrderType.LIMIT)
					base.xOrderType = eOrderType.LIMITFIXED;

				this.indDelta = ARC_DACumulativeDelta();

				this.indMomo = ARC_DAVMAlgo(ARC_DAVMAlgo_OptimizeSpeedSettings.Max, BandPeriod, Fast, Slow, StdDevNumber, VMSwingStrength, MultiplierMD, 0);
				this.indMomo.BackgroundFlooding = VMHistogramBackground ? ARC_DAVMAlgo_Flooding.Histogram : ARC_DAVMAlgo_Flooding.None;
				this.indMomo.DisplayInDataBox = true;
				this.indMomo.DisplayLevel1    = true;
				this.indMomo.DotsUpRisingColor    = DotsUpRisingColor;
				this.indMomo.DotsDownRisingColor  = DotsDownRisingColor;
				this.indMomo.DotsDownFallingColor = DotsDownFallingColor;
				this.indMomo.DotsUpFallingColor   = DotsUpFallingColor;
				this.indMomo.DotsRimColor   = DotsRimColor;
				this.indMomo.BBAverageColor = BBAverageColor;
				this.indMomo.BBUpperColor   = BBUpperColor;
				this.indMomo.BBLowerColor   = BBLowerColor;
				this.indMomo.HistDownColor  = HistDownColor;
				this.indMomo.HistUpColor    = HistUpColor;
				this.indMomo.ZerolineColor  = ZerolineColor;
				this.indMomo.ConnectorColor = ConnectorColor;
				this.indMomo.DeepBearishBackgroundColor = DeepBearishBackgroundColor;
				this.indMomo.DeepBullishBackgroundColor = DeepBullishBackgroundColor;
				this.indMomo.OppositeBackgroundColor = OppositeBackgroundColor;
				this.indMomo.BullishBackgroundColor  = BullishBackgroundColor;
				this.indMomo.BearishBackgroundColor  = BearishBackgroundColor;
				this.indMomo.ChannelColor = ChannelColor;
				this.indMomo.Level1Color  = ExcursionLevel1Color;
				this.indMomo.Level2Color  = ExcursionLevel2Color;
				this.indMomo.Level3Color  = ExcursionLevel3Color;
				AddChartIndicator(this.indMomo);

				//this.indPnlChart.font1 = new SimpleFont("Arial", this.ChartPnlFontSize);
				this.indPnlChart.blackbrush = this.ChartPnLTextColor;

				//if(UseHTFMovingAverage)
				{
					AddDataSeries(BarsPeriodType.Minute, MATimeframe);
                }
			}
			else if(State == State.DataLoaded)
            {
				uID = KeepOnlyTheseCharacters(Instrument.FullName + DateTime.Now.Ticks.ToString(), "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");//prevent multiple toolbar with same name
				#region -- Add Custom Toolbar --
				if (!isToolBarButtonAdded && ChartControl != null)
                {

					Dispatcher.BeginInvoke(new Action(() =>
					{
						ChartControl.AllowDrop = false;
						chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
						if (chartWindow == null) return;

						foreach (DependencyObject item in chartWindow.MainMenu) if (AutomationProperties.GetAutomationId(item) == (toolbarname + uID)) isToolBarButtonAdded = true;

						if (!isToolBarButtonAdded)
						{
							indytoolbar = new System.Windows.Controls.Grid { Visibility = Visibility.Collapsed };

							addToolBar();

							chartWindow.MainMenu.Add(indytoolbar);
							chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

							foreach (System.Windows.Controls.TabItem tab in chartWindow.MainTabControl.Items) if ((tab.Content as ChartTab).ChartControl == ChartControl && tab == chartWindow.MainTabControl.SelectedItem) indytoolbar.Visibility = Visibility.Visible;
							AutomationProperties.SetAutomationId(indytoolbar, toolbarname + uID);
						}
					}));
                }
				#endregion

				ema = EMA(Closes[2], MAPeriod);
				sma = SMA(Closes[2], MAPeriod);
//Print("Closes.Length: "+Closes.Length);
//for(int i = 0; i<BarsArray.Length; i++) Print("    BarsArray["+i+"]  "+BarsArray[i].BarsPeriod.BarsPeriodType.ToString()+"   count: "+BarsArray[i].Count);
				base.xCancelNumBars = 1;
				// Setup order Structure
				base.xQuantity1 = this.MmQuantity1;
				base.xQuantity2 = this.MmQuantity2;
				base.xQuantity3 = this.MmQuantity3;

				base.LogikSetBreakEvenParams(1, this.BreakEvenTrigger1, this.BreakEvenPlus1);
				base.LogikSetBreakEvenParams(2, this.BreakEvenTrigger1, this.BreakEvenPlus1);
				base.LogikSetBreakEvenParams(3, this.BreakEvenTrigger1, this.BreakEvenPlus1);

				if (this.TrailLookbackBars == 0)
				{
					base.LogikSetTrailParams(1, this.TrailTicks, TickSize, this.TrailTriggerTicks);
					base.LogikSetTrailParams(2, this.TrailTicks, TickSize, this.TrailTriggerTicks);
					base.LogikSetTrailParams(3, this.TrailTicks, TickSize, this.TrailTriggerTicks);
				}

				// *************************************
				// Setup trade Strategy Parameters
				// *************************************			
				if (GoldenTargType == eGoldenTargType.STATIC)
				{
					base.LogikSetTargetType(eStopTargMode.TICKS);
					base.LogikSetTargetValue(1, this.ProfitTargetTicks1);
					base.LogikSetTargetValue(2, this.ProfitTargetTicks2);
					base.LogikSetTargetValue(3, this.ProfitTargetTicks3);
				}
				else
				{
					base.LogikSetTargetType(eStopTargMode.PRICE);
					base.LogikSetTargetValue(1, 0);
					base.LogikSetTargetValue(2, 0);
					base.LogikSetTargetValue(3, 0);
				}

				//Print("UserId: "+UserId);
				if(UserId == "179704" || UserId == "42117"){
					FullLogging = true;
					var start = StartTime.ToString("000");
					var InstName = Instrument.MasterInstrument.Name.Trim();
					var file = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),string.Format("DeltaAlgo_{0}_{1}_preventlongs.txt",InstName,start));
					Print(file);
					file = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),string.Format("DeltaAlgo_{0}_{1}_preventshorts.txt",InstName,start));
					Print(file);
					file = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),string.Format("DeltaAlgo_{0}_{1}_enablelongs.txt",InstName,start));
					Print(file);
					file = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),string.Format("DeltaAlgo_{0}_{1}_enableshorts.txt",InstName,start));
					Print(file);
				}
				base.LogikSetStopLossType(eStopTargMode.TICKS);
				base.LogikSetStopLossValue(this.StopLossTicks);
			}

			#region State == State.Terminated
			else if (State == State.Terminated)
			{
				if (chartWindow != null && indytoolbar != null)
				{
					Dispatcher.BeginInvoke(new Action(() =>
					{
						chartWindow.MainMenu.Remove(indytoolbar);
						indytoolbar = null;

						chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
						chartWindow = null;
					}));
				}

			}
			#endregion
		}

		#region -- Toolbar Management Utilities --

		//==============================================================================================
		private static string KeepOnlyTheseCharacters(string instr, string CharactersToKeep)
		{
			string ret = string.Empty;
			char[] str = instr.ToCharArray(0, instr.Length);
			for (int i = 0; i < str.Length; i++) if (CharactersToKeep.Contains(str[i].ToString())) ret = string.Concat(ret, str[i].ToString());
			return ret;
		}

		private void addToolBar()
        {
			MenuControlContainer = new Menu { Background = Brushes.Orange, VerticalAlignment = VerticalAlignment.Center };
			MenuControl = new MenuItem { BorderThickness = new Thickness(2), BorderBrush = Brushes.Gold, Header = ButtonText, Foreground = Brushes.Gold, Background = Brushes.MidnightBlue, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			MenuControlContainer.Items.Add(MenuControl);

			miDeltaOff = new MenuItem { Header = "OFF", Name = "DeltaOff", Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.EntryDirection == eEntryDirection.OFF };
			miDeltaBoth = new MenuItem { Header = "LONG AND SHORT", Name = "DeltaBoth", Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.EntryDirection == eEntryDirection.LONG_AND_SHORT };
			miDeltaLong = new MenuItem { Header = "LONG ONLY", Name = "DeltaLong", Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.EntryDirection == eEntryDirection.LONG_ONLY };
			miDeltaShort = new MenuItem { Header = "SHORT ONLY", Name = "DeltaShort", Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = this.EntryDirection == eEntryDirection.SHORT_ONLY };

			miDeltaOff.Click += delegate (object o, RoutedEventArgs e)
			{
				Dispatcher.BeginInvoke(new Action(() =>
				{
					this.EntryDirection = eEntryDirection.OFF;
					miDeltaOff.IsChecked = true;
					miDeltaBoth.IsChecked = false;
					miDeltaLong.IsChecked = false;
					miDeltaShort.IsChecked = false;
				}));
				if (Position.MarketPosition == MarketPosition.Short)
				{
					base.LogikExitPosition("OFF");
				}
				else if (Position.MarketPosition == MarketPosition.Long)
				{
					base.LogikExitPosition("OFF");
				}

			};

			miDeltaBoth.Click += delegate (object o, RoutedEventArgs e)
			{
				Dispatcher.BeginInvoke(new Action(() =>
				{
					this.EntryDirection = eEntryDirection.LONG_AND_SHORT;
					miDeltaOff.IsChecked = false;
					miDeltaBoth.IsChecked = true;
					miDeltaLong.IsChecked = false;
					miDeltaShort.IsChecked = false;
				}));
			};

			miDeltaLong.Click += delegate (object o, RoutedEventArgs e)
			{
				Dispatcher.BeginInvoke(new Action(() =>
				{
					this.EntryDirection = eEntryDirection.LONG_ONLY;
					miDeltaOff.IsChecked = false;
					miDeltaBoth.IsChecked = false;
					miDeltaLong.IsChecked = true;
					miDeltaShort.IsChecked = false;
				}));
			};

			miDeltaShort.Click += delegate (object o, RoutedEventArgs e)
			{
				Dispatcher.BeginInvoke(new Action(() =>
				{
					this.EntryDirection = eEntryDirection.SHORT_ONLY;
					miDeltaOff.IsChecked = false;
					miDeltaBoth.IsChecked = false;
					miDeltaLong.IsChecked = false;
					miDeltaShort.IsChecked = true;
				}));
			};

			MenuControl.Items.Add(miDeltaOff);
			MenuControl.Items.Add(miDeltaBoth);
			MenuControl.Items.Add(miDeltaLong);
			MenuControl.Items.Add(miDeltaShort);

			indytoolbar.Children.Add(MenuControlContainer);
		}

		#region private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		private void TabSelectionChangedHandler(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0) return;
			TabItem tabItem = e.AddedItems[0] as System.Windows.Controls.TabItem;
			if (tabItem == null) return;
			ChartTab temp = tabItem.Content as ChartTab;
			if (temp != null && indytoolbar != null)
				indytoolbar.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
		}
		#endregion

		#endregion

		#region OnExecution
		protected override void OnExecutionUpdate(Cbi.Execution execution, string executionId, double price, int quantity, 
			Cbi.MarketPosition marketPosition, string orderId, DateTime time)
		{
			if (
				execution.Order.Name.Length == 2
				&& (execution.Order.Name.Contains("L") || execution.Order.Name.Contains("S"))
				)
			{
				if (Position.MarketPosition == MarketPosition.Long)
				{
					double stopTicks = this.StopLossTicks;

					if (this.GoldenTargType == eGoldenTargType.RR)
					{
						double p = Position.AveragePrice;
						base.LogikSetTargetValue(1, p + (stopTicks * this.ProfitTargetTicks1 * TickSize));
						base.LogikSetTargetValue(2, p + (stopTicks * this.ProfitTargetTicks2 * TickSize));
						base.LogikSetTargetValue(3, p + (stopTicks * this.ProfitTargetTicks3 * TickSize));
					}

				}

				if (Position.MarketPosition == MarketPosition.Short)
				{
					double stopTicks = this.StopLossTicks;

					if (this.GoldenTargType == eGoldenTargType.RR)
					{
						double p = Position.AveragePrice;
						base.LogikSetTargetValue(1, p - (stopTicks * this.ProfitTargetTicks1 * TickSize));
						base.LogikSetTargetValue(2, p - (stopTicks * this.ProfitTargetTicks2 * TickSize));
						base.LogikSetTargetValue(3, p - (stopTicks * this.ProfitTargetTicks3 * TickSize));
					}
				}
			}

			base.OnExecutionUpdate(execution, executionId, price, quantity, marketPosition, orderId, time);

		}
		#endregion

		protected override void OnMarketData(MarketDataEventArgs marketDataUpdate)
		{
			base.OnMarketData(marketDataUpdate);
		}
		/*
				protected override void OnOrderUpdate(Cbi.Order order, double limitPrice, double stopPrice, 
					int quantity, int filled, double averageFillPrice, 
					Cbi.OrderState orderState, DateTime time, Cbi.ErrorCode error, string comment)
				{

				}

				protected override void OnPositionUpdate(Cbi.Position position, double averagePrice, 
					int quantity, Cbi.MarketPosition marketPosition)
				{

				}*/
		private void FindControlTextFile(){
			//this was added by request for John Pretorius.  He wanted a backdoor method of controlling strategy direction ("EntryDirection") through control text files.
			//When these text files are present, they will restrict the trading longs or shorts
			var start = StartTime.ToString("000");
			var InstName = Instrument.MasterInstrument.Name.Trim();
			var file = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),string.Format("DeltaAlgo_{0}_{1}_preventlongs.txt",InstName,start));
if(FullLogging) Print("Checking file: "+file);
			if(System.IO.File.Exists(file)) {
//if(IsDebug) Print("Found: "+file);
				if(EntryDirection ==eEntryDirection.LONG_ONLY){
					EntryDirection = eEntryDirection.OFF; 
				} else if(EntryDirection==eEntryDirection.LONG_AND_SHORT){
					EntryDirection = eEntryDirection.SHORT_ONLY; 
				}
if(FullLogging) Print("Preventing shorts:   "+EntryDirection.ToString());
			}
			file = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),string.Format("DeltaAlgo_{0}_{1}_preventshorts.txt",InstName,start));
			if(System.IO.File.Exists(file)) {
//if(IsDebug) Print("Found: "+file);
				if(EntryDirection==eEntryDirection.SHORT_ONLY){
					EntryDirection = eEntryDirection.OFF; 
				}else if(EntryDirection==eEntryDirection.LONG_AND_SHORT){
					EntryDirection = eEntryDirection.LONG_ONLY;
				}
if(FullLogging) Print("Preventing shorts:   "+EntryDirection.ToString());
			}
			file = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),string.Format("DeltaAlgo_{0}_{1}_enablelongs.txt",InstName,start));
			if(System.IO.File.Exists(file)) {
//if(IsDebug) Print("Found: "+file);
				if(EntryDirection==eEntryDirection.SHORT_ONLY){
					EntryDirection = eEntryDirection.LONG_AND_SHORT;
				}else if(EntryDirection==eEntryDirection.OFF){
					EntryDirection = eEntryDirection.LONG_ONLY;
				}
if(FullLogging) Print("Enabling longs:   "+EntryDirection.ToString());
			}
			file = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),string.Format("DeltaAlgo_{0}_{1}_enableshorts.txt",InstName,start));
			if(System.IO.File.Exists(file)) {
//if(IsDebug) Print("Found: "+file);
				if(EntryDirection==eEntryDirection.LONG_ONLY){
					EntryDirection = eEntryDirection.LONG_AND_SHORT;
				}else if(EntryDirection==eEntryDirection.OFF){
					EntryDirection = eEntryDirection.SHORT_ONLY;
				}
if(FullLogging) Print("Enabling shorts:   "+EntryDirection.ToString());
			}
			Dispatcher.BeginInvoke(new Action(() =>
			{
				miDeltaOff.IsChecked   = EntryDirection == eEntryDirection.OFF;
				miDeltaBoth.IsChecked  = EntryDirection == eEntryDirection.LONG_AND_SHORT;
				miDeltaLong.IsChecked  = EntryDirection == eEntryDirection.LONG_ONLY;
				miDeltaShort.IsChecked = EntryDirection == eEntryDirection.SHORT_ONLY;
			}));
		}

		private int OrderBar = 0;

		protected override void OnBarUpdate()
		{
#if DoLicense
			if(!ValidLicense) {
				this.IsVisible = false;
				if(this.NewCustId<=0)
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext","Your ARCAI Contact Id is not present\n"+MachineId+"\n\nPlease run the latest ARC_LicenseActivator indicator\n\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				else
					NinjaTrader.NinjaScript.DrawingTools.Draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact support@architectsai.com for assistance",NinjaTrader.NinjaScript.DrawingTools.TextPosition.Center,Brushes.White,new NinjaTrader.Gui.Tools.SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif
			if(CurrentBars[0] < BarsRequiredToTrade)
            {
				return;
            }

			#region RegRunType					

			base.OnBarUpdate();

			//Print("Bars In Progress: " + BarsInProgress + ", Delta: " + this.indDelta.CumulativeVolume[0]);

			if (!base.bSystemReadyToProcess)
				return;

			if (BarsInProgress == 0)
			{

			}
			#endregion

			if (
				(base.XRunType == eRunType.BackTest && !Historical) || (base.XRunType == eRunType.RealTime && Historical)
				)
				return;

			if (BarsInProgress != 0)
				return;

			#region RegTrail

			if (
				this.TrailLookbackBars != 0
				&& base.LogikGetMaxPriceMovementAvgEntryTicks() >= this.TrailTriggerTicks
				)
			{
				if (Position.MarketPosition == MarketPosition.Long)
				{
					double p = MIN(Low, this.TrailLookbackBars)[0];
					for (int i = 1; i <= 3; i++)
						base.LogikUpdateSingleStopValue(i, p - this.TrailTicks * TickSize, false);
				}

				if (Position.MarketPosition == MarketPosition.Short)
				{
					double p = MAX(High, this.TrailLookbackBars)[0];
					for (int i = 1; i <= 3; i++)
						base.LogikUpdateSingleStopValue(i, p + this.TrailTicks * TickSize, false);
				}
			}
			#endregion

			#region RegDisplayPp

			//Print(this.indDelta.CumulativeVolume[0]);
			if (this.indDelta.CumulativeVolume[0] > 0)
				Draw.Text(this, CurrentBar.ToString() + "disp", true, this.indDelta.CumulativeVolume[0].ToString(), 0, High[0] + TickSize * 3, 0, PositiveDeltaColor, new SimpleFont("Arial", NetDeltaFontSize), TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);
			else if (this.indDelta.CumulativeVolume[0] < 0)
				Draw.Text(this, CurrentBar.ToString() + "disp", true, this.indDelta.CumulativeVolume[0].ToString(), 0, Low[0] - TickSize * 3, 0, NegativeDeltaColor, new SimpleFont("Arial", NetDeltaFontSize), TextAlignment.Center, Brushes.Transparent, Brushes.Transparent, 0);


			#endregion

			if(firstRealtimeBar == -1)
            {
				firstRealtimeBar = CurrentBar;
            }

			if(CurrentBar < firstRealtimeBar + this.MinBarsBeforeRevReq)
            {
				return;
            }
			if(base.ExecutionsToUpdate.Count>0){
				if(Position.MarketPosition == MarketPosition.Flat)
					base.ExecutionsToUpdate.Clear();
				else{
					if(IsDebug){
						ClearOutputWindow();
						Print("Unfinished executions: "+base.ExecutionsToUpdate.Count);
					}
					var keys = base.ExecutionsToUpdate.Keys.ToList();
					foreach(var k in keys){
						base.OnExecutionUpdate(
							base.ExecutionsToUpdate[k].execution,
							k,
							base.ExecutionsToUpdate[k].price, 
							base.ExecutionsToUpdate[k].quantity, 
							base.ExecutionsToUpdate[k].marketPosition, 
							base.ExecutionsToUpdate[k].orderId, 
							base.ExecutionsToUpdate[k].time); 
					}
				}
			}

			int barIdx = Calculate == Calculate.OnBarClose ? 0 : 1;
			bool allowPlaceOrder = (Calculate == Calculate.OnBarClose || IsFirstTickOfBar) && OrderBar < CurrentBars[0];
			if(allowPlaceOrder)
            {
				if (base.LogikGetBarDirection(barIdx) != base.LogikGetBarDirection(barIdx + 1))
				{
					this.pSameDirBars = this.cSameDirBars;
					this.cSameDirBars = 0;
				}

				this.cSameDirBars++;
			}

			if (
				base.LogikGetCanTrade()
				&& base.LogikGetActiveTradeTime(0)
				&& allowPlaceOrder
				)
			{

				//*******************************************************
				// Long Setup
				if (
					base.LogikGetBarDirection(barIdx) == 1
					&& base.LogikGetBarDirection(barIdx) != base.LogikGetBarDirection(barIdx + 1)
					// Prior Same # Bars
					&& this.pSameDirBars >= this.MinBarsBeforeRevReq
					// Momo Color
					&& ((this.indMomo.Histogram[barIdx] > 0 && VMBiasType == ARC_Delta_BiasType.ZERO_LINE) || (this.indMomo.StructureBiasState[barIdx] > 0 && VMBiasType == ARC_Delta_BiasType.STRUCTURAL) || !this.UseVMBias)
					// Momo Confluence
					&& (this.indMomo.BBMACD[barIdx] > 0 || !this.UseVMConfluence)
					// Excursion Blocking
					&&
					(
						this.BlockLevelEntry == 0
						|| (this.BlockLevelEntry == 1 && this.indMomo.Histogram[0] < this.indMomo.PriceExcursionUL1[0])
						|| (this.BlockLevelEntry == 2 && this.indMomo.Histogram[0] < this.indMomo.PriceExcursionUL2[0])
						|| (this.BlockLevelEntry == 3 && this.indMomo.Histogram[0] < this.indMomo.PriceExcursionUL3[0])
					)
					)
				{

					#region RegComputeNet

					bool netMergeBarsCondition = true;
					double netDelta = 0;
					int barsToCompute = this.NumBarsRatioCompute;
					int invertBars = 0;
					for (int i = barIdx + 1; i <= barsToCompute + barIdx; i++)
                    {
						if(!MergePullbackDeltas)
                        {
							if (this.indDelta.CumulativeVolume[i] > 0)
							{
								invertBars++;
								if (this.pSameDirBars >= this.MinBarsBeforeRevReq + invertBars)
								{
									barsToCompute++;
									continue;
								}
								else
								{
									netMergeBarsCondition = false;
									break;
								}
							}
						}
                        netDelta += this.indDelta.CumulativeVolume[i];
                    }

                    int deltaReq = (int)Math.Abs(netDelta * (this.RevDeltaReqPct / 100));
					//Draw.Text(this, CurrentBar.ToString(), deltaReq.ToString(), barIdx, Low[barIdx] - TickSize * 6, Brushes.Cyan);

					#endregion

					#region HFT Moving Average Filter
					bool maFilter = true;

					if(UseHTFMovingAverage && Close[barIdx] < GetMovingAverageValue(barIdx))
                    {
						maFilter = false;
                    }
                    #endregion

					if(ChartControl!=null && State==State.Realtime) FindControlTextFile();
					bool c1 = netMergeBarsCondition && maFilter;
					bool c2 = this.indDelta.CumulativeVolume[barIdx] >= deltaReq;
                    if (
						(EntryDirection == eEntryDirection.LONG_AND_SHORT || EntryDirection == eEntryDirection.LONG_ONLY)
						&& c1
						&& c2)
					{
						if(ChartControl!=null && LongStripOpacity>0) BackBrushes[0] = this.LongStripColor;

						if (Position.MarketPosition == MarketPosition.Flat || (Position.MarketPosition != MarketPosition.Long && this.EnableStopAndReverse))
						{
							OrderBar = CurrentBars[0];
							if (Position.MarketPosition == MarketPosition.Short)
							{
								base.LogikExitPosition("revLong");
							}

							base.LogikSubmitOrder(1, "L1", Close[barIdx], this.MmQuantity1);
							base.LogikSubmitOrder(2, "L2", Close[barIdx], this.MmQuantity2);
							base.LogikSubmitOrder(3, "L3", Close[barIdx], this.MmQuantity3);
						}
					}else if(c1 && c2 && FullLogging){Print(Times[0][0].ToString()+"   Long trade was skipped");
					}
				}

				//Short setup
				if (
					base.LogikGetBarDirection(barIdx) == -1
					&& base.LogikGetBarDirection(barIdx) != base.LogikGetBarDirection(barIdx + 1)
					// Prior Same # Bars
					&& this.pSameDirBars >= this.MinBarsBeforeRevReq
					// Momo Color
					&& ((this.indMomo.Histogram[barIdx] < 0 && VMBiasType == ARC_Delta_BiasType.ZERO_LINE) || (this.indMomo.StructureBiasState[barIdx] < 0 && VMBiasType == ARC_Delta_BiasType.STRUCTURAL) || !this.UseVMBias)
					// Momo Confluence
					&& (this.indMomo.BBMACD[barIdx] < 0 || !this.UseVMConfluence)
					// Excursion Blocking
					&&
					(
						this.BlockLevelEntry == 0
						|| (this.BlockLevelEntry == 1 && this.indMomo.Histogram[0] > this.indMomo.PriceExcursionLL1[0])
						|| (this.BlockLevelEntry == 2 && this.indMomo.Histogram[0] > this.indMomo.PriceExcursionLL2[0])
						|| (this.BlockLevelEntry == 3 && this.indMomo.Histogram[0] > this.indMomo.PriceExcursionLL3[0])
					)
					)
				{
					#region RegComputenet

					bool netMergeBarsCondition = true;
					double netDelta = 0;
					int barsToCompute = this.NumBarsRatioCompute;
					int invertBars = 0;
					for (int i = 1 + barIdx; i <= barsToCompute + barIdx; i++)
					{
						if (!MergePullbackDeltas)
						{
							if (this.indDelta.CumulativeVolume[i] < 0)
							{
								invertBars++;
								if (this.pSameDirBars >= this.MinBarsBeforeRevReq + invertBars)
								{
									barsToCompute++;
									continue;
								}
								else
								{
									netMergeBarsCondition = false;
									break;
								}
							}
						}
						netDelta += this.indDelta.CumulativeVolume[i];
					}

					int deltaReq = (int)Math.Abs(netDelta * (this.RevDeltaReqPct / 100)) * -1;
					//Draw.Text(this, CurrentBar.ToString(), deltaReq.ToString(), barIdx, High[barIdx] + TickSize * 6, Brushes.Tomato);

					#endregion

					#region HFT Moving Average Filter
					bool maFilter = true;

					if (UseHTFMovingAverage && Close[barIdx] > GetMovingAverageValue(barIdx))
					{
						maFilter = false;
					}
					#endregion

					if(ChartControl!=null && State==State.Realtime) FindControlTextFile();
					bool c1 = netMergeBarsCondition && maFilter;
					bool c2 = this.indDelta.CumulativeVolume[barIdx] <= deltaReq;
					if (
						(EntryDirection == eEntryDirection.LONG_AND_SHORT || EntryDirection == eEntryDirection.SHORT_ONLY)
						&& c1
						&& c2)
					{
						if(ChartControl!=null && ShortStripOpacity>0) BackBrushes[0] = this.ShortStripColor;

						if (Position.MarketPosition == MarketPosition.Flat || (Position.MarketPosition != MarketPosition.Short && this.EnableStopAndReverse))
						{
							OrderBar = CurrentBars[0];
							if (Position.MarketPosition == MarketPosition.Long)
							{
								base.LogikExitPosition("revShort");
							}

							base.LogikSubmitOrder(1, "S1", Close[barIdx], this.MmQuantity1);
							base.LogikSubmitOrder(2, "S2", Close[barIdx], this.MmQuantity2);
							base.LogikSubmitOrder(3, "S3", Close[barIdx], this.MmQuantity3);
						}
					}else if(c1 && c2 && FullLogging){Print(Times[0][0].ToString()+"   Short trade was skipped");}
				}
			}

			if(BarsInProgress == 0 && UseHTFMovingAverage)
            {
				HTF_MA[barIdx] = GetMovingAverageValue(barIdx);
            }
		}

		double GetMovingAverageValue(int idx)
        {
//			try{
			if(CurrentBars[2]<MAPeriod+1) return Closes[0][0];
			if(MAType == ARC_Delta_MA_Type.EMA)
            {
				return ema[idx];//EMA(Closes[2], MAPeriod)[idx];
            }
			else if(MAType == ARC_Delta_MA_Type.SMA)
            {
				return sma[idx];//SMA(Closes[2], MAPeriod)[idx];
            }
			else
            {
				return sma[idx];//SMA(Closes[2], MAPeriod)[idx];
			}
//			}catch(Exception ee){Print("2719:  "+ee.ToString()); return Closes[0][0];}
		}


//		private const string productVersion = "Version 2.0.13 (09/09)";
		private const string productVersion = "Version 2.0.16 (10/11)"; //fixed GetMovingAverageValue(), added if-then condition and created "ema" and "sma" variables
		#region RegVersionControl
		private const string productName = "ARC DeltaAlgo";

		public override string ToString()
		{
			return string.Format("{0} {1}", productName, productVersion);
		}

		public override string DisplayName { get { return ToString(); } }

		#endregion

		#region RegEnums

		public enum eGoldenTargType
		{
			STATIC,
			RR,
		}

		public enum eEntryOrderType
		{
			MARKET,
			LIMIT,
		}

		public enum eEntryDirection
		{
			LONG_AND_SHORT,
			LONG_ONLY,
			SHORT_ONLY,
			OFF
		}

		public enum ARC_Delta_MA_Type { EMA, SMA };

		public enum ARC_Delta_BiasType
        {
			STRUCTURAL,
			ZERO_LINE
        }

		#endregion

		#region Properties

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> HTF_MA
		{
			get { return Values[0]; }
		}

		#region Order Parameters
		[NinjaScriptProperty]
		[Display(Name="Entry Direction", Description="Entry Direction", Order=1, GroupName= "aOrderParameters")]
		public eEntryDirection EntryDirection
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name= "Quantity 1", Description="Quantity associated with Target 1", Order=2, GroupName= "aOrderParameters")]
		public int MmQuantity1
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name= "Quantity 2", Description="Quantity associated with Target 2", Order=3, GroupName= "aOrderParameters")]
		public int MmQuantity2
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name= "Quantity 3", Description="Quantity associated with Target 3", Order=4, GroupName= "aOrderParameters")]
		public int MmQuantity3
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Entry Order Type", Description="Entry Order Type", Order=5, GroupName= "aOrderParameters")]
		public eEntryOrderType EntryOrderType
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="Entry Offset Ticks", Description="Offset ticks for Limit Order", Order=6, GroupName= "aOrderParameters")]
		public int EntryOffsetTicks
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="StopLoss Ticks", Order=8, GroupName= "aOrderParameters")]
		public double StopLossTicks
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Target Type", Order=9, GroupName= "aOrderParameters")]
		public eGoldenTargType GoldenTargType
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="ProfitTarget 1", Description="Static St = # Ticks, RR = Multiplier factor", Order=10, GroupName= "aOrderParameters")]
		public double ProfitTargetTicks1
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="ProfitTarget 2", Description="Static St = # Ticks, RR = Multiplier factor", Order=11, GroupName= "aOrderParameters")]
		public double ProfitTargetTicks2
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="ProfitTarget 3", Description="Static St = # Ticks, RR = Multiplier factor", Order=12, GroupName= "aOrderParameters")]
		public double ProfitTargetTicks3
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name="Trail Trigger", Description="Number of ticks to in profit to enable the trail", Order=13, GroupName= "aOrderParameters")]
		public int TrailTriggerTicks
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name= "Trail # Bars Back", Description="Set this to 1 for tight mgmt, greater than 1 for loose mgmt (where the value you place is the number of bars lookback for the high / low price)", Order=14, GroupName= "aOrderParameters")]
		public int TrailLookbackBars
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name= "Trail Tick Offset", Description="Offset ticks for trail.", Order=15, GroupName= "aOrderParameters")]
		public double TrailTicks
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="BreakEven Trigger", Description="Number of ticks in profit to break event", Order=16, GroupName= "aOrderParameters")]
		public double BreakEvenTrigger1
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="BreakEven Plus", Order=17, GroupName= "aOrderParameters")]
		public double BreakEvenPlus1
		{ get; set; }

        #endregion

        #region Entry

        [NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name= "# Same Color Bars", Order=1, GroupName= "cEntryParameters")]
		public int MinBarsBeforeRevReq
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name= "# Bars Compute Ratio", Order=2, GroupName= "cEntryParameters")]
		public int NumBarsRatioCompute
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name= "Rev Ratio %", Order=3, GroupName= "cEntryParameters")]
		public double RevDeltaReqPct
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name= "Require VM Bias", Order=4, GroupName= "cEntryParameters")]
		public bool UseVMBias
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name= "Require VM Confluence", Order=5, GroupName= "cEntryParameters")]
		public bool UseVMConfluence
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name= "Enable Block Level", Description="0 to disable, this is the level at which to block if the histogram level is above / below", Order=6, GroupName= "cEntryParameters")]
		public int BlockLevelEntry
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Merge Pullback Deltas", Order = 7, GroupName = "cEntryParameters")]
		public bool MergePullbackDeltas
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Require HTF MA", Order = 8, GroupName = "cEntryParameters")]
		public bool UseHTFMovingAverage
		{ get; set; }

		#endregion

		#region VM Parameters

		[NinjaScriptProperty]
		[Display(Name = "VM Bias Type", Order = 1, GroupName = "dVMLeanParameters")]
		public ARC_Delta_BiasType VMBiasType
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="VM Histogram Background", Order=2, GroupName= "dVMLeanParameters")]
		public bool VMHistogramBackground
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name= "Period Bollinger Band", Description="Band Period for Bollinger Band", Order=4, GroupName= "dVMLeanParameters")]
		public int BandPeriod
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name= "Lookback fast EMA", Description="Period for fast EMA", Order=5, GroupName= "dVMLeanParameters")]
		public int Fast
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name= "Lookback slow EMA", Description="Period for slow EMA", Order=6, GroupName= "dVMLeanParameters")]
		public int Slow
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name= "Std. dev. multiplier", Description="Number of standard deviations", Order=7, GroupName= "dVMLeanParameters")]
		public double StdDevNumber
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name= "Swing strength", Description="Number of bars used to identify a swing high or low", Order=8, GroupName= "dVMLeanParameters")]
		public int VMSwingStrength
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name= "Deviation multiplier", Description="Multiplier used to calculate minimum deviation as an ATR multiple", Order=9, GroupName= "dVMLeanParameters")]
		public double MultiplierMD
		{ get; set; }

		#endregion

		#region VM Plot Colors
		[XmlIgnore]
		[Display(Name = "Rising dots above channel ", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 0)]
		public Brush DotsUpRisingColor { get; set; }
		[Browsable(false)]
		public string DotsUpRisingColorSerialize
		{
			get { return Serialize.BrushToString(DotsUpRisingColor); }
			set { DotsUpRisingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Rising dots inside/below channel ", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 1)]
		public Brush DotsDownRisingColor { get; set; }
		[Browsable(false)]
		public string DotsDownRisingColorSerialize
		{
			get { return Serialize.BrushToString(DotsDownRisingColor); }
			set { DotsDownRisingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Falling dots below channel ", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 2)]
		public Brush DotsDownFallingColor { get; set; }
		[Browsable(false)]
		public string DotsDownFallingColorSerialize
		{
			get { return Serialize.BrushToString(DotsDownFallingColor); }
			set { DotsDownFallingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Falling dots inside/above channel ", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 3)]
		public Brush DotsUpFallingColor { get; set; }
		[Browsable(false)]
		public string DotsUpFallingColorSerialize
		{
			get { return Serialize.BrushToString(DotsUpFallingColor); }
			set { DotsUpFallingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Dots rim", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 4)]
		public Brush DotsRimColor { get; set; }
		[Browsable(false)]
		public string DotsRimColorSerialize
		{
			get { return Serialize.BrushToString(DotsRimColor); }
			set { DotsRimColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bollinger average", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 5)]
		public Brush BBAverageColor { get; set; }
		[Browsable(false)]
		public string BBAverageColorSerialize
		{
			get { return Serialize.BrushToString(BBAverageColor); }
			set { BBAverageColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bollinger upper band", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 6)]
		public Brush BBUpperColor { get; set; }
		[Browsable(false)]
		public string BBUpperColorSerialize
		{
			get { return Serialize.BrushToString(BBUpperColor); }
			set { BBUpperColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bollinger lower band", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 7)]
		public Brush BBLowerColor { get; set; }
		[Browsable(false)]
		public string BBLowerColorSerialize
		{
			get { return Serialize.BrushToString(BBLowerColor); }
			set { BBLowerColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Momo Histogram Hi Color", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 8)]
		public Brush HistUpColor { get; set; }
		[Browsable(false)]
		public string HistUpColorSerialize
		{
			get { return Serialize.BrushToString(HistUpColor); }
			set { HistUpColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Momo Histogram Down Color", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 9)]
		public Brush HistDownColor { get; set; }
		[Browsable(false)]
		public string HistDownColorSerialize
		{
			get { return Serialize.BrushToString(HistDownColor); }
			set { HistDownColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Zeroline", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 10)]
		public Brush ZerolineColor { get; set; }
		[Browsable(false)]
		public string ZerolineColorSerialize
		{
			get { return Serialize.BrushToString(ZerolineColor); }
			set { ZerolineColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Connector", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 11)]
		public Brush ConnectorColor { get; set; }
		[Browsable(false)]
		public string ConnectorColorSerialize
		{
			get { return Serialize.BrushToString(ConnectorColor); }
			set { ConnectorColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Channel shading", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 12)]
		public Brush ChannelColor { get; set; }
		[Browsable(false)]
		public string ChannelColorSerialize
		{
			get { return Serialize.BrushToString(ChannelColor); }
			set { ChannelColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Deep Bearish background flooding", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 17)]
		public Brush DeepBearishBackgroundColor { get; set; }
		[Browsable(false)]
		public string DeepBearishBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(DeepBearishBackgroundColor); }
			set { DeepBearishBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bearish background flooding", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 16)]
		public Brush BearishBackgroundColor { get; set; }
		[Browsable(false)]
		public string BearishBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(BearishBackgroundColor); }
			set { BearishBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Opposite background flooding", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 15)]
		public Brush OppositeBackgroundColor { get; set; }
		[Browsable(false)]
		public string OppositeBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(OppositeBackgroundColor); }
			set { OppositeBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bullish background flooding", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 14)]
		public Brush BullishBackgroundColor { get; set; }
		[Browsable(false)]
		public string BullishBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(BullishBackgroundColor); }
			set { BullishBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Deep Bullish background flooding", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 13)]
		public Brush DeepBullishBackgroundColor { get; set; }
		[Browsable(false)]
		public string DeepBullishBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(DeepBullishBackgroundColor); }
			set { DeepBullishBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Excursion Level 1 Color", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 21)]
		public Brush ExcursionLevel1Color { get; set; }
		[Browsable(false)]
		public string ExcursionLevel1ColorSerialize
		{
			get { return Serialize.BrushToString(ExcursionLevel1Color); }
			set { ExcursionLevel1Color = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Excursion Level 2 Color", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 22)]
		public Brush ExcursionLevel2Color { get; set; }
		[Browsable(false)]
		public string ExcursionLevel2ColorSerialize
		{
			get { return Serialize.BrushToString(ExcursionLevel2Color); }
			set { ExcursionLevel2Color = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Excursion Level 3 Color", GroupName = "dVMLeanPlots", Description = "Select Color", Order = 23)]
		public Brush ExcursionLevel3Color { get; set; }
		[Browsable(false)]
		public string ExcursionLevel3ColorSerialize
		{
			get { return Serialize.BrushToString(ExcursionLevel3Color); }
			set { ExcursionLevel3Color = Serialize.StringToBrush(value); }
		}
		#endregion

		#region HTF Moving Averages

		[NinjaScriptProperty]
		[Display(Name = "MA Type", Description = "Moving average type", Order = 1, GroupName = "dHTFMovingAverages")]
		public ARC_Delta_MA_Type MAType
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "MA Timeframe Minutes", Description = "Timeframe to calculate moving average on in minutes", Order = 2, GroupName = "dHTFMovingAverages")]
		public int MATimeframe
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "MA Period", Description = "Period of the filter moving average", Order = 3, GroupName = "dHTFMovingAverages")]
		public int MAPeriod
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show on Screen", Description = "Wether the strategy shows the moving average", Order = 4, GroupName = "dHTFMovingAverages")]
		public bool ShowMA
		{ get; set; }

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "MA Color", Order = 5, GroupName = "dHTFMovingAverages")]
		public Brush MAColor
		{ get; set; }

		[Browsable(false)]
		public string MAColorSerializable
		{
			get { return Serialize.BrushToString(MAColor); }
			set { MAColor = Serialize.StringToBrush(value); }
		}

		#endregion

		#region Visuals

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name= "Long Stripe Signal Color", Order=1, GroupName= "bVisualParameters")]
		public Brush LongStripColor
		{ get; set; }
					[Browsable(false)]
					public string LongStripColorSerializable
					{	get { return Serialize.BrushToString(LongStripColor); }		set { LongStripColor = Serialize.StringToBrush(value); }		}			

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name= "Long Strip Opacity", Order=2, GroupName= "bVisualParameters")]
		public int LongStripOpacity
		{ get; set; }

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name= "Short Stripe Signal Color", Order=3, GroupName= "bVisualParameters")]
		public Brush ShortStripColor
		{ get; set; }
					[Browsable(false)]
					public string ShortStripColorSerializable
					{get { return Serialize.BrushToString(ShortStripColor); }	set { ShortStripColor = Serialize.StringToBrush(value); }		}			

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name= "Short Strip Opacity", Order=4, GroupName= "bVisualParameters")]
		public int ShortStripOpacity
		{ get; set; }

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="Positive Delta Color", Order=5, GroupName= "bVisualParameters")]
		public Brush PositiveDeltaColor
		{ get; set; }
					[Browsable(false)]
					public string PositiveDeltaColorSerializable
					{	get { return Serialize.BrushToString(PositiveDeltaColor); }	set { PositiveDeltaColor = Serialize.StringToBrush(value); }		}			

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="Negative Delta Color", Order=6, GroupName= "bVisualParameters")]
		public Brush NegativeDeltaColor
		{ get; set; }
					[Browsable(false)]
					public string NegativeDeltaColorSerializable
					{	get { return Serialize.BrushToString(NegativeDeltaColor); }	set { NegativeDeltaColor = Serialize.StringToBrush(value); }		}

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Net Delta Font Size", Order = 7, GroupName = "bVisualParameters")]
		public int NetDeltaFontSize
		{ get; set; }

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "Chart PnL Text Color", Order = 8, GroupName = "bVisualParameters")]
		public Brush ChartPnLTextColor
		{ get; set; }
					[Browsable(false)]
					public string ChartPnLTextColorSerializable
					{	get { return Serialize.BrushToString(ChartPnLTextColor); }	set { ChartPnLTextColor = Serialize.StringToBrush(value); }		}

		[NinjaScriptProperty]
		[Display(Name = "Button Text", Order = 10, GroupName = "bVisualParameters")]
		public string ButtonText
		{ get; set; }
		#endregion
		#endregion
	}
}
