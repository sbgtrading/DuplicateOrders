using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.Strategies.Licensing;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_IBOBAlgo : ARC_IBOBAlgo_ARCStrategyBase
	{
		public override string ProductVersion => "v1.0.2 (3/18/2024)";
		public override string ProductInfusionSoftTag => "28623";
		protected override bool AllowIntrabarEntries => true;
		public override bool HasStrategyBasedStops => true;

		private int lastIbObBar;
		private ARC_IBOBAlgo_SingleBarPattern? lastValidSignal;
		private ATR atr;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_IBOBAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "Inside Bar Outside Bar Algo";

				EnableIbSignals = true;
				EnableObSignals = true;
				MaxIbSignalDelay = 3;
				MinIbBar1SizeType = ARC_IBOBAlgo_IBOBMaxBarSizeType.Ticks;
				MinIbBar1Size = 1;
				MinIbBar1SizeATRPeriod = 10;
			}
			else if (State == State.Configure)
			{
				lastIbObBar = -1;
				lastValidSignal = null;
			}
			else if (State == State.DataLoaded)
			{
				if (EnableIbSignals && MinIbBar1SizeType == ARC_IBOBAlgo_IBOBMaxBarSizeType.ATR)
					atr = ATR(MinIbBar1SizeATRPeriod);
			}
		}
		
		protected override void OnTickBar()
		{
			if (CurrentBars[0] <= 1)
				return;

			if (lastValidSignal == null)
				return;

			var ibLookbackRange = CurrentBars[0] - lastIbObBar;

			for (var dir = -1; dir <= 1; dir += 2)
			{
				var entrySeries = (dir == 1 ? Highs : Lows)[0];
				var entryPrice = InsideBarEntryMethod switch
				{
					_ when lastValidSignal == ARC_IBOBAlgo_SingleBarPattern.Outside => entrySeries.GetValueAt(lastIbObBar),
					ARC_IBOBAlgo_IBOBInsideBarEntryMethod.Bar1 => entrySeries.GetValueAt(lastIbObBar - 1),
					ARC_IBOBAlgo_IBOBInsideBarEntryMethod.LastIb => entrySeries[0],
					ARC_IBOBAlgo_IBOBInsideBarEntryMethod.IbRange => dir == 1 
						? GetRangeMinMax(ibLookbackRange).Max
						: GetRangeMinMax(ibLookbackRange).Min
				};

				entryPrice += dir * EntryOffset * TickSize;

				if (Close[0].ApproxCompare(entryPrice) == -dir || !Close.ARC_IBOBAlgo_Crossed(entryPrice))
					continue;

				if (!TradeAllowed(dir))
					continue;

				var sl = (double?)null;
				var slSeries = (dir == 1 ? Lows : Highs)[0];
				if (EnableAlgoDefinedStopLosses)
				{
					if (lastValidSignal == ARC_IBOBAlgo_SingleBarPattern.Inside)
					{
						sl = InsideBarStopLossMethod switch
						{
							ARC_IBOBAlgo_IBOBInsideBarStopLossMethod.Bar1 => slSeries.GetValueAt(lastIbObBar - 1),
							ARC_IBOBAlgo_IBOBInsideBarStopLossMethod.IbRange => dir == 1 
								? GetRangeMinMax(ibLookbackRange).Min
								: GetRangeMinMax(ibLookbackRange).Max,
							ARC_IBOBAlgo_IBOBInsideBarStopLossMethod.BreakoutBar => dir == 1 ? CurBarLow : CurBarHigh
						};
					}
					else
					{
						sl = OutsideBarStopLossMethod switch
						{
							ARC_IBOBAlgo_IBOBOutsideBarStopLossType.OutsideBar => slSeries.GetValueAt(lastIbObBar),
							ARC_IBOBAlgo_IBOBOutsideBarStopLossType.BreakoutBar => dir == 1 ? CurBarLow : CurBarHigh
						};
					}

					if (sl == null)
						throw new NotImplementedException("Stop type not implemented!");

					var slOffsetMultiplier = StopLossOffsetType == ARC_IBOBAlgo_IBOBStopLossOffsetType.Ticks
						? TickSize
						: ((Highs[0].GetValueAt(lastIbObBar) - Lows[0].GetValueAt(lastIbObBar)) / 100);
					sl -= dir * slOffsetMultiplier * StopLossOffset;
					if (!TradeAllowedWithStop(Close[0], sl.Value))
						continue;
				}

				lastValidSignal = null;
				QueueEntry(dir, 1, stopLossPrice: sl);
				break;
			}
		}

		protected override void OnPrimaryBar()
		{
			if (CurrentBar == 0)
				return;

			if (CurrentBar - lastIbObBar > (lastValidSignal == ARC_IBOBAlgo_SingleBarPattern.Inside ? MaxIbSignalDelay : MaxObSignalDelay))
				lastValidSignal = null;

			if (lastValidSignal == ARC_IBOBAlgo_SingleBarPattern.Inside && (High[0] >= High.GetValueAt(lastIbObBar - 1) || Low[0] <= Low.GetValueAt(lastIbObBar - 1)))
				lastValidSignal = null;

			if (lastValidSignal != null)
				return;

			var pattern = GetSingleBarPattern(0);
			switch (pattern)
			{
			case ARC_IBOBAlgo_SingleBarPattern.Outside when EnableObSignals:
			case ARC_IBOBAlgo_SingleBarPattern.Inside when EnableIbSignals && High[1] - Low[1] >= MinIbBar1Size * (MinIbBar1SizeType == ARC_IBOBAlgo_IBOBMaxBarSizeType.ATR ? atr[1] : TickSize):
				lastValidSignal = pattern;
				lastIbObBar = CurrentBar;
				break;
			default:
				return;
			}
		}

		#region Parameters
		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_IBOBAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_IBOBAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Enable IB Signals", GroupName = StrategyParameterGroupName, Order = 0)]
		public ARC_IBOBAlgo_BoolEnum EnableIbSignalsEnum { get; set; }

		[Browsable(false)]
		public bool EnableIbSignals { get => EnableIbSignalsEnum == ARC_IBOBAlgo_BoolEnum.True; set => EnableIbSignalsEnum = value ? ARC_IBOBAlgo_BoolEnum.True : ARC_IBOBAlgo_BoolEnum.False; }

		[NinjaScriptProperty]
		[ARC_IBOBAlgo_HideUnless(nameof(EnableIbSignalsEnum), ARC_IBOBAlgo_PropComparisonType.EQ, ARC_IBOBAlgo_BoolEnum.True)]
		[Display(Name = "Inside Bar Entry Method", GroupName = StrategyParameterGroupName, Order = 1)]
		public ARC_IBOBAlgo_IBOBInsideBarEntryMethod InsideBarEntryMethod { get; set; }
		
		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[ARC_IBOBAlgo_HideUnless(nameof(EnableIbSignalsEnum), ARC_IBOBAlgo_PropComparisonType.EQ, ARC_IBOBAlgo_BoolEnum.True)]
		[Display(Name = "Max IB Signal Delay", GroupName = StrategyParameterGroupName, Order = 2)]
		public int MaxIbSignalDelay { get; set; }

		[NinjaScriptProperty, RefreshProperties(RefreshProperties.All)]
		[ARC_IBOBAlgo_HideUnless(nameof(EnableIbSignalsEnum), ARC_IBOBAlgo_PropComparisonType.EQ, ARC_IBOBAlgo_BoolEnum.True)]
		[Display(Name = "Min IB Signal Bar1 Size Type", GroupName = StrategyParameterGroupName, Order = 3)]
		public ARC_IBOBAlgo_IBOBMaxBarSizeType MinIbBar1SizeType { get; set; }

		[NinjaScriptProperty]
		[ARC_IBOBAlgo_HideUnless(nameof(EnableIbSignalsEnum), ARC_IBOBAlgo_PropComparisonType.EQ, ARC_IBOBAlgo_BoolEnum.True)]
		[ARC_IBOBAlgo_HideUnless(nameof(MinIbBar1SizeType), ARC_IBOBAlgo_PropComparisonType.EQ, ARC_IBOBAlgo_IBOBMaxBarSizeType.ATR)]
		[Display(Name = "Min IB Signal Bar1 Size ATR Period", GroupName = StrategyParameterGroupName, Order = 4)]
		public int MinIbBar1SizeATRPeriod { get; set; }

		[NinjaScriptProperty, Range(0.0001, double.MaxValue)]
		[ARC_IBOBAlgo_HideUnless(nameof(EnableIbSignalsEnum), ARC_IBOBAlgo_PropComparisonType.EQ, ARC_IBOBAlgo_BoolEnum.True)]
		[ARC_IBOBAlgo_Rename("Min IB Signal Bar1 Size (Ticks)", nameof(MinIbBar1SizeType), ARC_IBOBAlgo_PropComparisonType.EQ, ARC_IBOBAlgo_IBOBMaxBarSizeType.Ticks)]
		[ARC_IBOBAlgo_Rename("Min IB Signal Bar1 Size (ATRs)", nameof(MinIbBar1SizeType), ARC_IBOBAlgo_PropComparisonType.EQ, ARC_IBOBAlgo_IBOBMaxBarSizeType.ATR)]
		[Display(Name = "Min IB Signal Bar1 Size", GroupName = StrategyParameterGroupName, Order = 5)]
		public double MinIbBar1Size { get; set; }

		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_IBOBAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_IBOBAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Enable OB Signals", GroupName = StrategyParameterGroupName, Order = 6)]
		public ARC_IBOBAlgo_BoolEnum EnableObSignalsEnum { get; set; }

		[Browsable(false)]
		public bool EnableObSignals { get => EnableObSignalsEnum == ARC_IBOBAlgo_BoolEnum.True; set => EnableObSignalsEnum = value ? ARC_IBOBAlgo_BoolEnum.True : ARC_IBOBAlgo_BoolEnum.False; }
	
		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[ARC_IBOBAlgo_HideUnless(nameof(EnableObSignalsEnum), ARC_IBOBAlgo_PropComparisonType.EQ, ARC_IBOBAlgo_BoolEnum.True)]
		[Display(Name = "Max OB Signal Delay", GroupName = StrategyParameterGroupName, Order = 7)]
		public int MaxObSignalDelay { get; set; }

		[NinjaScriptProperty, Range(int.MinValue, int.MaxValue)]
		[Display(Name = "Entry Offset (Ticks)", GroupName = StrategyParameterGroupName, Order = 8)]
		public int EntryOffset { get; set; }

		#region Stop Loss
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_IBOBAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_IBOBAlgo_PropComparisonType.EQ, ARC_IBOBAlgo_BoolEnum.True)]
		[Display(Name = "Stop Loss Offset Type", GroupName = StopLossGroupName, Order = 0)]
		public ARC_IBOBAlgo_IBOBStopLossOffsetType StopLossOffsetType { get; set; }

		[NinjaScriptProperty, Range(double.MinValue, double.MaxValue)]
		[ARC_IBOBAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_IBOBAlgo_PropComparisonType.EQ, ARC_IBOBAlgo_BoolEnum.True)]
		[ARC_IBOBAlgo_Rename("Stop Loss Offset (Ticks)", nameof(StopLossOffsetType), ARC_IBOBAlgo_PropComparisonType.EQ, ARC_IBOBAlgo_IBOBStopLossOffsetType.Ticks)]
		[ARC_IBOBAlgo_Rename("Stop Loss Offset (% Bar Range)", nameof(StopLossOffsetType), ARC_IBOBAlgo_PropComparisonType.EQ, ARC_IBOBAlgo_IBOBStopLossOffsetType.PercentBarRange)]
		[Display(Name = "Stop Loss Offset", GroupName = StopLossGroupName, Order = 1)]
		public double StopLossOffset { get; set; }

		[NinjaScriptProperty]
		[ARC_IBOBAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_IBOBAlgo_PropComparisonType.EQ, ARC_IBOBAlgo_BoolEnum.True)]
		[ARC_IBOBAlgo_HideUnless(nameof(EnableIbSignalsEnum), ARC_IBOBAlgo_PropComparisonType.EQ, ARC_IBOBAlgo_BoolEnum.True)]
		[Display(Name = "Inside Bar Stop Loss Method", GroupName = StopLossGroupName, Order = 2)]
		public ARC_IBOBAlgo_IBOBInsideBarStopLossMethod InsideBarStopLossMethod { get; set; }

		[NinjaScriptProperty]
		[ARC_IBOBAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_IBOBAlgo_PropComparisonType.EQ, ARC_IBOBAlgo_BoolEnum.True)]
		[ARC_IBOBAlgo_HideUnless(nameof(EnableObSignalsEnum), ARC_IBOBAlgo_PropComparisonType.EQ, ARC_IBOBAlgo_BoolEnum.True)]
		[Display(Name = "Outside Bar Stop Loss Method", GroupName = StopLossGroupName, Order = 3)]
		public ARC_IBOBAlgo_IBOBOutsideBarStopLossType OutsideBarStopLossMethod { get; set; }
		#endregion
		#endregion
	}

	public enum ARC_IBOBAlgo_IBOBMaxBarSizeType
	{
		Ticks,
		ATR
	}

	public enum ARC_IBOBAlgo_IBOBInsideBarStopLossMethod
	{
		Bar1,
		IbRange,
		BreakoutBar
	}

	public enum ARC_IBOBAlgo_IBOBInsideBarEntryMethod
	{
		Bar1,
		IbRange,
		LastIb
	}

	public enum ARC_IBOBAlgo_IBOBOutsideBarStopLossType
	{
		OutsideBar,
		BreakoutBar
	}
	
	public enum ARC_IBOBAlgo_IBOBStopLossOffsetType
	{
		Ticks,
		PercentBarRange
	}
}