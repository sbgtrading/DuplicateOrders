using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.Strategies.Licensing;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_NRBOAlgo : ARC_NRBOAlgo_ARCStrategyBase
	{
		public override string ProductVersion => "v1.0.0 (9/3/2024)";
		public override string ProductInfusionSoftTag => "39753";
		protected override bool AllowIntrabarEntries => true;
		public override bool HasStrategyBasedStops => true;

		private EMA ema;
		private int? nrcDir;
		private ATR nrcThreshAtr;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_NRBOAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "NRBO Algo";

				EmaPeriod = 20;
				NarrowBodyPercent = 50;
				NrcBarSizeATRPeriod = 14;
				NrcBarSizeThreshType = ARC_NRBOAlgo_AtrOrTicks.ATR;
				NrcMinBarSize = 0;
				NrcMaxBarSize = 1000;
				RequireEma = true;
				RequireBarDirection = true;
				AddPlot(new Stroke(Brushes.Transparent, 3), PlotStyle.Hash, "Pullback Thresh");

				EmaStroke = new Stroke(Brushes.AliceBlue, 3);
			}
			else if (State == State.Configure)
			{
				nrcDir = null;
			}
			else if (State == State.DataLoaded)
			{
				if (NrcBarSizeThreshType == ARC_NRBOAlgo_AtrOrTicks.ATR)
					nrcThreshAtr = ATR(NrcBarSizeATRPeriod);

				AddChartIndicator(ema = EMA(EmaPeriod));
				ema.Name = "";
				ema.Plots[0].DashStyleHelper = EmaStroke.DashStyleHelper;
				ema.Plots[0].Brush = EmaStroke.Brush;
				ema.Plots[0].Width = EmaStroke.Width;
			}
		}
		
		protected override void OnTickBar()
		{
			if (CurrentBars[0] <= 1)
				return;

			if (nrcDir == null)
				return;
			
			var dir = Close[0].ApproxCompare((Opens[0][0] + Closes[0][0]) / 2);
			if (dir == 0)
				return;

			if (RequireBarDirection && nrcDir != dir)
				return;

			// Avoid processing flat ticks unnecessarily
			var barDir = Closes[tickBarsIdx][0].ApproxCompare(Closes[tickBarsIdx][1]);
			if (barDir != 0 && barDir != dir)
				return;

			if (RequireEma && Closes[0][0].ApproxCompare(ema[0]) != dir)
				return;

			if (!TradeAllowed(dir))
				return;

			var entryPrice = (dir == 1 ? Highs : Lows)[0][0] + dir * EntryOffset * TickSize;
			if (!Closes[tickBarsIdx].ARC_NRBOAlgo_Crossed(entryPrice))
				return;

			var sl = (double?)null;
			if (EnableAlgoDefinedStopLosses)
			{
				sl = (dir == 1 ? Lows : Highs)[0][0] - dir * StopLossOffset * (StopLossOffsetType == ARC_NRBOAlgo_NRBOStopLossOffsetType.Ticks ? TickSize : (Highs[0][0] - Lows[0][0]) / 100);
				if (!TradeAllowedWithStop(dir, Close[0], sl.Value))
					return;
			}

			nrcDir = null;
			QueueEntry(dir, 1, stopLossPrice: sl);
		}

		protected override void OnPrimaryBar()
		{
			nrcDir = GetBodyRatio(0) <= NarrowBodyPercent / 100 && ((High[0] - Low[0]) / (NrcBarSizeThreshType == ARC_NRBOAlgo_AtrOrTicks.ATR ? nrcThreshAtr[0] : TickSize)).ARC_NRBOAlgo_InRange(NrcMinBarSize, NrcMaxBarSize)
				? Close[0].ApproxCompare(Open[0])
				: (int?) null;
		}

		#region Parameters
		[NinjaScriptProperty, Range(1, 99)]
		[Display(Name = "Max NRC Body %", GroupName = StrategyParameterGroupName, Order = 0)]
		public double NarrowBodyPercent { get; set; }

		[NinjaScriptProperty, Range(int.MinValue, int.MaxValue)]
		[Display(Name = "Entry Offset (Ticks)", GroupName = StrategyParameterGroupName, Order = 1)]
		public int EntryOffset { get; set; }

		[NinjaScriptProperty, RefreshProperties(RefreshProperties.All)]
		[Display(Name = "NRC Min/Max Size Type", GroupName = StrategyParameterGroupName, Order = 2)]
		public ARC_NRBOAlgo_AtrOrTicks NrcBarSizeThreshType { get; set; }
		
		[NinjaScriptProperty]
		[ARC_NRBOAlgo_HideUnless(nameof(NrcBarSizeThreshType), ARC_NRBOAlgo_PropComparisonType.EQ, ARC_NRBOAlgo_AtrOrTicks.ATR)]
		[Display(Name = "NRC Min/Max Size ATR Period", GroupName = StrategyParameterGroupName, Order = 3)]
		public int NrcBarSizeATRPeriod { get; set; }
		
		[NinjaScriptProperty, Range(0, double.MaxValue)]
		[ARC_NRBOAlgo_Rename("NRC Min Size (Ticks)", nameof(NrcBarSizeThreshType), ARC_NRBOAlgo_PropComparisonType.EQ, ARC_NRBOAlgo_AtrOrTicks.Ticks)]
		[ARC_NRBOAlgo_Rename("NRC Min Size (ATRs)", nameof(NrcBarSizeThreshType), ARC_NRBOAlgo_PropComparisonType.EQ, ARC_NRBOAlgo_AtrOrTicks.ATR)]
		[Display(Name = "NRC Min Size", GroupName = StrategyParameterGroupName, Order = 4)]
		public double NrcMinBarSize { get; set; }

		[NinjaScriptProperty, Range(0, double.MaxValue)]
		[ARC_NRBOAlgo_Rename("NRC Max Size (Ticks)", nameof(NrcBarSizeThreshType), ARC_NRBOAlgo_PropComparisonType.EQ, ARC_NRBOAlgo_AtrOrTicks.Ticks)]
		[ARC_NRBOAlgo_Rename("NRC Max Size (ATRs)", nameof(NrcBarSizeThreshType), ARC_NRBOAlgo_PropComparisonType.EQ, ARC_NRBOAlgo_AtrOrTicks.ATR)]
		[Display(Name = "NRC Max Size", GroupName = StrategyParameterGroupName, Order = 5)]
		public double NrcMaxBarSize { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Require EMA", GroupName = StrategyParameterGroupName, Order = 6)]
		public bool RequireEma { get; set; }
		
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "EMA Period", GroupName = StrategyParameterGroupName, Order = 7)]
		public int EmaPeriod { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Require Bar Direction", GroupName = StrategyParameterGroupName, Order = 8)]
		public bool RequireBarDirection { get; set; }

		#region Stop Loss
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_NRBOAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_NRBOAlgo_PropComparisonType.EQ, ARC_NRBOAlgo_BoolEnum.True)]
		[Display(Name = "Stop Loss Offset Type", GroupName = StopLossGroupName, Order = 1)]
		public ARC_NRBOAlgo_NRBOStopLossOffsetType StopLossOffsetType { get; set; }
		
		[NinjaScriptProperty, Range(int.MinValue, int.MaxValue)]
		[ARC_NRBOAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_NRBOAlgo_PropComparisonType.EQ, ARC_NRBOAlgo_BoolEnum.True)]
		[ARC_NRBOAlgo_Rename("Stop Loss Offset (Ticks)", nameof(StopLossOffsetType), ARC_NRBOAlgo_PropComparisonType.EQ, ARC_NRBOAlgo_NRBOStopLossOffsetType.Ticks)]
		[ARC_NRBOAlgo_Rename("Stop Loss Offset (% NRC Range)", nameof(StopLossOffsetType), ARC_NRBOAlgo_PropComparisonType.EQ, ARC_NRBOAlgo_NRBOStopLossOffsetType.PercentOfNRCRange)]
		[Display(Name = "Stop Loss Offset", GroupName = StopLossGroupName, Order = 2)]
		public int StopLossOffset { get; set; }
		#endregion

		[Display(Name = "EMA Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 0)]
		public Stroke EmaStroke { get; set; }
		#endregion
	}

	public enum ARC_NRBOAlgo_NRBOStopLossOffsetType
	{
		Ticks,
		PercentOfNRCRange
	}

	public enum ARC_NRBOAlgo_NRBOStopLossType
	{
		BasingRange,
		ERC
	}
}