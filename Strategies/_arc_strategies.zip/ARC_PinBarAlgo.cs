﻿using System.ComponentModel.DataAnnotations;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using System.ComponentModel;
using System;
using System.Windows.Media;
using System.Linq;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_PinBarAlgo : ARC_PinBarAlgo_ARCStrategyBase
	{
		public override string ProductVersion => "v1.0.0 (6/26/2024)";
		public override string ProductInfusionSoftTag => "38101";
		public override bool HasStrategyBasedStops => true;
		protected override bool AllowIntrabarEntries => EntryType == ARC_PinBarAlgo_BarCloseOrIntrabar.Intrabar;

		private EMA ema;
		private ATR pinBarSizeAtr;
		private bool validSignal;
		private int lastValidPinBar;
		private int lastValidPinBarDir;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_PinBarAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "PinBar Algo";

				EmaPeriod = 20;
				EntryType = ARC_PinBarAlgo_BarCloseOrIntrabar.Intrabar;
				EntryOffset = 0;
				MaxBarDelay = 0;
				RequireInsidePinRange = false;
				RequireEma = true;
				PinBarSizeType = ARC_PinBarAlgo_AtrOrTicks.Ticks;
				PinBarSizeAtrPeriod = 14;
				MinAllowablePinBarSize = 1;
				MaxAllowablePinBarSize = 100000;
				MaxPinBarBody = 50;
				RequireBarDirection = true;
				RequireBarDirectionOverride = true;
				MaxPinBarBodyForDirectionOverride = 50;

				StopLossOffsetType = ARC_PinBarAlgo_TickOrPercentPatternHLRange.Ticks;
				StopLossOffset = 0;

				EmaStroke = new Stroke(Brushes.AliceBlue, 3);
			}
			else if (State == State.DataLoaded)
			{
				AddChartIndicator(ema = EMA(EmaPeriod));
				ema.Name = "";
				ema.Plots[0].DashStyleHelper = EmaStroke.DashStyleHelper;
				ema.Plots[0].Brush = EmaStroke.Brush;
				ema.Plots[0].Width = EmaStroke.Width;	

				pinBarSizeAtr = ATR(PinBarSizeAtrPeriod);
			}
		}

		protected override void OnEntryExecution(Execution execution, double price, int quantity)
		{
			base.OnEntryExecution(execution, price, quantity);
			validSignal = false;
		}

		private void ScanEntries()
		{
			if (CurrentBars.Any(cb => cb <= 1) || !validSignal)
				return;

			var dir = lastValidPinBarDir;
			if (RequireEma && Closes[0][0].ApproxCompare(ema[0]) != dir)
				return;

			if (EntryType == ARC_PinBarAlgo_BarCloseOrIntrabar.Intrabar)
			{
				var entryPrice = (dir == 1 ? Highs : Lows)[0].GetValueAt(lastValidPinBar) + dir * EntryOffset * TickSize;
				if (!Close.ARC_PinBarAlgo_Crossed(entryPrice))
					return;
			}
			
			var (min, max) = GetRangeMinMax(CurrentBars[0] - lastValidPinBar);
			var sl = (double?)null;
			if (EnableAlgoDefinedStopLosses)
			{
				sl = (dir == 1 ? min : max) - dir * (StopLossOffsetType == ARC_PinBarAlgo_TickOrPercentPatternHLRange.Ticks ? TickSize : (max - min) / 100) * StopLossOffset;
				if (!TradeAllowedWithStop(dir, Close[0], sl.Value))
					return;
			}

			if (!TradeAllowed(dir))
				return;

			QueueEntry(dir, 1, stopLossPrice: sl);
		}

		protected override void OnTickBar()
		{
			if (EntryType != ARC_PinBarAlgo_BarCloseOrIntrabar.Intrabar || lastEntryBar >= CurrentBars[0])
				return;
			
			ScanEntries();
		}

		protected override void OnPrimaryBar()
		{
			if (validSignal)
			{
				if (EntryType == ARC_PinBarAlgo_BarCloseOrIntrabar.Intrabar && CurrentBar - lastValidPinBar > MaxBarDelay)
					validSignal = false;

				if (RequireInsidePinRange && (High[0].ApproxCompare(High.GetValueAt(lastValidPinBar)) == 1 || Low[0].ApproxCompare(Low.GetValueAt(lastValidPinBar)) == -1))
					validSignal = false;

				if ((Position?.MarketPosition ?? MarketPosition.Flat) != MarketPosition.Flat)
					validSignal = false;
			}

			var mid = (High[0] + Low[0]) / 2;
			var dir = Close[0].ApproxCompare(mid);
			if (dir == 0 || Open[0].ApproxCompare(mid) != dir || !InValidTradingWindow(Time[0]) || (Position?.MarketPosition ?? MarketPosition.Flat) != MarketPosition.Flat)
				return;

			var thresh = dir == 1 
				? High[0] * (1 - MaxPinBarBody / 100) + Low[0] * MaxPinBarBody / 100
				: High[0] * MaxPinBarBody / 100 + Low[0] * (1 - MaxPinBarBody / 100);
			if (Open[0].ApproxCompare(thresh) != dir || Close[0].ApproxCompare(thresh) != dir)
				return;

			var pinBarSizeMult = PinBarSizeType == ARC_PinBarAlgo_AtrOrTicks.Ticks	? TickSize : pinBarSizeAtr[0];
			var barSize = High[0] - Low[0];
			if (!barSize.ARC_PinBarAlgo_InRange(MinAllowablePinBarSize * pinBarSizeMult, MaxAllowablePinBarSize * pinBarSizeMult))
				return;

			var bodySize = Math.Max(Close[0], Open[0]) - Math.Min(Close[0], Open[0]);
			if (RequireBarDirection && Close[0].ApproxCompare(Open[0]) != dir && (!RequireBarDirectionOverride || bodySize > barSize * MaxPinBarBodyForDirectionOverride / 100))
				return;

			validSignal = true;
			lastValidPinBar = CurrentBar;
			lastValidPinBarDir = dir;
			if (EntryType == ARC_PinBarAlgo_BarCloseOrIntrabar.BarClose)
				ScanEntries();
		}

		#region Parameters
		#region General
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "EMA Period", GroupName = StrategyParameterGroupName, Order = 0)]
		public int EmaPeriod { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Entry Type", GroupName = StrategyParameterGroupName, Order = 1)]
		public ARC_PinBarAlgo_BarCloseOrIntrabar EntryType { get; set; }
		
		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[ARC_PinBarAlgo_HideUnless(nameof(EntryType), ARC_PinBarAlgo_PropComparisonType.EQ, ARC_PinBarAlgo_BarCloseOrIntrabar.Intrabar)]
		[Display(Name = "Entry Offset (Ticks)", GroupName = StrategyParameterGroupName, Order = 2)]
		public int EntryOffset { get; set; }
		
		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[ARC_PinBarAlgo_HideUnless(nameof(EntryType), ARC_PinBarAlgo_PropComparisonType.EQ, ARC_PinBarAlgo_BarCloseOrIntrabar.Intrabar)]
		[Display(Name = "Max Bar Delay (Entries)", GroupName = StrategyParameterGroupName, Order = 3)]
		public int MaxBarDelay { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Require Inside Pin Range", GroupName = StrategyParameterGroupName, Order = 4)]
		public bool RequireInsidePinRange { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Require EMA", GroupName = StrategyParameterGroupName, Order = 5)]
		public bool RequireEma { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Pin Bar Range Type", GroupName = StrategyParameterGroupName, Order = 6)]
		public ARC_PinBarAlgo_AtrOrTicks PinBarSizeType { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[ARC_PinBarAlgo_HideUnless(nameof(PinBarSizeType), ARC_PinBarAlgo_PropComparisonType.EQ, ARC_PinBarAlgo_AtrOrTicks.ATR)]
		[Display(Name = "Pin Bar Range ATR Period", GroupName = StrategyParameterGroupName, Order = 7)]
		public int PinBarSizeAtrPeriod { get; set; }

		[NinjaScriptProperty, Range(0.001, double.MaxValue)]
		[ARC_PinBarAlgo_Rename("Min Allowable Pin Bar Size (Ticks)", nameof(PinBarSizeType), ARC_PinBarAlgo_PropComparisonType.EQ, ARC_PinBarAlgo_AtrOrTicks.Ticks)]
		[ARC_PinBarAlgo_Rename("Min Allowable Pin Bar Size (ATRs)", nameof(PinBarSizeType), ARC_PinBarAlgo_PropComparisonType.EQ, ARC_PinBarAlgo_AtrOrTicks.ATR)]
		[Display(Name = "Min Allowable Pin Bar Size", GroupName = StrategyParameterGroupName, Order = 8)]
		public double MinAllowablePinBarSize { get; set; }
		
		[NinjaScriptProperty, Range(0.001, double.MaxValue)]
		[ARC_PinBarAlgo_Rename("Max Allowable Pin Bar Size (Ticks)", nameof(PinBarSizeType), ARC_PinBarAlgo_PropComparisonType.EQ, ARC_PinBarAlgo_AtrOrTicks.Ticks)]
		[ARC_PinBarAlgo_Rename("Max Allowable Pin Bar Size (ATRs)", nameof(PinBarSizeType), ARC_PinBarAlgo_PropComparisonType.EQ, ARC_PinBarAlgo_AtrOrTicks.ATR)]
		[Display(Name = "Max Allowable Pin Bar Size", GroupName = StrategyParameterGroupName, Order = 9)]
		public double MaxAllowablePinBarSize { get; set; }
		
		[NinjaScriptProperty, Range(0.001, double.MaxValue)]
		[Display(Name = "Pin Bar Body % Range Threshold", GroupName = StrategyParameterGroupName, Order = 10)]
		public double MaxPinBarBody { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Require Bar Direction", GroupName = StrategyParameterGroupName, Order = 11)]
		public bool RequireBarDirection { get; set; }
		
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_PinBarAlgo_HideUnless(nameof(RequireBarDirection), ARC_PinBarAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Require Direction Override", GroupName = StrategyParameterGroupName, Order = 12)]
		public bool RequireBarDirectionOverride { get; set; }

		[NinjaScriptProperty, Range(0.001, double.MaxValue)]
		[ARC_PinBarAlgo_HideUnless(nameof(RequireBarDirectionOverride), ARC_PinBarAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Max Pin Bar Body % HL Range For Direction Override", GroupName = StrategyParameterGroupName, Order = 13)]
		public double MaxPinBarBodyForDirectionOverride { get; set; }
		#endregion

		#region Stop Loss
		[NinjaScriptProperty]
		[ARC_PinBarAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_PinBarAlgo_PropComparisonType.EQ, ARC_PinBarAlgo_BoolEnum.True)]
		[Display(Name = "Stop Loss Type", GroupName = StopLossGroupName, Order = 1)]
		public ARC_PinBarAlgo_TickOrPercentPatternHLRange StopLossOffsetType { get; set; }

		[NinjaScriptProperty, Range(double.MinValue, double.MaxValue)]
		[ARC_PinBarAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_PinBarAlgo_PropComparisonType.EQ, ARC_PinBarAlgo_BoolEnum.True)]
		[ARC_PinBarAlgo_Rename("Stop Loss Offset (Ticks)", nameof(StopLossOffsetType), ARC_PinBarAlgo_PropComparisonType.EQ, ARC_PinBarAlgo_TickOrPercentPatternHLRange.Ticks)]
		[ARC_PinBarAlgo_Rename("Stop Loss Offset (% of HL Range)", nameof(StopLossOffsetType), ARC_PinBarAlgo_PropComparisonType.EQ, ARC_PinBarAlgo_TickOrPercentPatternHLRange.PercentOfPatternHLRange)]
		[Display(Name = "Stop Loss Offset", GroupName = StopLossGroupName, Order = 2)]
		public double StopLossOffset { get; set; }
		#endregion

		[Display(Name = "EMA Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 0)]
		public Stroke EmaStroke { get; set; }
		#endregion
	}
}