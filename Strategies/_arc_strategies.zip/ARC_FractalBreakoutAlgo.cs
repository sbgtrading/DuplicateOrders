using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.Strategies.Licensing;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_FractalBreakoutAlgo : ARC_FractalBreakoutAlgo_ARCStrategyBase
	{
		public override string ProductVersion => "v1.0.1 (3/13/2025)";
		public override string ProductInfusionSoftTag => "42525";
		public override bool HasStrategyBasedStops => true;
		protected override bool AllowIntrabarEntries => EntryType == ARC_FractalBreakoutAlgo_AlgoEntryType.Intrabar;

		private class Window
		{
			public double High { get; }
			public double Low { get; }
			public int ZoneEndBar { get; }
			public int TakenTradeDir { get; set; }
			public int EndBar
			{
				set
				{
					foreach (var line in new [] { _lowLine, _highLine })
					{
						line.EndAnchor.SlotIndex = value;
						line.EndAnchor.DrawnOnBar = value;
					}
				}
			}

			private readonly DrawingTools.Line _highLine;
			private readonly DrawingTools.Line _lowLine;
			public Window(ARC_FractalBreakoutAlgo strategy, int windowStartBarsAgo, int windowEndBarsAgo)
			{
				var (min, max) = strategy.GetRangeMinMax(windowStartBarsAgo - windowEndBarsAgo, windowEndBarsAgo);
				
				ZoneEndBar = strategy.CurrentBars[0] - windowEndBarsAgo;
				High = max;
				Low = min;

				_highLine = Draw.Line(strategy, Guid.NewGuid().ToString(), true, windowStartBarsAgo, max, 0, max, strategy.FractalHighStroke.Brush, strategy.FractalHighStroke.DashStyleHelper, (int) strategy.FractalHighStroke.Width);
				_lowLine = Draw.Line(strategy, Guid.NewGuid().ToString(), true, windowStartBarsAgo, min, 0, min, strategy.FractalLowStroke.Brush, strategy.FractalLowStroke.DashStyleHelper, (int) strategy.FractalLowStroke.Width);
				var rect = Draw.Rectangle(strategy, Guid.NewGuid().ToString(), true, windowStartBarsAgo, min, windowEndBarsAgo, max, Brushes.Transparent, strategy.FractalFillBrush.OpaqueBrush, (int)(strategy.FractalFillBrush.Opacity * 255));
				rect.ZOrderType = DrawingToolZOrder.AlwaysDrawnFirst;
			}
		}

		private int _fractalsToday;
		private readonly List<Window> _activeWindows = new();
		private EMA ema;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_FractalBreakoutAlgo_IsLicensed())
				return;
			
			if (State == State.SetDefaults)
			{
				ButtonText = "Fractal Breakout Algo";
				
				_customWindows.Clear();
				MaxAllowableBarDelay = 1;
				RequireEma = true;
				EmaPeriod = 20;
				MaxFractals = 1;
			}
			else if (State == State.Configure)
			{
				_activeWindows.Clear();
				_fractalsToday = 0;
			}
			else if (State == State.DataLoaded)
			{
				AddChartIndicator(ema = EMA(EmaPeriod));
				ema.Name = "";
				ema.Plots[0].DashStyleHelper = EmaStroke.DashStyleHelper;
				ema.Plots[0].Brush = EmaStroke.Brush;
				ema.Plots[0].Width = EmaStroke.Width;
			}
		}

		private void ScanEntries()
		{
			if (CurrentBars[0] <= 5 || CurrentBar < 5)
				return;

			var dir = BarsInProgress == 0 ? Close[0].ApproxCompare(Open[0]) : Close[0].ApproxCompare(Close[1]);
			if (dir == 0)
				return;

			var entryOffset = EntryType == ARC_FractalBreakoutAlgo_AlgoEntryType.Intrabar ? TickSize * EntryOffset : 0;
			var enteringWindow = _activeWindows.FirstOrDefault(w => Close[0].ApproxCompare((dir == 1 ? w.High : w.Low) + dir * entryOffset) == dir && w.TakenTradeDir != dir);
			if (enteringWindow == null || enteringWindow.TakenTradeDir == dir)
				return;

			if (!AllowOppositeTrade || enteringWindow.TakenTradeDir != 0)
				_activeWindows.Remove(enteringWindow);
			else
				enteringWindow.TakenTradeDir = dir;

			if (RequireEma && Close[0].ApproxCompare(ema[0]) != dir)
				return;

			if (!TradeAllowed(dir))
				return;

			var sl = (double?)null;
			if (EnableAlgoDefinedStopLosses)
			{
				var offsetUnit = StopLossOffsetType == ARC_FractalBreakoutAlgo_FractalBreakoutStopLossOffsetType.PercentOfFractalRange ? (enteringWindow.High - enteringWindow.Low) / 100 : TickSize;
				sl = (dir == 1 ? enteringWindow.Low : enteringWindow.High) - dir * StopLossOffset * offsetUnit;
				if (!TradeAllowedWithStop(dir, Close[0], sl.Value))
					return;
			}

			QueueEntry(dir, AllowIntrabarEntries ? 1 : 0, stopLossPrice: sl);
		}

		private int TotalMinutes(DateTime dt)
		{
			return dt.Hour * 60 + dt.Minute;
		}

		private void UpdateWindows()
		{
			if (CurrentBar < 1)
				return;

			if (Bars.IsFirstBarOfSession)
			{
				_activeWindows.ForEach(w => w.EndBar = CurrentBar - 1);
				_activeWindows.Clear();
				_fractalsToday = 0;
				return;
			}

			_activeWindows.ForEach(w => w.EndBar = CurrentBar);
			
			var barStartEndMinuteNum = Enumerable.Range(0, 2)
				.Select(i => TotalMinutes(Time[i]))
				.Reverse()
				.ToArray();
		 
			switch (FractalType)
			{
			case ARC_FractalBreakoutAlgo_FractalType.Intervals:
				var windowNum = (barStartEndMinuteNum[1] - StartingMinute) / (FractalInterval + FractalLength);
				var windowStart = StartingMinute + windowNum * (FractalInterval + FractalLength);
				if ((windowStart % 60) < StartingMinute && Time[0] - sessionTracker.GetStartOfSession(0) < TimeSpan.FromHours(1))
					return;
				
				if (barStartEndMinuteNum[0] == windowStart)
					_activeWindows.Clear();
				
				var windowEnd = windowStart + FractalLength;
				var endBar = Bars.GetBar(Time[0].Date.AddMinutes(windowEnd));
				if (endBar == CurrentBar && _fractalsToday < MaxFractals)
				{
					_fractalsToday++;
					_activeWindows.Add(new Window(this, CurrentBar - Bars.GetBar(Time[0].Date.AddMinutes(windowStart).AddTicks(1)), CurrentBar - endBar));
				}

				break;
			case ARC_FractalBreakoutAlgo_FractalType.Custom:
				foreach (var window in Enumerable.Range(0, MaxFractals).Select(i => _customWindows[i]))
				{
					var windowMinutes = new [] { window.StartTime, window.StartTime + window.Length / 60 * 100 + (window.Length % 60) }
						.Select(t => t / 100 * 60 + t % 100)
						.ToArray();

					endBar = Bars.GetBar(Time[0].Date.AddMinutes(windowMinutes[1]));
					if (endBar != CurrentBar)
						continue;

					var startBar = Bars.GetBar(Time[0].Date.AddMinutes(windowMinutes[0]).AddTicks(1));
					_activeWindows.Add(new Window(this, CurrentBar - startBar, CurrentBar - endBar));
				}

				break;
			}

			_activeWindows.RemoveAll(w => CurrentBar - w.ZoneEndBar >= MaxAllowableBarDelay);
		}

		protected override void OnPrimaryBar()
		{
			if (BarsArray[0].IsFirstBarOfSession)
				_fractalsToday = 0;

			UpdateWindows();
			if (EntryType == ARC_FractalBreakoutAlgo_AlgoEntryType.BarClose)
				ScanEntries();
		}

		protected override void OnTickBar()
		{
			if (EntryType == ARC_FractalBreakoutAlgo_AlgoEntryType.Intrabar)
				ScanEntries();
		}

		#region Parameters
		private class CustomWindow
		{
			public int StartTime { get; set; }
			public int Length { get; set; }
		}

		private readonly ARC_FractalBreakoutAlgo_DefaultingDictionary<int, CustomWindow> _customWindows = new(i => new CustomWindow());

		[NinjaScriptProperty, RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Entry Type", GroupName = StrategyParameterGroupName, Order = -100)]
		public ARC_FractalBreakoutAlgo_AlgoEntryType EntryType { get; set; }

		[NinjaScriptProperty]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(EntryType), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_AlgoEntryType.Intrabar)]
		[Display(Name = "Entry Offset", GroupName = StrategyParameterGroupName, Order = -99)]
		public int EntryOffset { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Allow 2nd Opposite Trade", GroupName = StrategyParameterGroupName, Order = -98)]
		public bool AllowOppositeTrade { get; set; }

		[NinjaScriptProperty, RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Max Fractals Per Day", GroupName = StrategyParameterGroupName, Order = 0)]
		public int MaxFractals { get; set; }

		[NinjaScriptProperty, RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Fractal Type", GroupName = StrategyParameterGroupName, Order = 1)]
		public ARC_FractalBreakoutAlgo_FractalType FractalType { get; set; }

		[NinjaScriptProperty, Range(0, 2359)]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(FractalType), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_FractalType.Custom)]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(MaxFractals), ARC_FractalBreakoutAlgo_PropComparisonType.GTE, 1)]
		[Display(Name = "Fractal 1 - Start Time", GroupName = StrategyParameterGroupName, Order = 2)]
		public int Fractal1StartTime { get => _customWindows[0].StartTime; set => _customWindows[0].StartTime = value; }

		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(FractalType), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_FractalType.Custom)]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(MaxFractals), ARC_FractalBreakoutAlgo_PropComparisonType.GTE, 1)]
		[Display(Name = "Fractal 1 - Length", GroupName = StrategyParameterGroupName, Order = 3)]
		public int Fractal1Length { get => _customWindows[0].Length; set => _customWindows[0].Length = value; }

		[NinjaScriptProperty, Range(0, 2359)]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(FractalType), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_FractalType.Custom)]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(MaxFractals), ARC_FractalBreakoutAlgo_PropComparisonType.GTE, 2)]
		[Display(Name = "Fractal 2 - Start Time", GroupName = StrategyParameterGroupName, Order = 4)]
		public int Fractal2StartTime { get => _customWindows[1].StartTime; set => _customWindows[1].StartTime = value; }

		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(FractalType), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_FractalType.Custom)]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(MaxFractals), ARC_FractalBreakoutAlgo_PropComparisonType.GTE, 2)]
		[Display(Name = "Fractal 2 - Length", GroupName = StrategyParameterGroupName, Order = 5)]
		public int Fractal2Length { get => _customWindows[1].Length; set => _customWindows[1].Length = value; }

		[NinjaScriptProperty, Range(0, 2359)]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(FractalType), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_FractalType.Custom)]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(MaxFractals), ARC_FractalBreakoutAlgo_PropComparisonType.GTE, 3)]
		[Display(Name = "Fractal 3 - Start Time", GroupName = StrategyParameterGroupName, Order = 6)]
		public int Fractal3StartTime { get => _customWindows[2].StartTime; set => _customWindows[2].StartTime = value; }

		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(FractalType), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_FractalType.Custom)]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(MaxFractals), ARC_FractalBreakoutAlgo_PropComparisonType.GTE, 3)]
		[Display(Name = "Fractal 3 - Length", GroupName = StrategyParameterGroupName, Order = 7)]
		public int Fractal3Length { get => _customWindows[2].Length; set => _customWindows[2].Length = value; }

		[NinjaScriptProperty, Range(0, 59)]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(FractalType), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_FractalType.Intervals)]
		[Display(Name = "Starting Minute", GroupName = StrategyParameterGroupName, Order = 100)]
		public int StartingMinute { get; set; }

		[NinjaScriptProperty]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(FractalType), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_FractalType.Intervals)]
		[Display(Name = "Fractal Interval", GroupName = StrategyParameterGroupName, Order = 101)]
		public int FractalInterval { get; set; }

		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(FractalType), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_FractalType.Intervals)]
		[Display(Name = "Fractal Length", GroupName = StrategyParameterGroupName, Order = 101)]
		public int FractalLength { get; set; }

		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[Display(Name = "Max Allowable Bar Delay", GroupName = StrategyParameterGroupName, Order = 200)]
		public int MaxAllowableBarDelay { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Require EMA", GroupName = StrategyParameterGroupName, Order = 300)]
		public bool RequireEma { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "EMA Period", GroupName = StrategyParameterGroupName, Order = 301)]
		public int EmaPeriod { get; set; }

		#region Stop Loss
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_BoolEnum.True)]
		[Display(Name = "Stop Loss Offset Type", GroupName = StopLossGroupName, Order = 1)]
		public ARC_FractalBreakoutAlgo_FractalBreakoutStopLossOffsetType StopLossOffsetType { get; set; }
		
		[NinjaScriptProperty]
		[ARC_FractalBreakoutAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_BoolEnum.True)]
		[ARC_FractalBreakoutAlgo_Rename("Stop Loss Offset (Ticks)", nameof(StopLossOffsetType), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_FractalBreakoutStopLossOffsetType.Ticks)]
		[ARC_FractalBreakoutAlgo_Rename("Stop Loss Offset (% Fractal Range)", nameof(StopLossOffsetType), ARC_FractalBreakoutAlgo_PropComparisonType.EQ, ARC_FractalBreakoutAlgo_FractalBreakoutStopLossOffsetType.PercentOfFractalRange)]
		[Display(Name = "Stop Loss Offset", GroupName = StopLossGroupName, Order = 2)]
		public int StopLossOffset { get; set; }
		#endregion

		[Display(Name = "EMA Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 0)]
		public Stroke EmaStroke { get; set; } = new Stroke(Brushes.AliceBlue, 3);

		[Display(Name = "Fractal High Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 1)]
		public Stroke FractalHighStroke { get; set; } = new Stroke(Brushes.LightGray, DashStyleHelper.Dash, 2);

		[Display(Name = "Fractal Low Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 2)]
		public Stroke FractalLowStroke { get; set; } = new Stroke(Brushes.LightGray, DashStyleHelper.Dash, 2);

		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_FractalBreakoutAlgo_EnhancedBrushPicker")]
		[Display(Name = "Fractal Fill Brush", GroupName = StrategyVisualsParameterGroupName, Order = 3)]
		public ARC_FractalBreakoutAlgo_EnhancedBrush FractalFillBrush { get; set; } = new ARC_FractalBreakoutAlgo_EnhancedBrush(Brushes.LightGray, 0.2f);
		
		[Browsable(false)]
		public string FractalFillBrushSerializable
		{
			get => FractalFillBrush;
			set => FractalFillBrush = value;
		}
		#endregion
	}

	public enum ARC_FractalBreakoutAlgo_FractalType
	{
		Custom,
		Intervals
	}

	public enum ARC_FractalBreakoutAlgo_FractalBreakoutStopLossOffsetType
	{
		Ticks,
		PercentOfFractalRange
	}
}