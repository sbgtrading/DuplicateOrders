using System;
using System.Collections.Generic;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.Indicators.ARC;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.Xml.Serialization;
using System.Linq;
using System.Windows.Media;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using Unizone = NinjaTrader.NinjaScript.Indicators.ARC.ARC_UnizonesAlgo_ARC_Unizones.Unizone;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	[ARC_UnizonesAlgo_CoLicenses(typeof(ARC_UnizonesAlgo_ARC_Unizones))]
	public class ARC_UnizonesAlgo : ARC_UnizonesAlgo_ARCStrategyBase
	{
		public override string ProductVersion => "v1.0.20 (12/6/2023)";
		public override string ProductInfusionSoftTag => "27223";
		protected override bool AllowIntrabarEntries => true;
		public override bool HasStrategyBasedStops => true;

		private IEnumerable<Unizone> TradedZones
		{
			get
			{
				var indicators = enabledTypes
					.Where(kvp => kvp.Value)
					.Select(kvp => unizones[kvp.Key])
					.ToArray();

				var zones = Enumerable.Empty<Unizone>();
				if (TradeFreshZones)
					zones = zones.Concat(indicators.SelectMany(v => v.FreshBlocks));

				if (TradeTestedZones)
					zones = zones.Concat(indicators.SelectMany(v => v.TestedBlocks));

				return zones;
			}
		}

		private readonly ARC_UnizonesAlgo_DefaultingDictionary<Unizone, int> tradesPerZone = new ARC_UnizonesAlgo_DefaultingDictionary<Unizone, int>(0);
		private readonly Dictionary<ARC_UnizonesAlgo_UnizoneType, ARC_UnizonesAlgo_ARC_Unizones> unizones = new Dictionary<ARC_UnizonesAlgo_UnizoneType, ARC_UnizonesAlgo_ARC_Unizones>();
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_UnizonesAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "Unizones Algo";

				TradeFreshZones = true;
				TradeTestedZones = false;
				MaxTradesPerZone = 1;
				TradeEdgeOffset = 0;
				MinBarsOutsideTradeZone = 2;
				MaxAgeDays = 5;

				MaxObBody = 50;
				MaxBasingBarBody = 50;
				IncludeWicksInBasingBars = true;
				MaxBasingBars = 10000;
				TrapZoneSizeType = ARC_UnizonesAlgo_UnizoneSizeType.ATR;
				TrapZoneMinSize = 1;
				TrapZoneMaxSize = 1000;

				StopOffset = 0;
				MinAllowableStopLoss = 1;
				MaxAllowableStopLoss = 1000;

				BasingBarUpBrush = Brushes.White;
				BasingBarDownBrush = Brushes.Black;
				ThrustBarUpBrush = Brushes.Lime;
				ThrustBarDownBrush = Brushes.Red;
			}
			else if (State == State.Configure)
			{
				tradesPerZone.Clear();
				unizones.Clear();
			}
			else if (State == State.DataLoaded)
			{
				foreach (var t in Enum.GetValues(typeof(ARC_UnizonesAlgo_UnizoneType)).OfType<ARC_UnizonesAlgo_UnizoneType>().Where(t => enabledTypes[t]))
				{
					AddChartIndicator(unizones[t] = ARC_UnizonesAlgo_ARC_Unizones(t, t == ARC_UnizonesAlgo_UnizoneType.OrderBlock ? MaxObBody : MaxBasingBarBody, IncludeWicksInBasingBars, MaxBasingBars, MaxThrustBarDelay, MaxAgeDays, TrapZoneSizeType, TrapZoneMinSize, TrapZoneMaxSize));
					unizones[t].zoneBrushes = zoneBrushes;
					unizones[t].outlineBrushes = outlineBrushes;
					unizones[t].BasingBarUpBrush = BasingBarUpBrush;
					unizones[t].BasingBarDownBrush = BasingBarDownBrush;
					unizones[t].ThrustBarUpBrush = ThrustBarUpBrush;
					unizones[t].ThrustBarDownBrush = ThrustBarDownBrush;
				}
			}
		}

		private double GetTradeEdge(Unizone zone)
		{
			return (zone.Bias == 1 ? Math.Max(zone.Y1, zone.Y2) : Math.Min(zone.Y1, zone.Y2)) + zone.Bias * TradeEdgeOffset * TickSize;
		}

		private void ScanEntries()
		{
			if (CurrentBars[0] == 0 || lastSignalBar == CurrentBars[0] + 1)
				return;

			// Decide direction based on tick (if tick was up, we're entering resistance blocks)
			var dir = -Close[0].ApproxCompare(Close[1]);
			if (dir == 0)
				return;

			// Validate that there's a valid trade zone above us if last tick up, and below us if last tick down
			var nearestZone = TradedZones
				.Where(b =>
				{
					// Ensure bias
					if (b.Bias != dir)
						return false;

					// Ensure trades are under max count
					if (tradesPerZone[b] >= MaxTradesPerZone)
						return false;

					// Ensure tick touches trade edge and came from outside it
					var tradeEdge = GetTradeEdge(b);
					if (Close[0].ApproxCompare(tradeEdge) == dir || Close[1].ApproxCompare(tradeEdge) != dir)
						return false;

					// Ensure stop size (as defined by the ideal entry price) is within bounds
					if (EnableAlgoDefinedStopLosses)
					{
						var stopTicks = Math.Abs(b.EntryPrice - b.Stop) / TickSize + StopOffset + TradeEdgeOffset;
						if (!stopTicks.ARC_UnizonesAlgo_InRange(MinAllowableStopLoss, MaxAllowableStopLoss))
							return false;
					}

					// Ensure sufficient bars outside trade zone
					for (var i = 0; i < Math.Min(CurrentBars[0], MinBarsOutsideTradeZone); i++)
						if ((b.Bias == 1 ? Lows : Highs)[0][i].ApproxCompare(tradeEdge) != b.Bias)
							return false;

					return true;
				})
				.OrderBy(b => -b.Bias * b.EntryPrice)
				.FirstOrDefault();

			if (nearestZone == null)
				return;

			// Find the active zone crossed most closely to the current close
			if (!TradeAllowed(dir))
				return;

			tradesPerZone[nearestZone]++;
			QueueEntry(dir, 1, stopLossPrice: EnableAlgoDefinedStopLosses ? nearestZone.Stop - nearestZone.Bias * StopOffset * TickSize : (double?) null);
		}
		
		protected override void OnTickBar()
		{
			if (CurrentBars[0] < 0)
				return;

			ScanEntries();
		}

		protected override void OnPrimaryBar()
		{
			foreach (var unizone in unizones.Values)
				unizone.Update();
		}

		#region Parameters
		private readonly ARC_UnizonesAlgo_DefaultingDictionary<ARC_UnizonesAlgo_UnizoneType, bool> enabledTypes = new ARC_UnizonesAlgo_DefaultingDictionary<ARC_UnizonesAlgo_UnizoneType, bool>(true);

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Enable Order Blocks", GroupName = StrategyParameterGroupName, Order = 0)]
		public bool EnableOrderBlocks
		{
			get => enabledTypes[ARC_UnizonesAlgo_UnizoneType.OrderBlock];
			set => enabledTypes[ARC_UnizonesAlgo_UnizoneType.OrderBlock] = value;
		}
		
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Enable S&D", GroupName = StrategyParameterGroupName, Order = 1)]
		public bool EnableSupplyAndDemand
		{
			get => enabledTypes[ARC_UnizonesAlgo_UnizoneType.SupplyAndDemand];
			set => enabledTypes[ARC_UnizonesAlgo_UnizoneType.SupplyAndDemand] = value;
		}
		
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Enable Trap", GroupName = StrategyParameterGroupName, Order = 2)]
		public bool EnableTrap
		{
			get => enabledTypes[ARC_UnizonesAlgo_UnizoneType.Trap];
			set => enabledTypes[ARC_UnizonesAlgo_UnizoneType.Trap] = value;
		}

		[NinjaScriptProperty]
		[Display(Name = "Trade Fresh Zones", GroupName = StrategyParameterGroupName, Order = 3)]
		public bool TradeFreshZones { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Trade Tested Zones", GroupName = StrategyParameterGroupName, Order = 4)]
		public bool TradeTestedZones { get; set; }
		
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "Max Trades Per Zone", GroupName = StrategyParameterGroupName, Order = 5)]
		public int MaxTradesPerZone { get; set; }
		
		[NinjaScriptProperty, Range(int.MinValue, int.MaxValue)]
		[Display(Name = "Zone Edge Entry Price Offset", GroupName = StrategyParameterGroupName, Order = 6)]
		public int TradeEdgeOffset { get; set; }

		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[Display(Name = "Min Pre-Trade Bars Outside Entry Price", GroupName = StrategyParameterGroupName, Order = 7)]
		public int MinBarsOutsideTradeZone { get; set; }

		[NinjaScriptProperty, Range(double.Epsilon, 100)]
		[Display(Name = "Max Order Block Bar Body %", GroupName = StrategyParameterGroupName, Order = 100)]
		public double MaxObBody { get; set; }
		
		[NinjaScriptProperty, Range(double.Epsilon, 100)]
		[Display(Name = "Basing Bar Max Body %", GroupName = StrategyParameterGroupName, Order = 101)]
		public double MaxBasingBarBody { get; set; }

		[NinjaScriptProperty]
		[ARC_UnizonesAlgo_HideUnless(nameof(EnableSupplyAndDemand), ARC_UnizonesAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Include Wicks in Basing Bars", GroupName = StrategyParameterGroupName, Order = 102)]
		public bool IncludeWicksInBasingBars { get; set; }
		
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[ARC_UnizonesAlgo_HideUnless(nameof(EnableSupplyAndDemand), ARC_UnizonesAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Max Basing Bars", GroupName = StrategyParameterGroupName, Order = 103)]
		public int MaxBasingBars { get; set; }

		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[ARC_UnizonesAlgo_HideUnless(nameof(EnableOrderBlocks), ARC_UnizonesAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Max Thrust Bar Delay", GroupName = StrategyParameterGroupName, Order = 104)]
		public int MaxThrustBarDelay { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "Max Zone Age Days", GroupName = StrategyParameterGroupName, Order = 105)]
		public int MaxAgeDays { get; set; }

		[NinjaScriptProperty]
		[ARC_UnizonesAlgo_HideUnless(nameof(EnableTrap), ARC_UnizonesAlgo_PropComparisonType.EQ, true)]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Trap Zone Size Type", GroupName = StrategyParameterGroupName, Order = 106)]
		public ARC_UnizonesAlgo_UnizoneSizeType TrapZoneSizeType { get; set; }
		
		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[ARC_UnizonesAlgo_HideUnless(nameof(EnableTrap), ARC_UnizonesAlgo_PropComparisonType.EQ, true)]
		[ARC_UnizonesAlgo_Rename("Trap Zone Min Size (ATR)", nameof(TrapZoneSizeType), ARC_UnizonesAlgo_PropComparisonType.EQ, ARC_UnizonesAlgo_UnizoneSizeType.ATR)]
		[ARC_UnizonesAlgo_Rename("Trap Zone Min Size (Ticks)", nameof(TrapZoneSizeType), ARC_UnizonesAlgo_PropComparisonType.EQ, ARC_UnizonesAlgo_UnizoneSizeType.Ticks)]
		[Display(Name = "TrapZoneMinSize", GroupName = StrategyParameterGroupName, Order = 107)]
		public double TrapZoneMinSize { get; set; }
		
		[NinjaScriptProperty, Range(1e-5, int.MaxValue)]
		[ARC_UnizonesAlgo_HideUnless(nameof(EnableTrap), ARC_UnizonesAlgo_PropComparisonType.EQ, true)]
		[ARC_UnizonesAlgo_Rename("Trap Zone Max Size (ATR)", nameof(TrapZoneSizeType), ARC_UnizonesAlgo_PropComparisonType.EQ, ARC_UnizonesAlgo_UnizoneSizeType.ATR)]
		[ARC_UnizonesAlgo_Rename("Trap Zone Max Size (Ticks)", nameof(TrapZoneSizeType), ARC_UnizonesAlgo_PropComparisonType.EQ, ARC_UnizonesAlgo_UnizoneSizeType.Ticks)]
		[Display(Name = "TrapZoneMaxSize", GroupName = StrategyParameterGroupName, Order = 108)]
		public double TrapZoneMaxSize { get; set; }

		[NinjaScriptProperty, Range(int.MinValue, int.MaxValue)]
		[ARC_UnizonesAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_UnizonesAlgo_PropComparisonType.EQ, ARC_UnizonesAlgo_BoolEnum.True)]
		[Display(Name = "Stop Price Offset", GroupName = StopLossGroupName, Order = 1)]
		public int StopOffset { get; set; }
		
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[ARC_UnizonesAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_UnizonesAlgo_PropComparisonType.EQ, ARC_UnizonesAlgo_BoolEnum.True)]
		[Display(Name = "Min Allowable Stop Loss (Ticks)", GroupName = StopLossGroupName, Order = 2)]
		public int MinAllowableStopLoss { get; set; }
		
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[ARC_UnizonesAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_UnizonesAlgo_PropComparisonType.EQ, ARC_UnizonesAlgo_BoolEnum.True)]
		[Display(Name = "Max Allowable Stop Loss (Ticks)", GroupName = StopLossGroupName, Order = 3)]
		public int MaxAllowableStopLoss { get; set; }
		#endregion

		#region Visuals
		internal ARC_UnizonesAlgo_DefaultingDictionary<int, ARC_UnizonesAlgo_DefaultingDictionary<ARC_UnizonesAlgo_UnizoneFreshness, ARC_UnizonesAlgo_EnhancedBrush>> zoneBrushes = new ARC_UnizonesAlgo_DefaultingDictionary<int, ARC_UnizonesAlgo_DefaultingDictionary<ARC_UnizonesAlgo_UnizoneFreshness, ARC_UnizonesAlgo_EnhancedBrush>>(dir => new ARC_UnizonesAlgo_DefaultingDictionary<ARC_UnizonesAlgo_UnizoneFreshness, ARC_UnizonesAlgo_EnhancedBrush>(f =>
		{
			return f switch
			{
				ARC_UnizonesAlgo_UnizoneFreshness.Fresh => new ARC_UnizonesAlgo_EnhancedBrush { OpaqueBrush = dir == 1 ? Brushes.Lime : Brushes.Red, Opacity = 0.5f },
				ARC_UnizonesAlgo_UnizoneFreshness.Tested => new ARC_UnizonesAlgo_EnhancedBrush { OpaqueBrush = dir == 1 ? Brushes.Green : Brushes.Maroon, Opacity = 0.5f },
				ARC_UnizonesAlgo_UnizoneFreshness.Broken => new ARC_UnizonesAlgo_EnhancedBrush { OpaqueBrush = dir == 1 ? Brushes.Cyan : Brushes.LightCoral, Opacity = 0.25f },
				_ => throw new ArgumentOutOfRangeException(nameof(f))
			};
		}));

		internal ARC_UnizonesAlgo_DefaultingDictionary<ARC_UnizonesAlgo_UnizoneFreshness, Stroke> outlineBrushes = new ARC_UnizonesAlgo_DefaultingDictionary<ARC_UnizonesAlgo_UnizoneFreshness, Stroke>(_ => new Stroke { Brush = Brushes.Black, Opacity = 50, DashStyleHelper = DashStyleHelper.Solid, Width = 3 });

		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Fresh Support Color", GroupName = StrategyVisualsParameterGroupName, Order = 0)]
		public ARC_UnizonesAlgo_EnhancedBrush FreshSupportBrush
		{
			get => zoneBrushes[1][ARC_UnizonesAlgo_UnizoneFreshness.Fresh];
			set => zoneBrushes[1][ARC_UnizonesAlgo_UnizoneFreshness.Fresh] = value;
		}
		
		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Tested Support Color", GroupName = StrategyVisualsParameterGroupName, Order = 1)]
		public ARC_UnizonesAlgo_EnhancedBrush TestedSupportBrush
		{
			get => zoneBrushes[1][ARC_UnizonesAlgo_UnizoneFreshness.Tested];
			set => zoneBrushes[1][ARC_UnizonesAlgo_UnizoneFreshness.Tested] = value;
		}
		
		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Broken Support Color", GroupName = StrategyVisualsParameterGroupName, Order = 2)]
		public ARC_UnizonesAlgo_EnhancedBrush BrokenSupportBrush
		{
			get => zoneBrushes[1][ARC_UnizonesAlgo_UnizoneFreshness.Broken];
			set => zoneBrushes[1][ARC_UnizonesAlgo_UnizoneFreshness.Broken] = value;
		}
		
		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Fresh Resistance Color", GroupName = StrategyVisualsParameterGroupName, Order = 3)]
		public ARC_UnizonesAlgo_EnhancedBrush FreshResistanceBrush
		{
			get => zoneBrushes[-1][ARC_UnizonesAlgo_UnizoneFreshness.Fresh];
			set => zoneBrushes[-1][ARC_UnizonesAlgo_UnizoneFreshness.Fresh] = value;
		}
		
		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Tested Resistance Color", GroupName = StrategyVisualsParameterGroupName, Order = 4)]
		public ARC_UnizonesAlgo_EnhancedBrush TestedResistanceBrush
		{
			get => zoneBrushes[-1][ARC_UnizonesAlgo_UnizoneFreshness.Tested];
			set => zoneBrushes[-1][ARC_UnizonesAlgo_UnizoneFreshness.Tested] = value;
		}
		
		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Broken Resistance Color", GroupName = StrategyVisualsParameterGroupName, Order = 5)]
		public ARC_UnizonesAlgo_EnhancedBrush BrokenResistanceBrush
		{
			get => zoneBrushes[-1][ARC_UnizonesAlgo_UnizoneFreshness.Broken];
			set => zoneBrushes[-1][ARC_UnizonesAlgo_UnizoneFreshness.Broken] = value;
		}

		[Browsable(false)]
		public string SupportResistanceBrushesSerializable
		{
			get =>
				zoneBrushes.ToString('*', 
					dir => dir.ToString(), 
					zoneDict => zoneDict.ToString('&', fresh => fresh.ToString(), brush => brush.ToString()));
			set =>
				zoneBrushes = ARC_UnizonesAlgo_DefaultingDictionary.ARC_UnizonesAlgo_FromString(value, '*', 
					int.Parse, 
					freshDict => ARC_UnizonesAlgo_DefaultingDictionary.ARC_UnizonesAlgo_FromString(freshDict, '&', 
						fresh => (ARC_UnizonesAlgo_UnizoneFreshness) Enum.Parse(typeof(ARC_UnizonesAlgo_UnizoneFreshness), fresh), 
						brush => (ARC_UnizonesAlgo_EnhancedBrush) brush));
		}

		[Display(Name = "Fresh Outline Color", GroupName = StrategyVisualsParameterGroupName, Order = 6)]
		public Stroke FreshOutlineBrush
		{
			get => outlineBrushes[ARC_UnizonesAlgo_UnizoneFreshness.Fresh];
			set => outlineBrushes[ARC_UnizonesAlgo_UnizoneFreshness.Fresh] = value;
		}
		
		[Display(Name = "Tested Outline Color", GroupName = StrategyVisualsParameterGroupName, Order = 7)]
		public Stroke TestedOutlineBrush
		{
			get => outlineBrushes[ARC_UnizonesAlgo_UnizoneFreshness.Tested];
			set => outlineBrushes[ARC_UnizonesAlgo_UnizoneFreshness.Tested] = value;
		}
		
		[Display(Name = "Broken Outline Color", GroupName = StrategyVisualsParameterGroupName, Order = 8)]
		public Stroke BrokenOutlineBrush
		{
			get => outlineBrushes[ARC_UnizonesAlgo_UnizoneFreshness.Broken];
			set => outlineBrushes[ARC_UnizonesAlgo_UnizoneFreshness.Broken] = value;
		}

		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Basing Bar Up Color", GroupName = StrategyVisualsParameterGroupName, Order = 9)]
		public ARC_UnizonesAlgo_EnhancedBrush BasingBarUpBrush { get; set; }
		
		[Browsable(false)]
		public string BasingBarUpBrushSerializable
		{
			get => BasingBarUpBrush;
			set => BasingBarUpBrush = value;
		}
		
		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Basing Bar Down Color", GroupName = StrategyVisualsParameterGroupName, Order = 10)]
		public ARC_UnizonesAlgo_EnhancedBrush BasingBarDownBrush { get; set; }
		
		[Browsable(false)]
		public string BasingBarDownBrushSerializable
		{
			get => BasingBarDownBrush;
			set => BasingBarDownBrush = value;
		}
		
		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Thrust Bar Up Color", GroupName = StrategyVisualsParameterGroupName, Order = 11)]
		public ARC_UnizonesAlgo_EnhancedBrush ThrustBarUpBrush { get; set; }
		
		[Browsable(false)]
		public string ThrustBarUpBrushSerializable
		{
			get => ThrustBarUpBrush;
			set => ThrustBarUpBrush = value;
		}
		
		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_UnizonesAlgo_EnhancedBrushPicker")]
		[Display(Name = "Thrust Bar Down Color", GroupName = StrategyVisualsParameterGroupName, Order = 12)]
		public ARC_UnizonesAlgo_EnhancedBrush ThrustBarDownBrush { get; set; }
		
		[Browsable(false)]
		public string ThrustBarDownBrushSerializable
		{
			get => ThrustBarDownBrush;
			set => ThrustBarDownBrush = value;
		}
		#endregion
	}
}