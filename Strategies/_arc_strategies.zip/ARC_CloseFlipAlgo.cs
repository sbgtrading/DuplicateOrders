﻿using NinjaTrader.Cbi;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.Linq;
using NinjaTrader.Gui;
using System.Windows.Media;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_CloseFlipAlgo : ARC_CloseFlipAlgo_ARCStrategyBase
	{
		public override string ProductVersion => "v1.0.0 (8/21/2024)";
		public override string ProductInfusionSoftTag => "39571";
		public override bool HasStrategyBasedStops => true;
		protected override bool AllowIntrabarEntries => EntryType == ARC_CloseFlipAlgo_BarCloseOrIntrabar.Intrabar;

		private EMA ema;
		private int signalDir;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_CloseFlipAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "Close Flip Algo";

				EmaPeriod = 20;
				EntryType = ARC_CloseFlipAlgo_BarCloseOrIntrabar.Intrabar;
				EntryOffset = 0;
				RequireEma = true;
				AllowDojis = true;

				StopLossOffsetType = ARC_CloseFlipAlgo_TickOrPercentPatternHLRange.Ticks;
				StopLossOffset = 0;

				EmaStroke = new Stroke(Brushes.AliceBlue, 3);
			}
			else if (State == State.Configure)
			{
				signalDir = 0;
			}
			else if (State == State.DataLoaded)
			{
				AddChartIndicator(ema = EMA(EmaPeriod));
				ema.Name = "";
				ema.Plots[0].DashStyleHelper = EmaStroke.DashStyleHelper;
				ema.Plots[0].Brush = EmaStroke.Brush;
				ema.Plots[0].Width = EmaStroke.Width;
			}
		}

		protected override void OnEntryExecution(Execution execution, double price, int quantity)
		{
			base.OnEntryExecution(execution, price, quantity);
			signalDir = 0;
		}

		private void ScanEntries()
		{
			if (CurrentBars.Any(cb => cb <= 1))
				return;

			var dir = signalDir;
			if (dir == 0)
				return;

			if (RequireEma && Closes[0][0].ApproxCompare(ema[0]) != dir)
				return;

			if (EntryType == ARC_CloseFlipAlgo_BarCloseOrIntrabar.Intrabar && !Close.ARC_CloseFlipAlgo_Crossed((dir == 1 ? Highs : Lows)[0][0] + dir * EntryOffset * TickSize))
				return;

			var sl = (double?)null;
			if (EnableAlgoDefinedStopLosses)
			{
				var (min, max) = GetRangeMinMax(1);
				sl = (dir == 1 ? min : max) - dir * (StopLossOffsetType == ARC_CloseFlipAlgo_TickOrPercentPatternHLRange.Ticks ? TickSize : (max - min) / 100) * StopLossOffset;
				if (!TradeAllowedWithStop(dir, Close[0], sl.Value))
					return;
			}

			if (!TradeAllowed(dir))
				return;

			QueueEntry(dir, 1, stopLossPrice: sl);
		}

		protected override void OnTickBar()
		{
			if (EntryType == ARC_CloseFlipAlgo_BarCloseOrIntrabar.Intrabar && lastEntryBar < CurrentBars[0])
				ScanEntries();
		}

		protected override void OnPrimaryBar()
		{
			if (CurrentBar == 0)
				return;

			signalDir = -Close[1].ApproxCompare(Open[1]);
			if (signalDir != 0) 
			{
				var curBarDir = Close[0].ApproxCompare(Open[0]);
				if (curBarDir == 0 && AllowDojis)
					curBarDir = Close[0].ApproxCompare((High[0] + Low[0]) / 2);

				if (signalDir != curBarDir)
					signalDir = 0;
			}
			
			if (EntryType == ARC_CloseFlipAlgo_BarCloseOrIntrabar.BarClose)
				ScanEntries();
		}

		#region Parameters
		#region General
		[NinjaScriptProperty]
		[Display(Name = "Require EMA", GroupName = StrategyParameterGroupName, Order = 0)]
		public bool RequireEma { get; set; }
		
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "EMA Period", GroupName = StrategyParameterGroupName, Order = 1)]
		public int EmaPeriod { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Entry Type", GroupName = StrategyParameterGroupName, Order = 2)]
		public ARC_CloseFlipAlgo_BarCloseOrIntrabar EntryType { get; set; }

		[NinjaScriptProperty, Range(0, int.MaxValue)]
		[ARC_CloseFlipAlgo_HideUnless(nameof(EntryType), ARC_CloseFlipAlgo_PropComparisonType.EQ, ARC_CloseFlipAlgo_BarCloseOrIntrabar.Intrabar)]
		[Display(Name = "Entry Offset (Ticks)", GroupName = StrategyParameterGroupName, Order = 3)]
		public int EntryOffset { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Allow Dojis", GroupName = StrategyParameterGroupName, Order = 4)]
		public bool AllowDojis { get; set; }
		#endregion

		#region Stop Loss
		[NinjaScriptProperty]
		[ARC_CloseFlipAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_CloseFlipAlgo_PropComparisonType.EQ, ARC_CloseFlipAlgo_BoolEnum.True)]
		[Display(Name = "Stop Loss Type", GroupName = StopLossGroupName, Order = 1)]
		public ARC_CloseFlipAlgo_TickOrPercentPatternHLRange StopLossOffsetType { get; set; }

		[NinjaScriptProperty, Range(double.MinValue, double.MaxValue)]
		[ARC_CloseFlipAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_CloseFlipAlgo_PropComparisonType.EQ, ARC_CloseFlipAlgo_BoolEnum.True)]
		[ARC_CloseFlipAlgo_Rename("Stop Loss Offset (Ticks)", nameof(StopLossOffsetType), ARC_CloseFlipAlgo_PropComparisonType.EQ, ARC_CloseFlipAlgo_TickOrPercentPatternHLRange.Ticks)]
		[ARC_CloseFlipAlgo_Rename("Stop Loss Offset (% of HL Range)", nameof(StopLossOffsetType), ARC_CloseFlipAlgo_PropComparisonType.EQ, ARC_CloseFlipAlgo_TickOrPercentPatternHLRange.PercentOfPatternHLRange)]
		[Display(Name = "Stop Loss Offset", GroupName = StopLossGroupName, Order = 2)]
		public double StopLossOffset { get; set; }
		#endregion

		[Display(Name = "EMA Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 0)]
		public Stroke EmaStroke { get; set; }
		#endregion
	}
}
