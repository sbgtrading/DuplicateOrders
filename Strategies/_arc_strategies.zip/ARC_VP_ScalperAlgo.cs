using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.Indicators.ARC.Supporting;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using SharpDX;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_VP_ScalperAlgo : ARC_VP_ScalperAlgo_ARCStrategyBase
	{
		public override string ProductVersion => "v1.0.3 (2/25/2025)";
		public override string ProductInfusionSoftTag => "42161";
		public override bool HasStrategyBasedStops => true;

		private readonly ARC_VP_ScalperAlgo_DefaultingDictionary<int, List<Tuple<int, int>>> signals = new(_ => new List<Tuple<int, int>>());
		private EMA ema;
		private ARC_VP_ScalperAlgo_ExternalStrategyPlot strategyPlot;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_VP_ScalperAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "VP Scalper Algo";

				_enabledPatterns.Clear();
				FlipVolumeBar1Multiplier = 1;
				PullbackAccelerationBar3Multiplier = 1;
				VVolumeBar4Multiplier = 1;
				RequireEma = true;
				EmaPeriod = 20;
				EmaStroke = new Stroke(Brushes.AliceBlue, 3);

				ShortSignalStroke = new Stroke(Brushes.Red.ARC_VP_ScalperAlgo_WithAlpha(0.5f), 3);
				ShortSignalFill = Brushes.Red.ARC_VP_ScalperAlgo_WithAlpha(0.3f);
				LongSignalStroke = new Stroke(Brushes.Lime.ARC_VP_ScalperAlgo_WithAlpha(0.5f), 3);
				LongSignalFill = Brushes.Lime.ARC_VP_ScalperAlgo_WithAlpha(0.3f);
				UpVolumeStroke = new Stroke(Brushes.MediumBlue, DashStyleHelper.Solid, 1);
				DownVolumeStroke = new Stroke(Brushes.Maroon, DashStyleHelper.Solid, 1);
			}
			else if (State == State.Configure)
			{
				signals.Clear();
			}
			else if (State == State.DataLoaded)
			{
				if (ShowUpDownVolume)
				{
					AddChartIndicator(strategyPlot = ARC_VP_ScalperAlgo_ExternalStrategyPlot(2, Guid.NewGuid()));
					strategyPlot.Name = NinjaTrader.Custom.Resource.NinjaScriptIndicatorNameVolumeUpDown;
					for (var i = 0; i < strategyPlot.Plots.Length; i++)
					{
						strategyPlot.Plots[i].Name = i == 0 ? "Up Volume" : "Down Volume";
						var stroke = i == 0 ? UpVolumeStroke : DownVolumeStroke;
						strategyPlot.Plots[i].Brush = stroke.Brush;
						strategyPlot.Plots[i].PlotStyle = PlotStyle.Bar;
						strategyPlot.Plots[i].DashStyleHelper = stroke.DashStyleHelper;
						strategyPlot.Plots[i].AutoWidth = true;
					}
				}

				AddChartIndicator(ema = EMA(EmaPeriod));
				ema.Name = "";
				ema.Plots[0].DashStyleHelper = EmaStroke.DashStyleHelper;
				ema.Plots[0].Brush = EmaStroke.Brush;
				ema.Plots[0].Width = EmaStroke.Width;
			}

			SetZOrder(0);
		}

		private int GetBarDir(int offset)
		{
			var dir = Close[offset].ApproxCompare(Open[offset]);
			if (dir == 0 && AllowDojis)
				dir = Open[offset].ApproxCompare((High[offset] + Low[offset]) / 2);
			return dir;
		}

		protected override void OnPrimaryBar()
		{
			if (CurrentBars[0] <= 5)
				return;

			if (ShowUpDownVolume)
			{
				if (Close[0] >= Open[0])
				{
					strategyPlot.Values[0][0] = Volume[0];
					strategyPlot.Values[1].Reset();
				}
				else
				{
					strategyPlot.Values[0].Reset();
					strategyPlot.Values[1][0] = Volume[0];
				}
			}

			var dir = GetBarDir(0);
			if (dir == 0)
				return;

			var patternLength = 0;
			foreach (var pattern in (ARC_VP_ScalperAlgo_VolTraderPattern[]) Enum.GetValues(typeof(ARC_VP_ScalperAlgo_VolTraderPattern)))
			{
				if (!_enabledPatterns[pattern])
					continue;

				switch (pattern)
				{
				case ARC_VP_ScalperAlgo_VolTraderPattern.FlipVolume when CurrentBar >= 1:
					if (GetBarDir(1) != -dir || Volume[0] <= Volume[1] * FlipVolumeBar1Multiplier)
						continue;

					break;
				case ARC_VP_ScalperAlgo_VolTraderPattern.PullbackAcceleration when CurrentBar >= 2:
					if (GetBarDir(1) != dir || GetBarDir(2) != -dir)
						continue;

					if (EnablePullbackAccelerationB2GtB1Vol && Volume[1] <= Volume[2])
						continue;

					if (Volume[0] <= Volume[1] * PullbackAccelerationBar3Multiplier)
						continue;

					if (EnablePullbackAccelerationB3GtB1Vol && Volume[0] <= Volume[2])
						continue;

					break;
				case ARC_VP_ScalperAlgo_VolTraderPattern.VVolume when CurrentBar >= 3:
					if (GetBarDir(1) != dir || GetBarDir(2) != -dir || GetBarDir(3) != -dir)
						continue;

					if (EnableVVolumeB2LtB1Vol && Volume[2] >= Volume[3])
						continue;

					if (Volume[0] <= Volume[1] * VVolumeBar4Multiplier)
						continue;

					if (EnableVVolumeB3GtB2Vol && Volume[1] <= Volume[2])
						continue;

					if (EnableVVolumeB3B4GtB1B2Vol && Volume[0] <= Volume[2])
						continue;

					break;
				}

				patternLength = pattern switch
				{
					ARC_VP_ScalperAlgo_VolTraderPattern.FlipVolume => 2,
					ARC_VP_ScalperAlgo_VolTraderPattern.PullbackAcceleration => 3,
					ARC_VP_ScalperAlgo_VolTraderPattern.VVolume => 4
				};

				signals[dir].Add(new Tuple<int, int>(CurrentBar - patternLength, CurrentBar));
				break;
			}

			if (RequireEma && Close[0].ApproxCompare(ema[0]) != dir)
				return;

			if (!TradeAllowed(dir))
				return;

			if (patternLength == 0)
				return;

			var sl = (double?)null;
			if (EnableAlgoDefinedStopLosses)
			{
				var (min, max) = GetRangeMinMax(patternLength - 1);
				var offsetUnit = StopLossOffsetType == ARC_VP_ScalperAlgo_VolTraderStopLossOffsetType.PercentOfHighLowDistance ? (max - min) / 100 : TickSize;
				sl = (dir == 1 ? min : max) - dir * StopLossOffset * offsetUnit;
				if (!TradeAllowedWithStop(dir, Close[0], sl.Value))
					return;
			}

			QueueEntry(dir, stopLossPrice: sl);
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);

			LongSignalStroke.RenderTarget = RenderTarget;
			ShortSignalStroke.RenderTarget = RenderTarget; 

			foreach (var dir in new [] { -1, 1 })
			{
				var stroke = dir == 1 ? LongSignalStroke : ShortSignalStroke;
				var fillBrush = dir == 1 ? LongSignalFill : ShortSignalFill;
				using var fill = fillBrush.OpaqueBrush.ARC_VP_ScalperAlgo_WithAlpha(fillBrush.Opacity).ToDxBrush(RenderTarget);
				foreach (var signal in signals[dir])
				{
					var leftBar = signal.Item1 + 1;
					var rightBar = signal.Item2;
					if (leftBar > ChartBars.ToIndex || rightBar < ChartBars.FromIndex)
						continue;

					var margin = chartControl.Properties.BarDistance - chartControl.GetBarPaintWidth(ChartBars);
					var minPrice = Enumerable.Range(leftBar, rightBar - leftBar + 1).Min(Lows[0].GetValueAt) - TickSize;
					var maxPrice = Enumerable.Range(leftBar, rightBar - leftBar + 1).Max(Highs[0].GetValueAt) + TickSize;
					var rectf = new RectangleF
					{
						Left = chartControl.GetXByBarIndex(ChartBars, leftBar) - margin,
						Right = chartControl.GetXByBarIndex(ChartBars, rightBar) + margin,
						Top = chartScale.GetYByValue(maxPrice),
						Bottom = chartScale.GetYByValue(minPrice),
					};

					RenderTarget.FillRectangle(rectf, fill);
					RenderTarget.DrawRectangle(rectf, stroke.BrushDX, stroke.Width, stroke.StrokeStyle);
				}
			}
		}

		#region Parameters
		private readonly ARC_VP_ScalperAlgo_DefaultingDictionary<ARC_VP_ScalperAlgo_VolTraderPattern, bool> _enabledPatterns = new(true);

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_VP_ScalperAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_VP_ScalperAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Enable Flip Volume Pattern", Order = 0, GroupName = StrategyParameterGroupName)]
		public ARC_VP_ScalperAlgo_BoolEnum EnableFlipVolumeEnum 
		{ 
			get => _enabledPatterns[ARC_VP_ScalperAlgo_VolTraderPattern.FlipVolume] ? ARC_VP_ScalperAlgo_BoolEnum.True : ARC_VP_ScalperAlgo_BoolEnum.False; 
			set => _enabledPatterns[ARC_VP_ScalperAlgo_VolTraderPattern.FlipVolume] = value == ARC_VP_ScalperAlgo_BoolEnum.True;
		}

		[NinjaScriptProperty, Range(0.0001, int.MaxValue)]
		[ARC_VP_ScalperAlgo_HideUnless(nameof(EnableFlipVolumeEnum), ARC_VP_ScalperAlgo_PropComparisonType.EQ, ARC_VP_ScalperAlgo_BoolEnum.True)]
		[Display(Name = "Flip Pattern - Bar 1 Volume Mult.", GroupName = StrategyParameterGroupName, Order = 1)]
		public double FlipVolumeBar1Multiplier { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_VP_ScalperAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_VP_ScalperAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Enable Pullback Acceleration Pattern", Order = 100, GroupName = StrategyParameterGroupName)]
		public ARC_VP_ScalperAlgo_BoolEnum EnablePullbackAccelerationEnum 
		{ 
			get => _enabledPatterns[ARC_VP_ScalperAlgo_VolTraderPattern.PullbackAcceleration] ? ARC_VP_ScalperAlgo_BoolEnum.True : ARC_VP_ScalperAlgo_BoolEnum.False; 
			set => _enabledPatterns[ARC_VP_ScalperAlgo_VolTraderPattern.PullbackAcceleration] = value == ARC_VP_ScalperAlgo_BoolEnum.True;
		}

		[NinjaScriptProperty]
		[ARC_VP_ScalperAlgo_HideUnless(nameof(EnablePullbackAccelerationEnum), ARC_VP_ScalperAlgo_PropComparisonType.EQ, ARC_VP_ScalperAlgo_BoolEnum.True)]
		[Display(Name = "Pullback Acceleration - Require Bar 2 Volume > Bar 1 Volume", GroupName = StrategyParameterGroupName, Order = 101)]
		public bool EnablePullbackAccelerationB2GtB1Vol { get; set; }

		[NinjaScriptProperty, Range(0.0001, int.MaxValue)]
		[ARC_VP_ScalperAlgo_HideUnless(nameof(EnablePullbackAccelerationEnum), ARC_VP_ScalperAlgo_PropComparisonType.EQ, ARC_VP_ScalperAlgo_BoolEnum.True)]
		[Display(Name = "Pullback Acceleration - Bar 3 Vs 2 Volume Mult.", GroupName = StrategyParameterGroupName, Order = 102)]
		public double PullbackAccelerationBar3Multiplier { get; set; }

		[NinjaScriptProperty]
		[ARC_VP_ScalperAlgo_HideUnless(nameof(EnablePullbackAccelerationEnum), ARC_VP_ScalperAlgo_PropComparisonType.EQ, ARC_VP_ScalperAlgo_BoolEnum.True)]
		[Display(Name = "Pullback Acceleration - Require Bar 3 Volume > Bar 1 Volume", GroupName = StrategyParameterGroupName, Order = 103)]
		public bool EnablePullbackAccelerationB3GtB1Vol { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_VP_ScalperAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_VP_ScalperAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Enable V Volume Pattern", Order = 200, GroupName = StrategyParameterGroupName)]
		public ARC_VP_ScalperAlgo_BoolEnum EnableVVolumeEnum 
		{ 
			get => _enabledPatterns[ARC_VP_ScalperAlgo_VolTraderPattern.VVolume] ? ARC_VP_ScalperAlgo_BoolEnum.True : ARC_VP_ScalperAlgo_BoolEnum.False; 
			set => _enabledPatterns[ARC_VP_ScalperAlgo_VolTraderPattern.VVolume] = value == ARC_VP_ScalperAlgo_BoolEnum.True;
		}

		[NinjaScriptProperty]
		[ARC_VP_ScalperAlgo_HideUnless(nameof(EnableVVolumeEnum), ARC_VP_ScalperAlgo_PropComparisonType.EQ, ARC_VP_ScalperAlgo_BoolEnum.True)]
		[Display(Name = "V Volume - Require Bar 2 Volume < Bar 1 Volume", GroupName = StrategyParameterGroupName, Order = 201)]
		public bool EnableVVolumeB2LtB1Vol { get; set; }

		[NinjaScriptProperty]
		[ARC_VP_ScalperAlgo_HideUnless(nameof(EnableVVolumeEnum), ARC_VP_ScalperAlgo_PropComparisonType.EQ, ARC_VP_ScalperAlgo_BoolEnum.True)]
		[Display(Name = "V Volume - Require Bar 3 Volume > Bar 2 Volume", GroupName = StrategyParameterGroupName, Order = 202)]
		public bool EnableVVolumeB3GtB2Vol { get; set; }

		[NinjaScriptProperty, Range(0.0001, int.MaxValue)]
		[ARC_VP_ScalperAlgo_HideUnless(nameof(EnableVVolumeEnum), ARC_VP_ScalperAlgo_PropComparisonType.EQ, ARC_VP_ScalperAlgo_BoolEnum.True)]
		[Display(Name = "V Volume - Bar 4 Vs 3 Volume Mult.", GroupName = StrategyParameterGroupName, Order = 203)]
		public double VVolumeBar4Multiplier { get; set; }

		[NinjaScriptProperty]
		[ARC_VP_ScalperAlgo_HideUnless(nameof(EnableVVolumeEnum), ARC_VP_ScalperAlgo_PropComparisonType.EQ, ARC_VP_ScalperAlgo_BoolEnum.True)]
		[Display(Name = "V Volume - Require Bar 3 + 4 Volume > Bar 1 + 2 Volume", GroupName = StrategyParameterGroupName, Order = 204)]
		public bool EnableVVolumeB3B4GtB1B2Vol { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Allow Dojis", GroupName = StrategyParameterGroupName, Order = 300)]
		public bool AllowDojis { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Require EMA", GroupName = StrategyParameterGroupName, Order = 300)]
		public bool RequireEma { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "EMA Period", GroupName = StrategyParameterGroupName, Order = 301)]
		public int EmaPeriod { get; set; }

		#region Stop Loss
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_VP_ScalperAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_VP_ScalperAlgo_PropComparisonType.EQ, ARC_VP_ScalperAlgo_BoolEnum.True)]
		[Display(Name = "Stop Loss Offset Type", GroupName = StopLossGroupName, Order = 1)]
		public ARC_VP_ScalperAlgo_VolTraderStopLossOffsetType StopLossOffsetType { get; set; }
		
		[NinjaScriptProperty, Range(int.MinValue, int.MaxValue)]
		[ARC_VP_ScalperAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_VP_ScalperAlgo_PropComparisonType.EQ, ARC_VP_ScalperAlgo_BoolEnum.True)]
		[ARC_VP_ScalperAlgo_Rename("Stop Loss Offset (Ticks)", nameof(StopLossOffsetType), ARC_VP_ScalperAlgo_PropComparisonType.EQ, ARC_VP_ScalperAlgo_VolTraderStopLossOffsetType.Ticks)]
		[ARC_VP_ScalperAlgo_Rename("Stop Loss Offset (% Basing Bar Range)", nameof(StopLossOffsetType), ARC_VP_ScalperAlgo_PropComparisonType.EQ, ARC_VP_ScalperAlgo_VolTraderStopLossOffsetType.PercentOfHighLowDistance)]
		[Display(Name = "Stop Loss Offset", GroupName = StopLossGroupName, Order = 2)]
		public int StopLossOffset { get; set; }
		#endregion

		[Display(Name = "EMA Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 0)]
		public Stroke EmaStroke { get; set; }

		[Display(Name = "Long Signal Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 1)]
		public Stroke LongSignalStroke { get; set; }

		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_VP_ScalperAlgo_EnhancedBrushPicker")]
		[Display(Name = "Long Signal Fill", GroupName = StrategyVisualsParameterGroupName, Order = 2)]
		public ARC_VP_ScalperAlgo_EnhancedBrush LongSignalFill { get; set; }

		[Browsable(false)]
		public string LongSignalFillSerializable { get => LongSignalFill; set => LongSignalFill = value; }

		[Display(Name = "Short Signal Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 3)]
		public Stroke ShortSignalStroke { get; set; }

		[XmlIgnore]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_VP_ScalperAlgo_EnhancedBrushPicker")]
		[Display(Name = "Short Signal Fill", GroupName = StrategyVisualsParameterGroupName, Order = 4)]
		public ARC_VP_ScalperAlgo_EnhancedBrush ShortSignalFill { get; set; }

		[Browsable(false)]
		public string ShortSignalFillSerializable { get => ShortSignalFill; set => ShortSignalFill = value; }

		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Show Up/Down Volume", GroupName = StrategyVisualsParameterGroupName, Order = 5)]
		public bool ShowUpDownVolume { get; set; }

		[ARC_VP_ScalperAlgo_HideUnless(nameof(ShowUpDownVolume), ARC_VP_ScalperAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Up Volume", GroupName = StrategyVisualsParameterGroupName, Order = 6)]
		public Stroke UpVolumeStroke { get; set; }

		[ARC_VP_ScalperAlgo_HideUnless(nameof(ShowUpDownVolume), ARC_VP_ScalperAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Down Volume Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 7)]
		public Stroke DownVolumeStroke { get; set; }
		#endregion
	}

	public enum ARC_VP_ScalperAlgo_VolTraderPattern
	{
		FlipVolume,
		PullbackAcceleration,
		VVolume
	}

	public enum ARC_VP_ScalperAlgo_VolTraderStopLossOffsetType
	{
		Ticks,
		PercentOfHighLowDistance
	}
}