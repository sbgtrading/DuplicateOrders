using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Media;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.Indicators.ARC;
using NinjaTrader.NinjaScript.Indicators.ARC.Supporting;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using SharpDX;
using SharpDX.Direct2D1;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_DivAlgo : ARC_DivAlgo_ARCStrategyBase
	{
		public override string ProductVersion => "v1.0.1 (1/19/2025)";
		public override string ProductInfusionSoftTag => "41629";
		public override bool HasStrategyBasedStops => true;

		private class Divergence
		{
			public ARC_DivAlgo_ZigZagPoint[] ZZPivots { get; set; }
			public ARC_DivAlgo_ZigZagPoint[] OscPivots { get; set; }
			public DivergenceType Type => OscPivots[1].Price.ApproxCompare(OscPivots[0].Price) == Dir ? DivergenceType.Regular : DivergenceType.Hidden;
			public int Dir => -OscPivots[1].Side;
		}

		private ExternalStrategyPlot oscillator;
		private ARC_DivAlgo_ARC_MWPatternFinderZigZag zigZag;
		private ARC_DivAlgo_ARC_MWPatternFinderZigZag oscZigZag;
		private Func<double> getSignal;
		private EMA ema;
		private readonly List<Divergence> divergences = new List<Divergence>();
		public readonly HashSet<int> enteredDivergenceAnchorBars = new HashSet<int>();

		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_DivAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "Div Algo";
				MaximumBarsLookBack = MaximumBarsLookBack.Infinite;

				IncludeWicks = true;
				SwingStrength = 3;
				EmaPeriod = 14;

				OverboughtLevel = 70;
				MidlineLevel = 50;
				OversoldLevel = 30;

				RequireP1BeyondObos = true;
				RequireP2BeyondObos = true;

				RSIPeriod = 14;
				RSISmooth = 3;

				MACDFast = 12;
				MACDSlow = 26;
				MACDSmooth = 9;

				MFIPeriod = 14;

				VMLeanBandPeriod = 10;
				VMLeanFast = 12;
				VMLeanSlow = 26;
				VMLeanStdDevNumber = 1;
				VMLeanSwingStrength = 3;
				VMLeanMultiplierMD = 0;
				VMLeanMultiplierDTB = 0;
				VMLeanEnableEmaCrossover = false;
				VMLeanFastEmaPeriod = 14;
				VMLeanSlowEmaPeriod = 30;

				StopLossOffsetType = ARC_DivAlgo_DivAlgoStopLossOffsetType.Tick;
				StopLossOffset = 0;
			}
			else if (State == State.Configure)
			{
				divergences.Clear();
				enteredDivergenceAnchorBars.Clear();
			}
			else if (State == State.DataLoaded)
			{
				AddChartIndicator(zigZag = ARC_DivAlgo_ARC_MWPatternFinderZigZag(SwingStrength, IncludeWicks));
				zigZag.ZigZagStroke = ZigZagStroke;

				AddChartIndicator(oscillator = ExternalStrategyPlot(4, Guid.NewGuid()));
				oscillator.RenderCallback = (target, bars, scale) => RenderLines(target, bars, scale, true);
				oscillator.Name = "Oscillator";
				for (var i = 0; i < 4; i++)
				{
					oscillator.Plots[i].Name = i switch
					{
						0 => "Oscillator",
						1 => "Overbought",
						2 => "Midline",
						3 => "Oversold"
					};
					
					var stroke = i switch
					{
						0 => OscillatorStroke,
						1 => OverboughtStroke,
						2 => MidlineStroke,
						3 => OversoldStroke
					};
					oscillator.Plots[i].DashStyleHelper = stroke.DashStyleHelper;
					oscillator.Plots[i].Brush = stroke.Brush;
					oscillator.Plots[i].Pen = stroke.Pen;
				}

				oscZigZag = ARC_DivAlgo_ARC_MWPatternFinderZigZag(oscillator, SwingStrength, false);
				oscZigZag.IsOverlay = true;

				AddChartIndicator(ema = EMA(EmaPeriod));
				ema.Name = "";
				ema.Plots[0].DashStyleHelper = EmaStroke.DashStyleHelper;
				ema.Plots[0].Brush = EmaStroke.Brush;
				ema.Plots[0].Width = EmaStroke.Width;

				switch (Oscillator)
				{
				case ARC_DivAlgo_DivAlgoOscillator.MACD:
				{
					var indicator = MACD(MACDFast, MACDSlow, MACDSmooth);
					getSignal = () => MacdSignal switch
					{
						ARC_DivAlgo_DivAlgoMacdSignal.MACD => indicator.Default[0] * 100,
						ARC_DivAlgo_DivAlgoMacdSignal.Avg => indicator.Avg[0] * 100,
						ARC_DivAlgo_DivAlgoMacdSignal.Diff => indicator.Diff[0] * 100
					};
					break;
				}
				case ARC_DivAlgo_DivAlgoOscillator.RSI:
				{
					var indicator = RSI(RSIPeriod, RSISmooth);
					getSignal = () => RsiSignal switch
					{
						ARC_DivAlgo_DivAlgoRsiSignal.RSI => indicator.Default[0],
						ARC_DivAlgo_DivAlgoRsiSignal.Avg => indicator.Avg[0]
					};
					break;
				}
				case ARC_DivAlgo_DivAlgoOscillator.MFI:
				{
					var indicator = MFI(MFIPeriod);
					getSignal = () => indicator[0];
					break;
				}
				case ARC_DivAlgo_DivAlgoOscillator.VMLean:
				{
					var indicator = ARC_DivAlgo_VMAlgo(VMLeanOptimizeSpeed, VMLeanBandPeriod, VMLeanFast, VMLeanSlow, VMLeanStdDevNumber, VMSwingStrength, VMLeanMultiplierMD, VMLeanMultiplierDTB, VMLeanEnableEmaCrossover, VMFastEmaPeriod, VMSlowEmaPeriod);
					getSignal = () => VmLeanSignal switch
					{
						ARC_DivAlgo_DivAlgoVmLeanSignal.Histogram => indicator.Histogram[0],
						ARC_DivAlgo_DivAlgoVmLeanSignal.BB => indicator.BBMACD[0]
					};
					break;
				}
				}
			}
		}

		private Divergence GetDivergence(bool confirmed)
		{
			var offset = confirmed ? 1 : 0;
			if (zigZag.SwingPoints.Count < 3 + offset || oscZigZag.SwingPoints.Count < 1)
				return null;

			var div = new Divergence
			{
				ZZPivots = new[] { zigZag.SwingPoints[zigZag.SwingPoints.Count - 3 - offset], zigZag.SwingPoints[zigZag.SwingPoints.Count - 1 - offset] }, 
				OscPivots = new ARC_DivAlgo_ZigZagPoint[2]
			};

			for (var i = 0; i <= 1; i++)
			{
				var closestDist = int.MaxValue;
				foreach (var p in oscZigZag.SwingPoints.AsEnumerable().Reverse().Where(p => p.Side == div.ZZPivots[0].Side))
				{
					var dist = Math.Abs(p.Bar - div.ZZPivots[i].Bar);
					if (dist > closestDist)
						continue;

					if (!div.OscPivots.Contains(p))
						div.OscPivots[i] = p;
					closestDist = dist;
				}

				if (div.OscPivots[i] == null)
					return null;
			}

			var maxRange = Math.Max(div.ZZPivots[1].Bar - div.ZZPivots[0].Bar, div.OscPivots[1].Bar - div.OscPivots[0].Bar); 
			var overlapBars = Math.Max(0, Math.Min(div.ZZPivots[1].Bar, div.OscPivots[1].Bar) - Math.Max(div.ZZPivots[0].Bar, div.OscPivots[0].Bar));
			return overlapBars < Math.Ceiling(maxRange / 2.0) ? null : div;
		}

		protected override void OnPrimaryBar()
		{
			oscillator.Value[0] = getSignal();
			oscillator.Values[1][0] = OverboughtLevel;
			oscillator.Values[2][0] = MidlineLevel;
			oscillator.Values[3][0] = OversoldLevel;
			if (CurrentBar == 0)
				return;
			
			foreach (var confirmed in new[] { true, false })
			{
				if (confirmed ? !IncludeConfirmedDivergence : !IncludePotentialDivergence)
					continue;

				var divergence = GetDivergence(confirmed);
				if (divergence == null)
					continue;

				if (!IsValid(divergence) && !enteredDivergenceAnchorBars.Contains(divergence.ZZPivots[0].Bar))
				{
					divergences.RemoveAll(d => d.ZZPivots[0].Bar == divergence.ZZPivots[0].Bar);
					continue;
				}

				if (divergences.All(d => d.ZZPivots[0].Bar != divergence.ZZPivots[0].Bar))
					divergences.Add(divergence);

				var dir = divergence.Dir;
				if (RequireBarDirection && Close[0].ApproxCompare(Open[0]) != dir)
					continue;

				if (RequireEma && Closes[0][0].ApproxCompare(ema[0]) != dir)
					continue;

				if (enteredDivergenceAnchorBars.Contains(divergence.ZZPivots[0].Bar))
					continue;

				var midline = (OverboughtLevel + OversoldLevel) / 2;
				if (RequireMidlineBias && divergence.OscPivots.Any(p => p.Price.CompareTo(midline) != -dir))
					continue;

				var obosLevel = dir == 1 ? OversoldLevel : OverboughtLevel;
				if (divergence.OscPivots.Where((p, i) => i == 0 ? RequireP1BeyondObos : RequireP2BeyondObos).Any(p => p.Price.CompareTo(obosLevel) != -dir))
					continue;

				if (!divergenceToggles[divergence.Type])
					continue;

				var sl = (double?)null;
				if (EnableAlgoDefinedStopLosses)
				{
					var offsetUnit = StopLossOffsetType == ARC_DivAlgo_DivAlgoStopLossOffsetType.Tick ? TickSize : Math.Abs(divergence.ZZPivots[1].Price - Close[0]) / 100;
					sl = divergence.ZZPivots[1].Price - dir * offsetUnit * StopLossOffset;
					if (!TradeAllowedWithStop(dir, Close[0], sl.Value))
						continue;
				}

				enteredDivergenceAnchorBars.Add(divergence.ZZPivots[0].Bar);

				divergences.RemoveAll(div => div.ZZPivots[0].Bar == divergence.ZZPivots[0].Bar);
				divergence.ZZPivots = divergence.ZZPivots
					.Select(pt => new ARC_DivAlgo_ZigZagPoint(pt))
					.ToArray();
				divergence.OscPivots = divergence.OscPivots
					.Select(pt => new ARC_DivAlgo_ZigZagPoint(pt))
					.ToArray();
				divergences.Add(divergence);
				if (!TradeAllowed(dir))
					continue;

				QueueEntry(dir, stopLossPrice: sl);
				break;
			}
		}

		private bool IsValid(Divergence div)
		{
			if (!IncludeDtDb && (int) (Math.Abs(div.ZZPivots[0].Price - div.ZZPivots[1].Price) / TickSize) <= DtDbThresh)
				return false;

			return div.ZZPivots[1].Price.ApproxCompare(div.ZZPivots[0].Price) != div.OscPivots[1].Price.ApproxCompare(div.OscPivots[0].Price);
		}

		private void RenderLines(RenderTarget target, ChartBars bars, ChartScale scale, bool paintOscillator)
		{
			var aliasMode = target.AntialiasMode;
			target.AntialiasMode = AntialiasMode.PerPrimitive;
			foreach (var divergence in divergences)
			{
				var line = paintOscillator ? divergence.OscPivots : divergence.ZZPivots;
				if (line[0].Bar > bars.ToIndex || line[1].Bar < bars.FromIndex)
					continue;

				var stroke = (Stroke) divergenceStrokes[divergence.Dir][divergence.Type].Clone();
				stroke.RenderTarget = RenderTarget;
				var pts = line
					.Select(pt => new Vector2(ChartControl.GetXByBarIndex(bars, pt.Bar), scale.GetYByValue(pt.Price)))
					.ToArray();
				target.DrawLine(pts[0], pts[1], stroke.BrushDX, 3, stroke.StrokeStyle);
			}

			target.AntialiasMode = aliasMode;
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			RenderLines(RenderTarget, ChartBars, chartScale, false);
		}

		#region Parameters
		#region General
		[NinjaScriptProperty]
		[Display(Name = "Require Bar Direction", GroupName = StrategyParameterGroupName, Order = 0)]
		public bool RequireBarDirection { get; set; }
		
		[NinjaScriptProperty]
		[Display(Name = "Require EMA", GroupName = StrategyParameterGroupName, Order = 1)]
		public bool RequireEma { get; set; }
		
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(Name = "EMA Period", GroupName = StrategyParameterGroupName, Order = 2)]
		public int EmaPeriod { get; set; }

		private enum DivergenceType
		{
			Hidden,
			Regular
		}

		private readonly ARC_DivAlgo_DefaultingDictionary<DivergenceType, bool> divergenceToggles = new ARC_DivAlgo_DefaultingDictionary<DivergenceType, bool>(true);

		[NinjaScriptProperty]
		[Display(Order = 3, Name = "Include Hidden Divergence", GroupName = StrategyParameterGroupName)]
		public bool IncludeHiddenDivergence { get => divergenceToggles[DivergenceType.Hidden]; set => divergenceToggles[DivergenceType.Hidden] = value; }
		
		[NinjaScriptProperty]
		[Display(Order = 4, Name = "Include Regular Divergence", GroupName = StrategyParameterGroupName)]
		public bool IncludeRegularDivergence { get => divergenceToggles[DivergenceType.Regular]; set => divergenceToggles[DivergenceType.Regular] = value; }

		[NinjaScriptProperty]
		[Display(Order = 5, Name = "Include Potential Divergence", GroupName = StrategyParameterGroupName)]
		public bool IncludePotentialDivergence { get; set; }

		[NinjaScriptProperty]
		[Display(Order = 6, Name = "Include Confirmed Divergence", GroupName = StrategyParameterGroupName)]
		public bool IncludeConfirmedDivergence { get; set; }

		[NinjaScriptProperty]
		[Range(int.MinValue, int.MaxValue)]
		[Display(Order = 7, Name = "Overbought Level", GroupName = StrategyParameterGroupName)]
		public double OverboughtLevel { get; set; }
		
		[NinjaScriptProperty]
		[Range(int.MinValue, int.MaxValue)]
		[Display(Order = 8, Name = "Midline Level", GroupName = StrategyParameterGroupName)]
		public double MidlineLevel { get; set; }
		
		[NinjaScriptProperty]
		[Range(int.MinValue, int.MaxValue)]
		[Display(Order = 9, Name = "Oversold Level", GroupName = StrategyParameterGroupName)]
		public double OversoldLevel { get; set; }

		[NinjaScriptProperty]
		[Display(Order = 10, Name = "Require Left Pivot Beyond OBOS", GroupName = StrategyParameterGroupName)]
		public bool RequireP1BeyondObos { get; set; }

		[NinjaScriptProperty]
		[Display(Order = 11, Name = "Require Right Pivot Beyond OBOS", GroupName = StrategyParameterGroupName)]
		public bool RequireP2BeyondObos { get; set; }
		
		[NinjaScriptProperty]
		[Display(Order = 12, Name = "Include DT/DB", GroupName = StrategyParameterGroupName)]
		public bool IncludeDtDb { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Order = 13, Name = "DT/DB Thresh", GroupName = StrategyParameterGroupName)]
		public int DtDbThresh { get; set; }

		[NinjaScriptProperty]
		[Display(Order = 14, Name = "Midline Filter", GroupName = StrategyParameterGroupName)]
		public bool RequireMidlineBias { get; set; }

		private const int SwingParamOffset = 100;

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Order = SwingParamOffset, Name = "ZigZag - Swing Strength", GroupName = StrategyParameterGroupName, Description = "Number of bars used to identify a swing high or low")]
		public int SwingStrength { get; set; }

		[NinjaScriptProperty]
		[Display(Order = 1 + SwingParamOffset, Name = "ZigZag - Include Wicks", GroupName = StrategyParameterGroupName, Description = "Whether or not to use wicks (vs closes) for pivot points")]
		public bool IncludeWicks { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Order = 500, Name = "Oscillator", GroupName = StrategyParameterGroupName)]
		public ARC_DivAlgo_DivAlgoOscillator Oscillator { get; set; }

		#region MACD
		private const int MACDParamOffset = 600;

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.MACD)]
		[Display(Name = "Fast", GroupName = StrategyParameterGroupName, Order = MACDParamOffset)]
		public int MACDFast { get; set; }

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.MACD)]
		[Display(Name = "Slow", GroupName = StrategyParameterGroupName, Order = 1 + MACDParamOffset)]
		public int MACDSlow { get; set; }

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.MACD)]
		[Display(Name = "Smooth", GroupName = StrategyParameterGroupName, Order = 2 + MACDParamOffset)]
		public int MACDSmooth { get; set; }

		[NinjaScriptProperty]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.MACD)]
		[Display(Name = "Signal", GroupName = StrategyParameterGroupName, Order = 3 + MACDParamOffset)]
		public ARC_DivAlgo_DivAlgoMacdSignal MacdSignal { get; set; }
		#endregion

		#region RSI
		private const int RSIParamOffset = 700;

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.RSI)]
		[Display(Name = "Period", GroupName = StrategyParameterGroupName, Order = RSIParamOffset)]
		public int RSIPeriod { get; set; }

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.RSI)]
		[Display(Name = "Smooth", GroupName = StrategyParameterGroupName, Order = RSIParamOffset + 1)]
		public int RSISmooth { get; set; }

		[NinjaScriptProperty]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.RSI)]
		[Display(Name = "Signal", GroupName = StrategyParameterGroupName, Order = RSIParamOffset + 2)]
		public ARC_DivAlgo_DivAlgoRsiSignal RsiSignal { get; set; }
		#endregion

		#region MFI
		private const int MFIParamOffset = 800;

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.MFI)]
		[Display(Name = "Period", GroupName = StrategyParameterGroupName, Order = MFIParamOffset)]
		public int MFIPeriod { get; set; }
		#endregion

		#region VMLean
		private const int VMLeanParamOffset = 900;

		[NinjaScriptProperty]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.VMLean)]
		[Display(Name = "Optimize for Speed", GroupName = StrategyParameterGroupName, Description = "Improve run-time performance (reduces the number of historical chart markers", Order = VMLeanParamOffset)]
		public ARC_DivAlgo_VMAlgo_OptimizeSpeedSettings VMLeanOptimizeSpeed { get; set; }

		#region MACDBB Parameters
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.VMLean)]
		[Display(Name = "Period Bollinger Band", GroupName = StrategyParameterGroupName, Description = "Band Period for Bollinger Band", Order = VMLeanParamOffset + 1)]
		public int VMLeanBandPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.VMLean)]
		[Display(Name = "Lookback fast EMA", GroupName = StrategyParameterGroupName, Description = "Period for fast EMA", Order = VMLeanParamOffset + 2)]
		public int VMLeanFast { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.VMLean)]
		[Display(Name = "Lookback slow EMA", GroupName = StrategyParameterGroupName, Description = "Period for slow EMA", Order = VMLeanParamOffset + 3)]
		public int VMLeanSlow { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.VMLean)]
		[Display(Name = "Std. dev. multiplier", GroupName = StrategyParameterGroupName, Description = "Number of standard deviations", Order = VMLeanParamOffset + 4)]
		public double VMLeanStdDevNumber { get; set; }
		#endregion

		#region SwingTrend Parameters
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.VMLean)]
		[Display(Name = "Swing strength", GroupName = StrategyParameterGroupName, Description = "Number of bars used to identify a swing high or low", Order = VMLeanParamOffset + 5)]
		public int VMLeanSwingStrength { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.VMLean)]
		[Display(Name = "Deviation multiplier", GroupName = StrategyParameterGroupName, Description = "Multiplier used to calculate minimum deviation as an ATR multiple", Order = VMLeanParamOffset + 6)]
		public double VMLeanMultiplierMD { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.VMLean)]
		[Display(Name = "Sensitivity double tops/bottoms", GroupName = StrategyParameterGroupName, Description = "Fraction of ATR ignored when detecting double tops or bottoms", Order = VMLeanParamOffset + 7)]
		public double VMLeanMultiplierDTB { get; set; }
		#endregion
		
		#region EMA Crossover
		[NinjaScriptProperty]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.VMLean)]
		[Display(Name = "Enable EMA Crossover", GroupName = StrategyParameterGroupName, Order = VMLeanParamOffset + 8)]
		public bool VMLeanEnableEmaCrossover { get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.VMLean)]
		[Display(Name = "Fast Period", GroupName = StrategyParameterGroupName, Order = VMLeanParamOffset + 9)]
		public int VMLeanFastEmaPeriod { get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.VMLean)]
		[Display(Name = "Slow Period", GroupName = StrategyParameterGroupName, Order = VMLeanParamOffset + 10)]
		public int VMLeanSlowEmaPeriod { get; set; }
		#endregion

		[NinjaScriptProperty]
		[ARC_DivAlgo_HideUnless(nameof(Oscillator), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_DivAlgoOscillator.VMLean)]
		[Display(Name = "Signal", GroupName = StrategyParameterGroupName, Order = VMLeanParamOffset + 11)]
		public ARC_DivAlgo_DivAlgoVmLeanSignal VmLeanSignal { get; set; }
		#endregion
		#endregion

		#region Stop Loss Params
		[NinjaScriptProperty, ARC_DivAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_BoolEnum.True)]
		[Display(Name = "SL Offset Type", Order = 0, GroupName = StopLossGroupName)]
		public ARC_DivAlgo_DivAlgoStopLossOffsetType StopLossOffsetType { get; set; }

		[NinjaScriptProperty, ARC_DivAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_DivAlgo_PropComparisonType.EQ, ARC_DivAlgo_BoolEnum.True)]
		[Display(Name = "SL Offset", Order = 1, GroupName = StopLossGroupName)]
		public int StopLossOffset { get; set; }
		#endregion

		#region Visual Parameters
		private const string VisualParameterGroupName = "Visuals";

		private readonly ARC_DivAlgo_DefaultingDictionary<int, ARC_DivAlgo_DefaultingDictionary<DivergenceType, Stroke>> divergenceStrokes = new ARC_DivAlgo_DefaultingDictionary<int, ARC_DivAlgo_DefaultingDictionary<DivergenceType, Stroke>>(dir =>
		{
			return new ARC_DivAlgo_DefaultingDictionary<DivergenceType, Stroke>(type =>
			{
				var brush = type switch
				{
					DivergenceType.Hidden => dir == 1 ? Brushes.Cyan : Brushes.Magenta,
					DivergenceType.Regular => dir == 1 ? Brushes.Blue : Brushes.Red
				};

				return new Stroke(brush, DashStyleHelper.Solid, 3);
			});
		});

		[Display(Name = "Zig Zag Stroke", GroupName = VisualParameterGroupName, Order = 0)]
		public Stroke ZigZagStroke { get; set; } = new Stroke(Brushes.White, DashStyleHelper.Dash, 2);

		[Display(Name = "EMA Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 1)]
		public Stroke EmaStroke { get; set; } = new Stroke(Brushes.AliceBlue, 3);
		
		[Display(Name = "Oscillator Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 2)]
		public Stroke OscillatorStroke { get; set; } = new Stroke(Brushes.Yellow, 3);
		
		[Display(Name = "Overbought Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 3)]
		public Stroke OverboughtStroke { get; set; } = new Stroke(Brushes.Fuchsia, DashStyleHelper.Dot, 1);
		
		[Display(Name = "Midline Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 4)]
		public Stroke MidlineStroke { get; set; } = new Stroke(Brushes.Azure, DashStyleHelper.Dot, 1);
		
		[Display(Name = "Oversold Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 5)]
		public Stroke OversoldStroke { get; set; } = new Stroke(Brushes.Aqua, DashStyleHelper.Dot, 1);
		
		[Display(Name = "Regular Bullish Divergence Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 6)]
		public Stroke RegularBullishStroke { get => divergenceStrokes[1][DivergenceType.Regular]; set => divergenceStrokes[1][DivergenceType.Regular] = value; }
		
		[Display(Name = "Regular Bearish Divergence Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 7)]
		public Stroke RegularBearishStroke { get => divergenceStrokes[-1][DivergenceType.Regular]; set => divergenceStrokes[-1][DivergenceType.Regular] = value; }
		
		[Display(Name = "Hidden Bullish Divergence Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 8)]
		public Stroke HiddenBullishStroke { get => divergenceStrokes[1][DivergenceType.Hidden]; set => divergenceStrokes[1][DivergenceType.Hidden] = value; }
		
		[Display(Name = "Hidden Bearish Divergence Stroke", GroupName = StrategyVisualsParameterGroupName, Order = 9)]
		public Stroke HiddenBearishStroke { get => divergenceStrokes[-1][DivergenceType.Hidden]; set => divergenceStrokes[-1][DivergenceType.Hidden] = value; }
		#endregion
		#endregion
	}

	public enum ARC_DivAlgo_DivAlgoStopLossOffsetType
	{
		Tick,
		Percent
	}

	public enum ARC_DivAlgo_DivAlgoOscillator
	{
		MACD,
		RSI,
		MFI,
		VMLean
	}
	
	public enum ARC_DivAlgo_DivAlgoMacdSignal
	{
		MACD,
		Avg,
		Diff
	}
	
	public enum ARC_DivAlgo_DivAlgoRsiSignal
	{
		RSI,
		Avg
	}
	
	public enum ARC_DivAlgo_DivAlgoVmLeanSignal
	{
		Histogram,
		BB
	}
}