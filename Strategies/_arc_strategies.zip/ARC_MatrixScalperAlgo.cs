using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript.Strategies.Licensing;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_MatrixScalperAlgo : ARC_MatrixScalperAlgo_ARCStrategyBase
	{
		public override string ProductVersion => "v1.0.2 (4/8/2024)";
		public override string ProductInfusionSoftTag => "29589";
		protected override bool AllowIntrabarEntries => true;
		public override bool HasStrategyBasedStops => true;
		public override bool HasStrategyBasedTargets => true;

		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_MatrixScalperAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "Matrix Scalper Algo";

				SetupBarThreshold = 50;
				EntryOffset = 0;
				StopLossOffset = 0;
			}
			else if (State == State.Configure)
			{
				AddPlot(LongThreshStroke, PlotStyle.Hash, "Long Thresh");
				AddPlot(ShortThreshStroke, PlotStyle.Hash, "Short Thresh");
			}
		}
		
		protected override void OnTickBar()
		{
			if (CurrentBars[0] <= 1)
				return;

			var last2BarTypes = Enumerable.Range(0, 2)
				.Select(GetSingleBarPattern)
				.ToArray();
			
			// There's no pattern starting in 1
			if (last2BarTypes[1] == ARC_MatrixScalperAlgo_SingleBarPattern.Inside)
				return;
			
			var barDir = Closes[tickBarsIdx][0].ApproxCompare(Closes[tickBarsIdx][1]);
			for (var dir = -1; dir <= 1; dir += 2)
			{
				if (barDir != 0 && barDir != dir)
					continue;

				var entryPrice = (dir == 1 ? Highs : Lows)[0][0] + dir * EntryOffset * TickSize;
				if (!Closes[tickBarsIdx].ARC_MatrixScalperAlgo_Crossed(entryPrice))
					continue;

				// Ensure our third bar doesn't break the pattern
				if ((dir == 1 ? CurBarLow : CurBarHigh).ApproxCompare((dir == 1 ? Lows : Highs)[0][0]) == -dir)
					continue;

				// Must have reversed
				if (Closes[0][1].ApproxCompare(Opens[0][1]) != -dir)
					continue;
				
				// The middle (setup) bar must be in the lower/higher x% of the first bar in the pattern
				var bar1Thresh = Values[dir == 1 ? 0 : 1][0] = (dir == 1 ? Highs : Lows)[0][1] * (1 - SetupBarThreshold / 100) + (dir == 1 ? Lows : Highs)[0][1] * (SetupBarThreshold / 100);
				if ((dir == 1 ? Highs : Lows)[0][0].ApproxCompare(bar1Thresh) == dir)
					continue;

				var matchedPattern = last2BarTypes[1] switch
				{
					ARC_MatrixScalperAlgo_SingleBarPattern.Directional when last2BarTypes[0] == ARC_MatrixScalperAlgo_SingleBarPattern.Inside => ARC_MatrixScalperAlgo_MatrixScalperPattern.P212,
					ARC_MatrixScalperAlgo_SingleBarPattern.Outside when last2BarTypes[0] == ARC_MatrixScalperAlgo_SingleBarPattern.Inside => ARC_MatrixScalperAlgo_MatrixScalperPattern.P312,
					ARC_MatrixScalperAlgo_SingleBarPattern.Outside when last2BarTypes[0] == ARC_MatrixScalperAlgo_SingleBarPattern.Directional => ARC_MatrixScalperAlgo_MatrixScalperPattern.P322,
					_ => (ARC_MatrixScalperAlgo_MatrixScalperPattern?) null
				};

				if (matchedPattern == null || !enabledPatterns[matchedPattern.Value])
					continue;

				if (!TradeAllowed(dir))
					continue;

				var sl = (double?)null;
				if (EnableAlgoDefinedStopLosses)
				{
					var slMultiple = StopLossOffsetType == ARC_MatrixScalperAlgo_MatrixScalperStopLossOffsetType.Ticks ? TickSize : (Highs[0][1] - Lows[0][1]) / 100;
					sl = (dir == 1 ? Lows : Highs)[0][matchedPattern == ARC_MatrixScalperAlgo_MatrixScalperPattern.P322 ? 0 : 1] - dir * slMultiple * StopLossOffset;
					if (!TradeAllowedWithStop(dir, Close[0], sl.Value))
						continue;
				}

				var tp = (double?)null;
				if (EnableAlgoDefinedTargets)
				{
					tp = (dir == 1 ? Highs : Lows)[0][1];
					if (!TradeAllowedWithTakeProfit(dir, Close[0], tp.Value))
						continue;
				}

				QueueEntry(dir, 1, stopLossPrice: sl, profitTargetPrice: tp);
				break;
			}
		}

		#region Parameters
		private ARC_MatrixScalperAlgo_DefaultingDictionary<ARC_MatrixScalperAlgo_MatrixScalperPattern, bool> enabledPatterns = new ARC_MatrixScalperAlgo_DefaultingDictionary<ARC_MatrixScalperAlgo_MatrixScalperPattern, bool>(true);

		[NinjaScriptProperty, Range(1, 99)]
		[Display(Name = "Setup Bar Threshold (%)", GroupName = StrategyParameterGroupName, Order = 0)]
		public double SetupBarThreshold { get; set; }

		[NinjaScriptProperty, Range(int.MinValue, int.MaxValue)]
		[Display(Name = "Entry Offset (Ticks)", GroupName = StrategyParameterGroupName, Order = 1)]
		public int EntryOffset { get; set; }

		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_MatrixScalperAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_MatrixScalperAlgo_NonOptimizationCheckBoxEditor")]
		[ARC_MatrixScalperAlgo_HideUnless(nameof(HasStrategyBasedTargets), ARC_MatrixScalperAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Enable 2-1-2 Pattern", GroupName = StrategyParameterGroupName, Order = 2)]
		public bool Enable212Pattern
		{
			get => enabledPatterns[ARC_MatrixScalperAlgo_MatrixScalperPattern.P212]; 
			set => enabledPatterns[ARC_MatrixScalperAlgo_MatrixScalperPattern.P212] = value;
		}
		
		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_MatrixScalperAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_MatrixScalperAlgo_NonOptimizationCheckBoxEditor")]
		[ARC_MatrixScalperAlgo_HideUnless(nameof(HasStrategyBasedTargets), ARC_MatrixScalperAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Enable 3-1-2 Pattern", GroupName = StrategyParameterGroupName, Order = 3)]
		public bool Enable312Pattern
		{
			get => enabledPatterns[ARC_MatrixScalperAlgo_MatrixScalperPattern.P312]; 
			set => enabledPatterns[ARC_MatrixScalperAlgo_MatrixScalperPattern.P312] = value;
		}
		
		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_MatrixScalperAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_MatrixScalperAlgo_NonOptimizationCheckBoxEditor")]
		[ARC_MatrixScalperAlgo_HideUnless(nameof(HasStrategyBasedTargets), ARC_MatrixScalperAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Enable 3-2-2 Pattern", GroupName = StrategyParameterGroupName, Order = 4)]
		public bool Enable322Pattern
		{
			get => enabledPatterns[ARC_MatrixScalperAlgo_MatrixScalperPattern.P322]; 
			set => enabledPatterns[ARC_MatrixScalperAlgo_MatrixScalperPattern.P322] = value;
		}

		[Browsable(false)]
		public string EnabledPatternsSerializable
		{
			get => enabledPatterns.ToString('/', pattern => pattern.ToString(), b => b.ToString());
			set => enabledPatterns = ARC_MatrixScalperAlgo_DefaultingDictionary.ARC_MatrixScalperAlgo_FromString(value, '/', p => (ARC_MatrixScalperAlgo_MatrixScalperPattern)Enum.Parse(typeof(ARC_MatrixScalperAlgo_MatrixScalperPattern), p), bool.Parse);
		}

		#region Stop Loss
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_MatrixScalperAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_MatrixScalperAlgo_PropComparisonType.EQ, ARC_MatrixScalperAlgo_BoolEnum.True)]
		[Display(Name = "Stop Loss Offset Type", GroupName = StopLossGroupName, Order = 1)]
		public ARC_MatrixScalperAlgo_MatrixScalperStopLossOffsetType StopLossOffsetType { get; set; }
		
		[NinjaScriptProperty, Range(int.MinValue, int.MaxValue)]
		[ARC_MatrixScalperAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_MatrixScalperAlgo_PropComparisonType.EQ, ARC_MatrixScalperAlgo_BoolEnum.True)]
		[ARC_MatrixScalperAlgo_Rename("Stop Loss Offset (Ticks)", nameof(StopLossOffsetType), ARC_MatrixScalperAlgo_PropComparisonType.EQ, ARC_MatrixScalperAlgo_MatrixScalperStopLossOffsetType.Ticks)]
		[ARC_MatrixScalperAlgo_Rename("Stop Loss Offset (% Bar1 Range)", nameof(StopLossOffsetType), ARC_MatrixScalperAlgo_PropComparisonType.EQ, ARC_MatrixScalperAlgo_MatrixScalperStopLossOffsetType.PercentOfBar1Range)]
		[Display(Name = "Stop Loss Offset", GroupName = StopLossGroupName, Order = 2)]
		public int StopLossOffset { get; set; }
		#endregion

		#region Visuals
		[Display(Name = "Long Thresh", GroupName = StrategyVisualsParameterGroupName, Order = 0)]
		public Stroke LongThreshStroke { get; set; } = new Stroke(Brushes.Yellow, DashStyleHelper.Solid, 2);

		[Display(Name = "Short Thresh", GroupName = StrategyVisualsParameterGroupName, Order = 1)]
		public Stroke ShortThreshStroke { get; set; } = new Stroke(Brushes.Blue, DashStyleHelper.Solid, 2);
		#endregion
		#endregion
	}

	public enum ARC_MatrixScalperAlgo_MatrixScalperPattern
	{
		P212,
		P312,
		P322
	}

	public enum ARC_MatrixScalperAlgo_MatrixScalperStopLossOffsetType
	{
		Ticks,
		PercentOfBar1Range
	}
}