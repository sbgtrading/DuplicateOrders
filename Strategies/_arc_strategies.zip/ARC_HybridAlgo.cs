#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Xml.Serialization;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.Strategies.Licensing;

#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_HybridAlgo : ARC_HybridAlgo_ARCStrategyBase
	{
		public override string ProductVersion { get { return "v1.0.38 (2/5/2025)"; } }
		public override string ProductInfusionSoftTag { get { return "23828"; } }

		private int secondLastReversal;
		private int lastReversal;
		private int wickEntriesSinceReversal;
		private ATR atr;
		private readonly ARC_HybridAlgo_DefaultingDictionary<ARC_HybridAlgo_WickerAlgoSignalType, int> maxBarsSinceReversal = new ARC_HybridAlgo_DefaultingDictionary<ARC_HybridAlgo_WickerAlgoSignalType, int>();
		private readonly ARC_HybridAlgo_DefaultingDictionary<ARC_HybridAlgo_WickerAlgoSignalType, int> minOpposingBarsToMomoSignal = new ARC_HybridAlgo_DefaultingDictionary<ARC_HybridAlgo_WickerAlgoSignalType, int>();
		private readonly ARC_HybridAlgo_DefaultingDictionary<ARC_HybridAlgo_WickerAlgoSignalType, bool> signalEnabled = new ARC_HybridAlgo_DefaultingDictionary<ARC_HybridAlgo_WickerAlgoSignalType, bool>();

		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_HybridAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				EnableReversalSignals = true;
				EnableWickSignals = true;
				EnableBbMomoSignals = true;
				EnableHistMomoSignals = true;
				foreach (var type in (ARC_HybridAlgo_WickerAlgoSignalType[]) Enum.GetValues(typeof(ARC_HybridAlgo_WickerAlgoSignalType)))
				{
					signalEnabled[type] = true;
					maxBarsSinceReversal[type] = 5;
					if (type != ARC_HybridAlgo_WickerAlgoSignalType.Wick)
						minOpposingBarsToMomoSignal[type] = 14;
				}
				WickBasis = ARC_HybridAlgo_WickBasis.Ticks;
				WickThresh = 3;
				AtrPeriod = 100;
				MaxWickEntriesPerReversal = 1;
				ButtonText = "Hybrid Algo";
				MinPullbackBars = 2;
			}
			else if (State == State.Configure)
			{
				secondLastReversal = 0;
				lastReversal = 0;
				wickEntriesSinceReversal = 0;
				IsInstantiatedOnEachOptimizationIteration = false;
			}
			else if (State == State.DataLoaded)
			{
				atr = ATR(BarsArray[0], 100);
			}
		}

		private bool ValidSignal(ARC_HybridAlgo_WickerAlgoSignalType signalType)
		{
			if (!signalEnabled[signalType])
				return false;

			if (signalType == ARC_HybridAlgo_WickerAlgoSignalType.Reversal && lastReversal - secondLastReversal < MinPullbackBars)
				return false;

			if (signalType == ARC_HybridAlgo_WickerAlgoSignalType.Reversal)
				return Close[0].ApproxCompare(Open[0]) != Close[1].ApproxCompare(Open[1]);

			if (CurrentBar - lastReversal >= maxBarsSinceReversal[signalType])
				return false;

			var dir = Close[0].ApproxCompare(Open[0]);
			if (signalType == ARC_HybridAlgo_WickerAlgoSignalType.Wick)
			{
				if (wickEntriesSinceReversal >= MaxWickEntriesPerReversal)
					return false;

				double wickCriteriaBasis;
				switch (WickBasis)
				{
				case ARC_HybridAlgo_WickBasis.Ticks:
					wickCriteriaBasis = TickSize;
					break;
				case ARC_HybridAlgo_WickBasis.Body:
					wickCriteriaBasis = Math.Abs(Close[0] - Open[0]);
					break;
				case ARC_HybridAlgo_WickBasis.ATR:
					wickCriteriaBasis = atr[0];
					break;
				default:
					throw new ArgumentOutOfRangeException();
				}

				var wickSize = dir == 1
					? Math.Min(Open[0], Close[0]) - Low[0]
					: High[0] - Math.Max(Open[0], Close[0]);
				return wickSize >= wickCriteriaBasis * WickThresh;
			}

			var minOpposingBars = minOpposingBarsToMomoSignal[signalType];
			if (CurrentBar < minOpposingBars)
				return false;

			var signalSeries = signalType == ARC_HybridAlgo_WickerAlgoSignalType.BB ? indMomo.BBMACD : indMomo.Histogram;
			if (signalSeries[0].ApproxCompare(0) != dir)
				return false;

			if (signalSeries[0].ApproxCompare(0) == signalSeries[1].ApproxCompare(0))
				return false;

			var mro = MRO(() => signalSeries[0].ApproxCompare(0) == dir, 2, minOpposingBars);
			return mro == -1;
		}

		protected override void OnPrimaryBar()
		{
			if (CurrentBar < 1)
				return;

			var signal = Close[0].ApproxCompare(Open[0]);
			if (signal == 0)
				return;

			if (signal != Close[1].ApproxCompare(Open[1]))
			{
				secondLastReversal = lastReversal;
				lastReversal = CurrentBar;
				wickEntriesSinceReversal = 0;
				if (!signalEnabled[ARC_HybridAlgo_WickerAlgoSignalType.Reversal])
					return;
			}

			var entrySignal = Enum.GetValues(typeof(ARC_HybridAlgo_WickerAlgoSignalType))
				.OfType<ARC_HybridAlgo_WickerAlgoSignalType?>()
				.FirstOrDefault(t => ValidSignal(t.Value));
			if (entrySignal == null)
				return;

			// Handle other filters
			if (!TradeAllowed(signal))
				return;

			if (entrySignal == ARC_HybridAlgo_WickerAlgoSignalType.Wick)
				wickEntriesSinceReversal++;
			QueueEntry(signal);
		}

		#region Parameters
		#region Reversal Signals
		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_HybridAlgo_ShowOthersIf(ARC_HybridAlgo_PropComparisonType.EQ, ARC_HybridAlgo_BoolEnum.True, Properties = new[] { "MinPullbackBars" })]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_HybridAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_HybridAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Enable Reversal Signals", Order = 0, GroupName = StrategyParameterGroupName)]
		public ARC_HybridAlgo_BoolEnum EnableReversalSignalsEnum
		{
			get { return signalEnabled[ARC_HybridAlgo_WickerAlgoSignalType.Reversal] ? ARC_HybridAlgo_BoolEnum.True : ARC_HybridAlgo_BoolEnum.False; }
			set { signalEnabled[ARC_HybridAlgo_WickerAlgoSignalType.Reversal] = value == ARC_HybridAlgo_BoolEnum.True; }
		}

		[Browsable(false)]
		public bool EnableReversalSignals 
		{
			get { return signalEnabled[ARC_HybridAlgo_WickerAlgoSignalType.Reversal]; }  
			set { signalEnabled[ARC_HybridAlgo_WickerAlgoSignalType.Reversal] = value; }
		}

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_HybridAlgo_HideUnless("EnableReversalSignalsEnum", ARC_HybridAlgo_PropComparisonType.EQ, ARC_HybridAlgo_BoolEnum.True)]
		[Display(Name = "Min Pullback Bars", Order = 1, GroupName = StrategyParameterGroupName)]
		public int MinPullbackBars { get; set; }
		#endregion

		#region Wick Signals
		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_HybridAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_HybridAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Enable Wick Signals", Order = 200, GroupName = StrategyParameterGroupName)]
		public ARC_HybridAlgo_BoolEnum EnableWickSignalsEnum
		{
			get { return signalEnabled[ARC_HybridAlgo_WickerAlgoSignalType.Wick] ? ARC_HybridAlgo_BoolEnum.True : ARC_HybridAlgo_BoolEnum.False; }
			set { signalEnabled[ARC_HybridAlgo_WickerAlgoSignalType.Wick] = value == ARC_HybridAlgo_BoolEnum.True; }
		}

		[Browsable(false)]
		public bool EnableWickSignals 
		{
			get { return signalEnabled[ARC_HybridAlgo_WickerAlgoSignalType.Wick]; }  
			set { signalEnabled[ARC_HybridAlgo_WickerAlgoSignalType.Wick] = value; }
		}

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_HybridAlgo_HideUnless("EnableWickSignalsEnum", ARC_HybridAlgo_PropComparisonType.EQ, ARC_HybridAlgo_BoolEnum.True)]
		[Display(Name = "Max Wick Entries Per Reversal", Order = 201, GroupName = StrategyParameterGroupName)]
		[XmlElement("MaxEntriesPerReversal")]
		public int MaxWickEntriesPerReversal { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_HybridAlgo_HideUnless("EnableWickSignalsEnum", ARC_HybridAlgo_PropComparisonType.EQ, ARC_HybridAlgo_BoolEnum.True)]
		[Display(Name = "Max Bars to Wick Signal", Order = 202, GroupName = StrategyParameterGroupName)]
		public int MaxBarsSinceReversalToWickSignal
		{
			get { return maxBarsSinceReversal[ARC_HybridAlgo_WickerAlgoSignalType.Wick]; }  
			set { maxBarsSinceReversal[ARC_HybridAlgo_WickerAlgoSignalType.Wick] = value; }
		}

		[NinjaScriptProperty, RefreshProperties(RefreshProperties.All)]
		[ARC_HybridAlgo_HideUnless("EnableWickSignalsEnum", ARC_HybridAlgo_PropComparisonType.EQ, ARC_HybridAlgo_BoolEnum.True)]
		[Display(Name = "Signal Wick Basis", Order = 203, GroupName = StrategyParameterGroupName)]
		public ARC_HybridAlgo_WickBasis WickBasis { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_HybridAlgo_HideUnless("WickBasis", ARC_HybridAlgo_PropComparisonType.EQ, ARC_HybridAlgo_WickBasis.ATR)]
		[ARC_HybridAlgo_HideUnless("EnableWickSignalsEnum", ARC_HybridAlgo_PropComparisonType.EQ, ARC_HybridAlgo_BoolEnum.True)]
		[Display(Name = "Wick Basis ATR Period", Order = 204, GroupName = StrategyParameterGroupName)]
		public int AtrPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(double.Epsilon, double.MaxValue)]
		[ARC_HybridAlgo_Rename("Min Wick Size (Ticks)", "WickBasis", ARC_HybridAlgo_PropComparisonType.EQ, ARC_HybridAlgo_WickBasis.Ticks)]
		[ARC_HybridAlgo_Rename("Min Wick Size (Multiple of Body)", "WickBasis", ARC_HybridAlgo_PropComparisonType.EQ, ARC_HybridAlgo_WickBasis.Body)]
		[ARC_HybridAlgo_Rename("Min Wick Size (ATRs)", "WickBasis", ARC_HybridAlgo_PropComparisonType.EQ, ARC_HybridAlgo_WickBasis.ATR)]
		[ARC_HybridAlgo_HideUnless("EnableWickSignalsEnum", ARC_HybridAlgo_PropComparisonType.EQ, ARC_HybridAlgo_BoolEnum.True)]
		[Display(Name = "Min Wick Size", Order = 205, GroupName = StrategyParameterGroupName)]
		public double WickThresh { get; set; }
		#endregion

		#region Histo Momo Signals
		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_HybridAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_HybridAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Enable Histo Momo Signals", Order = 300, GroupName = StrategyParameterGroupName)]
		public ARC_HybridAlgo_BoolEnum EnableHistMomoSignalsEnum
		{
			get { return signalEnabled[ARC_HybridAlgo_WickerAlgoSignalType.Histo] ? ARC_HybridAlgo_BoolEnum.True : ARC_HybridAlgo_BoolEnum.False; }
			set { signalEnabled[ARC_HybridAlgo_WickerAlgoSignalType.Histo] = value == ARC_HybridAlgo_BoolEnum.True; }
		}

		[Browsable(false)]
		public bool EnableHistMomoSignals 
		{
			get { return signalEnabled[ARC_HybridAlgo_WickerAlgoSignalType.Histo]; }  
			set { signalEnabled[ARC_HybridAlgo_WickerAlgoSignalType.Histo] = value; }
		}
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_HybridAlgo_HideUnless("EnableHistMomoSignalsEnum", ARC_HybridAlgo_PropComparisonType.EQ, ARC_HybridAlgo_BoolEnum.True)]
		[Display(Name = "Max Bars to Momo Signal (Histo)", Order = 301, GroupName = StrategyParameterGroupName)]
		public int MaxBarsSinceReversalToHistMomoSignal
		{
			get { return maxBarsSinceReversal[ARC_HybridAlgo_WickerAlgoSignalType.Histo]; }  
			set { maxBarsSinceReversal[ARC_HybridAlgo_WickerAlgoSignalType.Histo] = value; }
		}

		[NinjaScriptProperty]
		[Range(1, 256)]
		[ARC_HybridAlgo_HideUnless("EnableHistMomoSignalsEnum", ARC_HybridAlgo_PropComparisonType.EQ, ARC_HybridAlgo_BoolEnum.True)]
		[Display(Name = "Min Opposing Momo Bars (Histo)", Order = 302, GroupName = StrategyParameterGroupName)]
		public int MinOpposingBarsToHistMomoSignal
		{
			get { return minOpposingBarsToMomoSignal[ARC_HybridAlgo_WickerAlgoSignalType.Histo]; }  
			set { minOpposingBarsToMomoSignal[ARC_HybridAlgo_WickerAlgoSignalType.Histo] = value; }
		}
		#endregion

		#region Histo BB Signals
		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_HybridAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_HybridAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Enable BB Momo Signals", Order = 400, GroupName = StrategyParameterGroupName)]
		public ARC_HybridAlgo_BoolEnum EnableBbMomoSignalsEnum
		{
			get { return signalEnabled[ARC_HybridAlgo_WickerAlgoSignalType.BB] ? ARC_HybridAlgo_BoolEnum.True : ARC_HybridAlgo_BoolEnum.False; }
			set { signalEnabled[ARC_HybridAlgo_WickerAlgoSignalType.BB] = value == ARC_HybridAlgo_BoolEnum.True; }
		}

		[Browsable(false)]
		public bool EnableBbMomoSignals
		{
			get { return signalEnabled[ARC_HybridAlgo_WickerAlgoSignalType.BB]; }  
			set { signalEnabled[ARC_HybridAlgo_WickerAlgoSignalType.BB] = value; }
		}

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_HybridAlgo_HideUnless("EnableBbMomoSignalsEnum", ARC_HybridAlgo_PropComparisonType.EQ, ARC_HybridAlgo_BoolEnum.True)]
		[Display(Name = "Max Bars to Momo Signal (BB)", Order = 401, GroupName = StrategyParameterGroupName)]
		public int MaxBarsSinceReversalToBbMomoSignal
		{
			get { return maxBarsSinceReversal[ARC_HybridAlgo_WickerAlgoSignalType.BB]; }  
			set { maxBarsSinceReversal[ARC_HybridAlgo_WickerAlgoSignalType.BB] = value; }
		}

		[NinjaScriptProperty]
		[Range(1, 256)]
		[ARC_HybridAlgo_HideUnless("EnableBbMomoSignalsEnum", ARC_HybridAlgo_PropComparisonType.EQ, ARC_HybridAlgo_BoolEnum.True)]
		[Display(Name = "Min Opposing Momo Bars (BB)", Order = 402, GroupName = StrategyParameterGroupName)]
		public int MinOpposingBarsToBbMomoSignal
		{
			get { return minOpposingBarsToMomoSignal[ARC_HybridAlgo_WickerAlgoSignalType.BB]; }  
			set { minOpposingBarsToMomoSignal[ARC_HybridAlgo_WickerAlgoSignalType.BB] = value; }
		}
		#endregion
		#endregion
	}
	
	public enum ARC_HybridAlgo_WickBasis
	{
		Ticks,
		Body,
		ATR
	}

	public enum ARC_HybridAlgo_WickerAlgoSignalType
	{
		Reversal,
		Wick,
		Histo,
		BB
	}
}