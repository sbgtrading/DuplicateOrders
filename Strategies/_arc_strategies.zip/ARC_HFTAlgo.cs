using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Xml.Serialization;
using NinjaTrader.Core;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using SharpDX;
using SharpDX.Direct2D1;
using SharpDX.DirectWrite;
using Brush = System.Windows.Media.Brush;
using Brushes = System.Windows.Media.Brushes;
using TextAlignment = SharpDX.DirectWrite.TextAlignment;
using Point = System.Windows.Point;
using NinjaTrader.Cbi;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	public class ARC_HFTAlgo : ARC_HFTAlgo_ARCStrategyBase, ARC_HFTAlgo_IPaintsDomBars, ARC_HFTAlgo_ITracksDomBarsWithImbalance
	{
		public override string ProductVersion { get { return "v2.0.35 (7/3/2023)"; } }
		public override string ProductInfusionSoftTag { get { return "24787"; } }
		protected override bool AllowIntrabarEntries { get { return EntryTimeType == ARC_HFTAlgo_HftAlgoEntryTime.Intrabar; } }
		protected override float BottomRenderMargin { get { return StripHeight; } }

		private class EntryRenderRecord
		{
			public int Dir { get; set; }
			public List<ARC_HFTAlgo_HftAlgoSignalType> Signals { get; private set; }
			public ARC_HFTAlgo_DomProfile SignalDom { get; set; }

			public EntryRenderRecord()
			{
				Signals = new List<ARC_HFTAlgo_HftAlgoSignalType>();
			}
		}

		private class AbsorptionRecord
		{
			public int StartBar { get; set; }
			public int EndBar { get; set; }
			public int Dir { get; set; }
		}

		private Guid[] domIdsAtLastExit = Array.Empty<Guid>();
		private double currentPrimaryBarVolume;
		private int currentPrimaryBarTickCount;
		private double currentPrimaryBarLow;
		private double currentPrimaryBarHigh;
		private ARC_HFTAlgo_DomBarTracker<ARC_HFTAlgo> domTracker;
		private Series<ARC_HFTAlgo_DomProfile> profiles;
		private List<ARC_HFTAlgo_HftAlgoSignalType> signalTypeOptimizedCheckOrder;
		private readonly List<AbsorptionRecord> absorptionRecords = new List<AbsorptionRecord>();
		private int primaryBarAtLastExtremeReset = -1;
		private double tickOpen;
		private readonly ConcurrentQueue<EntryRenderRecord> entryRenderRecords = new ConcurrentQueue<EntryRenderRecord>();
		private ATR absorptionAtr;
		protected override void OnStateChange()
		{
			base.OnStateChange();
			if (State != State.SetDefaults && State != State.Terminated && !this.ARC_HFTAlgo_IsLicensed())
				return;

			if (State == State.SetDefaults)
			{
				ButtonText = "HFT Algo";
				CheckDeltaCongruence = false;
				TicksPerDomLevel = 1;
				ImbalanceMultiplier = 3;
				MinImbalancePercent = 0;
				ImbalanceCalculationMode = ARC_HFTAlgo_ImbalanceCalculationMode.Diagonally;
				MinStackedImbalances = 3;
				TrappedTradersSignalMode = ARC_HFTAlgo_HftAlgoSignalToggleState.On;
				StackedImbalanceSignalMode = ARC_HFTAlgo_HftAlgoSignalToggleState.On;
				DeltaDivergenceSignalMode = ARC_HFTAlgo_HftAlgoSignalToggleState.On;
				ConfluenceSignalMode = ARC_HFTAlgo_HftAlgoSignalToggleState.On;
				DeltaDivergenceLookback = 3;
				MinConfluentSignals = 1;
				SignalBarThreshType = ARC_HFTAlgo_HftAlgoSignalBarThreshType.None;
				SignalBarThresh = 1;
				EntryTimeType = ARC_HFTAlgo_HftAlgoEntryTime.Intrabar;
				MinTrappedTraderLevels = 3;
				UseHighLowRangeFilter = true;
				VolumeDivisor = 1;

				PaintNonTradeBarDoms = true;
				DomTextColor = Brushes.Black;
				BidImbalanceColor = Brushes.White;
				AskImbalanceColor = Brushes.Cyan;
				ShortLabelColor = Brushes.Maroon;
				LongLabelColor = Brushes.Navy;
				SignalLabelDistance = 50;
				ShowNetDeltaAboveBars = true;
				DeltaLabelDistance = 50;
				SummaryStripGridColor = Brushes.Gray;
				SummaryStripNeutralBackingColor = Brushes.Azure;
				SummaryStripLongBackingColor = Brushes.Lime;
				SummaryStripShortBackingColor = Brushes.Red;
				SummaryStripHeaderColor = Brushes.Yellow;
				CumDeltaLookback = 10;
				MinDeltaPercentForColor = 5;
				AbsorptionLongColor = Brushes.Aqua;
				AbsorptionShortColor = Brushes.HotPink;
				AbsorptionLookback = 5;
				AbsorptionAtrPeriod = 14;
				MaxAbsorptionExcursionValue = 1;
			}
			else if (State == State.Configure)
			{
				IsAutoScale = true;
				currentPrimaryBarVolume = 0;
				currentPrimaryBarTickCount = 0;
				currentPrimaryBarLow = 0;
				currentPrimaryBarHigh = 0;
				entryRenderRecords.ARC_HFTAlgo_Clear();
				absorptionRecords.Clear();
				IsInstantiatedOnEachOptimizationIteration = false;

				if (BidAskCalculationMode == ARC_HFTAlgo_BidAskVolumeCalculationMode.TrueBidAsk)
				{
					EnsureDataSeriesAdded(BarsPeriodType.Tick, 1, MarketDataType.Bid);
					EnsureDataSeriesAdded(BarsPeriodType.Tick, 1, MarketDataType.Ask);
				}

				domTracker = BidAskCalculationMode == ARC_HFTAlgo_BidAskVolumeCalculationMode.UpTickDownTick 
					? new ARC_HFTAlgo_DomBarTracker<ARC_HFTAlgo>(this, orderBarsIdx)
					: new ARC_HFTAlgo_DomBarTracker<ARC_HFTAlgo>(this, orderBarsIdx, Array.FindIndex(BarsPeriods, bp => bp.BarsPeriodType == BarsPeriodType.Tick && bp.Value == 1 && bp.MarketDataType == MarketDataType.Bid), Array.FindIndex(BarsPeriods, bp => bp.BarsPeriodType == BarsPeriodType.Tick && bp.Value == 1 && bp.MarketDataType == MarketDataType.Ask));
				
				signalTypeOptimizedCheckOrder = signalToggleStates
					.Where(kvp => kvp.Value != ARC_HFTAlgo_HftAlgoSignalToggleState.Off)
					.OrderBy(kvp => kvp.Value == ARC_HFTAlgo_HftAlgoSignalToggleState.Required ? 0 : 1)
					.Select(kvp => kvp.Key)
					.ToList();
			}
			else if (State == State.DataLoaded)
			{
				profiles = new Series<ARC_HFTAlgo_DomProfile>(this, MaximumBarsLookBack.Infinite);
				if ((ShowAbsorptionBackgrounds || ShowAbsorptionStrip) && MaxAbsorptionExcursionType == ARC_HFTAlgo_MaxAbsorptionExcursionType.ATR)
					absorptionAtr = ATR(AbsorptionAtrPeriod);
			}
			else if (State == State.Historical)
			{
				SetZOrder(0);
			}
		}

		#region Core Logic
		protected override void OnTickBar()
		{
			// If our bar has just flipped, and we're not time based, and we haven't already captured
			// a profile for the completed bar, capture the bar profile and recheck for signals
			if (!BarsPeriods[0].BarsPeriodType.ARC_HFTAlgo_IsTimeBased() && domTracker.LastLeveledBarProfile != null && domTracker.FirstTickOfNewDom && profiles[0] == null)
			{
				profiles[0] = domTracker.LastLeveledBarProfile.Clone();
				CheckAbsorptions();
				if (EntryTimeType == ARC_HFTAlgo_HftAlgoEntryTime.BarClose)
					ScanEntries(domTracker.LastLeveledBarProfile);
			}

			if (CurrentBars[0] != primaryBarAtLastExtremeReset)
			{
				primaryBarAtLastExtremeReset = CurrentBars[0];
				tickOpen = Close[0];
				currentPrimaryBarTickCount = 0;
				currentPrimaryBarVolume = 0;
				currentPrimaryBarLow = double.MaxValue;
				currentPrimaryBarHigh = double.MinValue;
			}

			currentPrimaryBarTickCount++;
			currentPrimaryBarVolume += Volume[0];
			currentPrimaryBarLow = Math.Min(currentPrimaryBarLow, Close[0]);
			currentPrimaryBarHigh = Math.Max(currentPrimaryBarHigh, Close[0]);
			if (EntryTimeType == ARC_HFTAlgo_HftAlgoEntryTime.Intrabar)
				ScanEntries(domTracker.LeveledBarProfile);
		}

		protected override void OnExitExecution(Execution execution, int quantity)
		{
			var domIds = new List<Guid>
			{
				domTracker.CurrentBarProfileId,
				domTracker.LastLeveledBarProfile.ParentId,
				domTracker.LeveledBarProfile.ParentId
			};
			if (domTracker.PendingReset)
				domIds.Add(domTracker.NextBarProfileId);
			domIdsAtLastExit = domIds.Distinct().ToArray();
		}

		private void CheckAbsorptions()
		{
			if (!ShowAbsorptionBackgrounds && !ShowAbsorptionStrip)
				return;

			if (profiles[0] == null)
				return;

			var record = new AbsorptionRecord
			{
				Dir = Closes[0][0].ApproxCompare(Opens[0][0]),
				EndBar = CurrentBars[0]
			};

			if (profiles[0].NetDelta.ApproxCompare(0) != record.Dir)
				return;

			var lookback = Math.Min(AbsorptionLookback, CurrentBars[0] - (absorptionRecords.Count == 0 ? 0 : absorptionRecords.Last().EndBar));
			if (lookback < 1)
				return;
			
			var maxExcursion = MaxAbsorptionExcursionValue * (MaxAbsorptionExcursionType == ARC_HFTAlgo_MaxAbsorptionExcursionType.ATR ? absorptionAtr[0] : TickSize);
			var minExtreme = (record.Dir == -1 ? Highs : Lows)[0][0];
			var maxExtreme = minExtreme;
			for (var i = 1; i <= lookback; i++)
			{
				// Stop at the first non opposing bar
				if (Closes[0][i].ApproxCompare(Opens[0][i]) != -record.Dir)
					return;

				// Stop if max excursion exceeded
				var extreme = (record.Dir == -1 ? Highs : Lows)[0][i];
				maxExtreme = Math.Max(extreme, maxExtreme);
				minExtreme = Math.Min(extreme, minExtreme);
				if ((maxExtreme - minExtreme).ApproxCompare(maxExcursion) == 1)
					return;

				if (profiles[i] == null)
					continue;

				// Check delta
				if (profiles[i].NetDelta.ApproxCompare(0) != -record.Dir || Math.Abs(profiles[i].NetDelta) / profiles[i].TotalVolume < MinDeltaPercentForColor / 100)
					continue;

				// Check cum delta
				var deltaSum = Enumerable.Range(i, Math.Min(CurrentBars[0] - i,  CumDeltaLookback + 1))
					.Select(i2 => profiles[i2])
					.Where(p => p != null)
					.Select(p => p.NetDelta)
					.Take(CumDeltaLookback)
					.Sum();
				if (deltaSum.ApproxCompare(0) != -record.Dir)
					continue;

				record.StartBar = CurrentBars[0] - i;
				absorptionRecords.Add(record);

				if (!ShowAbsorptionBackgrounds)
					return;

				var recordHigh = Enumerable.Range(record.StartBar, record.EndBar - record.StartBar + 1).Max(i2 => Highs[0].GetValueAt(i2));
				var recordLow = Enumerable.Range(record.StartBar, record.EndBar - record.StartBar + 1).Min(i2 => Lows[0].GetValueAt(i2));
				var rect = Draw.Rectangle(this, Guid.NewGuid().ToString("N"), i, recordHigh, 0, recordLow, Brushes.Transparent, true);
				rect.AreaBrush = record.Dir == -1 ? AbsorptionShortColor : AbsorptionLongColor;
				rect.AreaOpacity = 25;
				rect.OutlineStroke.Opacity = 25;
				rect.StartAnchor.SlotIndex = record.StartBar;
				rect.EndAnchor.SlotIndex = record.EndBar;
				rect.ZOrderType = DrawingToolZOrder.AlwaysDrawnFirst;
				rect.ZOrder = -1;
				rect.IsSeparateZOrder = true;
				return;
			}
		}

		protected override void OnPrimaryBar()
		{
			if (domTracker.LastLeveledBarProfile == null || !BarsPeriods[0].BarsPeriodType.ARC_HFTAlgo_IsTimeBased())
				return;

			CheckAbsorptions();
			if (EntryTimeType == ARC_HFTAlgo_HftAlgoEntryTime.BarClose)
				ScanEntries(domTracker.LastLeveledBarProfile);

			profiles[0] = domTracker.LastLeveledBarProfile.Clone();
		}

		private void ScanEntries(ARC_HFTAlgo_DomProfile signalProfile)
		{
			if (DeltaDivergenceSignalMode != ARC_HFTAlgo_HftAlgoSignalToggleState.Off && CurrentBars[0] < DeltaDivergenceLookback)
				return;

			if (PendingEntryDir != 0)
				return;
			
			if (!AllowEntriesOnExitBars && domIdsAtLastExit.Contains(signalProfile.ParentId))
				return;

			// Prevent multiple signals within the same primary bar
			if (entryRenderRecords.Any() && entryRenderRecords.Last().SignalDom.ParentId == domTracker.CurrentBarProfileId)
				return;

			// Filter bar for minimum size or tick count
			switch (SignalBarThreshType)
			{
			case ARC_HFTAlgo_HftAlgoSignalBarThreshType.None:
				break;
			case ARC_HFTAlgo_HftAlgoSignalBarThreshType.TickCount:
				if (currentPrimaryBarTickCount < SignalBarThresh)
					return;
				break;
			case ARC_HFTAlgo_HftAlgoSignalBarThreshType.Price: 
				if ((currentPrimaryBarHigh - currentPrimaryBarLow) / TickSize < SignalBarThresh)
					return;
				break;
			case ARC_HFTAlgo_HftAlgoSignalBarThreshType.Volume:
				if (currentPrimaryBarVolume < SignalBarThresh)
					return;
				break;
			default: 
				throw new ArgumentOutOfRangeException();
			}
			
			for (var dir = -1; dir <= 1; dir += 2)
			{
				if (CheckDeltaCongruence && signalProfile.NetDelta.ApproxCompare(0) != dir)
					continue;

				if (!TradeAllowed(dir))
					continue;

				var tradeInvalid = false;
				var record = new EntryRenderRecord { Dir = dir };
				foreach (var signalType in signalTypeOptimizedCheckOrder)
				{
					var signalValid = SignalTypeValid(signalProfile, signalType, dir);
					if (signalValid)
						record.Signals.Add(signalType);

					if (signalToggleStates[signalType] != ARC_HFTAlgo_HftAlgoSignalToggleState.Required)
						continue;

					tradeInvalid = true;
					break;
				}

				if (tradeInvalid || record.Signals.Count < MinConfluentSignals)
					continue;

				var entryMarkerOffset = BarsInProgress == 0 || EntryTimeType == ARC_HFTAlgo_HftAlgoEntryTime.BarClose ? 0 : (Time[0] > Times[0][0] ? 1 : 0);
				record.SignalDom = signalProfile.Clone();
				entryRenderRecords.Enqueue(record);
				QueueEntry(dir, signalBarOffset: entryMarkerOffset, limitPrice: Close[0]);
				break;
			}
		}

		private bool SignalTypeValid(ARC_HFTAlgo_DomProfile signalProfile, ARC_HFTAlgo_HftAlgoSignalType type, int dir)
		{
			// For toggled signals and confluence signals, bar must point in dir
			var open = EntryTimeType == ARC_HFTAlgo_HftAlgoEntryTime.BarClose ? Opens[0][0] : tickOpen;
			var close = Closes[EntryTimeType == ARC_HFTAlgo_HftAlgoEntryTime.BarClose ? 0 : orderBarsIdx][0];
			if (barDirectionRequired[type] && close.ApproxCompare(open) != dir)
				return false;

			// For DD must be lowest low of lookback bars for long, highest high for short among past lookback bars. For TT and FR, must be the same but only for past 1 bar.
			if (type == ARC_HFTAlgo_HftAlgoSignalType.FlushReversal || type == ARC_HFTAlgo_HftAlgoSignalType.DeltaDivergence || (type == ARC_HFTAlgo_HftAlgoSignalType.TrappedTraders && UseHighLowRangeFilter))
			{
				var lookback = type == ARC_HFTAlgo_HftAlgoSignalType.DeltaDivergence ? DeltaDivergenceLookback : 1;
				var priceDeltaSeries = dir == 1 ? Lows[0] : Highs[0];
				var curExtreme = EntryTimeType == ARC_HFTAlgo_HftAlgoEntryTime.BarClose 
					? priceDeltaSeries[0] 
					: (dir == 1 ? currentPrimaryBarLow : currentPrimaryBarHigh);
				
				var rangeStart = EntryTimeType == ARC_HFTAlgo_HftAlgoEntryTime.BarClose ? 1 : 0;
				for (var i = rangeStart; i < rangeStart + lookback; i++)
					if (curExtreme.ApproxCompare(priceDeltaSeries[i]) != -dir)
						return false;
			}
			
			switch (type)
			{
			case ARC_HFTAlgo_HftAlgoSignalType.DeltaDivergence:
				// Delta must point in dir
				return signalProfile.NetDelta.ApproxCompare(0) == dir;
			case ARC_HFTAlgo_HftAlgoSignalType.TrappedTraders:
				if (signalProfile.Count < MinTrappedTraderLevels)
					return false;

				// Return true if the extreme end of the bar (bottom for longs, top for shorts) consists of n levels of decreasing volume
				var levelsEnumeration = signalProfile.Values
					.Skip(dir == 1 ? 0 : signalProfile.Count - MinTrappedTraderLevels)
					.Take(MinTrappedTraderLevels);

				var levels = levelsEnumeration
					.Select(kvp => dir == 1 ? kvp.Bid : kvp.Ask)
					.ToArray();

				for (var i = 1; i < levels.Length; i++)
					if (levels[i].ApproxCompare(levels[i - 1]) != dir)
						return false;
				
				return true;
			case ARC_HFTAlgo_HftAlgoSignalType.StackedImbalance:
				var barImbalances = signalProfile
					.Where(kvp => kvp.Value.Imbalance.HasFlag(dir == 1 ? ARC_HFTAlgo_BidAskFlags.Ask : ARC_HFTAlgo_BidAskFlags.Bid))
					.Select(kvp => kvp.Key)
					.ToArray();
				if (barImbalances.Length < MinStackedImbalances)
					return false;

				var stackedImbalances = 0;
				for (var i = 0; i < barImbalances.Length; i++)
				{
					if (i > 0 && (barImbalances[i] - barImbalances[i - 1]).ApproxCompare(TickSize * TicksPerDomLevel) == 1)
						stackedImbalances = 0;

					stackedImbalances++;
					if (stackedImbalances >= MinStackedImbalances)
						return true;
				}

				return false;
			case ARC_HFTAlgo_HftAlgoSignalType.FlushReversal:
				if (close.ApproxCompare(open) != dir)
					return false;

				if (signalProfile.NetDelta.ApproxCompare(0) != -dir)
					return false;

				var secondLastDomBarIdx = Enumerable.Range(0, CurrentBars[0])
					.Where(i2 => profiles[i2] != null && profiles[i2].ParentId != signalProfile.ParentId)
					.Append(-1)
					.First();
				if (secondLastDomBarIdx == -1 || Closes[0][secondLastDomBarIdx].ApproxCompare(Opens[0][secondLastDomBarIdx]) != -dir)
					return false;

				return true;
			case ARC_HFTAlgo_HftAlgoSignalType.Confluence:
				// Require that this bar (i == 0) passes our confluence criteria, and that some confluence criteria failed the prior bar (i == 1)
				for (var i = 0; i < 2; i++)
				{
					if (CurrentBars[0] < CumDeltaLookback + 1 + i)
						if (i == 0)
							return false;
						else
							continue;

					// Check delta
					var profile = i == 0 
						? signalProfile 
						: Enumerable.Range(0, CumDeltaLookback + 1 + i)
							.Select(i2 => profiles[i2])
							.FirstOrDefault(p => p != null && p.ParentId != signalProfile.ParentId);
					if (profile == null || profile.NetDelta.ApproxCompare(0) != dir || Math.Abs(profile.NetDelta) / profile.TotalVolume < MinDeltaPercentForColor / 100)
						if (i == 0)
							return false;
						else
							continue;

					// Check cum delta
					var deltas = Enumerable.Range(0, CumDeltaLookback + 1 + i)
						.Select(i2 => profiles[i2])
						.Where(p => p != null && p.ParentId != signalProfile.ParentId)
						.Select(p => p.NetDelta);
					if (i == 0)
						deltas = deltas.Prepend(signalProfile.NetDelta);

					var sum = deltas.Take(CumDeltaLookback).Sum();
					if (sum.ApproxCompare(0) != dir)
						if (i == 0)
							return false;
						else
							continue;

					// Check state
					if (i == 0)
					{
						if (close.ApproxCompare(open) != dir)
							return false;
					}
					else
					{
						var secondLastDomBarIdx2 = Enumerable.Range(0, CumDeltaLookback + 1 + i).First(i2 => profiles[i2] != null && profiles[i2].ParentId != signalProfile.ParentId);
						if (Closes[0][secondLastDomBarIdx2].ApproxCompare(Opens[0][secondLastDomBarIdx2]) != dir)
							continue;
					}

					if (i == 1)
						return false;
				}
				
				return true;
			default: 
				throw new ArgumentOutOfRangeException("type", type, null);
			}
		}

		protected override void OnBarUpdate()
		{
			if (!this.ARC_HFTAlgo_IsLicensed())
				return;

			if (CurrentBars.All(cb => cb > 0))
				domTracker.HandleBarUpdate();

			base.OnBarUpdate();
		}
		#endregion

		public override void OnCalculateMinMax()
		{
			base.OnCalculateMinMax();
			if (ChartPanel == null || ChartBars == null)
				return;
			
			if (ChartPanel.Scales[ScaleJustification].Properties.YAxisRangeType == YAxisRangeType.Fixed)
			{
				MinValue = ChartPanel.Scales[ScaleJustification].MinValue;
				MaxValue = ChartPanel.Scales[ScaleJustification].MaxValue;
				return;
			}

			var stripHeight = Math.Min(MinStripHeight * enabledStrips.Values.Count(v => v), ChartPanel.H / 4f);
			var min = double.MaxValue;
			var max = double.MinValue;
			for (var i = ChartBars.FromIndex; i <= ChartBars.ToIndex; i++)
			{
				min = Math.Min(Lows[0].GetValueAt(i), min);
				max = Math.Max(Highs[0].GetValueAt(i), max);
			}

			MaxValue = max;
			MinValue = min - (max - min) * (1 / (1 - stripHeight / ChartPanel.H) - 1);
		}

		#region Rendering
		private const float MinStripHeight = 15;
		private float RenderedStrips { get { return enabledStrips.Count(kvp => kvp.Value); } }
		private float StripHeight { get { return Math.Min(MinStripHeight * RenderedStrips, ChartPanel.H / 4f); } }
		
		private ARC_HFTAlgo_DomProfile GetRenderedDomProfile(int barIdx)
		{
			// Get the bar dom, if null return null
			var dom = barIdx < ChartBars.Count - 1 ? profiles.GetValueAt(barIdx) : domTracker.RenderThreadSafeLeveledBarProfile;
			if (dom == null)
				return null;

			// Get the entry record associated with that dom
			var entryRecord = entryRenderRecords.FirstOrDefault(r => r.SignalDom.ParentId == dom.ParentId);

			// If an entry didn't take place, and we aren't painting non trade bar doms, return null
			if (entryRecord == null && !PaintNonTradeBarDoms)
				return null;

			// If entering on bar close, not freezing on signal, or there was no signal, return the dom, otherwise 
			return EntryTimeType == ARC_HFTAlgo_HftAlgoEntryTime.BarClose || !FreezeDomOnSignal || entryRecord == null ? dom : entryRecord.SignalDom;
		}

		private void RenderProfiles(ChartControl chartControl, ChartScale chartScale)
		{
			var domCellsSize = this.ARC_HFTAlgo_GetDomTargetCellSize(chartControl, chartScale);
			if (domCellsSize.Width.ApproxCompare(5f) <= 0)
				return;

			const float minFontSize = 5;
			var font = new SimpleFont("Consolas", 12);
			var renderedProfiles = new Dictionary<int, ARC_HFTAlgo_DomProfile>();
			for (var i = chartControl.PrimaryBars.FromIndex; i <= chartControl.PrimaryBars.ToIndex; i++)
			{
				var profile = GetRenderedDomProfile(i);
				if (profile == null || profile.Count == 0)
					continue;

				renderedProfiles[i] = profile;
				profile.ARC_HFTAlgo_SizeFontToFit(this, font, domCellsSize, minFontSize);
				if (font.Size <= minFontSize)
					return;
			}

			if (renderedProfiles.Count == 0)
				return;
			
			foreach (var barIdx in renderedProfiles.Keys)
				this.ARC_HFTAlgo_RenderDom(chartControl, chartScale, renderedProfiles[barIdx], barIdx, domCellsSize, font, deltaOffset: DeltaLabelDistance, showDelta: ShowNetDeltaAboveBars);
		}

		private static string GetSummaryHeaderText(ARC_HFTAlgo_HftAlgoProfileSummaryStrips strip)
		{
			switch (strip)
			{
			case ARC_HFTAlgo_HftAlgoProfileSummaryStrips.Absorption:
				return "Absorb.";
			case ARC_HFTAlgo_HftAlgoProfileSummaryStrips.State:
				return "State";
			case ARC_HFTAlgo_HftAlgoProfileSummaryStrips.Delta:
				return "Delta";
			case ARC_HFTAlgo_HftAlgoProfileSummaryStrips.CumDelta:
				return "Cum.D";
			case ARC_HFTAlgo_HftAlgoProfileSummaryStrips.BidAskPercent:
				return "B/A %";
			case ARC_HFTAlgo_HftAlgoProfileSummaryStrips.DeltaPercent:
				return "D%";
			case ARC_HFTAlgo_HftAlgoProfileSummaryStrips.Volume:
				return "Vol";
			default: 
				throw new ArgumentOutOfRangeException("strip", strip, null);
			}
		}

		private class FormattedDouble
		{
			public string Format { get; set; }
			public double Value { get; set; }

			public override string ToString()
			{
				return Value.ToString(Format);
			}
		}

		private ARC_HFTAlgo_DomProfile GetSummaryStripDomProfile(int barIdx)
		{
			var dom = barIdx < ChartBars.Count - 1 ? profiles.GetValueAt(barIdx) : domTracker.RenderThreadSafeLeveledBarProfile;
			if (dom == null || EntryTimeType == ARC_HFTAlgo_HftAlgoEntryTime.BarClose || !FreezeSummaryStripOnSignal)
				return dom;
			
			var entryRecord = entryRenderRecords.FirstOrDefault(r => r.SignalDom.ParentId == dom.ParentId);
			return entryRecord == null ? dom : entryRecord.SignalDom;
		}

		private void RenderSummaryStrips(ChartControl chartControl)
		{
			if (enabledStrips.Values.All(v => !v))
				return;

			var renderedStrips = enabledStrips
				.Where(kvp => kvp.Value)
				.Select(kvp => kvp.Key)
				.OrderByDescending(s => (int) s)
				.ToArray();
			
			if (ChartBars.FromIndex == ChartBars.ToIndex)
				return;

			var cellsSize = new Size2F
			{
				Width = chartControl.GetXByBarIndex(ChartBars, ChartBars.FromIndex + 1) - chartControl.GetXByBarIndex(ChartBars, ChartBars.FromIndex),
				Height = StripHeight / RenderedStrips
			};

			if (cellsSize.Width <= 5)
				return;

			// Compile a list of rendered profiles, and a dictionary relating bar indexes, strips, and cell values
			var summaryStripCellValues = new Dictionary<int, Dictionary<ARC_HFTAlgo_HftAlgoProfileSummaryStrips, FormattedDouble>>();
			var stripProfiles = new Dictionary<int, ARC_HFTAlgo_DomProfile>();
			var absorptionRecordDirs = new Dictionary<int, int>();
			for (var i = Math.Max(0, ChartBars.FromIndex - CumDeltaLookback); i <= ChartBars.ToIndex; i++)
			{
				absorptionRecordDirs[i] = absorptionRecords
					.Where(r => i >= r.StartBar && i <= r.EndBar)
					.Select(r => r.Dir)
					.FirstOrDefault();

				var profile = GetSummaryStripDomProfile(i);
				if (profile == null || profile.Count == 0)
					continue;

				stripProfiles[i] = profile;
				summaryStripCellValues[i] = new Dictionary<ARC_HFTAlgo_HftAlgoProfileSummaryStrips, FormattedDouble>();

				if (i < ChartBars.FromIndex)
					continue;

				foreach (var s in renderedStrips)
				{
					summaryStripCellValues[i][s] = new FormattedDouble();
					switch (s)
					{
					case ARC_HFTAlgo_HftAlgoProfileSummaryStrips.Absorption:
						summaryStripCellValues[i][s].Format = "";
						summaryStripCellValues[i][s].Value = 0;
						break;
					case ARC_HFTAlgo_HftAlgoProfileSummaryStrips.State:
						summaryStripCellValues[i][s].Format = "";
						summaryStripCellValues[i][s].Value = 0;
						break;
					case ARC_HFTAlgo_HftAlgoProfileSummaryStrips.Delta:
						summaryStripCellValues[i][s].Format = "N0";
						summaryStripCellValues[i][s].Value = profile.NetDelta;
						break;
					case ARC_HFTAlgo_HftAlgoProfileSummaryStrips.CumDelta:
						summaryStripCellValues[i][s].Format = "N0";
						summaryStripCellValues[i][s].Value = profile.NetDelta;
						ARC_HFTAlgo_DomProfile dom;
						for (var i2 = i - 1; i2 >= Math.Max(0, i - CumDeltaLookback + 1); i2--)
							summaryStripCellValues[i][s].Value += stripProfiles.TryGetValue(i2, out dom) ? dom.NetDelta : 0;
						break;
					case ARC_HFTAlgo_HftAlgoProfileSummaryStrips.BidAskPercent:
						summaryStripCellValues[i][s].Format = "P1";
						summaryStripCellValues[i][s].Value = (profile.TotalAsk.ApproxCompare(profile.TotalBid) == 1 ? profile.TotalAsk : -profile.TotalBid) / profile.TotalVolume;
						break;
					case ARC_HFTAlgo_HftAlgoProfileSummaryStrips.DeltaPercent:
						summaryStripCellValues[i][s].Format = "P1";
						summaryStripCellValues[i][s].Value = profile.NetDelta / profile.TotalVolume;
						break;
					case ARC_HFTAlgo_HftAlgoProfileSummaryStrips.Volume:
						summaryStripCellValues[i][s].Format = "N0";
						summaryStripCellValues[i][s].Value = profile.TotalVolume;
						break;
					default:
						throw new ArgumentOutOfRangeException();
					}
				}
			}

			const float minCellFontSize = 5;
			var font = new SimpleFont("Consolas", 12);
			var stripStrings = summaryStripCellValues
				.SelectMany(d => d.Value.Values)
				.Select(s => s.ToString())
				.ToArray();
			font.Size = stripStrings.Length == 0 ? 1 : font.ARC_HFTAlgo_GetIdealFontSize(ChartPanel, new Size2F(cellsSize.Width * 0.8f, cellsSize.Height - 5), minCellFontSize, stripStrings);

			const float minHeaderFontSize = 3;
			var headerFont = new SimpleFont("Consolas", 12);
			headerFont.Size = Math.Max(headerFont.ARC_HFTAlgo_GetIdealFontSize(ChartPanel, new Size2F(cellsSize.Width - 5, cellsSize.Height - 5), minHeaderFontSize, renderedStrips.Select(GetSummaryHeaderText).ToArray()), 1);

			using (var defaultTextBrush = DomTextColor.ToDxBrush(RenderTarget))
			using (var cellNeutralBackingBrush = SummaryStripNeutralBackingColor.ToDxBrush(RenderTarget))
			using (var absorptionLongBrush = AbsorptionLongColor.ToDxBrush(RenderTarget))
			using (var absorptionShortBrush = AbsorptionShortColor.ToDxBrush(RenderTarget))
			using (var cellLongBackingBrush = SummaryStripLongBackingColor.ToDxBrush(RenderTarget))
			using (var cellShortBackingBrush = SummaryStripShortBackingColor.ToDxBrush(RenderTarget))
			using (var headerBackingBrush = SummaryStripHeaderColor.ToDxBrush(RenderTarget))
			using (var gridBrush = SummaryStripGridColor.ToDxBrush(RenderTarget))
			using (var cellTf = font.ToDirectWriteTextFormat())
			using (var headerTf = headerFont.ToDirectWriteTextFormat())
			{
				cellTf.ParagraphAlignment = ParagraphAlignment.Center;
				cellTf.WordWrapping = WordWrapping.NoWrap;
				cellTf.TextAlignment = TextAlignment.Center;

				headerTf.ParagraphAlignment = ParagraphAlignment.Far;
				headerTf.WordWrapping = WordWrapping.NoWrap;
				headerTf.TextAlignment = TextAlignment.Trailing;

				for (var barIdx = ChartBars.ToIndex; barIdx >= Math.Max(0, ChartBars.FromIndex - 1); barIdx--)
				for (int stripIdx = 0; stripIdx < renderedStrips.Length; stripIdx++)
				{
					var isHeader = barIdx == ChartBars.FromIndex;
					var barX = chartControl.GetXByBarIndex(ChartBars, barIdx);
					var vector = new Vector2
					{
						X = barX - cellsSize.Width / 2,
						Y = ChartPanel.H - cellsSize.Height * (stripIdx + 1)
					};
						
					if (isHeader)
					{
						RenderTarget.FillRectangle(new RectangleF(0, vector.Y, cellsSize.Width + (barX - cellsSize.Width / 2), cellsSize.Height), headerBackingBrush);
						var headerText = GetSummaryHeaderText(renderedStrips[stripIdx]);
						if (headerFont.Size > minHeaderFontSize && !string.IsNullOrWhiteSpace(headerText))
							using (var tl = new TextLayout(Globals.DirectWriteFactory, headerText, headerTf, cellsSize.Width - 5, cellsSize.Height))
								RenderTarget.DrawTextLayout(vector, tl, defaultTextBrush);
						continue;
					}

					if (barIdx < ChartBars.FromIndex)
						continue;

					ARC_HFTAlgo_DomProfile dom;
					if (!stripProfiles.TryGetValue(barIdx, out dom))
					{
						RenderTarget.FillRectangle(new RectangleF(barX - cellsSize.Width / 2, vector.Y, cellsSize.Width, cellsSize.Height), cellNeutralBackingBrush);
						RenderTarget.DrawRectangle(new RectangleF(barX - cellsSize.Width / 2, vector.Y, cellsSize.Width, cellsSize.Height), gridBrush);
						continue;
					}

					var cellValue = summaryStripCellValues[barIdx][renderedStrips[stripIdx]];
					SharpDX.Direct2D1.Brush backingBrush;
					if (renderedStrips[stripIdx] == ARC_HFTAlgo_HftAlgoProfileSummaryStrips.Volume || (renderedStrips[stripIdx] == ARC_HFTAlgo_HftAlgoProfileSummaryStrips.DeltaPercent && Math.Abs(cellValue.Value) < MinDeltaPercentForColor / 100))
					{
						backingBrush = cellNeutralBackingBrush;
					}
					else if (renderedStrips[stripIdx] == ARC_HFTAlgo_HftAlgoProfileSummaryStrips.Absorption)
					{
						var dir = absorptionRecordDirs[barIdx];
						if (dir == 0)
							backingBrush = cellNeutralBackingBrush;
						else
							backingBrush = dir == 1 ? absorptionLongBrush : absorptionShortBrush;
					}
					else if (renderedStrips[stripIdx] == ARC_HFTAlgo_HftAlgoProfileSummaryStrips.State)
					{
						var dir = dom.NetDelta.ApproxCompare(0);
						if (dir == 0 || dir != Closes[0].GetValueAt(barIdx).ApproxCompare(Opens[0].GetValueAt(barIdx)))
							backingBrush = cellNeutralBackingBrush;
						else
							backingBrush = dir == 1 ? cellLongBackingBrush : cellShortBackingBrush;
					}
					else
					{
						switch (cellValue.Value.ApproxCompare(0))
						{
						case -1:
							backingBrush = cellShortBackingBrush;
							break;
						case 0:
							backingBrush = cellNeutralBackingBrush;
							break;
						case 1:
							backingBrush = cellLongBackingBrush;
							break;
						default:
							throw new ArgumentOutOfRangeException();
						}
					}

					RenderTarget.FillRectangle(new RectangleF(barX - cellsSize.Width / 2, vector.Y, cellsSize.Width, cellsSize.Height), backingBrush);
					RenderTarget.DrawRectangle(new RectangleF(barX - cellsSize.Width / 2, vector.Y, cellsSize.Width, cellsSize.Height), gridBrush);

					var cellText = cellValue.Value.ToString(cellValue.Format);
					if (renderedStrips[stripIdx] == ARC_HFTAlgo_HftAlgoProfileSummaryStrips.Absorption || renderedStrips[stripIdx] == ARC_HFTAlgo_HftAlgoProfileSummaryStrips.State || font.Size <= minCellFontSize || string.IsNullOrWhiteSpace(cellText))
						continue;

					using (var tl = new TextLayout(Globals.DirectWriteFactory, cellText, cellTf, cellsSize.Width, cellsSize.Height))
						RenderTarget.DrawTextLayout(vector, tl, defaultTextBrush);
				}
			}
		}

		private enum SignalLabelShape
		{
			Triangle,
			Diamond
		}

		private void RenderSignalLabel(ChartControl chartControl, ChartScale chartScale, int barIdx, int shapeDir, int textSide, SignalLabelShape shape, double price, int yOffset, out double height, params ARC_HFTAlgo_HftAlgoSignalType[] signals)
		{
			RenderSignalLabel(chartControl, barIdx, shapeDir, textSide, shape, chartScale.GetYByValue(price) + shapeDir * yOffset, out height, signals);
		}

		private void RenderSignalLabel(ChartControl chartControl, int barIdx, int shapeDir, int textSide, SignalLabelShape shape, int y, out double height, params ARC_HFTAlgo_HftAlgoSignalType[] signals)
		{
			// Draw signal text and arrows
			const float minSignalFontSize = 5;
			var barWidth = chartControl.GetBarPaintWidth(ChartBars);
			var font = new SimpleFont("Consolas", 12);

			var priorAaMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = AntialiasMode.Aliased;
			try
			{
				var labels = signals
					.Select(s =>
					{
						switch (s)
						{
						case ARC_HFTAlgo_HftAlgoSignalType.DeltaDivergence:
							return "DD";
						case ARC_HFTAlgo_HftAlgoSignalType.TrappedTraders:
							return "TT";
						case ARC_HFTAlgo_HftAlgoSignalType.StackedImbalance:
							return "SI";
						case ARC_HFTAlgo_HftAlgoSignalType.FlushReversal:
							return "FR";
						case ARC_HFTAlgo_HftAlgoSignalType.Confluence:
							return "CO";
						default:
							throw new ArgumentOutOfRangeException("s", s, null);
						}
					})
					.ToArray();

				var idealSize = new Size2F { Width = Math.Max(0, Math.Min(25, barWidth + chartControl.Properties.BarDistance)), Height = float.MaxValue };
				font.Size = font.ARC_HFTAlgo_GetIdealFontSize(ChartPanel, idealSize, minSignalFontSize, labels) + 0.1;
				var label = string.Join(Environment.NewLine, labels).Trim();
				var textSize = font.ARC_HFTAlgo_GetTextSize(ChartPanel, label);
				var vector = new Vector2(chartControl.GetXByBarIndex(ChartBars, barIdx) - textSize.Width / 2, y);

				using (var shortBrush = ShortLabelColor.ToDxBrush(RenderTarget))
				using (var longBrush = LongLabelColor.ToDxBrush(RenderTarget))
				using (var outlineBrush = Brushes.Black.ToDxBrush(RenderTarget))
				{
					var brush = shapeDir == 1 ? longBrush : shortBrush;

					// Draw an entry marker
					if (shape == SignalLabelShape.Triangle)
						RenderTarget.ARC_HFTAlgo_DrawTriangle(new Point(chartControl.GetXByBarIndex(ChartBars, barIdx), vector.Y), idealSize.Width, outlineBrush, 1, shapeDir, brush);
					else
						RenderTarget.ARC_HFTAlgo_DrawDiamond(new Point(chartControl.GetXByBarIndex(ChartBars, barIdx), vector.Y), idealSize.Width / 2, brush, outlineBrush);

					// Draw the setup labels
					using (var tf = font.ToDirectWriteTextFormat())
					{
						tf.ParagraphAlignment = shapeDir == 1 ? ParagraphAlignment.Near : ParagraphAlignment.Far;
						tf.TextAlignment = TextAlignment.Center;
						tf.WordWrapping = WordWrapping.NoWrap;
						tf.SetLineSpacing(LineSpacingMethod.Default, 0, 0);

						using (var tl = new TextLayout(Globals.DirectWriteFactory, label, tf, textSize.Width, textSize.Height))
						{
							tl.ParagraphAlignment = tf.ParagraphAlignment;
							tl.TextAlignment = tf.TextAlignment;
							var offset = new Vector2(0, (textSide == 1 ? 0 : -textSize.Height) + textSide * (idealSize.Width / 2 + 5));
							height = textSize.Height * 1.5f + idealSize.Width / 2 + 5;
							RenderTarget.DrawTextLayout(vector + offset, tl, brush);
						}
					}
				}
			}
			finally
			{
				RenderTarget.AntialiasMode = priorAaMode;
			}
		}

		private void RenderSignalLabels(ChartControl chartControl, ChartScale chartScale)
		{
			for (var i = ChartBars.FromIndex; i <= ChartBars.ToIndex; i++)
			{
				var barCloseDom = i == ChartBars.Count - 1 ? domTracker.RenderThreadSafeLeveledBarProfile : profiles.GetValueAt(i);
				if (barCloseDom == null)
					continue;

				var record = entryRenderRecords.FirstOrDefault(r => r.SignalDom.ParentId == barCloseDom.ParentId);
				if (record == null)
					continue;

				var groups = record.Signals
					.GroupBy(s => s == ARC_HFTAlgo_HftAlgoSignalType.Confluence)
					.OrderBy(g => g.Key)
					.Select(s => s.ToArray())
					.ToArray();

				double labelHeight;

				// Render the confluence signals
				var yOffset = SignalLabelDistance;
				if (groups.Any(g => g.Contains(ARC_HFTAlgo_HftAlgoSignalType.Confluence)))
				{
					RenderSignalLabel(chartControl, chartScale, i, record.Dir, record.Dir, SignalLabelShape.Diamond, (record.Dir == 1 ? Lows : Highs)[0].GetValueAt(i), yOffset, out labelHeight, ARC_HFTAlgo_HftAlgoSignalType.Confluence);
					yOffset += (int)labelHeight + 5;
				}

				// Render the normal signals
				if (groups.Any(g => !g.Contains(ARC_HFTAlgo_HftAlgoSignalType.Confluence)))
				{
					RenderSignalLabel(chartControl, chartScale, i, record.Dir, record.Dir, SignalLabelShape.Triangle, (record.Dir == 1 ? Lows : Highs)[0].GetValueAt(i), yOffset, out labelHeight, record.Signals.Where(s => s != ARC_HFTAlgo_HftAlgoSignalType.Confluence).ToArray());
					yOffset += (int)labelHeight + 5;
				}
			}
		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			if (State != State.Realtime && State != State.Terminated)
				return;

			if (!this.ARC_HFTAlgo_IsLicensed())
				return;

			RenderProfiles(chartControl, chartScale);
			RenderSignalLabels(chartControl, chartScale);
			RenderSummaryStrips(chartControl);
		}
		#endregion

		#region Properties
		#region Parameters
		private readonly ARC_HFTAlgo_DefaultingDictionary<ARC_HFTAlgo_HftAlgoSignalType, ARC_HFTAlgo_HftAlgoSignalToggleState> signalToggleStates = new ARC_HFTAlgo_DefaultingDictionary<ARC_HFTAlgo_HftAlgoSignalType, ARC_HFTAlgo_HftAlgoSignalToggleState>(ARC_HFTAlgo_HftAlgoSignalToggleState.On);
		private readonly ARC_HFTAlgo_DefaultingDictionary<ARC_HFTAlgo_HftAlgoSignalType, bool> barDirectionRequired = new ARC_HFTAlgo_DefaultingDictionary<ARC_HFTAlgo_HftAlgoSignalType, bool>(t => t != ARC_HFTAlgo_HftAlgoSignalType.StackedImbalance);

		[NinjaScriptProperty, RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Trapped Trader Signals", Order = 0, GroupName = StrategyParameterGroupName)]
		public ARC_HFTAlgo_HftAlgoSignalToggleState TrappedTradersSignalMode
		{
			get { return signalToggleStates[ARC_HFTAlgo_HftAlgoSignalType.TrappedTraders]; } 
			set { signalToggleStates[ARC_HFTAlgo_HftAlgoSignalType.TrappedTraders] = value; }
		}
		
		[NinjaScriptProperty, Range(2, int.MaxValue)]
		[ARC_HFTAlgo_HideUnless("TrappedTradersSignalMode", ARC_HFTAlgo_PropComparisonType.NEQ, ARC_HFTAlgo_HftAlgoSignalToggleState.Off)]
		[Display(Name = "Min Trapped Trader Levels", Order = 1, GroupName = StrategyParameterGroupName)]
		public int MinTrappedTraderLevels { get; set; }
		
		[NinjaScriptProperty]
		[ARC_HFTAlgo_HideUnless("TrappedTradersSignalMode", ARC_HFTAlgo_PropComparisonType.NEQ, ARC_HFTAlgo_HftAlgoSignalToggleState.Off)]
		[Display(Name = "High/Low Range Filter", Order = 2, GroupName = StrategyParameterGroupName)]
		public bool UseHighLowRangeFilter { get; set; }
		
		[NinjaScriptProperty]
		[ARC_HFTAlgo_HideUnless("TrappedTradersSignalMode", ARC_HFTAlgo_PropComparisonType.NEQ, ARC_HFTAlgo_HftAlgoSignalToggleState.Off)]
		[Display(Name = "Require Bar Direction for TT Signals", Order = 3, GroupName = StrategyParameterGroupName)]
		public bool BarDirectionRequiredTrappedTraders
		{
			get { return barDirectionRequired[ARC_HFTAlgo_HftAlgoSignalType.TrappedTraders]; } 
			set { barDirectionRequired[ARC_HFTAlgo_HftAlgoSignalType.TrappedTraders] = value; }
		}

		[NinjaScriptProperty, RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Stacked Imbalance Signals", Order = 4, GroupName = StrategyParameterGroupName)]
		public ARC_HFTAlgo_HftAlgoSignalToggleState StackedImbalanceSignalMode
		{
			get { return signalToggleStates[ARC_HFTAlgo_HftAlgoSignalType.StackedImbalance]; } 
			set { signalToggleStates[ARC_HFTAlgo_HftAlgoSignalType.StackedImbalance] = value; }
		}

		[NinjaScriptProperty, Range(0, 100)]
		[ARC_HFTAlgo_HideUnless("StackedImbalanceSignalMode", ARC_HFTAlgo_PropComparisonType.NEQ, ARC_HFTAlgo_HftAlgoSignalToggleState.Off)]
		[Display(Name = "Min. Imbalance %", Order = 5, GroupName = StrategyParameterGroupName, Description = "The minimum size of the imbalance (larger - smaller) as a percent of the entire candles volume")]
		public int MinImbalancePercent { get; set; }

		[NinjaScriptProperty, Range(0, double.MaxValue)]
		[ARC_HFTAlgo_HideUnless("StackedImbalanceSignalMode", ARC_HFTAlgo_PropComparisonType.NEQ, ARC_HFTAlgo_HftAlgoSignalToggleState.Off)]
		[Display(Name = "Min. Imbalance Multiplier", Order = 6, GroupName = StrategyParameterGroupName)]
		public double ImbalanceMultiplier { get; set; }

		[NinjaScriptProperty]
		[ARC_HFTAlgo_HideUnless("StackedImbalanceSignalMode", ARC_HFTAlgo_PropComparisonType.NEQ, ARC_HFTAlgo_HftAlgoSignalToggleState.Off)]
		[Display(Name = "Imbalance Calculation Mode", Order = 7, GroupName = StrategyParameterGroupName)]
		public ARC_HFTAlgo_ImbalanceCalculationMode ImbalanceCalculationMode { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[ARC_HFTAlgo_HideUnless("StackedImbalanceSignalMode", ARC_HFTAlgo_PropComparisonType.NEQ, ARC_HFTAlgo_HftAlgoSignalToggleState.Off)]
		[Display(Name = "Min. Stacked Imbalances", Order = 8, GroupName = StrategyParameterGroupName)]
		public int MinStackedImbalances { get; set; }

		[NinjaScriptProperty, RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Delta Divergence Signals", Order = 9, GroupName = StrategyParameterGroupName, Description = "Price is the highest high for the past n bars, and delta is lower then prior")]
		public ARC_HFTAlgo_HftAlgoSignalToggleState DeltaDivergenceSignalMode
		{
			get { return signalToggleStates[ARC_HFTAlgo_HftAlgoSignalType.DeltaDivergence]; } 
			set { signalToggleStates[ARC_HFTAlgo_HftAlgoSignalType.DeltaDivergence] = value; }
		}

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[ARC_HFTAlgo_HideUnless("DeltaDivergenceSignalMode", ARC_HFTAlgo_PropComparisonType.NEQ, ARC_HFTAlgo_HftAlgoSignalToggleState.Off)]
		[Display(Name = "Delta Divergence Lookback", Order = 10, GroupName = StrategyParameterGroupName)]
		public int DeltaDivergenceLookback { get; set; }

		[NinjaScriptProperty]
		[ARC_HFTAlgo_HideUnless("DeltaDivergenceSignalMode", ARC_HFTAlgo_PropComparisonType.NEQ, ARC_HFTAlgo_HftAlgoSignalToggleState.Off)]
		[Display(Name = "Require Bar Direction for DD Signals", Order = 11, GroupName = StrategyParameterGroupName)]
		public bool BarDirectionRequiredDeltaDivergence
		{
			get { return barDirectionRequired[ARC_HFTAlgo_HftAlgoSignalType.DeltaDivergence]; } 
			set { barDirectionRequired[ARC_HFTAlgo_HftAlgoSignalType.DeltaDivergence] = value; }
		}

		[NinjaScriptProperty, RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Confluence Signals", Order = 12, GroupName = StrategyParameterGroupName)]
		public ARC_HFTAlgo_HftAlgoSignalToggleState ConfluenceSignalMode
		{
			get { return signalToggleStates[ARC_HFTAlgo_HftAlgoSignalType.Confluence]; } 
			set { signalToggleStates[ARC_HFTAlgo_HftAlgoSignalType.Confluence] = value; }
		}

		[NinjaScriptProperty]
		[Display(Name = "Cum. Delta Lookback", Order = 13, GroupName = StrategyParameterGroupName)]
		public int CumDeltaLookback { get; set; }
		
		[NinjaScriptProperty]
		[Range(0, 100)]
		[Display(Name = "Min Delta % for Cell Coloring", Order = 14, GroupName = StrategyParameterGroupName)]
		public double MinDeltaPercentForColor { get; set; }

		[NinjaScriptProperty, RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Flush Reversal Signals", Order = 15, GroupName = StrategyParameterGroupName)]
		public ARC_HFTAlgo_HftAlgoSignalToggleState FlushReversalSignalMode
		{
			get { return signalToggleStates[ARC_HFTAlgo_HftAlgoSignalType.FlushReversal]; } 
			set { signalToggleStates[ARC_HFTAlgo_HftAlgoSignalType.FlushReversal] = value; }
		}

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Ticks Per Level", Order = 100, GroupName = StrategyParameterGroupName)]
		public int TicksPerDomLevel { get; set; }

		/// <summary>
		/// NOTE: This isn't marked as a script property on purpose, since that would allow users to optimize for it, which would prevent us from loading Bid/Ask series based on the setting
		/// </summary>
		[Display(Name = "Bid Ask Calculation Mode", Order = 101, GroupName = StrategyParameterGroupName)]
		public ARC_HFTAlgo_BidAskVolumeCalculationMode BidAskCalculationMode { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Check for Delta Congruity", Order = 102, GroupName = StrategyParameterGroupName)]
		public bool CheckDeltaCongruence { get; set; }

		[NinjaScriptProperty, Range(1, 3)]
		[Display(Name = "Min Combined Signals", Order = 103, GroupName = StrategyParameterGroupName)]
		public int MinConfluentSignals { get; set; }

		[NinjaScriptProperty, RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Signal Bar Size Threshold Type", Order = 104, GroupName = StrategyParameterGroupName)]
		public ARC_HFTAlgo_HftAlgoSignalBarThreshType SignalBarThreshType { get; set; }

		[NinjaScriptProperty, Range(0, double.MaxValue)]
		[ARC_HFTAlgo_HideUnless("SignalBarThreshType", ARC_HFTAlgo_PropComparisonType.NEQ, ARC_HFTAlgo_HftAlgoSignalBarThreshType.None)]
		[ARC_HFTAlgo_Rename("Min Signal Bar Size (Tick Count)", "SignalBarThreshType", ARC_HFTAlgo_PropComparisonType.EQ, ARC_HFTAlgo_HftAlgoSignalBarThreshType.TickCount)]
		[ARC_HFTAlgo_Rename("Min Signal Bar Size (Price in Ticks)", "SignalBarThreshType", ARC_HFTAlgo_PropComparisonType.EQ, ARC_HFTAlgo_HftAlgoSignalBarThreshType.Price)]
		[ARC_HFTAlgo_Rename("Min Signal Bar Size (Volume)", "SignalBarThreshType", ARC_HFTAlgo_PropComparisonType.EQ, ARC_HFTAlgo_HftAlgoSignalBarThreshType.Volume)]
		[Display(Name = "Min Signal Bar Size", Order = 105, GroupName = StrategyParameterGroupName)]
		public double SignalBarThresh { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Entry Time", Order = 106, GroupName = StrategyParameterGroupName)]
		public ARC_HFTAlgo_HftAlgoEntryTime EntryTimeType { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Volume Divisor", Order = 107, GroupName = StrategyParameterGroupName, Description = "The number to divide all displayed volumes by")]
		public int VolumeDivisor { get; set; }
		#endregion

		#region Visauls
		#region DOM
		[Display(Name = "Show Non Trade Bar Doms", Order = 0, GroupName = StrategyVisualsParameterGroupName)]
		public bool PaintNonTradeBarDoms { get; set; }

		[Display(Name = "Freeze DOM on Signal", Order = 1, GroupName = StrategyVisualsParameterGroupName)]
		[ARC_HFTAlgo_HideUnless("EntryTimeType", ARC_HFTAlgo_PropComparisonType.EQ, ARC_HFTAlgo_HftAlgoEntryTime.Intrabar)]
		public bool FreezeDomOnSignal { get; set; }

		[XmlIgnore]
		[Display(Name = "Text", Order = 2, GroupName = StrategyVisualsParameterGroupName)]
		public Brush DomTextColor { get; set; }

		[Browsable(false)]
		public string DomTextColorSerialize
		{
			get { return Serialize.BrushToString(DomTextColor); }
			set { DomTextColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bid Imbalance/Delta Color", Order = 3, GroupName = StrategyVisualsParameterGroupName)]
		public Brush BidImbalanceColor { get; set; }

		[Browsable(false)]
		public string BidImbalanceColorSerialize
		{
			get { return Serialize.BrushToString(BidImbalanceColor); }
			set { BidImbalanceColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Ask Imbalance/Delta Color", Order = 4, GroupName = StrategyVisualsParameterGroupName)]
		public Brush AskImbalanceColor { get; set; }

		[Browsable(false)]
		public string AskImbalanceColorSerialize
		{
			get { return Serialize.BrushToString(AskImbalanceColor); }
			set { AskImbalanceColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Short Label Color", Order = 5, GroupName = StrategyVisualsParameterGroupName)]
		public Brush ShortLabelColor { get; set; }

		[Browsable(false)]
		public string ShortLabelColorSerialize
		{
			get { return Serialize.BrushToString(ShortLabelColor); }
			set { ShortLabelColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Long Label Color", Order = 6, GroupName = StrategyVisualsParameterGroupName)]
		public Brush LongLabelColor { get; set; }

		[Browsable(false)]
		public string LongLabelColorSerialize
		{
			get { return Serialize.BrushToString(LongLabelColor); }
			set { LongLabelColor = Serialize.StringToBrush(value); }
		}

		[Range(0, int.MaxValue)]
		[Display(Name = "Signal Label Offset (Pixels)", Order = 7, GroupName = StrategyVisualsParameterGroupName)]
		public int SignalLabelDistance { get; set; }
		
		[Display(Name = "Show Delta Label Above Bars", Order = 8, GroupName = StrategyVisualsParameterGroupName)]
		[XmlElement("ShowNetDelta")]
		public bool ShowNetDeltaAboveBars { get; set; }

		[ARC_HFTAlgo_HideUnless("ShowNetDeltaAboveBars", ARC_HFTAlgo_PropComparisonType.EQ, true)]
		[Range(0, int.MaxValue)]
		[Display(Name = "Delta Label Offset (Pixels)", Order = 9, GroupName = StrategyVisualsParameterGroupName)]
		public int DeltaLabelDistance { get; set; }
		#endregion

		#region Summary Strip
		private readonly ARC_HFTAlgo_DefaultingDictionary<ARC_HFTAlgo_HftAlgoProfileSummaryStrips, bool> enabledStrips = new ARC_HFTAlgo_DefaultingDictionary<ARC_HFTAlgo_HftAlgoProfileSummaryStrips, bool>(true);

		[Display(Name = "Freeze Summary Strip on Signal", Order = 100, GroupName = StrategyVisualsParameterGroupName)]
		[ARC_HFTAlgo_HideUnless("EntryTimeType", ARC_HFTAlgo_PropComparisonType.EQ, ARC_HFTAlgo_HftAlgoEntryTime.Intrabar)]
		public bool FreezeSummaryStripOnSignal { get; set; }

		[Display(Name = "Show Absorption Strip", Order = 200, GroupName = StrategyVisualsParameterGroupName)]
		public bool ShowAbsorptionStrip 
		{
			get { return enabledStrips[ARC_HFTAlgo_HftAlgoProfileSummaryStrips.Absorption]; }
			set { enabledStrips[ARC_HFTAlgo_HftAlgoProfileSummaryStrips.Absorption] = value; }
		}

		[Display(Name = "Show State Strip", Order = 201, GroupName = StrategyVisualsParameterGroupName)]
		public bool ShowStateStrip 
		{
			get { return enabledStrips[ARC_HFTAlgo_HftAlgoProfileSummaryStrips.State]; }
			set { enabledStrips[ARC_HFTAlgo_HftAlgoProfileSummaryStrips.State] = value; }
		}

		[Display(Name = "Show Net Delta Strip", Order = 202, GroupName = StrategyVisualsParameterGroupName)]
		public bool ShowDeltaStrip 
		{
			get { return enabledStrips[ARC_HFTAlgo_HftAlgoProfileSummaryStrips.Delta]; }
			set { enabledStrips[ARC_HFTAlgo_HftAlgoProfileSummaryStrips.Delta] = value; }
		}
		
		[Display(Name = "Show Cum. Net Delta Strip", Order = 203, GroupName = StrategyVisualsParameterGroupName)]
		public bool ShowCumDeltaStrip 
		{
			get { return enabledStrips[ARC_HFTAlgo_HftAlgoProfileSummaryStrips.CumDelta]; }
			set { enabledStrips[ARC_HFTAlgo_HftAlgoProfileSummaryStrips.CumDelta] = value; }
		}
		
		[Display(Name = "Show Bid Ask % Strip", Order = 204, GroupName = StrategyVisualsParameterGroupName)]
		public bool ShowBidAskPercentStrip 
		{
			get { return enabledStrips[ARC_HFTAlgo_HftAlgoProfileSummaryStrips.BidAskPercent]; }
			set { enabledStrips[ARC_HFTAlgo_HftAlgoProfileSummaryStrips.BidAskPercent] = value; }
		}

		[Display(Name = "Show Delta % Strip", Order = 205, GroupName = StrategyVisualsParameterGroupName)]
		public bool ShowDeltaPercentStrip
		{
			get { return enabledStrips[ARC_HFTAlgo_HftAlgoProfileSummaryStrips.DeltaPercent]; }
			set { enabledStrips[ARC_HFTAlgo_HftAlgoProfileSummaryStrips.DeltaPercent] = value; }
		}

		[Display(Name = "Show Volume Strip", Order = 206, GroupName = StrategyVisualsParameterGroupName)]
		public bool ShowVolumeStrip 
		{
			get { return enabledStrips[ARC_HFTAlgo_HftAlgoProfileSummaryStrips.Volume]; }
			set { enabledStrips[ARC_HFTAlgo_HftAlgoProfileSummaryStrips.Volume] = value; }
		}

		[XmlIgnore]
		[Display(Name = "Summary Strip Grid Color", Order = 300, GroupName = StrategyVisualsParameterGroupName)]
		public Brush SummaryStripGridColor { get; set; }

		[Browsable(false)]
		public string SummaryStripGridColorSerialize
		{
			get { return Serialize.BrushToString(SummaryStripGridColor); }
			set { SummaryStripGridColor = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(Name = "Summary Strip Neutral Backing Color", Order = 301, GroupName = StrategyVisualsParameterGroupName)]
		public Brush SummaryStripNeutralBackingColor { get; set; }

		[Browsable(false)]
		public string SummaryStripNeutralBackingColorSerialize
		{
			get { return Serialize.BrushToString(SummaryStripNeutralBackingColor); }
			set { SummaryStripNeutralBackingColor = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(Name = "Summary Strip Long Backing Color", Order = 302, GroupName = StrategyVisualsParameterGroupName)]
		public Brush SummaryStripLongBackingColor { get; set; }

		[Browsable(false)]
		public string SummaryStripLongBackingColorSerialize
		{
			get { return Serialize.BrushToString(SummaryStripLongBackingColor); }
			set { SummaryStripLongBackingColor = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(Name = "Summary Strip Short Backing Color", Order = 303, GroupName = StrategyVisualsParameterGroupName)]
		public Brush SummaryStripShortBackingColor { get; set; }

		[Browsable(false)]
		public string SummaryStripShortBackingColorSerialize
		{
			get { return Serialize.BrushToString(SummaryStripShortBackingColor); }
			set { SummaryStripShortBackingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Summary Strip Header Color", Order = 304, GroupName = StrategyVisualsParameterGroupName)]
		public Brush SummaryStripHeaderColor { get; set; }

		[Browsable(false)]
		public string SummaryStripHeaderColorSerialize
		{
			get { return Serialize.BrushToString(SummaryStripHeaderColor); }
			set { SummaryStripHeaderColor = Serialize.StringToBrush(value); }
		}
		#endregion

		#region Absorption 
		[Display(Name = "Show Absorption Backgrounds", Order = 400, GroupName = StrategyVisualsParameterGroupName)]
		public bool ShowAbsorptionBackgrounds { get; set; }
		
		[Range(1, int.MaxValue)]
		[Display(Name = "Absorption Lookback", Order = 401, GroupName = StrategyVisualsParameterGroupName)]
		public int AbsorptionLookback { get; set; }
		
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Absorption Max Excursion Type", Order = 402, GroupName = StrategyVisualsParameterGroupName)]
		public ARC_HFTAlgo_MaxAbsorptionExcursionType MaxAbsorptionExcursionType { get; set; }
		
		[Range(1, int.MaxValue)]
		[ARC_HFTAlgo_HideUnless("MaxAbsorptionExcursionType", ARC_HFTAlgo_PropComparisonType.EQ, ARC_HFTAlgo_MaxAbsorptionExcursionType.ATR)]
		[Display(Name = "Absorption ATR Period", Order = 403, GroupName = StrategyVisualsParameterGroupName)]
		public int AbsorptionAtrPeriod { get; set; }
		
		[Range(double.Epsilon, double.MaxValue)]
		[ARC_HFTAlgo_Rename("Absorption Max Excursion ATR Mult.", "MaxAbsorptionExcursionType", ARC_HFTAlgo_PropComparisonType.EQ, ARC_HFTAlgo_MaxAbsorptionExcursionType.ATR)]
		[ARC_HFTAlgo_Rename("Absorption Max Excursion Ticks Dist.", "MaxAbsorptionExcursionType", ARC_HFTAlgo_PropComparisonType.EQ, ARC_HFTAlgo_MaxAbsorptionExcursionType.Tick)]
		[Display(Name = "Absorption ATR Mult.", Order = 404, GroupName = StrategyVisualsParameterGroupName)]
		public double MaxAbsorptionExcursionValue { get; set; }

		[XmlIgnore]
		[Display(Name = "Absorption Long Color", Order = 405, GroupName = StrategyVisualsParameterGroupName)]
		public Brush AbsorptionLongColor { get; set; }

		[Browsable(false)]
		public string AbsorptionLongColorSerialize
		{
			get { return Serialize.BrushToString(AbsorptionLongColor); }
			set { AbsorptionLongColor = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(Name = "Absorption Short Color", Order = 406, GroupName = StrategyVisualsParameterGroupName)]
		public Brush AbsorptionShortColor { get; set; }

		[Browsable(false)]
		public string AbsorptionShortColorSerialize
		{
			get { return Serialize.BrushToString(AbsorptionShortColor); }
			set { AbsorptionShortColor = Serialize.StringToBrush(value); }
		}
		#endregion
		#endregion
		#endregion
	}

	public enum ARC_HFTAlgo_MaxAbsorptionExcursionType
	{
		Tick,
		ATR
	}

	public enum ARC_HFTAlgo_HftAlgoProfileSummaryStrips
	{
		Absorption = 0,
		State = 1,
		Delta = 2,
		CumDelta = 3,
		BidAskPercent = 4,
		DeltaPercent = 5,
		Volume = 6
	}

	public enum ARC_HFTAlgo_HftAlgoEntryTime
	{
		Intrabar,
		BarClose
	}
	
	public enum ARC_HFTAlgo_HftAlgoSignalType
	{
		DeltaDivergence,
		TrappedTraders,
		StackedImbalance,
		FlushReversal,
		Confluence
	}
	
	public enum ARC_HFTAlgo_HftAlgoSignalToggleState
	{
		Off,
		On,
		Required
	}

	public enum ARC_HFTAlgo_HftAlgoSignalBarThreshType
	{
		None,
		TickCount,
		Price,
		Volume
	}
}