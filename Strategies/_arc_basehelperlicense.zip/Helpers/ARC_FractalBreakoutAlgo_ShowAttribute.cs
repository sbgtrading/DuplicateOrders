﻿using System;
using System.Linq;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	/// <summary>
	/// Used to show properties when the value of this one matches the provided value
	/// </summary>
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
	public class ARC_FractalBreakoutAlgo_ShowOthersIfAttribute : ARC_FractalBreakoutAlgo_SelfReferencingConditionalAttributeBase
	{
		/// <summary>
		/// The affected Properties
		/// </summary>
		public string[] Properties { get; set; }

		/// <summary>
		/// The affected Group
		/// </summary>
		public string[] Groups { get; set; }

		public ARC_FractalBreakoutAlgo_ShowOthersIfAttribute(ARC_FractalBreakoutAlgo_PropComparisonType compareType, params object[] args) : base(compareType, args)
		{
			Properties = Array.Empty<string>();
			Groups = Array.Empty<string>();
		}

		public ARC_FractalBreakoutAlgo_ShowOthersIfAttribute(ARC_FractalBreakoutAlgo_ShowOthersIfAttribute attr) : base(attr)
		{ }

		public override object Clone()
		{
			return new ARC_FractalBreakoutAlgo_ShowOthersIfAttribute(this);
		}

		public override ARC_FractalBreakoutAlgo_IReferencesPropsByName TransformPropNames(Func<string, string> transform)
		{
			var newAttr = (ARC_FractalBreakoutAlgo_ShowOthersIfAttribute) Clone();
			newAttr.Properties = Properties
				.Select(transform)
				.ToArray();
			return newAttr;
		}
	}

	/// <summary>
	/// Used to show this property when the value of the target matches the provided value
	/// </summary>
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
	public class ARC_FractalBreakoutAlgo_ShowIfAttribute : ARC_FractalBreakoutAlgo_ReferentialConditionalAttributeBase
	{
		public ARC_FractalBreakoutAlgo_ShowIfAttribute(string conditionPropName, ARC_FractalBreakoutAlgo_PropComparisonType compareType, params object[] args) : base(conditionPropName, compareType, args)
		{ }

		public ARC_FractalBreakoutAlgo_ShowIfAttribute(ARC_FractalBreakoutAlgo_ShowIfAttribute attr) : base(attr)
		{ }

		public override object Clone()
		{
			return new ARC_FractalBreakoutAlgo_ShowIfAttribute(this);
		}
	}
}