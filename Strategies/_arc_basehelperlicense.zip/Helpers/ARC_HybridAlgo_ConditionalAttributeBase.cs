﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	public abstract class ARC_HybridAlgo_ConditionalAttributeBase : Attribute, ARC_HybridAlgo_IReferencesPropsByName
	{
		public override object TypeId { get { return args.GetHashCode() + compareType.GetHashCode(); } }
		private bool IsSingleNumCompare { get { return compareType == ARC_HybridAlgo_PropComparisonType.GT || compareType == ARC_HybridAlgo_PropComparisonType.GTE || compareType == ARC_HybridAlgo_PropComparisonType.LT || compareType == ARC_HybridAlgo_PropComparisonType.LTE; } }
		private bool IsDualNumCompare { get { return compareType == ARC_HybridAlgo_PropComparisonType.Between || compareType == ARC_HybridAlgo_PropComparisonType.NotBetween; } }
		private readonly ARC_HybridAlgo_PropComparisonType compareType;
		private readonly object[] args;
		protected ARC_HybridAlgo_ConditionalAttributeBase(ARC_HybridAlgo_PropComparisonType compareType, params object[] args)
		{
			if (args.Length == 0)
				throw new ArgumentException("Attribute requires at least one value for any comparison type!");
				
			this.args = args;
			this.compareType = compareType;

			if ((IsSingleNumCompare || IsDualNumCompare) && args.Any(a => !(a is IComparable)))
				throw new ArgumentException("In numeric comparison, args must all be comparable");
			if (IsSingleNumCompare && args.Length != 1)
				throw new ArgumentException("Comparison requires one input!");
			if (IsDualNumCompare && args.Length != 2)
				throw new ArgumentException("Comparison requires two inputs!");
		}

		protected ARC_HybridAlgo_ConditionalAttributeBase(ARC_HybridAlgo_ConditionalAttributeBase attr)
		{
			args = attr.args;
			compareType = attr.compareType;
		}

		public bool MatchesCriteria(object value)
		{
			switch (compareType)
			{
			case ARC_HybridAlgo_PropComparisonType.EQ:
				return Equals(value, args[0]);
			case ARC_HybridAlgo_PropComparisonType.NEQ:
				return !Equals(value, args[0]);
			case ARC_HybridAlgo_PropComparisonType.IsOneOf:
				return args.Any(a => Equals(value, a));
			case ARC_HybridAlgo_PropComparisonType.IsNotOneOf:
				return args.All(a => !Equals(value, a));
			}

			var cVal = value as IComparable;
			if (cVal == null)
				throw new ArgumentException("Argument must be comparable for numeric comparison to work!");

			var comparisons = args.OfType<IComparable>().Select(c => cVal.CompareTo(c)).ToArray();
			switch (compareType)
			{
			case ARC_HybridAlgo_PropComparisonType.Between:
				return comparisons[0] > 0 && comparisons[1] < 0;
			case ARC_HybridAlgo_PropComparisonType.NotBetween:
				return comparisons[0] < 0 || comparisons[1] > 0;
			case ARC_HybridAlgo_PropComparisonType.LT:
				return comparisons[0] < 0;
			case ARC_HybridAlgo_PropComparisonType.GT:
				return comparisons[0] > 0;
			case ARC_HybridAlgo_PropComparisonType.LTE:
				return comparisons[0] <= 0;
			case ARC_HybridAlgo_PropComparisonType.GTE:
				return comparisons[0] >= 0;
			default:
				throw new ArgumentOutOfRangeException();
			}
		}

		public abstract object Clone();

		public abstract ARC_HybridAlgo_IReferencesPropsByName TransformPropNames(Func<string, string> transform);
	}

	/// <summary>
	/// Base class for conditional attributes that reference other parameters
	/// </summary>
	public abstract class ARC_HybridAlgo_ReferentialConditionalAttributeBase : ARC_HybridAlgo_ConditionalAttributeBase
	{
		public override object TypeId { get { return base.TypeId.GetHashCode() + ConditionPropName.GetHashCode(); } }
		public string ConditionPropName { get; private set; }

		/// <param name="conditionPropName">Prefix the name with "." to compare to reference a property of the parent class from within a flattened child class.</param>
		/// <param name="compareType"></param>
		/// <param name="args"></param>
		protected ARC_HybridAlgo_ReferentialConditionalAttributeBase(string conditionPropName, ARC_HybridAlgo_PropComparisonType compareType, params object[] args) : base(compareType, args)
		{
			ConditionPropName = conditionPropName;
		}
		
		protected ARC_HybridAlgo_ReferentialConditionalAttributeBase(ARC_HybridAlgo_ReferentialConditionalAttributeBase attr) : base(attr)
		{
			ConditionPropName = attr.ConditionPropName;
		}

		public override ARC_HybridAlgo_IReferencesPropsByName TransformPropNames(Func<string, string> transform)
		{
			var newAttr = (ARC_HybridAlgo_ReferentialConditionalAttributeBase) Clone();
			newAttr.ConditionPropName = transform(ConditionPropName);
			return newAttr;
		}
	}
	
	/// <summary>
	/// Base class for conditional attributes that reference other parameters
	/// </summary>
	public abstract class ARC_HybridAlgo_SelfReferencingConditionalAttributeBase : ARC_HybridAlgo_ConditionalAttributeBase
	{
		protected ARC_HybridAlgo_SelfReferencingConditionalAttributeBase(ARC_HybridAlgo_PropComparisonType compareType, params object[] args) : base(compareType, args)
		{ }

		protected ARC_HybridAlgo_SelfReferencingConditionalAttributeBase(ARC_HybridAlgo_SelfReferencingConditionalAttributeBase attr) : base(attr)
		{ }
	}

	public interface ARC_HybridAlgo_IReferencesPropsByName : ICloneable
	{
		/// <summary>
		/// Return a copy of the attribute with each name that references a property transformed with the provided function
		/// </summary>
		/// <param name="transform"></param>
		/// <returns></returns>
		ARC_HybridAlgo_IReferencesPropsByName TransformPropNames(Func<string, string> transform);
	}

	[SuppressMessage("ReSharper", "InconsistentNaming")]
	public enum ARC_HybridAlgo_PropComparisonType
	{
		/// <summary>
		/// Two arguments, low and high of number type
		/// </summary>
		Between,
		/// <summary>
		/// <inheritdoc cref="Between"/>
		/// </summary>
		NotBetween,
		IsOneOf,
		IsNotOneOf,
		EQ,
		NEQ,
		LT,
		GT,
		LTE,
		GTE
	}
}