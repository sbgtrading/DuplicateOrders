﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows.Media;
using NinjaTrader.Core;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.NinjaScript;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using SharpDX;
using SharpDX.Direct2D1;
using SharpDX.DirectWrite;
using Brush = System.Windows.Media.Brush;
using RectangleF = SharpDX.RectangleF;
using TextAlignment = SharpDX.DirectWrite.TextAlignment;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	internal class ARC_TSScalperAlgo_DomBarTracker<TScript> where TScript : NinjaScriptBase, ARC_TSScalperAlgo_ITracksDomBars
	{
		private readonly SemaphoreSlim leveledBarProfileRenderRefreshLock = new SemaphoreSlim(1);
		private readonly SemaphoreSlim leveledBarProfileUpdateLock = new SemaphoreSlim(1);

		internal ARC_TSScalperAlgo_DomProfile LeveledBarProfile
		{
			get
			{
				if (!leveledBarProfileIsDirty)
					return leveledBarProfile;

				try
				{
					if (!leveledBarProfileUpdateLock.Wait(TimeSpan.FromSeconds(10)))
						throw new Exception("Timed out waiting for render thread to release DOM profile lock!");
				}
				finally
				{
					leveledBarProfileUpdateLock.Release();
				}

				// Compile our current bar profile into dictionary by level
				leveledBarProfile = new ARC_TSScalperAlgo_DomProfile { ParentId = CurrentBarProfileId };
				if (currentBarProfile.Count == 0)
				{
					leveledBarProfileIsDirty = false;
					renderThreadSafeLeveledBarProfileIsDirty = true;
					return leveledBarProfile;
				}

				var minKey = currentBarProfile.Keys.First();
				foreach (var t in currentBarProfile.GroupBy(kvp => Math.Floor((kvp.Key - minKey) / (script.TickSize * script.TicksPerDomLevel))))
					leveledBarProfile[t.Average(kvp => kvp.Key)] = new ARC_TSScalperAlgo_DomRow { Bid = t.Sum(ba => ba.Value.Bid), Ask = t.Sum(ba => ba.Value.Ask) };

				var levelKeyArr = leveledBarProfile.Keys.ToArray();
				var totalVolume = leveledBarProfile.Values.Sum(r => r.Bid + r.Ask);

				if (script is ARC_TSScalperAlgo_ITracksDomBarsWithImbalance scriptWithImbalance)
				{
					var endOffset = scriptWithImbalance.ImbalanceCalculationMode == ARC_TSScalperAlgo_ImbalanceCalculationMode.Diagonally ? 1 : 0;
					for (var l = endOffset; l < leveledBarProfile.Count; l++)
					{
						var bidPrice = levelKeyArr[l - endOffset];
						var askPrice = levelKeyArr[l];
						var bidVolume = leveledBarProfile[bidPrice].Bid;
						var askVolume = leveledBarProfile[askPrice].Ask;

						if (Math.Abs(askVolume - bidVolume) < totalVolume * scriptWithImbalance.MinImbalancePercent / 100 || bidVolume.ApproxCompare(askVolume) == 0)
							continue;

						var imbalanceSide = askVolume > bidVolume ? ARC_TSScalperAlgo_BidAsk.Ask : ARC_TSScalperAlgo_BidAsk.Bid;
						var var1 = imbalanceSide == ARC_TSScalperAlgo_BidAsk.Ask ? askVolume : bidVolume;
						var var2 = imbalanceSide == ARC_TSScalperAlgo_BidAsk.Ask ? bidVolume : askVolume;
						var volRatio = var2.ApproxCompare(0) == 0 ? double.MaxValue : var1 / var2;
						if (volRatio < scriptWithImbalance.ImbalanceMultiplier)
							continue;

						leveledBarProfile[imbalanceSide == ARC_TSScalperAlgo_BidAsk.Bid ? bidPrice : askPrice].Imbalance |= imbalanceSide == ARC_TSScalperAlgo_BidAsk.Ask ? ARC_TSScalperAlgo_BidAskFlags.Ask : ARC_TSScalperAlgo_BidAskFlags.Bid;
					}
				}

				leveledBarProfileIsDirty = false;
				renderThreadSafeLeveledBarProfileIsDirty = true;
				return leveledBarProfile;
			}
		}
		private ARC_TSScalperAlgo_DomProfile leveledBarProfile = new ARC_TSScalperAlgo_DomProfile();
		private bool leveledBarProfileIsDirty;

		public ARC_TSScalperAlgo_DomProfile RenderThreadSafeLeveledBarProfile
		{
			get
			{
				if (leveledBarProfileRenderRefreshLock.CurrentCount == 0 || !renderThreadSafeLeveledBarProfileIsDirty)
					return renderThreadSafeLeveledBarProfile;

				// Lock semaphore to prevent other render calls from redundantly syncing leveled bar profile, then sync leveled bar profile
				leveledBarProfileRenderRefreshLock.Wait();
				ARC_TSScalperAlgo_DomProfile lbp;
				try
				{
					lbp = LeveledBarProfile;
				}
				finally
				{
					leveledBarProfileRenderRefreshLock.Release();
				}

				// Lock semaphore to prevent OnBarUpdate and OnRender from updating leveled bar profile, then clone it
				leveledBarProfileUpdateLock.Wait();
				try
				{
					return renderThreadSafeLeveledBarProfile = lbp.Clone();
				}
				finally
				{
					renderThreadSafeLeveledBarProfileIsDirty = false;
					leveledBarProfileUpdateLock.Release();
				}
			}
		}
		private ARC_TSScalperAlgo_DomProfile renderThreadSafeLeveledBarProfile = new ARC_TSScalperAlgo_DomProfile();
		private bool renderThreadSafeLeveledBarProfileIsDirty;
		
		internal ARC_TSScalperAlgo_DomProfile LastLeveledBarProfile { get; private set; }

		public bool PendingReset { get; private set; }
		public Guid CurrentBarProfileId { get; private set; }
		public Guid NextBarProfileId { get; set; }
		public int TickBarIdx { get; }
		public int BidTickBarIdx { get; }
		public int AskTickBarIdx { get; }
		public bool FirstTickOfNewDom { get; private set; }
		
		private int lastTickSide;
		private readonly ARC_TSScalperAlgo_DomProfile currentBarProfile = new ARC_TSScalperAlgo_DomProfile();
		private readonly TScript script;
		private ARC_TSScalperAlgo_DomBarTracker()
		{
			CurrentBarProfileId = Guid.NewGuid();
			NextBarProfileId = Guid.NewGuid();
		}

		public ARC_TSScalperAlgo_DomBarTracker(TScript script, int tickBarIdx) : this()
		{
			this.script = script;
			TickBarIdx = tickBarIdx;
			BidTickBarIdx = -1;
			AskTickBarIdx = -1;
		}
		
		public ARC_TSScalperAlgo_DomBarTracker(TScript script, int tickBarIdx, int bidTickBarIdx, int askTickBarIdx) : this(script, tickBarIdx)
		{
			this.script = script;
			BidTickBarIdx = bidTickBarIdx;
			AskTickBarIdx = askTickBarIdx;
		}
		
		private void ResetCurrentBarProfile()
		{
			LastLeveledBarProfile = LeveledBarProfile;
			CurrentBarProfileId = NextBarProfileId;
			NextBarProfileId = Guid.NewGuid();
			currentBarProfile.Clear();
			leveledBarProfileIsDirty = true;
			renderThreadSafeLeveledBarProfileIsDirty = true;
			PendingReset = false;
			FirstTickOfNewDom = true;
		}

		public void HandleBarUpdate()
		{
			if (script.BarsInProgress == 0)
			{
				if (script.BarsPeriods[0].BarsPeriodType.ARC_TSScalperAlgo_IsTimeBased())
					ResetCurrentBarProfile();
				else
					PendingReset = true;
				return;
			}

			if (script.BarsInProgress != TickBarIdx)
				return;

			if (PendingReset)
			{
				if (script.Close[0].ApproxCompare(script.Lows[0][0]) == -1 || script.Close[0].ApproxCompare(script.Highs[0][0]) == 1 || script.Time[0] > script.Times[0][0])
					ResetCurrentBarProfile();
				else
					FirstTickOfNewDom = false;
			}

			int tickSide;
			if (script.CurrentBar < 1)
				return;

			tickSide = script.Close[0].ApproxCompare(script.Close[1]);
			if (tickSide == 0)
				tickSide = lastTickSide;

			if (tickSide == 0)
				return;

			if (!currentBarProfile.TryGetValue(script.Close[0], out var row))
				currentBarProfile[script.Close[0]] = row = new ARC_TSScalperAlgo_DomRow { Bid = 0, Ask = 0 };

			if (tickSide == -1)
				row.Bid += script.Volume[0] / script.VolumeDivisor;
			if (tickSide == 1)
				row.Ask += script.Volume[0] / script.VolumeDivisor;

			renderThreadSafeLeveledBarProfileIsDirty = true;
			leveledBarProfileIsDirty = true;
			lastTickSide = tickSide;
		}
	}

	internal class ARC_TSScalperAlgo_DomProfile : SortedDictionary<double, ARC_TSScalperAlgo_DomRow>
	{
		/// <summary>
		/// An ID used to group together snapshots and aggregate profiles with their parent
		/// </summary>
		public Guid ParentId { get; set; }

		public double TotalVolume => TotalAsk + TotalBid;

		public double NetDelta => TotalAsk - TotalBid;

		public double TotalAsk
		{
			get
			{
				if (totalBidAskDirty)
					RecalculateTotalBidAsk();

				return totalAsk;
			}
		}
		private double totalAsk;

		public double TotalBid
		{
			get
			{
				if (totalBidAskDirty)
					RecalculateTotalBidAsk();

				return totalBid;
			}
		}
		private double totalBid;

		public new ARC_TSScalperAlgo_DomRow this[double price]
		{
			get => base[price];
			set
			{
				base[price] = value;
				value.ParentProfile = this;
				ResetIsDirty();
			}
		}

		private bool totalBidAskDirty = true;
		public ARC_TSScalperAlgo_DomProfile()
		{ }

		private ARC_TSScalperAlgo_DomProfile(ARC_TSScalperAlgo_DomProfile other) : base(other)
		{
			foreach (var key in Keys.ToArray())
				this[key] = new ARC_TSScalperAlgo_DomRow(this[key]) { ParentProfile = this };

			ParentId = other.ParentId;
			totalBidAskDirty = other.totalBidAskDirty;
			totalBid = other.totalBid;
			totalAsk = other.totalAsk;
		}

		public ARC_TSScalperAlgo_DomProfile Clone()
		{
			return new ARC_TSScalperAlgo_DomProfile(this);
		}

		private void RecalculateTotalBidAsk()
		{
			totalAsk = Values.Sum(r => r.Ask);
			totalBid = Values.Sum(r => r.Bid);
			totalBidAskDirty = false;
		}

		public void ResetIsDirty()
		{
			totalBidAskDirty = true;
		}

		public new void Clear()
		{
			base.Clear();
			ResetIsDirty();
		}
	}

	public interface ARC_TSScalperAlgo_ITracksDomBars
	{
		int TicksPerDomLevel { get; set; }
		int VolumeDivisor { get; set; }
	}

	public interface ARC_TSScalperAlgo_ITracksDomBarsWithImbalance : ARC_TSScalperAlgo_ITracksDomBars
	{
		int MinImbalancePercent { get; set; }
		double ImbalanceMultiplier { get; set; }
		ARC_TSScalperAlgo_ImbalanceCalculationMode ImbalanceCalculationMode { get; set; }
	}

	public interface ARC_TSScalperAlgo_IPaintsDomBars : ARC_TSScalperAlgo_ITracksDomBars
	{
		Brush DomTextColor { get; set; }
	}
	
	public interface ARC_TSScalperAlgo_IPaintsDomBarsWithImbalance : ARC_TSScalperAlgo_IPaintsDomBars
	{
		Brush BidImbalanceColor { get; set; }
		Brush AskImbalanceColor { get; set; }
	}

	internal class ARC_TSScalperAlgo_DomRow
	{
		/// <summary>
		/// Short volume
		/// </summary>
		public double Bid
		{
			get => bid;
			set
			{
				if (bid.ApproxCompare(value) == 0)
					return;

				bid = value;
				ParentProfile?.ResetIsDirty();
			}
		}
		private double bid;

		/// <summary>
		/// Long volume
		/// </summary>
		public double Ask
		{
			get => ask;
			set
			{
				if (ask.ApproxCompare(value) == 0)
					return;

				ask = value;
				ParentProfile?.ResetIsDirty();
			}
		}
		private double ask;

		public ARC_TSScalperAlgo_BidAskFlags Imbalance { get; set; }

		public ARC_TSScalperAlgo_DomProfile ParentProfile { get; set; }

		public ARC_TSScalperAlgo_DomRow()
		{ }

		public ARC_TSScalperAlgo_DomRow(ARC_TSScalperAlgo_DomRow row)
		{
			Imbalance = row.Imbalance;
			Bid = row.Bid;
			Ask = row.Ask;
			ParentProfile = row.ParentProfile;
		}

		public double this[ARC_TSScalperAlgo_BidAsk bidAsk] => bidAsk == ARC_TSScalperAlgo_BidAsk.Bid ? Bid : Ask;
	}

	internal static class ARC_TSScalperAlgo_DomBarHelpers
	{
		private static float GetDomTextMargin<TScript>(this TScript script, ChartControl chartControl)
			where TScript : NinjaScriptBase, ARC_TSScalperAlgo_IPaintsDomBars, IChartBars, IChartObject, IRenderTarget, IBarsPeriodProvider
		{
			return Math.Max(1, chartControl.GetBarPaintWidth(script.ChartBars) / 10f);
		}
		
		public static Size2F ARC_TSScalperAlgo_GetDomTargetCellSize<TScript>(this TScript script, ChartControl chartControl, ChartScale chartScale)
			where TScript : NinjaScriptBase, ARC_TSScalperAlgo_IPaintsDomBars, IChartBars, IChartObject, IRenderTarget, IBarsPeriodProvider
		{
			return new Size2F
			{
				Width = Math.Max(0, (chartControl.Properties.BarDistance - chartControl.GetBarPaintWidth(script.ChartBars) - script.GetDomTextMargin(chartControl)) / 2),
				Height = chartScale.GetPixelsForDistance(script.TicksPerDomLevel * script.TickSize / 2)
			};
		}
		
		public static void ARC_TSScalperAlgo_SizeFontToFit<TScript>(this ARC_TSScalperAlgo_DomProfile profile, TScript script, SimpleFont font, Size2F targetCellSize, float minFontSize)
			where TScript : NinjaScriptBase, ARC_TSScalperAlgo_IPaintsDomBars, IChartBars, IChartObject, IRenderTarget, IBarsPeriodProvider
		{
			font.Size = font.ARC_TSScalperAlgo_GetIdealFontSize(script.ChartPanel, targetCellSize, minFontSize, profile.Values.SelectMany(r => new[] { r.Bid, r.Ask }).Select(v => v.ToString("F0")).ToArray());
		}

		public delegate void RenderBidAskText(TextFormat tf, string text, Vector2 placement, ARC_TSScalperAlgo_DomRow row, double price, ARC_TSScalperAlgo_BidAsk side, SharpDX.Direct2D1.Brush textBrush);

		public static void ARC_TSScalperAlgo_RenderDom<TScript>(this TScript script, ChartControl chartControl, ChartScale chartScale, ARC_TSScalperAlgo_DomProfile barProfile, int barIdx, Size2F domCellsSize, SimpleFont font, RenderBidAskText renderAction)
			where TScript : NinjaScriptBase, ARC_TSScalperAlgo_IPaintsDomBars, IChartBars, IChartObject, IRenderTarget, IBarsPeriodProvider
		{
			if (script.Bars?.Instrument == null || script.CurrentBar < 1 || script.IsInHitTest)
				return;

			var oldAntialiasMode = script.RenderTarget.AntialiasMode;
			script.RenderTarget.AntialiasMode = AntialiasMode.Aliased;
			
			try
			{
				var barFullWidth = chartControl.GetBarPaintWidth(script.ChartBars);
				var barHalfWidth = (barFullWidth - 1) / 2 + 2;
				var barMargin = script.GetDomTextMargin(chartControl) / 2;

				var barX = chartControl.GetXByBarIndex(script.ChartBars, barIdx);
				using var tf = font.ToDirectWriteTextFormat();
				tf.ParagraphAlignment = ParagraphAlignment.Center;
				tf.WordWrapping = WordWrapping.NoWrap;

				// Render DOM
				using var textBrush = script.DomTextColor.ToDxBrush(script.RenderTarget);

				for (var i = 0; i < barProfile.Count; i++)
				{
					foreach (var side in (ARC_TSScalperAlgo_BidAsk[])Enum.GetValues(typeof(ARC_TSScalperAlgo_BidAsk)))
					{
						var price = barProfile.Keys.Skip(i).First();
						var row = barProfile[price];

						if ((side == ARC_TSScalperAlgo_BidAsk.Bid ? row.Bid : row.Ask).ApproxCompare(0) == 0 && i == (side == ARC_TSScalperAlgo_BidAsk.Ask ? 0 : barProfile.Count - 1))
							continue;

						var textXyVector = new Vector2
						{
							X = side == ARC_TSScalperAlgo_BidAsk.Bid
								? barX - barHalfWidth - domCellsSize.Width - barMargin / 2
								: barX + barHalfWidth + barMargin / 2,
							Y = chartScale.GetYByValue(price + script.TicksPerDomLevel * script.TickSize / 4)
						};

						var text = (side == ARC_TSScalperAlgo_BidAsk.Ask ? row.Ask : row.Bid).ToString("F0");
						renderAction(tf, text, textXyVector, row, price, side, textBrush);
					}
				}
			}
			finally
			{
				script.RenderTarget.AntialiasMode = oldAntialiasMode;
			}
		}

		public static void ARC_TSScalperAlgo_RenderDom<TScript>(this TScript script, ChartControl chartControl, ChartScale chartScale, ARC_TSScalperAlgo_DomProfile barProfile, int barIdx, Size2F domCellsSize, SimpleFont font, bool renderTextBoxes = false, bool showDelta = true, int deltaOffset = 0)
			where TScript : NinjaScriptBase, ARC_TSScalperAlgo_IPaintsDomBarsWithImbalance, IChartBars, IChartObject, IRenderTarget, IBarsPeriodProvider
		{
			if (script.Bars?.Instrument == null || script.CurrentBar < 1 || script.IsInHitTest)
				return;

			using var bidImbalanceBrush = script.BidImbalanceColor.ToDxBrush(script.RenderTarget);
			using var askImbalanceBrush = script.AskImbalanceColor.ToDxBrush(script.RenderTarget);
			ARC_TSScalperAlgo_RenderDom(script, chartControl, chartScale, barProfile, barIdx, domCellsSize, font, (tf, text, placement, row, price, side, textBrush) =>
			{
				if (renderTextBoxes)
					script.RenderTarget.ARC_TSScalperAlgo_DrawBoundingRect(tf, placement, text);

				tf.TextAlignment = side == ARC_TSScalperAlgo_BidAsk.Bid ? TextAlignment.Trailing : TextAlignment.Leading;
				var brush = !row.Imbalance.HasFlag(side == ARC_TSScalperAlgo_BidAsk.Ask ? ARC_TSScalperAlgo_BidAskFlags.Ask : ARC_TSScalperAlgo_BidAskFlags.Bid) 
					? textBrush
					: (side == ARC_TSScalperAlgo_BidAsk.Ask ? askImbalanceBrush : bidImbalanceBrush);
				using var tl = new TextLayout(Globals.DirectWriteFactory, text, tf, domCellsSize.Width, domCellsSize.Height);
				script.RenderTarget.DrawTextLayout(placement, tl, brush);
			});

			var oldAntialiasMode = script.RenderTarget.AntialiasMode;
			script.RenderTarget.AntialiasMode = AntialiasMode.Aliased;
			
			try
			{
				var barX = chartControl.GetXByBarIndex(script.ChartBars, barIdx);
				using var tf = font.ToDirectWriteTextFormat();
				tf.ParagraphAlignment = ParagraphAlignment.Center;
				tf.WordWrapping = WordWrapping.NoWrap;
				tf.TextAlignment = TextAlignment.Center;
				
				// Render net delta
				if (!showDelta)
					return;

				var netDeltaDir = barProfile.NetDelta.ApproxCompare(0);
				if (netDeltaDir == 0)
					return;
				
				using var backBrush = Brushes.Black.ToDxBrush(script.RenderTarget);
				using var tl = new TextLayout(Globals.DirectWriteFactory, Math.Abs(barProfile.NetDelta).ToString("F0"), tf, domCellsSize.Width, domCellsSize.Height);
				var placementVector = new Vector2
				{
					X = barX - domCellsSize.Width / 2,
					Y = chartScale.GetYByValue((netDeltaDir == 1 ? script.Highs : script.Lows)[0].GetValueAt(barIdx)) - netDeltaDir * (chartScale.GetPixelsForDistance(chartScale.MaxMinusMin) / 50 + deltaOffset)
				};
				if (netDeltaDir == 1)
					placementVector.Y -= tl.Metrics.Height / 2;

				var padding = new Vector2
				{
					X = tl.DetermineMinWidth() / 4,
					Y = tl.Metrics.Height / 8
				};
				script.RenderTarget.FillRectangle(new RectangleF
				{
					X = placementVector.X + (domCellsSize.Width - tl.DetermineMinWidth()) / 2 - padding.X,
					Y = placementVector.Y + (domCellsSize.Height - tl.Metrics.Height) / 2 - padding.Y,
					Width = tl.DetermineMinWidth() + padding.X * 2,
					Height = tl.Metrics.Height + padding.Y * 2
				}, backBrush);
				script.RenderTarget.DrawTextLayout(placementVector, tl, netDeltaDir == 1 ? askImbalanceBrush : bidImbalanceBrush);
			}
			finally
			{
				script.RenderTarget.AntialiasMode = oldAntialiasMode;
			}
		}
	}
}