using System.Globalization;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Controls.WpfPropertyGrid;
using System.Windows.Data;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	public class ARC_TrendStepperAlgo_NonOptimizationCheckBoxEditor : PropertyEditor
	{
		public ARC_TrendStepperAlgo_NonOptimizationCheckBoxEditor()
		{
			InlineTemplate = CreateTemplate();
		}

		private DataTemplate CreateTemplate()
		{
			var checkBox = new FrameworkElementFactory(typeof(CheckBox));
			checkBox.SetBinding(ToggleButton.IsCheckedProperty, new Binding("Value") { Converter = new ARC_TrendStepperAlgo_BoolEnumValueConverter(), Mode = BindingMode.TwoWay });
			return new DataTemplate(typeof(CheckBox)) { VisualTree = checkBox };
		}
	}

	public class ARC_TrendStepperAlgo_BoolEnumValueConverter : IValueConverter
	{
		private bool ToBoolean(object value)
		{
			return value.ToString().ToLower() == "true";
		}

		private ARC_TrendStepperAlgo_BoolEnum ToEnum(object value)
		{
			return value.ToString().ToLower() == "true" ? ARC_TrendStepperAlgo_BoolEnum.True : ARC_TrendStepperAlgo_BoolEnum.False;
		}

		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			if (value == null)
				return null;

			return ToBoolean(value);
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return ToEnum(value);
		}
	}
}
