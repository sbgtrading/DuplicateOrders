﻿using System;
using System.Linq;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	/// <summary>
	/// Used to show properties when the value of this one matches the provided value
	/// </summary>
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
	public class ARC_QuickTester_ShowOthersIfAttribute : ARC_QuickTester_SelfReferencingConditionalAttributeBase
	{
		/// <summary>
		/// The affected Properties
		/// </summary>
		public string[] Properties { get; set; }

		/// <summary>
		/// The affected Group
		/// </summary>
		public string[] Groups { get; set; }

		public ARC_QuickTester_ShowOthersIfAttribute(ARC_QuickTester_PropComparisonType compareType, params object[] args) : base(compareType, args)
		{
			Properties = Array.Empty<string>();
			Groups = Array.Empty<string>();
		}

		public ARC_QuickTester_ShowOthersIfAttribute(ARC_QuickTester_ShowOthersIfAttribute attr) : base(attr)
		{ }

		public override object Clone()
		{
			return new ARC_QuickTester_ShowOthersIfAttribute(this);
		}

		public override ARC_QuickTester_IReferencesPropsByName TransformPropNames(Func<string, string> transform)
		{
			var newAttr = (ARC_QuickTester_ShowOthersIfAttribute) Clone();
			newAttr.Properties = Properties
				.Select(transform)
				.ToArray();
			return newAttr;
		}
	}

	/// <summary>
	/// Used to show this property when the value of the target matches the provided value
	/// </summary>
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
	public class ARC_QuickTester_ShowIfAttribute : ARC_QuickTester_ReferentialConditionalAttributeBase
	{
		public ARC_QuickTester_ShowIfAttribute(string conditionPropName, ARC_QuickTester_PropComparisonType compareType, params object[] args) : base(conditionPropName, compareType, args)
		{ }

		public ARC_QuickTester_ShowIfAttribute(ARC_QuickTester_ShowIfAttribute attr) : base(attr)
		{ }

		public override object Clone()
		{
			return new ARC_QuickTester_ShowIfAttribute(this);
		}
	}
}