﻿using System;
using System.Collections.Concurrent;
using System.Linq;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	/// <summary>
	/// The same as a dictionary, except that it automatically adds a default value for the requested key if it doesn't exist yet
	/// </summary>
	/// <typeparam name="TKey"></typeparam>
	/// <typeparam name="TValue"></typeparam>
	public class ARC_PinBarAlgo_DefaultingDictionary<TKey, TValue> : ConcurrentDictionary<TKey, TValue>
	{
		private readonly TValue defaultValue;
		private readonly Func<TKey, TValue> defaultValueFactory;
		public ARC_PinBarAlgo_DefaultingDictionary()
		{
			defaultValue = default;
		}
		
		public ARC_PinBarAlgo_DefaultingDictionary(TValue defaultOverride)
		{
			defaultValue = defaultOverride;
		}
		
		public ARC_PinBarAlgo_DefaultingDictionary(Func<TKey, TValue> defaultFactory)
		{
			defaultValueFactory = defaultFactory;
		}

		public bool Remove(TKey key)
		{
			return TryRemove(key, out _);
		}

		public new TValue this[TKey key]
		{
			get
			{
				if (TryGetValue(key, out var outValue))
					return outValue;

				return this[key] = defaultValueFactory == null ? defaultValue : defaultValueFactory(key);
			}
			set => base[key] = value;
		}

		public string ToString(char separator, Func<TKey, string> keyStringifier, Func<TValue, string> valueStringifier)
		{
			return Keys.Aggregate("", (current, key) => current + keyStringifier(key) + separator + valueStringifier(this[key]) + separator).Trim(separator);
		}
	}

	public class ARC_PinBarAlgo_DefaultingDictionary
	{
		public static ARC_PinBarAlgo_DefaultingDictionary<TKey, TValue> ARC_PinBarAlgo_FromString<TKey, TValue>(string str, char separator, Func<string, TKey> keyParser, Func<string, TValue> valueParser)
		{
			if (string.IsNullOrWhiteSpace(str))
				return new ARC_PinBarAlgo_DefaultingDictionary<TKey, TValue>();

			var parts = str.Split(separator);
			var dict = new ARC_PinBarAlgo_DefaultingDictionary<TKey, TValue>();
			for (var i = 0; i < parts.Length / 2; i++)
				dict[keyParser(parts[2 * i])] = valueParser(parts[2 * i + 1]);
			return dict;
		}
	}
}