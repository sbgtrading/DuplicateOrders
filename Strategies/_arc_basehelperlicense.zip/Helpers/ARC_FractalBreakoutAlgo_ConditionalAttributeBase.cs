﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	public abstract class ARC_FractalBreakoutAlgo_ConditionalAttributeBase : Attribute, ARC_FractalBreakoutAlgo_IReferencesPropsByName
	{
		public override object TypeId => args.GetHashCode() + compareType.GetHashCode();
		private bool IsSingleNumCompare => compareType is ARC_FractalBreakoutAlgo_PropComparisonType.GT or ARC_FractalBreakoutAlgo_PropComparisonType.GTE or ARC_FractalBreakoutAlgo_PropComparisonType.LT or ARC_FractalBreakoutAlgo_PropComparisonType.LTE;
		private bool IsDualNumCompare => compareType is ARC_FractalBreakoutAlgo_PropComparisonType.Between or ARC_FractalBreakoutAlgo_PropComparisonType.NotBetween;
		private readonly ARC_FractalBreakoutAlgo_PropComparisonType compareType;
		private readonly object[] args;
		protected ARC_FractalBreakoutAlgo_ConditionalAttributeBase(ARC_FractalBreakoutAlgo_PropComparisonType compareType, params object[] args)
		{
			if (args.Length == 0)
				throw new ArgumentException("Attribute requires at least one value for any comparison type!");
				
			this.args = args;
			this.compareType = compareType;

			if ((IsSingleNumCompare || IsDualNumCompare) && args.Any(a => a is not IComparable))
				throw new ArgumentException("In numeric comparison, args must all be comparable");
			if (IsSingleNumCompare && args.Length != 1)
				throw new ArgumentException("Comparison requires one input!");
			if (IsDualNumCompare && args.Length != 2)
				throw new ArgumentException("Comparison requires two inputs!");
		}

		protected ARC_FractalBreakoutAlgo_ConditionalAttributeBase(ARC_FractalBreakoutAlgo_ConditionalAttributeBase attr)
		{
			args = attr.args;
			compareType = attr.compareType;
		}

		public bool MatchesCriteria(object value)
		{
			switch (compareType)
			{
			case ARC_FractalBreakoutAlgo_PropComparisonType.EQ:
				return Equals(value, args[0]);
			case ARC_FractalBreakoutAlgo_PropComparisonType.NEQ:
				return !Equals(value, args[0]);
			case ARC_FractalBreakoutAlgo_PropComparisonType.IsOneOf:
				return args.Any(a => Equals(value, a));
			case ARC_FractalBreakoutAlgo_PropComparisonType.IsNotOneOf:
				return args.All(a => !Equals(value, a));
			}

			if (value is not IComparable cVal)
				throw new ArgumentException("Argument must be comparable for numeric comparison to work!");

			var comparisons = args
				.OfType<IComparable>()
				.Select(cVal.CompareTo)
				.ToArray();
			return compareType switch
			{
				ARC_FractalBreakoutAlgo_PropComparisonType.Between => comparisons[0] > 0 && comparisons[1] < 0,
				ARC_FractalBreakoutAlgo_PropComparisonType.NotBetween => comparisons[0] < 0 || comparisons[1] > 0,
				ARC_FractalBreakoutAlgo_PropComparisonType.LT => comparisons[0] < 0,
				ARC_FractalBreakoutAlgo_PropComparisonType.GT => comparisons[0] > 0,
				ARC_FractalBreakoutAlgo_PropComparisonType.LTE => comparisons[0] <= 0,
				ARC_FractalBreakoutAlgo_PropComparisonType.GTE => comparisons[0] >= 0,
				_ => throw new ArgumentOutOfRangeException()
			};
		}

		public abstract object Clone();

		public abstract ARC_FractalBreakoutAlgo_IReferencesPropsByName TransformPropNames(Func<string, string> transform);
	}

	/// <summary>
	/// Base class for conditional attributes that reference other parameters
	/// </summary>
	public abstract class ARC_FractalBreakoutAlgo_ReferentialConditionalAttributeBase : ARC_FractalBreakoutAlgo_ConditionalAttributeBase
	{
		public override object TypeId => base.TypeId.GetHashCode() + ConditionPropName.GetHashCode();
		public string ConditionPropName { get; private set; }

		/// <param name="conditionPropName">Prefix the name with "." to compare to reference a property of the parent class from within a flattened child class.</param>
		/// <param name="compareType"></param>
		/// <param name="args"></param>
		protected ARC_FractalBreakoutAlgo_ReferentialConditionalAttributeBase(string conditionPropName, ARC_FractalBreakoutAlgo_PropComparisonType compareType, params object[] args) : base(compareType, args)
		{
			ConditionPropName = conditionPropName;
		}
		
		protected ARC_FractalBreakoutAlgo_ReferentialConditionalAttributeBase(ARC_FractalBreakoutAlgo_ReferentialConditionalAttributeBase attr) : base(attr)
		{
			ConditionPropName = attr.ConditionPropName;
		}

		public override ARC_FractalBreakoutAlgo_IReferencesPropsByName TransformPropNames(Func<string, string> transform)
		{
			var newAttr = (ARC_FractalBreakoutAlgo_ReferentialConditionalAttributeBase) Clone();
			newAttr.ConditionPropName = transform(ConditionPropName);
			return newAttr;
		}
	}
	
	/// <summary>
	/// Base class for conditional attributes that reference other parameters
	/// </summary>
	public abstract class ARC_FractalBreakoutAlgo_SelfReferencingConditionalAttributeBase : ARC_FractalBreakoutAlgo_ConditionalAttributeBase
	{
		protected ARC_FractalBreakoutAlgo_SelfReferencingConditionalAttributeBase(ARC_FractalBreakoutAlgo_PropComparisonType compareType, params object[] args) : base(compareType, args)
		{ }

		protected ARC_FractalBreakoutAlgo_SelfReferencingConditionalAttributeBase(ARC_FractalBreakoutAlgo_SelfReferencingConditionalAttributeBase attr) : base(attr)
		{ }
	}

	public interface ARC_FractalBreakoutAlgo_IReferencesPropsByName : ICloneable
	{
		/// <summary>
		/// Return a copy of the attribute with each name that references a property transformed with the provided function
		/// </summary>
		/// <param name="transform"></param>
		/// <returns></returns>
		ARC_FractalBreakoutAlgo_IReferencesPropsByName TransformPropNames(Func<string, string> transform);
	}

	[SuppressMessage("ReSharper", "InconsistentNaming")]
	public enum ARC_FractalBreakoutAlgo_PropComparisonType
	{
		/// <summary>
		/// Two arguments, low and high of number type
		/// </summary>
		Between,
		/// <summary>
		/// <inheritdoc cref="Between"/>
		/// </summary>
		NotBetween,
		IsOneOf,
		IsNotOneOf,
		EQ,
		NEQ,
		LT,
		GT,
		LTE,
		GTE
	}
}