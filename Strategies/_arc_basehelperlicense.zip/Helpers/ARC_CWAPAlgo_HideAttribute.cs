﻿using System;
using System.Linq;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	/// <summary>
	/// Used to hide this property unless the criteria is met
	/// </summary>
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
	public class ARC_CWAPAlgo_HideUnlessAttribute : ARC_CWAPAlgo_ReferentialConditionalAttributeBase
	{
		public ARC_CWAPAlgo_HideUnlessAttribute(string conditionPropName, ARC_CWAPAlgo_PropComparisonType compareType, params object[] args) : base(conditionPropName, compareType, args)
		{ }

		public ARC_CWAPAlgo_HideUnlessAttribute(ARC_CWAPAlgo_HideUnlessAttribute attr) : base(attr)
		{ }

		public override object Clone()
		{
			return new ARC_CWAPAlgo_HideUnlessAttribute(this);
		}
	}

	/// <summary>
	/// Used to hide other properties when the value of this one matches the provided value
	/// </summary>
	[AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
	public class ARC_CWAPAlgo_HideParametersAttribute : Attribute
	{
		/// <summary>
		/// The affected Properties
		/// </summary>
		public string[] Properties { get; set; }

		/// <summary>
		/// The affected Group
		/// </summary>
		public string[] Groups { get; set; }

		public override object TypeId => Properties.GetHashCode() + Groups.GetHashCode();

		public readonly ARC_CWAPAlgo_StrategyContext[] Contexts;
		public ARC_CWAPAlgo_HideParametersAttribute(params ARC_CWAPAlgo_StrategyContext[] contexts)
		{
			Contexts = contexts;
			Properties = Array.Empty<string>();
			Groups = Array.Empty<string>();
		}

		public ARC_CWAPAlgo_HideParametersAttribute() : this(Array.Empty<ARC_CWAPAlgo_StrategyContext>())
		{
			Properties = Array.Empty<string>();
			Groups = Array.Empty<string>();
		}
	}
	
	/// <summary>
	/// Used to hide other properties when the value of this one matches the provided value
	/// </summary>
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
	public class ARC_CWAPAlgo_HideOthersIfAttribute : ARC_CWAPAlgo_SelfReferencingConditionalAttributeBase
	{
		/// <summary>
		/// The affected Properties
		/// </summary>
		public string[] Properties { get; set; }

		/// <summary>
		/// The affected Group
		/// </summary>
		public string[] Groups { get; set; }

		public ARC_CWAPAlgo_HideOthersIfAttribute(ARC_CWAPAlgo_PropComparisonType compareType, params object[] args) : base(compareType, args)
		{
			Properties = Array.Empty<string>();
			Groups = Array.Empty<string>();
		}

		public ARC_CWAPAlgo_HideOthersIfAttribute(ARC_CWAPAlgo_HideOthersIfAttribute attr) : base(attr)
		{ }

		public override object Clone()
		{
			return new ARC_CWAPAlgo_HideOthersIfAttribute(this);
		}

		public override ARC_CWAPAlgo_IReferencesPropsByName TransformPropNames(Func<string, string> transform)
		{
			var newAttr = (ARC_CWAPAlgo_HideOthersIfAttribute) Clone();
			newAttr.Properties = Properties
				.Select(transform)
				.ToArray();
			return newAttr;
		}
	}

	/// <summary>
	/// Browsable(false) removed properties from the descriptor collection, meaning they can't be shown conditionally, only hidden conditionally. This preserves them.
	/// </summary>
	[AttributeUsage(AttributeTargets.Property)]
	public class ARC_CWAPAlgo_HideByDefaultAttribute : Attribute
	{ }

	public enum ARC_CWAPAlgo_StrategyContext
	{
		Realtime,
		Backtest,
		Optimization
	}
}
