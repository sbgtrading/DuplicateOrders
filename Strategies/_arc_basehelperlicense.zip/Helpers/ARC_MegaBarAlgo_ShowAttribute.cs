﻿using System;
using System.Linq;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	/// <summary>
	/// Used to show properties when the value of this one matches the provided value
	/// </summary>
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
	public class ARC_MegaBarAlgo_ShowOthersIfAttribute : ARC_MegaBarAlgo_SelfReferencingConditionalAttributeBase
	{
		/// <summary>
		/// The affected Properties
		/// </summary>
		public string[] Properties { get; set; }

		/// <summary>
		/// The affected Group
		/// </summary>
		public string[] Groups { get; set; }

		public ARC_MegaBarAlgo_ShowOthersIfAttribute(ARC_MegaBarAlgo_PropComparisonType compareType, params object[] args) : base(compareType, args)
		{
			Properties = Array.Empty<string>();
			Groups = Array.Empty<string>();
		}

		public ARC_MegaBarAlgo_ShowOthersIfAttribute(ARC_MegaBarAlgo_ShowOthersIfAttribute attr) : base(attr)
		{ }

		public override object Clone()
		{
			return new ARC_MegaBarAlgo_ShowOthersIfAttribute(this);
		}

		public override ARC_MegaBarAlgo_IReferencesPropsByName TransformPropNames(Func<string, string> transform)
		{
			var newAttr = (ARC_MegaBarAlgo_ShowOthersIfAttribute) Clone();
			newAttr.Properties = Properties
				.Select(transform)
				.ToArray();
			return newAttr;
		}
	}

	/// <summary>
	/// Used to show this property when the value of the target matches the provided value
	/// </summary>
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
	public class ARC_MegaBarAlgo_ShowIfAttribute : ARC_MegaBarAlgo_ReferentialConditionalAttributeBase
	{
		public ARC_MegaBarAlgo_ShowIfAttribute(string conditionPropName, ARC_MegaBarAlgo_PropComparisonType compareType, params object[] args) : base(conditionPropName, compareType, args)
		{ }

		public ARC_MegaBarAlgo_ShowIfAttribute(ARC_MegaBarAlgo_ShowIfAttribute attr) : base(attr)
		{ }

		public override object Clone()
		{
			return new ARC_MegaBarAlgo_ShowIfAttribute(this);
		}
	}
}