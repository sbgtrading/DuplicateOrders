﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Windows.Media;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	internal static class ARC_DivAlgo_BrushAndColorExtensions
	{
		/// <summary>
		/// </summary>
		/// <param name="color"></param>
		/// <param name="alpha">A byte alpha value</param>
		/// <returns></returns>
		internal static Color ARC_DivAlgo_WithAlpha(this Color color, byte alpha)
		{
			return Color.FromArgb(alpha, color.R, color.G, color.B);
		}

		/// <summary>
		/// </summary>
		/// <param name="color"></param>
		/// <param name="alpha">A fraction from 0 to 1</param>
		/// <returns></returns>
		internal static Color ARC_DivAlgo_WithAlpha(this Color color, float alpha)
		{
			return color.ARC_DivAlgo_WithAlpha((byte)(alpha * 255));
		}

		internal static Color ARC_DivAlgo_GetColor(this Brush brush)
		{
			return ((brush as SolidColorBrush) ?? Brushes.Transparent).Color;
		}
		
		internal static Brush ARC_DivAlgo_WithAlpha(this Brush brush, float alpha)
		{
			var newBrush = brush.CloneCurrentValue();
			newBrush.Opacity = alpha;
			return newBrush;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="brush"></param>
		/// <param name="amount">% to darken by, from 0 to 1</param>
		/// <returns></returns>s
		internal static SolidColorBrush ARC_DivAlgo_Darken(this SolidColorBrush brush, float amount)
		{
			return new SolidColorBrush(brush.Color.ARC_DivAlgo_Darken(amount));
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="color"></param>
		/// <param name="amount">% to darken by, from 0 to 1</param>
		/// <returns></returns>
		internal static Color ARC_DivAlgo_Darken(this Color color, float amount)
		{
			if (amount > 1 || amount < 0)
				throw new ArgumentOutOfRangeException(nameof(amount), amount, "Amount must be from 0 to 1");

			return new Color
			{
				A = color.A,
				R = (byte) ((1 - amount) * color.R),
				G = (byte) ((1 - amount) * color.G),
				B = (byte) ((1 - amount) * color.B)
			};
		}
	}

	internal static class ARC_DivAlgo_DateTimeExtensions
	{
		public static bool ARC_DivAlgo_InRange(this DateTime time, int h1, int m1, int h2, int m2)
		{
			return time.ARC_DivAlgo_InRange(h1 * 100 + m1, h2 * 100 + m2);
		}

		internal static void ARC_DivAlgo_WrapTime(ref int h, ref int m)
		{
			var mHrs = m / 60;
			m -= mHrs * 60;
			h += mHrs;
			h -= h / 24;
		}

		internal static int ARC_DivAlgo_CompareTime(int h1, int m1, int h2, int m2)
		{
			return ARC_DivAlgo_CompareTime(h1 * 100 + m1, h2 * 100 + m2);
		}

		public static bool ARC_DivAlgo_InRange(this DateTime time, int hourAndMinute1, int hourAndMinute2)
		{
			var startCompare = ARC_DivAlgo_CompareTime(time, hourAndMinute1);
			var endCompare = ARC_DivAlgo_CompareTime(time, hourAndMinute2);
			if (startCompare == 0 || endCompare == 0)
				return true;
			if (hourAndMinute1 == hourAndMinute2)
				return false;

			// If our end is greater then our start, we want our time to be between time start and end, otherwise we want our time outside of it
			var useInnerSpan = ARC_DivAlgo_CompareTime(hourAndMinute1, hourAndMinute2) != 1;
			return useInnerSpan ? startCompare != -1 && endCompare != 1 : endCompare != 1 || startCompare != -1;
		}

		internal static void ARC_DivAlgo_WrapTime(ref int hourAndMinute)
		{
			var h = hourAndMinute / 100;
			var m = hourAndMinute % 100;
			ARC_DivAlgo_WrapTime(ref h, ref m);
			hourAndMinute = h * 100 + m;
		}

		internal static int ARC_DivAlgo_CompareTime(int hourAndMinute1, int hourAndMinute2)
		{
			ARC_DivAlgo_WrapTime(ref hourAndMinute1);
			ARC_DivAlgo_WrapTime(ref hourAndMinute2);
			if (hourAndMinute1 > hourAndMinute2)
				return 1;
			if (hourAndMinute1 < hourAndMinute2)
				return -1;
			return 0;
		}

		public static int ARC_DivAlgo_CompareTime(this DateTime dt, int hour, int minute)
		{
			return ARC_DivAlgo_CompareTime(dt.Hour, dt.Minute, hour, minute);
		}

		public static int ARC_DivAlgo_CompareTime(this DateTime dt, int hourAndMinute)
		{
			return dt.ARC_DivAlgo_CompareTime(hourAndMinute / 100, hourAndMinute % 100);
		}
	}

	internal static class ARC_DivAlgo_ObjectExtensions
	{
		public static List<PropertyInfo> ARC_DivAlgo_GetNinjaScriptProperties(this Type type)
		{
			var props = type.GetProperties()
				.Where(p => p.GetCustomAttribute<NinjaScriptPropertyAttribute>() != null)
				.ToDictionary(p => p.MetadataToken, p => p);

			if (type.BaseType == null || type.BaseType == typeof(object))
				return props.Values.ToList();

			foreach (var p in type.BaseType.ARC_DivAlgo_GetNinjaScriptProperties().Where(p => !props.ContainsKey(p.MetadataToken)))
				props[p.MetadataToken] = p;
			return props.Values.ToList();
		}

		/// <summary>
		/// Removed attached event handlers from the object. For UI events, instead use <seealso cref="ARC_DivAlgo_UiElementExtensions.ARC_DivAlgo_RemoveRoutedEventHandlers"/>
		/// </summary>
		/// <param name="obj"></param>
		/// <param name="eventName"></param>
		public static void ARC_DivAlgo_ClearEventInvocations(this object obj, string eventName)
		{
			var fi = obj.GetType().ARC_DivAlgo_GetEventField(eventName);
			if (fi == null)
				return;

			fi.SetValue(obj, null);
		}

		public static FieldInfo ARC_DivAlgo_GetEventField(this Type type, string eventName)
		{
			FieldInfo field = null;
			while (type != null)
			{
				/* Find events defined as field */
				field = type.GetField(eventName, BindingFlags.Static | BindingFlags.Instance | BindingFlags.NonPublic);
				if (field != null && (field.FieldType == typeof(MulticastDelegate) || field.FieldType.IsSubclassOf(typeof(MulticastDelegate))))
					break;

				/* Find events defined as property { add; remove; } */
				field = type.GetField($"EVENT_{eventName.ToUpper()}", BindingFlags.Static | BindingFlags.Instance | BindingFlags.NonPublic);
				if (field != null)
					break;

				type = type.BaseType;
			}

			return field;
		}

		public static bool ARC_DivAlgo_IsNumeric(this Type t)
		{
			if (t.IsEnum)
				return false;

			switch (Type.GetTypeCode(t))
			{
			case TypeCode.Byte:
			case TypeCode.SByte:
			case TypeCode.UInt16:
			case TypeCode.UInt32:
			case TypeCode.UInt64:
			case TypeCode.Int16:
			case TypeCode.Int32:
			case TypeCode.Int64:
			case TypeCode.Decimal:
			case TypeCode.Double:
			case TypeCode.Single:
			case TypeCode.Boolean:
				return true;
			default:
				return false;
			}
		}

		public static ARC_DivAlgo_BoolEnum ARC_DivAlgo_ToEnum(this bool b)
		{
			return b ? ARC_DivAlgo_BoolEnum.True : ARC_DivAlgo_BoolEnum.False;
		}
		
		public static bool ARC_DivAlgo_ToBool(this ARC_DivAlgo_BoolEnum b)
		{
			return b == ARC_DivAlgo_BoolEnum.True;
		}
	}

	internal static class ARC_DivAlgo_EnumerableExtensions
	{
		/// <summary>
		/// Return the 'best' output (by ranking) given a set of inputs and an output selector, an acceptable match criteria, a rank selector and optionally a perfectMatchCriteria.
		/// </summary>
		/// <typeparam name="TIn"></typeparam>
		/// <typeparam name="TOut"></typeparam>
		/// <typeparam name="TKey"></typeparam>
		/// <param name="items">The items to transform</param>
		/// <param name="outputSelector">The function transforming input to output</param>
		/// <param name="validMatchCriteria">A function returning true if the input is valid, and false otherwise</param>
		/// <param name="orderFunc">A method that takes an output and returns the key used to rank outputs in ascending order of fitness</param>
		/// <param name="perfectMatchCriteria">A function returning true if a match is 'perfect' (stops the search if found)</param>
		/// <returns></returns>
		internal static KeyValuePair<TIn, TOut>? ARC_DivAlgo_FindBest<TIn, TOut, TKey>(this IEnumerable<TIn> items, Func<TIn, TOut> outputSelector, Func<TOut, bool> validMatchCriteria, Func<TOut, TKey> orderFunc, Func<TOut, bool> perfectMatchCriteria) where TKey : IComparable
		{
			// Define our input to output dictionary
			var outputDict = new Dictionary<TIn, TOut>();
			foreach (var i in items)
			{
				var output = outputSelector(i);

				// Ignore invalid outputs
				if (!validMatchCriteria(output))
					continue;

				// If we find a perfect match return the value and stop searching
				if (perfectMatchCriteria != null && perfectMatchCriteria(output))
					return new KeyValuePair<TIn, TOut>(i, output);

				outputDict[i] = output;
			}

			// Use the ranking function to sort the output (descending order) then return
			return outputDict
				.OrderBy(kvp => orderFunc(kvp.Value))
				.Select(kvp => (KeyValuePair<TIn, TOut>?)kvp)
				.FirstOrDefault();
		}

		internal static double ARC_DivAlgo_StdDev(this IEnumerable<double> set)
		{
			var arr = set as double[] ?? set.ToArray();
			var avg = arr.Average();
			return Math.Sqrt(arr.Sum(v => Math.Pow(v - avg, 2)) / Math.Max(arr.Length - 1, 1));
		}

		internal static double ARC_DivAlgo_Covariance(this IEnumerable<double> set1, IEnumerable<double> set2)
		{
			var arr1 = set1 as double[] ?? set1.ToArray();
			var arr2 = set2 as double[] ?? set2.ToArray();

			if (arr1.Length != arr2.Length)
				throw new Exception();

			var avg1 = arr1.Average();
			var avg2 = arr2.Average();

			var covariance = arr1
				.Select((s1Val, i) => (s1Val - avg1) * (arr2[i] - avg2))
				.Sum();
			covariance /= Math.Max(arr1.Length - 1, 1);
			return covariance;
		}

		internal static double ARC_DivAlgo_Variance(this IEnumerable<double> set)
		{
			var arr = set as double[] ?? set.ToArray();
			var avg = arr.Average();
			var variance = arr
				.Select((val, i) => Math.Pow(val - avg, 2))
				.Sum();
			variance /= Math.Max(arr.Length - 1, 1);
			return variance;
		}

		internal static double ARC_DivAlgo_Correlation(this IEnumerable<double> set1, IEnumerable<double> set2)
		{
			var arr1 = set1 as double[] ?? set1.ToArray();
			var arr2 = set2 as double[] ?? set2.ToArray();
			return ARC_DivAlgo_Covariance(arr1, arr2) / (arr1.ARC_DivAlgo_StdDev() * arr2.ARC_DivAlgo_StdDev());
		}

		internal static double ARC_DivAlgo_Percentile(this IEnumerable<double> population, double value)
		{
			var arr = population as double[] ?? population.ToArray();
			if (arr.Length == 0)
				return 0;

			return Math.Max(Array.FindIndex(arr, a => a > value), 0) / (double)arr.Length * 100;
		}

		internal static SortedDictionary<TKey, TElement> ARC_DivAlgo_ToSortedDictionary<TSource, TKey, TElement>(this IEnumerable<TSource> source, Func<TSource, TKey> keySelector, Func<TSource, TElement> elementSelector)
		{
			if (source == null)
				throw new ArgumentNullException(nameof(source));
			if (keySelector == null)
				throw new ArgumentNullException(nameof(keySelector));
			if (elementSelector == null)
				throw new ArgumentNullException(nameof(elementSelector));
			var dictionary = new SortedDictionary<TKey, TElement>();
			foreach (var source1 in source)
				dictionary[keySelector(source1)] = elementSelector(source1);
			return dictionary;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <typeparam name="TItem"></typeparam>
		/// <param name="items"></param>
		/// <param name="contiguityCheck">A function that determines whether arg1 and arg2 are contiguous</param>
		/// <returns></returns>
		internal static IEnumerable<List<TItem>> ARC_DivAlgo_GetContiguousGroups<TItem>(this IEnumerable<TItem> items, Func<TItem, TItem, bool> contiguityCheck)
		{
			var groups = new List<List<TItem>>();
			var curGroup = new List<TItem>();
			foreach (var item in items)
			{
				if (curGroup.Count != 0 && !contiguityCheck(curGroup.Last(), item))
				{
					groups.Add(curGroup.ToList());
					curGroup.Clear();
				}

				curGroup.Add(item);
			}

			if (curGroup.Count > 0)
				groups.Add(curGroup);

			return groups;
		}

		internal static void ARC_DivAlgo_Clear<TItem>(this ConcurrentQueue<TItem> queue)
		{
			while (queue.TryDequeue(out _))
			{ }
		}
	}

	internal static class ARC_DivAlgo_StringExtensions
	{
		public static string ARC_DivAlgo_LimitCharacters(this string str, string validChars)
		{
			return new string(str.Where(validChars.Contains).ToArray());
		}
	}

	internal static class ARC_DivAlgo_MathExtensions
	{
		public static double ARC_DivAlgo_ClosestValue(this double value, params double[] values)
		{
			return values
				.OrderBy(v => Math.Abs(value - v))
				.First();
		}

		public static double ARC_DivAlgo_ShortestDistance(this double value, params double[] values)
		{
			return Math.Abs(value - value.ARC_DivAlgo_ClosestValue(values));
		}

		public static bool ARC_DivAlgo_InRange(this double value, double bound1, double bound2, bool inclusive = true)
		{
			var comp1 = value.ApproxCompare(bound1);
			if (comp1 == 0 && inclusive)
				return true;
			
			var comp2 = value.ApproxCompare(bound2);
			if (comp2 == 0 && inclusive)
				return true;

			return comp1 == -comp2;
		}
		
		public static bool ARC_DivAlgo_InRange(this int value, int bound1, int bound2, bool inclusive = true)
		{
			var comp1 = value.CompareTo(bound1);
			if (comp1 == 0 && inclusive)
				return true;
			
			var comp2 = value.CompareTo(bound2);
			if (comp2 == 0 && inclusive)
				return true;

			return comp1 == -comp2;
		}
	}

	internal static class ARC_DivAlgo_DrawingToolExtensions
	{
		internal static void ARC_DivAlgo_SnapToTick(this DrawingTool tool, ChartAnchor anchor)
		{
			if (tool.AttachedTo?.Instrument == null)
				return;

			anchor.Price = tool.AttachedTo.Instrument.MasterInstrument.RoundToTickSize(anchor.Price);
		}
	}

	internal static class ARC_DivAlgo_NtTypeExtensions
	{
		public static bool ARC_DivAlgo_IsTimeBased(this BarsPeriodType bp)
		{
			return bp == BarsPeriodType.Second || bp == BarsPeriodType.Minute || bp == BarsPeriodType.Day ||
					bp == BarsPeriodType.Week || bp == BarsPeriodType.Month || bp == BarsPeriodType.Year;
		}

		public static bool ARC_DivAlgo_Crossed(this ISeries<double> series, double level, int offset = 0)
		{
			if (offset < 0)
				throw new ArgumentOutOfRangeException(nameof(offset), "Offset must be GTE 0");

			return series.Count >= 2 && series[offset].ApproxCompare(level) != series[offset + 1].ApproxCompare(level);
		}

		public static int ARC_DivAlgo_EnsureDataSeriesAdded(this NinjaScriptBase script, Action<BarsPeriod> addDataSeries, BarsPeriodType periodType, int period, MarketDataType marketDataType = MarketDataType.Last)
		{
			var idx = Array.FindIndex(script.BarsPeriods, b => b.BarsPeriodType == periodType && b.Value == period && b.MarketDataType == marketDataType);
			if (idx != -1)
				return idx;

			var bp = (BarsPeriod) script.BarsPeriods[0].Clone();
			bp.BarsPeriodType = periodType;
			bp.Value = period;
			bp.MarketDataType = marketDataType;
			if (periodType is BarsPeriodType.Tick || periodType.ARC_DivAlgo_IsTimeBased()) 
			{
				bp.BaseBarsPeriodValue = bp.Value2 = 1;
				bp.BaseBarsPeriodType = BarsPeriodType.Minute;
			}
			addDataSeries(bp);
			return script.BarsArray.Length - 1;
		}
	}
}
