﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	internal class ARC_CWAPAlgo_ReadOnlyMapProxy<TItem>: IEnumerable<TItem>
	{
		private readonly Func<int, TItem> accessor;
		private readonly Func<IEnumerable<TItem>> totalSetAccessor;
		public ARC_CWAPAlgo_ReadOnlyMapProxy(Func<IEnumerable<TItem>> totalSetAccessor, Func<int, TItem> accessor)
		{
			this.totalSetAccessor = totalSetAccessor;
			this.accessor = accessor;
		}

		public IEnumerator<TItem> GetEnumerator()
		{
			return totalSetAccessor().GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}

		public TItem this[int idx] => accessor(idx);
	}
	
	internal class ARC_CWAPAlgo_MapProxy<TItem> : ARC_CWAPAlgo_ReadOnlyMapProxy<TItem>
	{
		private readonly Action<int, TItem> setter;
		public ARC_CWAPAlgo_MapProxy(Func<IEnumerable<TItem>> totalSetAccessor, Func<int, TItem> accessor, Action<int, TItem> setter) : base(totalSetAccessor, accessor)
		{
			this.setter = setter;
		}

		public new TItem this[int idx]
		{
			get => base[idx];
			set => setter(idx, value);
		}
	}
}