﻿using System;
using System.Windows;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	internal class ARC_EngulfingAlgo_CohenSutherlandTest
	{
		public Rect Rect { get; }

		[Flags]
		private enum RegionCode
		{
			Inside = 0,
			Left = 1,
			Right = 2,
			Bottom = 4,
			Top = 8
		}

		public ARC_EngulfingAlgo_CohenSutherlandTest(Rect rect)
		{
			Rect = rect;
		}

		private RegionCode ComputeCode(Point p)
		{
			// initialized as being inside
			var code = RegionCode.Inside;

			if (p.X < Rect.X) // to the left of rectangle
				code |= RegionCode.Left;
			else if (p.X > Rect.X + Rect.Width) // to the right of rectangle
				code |= RegionCode.Right;
			if (p.Y < Rect.Y) // below the rectangle
				code |= RegionCode.Bottom;
			else if (p.Y > Rect.Y + Rect.Height) // above the rectangle
				code |= RegionCode.Top;

			return code;
		}

		public bool IntersectsLine(Point p1, Point p2)
		{
			// Compute region codes for P1, P2
			var code1 = ComputeCode(p1);
			var code2 = ComputeCode(p2);

			while (true)
			{
				// If both endpoints lie within rectangle
				if (code1 == 0 && code2 == 0)
					return true;

				if ((code1 & code2) != 0)
					return false;

				// Some segment of line lies within the
				// rectangle
				var x = 0.0;
				var y = 0.0;

				// At least one endpoint is outside the
				// rectangle, pick it.
				var codeOut = code1 != 0 ? code1 : code2;

				// Find intersection point;
				// using formulas y = p1.Y + slope * (x - p1.X),
				// x = p1.X + (1 / slope) * (y - p1.Y)
				if ((codeOut & RegionCode.Top) != 0)
				{
					// point is above the clip rectangle
					x = p1.X + (p2.X - p1.X) * (Rect.Y + Rect.Height - p1.Y) / (p2.Y - p1.Y);
					y = Rect.Y + Rect.Height;
				}
				else if ((codeOut & RegionCode.Bottom) != 0)
				{
					// point is below the rectangle
					x = p1.X + (p2.X - p1.X) * (Rect.Y - p1.Y) / (p2.Y - p1.Y);
					y = Rect.Y;
				}
				else if ((codeOut & RegionCode.Right) != 0)
				{
					// point is to the right of rectangle
					y = p1.Y + (p2.Y - p1.Y) * (Rect.X + Rect.Width - p1.X) / (p2.X - p1.X);
					x = Rect.X + Rect.Width;
				}
				else if ((codeOut & RegionCode.Left) != 0)
				{
					// point is to the left of rectangle
					y = p1.Y + (p2.Y - p1.Y) * (Rect.X - p1.X) / (p2.X - p1.X);
					x = Rect.X;
				}

				// Now intersection point x, y is found
				// We replace point outside rectangle
				// by intersection point
				if (codeOut == code1)
				{
					p1 = new Point(x, y);
					code1 = ComputeCode(p1);
				}
				else
				{
					p2 = new Point(x, y);
					code2 = ComputeCode(p2);
				}
			}
		}
	}
}