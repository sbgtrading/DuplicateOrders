﻿using System;
using System.Collections.Generic;
using System.Linq;
using Color = System.Windows.Media.Color;
using SolidColorBrush = System.Windows.Media.SolidColorBrush;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	/// <summary>
	/// Essentially a dictionary filled with objects that are created with a function if the dict doesn't already have an item for that key
	/// </summary>
	internal abstract class ARC_SpringboardAlgo_CacheBase<TKey, TContents> : IDisposable
	{
		protected readonly Dictionary<TKey, TContents> cacheDict = new Dictionary<TKey, TContents>();
		private readonly Func<TKey, TContents> generationFunc;

		protected ARC_SpringboardAlgo_CacheBase(Func<TKey, TContents> generationFunc)
		{
			this.generationFunc = generationFunc;
		}

		/// <summary>
		/// Return an existing brush if one's been made for this color, or create and store a new one and return that.
		/// </summary>
		/// <returns></returns>
		internal TContents this[TKey key]
		{
			get
			{
				if (!cacheDict.ContainsKey(key))
					cacheDict[key] = generationFunc(key);
				return cacheDict[key];
			}
		}

		public virtual void Dispose()
		{
			foreach (var value in cacheDict.Values.OfType<IDisposable>())
				value.Dispose();
		}
	}

	internal class ARC_SpringboardAlgo_SolidColorBrushCache : ARC_SpringboardAlgo_CacheBase<Color, SolidColorBrush>
	{
		internal ARC_SpringboardAlgo_SolidColorBrushCache() : base(c => new SolidColorBrush(c)) { }
	}
}
