﻿using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using System.Collections.Generic;
using System;
using System.Linq;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	public class ARC_FractalBreakoutAlgo_SessionTracker
	{
		private readonly ARC_FractalBreakoutAlgo_InstrumentDictionary<Dictionary<TradingHours, SessionIterator>> sessionIterators = new ARC_FractalBreakoutAlgo_InstrumentDictionary<Dictionary<TradingHours, SessionIterator>>(_ => new Dictionary<TradingHours, SessionIterator>());
		private readonly NinjaScriptBase script;
		public ARC_FractalBreakoutAlgo_SessionTracker(NinjaScriptBase script)
		{
			this.script = script;
			for (var bip = 0; bip < script.BarsArray.Length; bip++)
			{
				if (sessionIterators.ContainsKey(script.Instruments[bip]))
					continue;

				var tradingHours = script.TradingHoursArray
					.Where((th, i) => script.Instruments[i] == script.Instruments[bip])
					.Distinct()
					.ToArray();
			
				// Create a session iterator per trading hours, and track the BIPs per trading hours
				foreach (var th in tradingHours)
					sessionIterators[script.Instruments[bip]][th] = new SessionIterator(th);
			}
		}

		private void SyncSession(int bip, DateTime? dateTime = null)
		{
			dateTime = dateTime ?? script.Times[bip][0];
			if (dateTime.Value < this[bip].ActualSessionBegin || dateTime.Value > this[bip].ActualSessionEnd)
				this[bip].GetNextSession(dateTime.Value, true);
		}

		public DateTime GetEndOfSession(int bip)
		{
			SyncSession(bip);
			return this[bip].ActualSessionEnd;
		}
		
		public DateTime GetStartOfSession(int bip)
		{
			SyncSession(bip);
			return this[bip].ActualSessionBegin;
		}

		/// <summary>
		/// Returns the start of the next session relative to the time provided
		/// </summary>
		/// <param name="bip"></param>
		/// <param name="dateTime">The date time to check (if null, defaults to current time for BIP)</param>
		/// <param name="nonTimeBarsEodTolerance">The min distance from end of session under which non time based bars are considered to be the "last". Defaults to 5m. </param>
		/// <returns></returns>
		public DateTime GetStartOfSession(int bip, DateTime dateTime, TimeSpan? nonTimeBarsEodTolerance = null)
		{
			SyncSession(bip, dateTime);
			if (!script.BarsPeriods[bip].BarsPeriodType.ARC_FractalBreakoutAlgo_IsTimeBased() && IsLastBarOfSession(bip, dateTime, nonTimeBarsEodTolerance))
				SyncSession(bip, this[bip].ActualSessionEnd.AddTicks(1));

			return this[bip].ActualSessionBegin;
		}

		/// <summary>
		/// Returns true if the BIPs current bar is also the last of the session
		/// </summary>
		/// <param name="bip"></param>
		/// <param name="dateTime">The date time to check (if null, defaults to current time for BIP)</param>
		/// <param name="nonTimeBarsEodTolerance">The min distance from end of session under which non time based bars are considered to be the "last". Defaults to 5m. </param>
		/// <returns></returns>
		public bool IsLastBarOfSession(int bip, DateTime? dateTime = null, TimeSpan? nonTimeBarsEodTolerance = null)
		{
			SyncSession(bip, dateTime);
			var limit = script.BarsPeriods[bip].BarsPeriodType.ARC_FractalBreakoutAlgo_IsTimeBased() 
				? this[bip].ActualSessionEnd
				: this[bip].ActualSessionEnd - (nonTimeBarsEodTolerance ?? new TimeSpan(0, 0, 5, 0));
			return (dateTime ?? script.Times[bip][0]) >= limit;
		}

		private SessionIterator this[int bip] { get { return sessionIterators[script.Instruments[bip]][script.TradingHoursArray[bip]]; } }
	}
}