﻿using System;
using System.Linq;
using System.Windows.Media;
using NinjaTrader.Core;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX;
using SharpDX.Direct2D1;
using SharpDX.DirectWrite;
using Brush = SharpDX.Direct2D1.Brush;
using Ellipse = SharpDX.Direct2D1.Ellipse;
using PathGeometry = SharpDX.Direct2D1.PathGeometry;
using Point = System.Windows.Point;
using RectangleF = SharpDX.RectangleF;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	internal static class ARC_MatrixScalperAlgo_RenderExtensions
	{
		public static void ARC_MatrixScalperAlgo_DrawArrow(this RenderTarget renderTarget, Point point, bool pointsDown, float barWidth, Brush outlineBrush, Brush fillBrush)
		{
			if (outlineBrush == null && fillBrush == null)
				return;

			var arrowHeight = barWidth * 3f;
			var arrowStemWidth = barWidth / 3f;

			// the geometry is created with 0,0 as point origin, and pointing UP by default.
			// so translate & rotate as needed
			var vector = point.ToVector2() + new Vector2(0, (pointsDown ? -1 : 1) * barWidth);
			var transformMatrix = pointsDown
				// Flip it around. beware due to our translation we rotate on origin
				? Matrix3x2.Rotation(DrawingTool.MathHelper.DegreesToRadians(180), Vector2.Zero) * Matrix3x2.Translation(vector)
				: Matrix3x2.Translation(vector);

			renderTarget.Transform = transformMatrix;

			using (var arrowPathGeometry = new PathGeometry(Globals.D2DFactory))
			using (var geometrySink = arrowPathGeometry.Open())
			{
				geometrySink.BeginFigure(Vector2.Zero, FigureBegin.Filled);

				geometrySink.AddLine(new Vector2(barWidth, barWidth));
				geometrySink.AddLine(new Vector2(arrowStemWidth, barWidth));
				geometrySink.AddLine(new Vector2(arrowStemWidth, arrowHeight));
				geometrySink.AddLine(new Vector2(-arrowStemWidth, arrowHeight));
				geometrySink.AddLine(new Vector2(-arrowStemWidth, barWidth));
				geometrySink.AddLine(new Vector2(-barWidth, barWidth));

				geometrySink.EndFigure(FigureEnd.Closed);
				geometrySink.Close(); // note this calls dispose for you. but not the other way around

				if (outlineBrush != null)
					renderTarget.DrawGeometry(arrowPathGeometry, outlineBrush, 2);
				if (fillBrush != null)
					renderTarget.FillGeometry(arrowPathGeometry, fillBrush);
			}

			renderTarget.Transform = Matrix3x2.Identity;
		}

		public static void ARC_MatrixScalperAlgo_DrawDot(this RenderTarget renderTarget, Point point, float radius, Brush brush)
		{
			if (brush == null)
				return;

			renderTarget.FillEllipse(new Ellipse(point.ToVector2(), radius, radius), brush);
		}

		public static void ARC_MatrixScalperAlgo_DrawDiamond(this RenderTarget renderTarget, Point point, float width, Brush fillBrush, Brush outlineBrush = null, float strokeWidth = 1)
		{
			var vector = point.ToVector2();
			var sideLength = (float)(width / Math.Sin(DrawingTool.MathHelper.DegreesToRadians(45)));
			var rect = new RectangleF(-sideLength / 2, -sideLength / 2, sideLength, sideLength);
			renderTarget.Transform = Matrix3x2.Rotation(DrawingTool.MathHelper.DegreesToRadians(45), Vector2.Zero) * Matrix3x2.Translation(vector);
			if (fillBrush != null)
				renderTarget.FillRectangle(rect, fillBrush);
			if (outlineBrush != null)
				renderTarget.DrawRectangle(rect, outlineBrush, strokeWidth);

			renderTarget.Transform = Matrix3x2.Identity;
		}

		public static void ARC_MatrixScalperAlgo_DrawV(this RenderTarget renderTarget, Point point, float width, Brush brush, float strokeWidth, int dir)
		{
			if (brush == null)
				return;

			var vector = point.ToVector2();
			
			var transformMatrix = dir == 1
				? Matrix3x2.Translation(vector)
				: Matrix3x2.Rotation(DrawingTool.MathHelper.DegreesToRadians(180), Vector2.Zero) * Matrix3x2.Translation(vector);

			renderTarget.Transform = transformMatrix;

			using (var trianglePathGeometry = new PathGeometry(Globals.D2DFactory))
			using (var geometrySink = trianglePathGeometry.Open())
			{
				geometrySink.BeginFigure(new Vector2(width, width), FigureBegin.Filled);
				geometrySink.AddLines(new[] { Vector2.Zero, new Vector2(-width, width) });
				geometrySink.EndFigure(FigureEnd.Open);
				geometrySink.Close();

				renderTarget.DrawGeometry(trianglePathGeometry, brush, strokeWidth);
			}

			renderTarget.Transform = Matrix3x2.Identity;
		}
		
		public static void ARC_MatrixScalperAlgo_DrawTriangle(this RenderTarget renderTarget, Point point, float width, Brush brush, float strokeWidth, int dir, Brush fillBrush = null)
		{
			if (brush == null)
				return;

			var vector = point.ToVector2();
			
			var transformMatrix = dir == 1
				? Matrix3x2.Translation(vector)
				: Matrix3x2.Rotation(DrawingTool.MathHelper.DegreesToRadians(180), Vector2.Zero) * Matrix3x2.Translation(vector);

			renderTarget.Transform = transformMatrix;

			using (var trianglePathGeometry = new PathGeometry(Globals.D2DFactory))
			using (var geometrySink = trianglePathGeometry.Open())
			{
				geometrySink.BeginFigure(new Vector2(width / 2, width / 2), FigureBegin.Filled);
				geometrySink.AddLines(new[] { Vector2.Zero, new Vector2(-width / 2, width / 2) });
				geometrySink.EndFigure(FigureEnd.Closed);
				geometrySink.Close();
				if (fillBrush != null)
					renderTarget.FillGeometry(trianglePathGeometry, fillBrush);
				renderTarget.DrawGeometry(trianglePathGeometry, brush, strokeWidth);
			}

			renderTarget.Transform = Matrix3x2.Identity;
		}

		public static Size2F ARC_MatrixScalperAlgo_GetTextSize(this SimpleFont sf, ChartPanel chartPanel, string text)
		{
			if (text.Length <= 0 || sf.Size < 0.01)
				return new Size2F();

			using var tf = sf.ToDirectWriteTextFormat();
			tf.WordWrapping = WordWrapping.NoWrap;
			using var tl = new TextLayout(Globals.DirectWriteFactory, text, tf, chartPanel.W, chartPanel.H);
			return new Size2F(tl.Metrics.Width, tl.Metrics.Height / 2);
		}

		public static double ARC_MatrixScalperAlgo_GetIdealFontSize(this SimpleFont sf, ChartPanel chartPanel, Size2F targetSize, float minFontSize, params string[] strings)
		{
			if (strings.Max(s => s.Length) == 0)
				return minFontSize;

			sf = (SimpleFont)sf.Clone();
			sf.Size = minFontSize;
			
			// Check if even at the min allowed font size we're larger then our target space, if we are, then 
			var exceedsTargetAtMinSize = strings
				.OrderByDescending(s => s.Length)
				.Select(str => sf.ARC_MatrixScalperAlgo_GetTextSize(chartPanel, str))
				.Any(s => s.Width > targetSize.Width || s.Height > targetSize.Height);
			if (exceedsTargetAtMinSize)
				return minFontSize;

			var maxSize = new Size2F();
			sf.Size = 1000;
			while (true)
			{
				var lastMaxSize = maxSize;
				var sizes = strings
					.Select(str => sf.ARC_MatrixScalperAlgo_GetTextSize(chartPanel, str))
					.ToArray();
				maxSize = new Size2F
				{
					Width = sizes.Max(s => s.Width),
					Height = sizes.Max(s => s.Height)
				};
				if ((maxSize.Width <= targetSize.Width && maxSize.Height <= targetSize.Height) || maxSize == lastMaxSize)
					return Math.Max(sf.Size, minFontSize);
				sf.Size *= Math.Min(targetSize.Width / maxSize.Width, targetSize.Height / maxSize.Height);
				if (sf.Size.ApproxCompare(minFontSize) <= 0)
					return minFontSize;
			}
		}

		public static void ARC_MatrixScalperAlgo_DrawBoundingRect(this RenderTarget renderTarget, TextFormat tf, Vector2 topLeft, string text)
		{
			using var brush = Brushes.Aqua.ToDxBrush(renderTarget);
			using var tl = new TextLayout(Globals.DirectWriteFactory, text, tf, renderTarget.Size.Width, renderTarget.Size.Height);
			renderTarget.DrawRectangle(new RectangleF
			{
				X = topLeft.X,
				Y = topLeft.Y,
				Width = tl.Metrics.Width,
				Height = tl.Metrics.Height
			}, brush, 2);
		}

		public static void ARC_MatrixScalperAlgo_DrawRegion(this RenderTarget renderTarget, bool sortPoints, Brush outlineBrush, Brush fillBrush, params Vector2[] boundingPoints)
		{
			if (boundingPoints.Length < 3)
				return;

			//// TODO Fix this, right now produces strange jagged shapes
			//if (sortPoints)
			//{
			//	var centroid = new Vector2(boundingPoints.Average(p => p.X), boundingPoints.Average(p => p.Y));
			//	boundingPoints = boundingPoints
			//		.OrderBy(p => Math.Atan2(p.Y - centroid.Y, p.X - centroid.X))
			//		.ToArray();
			//}

			using var path = new PathGeometry(Globals.D2DFactory);
			using var sink = path.Open();
			sink.BeginFigure(boundingPoints[0], new FigureBegin());
			sink.AddLines(boundingPoints
				.Skip(1)
				.Append(boundingPoints[0])
				.ToArray());
			sink.EndFigure(FigureEnd.Closed);
			sink.Close();

			renderTarget.FillGeometry(path, fillBrush);
			renderTarget.DrawGeometry(path, outlineBrush);
		}
	}
}