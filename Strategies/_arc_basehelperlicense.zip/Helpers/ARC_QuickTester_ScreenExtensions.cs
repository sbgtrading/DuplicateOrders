﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	internal static class ARC_QuickTester_ScreenExtensions
	{
		[DllImport("dwmapi")]
		private static extern int DwmGetWindowAttribute(IntPtr hwnd, int dwAttribute, ref RECT pvAttribute, int cbAttribute);

		const int DWMWA_EXTENDED_FRAME_BOUNDS = 9;

		[DllImport("user32.dll")]
		private static extern bool GetWindowRect(IntPtr hWnd, ref RECT lpRect);

		public static int ARC_QuickTester_ScalingPercent(this Screen screen)
		{
			var grab = new InactiveForm
			{
				FormBorderStyle = FormBorderStyle.None,
				TransparencyKey = Color.Red,
				BackColor = Color.Red,
				ShowInTaskbar = false,
				StartPosition = FormStartPosition.Manual,
				Location = screen.Bounds.Location
			};
			grab.Shown += (_, __) =>
			{
				grab.Location = new Point(grab.Location.X + 1, grab.Location.Y + 1); // need to update the location so the frame changes
				var rcFrame = new RECT();
				DwmGetWindowAttribute(grab.Handle, DWMWA_EXTENDED_FRAME_BOUNDS, ref rcFrame, Marshal.SizeOf(rcFrame));
				var rcWind = new RECT();
				GetWindowRect(grab.Handle, ref rcWind);
				grab.Tag = (int)((rcFrame.right - rcFrame.left) / (double)(rcWind.right - rcWind.left) * 100 / 25) * 25;
				grab.Close();
			};
			grab.ShowDialog();
			return (int) grab.Tag;
		}

		private class InactiveForm : Form
		{
			protected override bool ShowWithoutActivation
			{
				get
				{
					return true;
				}
			}
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct RECT
		{
			public int left, top, right, bottom;
		}
	}
}