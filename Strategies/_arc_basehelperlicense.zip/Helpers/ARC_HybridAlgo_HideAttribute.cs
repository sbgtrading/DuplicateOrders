﻿using System;
using System.Linq;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	/// <summary>
	/// Used to hide this property unless the criteria is met
	/// </summary>
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
	public class ARC_HybridAlgo_HideUnlessAttribute : ARC_HybridAlgo_ReferentialConditionalAttributeBase
	{
		public ARC_HybridAlgo_HideUnlessAttribute(string conditionPropName, ARC_HybridAlgo_PropComparisonType compareType, params object[] args) : base(conditionPropName, compareType, args)
		{ }

		public ARC_HybridAlgo_HideUnlessAttribute(ARC_HybridAlgo_HideUnlessAttribute attr) : base(attr)
		{ }

		public override object Clone()
		{
			return new ARC_HybridAlgo_HideUnlessAttribute(this);
		}
	}

	/// <summary>
	/// Used to hide other properties when the value of this one matches the provided value
	/// </summary>
	[AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
	public class ARC_HybridAlgo_HideParametersAttribute : Attribute
	{
		/// <summary>
		/// The affected Properties
		/// </summary>
		public string[] Properties { get; set; }

		/// <summary>
		/// The affected Group
		/// </summary>
		public string[] Groups { get; set; }

		public override object TypeId { get { return Properties.GetHashCode() + Groups.GetHashCode(); } }

		public readonly ARC_HybridAlgo_StrategyContext[] Contexts;
		public ARC_HybridAlgo_HideParametersAttribute(params ARC_HybridAlgo_StrategyContext[] contexts)
		{
			Contexts = contexts;
			Properties = Array.Empty<string>();
			Groups = Array.Empty<string>();
		}

		public ARC_HybridAlgo_HideParametersAttribute() : this(Array.Empty<ARC_HybridAlgo_StrategyContext>())
		{
			Properties = Array.Empty<string>();
			Groups = Array.Empty<string>();
		}
	}
	
	/// <summary>
	/// Used to hide other properties when the value of this one matches the provided value
	/// </summary>
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
	public class ARC_HybridAlgo_HideOthersIfAttribute : ARC_HybridAlgo_SelfReferencingConditionalAttributeBase
	{
		/// <summary>
		/// The affected Properties
		/// </summary>
		public string[] Properties { get; set; }

		/// <summary>
		/// The affected Group
		/// </summary>
		public string[] Groups { get; set; }

		public ARC_HybridAlgo_HideOthersIfAttribute(ARC_HybridAlgo_PropComparisonType compareType, params object[] args) : base(compareType, args)
		{
			Properties = Array.Empty<string>();
			Groups = Array.Empty<string>();
		}

		public ARC_HybridAlgo_HideOthersIfAttribute(ARC_HybridAlgo_HideOthersIfAttribute attr) : base(attr)
		{ }

		public override object Clone()
		{
			return new ARC_HybridAlgo_HideOthersIfAttribute(this);
		}

		public override ARC_HybridAlgo_IReferencesPropsByName TransformPropNames(Func<string, string> transform)
		{
			var newAttr = (ARC_HybridAlgo_HideOthersIfAttribute) Clone();
			newAttr.Properties = Properties
				.Select(transform)
				.ToArray();
			return newAttr;
		}
	}

	/// <summary>
	/// Browsable(false) removed properties from the descriptor collection, meaning they can't be shown conditionally, only hidden conditionally. This preserves them.
	/// </summary>
	[AttributeUsage(AttributeTargets.Property)]
	public class ARC_HybridAlgo_HideByDefaultAttribute : Attribute
	{ }

	public enum ARC_HybridAlgo_StrategyContext
	{
		Realtime,
		Backtest,
		Optimization
	}
}
