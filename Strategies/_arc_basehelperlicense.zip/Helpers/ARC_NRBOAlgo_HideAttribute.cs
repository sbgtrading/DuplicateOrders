﻿using System;
using System.Linq;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	/// <summary>
	/// Used to hide this property unless the criteria is met
	/// </summary>
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
	public class ARC_NRBOAlgo_HideUnlessAttribute : ARC_NRBOAlgo_ReferentialConditionalAttributeBase
	{
		public ARC_NRBOAlgo_HideUnlessAttribute(string conditionPropName, ARC_NRBOAlgo_PropComparisonType compareType, params object[] args) : base(conditionPropName, compareType, args)
		{ }

		public ARC_NRBOAlgo_HideUnlessAttribute(ARC_NRBOAlgo_HideUnlessAttribute attr) : base(attr)
		{ }

		public override object Clone()
		{
			return new ARC_NRBOAlgo_HideUnlessAttribute(this);
		}
	}

	/// <summary>
	/// Used to hide other properties when the value of this one matches the provided value
	/// </summary>
	[AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
	public class ARC_NRBOAlgo_HideParametersAttribute : Attribute
	{
		/// <summary>
		/// The affected Properties
		/// </summary>
		public string[] Properties { get; set; }

		/// <summary>
		/// The affected Group
		/// </summary>
		public string[] Groups { get; set; }

		public override object TypeId => Properties.GetHashCode() + Groups.GetHashCode();

		public readonly ARC_NRBOAlgo_StrategyContext[] Contexts;
		public ARC_NRBOAlgo_HideParametersAttribute(params ARC_NRBOAlgo_StrategyContext[] contexts)
		{
			Contexts = contexts;
			Properties = Array.Empty<string>();
			Groups = Array.Empty<string>();
		}

		public ARC_NRBOAlgo_HideParametersAttribute() : this(Array.Empty<ARC_NRBOAlgo_StrategyContext>())
		{
			Properties = Array.Empty<string>();
			Groups = Array.Empty<string>();
		}
	}
	
	/// <summary>
	/// Used to hide other properties when the value of this one matches the provided value
	/// </summary>
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
	public class ARC_NRBOAlgo_HideOthersIfAttribute : ARC_NRBOAlgo_SelfReferencingConditionalAttributeBase
	{
		/// <summary>
		/// The affected Properties
		/// </summary>
		public string[] Properties { get; set; }

		/// <summary>
		/// The affected Group
		/// </summary>
		public string[] Groups { get; set; }

		public ARC_NRBOAlgo_HideOthersIfAttribute(ARC_NRBOAlgo_PropComparisonType compareType, params object[] args) : base(compareType, args)
		{
			Properties = Array.Empty<string>();
			Groups = Array.Empty<string>();
		}

		public ARC_NRBOAlgo_HideOthersIfAttribute(ARC_NRBOAlgo_HideOthersIfAttribute attr) : base(attr)
		{ }

		public override object Clone()
		{
			return new ARC_NRBOAlgo_HideOthersIfAttribute(this);
		}

		public override ARC_NRBOAlgo_IReferencesPropsByName TransformPropNames(Func<string, string> transform)
		{
			var newAttr = (ARC_NRBOAlgo_HideOthersIfAttribute) Clone();
			newAttr.Properties = Properties
				.Select(transform)
				.ToArray();
			return newAttr;
		}
	}

	/// <summary>
	/// Browsable(false) removed properties from the descriptor collection, meaning they can't be shown conditionally, only hidden conditionally. This preserves them.
	/// </summary>
	[AttributeUsage(AttributeTargets.Property)]
	public class ARC_NRBOAlgo_HideByDefaultAttribute : Attribute
	{ }

	public enum ARC_NRBOAlgo_StrategyContext
	{
		Realtime,
		Backtest,
		Optimization
	}
}
