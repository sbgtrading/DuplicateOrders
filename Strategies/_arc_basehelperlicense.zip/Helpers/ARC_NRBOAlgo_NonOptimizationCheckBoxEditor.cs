﻿using System.Globalization;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Controls.WpfPropertyGrid;
using System.Windows.Data;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	public class ARC_NRBOAlgo_NonOptimizationCheckBoxEditor : PropertyEditor
	{
		public ARC_NRBOAlgo_NonOptimizationCheckBoxEditor()
		{
			InlineTemplate = CreateTemplate();
		}

		private static DataTemplate CreateTemplate()
		{
			var checkBox = new FrameworkElementFactory(typeof(CheckBox));
			checkBox.SetBinding(ToggleButton.IsCheckedProperty, new Binding("Value") { Converter = new ARC_NRBOAlgo_BoolEnumValueConverter(), Mode = BindingMode.TwoWay });
			return new DataTemplate(typeof(CheckBox)) { VisualTree = checkBox };
		}
	}

	public class ARC_NRBOAlgo_BoolEnumValueConverter : IValueConverter
	{
		private static bool ToBoolean(object value)
		{
			return value.ToString().ToLower() == "true";
		}

		private static ARC_NRBOAlgo_BoolEnum ToEnum(object value)
		{
			return value.ToString().ToLower() == "true" ? ARC_NRBOAlgo_BoolEnum.True : ARC_NRBOAlgo_BoolEnum.False;
		}

		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return targetType == typeof(bool) ? (object) ToEnum(value) : ToBoolean(value);
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			if (value == null)
				return null;
		
			return targetType == typeof(bool) ? (object) ToEnum(value) : ToBoolean(value);
		}
	}
}