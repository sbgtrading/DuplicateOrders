﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Controls.WpfPropertyGrid;
using System.Windows.Controls.WpfPropertyGrid.Controls;
using System.Windows.Controls.WpfPropertyGrid.Design;
using System.Windows.Data;
using System.Windows.Media;
using NinjaTrader.Gui;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	public class ARC_FractalBreakoutAlgo_EnhancedBrush
	{
		public Brush OpaqueBrush
		{
			get => opaqueBrush;
			set
			{
				opaqueBrush = value;
				frozenBrush = null;
				IsTransparent = value == Brushes.Transparent;
			}
		}
		private Brush opaqueBrush;

		public float Opacity
		{
			get => opacity;
			set
			{
				opacity = value;
				frozenBrush = null;
			}
		}
		private float opacity;
		
		public bool IsTransparent { get; set; }

		private Brush frozenBrush;
		public ARC_FractalBreakoutAlgo_EnhancedBrush(Brush opaqueBrush, float opacity = 1f)
		{
			OpaqueBrush = opaqueBrush;
			Opacity = opacity;
			IsTransparent = opaqueBrush == Brushes.Transparent;
		}
		
		public ARC_FractalBreakoutAlgo_EnhancedBrush()
		{
			Opacity = 1;
		}

		public static implicit operator Brush(ARC_FractalBreakoutAlgo_EnhancedBrush brush)
		{
			return brush.frozenBrush ?? (brush.frozenBrush = brush.OpaqueBrush.ARC_FractalBreakoutAlgo_WithAlpha(brush.IsTransparent ? 0 : brush.Opacity).ToFrozenBrush());
		}
		
		public static implicit operator ARC_FractalBreakoutAlgo_EnhancedBrush(Brush brush)
		{
			var brushColor = brush.ARC_FractalBreakoutAlgo_GetColor();
			return new ARC_FractalBreakoutAlgo_EnhancedBrush
			{
				OpaqueBrush = brush == Brushes.Transparent 
					? Brushes.Transparent 
					: typeof(Brushes)
						.GetProperties()
						.Select(p => p.GetValue(null, null))
						.OfType<Brush>()
						.Where(b => b != Brushes.Transparent)
						.First(b =>
						{
							var color = b.ARC_FractalBreakoutAlgo_GetColor();
							return color.R == brushColor.R && color.G == brushColor.G && color.B == brushColor.B;
						}),
				Opacity = brushColor.A / 255f,
				IsTransparent = brush == Brushes.Transparent
			};
		}

		public override string ToString()
		{
			return this;
		}

		public static implicit operator string(ARC_FractalBreakoutAlgo_EnhancedBrush brush)
		{
			var clr = brush.opaqueBrush.ARC_FractalBreakoutAlgo_GetColor();
			return string.Join(":", new [] { (int) (brush.Opacity * 255), clr.R, clr.G, clr.B, brush.IsTransparent ? 1 : 0 });
		}
		
		public static implicit operator ARC_FractalBreakoutAlgo_EnhancedBrush(string brush)
		{
			var clrParts = brush.Split(':')
				.Select(int.Parse)
				.ToArray();
			return new ARC_FractalBreakoutAlgo_EnhancedBrush
			{
				Opacity = clrParts[0] / 255f,
				IsTransparent = clrParts[4] == 1,
				OpaqueBrush = clrParts[4] == 1 
					? Brushes.Transparent 
					: typeof(Brushes)
						.GetProperties()
						.Select(p => p.GetValue(null, null))
						.OfType<Brush>()
						.Where(b => b != Brushes.Transparent)
						.First(b =>
						{
							var color = b.ARC_FractalBreakoutAlgo_GetColor();
							return color.R == clrParts[1] && color.G == clrParts[2] && color.B == clrParts[3];
						})
			};
		}
	}

	public class ARC_FractalBreakoutAlgo_EnhancedBrushPicker : PropertyEditor
	{
		public ARC_FractalBreakoutAlgo_EnhancedBrushPicker()
		{
			InlineTemplate = CreateTemplate();
		}

		private static DataTemplate CreateTemplate()
		{
			var editor = new FrameworkElementFactory(typeof(StackPanel));
			editor.SetValue(FrameworkElement.DataContextProperty, new Binding("Value"));

			// Create a ComboBox to select the brush
			var brushComboBoxFactory = new FrameworkElementFactory(typeof(BrushPicker));
			brushComboBoxFactory.SetBinding(BrushPicker.SelectedBrushProperty, new Binding("OpaqueBrush") { Mode = BindingMode.TwoWay });
			editor.AppendChild(brushComboBoxFactory);

			// Create a row for the opacity label and slider
			var opacitySectionFactory = new FrameworkElementFactory(typeof(Grid));
			for (var c = 0; c < 2; c++)
			{
				var column = new FrameworkElementFactory(typeof(ColumnDefinition));
				column.SetValue(ColumnDefinition.WidthProperty, new GridLength(1, c == 0 ? GridUnitType.Auto : GridUnitType.Star));
				opacitySectionFactory.AppendChild(column);
			}
			editor.AppendChild(opacitySectionFactory);

			// Add the label
			var opacityLabelFactory = new FrameworkElementFactory(typeof(PropertyNameTextBlock));
			opacityLabelFactory.SetValue(TextBlock.TextProperty, "Opacity: ");
			opacityLabelFactory.SetValue(Grid.ColumnProperty, 0);
			opacitySectionFactory.AppendChild(opacityLabelFactory);

			// Create a Slider for opacity
			var opacitySliderFactory = new FrameworkElementFactory(typeof(Slider));
			opacitySliderFactory.SetValue(RangeBase.MinimumProperty, 0.0);
			opacitySliderFactory.SetValue(RangeBase.MaximumProperty, 1.0);
			opacitySliderFactory.SetValue(RangeBase.SmallChangeProperty, 0.01);
			opacitySliderFactory.SetValue(RangeBase.LargeChangeProperty, 0.1);
			opacitySliderFactory.SetValue(Grid.ColumnProperty, 1);
			opacitySliderFactory.SetBinding(RangeBase.ValueProperty, new Binding("Opacity") { Mode = BindingMode.TwoWay });
			opacitySectionFactory.AppendChild(opacitySliderFactory);

			return new DataTemplate(typeof(StackPanel)) { VisualTree = editor };
		}
	}
}