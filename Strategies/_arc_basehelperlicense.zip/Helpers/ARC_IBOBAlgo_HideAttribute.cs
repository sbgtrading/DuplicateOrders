﻿using System;
using System.Linq;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	/// <summary>
	/// Used to hide this property unless the criteria is met
	/// </summary>
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
	public class ARC_IBOBAlgo_HideUnlessAttribute : ARC_IBOBAlgo_ReferentialConditionalAttributeBase
	{
		public ARC_IBOBAlgo_HideUnlessAttribute(string conditionPropName, ARC_IBOBAlgo_PropComparisonType compareType, params object[] args) : base(conditionPropName, compareType, args)
		{ }

		public ARC_IBOBAlgo_HideUnlessAttribute(ARC_IBOBAlgo_HideUnlessAttribute attr) : base(attr)
		{ }

		public override object Clone()
		{
			return new ARC_IBOBAlgo_HideUnlessAttribute(this);
		}
	}

	/// <summary>
	/// Used to hide other properties when the value of this one matches the provided value
	/// </summary>
	[AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
	public class ARC_IBOBAlgo_HideParametersAttribute : Attribute
	{
		/// <summary>
		/// The affected Properties
		/// </summary>
		public string[] Properties { get; set; }

		/// <summary>
		/// The affected Group
		/// </summary>
		public string[] Groups { get; set; }

		public override object TypeId => Properties.GetHashCode() + Groups.GetHashCode();

		public readonly ARC_IBOBAlgo_StrategyContext[] Contexts;
		public ARC_IBOBAlgo_HideParametersAttribute(params ARC_IBOBAlgo_StrategyContext[] contexts)
		{
			Contexts = contexts;
			Properties = Array.Empty<string>();
			Groups = Array.Empty<string>();
		}

		public ARC_IBOBAlgo_HideParametersAttribute() : this(Array.Empty<ARC_IBOBAlgo_StrategyContext>())
		{
			Properties = Array.Empty<string>();
			Groups = Array.Empty<string>();
		}
	}
	
	/// <summary>
	/// Used to hide other properties when the value of this one matches the provided value
	/// </summary>
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
	public class ARC_IBOBAlgo_HideOthersIfAttribute : ARC_IBOBAlgo_SelfReferencingConditionalAttributeBase
	{
		/// <summary>
		/// The affected Properties
		/// </summary>
		public string[] Properties { get; set; }

		/// <summary>
		/// The affected Group
		/// </summary>
		public string[] Groups { get; set; }

		public ARC_IBOBAlgo_HideOthersIfAttribute(ARC_IBOBAlgo_PropComparisonType compareType, params object[] args) : base(compareType, args)
		{
			Properties = Array.Empty<string>();
			Groups = Array.Empty<string>();
		}

		public ARC_IBOBAlgo_HideOthersIfAttribute(ARC_IBOBAlgo_HideOthersIfAttribute attr) : base(attr)
		{ }

		public override object Clone()
		{
			return new ARC_IBOBAlgo_HideOthersIfAttribute(this);
		}

		public override ARC_IBOBAlgo_IReferencesPropsByName TransformPropNames(Func<string, string> transform)
		{
			var newAttr = (ARC_IBOBAlgo_HideOthersIfAttribute) Clone();
			newAttr.Properties = Properties
				.Select(transform)
				.ToArray();
			return newAttr;
		}
	}

	/// <summary>
	/// Browsable(false) removed properties from the descriptor collection, meaning they can't be shown conditionally, only hidden conditionally. This preserves them.
	/// </summary>
	[AttributeUsage(AttributeTargets.Property)]
	public class ARC_IBOBAlgo_HideByDefaultAttribute : Attribute
	{ }

	public enum ARC_IBOBAlgo_StrategyContext
	{
		Realtime,
		Backtest,
		Optimization
	}
}
