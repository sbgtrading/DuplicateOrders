﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows;
using System.Windows.Controls.Primitives;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using Control = System.Windows.Forms.Control;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	internal static class ARC_APSAlgo_MenuItemExtensions
	{
		/// <summary>
		/// Dispose the menu by deleting it from it's parent's items and clearing any events that have handlers registered
		/// </summary>
		/// <param name="item"></param>
		/// <returns></returns>
		internal static void ARC_APSAlgo_Delete(this NTMenuItem item)
		{
			if (item == null)
				return;

			var parent = item.ARC_APSAlgo_GetAncestor<NTMenuItem>();
			parent?.Items.Remove(item);
			item.ARC_APSAlgo_ClearInvocations(MenuItem.ClickEvent);
		}
	}

	internal static class ARC_APSAlgo_UiElementExtensions
	{
		/// <summary>
		/// Clear invocations of the given events
		/// </summary>
		/// <param name="target"></param>
		/// <param name="routedEvents"></param>
		internal static void ARC_APSAlgo_ClearInvocations(this UIElement target, params RoutedEvent[] routedEvents)
		{
			if (target == null)
				return;

			if (routedEvents.Length == 0)
				throw new ArgumentException("Must be provided routed events to clear subscribers from", nameof(routedEvents));

			foreach (var e in routedEvents)
				target.ARC_APSAlgo_RemoveRoutedEventHandlers(e);
		}

		/// <summary>
		/// Removes all event handlers subscribed to the specified routed event from the specified element.
		/// </summary>
		/// <param name="element">The UI element on which the routed event is defined.</param>
		/// <param name="routedEvent">The routed event for which to remove the event handlers.</param>
		internal static void ARC_APSAlgo_RemoveRoutedEventHandlers(this UIElement element, RoutedEvent routedEvent)
		{
			if (element == null)
				return;

			// Get the EventHandlersStore instance which holds event handlers for the specified element.
			// The EventHandlersStore class is declared as internal.
			var eventHandlersStoreProperty = typeof(UIElement).GetProperty("EventHandlersStore", BindingFlags.Instance | BindingFlags.NonPublic);
			if (eventHandlersStoreProperty == null)
				return;

			var eventHandlersStore = eventHandlersStoreProperty.GetValue(element, null);
			if (eventHandlersStore == null)
				return;

			// Invoke the GetRoutedEventHandlers method on the EventHandlersStore instance 
			// for getting an array of the subscribed event handlers.
			var getRoutedEventHandlers = eventHandlersStore.GetType().GetMethod("GetRoutedEventHandlers", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
			if (getRoutedEventHandlers == null)
				return;

			var routedEventHandlers = (RoutedEventHandlerInfo[])getRoutedEventHandlers.Invoke(eventHandlersStore, new object[] { routedEvent });
			if (routedEventHandlers == null)
				return;

			// Iteratively remove all routed event handlers from the element.
			foreach (var routedEventHandler in routedEventHandlers.Where(reh => reh.Handler != null))
				element.RemoveHandler(routedEvent, routedEventHandler.Handler);
		}

		internal static TElement ARC_APSAlgo_GetAncestor<TElement>(this FrameworkElement descendent) where TElement : class
		{
			while (true)
			{
				if (descendent == null)
					return null;

				var parent = VisualTreeHelper.GetParent(descendent);
				if (parent is TElement typedParent)
					return typedParent;

				descendent = parent as FrameworkElement;
			}
		}

		/// <summary>
		/// Finds a Child of a given item in the visual tree. 
		/// </summary>
		/// <param name="parent">A direct parent of the queried item.</param>
		/// <typeparam name="TTarget">The type of the queried item.</typeparam>
		/// <param name="elementValidator"></param>
		/// <returns>The first parent item that matches the submitted type parameter. 
		/// If not matching item can be found, 
		/// a null parent is being returned.</returns>
		internal static TTarget ARC_APSAlgo_FindBy<TTarget>(this DependencyObject parent, Func<TTarget, bool> elementValidator) where TTarget : class
		{
			// Confirm parent and childName are valid. 
			if (parent == null)
				return null;

			var children = new List<DependencyObject>();
			var visualChildCount = VisualTreeHelper.GetChildrenCount(parent);
			for (var i = 0; i < visualChildCount; i++)
				children.Add(VisualTreeHelper.GetChild(parent, i));

			foreach (var child in children)
			{
				// If the child is not of the request child type child
				if (child is TTarget childType && elementValidator(childType))
					return childType;

				// recursively drill down the tree
				var foundChild = child.ARC_APSAlgo_FindBy(elementValidator);

				// If the child is found, break so we do not overwrite the found child. 
				if (foundChild != null)
					return foundChild;
			}

			return null;
		}

		internal static TElement ARC_APSAlgo_FindByName<TElement>(this FrameworkElement parent, string name) where TElement : class
		{
			return parent.ARC_APSAlgo_FindBy<TElement>(e =>
			{
				if (e is FrameworkElement fe)
					return fe.Name == name;

				if (e is Control ctrl)
					return ctrl.Name == name;

				return false;
			});
		}

		internal static void ARC_APSAlgo_SetChildRowColumn(this Grid grid, UIElement child, int row, int column, int rowSpan = 1, int columnSpan = 1)
		{
			if (!grid.Children.Contains(child))
				grid.Children.Add(child);

			Grid.SetRow(child, row);
			Grid.SetRowSpan(child, rowSpan);

			Grid.SetColumn(child, column);
			Grid.SetColumnSpan(child, columnSpan);
		}
	}

	internal static class ARC_APSAlgo_ChartExtensions
	{
		internal static ScrollBar ARC_APSAlgo_GetScrollbar(this ChartControl chartCtrl)
		{
			var chartTab = chartCtrl.ARC_APSAlgo_GetAncestor<ChartTab>();
			return chartTab?.ARC_APSAlgo_FindByName<ScrollBar>("scrollBar");
		}

		// TODO: Not working, check out ChartControl.BringIntoView?
		internal static void ARC_APSAlgo_SetViewportWidth(this ChartControl chartCtrl, int bars)
		{
			var scrollBar = chartCtrl.ARC_APSAlgo_GetScrollbar();
			if (scrollBar == null)
				return;
			scrollBar.ViewportSize = bars;
		}

		internal static void ARC_APSAlgo_ScrollToBar(this ChartControl chartCtrl, int barIndex, ARC_APSAlgo_SubjectAlignment alignment = ARC_APSAlgo_SubjectAlignment.Center)
		{
			var scrollBar = chartCtrl.ARC_APSAlgo_GetScrollbar();
			if (scrollBar == null)
				return;

			scrollBar.Value = alignment switch
			{
				ARC_APSAlgo_SubjectAlignment.Center => barIndex + scrollBar.ViewportSize / 2,
				ARC_APSAlgo_SubjectAlignment.Left => barIndex - scrollBar.ViewportSize,
				ARC_APSAlgo_SubjectAlignment.Right => barIndex,
				_ => throw new ArgumentOutOfRangeException(nameof(alignment), alignment, null)
			};
		}
	}

	internal enum ARC_APSAlgo_SubjectAlignment
	{
		Center,
		Left,
		Right
	}
}
