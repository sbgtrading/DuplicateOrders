﻿using System;
using System.Collections.Concurrent;
using System.Linq;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	/// <summary>
	/// The same as a dictionary, except that it automatically adds a default value for the requested key if it doesn't exist yet
	/// </summary>
	/// <typeparam name="TKey"></typeparam>
	/// <typeparam name="TValue"></typeparam>
	public class ARC_ThrustBreakoutAlgo_DefaultingDictionary<TKey, TValue> : ConcurrentDictionary<TKey, TValue>
	{
		private readonly TValue defaultValue;
		private readonly Func<TKey, TValue> defaultValueFactory;
		public ARC_ThrustBreakoutAlgo_DefaultingDictionary()
		{
			defaultValue = default;
		}
		
		public ARC_ThrustBreakoutAlgo_DefaultingDictionary(TValue defaultOverride)
		{
			defaultValue = defaultOverride;
		}
		
		public ARC_ThrustBreakoutAlgo_DefaultingDictionary(Func<TKey, TValue> defaultFactory)
		{
			defaultValueFactory = defaultFactory;
		}

		public bool Remove(TKey key)
		{
			return TryRemove(key, out _);
		}

		public new TValue this[TKey key]
		{
			get
			{
				if (TryGetValue(key, out var outValue))
					return outValue;

				return this[key] = defaultValueFactory == null ? defaultValue : defaultValueFactory(key);
			}
			set => base[key] = value;
		}

		public string ToString(char separator, Func<TKey, string> keyStringifier, Func<TValue, string> valueStringifier)
		{
			return Keys.Aggregate("", (current, key) => current + keyStringifier(key) + separator + valueStringifier(this[key]) + separator).Trim(separator);
		}
	}

	public class ARC_ThrustBreakoutAlgo_DefaultingDictionary
	{
		public static ARC_ThrustBreakoutAlgo_DefaultingDictionary<TKey, TValue> ARC_ThrustBreakoutAlgo_FromString<TKey, TValue>(string str, char separator, Func<string, TKey> keyParser, Func<string, TValue> valueParser)
		{
			var parts = str.Split(separator);
			var dict = new ARC_ThrustBreakoutAlgo_DefaultingDictionary<TKey, TValue>();
			for (var i = 0; i < parts.Length / 2; i++)
				dict[keyParser(parts[2 * i])] = valueParser(parts[2 * i + 1]);
			return dict;
		}
	}
}