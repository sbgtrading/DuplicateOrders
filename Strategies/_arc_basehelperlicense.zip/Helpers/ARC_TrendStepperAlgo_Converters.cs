using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Reflection;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Strategies;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	public class ARC_TrendStepperAlgo_ExtendedStrategyConverter : StrategyBaseConverter
	{
		public override PropertyDescriptorCollection GetProperties(ITypeDescriptorContext context, object component, Attribute[] attrs)
		{
			var propertyDescriptorCollection = base.GetPropertiesSupported(context)
				? base.GetProperties(context, component, attrs)
				: TypeDescriptor.GetProperties(component, attrs);

			if (propertyDescriptorCollection == null)
				return null;

			try
			{
				var helper = new ARC_TrendStepperAlgo_DynamicPropertiesHelper(component, propertyDescriptorCollection);
				helper.UpdateProperties();
				return propertyDescriptorCollection;
			}
			catch
			{
				return base.GetPropertiesSupported(context)
					? base.GetProperties(context, component, attrs)
					: TypeDescriptor.GetProperties(component, attrs);
			}
		}

		public override bool GetPropertiesSupported(ITypeDescriptorContext context)
		{
			return true;
		}
	}

	public class ARC_TrendStepperAlgo_ExtendedIndicatorConverter : IndicatorBaseConverter
	{
		public override PropertyDescriptorCollection GetProperties(ITypeDescriptorContext context, object component, Attribute[] attrs)
		{
			var propertyDescriptorCollection = base.GetPropertiesSupported(context)
				? base.GetProperties(context, component, attrs)
				: TypeDescriptor.GetProperties(component, attrs);

			if (propertyDescriptorCollection == null)
				return null;

			try
			{
				var helper = new ARC_TrendStepperAlgo_DynamicPropertiesHelper(component, propertyDescriptorCollection);
				helper.UpdateProperties();
				return propertyDescriptorCollection;
			}
			catch
			{
				return base.GetPropertiesSupported(context)
					? base.GetProperties(context, component, attrs)
					: TypeDescriptor.GetProperties(component, attrs);
			}
		}

		public override bool GetPropertiesSupported(ITypeDescriptorContext context)
		{
			return true;
		}
	}

	public class ARC_TrendStepperAlgo_DynamicPropertiesHelper
	{
		private bool ParametersAreSingles
		{
			get
			{
				var asStrategy = component as Strategy;
				return asStrategy == null
				       || asStrategy.Category == Category.Backtest
				       || (asStrategy.Category == Category.NinjaScript && !asStrategy.IsInStrategyAnalyzer);
			}
		}

		[SuppressMessage("ReSharper", "CollectionNeverUpdated.Local")]
		private readonly ARC_TrendStepperAlgo_DefaultingDictionary<Type, PropertyInfo[]> typeToPropInfoCache = new ARC_TrendStepperAlgo_DefaultingDictionary<Type, PropertyInfo[]>(key => key.GetProperties());

		private readonly Dictionary<PropertyDescriptor, PropertyInfo> propDescriptorToPropInfoCache = new Dictionary<PropertyDescriptor, PropertyInfo>();
		private PropertyDescriptor[] completePropDescriptorSet = Array.Empty<PropertyDescriptor>();

		private readonly object component;
		private readonly PropertyDescriptorCollection propertyDescriptorCollection;

		public ARC_TrendStepperAlgo_DynamicPropertiesHelper(object component, PropertyDescriptorCollection propertyDescriptorCollection)
		{
			this.component = component;
			this.propertyDescriptorCollection = propertyDescriptorCollection;
		}

		#region Dynamic Property Handlers
		public void UpdateProperties()
		{
			RefreshCompletePropDescriptorSet();
			HandleRenamedProperties();
			HandleHiddenProperties();
			HandleShownProperties();
		}

		private void HandleRenamedProperties()
		{
			var type = component.GetType();
			var propRenameDict = type.GetCustomAttributes<ARC_TrendStepperAlgo_RenameParameterAttribute>().ToDictionary(a => a.property, a => a.newName);

			// Handle conditional renames
			if (ParametersAreSingles)
				foreach (var kvp in GetConditionalAttrsByState<ARC_TrendStepperAlgo_RenameAttribute>(true))
					propRenameDict[kvp.Key.Name] = kvp.Value
						.Select(v => v.newName)
						.Last();

			foreach (var p in propertyDescriptorCollection.OfType<PropertyDescriptor>())
			{
				string newName;
				if (!propRenameDict.TryGetValue(p.Name, out newName))
					continue;

				var attr = p.Attributes.OfType<DisplayAttribute>().FirstOrDefault();
				if (attr != null)
					attr.Name = newName;
			}
		}

		private void HandleShownProperties()
		{
			// Start with the class level attribute usage
			var shownGroups = new List<string>();
			var shownProps = new List<string>();
			
			// Hide any props associated with HideOthers if props
			var passedOthersIfProps = GetConditionalAttrsByState<ARC_TrendStepperAlgo_ShowOthersIfAttribute>(true);
			foreach (var attr in passedOthersIfProps.SelectMany(kvp => kvp.Value))
			{
				shownProps.AddRange(attr.Properties);
				shownGroups.AddRange(attr.Groups);
			}

			var passedIfProps = GetConditionalAttrsByState<ARC_TrendStepperAlgo_ShowIfAttribute>(true);
			shownProps.AddRange(passedIfProps.Select(p => p.Key.Name));

			var shownPropDescriptors = new List<PropertyDescriptor>();
			foreach (var p in propertyDescriptorCollection.OfType<PropertyDescriptor>())
			{
				var displayParameter = p.Attributes
					.OfType<DisplayAttribute>()
					.FirstOrDefault();
				
				// First check if the prop is a part of a hidden group
				var shown = displayParameter != null && displayParameter.GroupName != null && shownGroups.Contains(displayParameter.GroupName);

				// Next check if the prop is either parented by, or is itself, a directly hidden prop
				shown = shown || shownProps.Any(name => name == p.Name);

				if (!shown)
					continue;

				shownPropDescriptors.Add(p);
			}
			
			foreach (var prop in propertyDescriptorCollection
				.OfType<PropertyDescriptor>()
				.Where(p => p.Attributes[typeof(ARC_TrendStepperAlgo_HideByDefaultAttribute)] != null)
				.Except(shownPropDescriptors))
				propertyDescriptorCollection.Remove(prop);
		}

		private void HandleHiddenProperties()
		{
			var asStrategy = component as Strategy;

			// Start with the class level attribute usage
			var type = component.GetType();
			var typeLevelActiveHideAttrs = type.GetCustomAttributes<ARC_TrendStepperAlgo_HideParametersAttribute>()
				.Where(a =>
				{
					if (asStrategy == null || a.Contexts.Length == 0)
						return false;
					if (a.Contexts.Contains(ARC_TrendStepperAlgo_StrategyContext.Backtest) && asStrategy.Category == Category.Backtest)
						return true;
					if (a.Contexts.Contains(ARC_TrendStepperAlgo_StrategyContext.Optimization) && !ParametersAreSingles)
						return true;
					if (a.Contexts.Contains(ARC_TrendStepperAlgo_StrategyContext.Realtime) && asStrategy.Category == Category.NinjaScript)
						return true;
					return false;
				})
				.ToArray();
			var hiddenGroups = typeLevelActiveHideAttrs
				.Where(a => a.Groups != null)
				.SelectMany(a => a.Groups)
				.ToList();
			var hiddenProps = typeLevelActiveHideAttrs
				.Where(a => a.Properties != null)
				.SelectMany(a => a.Properties)
				.ToList();

			// Hide any props associated with passed HideUnless props
			var passedHideUnlessProps = GetConditionalAttrsByState<ARC_TrendStepperAlgo_HideUnlessAttribute>(false);
			hiddenProps.AddRange(passedHideUnlessProps.Keys.Select(p => p.Name));

			// Hide any props associated with HideOthers if props
			var passedOthersIfProps = GetConditionalAttrsByState<ARC_TrendStepperAlgo_HideOthersIfAttribute>(true);
			foreach (var attr in passedOthersIfProps.SelectMany(kvp => kvp.Value))
			{
				hiddenProps.AddRange(attr.Properties);
				hiddenGroups.AddRange(attr.Groups);
			}

			var props = propertyDescriptorCollection
				.OfType<PropertyDescriptor>()
				.ToArray();
			foreach (var p in props)
			{
				var displayParameter = p.Attributes
					.OfType<DisplayAttribute>()
					.FirstOrDefault();
				
				// First check if the prop is a part of a hidden group
				var hidden = displayParameter != null && displayParameter.GroupName != null && hiddenGroups.Contains(displayParameter.GroupName);

				// Next check if the prop is either parented by, or is itself, a directly hidden prop
				hidden = hidden || hiddenProps.Any(name => name == p.Name);

				if (!hidden)
					continue;
				
				propertyDescriptorCollection.Remove(p);
			}
		}
		#endregion

		#region Misc
		private void RefreshCompletePropDescriptorSet()
		{
			completePropDescriptorSet = propertyDescriptorCollection
				.OfType<PropertyDescriptor>()
				.Union(TypeDescriptor.GetProperties(component.GetType()).OfType<PropertyDescriptor>())
				.ToArray();
		}

		private PropertyInfo GetPropertyInfo(PropertyDescriptor prop)
		{
			PropertyInfo info;
			if (propDescriptorToPropInfoCache.TryGetValue(prop, out info))
				return info;

			// Flattened properties names are denoted "parent.child" so we allow for loop recursion to drill down to the root property
			var parentType = prop.ComponentType;
			var propChain = prop.Name.Split('.');
			foreach (var name in propChain)
			{
				var parentPropInfos = typeToPropInfoCache[parentType];
				info = parentPropInfos.FirstOrDefault(i => i.Name == name);
				if (info == null)
					break;

				parentType = info.PropertyType;
			}

			return propDescriptorToPropInfoCache[prop] = info;
		}

		private Dictionary<PropertyDescriptor, TAttr[]> GetConditionalAttrsByState<TAttr>(bool matchState) where TAttr : ARC_TrendStepperAlgo_ConditionalAttributeBase
		{
			var isSelfReferencing = typeof(ARC_TrendStepperAlgo_SelfReferencingConditionalAttributeBase).IsAssignableFrom(typeof(TAttr));

			// Get a list of TAttr instances per decorated property (We use wrappers to ensure self referential conditional
			// attributes with the same properties but attached to different properties aren't considered equal)
			var decoratedPropDescriptorsToAttrs = new Dictionary<PropertyDescriptor, ConditionalAttributeReferentialWrapper[]>();
			foreach (var p in completePropDescriptorSet)
			{
				var info = GetPropertyInfo(p);
				if (info == null)
					continue;

				var attrs = info.GetCustomAttributes<TAttr>()
					.Select(a => new ConditionalAttributeReferentialWrapper(isSelfReferencing ? p.Name : ((ARC_TrendStepperAlgo_ReferentialConditionalAttributeBase)(object)a).ConditionPropName, a))
					.ToArray();
				if (attrs.Length == 0)
					continue;

				decoratedPropDescriptorsToAttrs[p] = attrs;
			}

			if (decoratedPropDescriptorsToAttrs.Count == 0)
				return new Dictionary<PropertyDescriptor, TAttr[]>();

			// Create a dictionary relating attributes to condition properties
			var attrToConditionProp = decoratedPropDescriptorsToAttrs
				.SelectMany(kvp => kvp.Value)
				.Distinct()
				.ToDictionary(a => a, a => completePropDescriptorSet.FirstOrDefault(p => p.Name == a.ConditionPropName));

			// Remove all properties where no name matched the condition property name
			foreach (var kvp in attrToConditionProp.Where(kvp => kvp.Value == null).ToList())
			{
				Debug.WriteLine("Converter couldn't find property named \"" + kvp.Value.Name + "\"");
				attrToConditionProp.Remove(kvp.Key);
			}

			// Build a dictionary relating props that we'll need values for to their values
			var conditionValues = new Dictionary<PropertyDescriptor, ValueSetBase>();
			var asStrategy = component as Strategy;
			foreach (var p in attrToConditionProp.Values.Distinct())
			{
				if (asStrategy == null || ParametersAreSingles)
				{
					conditionValues[p] = new ExactValueSet(p.GetValue(component));
					continue;
				}

				var param = asStrategy.OptimizationParameters.FirstOrDefault(p2 => p2.Name == p.Name);
				if (param == null)
				{
					conditionValues[p] = new ExactValueSet(p.GetValue(component));
					continue;
				}

				conditionValues[p] = new OptimizationParameterValueSet(param);
			}

			// Add in the hide prop level attribute usage
			var outDict = new Dictionary<PropertyDescriptor, TAttr[]>();
			foreach (var kvp in decoratedPropDescriptorsToAttrs)
			{
				var passingAttrs = kvp.Value
					.Where(attr =>
					{
						PropertyDescriptor conditionProp;
						if (!attrToConditionProp.TryGetValue(attr, out conditionProp))
							return false;

						ValueSetBase conditionValue;
						if (conditionValues.TryGetValue(conditionProp, out conditionValue))
							return conditionValue.Matches(attr) == matchState;

						Debug.WriteLine("Couldn't get value of property \"" + conditionProp.Name + "\"");
						return false;
					})
					.Select(a => a.ConditionalAttribute)
					.OfType<TAttr>()
					.ToArray();

				if (passingAttrs.Length == 0)
					continue;

				outDict[kvp.Key] = passingAttrs;
			}

			return outDict;
		}
		#endregion

		private abstract class ValueSetBase
		{
			public abstract bool Matches(ARC_TrendStepperAlgo_ConditionalAttributeBase attr);

			public bool Matches(ConditionalAttributeReferentialWrapper attr)
			{
				return Matches(attr.ConditionalAttribute);
			}
		}

		private class ExactValueSet : ValueSetBase
		{
			private readonly object expectedValue;

			public ExactValueSet(object value)
			{
				expectedValue = value;
			}

			public override bool Matches(ARC_TrendStepperAlgo_ConditionalAttributeBase attr)
			{
				return attr.MatchesCriteria(expectedValue);
			}
		}

		private class OptimizationParameterValueSet : ValueSetBase
		{
			private readonly Parameter parameter;

			public OptimizationParameterValueSet(Parameter param)
			{
				parameter = param;
			}

			public override bool Matches(ARC_TrendStepperAlgo_ConditionalAttributeBase attr)
			{
				return parameter.ParameterType.ARC_TrendStepperAlgo_IsNumeric()
					? attr.MatchesCriteria(parameter.Min) || attr.MatchesCriteria(parameter.Max)
					: parameter.EnumValues.Any(attr.MatchesCriteria);
			}
		}

		private class ConditionalAttributeReferentialWrapper
		{
			public readonly string ConditionPropName;
			public readonly ARC_TrendStepperAlgo_ConditionalAttributeBase ConditionalAttribute;

			public ConditionalAttributeReferentialWrapper(string conditionPropName, ARC_TrendStepperAlgo_ConditionalAttributeBase conditionalAttribute)
			{
				ConditionPropName = conditionPropName;
				ConditionalAttribute = conditionalAttribute;
			}

			public override bool Equals(object obj)
			{
				if (ReferenceEquals(null, obj))
					return false;
				if (ReferenceEquals(this, obj))
					return true;
				if (obj.GetType() != GetType())
					return false;
				return GetHashCode() != obj.GetHashCode();
			}

			public override int GetHashCode()
			{
				unchecked
				{
					return ((ConditionPropName != null ? ConditionPropName.GetHashCode() : 0) * 397) ^ (ConditionalAttribute != null ? ConditionalAttribute.TypeId.GetHashCode() : 0);
				}
			}
		}
	}

	public class ARC_TrendStepperAlgo_BoolEnumConverter : TypeConverter
	{
		public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
		{
			return InOptimization(context)
				? new StandardValuesCollection(Enum.GetValues(typeof(ARC_TrendStepperAlgo_BoolEnum)))
				: new StandardValuesCollection(new [] { true, false });
		}

		private bool InOptimization(ITypeDescriptorContext context)
		{
			if (context == null)
				return false;
			var asStrategy = context.Instance as Strategy;
			if (asStrategy == null)
				return false;

			return asStrategy.Category == Category.MultiObjective || asStrategy.Category == Category.Optimize || asStrategy.Category == Category.WalkForward;
		}

		private bool ToBoolean(object value)
		{
			return value.ToString().ToLower() == "true";
		}

		private ARC_TrendStepperAlgo_BoolEnum ToEnum(object value)
		{
			return Enum.GetValues(typeof(ARC_TrendStepperAlgo_BoolEnum))
				.OfType<ARC_TrendStepperAlgo_BoolEnum>()
				.First(b => value.ToString().ToLower() == b.ToString().ToLower());
		}

		public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
		{
			if (value == null)
				return null;

			return InOptimization(context) ? (object) ToBoolean(value) : ToEnum(value);
		}

		public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
		{
			if (value == null)
				return null;

			return InOptimization(context) ? (object) ToEnum(value) : ToBoolean(value);
		}

		public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
		{ return true; }

		public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
		{ return true; }

		public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
		{ return true; }

		public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
		{ return true; }
	}
}
