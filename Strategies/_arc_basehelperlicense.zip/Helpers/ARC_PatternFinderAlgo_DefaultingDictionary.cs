﻿using System;
using System.Collections.Generic;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	/// <summary>
	/// The same as a dictionary, except that it automatically adds a default value for the requested key if it doesn't exist yet
	/// </summary>
	/// <typeparam name="TKey"></typeparam>
	/// <typeparam name="TValue"></typeparam>
	public class ARC_PatternFinderAlgo_DefaultingDictionary<TKey, TValue> : Dictionary<TKey, TValue>
	{
		private readonly TValue defaultValue;
		private readonly Func<TKey, TValue> defaultValueFactory;
		public ARC_PatternFinderAlgo_DefaultingDictionary()
		{
			defaultValue = default(TValue);
		}
		
		public ARC_PatternFinderAlgo_DefaultingDictionary(TValue defaultOverride)
		{
			defaultValue = defaultOverride;
		}
		
		public ARC_PatternFinderAlgo_DefaultingDictionary(Func<TKey, TValue> defaultFactory)
		{
			defaultValueFactory = defaultFactory;
		}

		public new TValue this[TKey key]
		{
			get
			{
				TValue outValue;
				if (TryGetValue(key, out outValue))
					return outValue;

				return this[key] = defaultValueFactory == null ? defaultValue : defaultValueFactory(key);
			}
			set { base[key] = value; }
		}
	}
}