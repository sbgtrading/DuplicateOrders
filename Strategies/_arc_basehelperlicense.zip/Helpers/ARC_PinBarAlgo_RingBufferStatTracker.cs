﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	// TODO Somehow add the concept of shared samples in for efficiency

	public abstract class ARC_PinBarAlgo_RingBufferStatTracker
	{
		public virtual double Value { get; protected set; }
		public abstract int SampleCount { get; }

		protected int MaxSampleCount;
		protected ARC_PinBarAlgo_RingBufferStatTracker(int maxSampleCount)
		{
			if (maxSampleCount <= 0)
				throw new ArgumentOutOfRangeException(nameof(maxSampleCount), "Max sample count must be greater then 0");
			MaxSampleCount = maxSampleCount;
		}

		protected ARC_PinBarAlgo_RingBufferStatTracker(ARC_PinBarAlgo_RingBufferStatTracker statTracker)
		{
			statTracker.CopyTo(this);
		}

		public virtual void CopyTo(ARC_PinBarAlgo_RingBufferStatTracker statTracker)
		{
			statTracker.Value = Value;
			statTracker.MaxSampleCount = MaxSampleCount;
		}

		public static implicit operator double(ARC_PinBarAlgo_RingBufferStatTracker tracker)
		{
			return tracker.Value;
		}
	}

	#region Mono Input Trackers
	public abstract class ARC_PinBarAlgo_MonoInputRingBufferStatTracker : ARC_PinBarAlgo_RingBufferStatTracker
	{
		public override int SampleCount => ElementQueue.Count;
		public IReadOnlyCollection<double> Samples => ElementQueue;

		protected readonly Queue<double> ElementQueue = new Queue<double>();
		protected ARC_PinBarAlgo_MonoInputRingBufferStatTracker(int maxSampleCount) : base(maxSampleCount)
		{ }

		protected ARC_PinBarAlgo_MonoInputRingBufferStatTracker(ARC_PinBarAlgo_MonoInputRingBufferStatTracker statTracker) : base(statTracker)
		{
			foreach (var i in statTracker.ElementQueue)
				ElementQueue.Enqueue(i);
		}

		public virtual void AddSample(double sample)
		{
			if (ElementQueue.Count == MaxSampleCount)
			{
				OnSampleRemoved(ElementQueue.Peek());
				ElementQueue.Dequeue();
			}

			ElementQueue.Enqueue(sample);
		}

		public virtual void RemoveLastSample()
		{
			var elements = ElementQueue
				.Take(ElementQueue.Count - 1)
				.ToList();
			ElementQueue.Clear();
			elements.ForEach(AddSample);
		}

		protected abstract void OnSampleRemoved(double sample);
	}

	public class ARC_PinBarAlgo_AverageTracker : ARC_PinBarAlgo_MonoInputRingBufferStatTracker
	{
		public ARC_PinBarAlgo_AverageTracker(int maxSampleCount) : base(maxSampleCount)
		{ }

		public ARC_PinBarAlgo_AverageTracker(ARC_PinBarAlgo_AverageTracker statTracker) : base(statTracker)
		{ }

		protected override void OnSampleRemoved(double sample)
		{
			Value -= sample / SampleCount;
			Value *= SampleCount / (SampleCount - 1d);
		}

		public override void AddSample(double sample)
		{
			base.AddSample(sample);
			Value = ((SampleCount - 1) * Value + sample) / SampleCount;
		}
	}

	public class ARC_PinBarAlgo_EMATracker : ARC_PinBarAlgo_MonoInputRingBufferStatTracker
	{
		public ARC_PinBarAlgo_EMATracker(int maxSampleCount) : base(maxSampleCount)
		{ }

		public ARC_PinBarAlgo_EMATracker(ARC_PinBarAlgo_AverageTracker statTracker) : base(statTracker)
		{ }

		protected override void OnSampleRemoved(double sample)
		{ }

		public override void AddSample(double sample)
		{
			base.AddSample(sample);
			var c1 = 2.0 / (1 + SampleCount);
			var c2 = 1 - (2.0 / (1 + SampleCount));
			Value = SampleCount == 1 ? sample : sample * c1 + c2 * Value;
		}
	}

	public class ARC_PinBarAlgo_StdDevTracker : ARC_PinBarAlgo_MonoInputRingBufferStatTracker
	{
		public double Average { get; private set; }
		public ARC_PinBarAlgo_StdDevTracker(int maxSampleCount) : base(maxSampleCount)
		{ }

		public ARC_PinBarAlgo_StdDevTracker(ARC_PinBarAlgo_StdDevTracker statTracker) : base(statTracker)
		{ }

		protected override void OnSampleRemoved(double sample)
		{
			Average -= sample / SampleCount;
			Average *= SampleCount / (SampleCount - 1d);
		}

		public override void AddSample(double sample)
		{
			base.AddSample(sample);
			Average = ((SampleCount - 1) * Average + sample) / SampleCount;
			Value = Math.Sqrt(ElementQueue.Sum(v => Math.Pow(v - Average, 2)) / Math.Max(SampleCount, 1));
		}
	}

	public class ARC_PinBarAlgo_SumTracker : ARC_PinBarAlgo_MonoInputRingBufferStatTracker
	{
		public ARC_PinBarAlgo_SumTracker(int maxSampleCount) : base(maxSampleCount)
		{ }

		public ARC_PinBarAlgo_SumTracker(ARC_PinBarAlgo_SumTracker statTracker) : base(statTracker)
		{ }

		protected override void OnSampleRemoved(double sample)
		{
			Value -= sample;
		}

		public override void AddSample(double sample)
		{
			base.AddSample(sample);
			Value += sample;
		}
	}

	public class ARC_PinBarAlgo_VarianceTracker : ARC_PinBarAlgo_MonoInputRingBufferStatTracker
	{
		public override int SampleCount => avgTracker.SampleCount;

		private readonly ARC_PinBarAlgo_AverageTracker avgTracker;
		public ARC_PinBarAlgo_VarianceTracker(int maxSampleCount) : base(maxSampleCount)
		{
			avgTracker = new ARC_PinBarAlgo_AverageTracker(maxSampleCount);
		}

		public ARC_PinBarAlgo_VarianceTracker(ARC_PinBarAlgo_VarianceTracker statTracker) : base(statTracker)
		{ }

		public override void AddSample(double sample)
		{
			base.AddSample(sample);
			avgTracker.AddSample(sample);
			Value = Samples.Average(s => Math.Pow(s - avgTracker, 2));
		}

		protected override void OnSampleRemoved(double sample)
		{ }
	}
	#endregion
}
