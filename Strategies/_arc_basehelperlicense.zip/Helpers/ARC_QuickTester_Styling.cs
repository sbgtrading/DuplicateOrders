﻿using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NinjaTrader.Core;
using NinjaTrader.Gui.Tools;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	internal static class ARC_QuickTester_IconHelper
	{
		internal static FontFamily NtDefaultIconFont { get { return Application.Current.TryFindResource("IconsFamily") as FontFamily; } }

		/// <summary>Return the requested font family.</summary>
		/// <param name="ttfResourceFilePath">The path of the TTF resource file. Will use the builtin NT8 icon font if unspecified</param>
		private static FontFamily GetIconFontFamily(string ttfResourceFilePath = null)
		{
			return ttfResourceFilePath == null ? NtDefaultIconFont : new FontFamily(Path.Combine(Globals.UserDataDir, "templates", "Icon Fonts", "#" + ttfResourceFilePath));
		}

		/// <summary>Apply the provided icon to the control.</summary>
		/// <param name="control"></param>
		/// <param name="icon">One of the icons from <seealso cref="Icons"/> or <seealso cref="ARC_QuickTester_UnlistedNt8Icons"/> </param>
		/// <param name="ttfResourceFilePath">The path of the TTF resource file. Will use the builtin NT8 icon font if unspecified</param>
		internal static void ARC_QuickTester_SetIcon(this MenuItem control, string icon, string ttfResourceFilePath = null)
		{
			control.Icon = icon;
			control.FontFamily = GetIconFontFamily(ttfResourceFilePath);
		}

		/// <summary>Apply the provided icon to the control.</summary>
		/// <param name="control"></param>
		/// <param name="icon">One of the icons from <seealso cref="Icons"/> or <seealso cref="ARC_QuickTester_UnlistedNt8Icons"/> </param>
		/// <param name="ttfResourceFilePath">The path of the TTF resource file. Will use the builtin NT8 icon font if unspecified</param>
		internal static void ARC_QuickTester_SetIcon(this Button control, string icon, string ttfResourceFilePath = null)
		{
			control.Content = icon;
			control.FontFamily = GetIconFontFamily(ttfResourceFilePath);
		}
	}

	internal static class ARC_QuickTester_UnlistedNt8Icons
	{
		internal static string Star = "\xE01D";
		internal static string X = "\xE018";
		internal static string Flag = "\xE047";
	}

	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	internal enum ARC_QuickTester_NtStyle
	{
		FontControlReverseBrush,
		FontNormalTabHover,
		FontCryptoTrailingRun,
		FontModalTitle,
		FontActiveTab,
		FontHeaderLevel1,
		FontHeaderLevel1Trivial,
		FontGetConnectedSmall,
		FontControlTrivial,
		FontHeaderLevel4,
		FontCryptoRun,
		FontGetConnectedLarge,
		FontModalLinkHyperlink,
		FontHeaderLevel2,
		FontLabel,
		FontNormalTab,
		FontTable,
		FontList,
		FontModal,
		FontDailyChanged,
		FontButton,
		FontTitleBlock,
		FontModalLink,
		FontMainNavigation,
		FontHeaderLevel3,
		FontTableTrivial,
		FontLabelTrivial,
		FontAction,
		FontControl,
		PropertyEditorMultilineTextBox,
		PropertyEditorTextBox,
		InstrumentPopupTextBoxStyle,
		TextBoxNoEffects,
		OrderGridButton,
		CarouselButtonStyle,
		TabControlButton,
		PropertyEditorButton,
		LinkButtonStyle,
		FavoriteButton,
		ComboBoxToggleButton,
		SuperDomQuickButton,
		SuperDomButton,
		ThumbnailButton,
		FxBoardClosePositionButtonStyle,
		FilterToggleButton,
		SuperDomLadderLeftButton,
		FxBoardActionButtonStyle,
		SuperDomLadderRightButton,
		BorderlessButtonStyle,
		LinkButtonStyleNoTriggers,
		ChartScrollToLastBarStyle,
		ComboBoxReadonlyToggleButton,
		SpinButtonStyle,
		BasicEntryButton,
		InfoButtonStyle,
		ScrollBarHorizontalPageButton,
		ScrollBarHorizontalThumb,
		ScrollBarVerticalPageButton,
		ScrollBarVerticalThumb,
		ScrollBarButtonStyle,
		ScrollBarButton,
		SimpleSliderThumb,
		ChartSplitter,
		CategoryExpander,
		SessionExpander,
		ComplexPropertyExpander,
		StrategyAnalyzerPropertyExpander,
		AccountsComplexPropertyExpander,
		HistoricalDataExpander,
		GridCheckBox,
		AtmStrategyComboBoxStyle,
		PropertyEditorComboBox,
		LinkControlSeparator,
		AccountFinderComboBox,
		GroupBoxDrawingTools,
		GroupBoxNoScrollViewer,
		QuantitySelectorPresetConfigureContainer,
		QuantitySelectorIncrementConfigureContainer,
		FxTileContainer,
		QuantitySelectorContainer,
		FocusVisual,
		NewsMenuItem,
		InstrumentMenuItem,
		MainMenuSeparator,
		MainMenuIconItem,
		SystemMenuStyle,
		WorkspaceMenuItem,
		DisplayModeMenuStyle,
		DisplayModeMenuItem,
		InstrumentMenuStyle,
		NinjaScriptMenuItem,
		VariableSelectorMenuStyle,
		TabControlMenuItem,
		VariableSelectorMenuItem,
		IntervalsDisplayMenuParent,
		ConnectionMenuItem,
		TabControlMenuStyle,
		InstrumentMenuItemFx,
		InstrumentMenuItemSimple,
		MainMenuItem,
		AlertMenuItem,
		IntervalsDisplayMenuItem,
		NsEditorSymbolSelector,
		NsNavigableDropdownComboBox,
		NSEditorTabControlStyle,
		OrderGridDecreaseStyle,
		ServerStatusCellValuePresenter,
		StrategyNameStyle,
		MessagesEnabledCellStyle,
		AlertsWindowCellValuePresenter,
		QuantityCellEditable,
		InstrumentSearchCellAreaStyle,
		BlurFieldStyle,
		StrategyIsNotSyncStyle,
		AlertsWindowRecordPresenter,
		LabelContentStyle,
		AdminSizeEditorStyle,
		AdminMaxPositionSizeEditable,
		InfragisticsScrollBar,
		MarketAnalyzerBarGraphCellValuePresenter,
		NTGridPrintStyle,
		AlertsWindowForegroundStyle,
		NSEditorErrorGridCellPresenterStyle,
		PlaybackCellValuePresenterStyle,
		MarketAnalyzerRenderCellValuePresenter,
		NSWizardCellValuePresenter,
		OrderGridPriceEditorStyle,
		InstrumentQuickSearchStyle,
		StrategyWaitForFlatForegroundStyle,
		PositionGridCloseStyle,
		MarketAnalyzerCellValuePresenter,
		HdmDataRecordCellAreaStyle,
		StrategyIsSyncStyle,
		OrdersGridGroupedDataRecordPresenter,
		LiquidationStatusCellPresenterStyle,
		PriceCellEditable,
		OrderGridCellValuePresenter,
		NSEditorErrorGridInfoButtonStyle,
		StopPriceCellEditable,
		NegativePositiveStyle,
		HdmCellValuePresenterStyle,
		AccountDataGridCellValuePresenterLite,
		StrategyActiveForegroundStyle,
		OrderGridCancelStyle,
		SummaryGridCvpStyle,
		ForegroundBlackStyle,
		AdminMaxOrderSizeEditable,
		MarketAnalyzerDataRecordCellAreaStyle,
		ForegroundStyle,
		OrderGridCellValuePresenterLite,
		AlertsPriceEditorStyle,
		StrategyAnalyzerGridCvpStyle,
		LeftAlignmentCellPresenter,
		AccountDataGridCellValuePresenter,
		StrategyIsEnabledStyle,
		OrderGridQuantityEditorStyle,
		PriceEditorStyle,
		GroupedDataRecordPresenter,
		OrderGridIncreaseStyle,
		AccountGridCloseStyle,
		ReadOnlyCellStyle,
		SimpleDataRecordPresenter,
		LimitPriceCellEditable,
		OrderStateCellPresenterStyle,
		SimpleNestedDataRecordPresenter,
		ColorPickerComboBox,
		PlaybackRadioButton,
		InstrumentQuickSearchRadioButtonStyle,
		ListBoxSeperatedScrollViewer,
		FolderTreeViewItem,
		FolderToggleButton,
		SimpleTreeViewItemToggleButtonImage,
		SimpleTreeViewItemToggleButton,
		NinjaScriptTreeViewItem,
		BaseForNumericEditor,
		ChartAnchorPriceEditorStyle,
		HdmCryptoVolumeEditorStyle,
		MarketAnalyzerCellEditorStyle,
		HdmVolumeEditorStyle,
		DateTimeShortFormatConverterEditor,
		HdmBaseEditorStyle,
		CalendarDayBaseNT,
		CalendarWeekNumberBaseNT,
		CalendarItemGroupTitleBaseNT,
		XamMaskedEditorBaseStyle,
		CalendarDayOfWeekBaseNT,
		CalendarItemBaseNT,
		XamDateTimeEditorBaseStyle,
		CalendarItemAreaBaseNT,
		OptimizationGraphPointStyle,
		MonteCarloTradeDataPointStyle,
		ToolBarToggleButton,
		ToolTipTextBlockStyle,
		ToolTipTextBlockTitleStyle,
		WindowCaptionStyle,
		CloseButton,
		WindowButtons,
		MainFrameStyle,
		SystemButtonsContainerStyle,
		WindowCaptionStyleModal,
	}

	internal static class ARC_QuickTester_NtStyleHelper
	{
		public static Style ARC_QuickTester_GetStyle(ARC_QuickTester_NtStyle style)
		{
			return Application.Current.Resources[style.ToString()] as Style;
		}
	}
}
