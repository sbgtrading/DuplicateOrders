﻿using System;
using System.Linq;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	/// <summary>
	/// Used to hide this property unless the criteria is met
	/// </summary>
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
	public class ARC_FractalBreakoutAlgo_HideUnlessAttribute : ARC_FractalBreakoutAlgo_ReferentialConditionalAttributeBase
	{
		public ARC_FractalBreakoutAlgo_HideUnlessAttribute(string conditionPropName, ARC_FractalBreakoutAlgo_PropComparisonType compareType, params object[] args) : base(conditionPropName, compareType, args)
		{ }

		public ARC_FractalBreakoutAlgo_HideUnlessAttribute(ARC_FractalBreakoutAlgo_HideUnlessAttribute attr) : base(attr)
		{ }

		public override object Clone()
		{
			return new ARC_FractalBreakoutAlgo_HideUnlessAttribute(this);
		}
	}

	/// <summary>
	/// Used to hide other properties when the value of this one matches the provided value
	/// </summary>
	[AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
	public class ARC_FractalBreakoutAlgo_HideParametersAttribute : Attribute
	{
		/// <summary>
		/// The affected Properties
		/// </summary>
		public string[] Properties { get; set; }

		/// <summary>
		/// The affected Group
		/// </summary>
		public string[] Groups { get; set; }

		public override object TypeId => Properties.GetHashCode() + Groups.GetHashCode();

		public readonly ARC_FractalBreakoutAlgo_StrategyContext[] Contexts;
		public ARC_FractalBreakoutAlgo_HideParametersAttribute(params ARC_FractalBreakoutAlgo_StrategyContext[] contexts)
		{
			Contexts = contexts;
			Properties = Array.Empty<string>();
			Groups = Array.Empty<string>();
		}

		public ARC_FractalBreakoutAlgo_HideParametersAttribute() : this(Array.Empty<ARC_FractalBreakoutAlgo_StrategyContext>())
		{
			Properties = Array.Empty<string>();
			Groups = Array.Empty<string>();
		}
	}
	
	/// <summary>
	/// Used to hide other properties when the value of this one matches the provided value
	/// </summary>
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
	public class ARC_FractalBreakoutAlgo_HideOthersIfAttribute : ARC_FractalBreakoutAlgo_SelfReferencingConditionalAttributeBase
	{
		/// <summary>
		/// The affected Properties
		/// </summary>
		public string[] Properties { get; set; }

		/// <summary>
		/// The affected Group
		/// </summary>
		public string[] Groups { get; set; }

		public ARC_FractalBreakoutAlgo_HideOthersIfAttribute(ARC_FractalBreakoutAlgo_PropComparisonType compareType, params object[] args) : base(compareType, args)
		{
			Properties = Array.Empty<string>();
			Groups = Array.Empty<string>();
		}

		public ARC_FractalBreakoutAlgo_HideOthersIfAttribute(ARC_FractalBreakoutAlgo_HideOthersIfAttribute attr) : base(attr)
		{ }

		public override object Clone()
		{
			return new ARC_FractalBreakoutAlgo_HideOthersIfAttribute(this);
		}

		public override ARC_FractalBreakoutAlgo_IReferencesPropsByName TransformPropNames(Func<string, string> transform)
		{
			var newAttr = (ARC_FractalBreakoutAlgo_HideOthersIfAttribute) Clone();
			newAttr.Properties = Properties
				.Select(transform)
				.ToArray();
			return newAttr;
		}
	}

	/// <summary>
	/// Browsable(false) removed properties from the descriptor collection, meaning they can't be shown conditionally, only hidden conditionally. This preserves them.
	/// </summary>
	[AttributeUsage(AttributeTargets.Property)]
	public class ARC_FractalBreakoutAlgo_HideByDefaultAttribute : Attribute
	{ }

	public enum ARC_FractalBreakoutAlgo_StrategyContext
	{
		Realtime,
		Backtest,
		Optimization
	}
}
