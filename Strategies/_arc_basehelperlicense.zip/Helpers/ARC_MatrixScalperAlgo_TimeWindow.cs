﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	public class ARC_MatrixScalperAlgo_TimeWindow
	{
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Name", Order = 0, GroupName = "Values")]
		public string Name { get; set; } = "";

		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Enabled", Order = 1, GroupName = "Values")]
		public bool Enabled { get; set; }

		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Start Time", Order = 2, GroupName = "Values")]
		public int StartTime { get; set; } = 1;

		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "End Time", Order = 3, GroupName = "Values")]
		public int EndTime { get; set; } = 100;

		private IEnumerable<int[]> SubRegions
		{
			get
			{
				if (StartTime <= EndTime)
				{
					yield return new[] { StartTime, EndTime };
					yield break;
				}

				yield return new[] { 0, EndTime };
				yield return new[] { StartTime, 2400 };
			}
		}

		public override string ToString()
		{
			var name = string.IsNullOrWhiteSpace(Name) ? "" : $"[{Name}] ";
			name += Enabled 
				? string.Join(" - ", new[] { StartTime, EndTime }.Select(t =>
				{
					var str = t.ToString().PadLeft(4, '0');
					return $"{str.Substring(0, 2)}:{str.Substring(2)}";
				}))
				: "Disabled";
			return name;
		}

		public bool Overlaps(ARC_MatrixScalperAlgo_TimeWindow window)
		{
			var windowRegions = new [] { this, window }
				.Select(w => w.SubRegions.ToArray())
				.ToArray();

			// See if any regions boundaries falls within any other regions boundaries
			for (var flip = 0; flip <= 1; flip++)
			{
				foreach (var subRegion1 in windowRegions[flip])
				foreach (var subRegion2 in windowRegions[flip == 0 ? 1 : 0])
				{
					if (subRegion1[0] < subRegion2[1] && subRegion1[1] > subRegion2[0])
						return true;
				}
			}

			return false;
		}
	}
}