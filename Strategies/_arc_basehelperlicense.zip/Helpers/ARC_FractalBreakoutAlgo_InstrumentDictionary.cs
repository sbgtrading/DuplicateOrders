﻿using System.Collections.Generic;
using System;
using NinjaTrader.Cbi;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	public class ARC_FractalBreakoutAlgo_InstrumentDictionary<TValue>
	{
		public ICollection<TValue> Values => values.Values;

		public ICollection<string> Keys => values.Keys;

		private readonly ARC_FractalBreakoutAlgo_DefaultingDictionary<string, TValue> values;
		public ARC_FractalBreakoutAlgo_InstrumentDictionary(Func<string, TValue> defaultValue)
		{
			values = new ARC_FractalBreakoutAlgo_DefaultingDictionary<string, TValue>(defaultValue);
		}
		
		public ARC_FractalBreakoutAlgo_InstrumentDictionary(TValue defaultValue = default)
		{
			values = new ARC_FractalBreakoutAlgo_DefaultingDictionary<string, TValue>(defaultValue);
		}

		public bool ContainsKey(Instrument instrument)
		{
			return values.ContainsKey(instrument.FullName);
		}
		
		public bool ContainsKey(string instrument)
		{
			return values.ContainsKey(instrument);
		}
		
		public bool TryGetValue(Instrument instrument, out TValue value)
		{
			return values.TryGetValue(instrument.FullName, out value);
		}
		
		public bool TryGetValue(string instrument, out TValue value)
		{
			return values.TryGetValue(instrument, out value);
		}

		public TValue this[string instrument] { get => values[instrument]; set => values[instrument] = value; }

		public TValue this[Instrument instrument] { get => values[instrument.FullName]; set => values[instrument.FullName] = value; }
	}
}