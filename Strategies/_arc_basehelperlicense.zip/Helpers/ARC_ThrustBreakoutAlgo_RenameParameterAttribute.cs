﻿using System;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	/// <summary>
	/// Used to relabel a parameter from the parent class, or to conditionally relabel parameters of a class itself
	/// </summary>
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
	public class ARC_ThrustBreakoutAlgo_RenameAttribute : ARC_ThrustBreakoutAlgo_ReferentialConditionalAttributeBase
	{
		public readonly string newName;
		public ARC_ThrustBreakoutAlgo_RenameAttribute(string newName, string conditionPropName, ARC_ThrustBreakoutAlgo_PropComparisonType compareType, params object[] args) : base(conditionPropName, compareType, args)
		{
			this.newName = newName;
		}

		public ARC_ThrustBreakoutAlgo_RenameAttribute(ARC_ThrustBreakoutAlgo_RenameAttribute attr) : base(attr)
		{
			newName = attr.newName;
		}

		public override object Clone()
		{
			return new ARC_ThrustBreakoutAlgo_RenameAttribute(this);
		}
	}

	/// <summary>
	/// Used to relabel a parameter from the parent class, or to conditionally relabel parameters of a class itself
	/// </summary>
	[AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
	public class ARC_ThrustBreakoutAlgo_RenameParameterAttribute : Attribute
	{
		public readonly string property;
		public readonly string newName;
		public ARC_ThrustBreakoutAlgo_RenameParameterAttribute(string property, string newName)
		{
			this.property = property;
			this.newName = newName;
		}
	}
}