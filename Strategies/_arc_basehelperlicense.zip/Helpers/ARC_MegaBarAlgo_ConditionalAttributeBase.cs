﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	public abstract class ARC_MegaBarAlgo_ConditionalAttributeBase : Attribute, ARC_MegaBarAlgo_IReferencesPropsByName
	{
		public override object TypeId => args.GetHashCode() + compareType.GetHashCode();
		private bool IsSingleNumCompare => compareType == ARC_MegaBarAlgo_PropComparisonType.GT || compareType == ARC_MegaBarAlgo_PropComparisonType.GTE || compareType == ARC_MegaBarAlgo_PropComparisonType.LT || compareType == ARC_MegaBarAlgo_PropComparisonType.LTE;
		private bool IsDualNumCompare => compareType == ARC_MegaBarAlgo_PropComparisonType.Between || compareType == ARC_MegaBarAlgo_PropComparisonType.NotBetween;
		private readonly ARC_MegaBarAlgo_PropComparisonType compareType;
		private readonly object[] args;
		protected ARC_MegaBarAlgo_ConditionalAttributeBase(ARC_MegaBarAlgo_PropComparisonType compareType, params object[] args)
		{
			if (args.Length == 0)
				throw new ArgumentException("Attribute requires at least one value for any comparison type!");
				
			this.args = args;
			this.compareType = compareType;

			if ((IsSingleNumCompare || IsDualNumCompare) && args.Any(a => !(a is IComparable)))
				throw new ArgumentException("In numeric comparison, args must all be comparable");
			if (IsSingleNumCompare && args.Length != 1)
				throw new ArgumentException("Comparison requires one input!");
			if (IsDualNumCompare && args.Length != 2)
				throw new ArgumentException("Comparison requires two inputs!");
		}

		protected ARC_MegaBarAlgo_ConditionalAttributeBase(ARC_MegaBarAlgo_ConditionalAttributeBase attr)
		{
			args = attr.args;
			compareType = attr.compareType;
		}

		public bool MatchesCriteria(object value)
		{
			switch (compareType)
			{
			case ARC_MegaBarAlgo_PropComparisonType.EQ:
				return Equals(value, args[0]);
			case ARC_MegaBarAlgo_PropComparisonType.NEQ:
				return !Equals(value, args[0]);
			case ARC_MegaBarAlgo_PropComparisonType.IsOneOf:
				return args.Any(a => Equals(value, a));
			case ARC_MegaBarAlgo_PropComparisonType.IsNotOneOf:
				return args.All(a => !Equals(value, a));
			}

			if (!(value is IComparable cVal))
				throw new ArgumentException("Argument must be comparable for numeric comparison to work!");

			var comparisons = args
				.OfType<IComparable>()
				.Select(cVal.CompareTo)
				.ToArray();
			return compareType switch
			{
				ARC_MegaBarAlgo_PropComparisonType.Between => comparisons[0] > 0 && comparisons[1] < 0,
				ARC_MegaBarAlgo_PropComparisonType.NotBetween => comparisons[0] < 0 || comparisons[1] > 0,
				ARC_MegaBarAlgo_PropComparisonType.LT => comparisons[0] < 0,
				ARC_MegaBarAlgo_PropComparisonType.GT => comparisons[0] > 0,
				ARC_MegaBarAlgo_PropComparisonType.LTE => comparisons[0] <= 0,
				ARC_MegaBarAlgo_PropComparisonType.GTE => comparisons[0] >= 0,
				_ => throw new ArgumentOutOfRangeException()
			};
		}

		public abstract object Clone();

		public abstract ARC_MegaBarAlgo_IReferencesPropsByName TransformPropNames(Func<string, string> transform);
	}

	/// <summary>
	/// Base class for conditional attributes that reference other parameters
	/// </summary>
	public abstract class ARC_MegaBarAlgo_ReferentialConditionalAttributeBase : ARC_MegaBarAlgo_ConditionalAttributeBase
	{
		public override object TypeId => base.TypeId.GetHashCode() + ConditionPropName.GetHashCode();
		public string ConditionPropName { get; private set; }

		/// <param name="conditionPropName">Prefix the name with "." to compare to reference a property of the parent class from within a flattened child class.</param>
		/// <param name="compareType"></param>
		/// <param name="args"></param>
		protected ARC_MegaBarAlgo_ReferentialConditionalAttributeBase(string conditionPropName, ARC_MegaBarAlgo_PropComparisonType compareType, params object[] args) : base(compareType, args)
		{
			ConditionPropName = conditionPropName;
		}
		
		protected ARC_MegaBarAlgo_ReferentialConditionalAttributeBase(ARC_MegaBarAlgo_ReferentialConditionalAttributeBase attr) : base(attr)
		{
			ConditionPropName = attr.ConditionPropName;
		}

		public override ARC_MegaBarAlgo_IReferencesPropsByName TransformPropNames(Func<string, string> transform)
		{
			var newAttr = (ARC_MegaBarAlgo_ReferentialConditionalAttributeBase) Clone();
			newAttr.ConditionPropName = transform(ConditionPropName);
			return newAttr;
		}
	}
	
	/// <summary>
	/// Base class for conditional attributes that reference other parameters
	/// </summary>
	public abstract class ARC_MegaBarAlgo_SelfReferencingConditionalAttributeBase : ARC_MegaBarAlgo_ConditionalAttributeBase
	{
		protected ARC_MegaBarAlgo_SelfReferencingConditionalAttributeBase(ARC_MegaBarAlgo_PropComparisonType compareType, params object[] args) : base(compareType, args)
		{ }

		protected ARC_MegaBarAlgo_SelfReferencingConditionalAttributeBase(ARC_MegaBarAlgo_SelfReferencingConditionalAttributeBase attr) : base(attr)
		{ }
	}

	public interface ARC_MegaBarAlgo_IReferencesPropsByName : ICloneable
	{
		/// <summary>
		/// Return a copy of the attribute with each name that references a property transformed with the provided function
		/// </summary>
		/// <param name="transform"></param>
		/// <returns></returns>
		ARC_MegaBarAlgo_IReferencesPropsByName TransformPropNames(Func<string, string> transform);
	}

	[SuppressMessage("ReSharper", "InconsistentNaming")]
	public enum ARC_MegaBarAlgo_PropComparisonType
	{
		/// <summary>
		/// Two arguments, low and high of number type
		/// </summary>
		Between,
		/// <summary>
		/// <inheritdoc cref="Between"/>
		/// </summary>
		NotBetween,
		IsOneOf,
		IsNotOneOf,
		EQ,
		NEQ,
		LT,
		GT,
		LTE,
		GTE
	}
}