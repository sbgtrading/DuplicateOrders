﻿using System.CodeDom.Compiler;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Effects;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	[GeneratedCode("UiResourceGenerator", "1")]
	[SuppressMessage("CodeQuality", "IDE0079:Remove unnecessary suppression", Justification = "<Removes Resharper Issues>")]
	[SuppressMessage("ReSharper", "InconsistentNaming")]
	[SuppressMessage("ReSharper", "IdentifierTypo")]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	internal enum ARC_QuickTester_BrushResourceKeys
	{
		AtmHeaderBackground,
		AtmHeaderTextBackground,
		InstrumentTextForeground,
		InstrumentTextBackground,
		BasicEntry_UptickBackground,
		BasicEntry_UptickForeground,
		BasicEntry_DowntickBackground,
		BasicEntry_DowntickForeground,
		BasicEntry_TextBoxBackground,
		BasicEntry_PositionQtyLongBackground,
		BasicEntry_PositionQtyShortBackground,
		BasicEntry_PnLBackground,
		BasicEntry_ButtonBackground,
		BasicEntry_ActionButtonsBackground,
		BasicEntry_BuyButtonsBackground,
		BasicEntry_SellButtonsBackground,
		ExcessIntradayMarginHighlight,
		ExcessInitialMarginHighlight,
		ExcessPositionMarginHighlight,
		LargePositionHighlight,
		InstrumentSelectorPopupBackground,
		InstrumentSelectorPopupForeground,
		LinkPressedBrush,
		ButtonBackgroundBrush,
		ButtonBackgroundPressedBrush,
		ButtonBorderBrush,
		ButtonDisabledBorder,
		ButtonDisabledForeground,
		ButtonDisabledBackground,
		CheckBoxBackgroundBrush,
		CheckBoxDisabledBorder,
		CheckBoxDisabledForeground,
		CheckBoxDisabledBackground,
		ComboBoxBackgroundBrush,
		ComboBoxDropDownBackBrush,
		ComboBoxItemForeground,
		ComboBoxItemHoverBorder,
		ComboBoxItemHoverBackground,
		ComboBoxDisabledBorder,
		ComboBoxDisabledForeground,
		ComboBoxDisabledBackground,
		LinkAllGreenBackground,
		LinkAllOrangeBackground,
		LinkAllRedBackground,
		ListBoxBorderBrush,
		ListBoxBackgroundBrush,
		ListBoxItemForeground,
		ListBoxItemHoverBorder,
		ListBoxItemHoverBackground,
		ListBoxDisabledBorder,
		ListBoxDisabledForeground,
		ListBoxDisabledBackground,
		MenuBorderBrush,
		MenuRibbonBrush,
		MenuSeparator,
		SubMenuBackground,
		MenuHilightBorderBrush,
		MenuHilightBackgroundBrush,
		MenuItemDisabledForeground,
		SystemMenuBackground,
		MenuShadowBottom,
		MenuShadowTop,
		RadioButtonBackground,
		RadioButtonCheckMark,
		RadioButtonDisabledBorder,
		RadioButtonDisabledForeground,
		RadioButtonDisabledBackground,
		ScrollBarTrackBackground,
		ScrollBarTrackHover,
		ScrollBarTrackPressed,
		ScrollBarDisabledBackground,
		ScrollButtonsLeftBorder,
		ScrollBarThumbBorder,
		ScrollBarThumbBorderHover,
		ScrollBarThumbBorderPressed,
		ScrollBarVerticalForeground,
		ScrollBarHorizontalForeground,
		ScrollBarVerticalForeHover,
		ScrollBarVerticalForePressed,
		ScrollBarHorizontalForeHover,
		ScrollBarHorizontalForePressed,
		ScrollBarForeAdorner,
		ScrollBarForeAdornerHover,
		ScrollBarForeAdornerPressed,
		ScrollBarForeAdornerDisabled,
		ScrollBarCaratNormal,
		ScrollBarCaratHover,
		ScrollBarCaratPressed,
		ScrollBarCaratDisabled,
		ScrollBarArrowNormal,
		ScrollBarArrowHover,
		ScrollBarArrowPressed,
		ScrollBarArrowDisabled,
		ScrollBarArrowBackgroundNormal,
		ScrollBarArrowBackgroundHover,
		ScrollBarArrowBackgroundPressed,
		ScrollBarArrowBackgroundDisabled,
		SliderBorderBrush,
		SliderTicksBrush,
		SliderBackgroundBrush,
		SliderForegroundBrush,
		TabItemPrintBackground,
		TabControlBorderBrush,
		TabBackground,
		TabItemNormalForeground,
		TabItemSelectedForeground,
		TabItemHotForeground,
		TabItemButton,
		TabActiveBorder,
		TabNormalBorder,
		TabItemNormalBackground,
		TabItemButtonPressed,
		TabHeaderShadowBrush,
		TextBoxDisabledBackground,
		TextBoxDisabledForeground,
		TextBoxDisabledBorder,
		TextBoxErrorBorder,
		TextBoxErrorBackground,
		TreeViewDisabledForeground,
		TreeItemSelectedBackground,
		TreeViewDisabledSelectedForeground,
		NinjaScriptOutputSearchHighlight,
		MenuIconDisabledForeground,
		brushButtonSpinnersBackground,
		XamNumericEditorBackground,
		XamNumericEditorBackgroundFocused,
		BackgroundActiveTab,
		BackgroundCaptionBar,
		FlashingCaptionBar,
		BackgroundCaptionBarInactive,
		BackgroundMainWindow,
		BackgroundModalWindow,
		TabBlendingColor,
		BackgroundModalOverlay,
		BackgroundNormalTab,
		BackgroundTableSolidBottom,
		FavoritesBorderBrush,
		BackgroundTableHeaderVertical,
		BackgroundTableHeader,
		BackgroundTextHighlight,
		BackgroundTextInput,
		BackgroundTitleBlock,
		BorderMainWindowBrush,
		BorderNormalTabBrush,
		BorderTextHighlightBrush,
		BorderThinBrush,
		ConnectionBorderBrush,
		DisconnectedBrush,
		ConnectedBrush,
		ConnectingBrush,
		ConnectionLostPriceBrush,
		ConnectionLostOrderBrush,
		WorkspaceActiveFill,
		WorkspaceInactiveFill,
		WorkspaceStroke,
		ColumnBaseAltBarColor,
		ColumnBaseBarColor,
		TextHighlightBrush,
		WindowButtonsInactive,
		SystemButtonsForeground,
		SystemButtonsBackgroundNormal,
		SystemButtonsBackgroundPressed,
		SystemCloseBackgroundNormal,
		SystemCloseBackgroundPressed,
		SystemButtonsBorder,
		SystemCloseBorder,
		FocusedBrush,
		brushStrategyWaitForFlat,
		brushStrategyActive,
		brushStrategyNotSynced,
		brushOrderWorking,
		brushOrderPartFilled,
		brushOrderPendingSubmit,
		brushOrderPendingChange,
		brushOrderAccepted,
		brushOrderPendingCancel,
		brushOrderInitialized,
		brushOrderTriggerPending,
		PropertiesSlimText,
		PropertiesFatText,
		PropertiesDisabledText,
		PropertyGridSeparatorLineFill,
		GridHeaderHighlight,
		GridRowBackground,
		GridRowForeground,
		GridRowHighlight,
		GridEntireBackground,
		GridRowBackgroundPrinting,
		GridLabelBackgroundPrinting,
		ToolTipDividerBrush,
		BackgroundModalOverlayToolTip,
		BackgroundModalOverlayToolTipStrokeBrush,
		FlatBackground,
		LongBackground,
		ShortBackground,
		PositionTextBlockBrush,
		PositionTextBlockProfitBrush,
		PositionTextBlockLossBrush,
		PnLBackground,
		PositionLongQuantityBrush,
		PositionShortQuantityBrush,
		BrowserChartBackground,
		FontToolTipBrush,
		FontActionBrush,
		FontButtonBrush,
		FontControlBrush,
		FontControlBrushReverse,
		FontHeaderLevel1Brush,
		FontHeaderLevel3Brush,
		FontLabelBrush,
		FontListBrush,
		FontMenuBrush,
		FontMenuTopBrush,
		FontMenuHighlightedBrush,
		FontModalTitleBrush,
		FontPipBrush,
		FontTableBrush,
		FontTitleBlockBrush,
		FontActiveTabBrush,
		FontHeaderLevel2Brush,
		FontHeaderLevel4Brush,
		FontMainNavigationBrush,
		FontModalBrush,
		FontModalLinkBrush,
		FontNormalTabBrush,
		FontNormalTabHoverBrush,
		FontToolTipTitleBrush,
		DepthChart_AxisBackground,
		DepthChart_TextForeground,
		SelectedApAreaBrush,
		NegativeApAreaBrush,
		PositiveApAreaBrush,
		NegativeApAreaStroke,
		PositiveApAreaStroke,
		NegativeApMarkerBrush,
		PositiveApMarkerBrush,
		ApMarkerBorderBrush,
		Alt1ApGridBrush,
		Alt2ApGridBrush,
		ApOptimizationScatterFill,
		OptimizationGraphScatterBrush,
		ParetoDataPointBrush,
		ParetoPinnedDataPointBrush,
		ParetoDataPointHoverBrush,
		ParetoSelectedDataPointBrush,
		StrategyAnalyzerNegativeValueBrush,
		OptimizationGraphGridLinesColor,
		NinjaScriptEditorBackground,
		NinjaScriptEditorCommentForeground,
		NinjaScriptEditorCompilerErrorForeground,
		NinjaScriptEditorIdentifierForeground,
		NinjaScriptEditorIndentationLineForeground,
		NinjaScriptEditorKeywordForeground,
		NinjaScriptEditorLineNumbersBackground,
		NinjaScriptEditorLineNumbersForeground,
		NinjaScriptEditorNumberForeground,
		NinjaScriptEditorStringForeground,
		NinjaScriptEditorSyntaxErrorForeground,
		NinjaScriptEditorPlainTextForeground,
		NinjaScriptEditorErrorGridBackgroundSelectedTab,
		NinjaScriptEditorErrorGridBackgroundOtherTab,
		NinjaScriptEditorCaretBrush,
		NinjaScriptEditorCollapsibleRegionBackground,
		NinjaScriptEditorWarningDotBrush,
		NinjaScriptEditorErrorDotBrush,
		FontSelectionBrush,
		FxBoardPnLProfitBrush,
		FxBoardPnLLossBrush,
		FxBoardPnLZeroBrush,
		FxBoardPositionLongBrush,
		FxBoardPositionShortBrush,
		FxBoardPositionFlatBrush,
		FxBoardPositionBorderBrush,
		FxBoardPositionForegroundBrush,
		FxBoardPositionBarBackgroundBrush,
		FxBoardClosePositionForegroundBrush,
		FxBoardCloseButtonBorderBrush,
		FxBoardBidAskBarBackgroundBrush,
		FxBoardBidAskBarForegroundBrush,
		FxBoardInstrumentSelectorForeground,
		FxBoardInstrumentSelectorBorder,
		FxBoardInstrumentSelectorBackground,
		FxBoardInstrumentSelectorForegroundSelected,
		FxBoardInstrumentSelectorBorderSelected,
		FxBoardInstrumentSelectorBackgroundSelected,
		FxBoardActionButtonFillBrush,
		FxBoardCloseButtonFillBrush,
		FxBoardCloseButtonFillBrushPressed,
		FxBoardSpreadBorderBrush,
		FxBoardSpreadBackgroundBrush,
		FxBoardSpreadForegroundBrush,
		HdmAddRowBrush,
		HdmDeleteRowBrush,
		HdmEditRowBrush,
		OcoSignifierBackground,
		SoSignifierBackground,
		TradePerformanceFiltersBackground,
		TradePerformanceFiltersBackground2,
		TradePerformanceFiltersBackground3,
		CryptocurrencyTrailingZeroForeground,
		ChartTrader_ButtonBackground,
		ChartTrader_ActionButtonsBackground,
		ChartTrader_BuyButtonsBackground,
		ChartTrader_SellButtonsBackground,
		ChartControl_ChartBackground,
		ChartControl_ChartText,
		ChartControl_InactivePriceMarkersBackground,
		ChartControl_CrosshairLabelBackground,
		ChartControl_DataBoxPanelLabelBackground,
		ChartControl_DataBoxItemLabelBackground,
		ChartControl_DataBoxBackground,
		ChartControl_DataBoxForeground,
		ChartControl_DropHighlight,
		ChartControl_UpBrush,
		ChartControl_DownBrush,
		ChartControl_VolumetricText,
		LogGrid_InformationBackground,
		LogGrid_WarningBackground,
		LogGrid_ErrorBackground,
		LogGrid_AlertBackground,
		DataSeries_PriceMarkerBrush,
		DataSeries_ShortExecutionBrush,
		DataSeries_LongExecutionBrush,
		FxBoard_UptickBackground,
		FxBoard_UptickForeground,
		FxBoard_DowntickBackground,
		FxBoard_DowntickForeground,
		FxBoard_ButtonBackground,
		FxBoard_ButtonForeground,
		FxPro_TextBoxBackground,
		FxPro_PositionQtyLongBackground,
		FxPro_PositionQtyShortBackground,
		FxPro_PnLBackground,
		FxPro_UptickBackground,
		FxPro_UptickForeground,
		FxPro_DowntickBackground,
		FxPro_DowntickForeground,
		FxPro_ButtonForeground,
		FxPro_ButtonBackground,
		FxPro_ActionButtonsBackground,
		FxPro_BuyButtonsBackground,
		FxPro_SellButtonsBackground,
		Level2_L1Background,
		Level2_L2Background,
		Level2_L3Background,
		Level2_L4Background,
		Level2_L5Background,
		Level2_L6Background,
		Level2_L7Background,
		Level2_L8Background,
		Level2_L9Background,
		Level2_L10Background,
		Level2_MarketMakersBackground,
		Level2_MarketMakersForeground,
		Level2_TextForeground,
		Level2_UptickForeground,
		Level2_UptickBackground,
		Level2_DowntickForeground,
		Level2_DowntickBackground,
		ConditionBackground,
		ConditionForeground,
		MAGridForeground,
		MAGridLines,
		LabelRowBackground,
		LabelRowForeground,
		RowChangeHighlightBackground,
		RowChangeHighlightForeground,
		MAGridTotalRowBackground,
		AlertBackground,
		AlertForeground,
		BackgroundWizard,
		BorderWizardInner,
		BorderWizardOuter,
		OptionChain_StrikeBackground,
		OptionChain_StrikeForeground,
		OptionChain_HoverBrush,
		OptionChain_SelectionBrush,
		OptionChain_ItmBackground,
		OptionChain_ItmForeground,
		OptionChain_OtmBackground,
		OptionChain_OtmForeground,
		OptionChain_ItmLineBrush,
		OptionChain_PriceMarkerBrush,
		OptionChain_MinVolumeBrush,
		OptionChain_MaxVolumeBrush,
		OrderTicket_ButtonBackground,
		OrderTicket_BuyButtonsBackground,
		OrderTicket_SellButtonsBackground,
		SuperDom_ButtonBackground,
		SuperDom_ActionButtonsBackground,
		SuperDom_BuyButtonsBackground,
		SuperDom_SellButtonsBackground,
		ModifierFlagForeground,
		brushAskPriceForeground,
		brushBidPriceForeground,
		brushBuyColumnBackground,
		brushBuyColumnForeground,
		brushDailyHighPriceBackground,
		brushDailyLowPriceBackground,
		brushEntryPriceBackground,
		brushHighlightBackground,
		brushLastTradeBackground,
		brushPriceColumnBackground,
		brushPriceColumnForeground,
		brushSellColumnBackground,
		brushSellColumnForeground,
		immutableBrushAskPriceForeground,
		immutableBrushBidPriceForeground,
		immutableBrushBuyColumnBackground,
		immutableBrushBuyColumnForeground,
		immutableBrushDailyHighPriceBackground,
		immutableBrushDailyLowPriceBackground,
		immutableBrushEntryPriceBackground,
		immutableBrushHighlightBackground,
		immutableBrushLastTradeBackground,
		immutableBrushPriceColumnBackground,
		immutableBrushPriceColumnForeground,
		immutableBrushSellColumnBackground,
		immutableBrushSellColumnForeground,
		TriggerPendingOrderStateFillBrush,
		PendingOrderStateFillBrush,
		TimeAndSales_AboveAskBackground,
		TimeAndSales_AboveAskForeground,
		TimeAndSales_AskForeground,
		TimeAndSales_AskBackground,
		TimeAndSales_AtAskBackground,
		TimeAndSales_AtAskForeground,
		TimeAndSales_AtBidBackground,
		TimeAndSales_AtBidForeground,
		TimeAndSales_BelowBidBackground,
		TimeAndSales_BelowBidForeground,
		TimeAndSales_BetweenBackground,
		TimeAndSales_BetweenForeground,
		TimeAndSales_BidForeground,
		TimeAndSales_BidBackground,
		TimeAndSales_BlockAlertForeground,
		TimeAndSales_DailyHighForeground,
		TimeAndSales_DailyLowForeground,
		TimeAndSales_MainBackground,
	}

	[GeneratedCode("UiResourceGenerator", "1")]
	[SuppressMessage("CodeQuality", "IDE0079:Remove unnecessary suppression", Justification = "<Removes Resharper Issues>")]
	[SuppressMessage("ReSharper", "InconsistentNaming")]
	[SuppressMessage("ReSharper", "IdentifierTypo")]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	internal enum ARC_QuickTester_ColorResourceKeys
	{
		ButtonTextColorNormal,
		WindowBottomGradientStopColor,
		ColorTextNormal,
		ColorTextHighlight,
		ColorDisabledBackground,
		ColorDisabledForeground,
		ColorItemHoverBorder,
		ColorTabItemShadow,
		ColorDisabledBorder,
		ButtonBackgroundStop1,
		ButtonBackgroundStop2,
		NegativeApAreaColor,
		PositiveApAreaColor,
		NegativeApMarkerColor,
		PositiveApMarkerColor,
		OptimizationGraphGradientColor1,
		OptimizationGraphGradientColor2,
		OptimizationGraphGradientColor3,
		OptimizationGraphGradientColor4,
		OptimizationGraphGradientColor5,
		OptimizationGraphGradientColor6,
		colorOrderStateTriggerPending,
		colorOrderTypeLimit,
		colorOrderTypeMarketIfTouched,
		colorOrderTypeStopLimit,
		colorOrderTypeStopMarket,
		colorProfitTarget,
		colorStopLoss,
		colorOrderDropShadow,
		brushHoldOutline,
	}

	[GeneratedCode("UiResourceGenerator", "1")]
	[SuppressMessage("CodeQuality", "IDE0079:Remove unnecessary suppression", Justification = "<Removes Resharper Issues>")]
	[SuppressMessage("ReSharper", "InconsistentNaming")]
	[SuppressMessage("ReSharper", "IdentifierTypo")]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	internal enum ARC_QuickTester_GradientStopCollectionResourceKeys
	{
		ItemHoverStops,
		SystemMinMaxStops,
		SystemCloseStops,
		SysMenuBackStops,
		BaseBorderStops,
		InnerBorderStops,
		ButtonBackgroundStops,
		ButtonBorderStops,
		CheckBoxBackgroundStops,
		RadioButtonStops,
		ShadowTopStops,
		ShadowBottomStops,
		ConnectedStops,
		ConnectingStops,
		ConnectionLostPriceStops,
		ConnectionLostOrderStops,
		DisconnectedStops,
		ScrollThumbBackStops,
		ScrollThumbBackStopsHover,
		ScrollThumbBackStopsPressed,
		ModifierFlagBackgroundStops,
	}

	[GeneratedCode("UiResourceGenerator", "1")]
	[SuppressMessage("CodeQuality", "IDE0079:Remove unnecessary suppression", Justification = "<Removes Resharper Issues>")]
	[SuppressMessage("ReSharper", "InconsistentNaming")]
	[SuppressMessage("ReSharper", "IdentifierTypo")]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	internal enum ARC_QuickTester_DoubleResourceKeys
	{
		SizeLinkControlItem,
		SizeLinkControlMenu,
		MenuRibbonWidth,
		NTScrollWidth,
		BorderMainWindowThickness,
		BorderNormalTabThickness,
		BorderTextHighlightThickness,
		BorderThinThickness,
		ToolTipDividerHeight,
		ToolTipMaxWidth,
		BackgroundModalOverlayToolTipStrokeThickness,
		NTFontSizeBiggest,
		FontToolTipHeight,
		FontActionMargin,
		FontActionHeight,
		FontButtonHeight,
		FontControlHeight,
		FontGetConnectedSmallHeight,
		FontGetConnectedLargeHeight,
		FontDailyChangedHeight,
		FontHeaderLevel1Height,
		FontHeaderLevel3Height,
		FontHeaderLevel3Margin,
		FontLabelHeight,
		FontListHeight,
		FontListMargin,
		FontMenuHeight,
		FontMenuTopHeight,
		FontModalTitleHeight,
		FontModalTitleMargin,
		FontTableHeight,
		FontTableMargin,
		FontTitleBlockHeight,
		FontActiveTabHeight,
		FontHeaderLevel2Height,
		FontHeaderLevel4Height,
		FontHeaderLevel4Margin,
		FontMainNavigationHeight,
		FontModalHeight,
		FontModalMargin,
		FontModalLinkHeight,
		FontModalLinkMargin,
		FontNormalTabHeight,
		FontNormalTabHoverHeight,
		FontToolTipTitleHeight,
		HeightControl,
		HeightSmallControl,
		HeightTableHeader,
		IconModalButton,
		IconModalSilhouette,
		TreeViewFontIconSize,
		MarginActiveTab,
		MarginBase,
		MarginBaseNegative,
		MarginButtonLeft,
		MarginButtonTop,
		MarginControl,
		MarginConnectionIcon,
		MarginFontList,
		MarginMainNavigation,
		MarginMainNavigationIcon,
		MarginNormalTab,
		MarginWindowControl,
		PaddingButton,
		PaddingColumn,
		PaddingColumn2,
		PaddingGroup,
		PaddingTab,
		PaddingTableHeader,
		PaddingTextInputVertical,
		NTGridCellPadding,
		HotKeyEditorMargin,
		SizeWindowControl,
		TabControlCloseButtonContentSize,
		TabControlCloseButtonSize,
		TabControlCloseButtonPadding,
		TabControlItemFontSizeSelected,
		TabControlItemFontSizeUnselected,
		TabControlItemMarginBase,
		TabControlItemMinWidth,
		TabControlSelectedItemHeightIncrease,
		TabControlConnectionStatusSize,
		TabControlConnectionStatusMargin,
		MarketWatchTileWidthExtraSmall,
		MarketWatchTileHeightExtraSmall,
		MarketWatchTileFontSizeExtraSmall,
		MarketWatchTileWidthSmall,
		MarketWatchTileHeightSmall,
		MarketWatchTileFontSizeSmall,
		MarketWatchTileWidthMedium,
		MarketWatchTileHeightMedium,
		MarketWatchTileFontSizeMedium,
		MarketWatchTileWidthLarge,
		MarketWatchTileHeightLarge,
		MarketWatchTileFontSizeLarge,
		MarketWatchTileWidthExtraLarge,
		MarketWatchTileHeightExtraLarge,
		MarketWatchTileFontSizeExtraLarge,
		TileWidthLarge,
		TileHeightLarge,
		SubPipSizeLarge,
		SubPipMinWidthLarge,
		TileWidthMedium,
		TileHeightMedium,
		SubPipSizeMedium,
		SubPipMinWidthMedium,
		TileWidthSmall,
		TileHeightSmall,
		SubPipSizeSmall,
		SubPipMinWidthSmall,
		holdDropShadowRadius,
		holdDropShadowOpacity,
	}

	[GeneratedCode("UiResourceGenerator", "1")]
	[SuppressMessage("CodeQuality", "IDE0079:Remove unnecessary suppression", Justification = "<Removes Resharper Issues>")]
	[SuppressMessage("ReSharper", "InconsistentNaming")]
	[SuppressMessage("ReSharper", "IdentifierTypo")]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	internal enum ARC_QuickTester_HorizontalAlignmentResourceKeys
	{
		AlignmentButtonText,
		AlignmentGrid,
	}

	[GeneratedCode("UiResourceGenerator", "1")]
	[SuppressMessage("CodeQuality", "IDE0079:Remove unnecessary suppression", Justification = "<Removes Resharper Issues>")]
	[SuppressMessage("ReSharper", "InconsistentNaming")]
	[SuppressMessage("ReSharper", "IdentifierTypo")]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	internal enum ARC_QuickTester_VerticalAlignmentResourceKeys
	{
		AlignmentLabel,
	}

	[GeneratedCode("UiResourceGenerator", "1")]
	[SuppressMessage("CodeQuality", "IDE0079:Remove unnecessary suppression", Justification = "<Removes Resharper Issues>")]
	[SuppressMessage("ReSharper", "InconsistentNaming")]
	[SuppressMessage("ReSharper", "IdentifierTypo")]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	internal enum ARC_QuickTester_TextAlignmentResourceKeys
	{
		AlignmentLabelText,
	}

	[GeneratedCode("UiResourceGenerator", "1")]
	[SuppressMessage("CodeQuality", "IDE0079:Remove unnecessary suppression", Justification = "<Removes Resharper Issues>")]
	[SuppressMessage("ReSharper", "InconsistentNaming")]
	[SuppressMessage("ReSharper", "IdentifierTypo")]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	internal enum ARC_QuickTester_DropShadowEffectResourceKeys
	{
		ToolTipDropShadowEffect,
		HoverDropShadow,
		TextDropShadow,
		QuantitySelectorDropShadow,
		DropShadowModalWindow,
		DropShadowTitleBlock,
	}

	[GeneratedCode("UiResourceGenerator", "1")]
	[SuppressMessage("CodeQuality", "IDE0079:Remove unnecessary suppression", Justification = "<Removes Resharper Issues>")]
	[SuppressMessage("ReSharper", "InconsistentNaming")]
	[SuppressMessage("ReSharper", "IdentifierTypo")]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	internal enum ARC_QuickTester_FontFamilyResourceKeys
	{
		FontToolTipFamily,
		FontActionFamily,
		FontButtonFamily,
		FontControlFamily,
		FontHeaderLevel1Family,
		FontHeaderLevel3Family,
		FontLabelFamily,
		FontListFamily,
		FontMenuFamily,
		FontMenuTopFamily,
		FontModalTitleFamily,
		FontPipFamily,
		FontTableFamily,
		FontTitleBlockFamily,
		FontActiveTabFamily,
		FontHeaderLevel2Family,
		FontHeaderLevel4Family,
		FontMainNavigationFamily,
		FontModalFamily,
		FontModalLinkFamily,
		FontNormalTabFamily,
		FontNormalTabHoverFamily,
		FontToolTipTitleFamily,
	}

	[GeneratedCode("UiResourceGenerator", "1")]
	[SuppressMessage("CodeQuality", "IDE0079:Remove unnecessary suppression", Justification = "<Removes Resharper Issues>")]
	[SuppressMessage("ReSharper", "InconsistentNaming")]
	[SuppressMessage("ReSharper", "IdentifierTypo")]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	internal enum ARC_QuickTester_FontStyleResourceKeys
	{
		FontToolTipStyle,
		FontActionStyle,
		FontButtonStyle,
		FontControlStyle,
		FontHeaderLevel1Style,
		FontHeaderLevel3Style,
		FontLabelStyle,
		FontListStyle,
		FontMenuStyle,
		FontMenuTopStyle,
		FontModalTitleStyle,
		FontPipStyle,
		FontTableStyle,
		FontTitleBlockStyle,
		FontActiveTabStyle,
		FontHeaderLevel2Style,
		FontHeaderLevel4Style,
		FontMainNavigationStyle,
		FontModalStyle,
		FontModalLinkStyle,
		FontNormalTabStyle,
		FontNormalTabHoverStyle,
		FontToolTipTitleStyle,
	}

	[GeneratedCode("UiResourceGenerator", "1")]
	[SuppressMessage("CodeQuality", "IDE0079:Remove unnecessary suppression", Justification = "<Removes Resharper Issues>")]
	[SuppressMessage("ReSharper", "InconsistentNaming")]
	[SuppressMessage("ReSharper", "IdentifierTypo")]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	internal enum ARC_QuickTester_FontWeightResourceKeys
	{
		FontToolTipWeight,
		FontActionWeight,
		FontButtonWeight,
		FontControlWeight,
		FontHeaderLevel1Weight,
		FontHeaderLevel3Weight,
		FontLabelWeight,
		FontListWeight,
		FontMenuWeight,
		FontMenuTopWeight,
		FontModalTitleWeight,
		FontPipWeight,
		FontTableWeight,
		FontTitleBlockWeight,
		FontActiveTabWeight,
		FontHeaderLevel2Weight,
		FontHeaderLevel4Weight,
		FontMainNavigationWeight,
		FontModalWeight,
		FontModalLinkWeight,
		FontNormalTabWeight,
		FontNormalTabHoverWeight,
		FontToolTipTitleWeight,
	}

	[GeneratedCode("UiResourceGenerator", "1")]
	[SuppressMessage("CodeQuality", "IDE0079:Remove unnecessary suppression", Justification = "<Removes Resharper Issues>")]
	[SuppressMessage("ReSharper", "InconsistentNaming")]
	[SuppressMessage("ReSharper", "IdentifierTypo")]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	internal enum ARC_QuickTester_PenResourceKeys
	{
		ApGridLinesPen,
		ApAxisLinesPen,
		ChartControl_AxisPen,
		ChartControl_CrosshairPen,
		ChartControl_GridLineHPen,
		ChartControl_GridLineVPen,
		ChartControl_PanelSplitterPen,
		ChartControl_Stroke,
		ChartControl_Stroke2,
		DataSeries_PositionPenLoser,
		DataSeries_PositionPenWinner,
		DataSeries_TradingHoursPen,
		OptionChain_StrikeLadderPen,
		OptionChain_ItmLinePen,
	}

	[GeneratedCode("UiResourceGenerator", "1")]
	[SuppressMessage("ReSharper", "InconsistentNaming")]
	[SuppressMessage("ReSharper", "IdentifierTypo")]
	[SuppressMessage("ReSharper", "UnusedMember.Global")]
	internal static class ARC_QuickTester_SkinResourceHelper
	{
		private static readonly Dictionary<ARC_QuickTester_BrushResourceKeys, Brush> BrushResources = new Dictionary<ARC_QuickTester_BrushResourceKeys, Brush>();
		private static readonly Dictionary<ARC_QuickTester_ColorResourceKeys, Color> ColorResources = new Dictionary<ARC_QuickTester_ColorResourceKeys, Color>();
		private static readonly Dictionary<ARC_QuickTester_GradientStopCollectionResourceKeys, GradientStopCollection> GradientStopCollectionResources = new Dictionary<ARC_QuickTester_GradientStopCollectionResourceKeys, GradientStopCollection>();
		private static readonly Dictionary<ARC_QuickTester_DoubleResourceKeys, Double> DoubleResources = new Dictionary<ARC_QuickTester_DoubleResourceKeys, Double>();
		private static readonly Dictionary<ARC_QuickTester_HorizontalAlignmentResourceKeys, HorizontalAlignment> HorizontalAlignmentResources = new Dictionary<ARC_QuickTester_HorizontalAlignmentResourceKeys, HorizontalAlignment>();
		private static readonly Dictionary<ARC_QuickTester_VerticalAlignmentResourceKeys, VerticalAlignment> VerticalAlignmentResources = new Dictionary<ARC_QuickTester_VerticalAlignmentResourceKeys, VerticalAlignment>();
		private static readonly Dictionary<ARC_QuickTester_TextAlignmentResourceKeys, TextAlignment> TextAlignmentResources = new Dictionary<ARC_QuickTester_TextAlignmentResourceKeys, TextAlignment>();
		private static readonly Dictionary<ARC_QuickTester_DropShadowEffectResourceKeys, DropShadowEffect> DropShadowEffectResources = new Dictionary<ARC_QuickTester_DropShadowEffectResourceKeys, DropShadowEffect>();
		private static readonly Dictionary<ARC_QuickTester_FontFamilyResourceKeys, FontFamily> FontFamilyResources = new Dictionary<ARC_QuickTester_FontFamilyResourceKeys, FontFamily>();
		private static readonly Dictionary<ARC_QuickTester_FontStyleResourceKeys, FontStyle> FontStyleResources = new Dictionary<ARC_QuickTester_FontStyleResourceKeys, FontStyle>();
		private static readonly Dictionary<ARC_QuickTester_FontWeightResourceKeys, FontWeight> FontWeightResources = new Dictionary<ARC_QuickTester_FontWeightResourceKeys, FontWeight>();
		private static readonly Dictionary<ARC_QuickTester_PenResourceKeys, Pen> PenResources = new Dictionary<ARC_QuickTester_PenResourceKeys, Pen>();

		private static TOut ARC_QuickTester_GetResource<TKey, TOut>(TKey key)
		{
			var tOut = typeof(TOut);
			Dictionary<TKey, TOut> dict;
			if (tOut == typeof(Brush))
				dict = (dynamic)BrushResources;
			else if (tOut == typeof(Color))
				dict = (dynamic)ColorResources;
			else if (tOut == typeof(GradientStopCollection))
				dict = (dynamic)GradientStopCollectionResources;
			else if (tOut == typeof(Double))
				dict = (dynamic)DoubleResources;
			else if (tOut == typeof(HorizontalAlignment))
				dict = (dynamic)HorizontalAlignmentResources;
			else if (tOut == typeof(VerticalAlignment))
				dict = (dynamic)VerticalAlignmentResources;
			else if (tOut == typeof(TextAlignment))
				dict = (dynamic)TextAlignmentResources;
			else if (tOut == typeof(DropShadowEffect))
				dict = (dynamic)DropShadowEffectResources;
			else if (tOut == typeof(FontFamily))
				dict = (dynamic)FontFamilyResources;
			else if (tOut == typeof(FontStyle))
				dict = (dynamic)FontStyleResources;
			else if (tOut == typeof(FontWeight))
				dict = (dynamic)FontWeightResources;
			else if (tOut == typeof(Pen))
				dict = (dynamic)PenResources;
			else
				throw new Exception("No resources of the specified type found");

			TOut value;
			if (dict.TryGetValue(key, out value))
				return value;

			return dict[key] = (TOut)Application.Current.TryFindResource(key.ToString().Replace('_', '.'));
		}

		internal static Brush ARC_QuickTester_GetResource(ARC_QuickTester_BrushResourceKeys key) { return ARC_QuickTester_GetResource<ARC_QuickTester_BrushResourceKeys, Brush>(key); }

		internal static Color ARC_QuickTester_GetResource(ARC_QuickTester_ColorResourceKeys key) { return ARC_QuickTester_GetResource<ARC_QuickTester_ColorResourceKeys, Color>(key); }

		internal static GradientStopCollection ARC_QuickTester_GetResource(ARC_QuickTester_GradientStopCollectionResourceKeys key) { return ARC_QuickTester_GetResource<ARC_QuickTester_GradientStopCollectionResourceKeys, GradientStopCollection>(key); }

		internal static Double ARC_QuickTester_GetResource(ARC_QuickTester_DoubleResourceKeys key) { return ARC_QuickTester_GetResource<ARC_QuickTester_DoubleResourceKeys, Double>(key); }

		internal static HorizontalAlignment ARC_QuickTester_GetResource(ARC_QuickTester_HorizontalAlignmentResourceKeys key) { return ARC_QuickTester_GetResource<ARC_QuickTester_HorizontalAlignmentResourceKeys, HorizontalAlignment>(key); }

		internal static VerticalAlignment ARC_QuickTester_GetResource(ARC_QuickTester_VerticalAlignmentResourceKeys key) { return ARC_QuickTester_GetResource<ARC_QuickTester_VerticalAlignmentResourceKeys, VerticalAlignment>(key); }

		internal static TextAlignment ARC_QuickTester_GetResource(ARC_QuickTester_TextAlignmentResourceKeys key) { return ARC_QuickTester_GetResource<ARC_QuickTester_TextAlignmentResourceKeys, TextAlignment>(key); }

		internal static DropShadowEffect ARC_QuickTester_GetResource(ARC_QuickTester_DropShadowEffectResourceKeys key) { return ARC_QuickTester_GetResource<ARC_QuickTester_DropShadowEffectResourceKeys, DropShadowEffect>(key); }

		internal static FontFamily ARC_QuickTester_GetResource(ARC_QuickTester_FontFamilyResourceKeys key) { return ARC_QuickTester_GetResource<ARC_QuickTester_FontFamilyResourceKeys, FontFamily>(key); }

		internal static FontStyle ARC_QuickTester_GetResource(ARC_QuickTester_FontStyleResourceKeys key) { return ARC_QuickTester_GetResource<ARC_QuickTester_FontStyleResourceKeys, FontStyle>(key); }

		internal static FontWeight ARC_QuickTester_GetResource(ARC_QuickTester_FontWeightResourceKeys key) { return ARC_QuickTester_GetResource<ARC_QuickTester_FontWeightResourceKeys, FontWeight>(key); }

		internal static Pen GetResource(ARC_QuickTester_PenResourceKeys key) { return ARC_QuickTester_GetResource<ARC_QuickTester_PenResourceKeys, Pen>(key); }
	}
}
