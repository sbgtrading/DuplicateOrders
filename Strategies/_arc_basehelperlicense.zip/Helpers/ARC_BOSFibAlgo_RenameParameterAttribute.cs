﻿using System;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	/// <summary>
	/// Used to relabel a parameter from the parent class, or to conditionally relabel parameters of a class itself
	/// </summary>
	[AttributeUsage(AttributeTargets.Property, AllowMultiple = true)]
	public class ARC_BOSFibAlgo_RenameAttribute : ARC_BOSFibAlgo_ReferentialConditionalAttributeBase
	{
		public readonly string newName;
		public ARC_BOSFibAlgo_RenameAttribute(string newName, string conditionPropName, ARC_BOSFibAlgo_PropComparisonType compareType, params object[] args) : base(conditionPropName, compareType, args)
		{
			this.newName = newName;
		}

		public ARC_BOSFibAlgo_RenameAttribute(ARC_BOSFibAlgo_RenameAttribute attr) : base(attr)
		{
			newName = attr.newName;
		}

		public override object Clone()
		{
			return new ARC_BOSFibAlgo_RenameAttribute(this);
		}
	}

	/// <summary>
	/// Used to relabel a parameter from the parent class, or to conditionally relabel parameters of a class itself
	/// </summary>
	[AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
	public class ARC_BOSFibAlgo_RenameParameterAttribute : Attribute
	{
		public readonly string property;
		public readonly string newName;
		public ARC_BOSFibAlgo_RenameParameterAttribute(string property, string newName)
		{
			this.property = property;
			this.newName = newName;
		}
	}
}