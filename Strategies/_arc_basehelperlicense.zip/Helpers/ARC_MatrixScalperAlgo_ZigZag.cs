﻿using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.NinjaScript;
using NinjaTrader.NinjaScript;
using SharpDX.Direct2D1;
using System.Collections.Generic;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using NinjaTrader.Gui;
using SharpDX;
using Brush = SharpDX.Direct2D1.Brush;
using Point = System.Windows.Point;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	internal static class ARC_MatrixScalperAlgo_ZigZagExtensions
	{
		public static void ARC_MatrixScalperAlgo_DrawZigZag<TScript>(this RenderTarget renderTarget, TScript script, ChartScale chartScale, List<ARC_MatrixScalperAlgo_ZigZagPoint> points, Brush brush, float strokeWidth = 1, DashStyleHelper lineStyle = DashStyleHelper.Solid, bool drawAsOneLine = false)
			where TScript : NinjaScriptBase, IChartBars, IChartObject, IRenderTarget, IBarsPeriodProvider
		{
			if (points.Count < 2)
				return;

			var strokeStyle = new Stroke(Brushes.Transparent, lineStyle, strokeWidth).StrokeStyle;

			// Per side, get the points within the rendered range, and the first point on either side
			// outside of the range. Multiply each by it's side dir, then sort by order of appearance.
			var rangeStart = Math.Max(0, points.FindIndex(pt => pt.Bar >= script.ChartBars.FromIndex) - 1);
			var rangeEnd = Math.Min(points.Count - 1, points.FindLastIndex(pt => pt.Bar <= script.ChartBars.ToIndex) + 1);
			points = points.GetRange(rangeStart, rangeEnd - rangeStart + 1);

			var screenCrossTest = new ARC_MatrixScalperAlgo_CohenSutherlandTest(new Rect(script.ChartBars.FromIndex, chartScale.MinValue, script.ChartBars.ToIndex - script.ChartBars.FromIndex, chartScale.MaxMinusMin));
			var allLineVectors = new List<Vector2>(); 
			for (var i = 1; i < points.Count; i++)
			{
				var barPricePoints = new[] { points[i - 1], points[i] }
					.Select(pt => new Point(pt.Bar, pt.Price))
					.ToArray();
				if (!screenCrossTest.IntersectsLine(barPricePoints[0], barPricePoints[1]))
					continue;

				var vectors = barPricePoints
					.Select(p => new Vector2(script.ChartPanel.ChartControl.GetXByBarIndex(script.ChartBars, (int)p.X), chartScale.GetYByValue(p.Y)))
					.ToList();
				allLineVectors.AddRange(vectors);

				if (!drawAsOneLine)
					renderTarget.DrawLine(vectors[0], vectors[1], brush, strokeWidth, strokeStyle);
			}

			if (!drawAsOneLine || allLineVectors.Count == 0) 
				return;
			
			using var g = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
			using var sink = g.Open();
			sink.BeginFigure(allLineVectors[0], FigureBegin.Hollow);
			sink.AddLines(allLineVectors.ToArray());
			sink.EndFigure(FigureEnd.Open);
			sink.Close(); // calls dispose for you
			renderTarget.DrawGeometry(g, brush, strokeWidth, strokeStyle);
		}
	}

	internal class ARC_MatrixScalperAlgo_ZigZagPoint
	{
		public int Side { get; set; }
		public int Bar { get; set; }
		public double Price { get; set; }
		public int BarCreated { get; private set; }
		public double InitialPrice { get; private set; }

		public ARC_MatrixScalperAlgo_ZigZagPoint(int side, int bar, double price)
		{
			Side = side;
			Bar = BarCreated = bar;
			Price = InitialPrice = price;
		}

		public ARC_MatrixScalperAlgo_ZigZagPoint GetMidpoint(ARC_MatrixScalperAlgo_ZigZagPoint point2, int midpointBar)
		{
			var nextPointWeightRatio = (float) (midpointBar - Bar) / Math.Max(point2.Bar - Bar, 1);
			return new ARC_MatrixScalperAlgo_ZigZagPoint(point2.Side, midpointBar, Price * (1 - nextPointWeightRatio) + point2.Price * nextPointWeightRatio);
		}
	}
}