﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Controls;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Controls.WpfPropertyGrid;
using System.Windows.Data;
using Infragistics.Windows.DataPresenter;
using NinjaTrader.Gui.Tools;
using Infragistics.Windows.Editors;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	public class ARC_MegaBarAlgo_DateListEditor : PropertyEditor
	{
		public ARC_MegaBarAlgo_DateListEditor()
		{
			var button = new FrameworkElementFactory(typeof(Button));
			button.SetBinding(ContentControl.ContentProperty, new Binding("Value.Count"));
			button.SetValue(ContentControl.ContentStringFormatProperty, "{0} Dates");
			button.AddHandler(ButtonBase.ClickEvent, new RoutedEventHandler(OnClickEditButton));
			InlineTemplate = new DataTemplate(typeof(Button)) { VisualTree = button };
		}

		private static void OnClickEditButton(object sender, RoutedEventArgs e)
		{
			var dateEditorWindow = new ARC_MegaBarAlgo_DateEditorWindow((List<DateTime>) ((PropertyItemValue) ((Button) sender).DataContext).Value);
			dateEditorWindow.ShowDialog();
			((PropertyItemValue) ((Button) sender).DataContext).Value = dateEditorWindow.Dates;
		}
	}

	public class ARC_MegaBarAlgo_DateEditorWindow : NTWindow
	{
		public List<DateTime> Dates => dates.Select(d => d.Date).ToList();

		private readonly BindingList<ARC_MegaBarAlgo_DateListEditorBindingItem> dates;
	    public ARC_MegaBarAlgo_DateEditorWindow(List<DateTime> initialDates)
	    {
	        dates = new BindingList<ARC_MegaBarAlgo_DateListEditorBindingItem>(initialDates
				.Select(d => new ARC_MegaBarAlgo_DateListEditorBindingItem { Date = d })
				.ToList());
	     
			Caption = "Edit Dates";
			SizeToContent = SizeToContent.WidthAndHeight;
	        ResizeMode = ResizeMode.NoResize;

			var mainGrid = new Grid
			{
				ColumnDefinitions =
				{
					new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) },
					new ColumnDefinition { Width = GridLength.Auto }
				},
				RowDefinitions =
				{
					new RowDefinition { Height = new GridLength(1, GridUnitType.Star) },
					new RowDefinition { Height = GridLength.Auto }
				}
			};
	        
			var dateGrid = new NTGrid
			{
				GroupByAreaLocation = GroupByAreaLocation.None,
				DataSource = dates,
				FieldSettings =
				{
					LabelClickAction = LabelClickAction.Nothing,
					LabelHeight = 0
				}
			};
			dateGrid.FieldLayouts.Add(new FieldLayout());
			
			var dateField = new Field
			{
				Name = "Date",
				Label = "",
				EditorType = typeof(XamDateTimeEditor),
				Width = FieldLength.Auto
			};
			dateGrid.FieldLayouts[0].Fields.Add(dateField);

			var removeButtonFactory = new FrameworkElementFactory(typeof(Button));
			removeButtonFactory.SetValue(ContentProperty, "x");
			removeButtonFactory.SetValue(ButtonBase.DataContextProperty, new Binding("."));
			removeButtonFactory.AddHandler(ButtonBase.ClickEvent, new RoutedEventHandler(RemoveButtonClick));
			var removeButtonColumn = new TemplateField
			{
				Name = "RemoveColumnPlaceholder",
				Label = "",
				DisplayTemplate = new DataTemplate { VisualTree = removeButtonFactory },
				Width = FieldLength.Auto
			};
			dateGrid.FieldLayouts[0].Fields.Add(removeButtonColumn);

			dateGrid.EditModeStarted += DateGrid_EditModeStarted;

			var wrapper = new ContentPresenter { Content = dateGrid };
			mainGrid.ARC_MegaBarAlgo_SetChildRowColumn(wrapper, 0, 0, 1, 2);

			var addButton = new Button
			{
				Content = "Add",
				HorizontalAlignment = HorizontalAlignment.Center,
				Margin = new Thickness(0, 10, 0, 0)
			};
			addButton.Click += AddButtonClick;
			mainGrid.ARC_MegaBarAlgo_SetChildRowColumn(addButton, 1, 1);

			AddChild(mainGrid);
	    }

		private void DateGrid_EditModeStarted(object sender, Infragistics.Windows.DataPresenter.Events.EditModeStartedEventArgs e)
		{
			if (e.Cell.Field.Index == 0)
				return;
			
			var item = dates.First(d => d == e.Cell.Record.DataItem);
			dates.Remove(item);
		}

		private void RemoveButtonClick(object sender, RoutedEventArgs e)
	    {
	        var button = (Button)sender;
	        dates.Remove((ARC_MegaBarAlgo_DateListEditorBindingItem)button.DataContext);
	    }

	    private void AddButtonClick(object sender, RoutedEventArgs e)
	    {
	        dates.Add(new ARC_MegaBarAlgo_DateListEditorBindingItem { Date = DateTime.Now.Date });
	    }
	}

	public class ARC_MegaBarAlgo_DateListEditorBindingItem
	{
		public DateTime Date { get; set; }
		public object RemoveColumnPlaceholder { get; set; }
	}
}