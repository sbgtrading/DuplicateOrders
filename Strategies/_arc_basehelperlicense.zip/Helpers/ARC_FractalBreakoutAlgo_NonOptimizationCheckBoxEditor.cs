﻿using System.Globalization;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Controls.WpfPropertyGrid;
using System.Windows.Data;

namespace NinjaTrader.Custom.Strategies.Helpers.ARC
{
	public class ARC_FractalBreakoutAlgo_NonOptimizationCheckBoxEditor : PropertyEditor
	{
		public ARC_FractalBreakoutAlgo_NonOptimizationCheckBoxEditor()
		{
			InlineTemplate = CreateTemplate();
		}

		private static DataTemplate CreateTemplate()
		{
			var checkBox = new FrameworkElementFactory(typeof(CheckBox));
			checkBox.SetBinding(ToggleButton.IsCheckedProperty, new Binding("Value") { Converter = new ARC_FractalBreakoutAlgo_BoolEnumValueConverter(), Mode = BindingMode.TwoWay });
			return new DataTemplate(typeof(CheckBox)) { VisualTree = checkBox };
		}
	}

	public class ARC_FractalBreakoutAlgo_BoolEnumValueConverter : IValueConverter
	{
		private static bool ToBoolean(object value)
		{
			return value.ToString().ToLower() == "true";
		}

		private static ARC_FractalBreakoutAlgo_BoolEnum ToEnum(object value)
		{
			return value.ToString().ToLower() == "true" ? ARC_FractalBreakoutAlgo_BoolEnum.True : ARC_FractalBreakoutAlgo_BoolEnum.False;
		}

		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return targetType == typeof(bool) ? ToEnum(value) : ToBoolean(value);
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return value == null ? null : targetType == typeof(bool) ? ToEnum(value) : ToBoolean(value);
		}
	}
}