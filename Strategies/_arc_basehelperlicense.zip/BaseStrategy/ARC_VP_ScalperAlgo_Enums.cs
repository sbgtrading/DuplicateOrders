using System;

public enum ARC_VP_ScalperAlgo_RunType { BackTest, RealTime, Combined }

public enum ARC_VP_ScalperAlgo_HighWaterMarkType { Off, Realized, RealizedPlusUnrealized }

public enum ARC_VP_ScalperAlgo_TargetType { Ticks, RR, ATR }

public enum ARC_VP_ScalperAlgo_BidAsk { Bid, Ask }

[Flags]
public enum ARC_VP_ScalperAlgo_BidAskFlags { Bid = 1, Ask = 2 }

public enum ARC_VP_ScalperAlgo_StopLossType { Ticks, ATR }

public enum ARC_VP_ScalperAlgo_AtrOrTicks { Ticks, ATR }

public enum ARC_VP_ScalperAlgo_SizingStrategy { Static, FixedCost, PercentOfBalance }

public enum ARC_VP_ScalperAlgo_EntryOrderType { Market, Limit }

public enum ARC_VP_ScalperAlgo_AllowedEntryDirection { LongAndShort, LongOnly, ShortOnly, None }

public enum ARC_VP_ScalperAlgo_OppositeSignalAction { None, ExitOnly, Reverse }

public enum ARC_VP_ScalperAlgo_BarCloseOrIntrabar { BarClose, Intrabar }

public enum ARC_VP_ScalperAlgo_TickOrPercentPatternHLRange { Ticks, PercentOfPatternHLRange }

public enum ARC_VP_ScalperAlgo_ImbalanceCalculationMode { Diagonally, Horizontally }

public enum ARC_VP_ScalperAlgo_BidAskVolumeCalculationMode { UpTickDownTick, TrueBidAsk }

public enum ARC_VP_ScalperAlgo_BoolEnum { True, False }

public enum ARC_VP_ScalperAlgo_MovingAverageType { EMA, SMA, StepMA }

public enum ARC_VP_ScalperAlgo_StepMaTrendType { Level, Trend }

public enum ARC_VP_ScalperAlgo_DayWeekMonth { Day, Week, Month }

public enum ARC_VP_ScalperAlgo_SingleBarPattern
{
	Inside = 1, 
	Directional = 2,
	Outside = 3
}

[Flags]
public enum ARC_VP_ScalperAlgo_ARCFilterType
{
	TaFilters = 1,
	MoneyManagement = 2,
	Time = 4,
	Direction = 8,
	ConsecutiveTrades = 16,
	ArmState = 32,
	SameBar = 64,
	AllExceptArmState = TaFilters | MoneyManagement | Time | Direction | ConsecutiveTrades | SameBar,
	All = AllExceptArmState | ArmState
}