using NinjaTrader.Cbi;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.Indicators.ARC;
using NinjaTrader.NinjaScript.Indicators.ARC.AlgoSup;
using NinjaTrader.NinjaScript.Indicators.ARC.Supporting;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Media;
using System.Xml.Serialization;
using SharpDX;
using SharpDX.Direct2D1;
using Brush = System.Windows.Media.Brush;
using DayOfWeek = System.DayOfWeek;
using Order = NinjaTrader.Cbi.Order;
using System.Diagnostics;
using System.Globalization;

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_ExtendedStrategyConverter")]
	[ARC_TSScalperAlgo_HideParameters(ARC_TSScalperAlgo_StrategyContext.Backtest, ARC_TSScalperAlgo_StrategyContext.Optimization, Properties = new [] { nameof(AutoDisarm), nameof(RunType), nameof(ShowBacktestModeWarning) })]
	[ARC_TSScalperAlgo_HideParameters(ARC_TSScalperAlgo_StrategyContext.Realtime, Properties = new [] { nameof(EnableCompounding), nameof(StartingBalance) })]
	[ARC_TSScalperAlgo_CoLicenses(typeof(ARC_TSScalperAlgo_VMAlgo), typeof(ARC_TSScalperAlgo_ARC_TrendStepper), typeof(ARC_TSScalperAlgo_ARC_MWPatternFinderZigZag), typeof(ARC_TSScalperAlgo_TrendFilters))]
	[CategoryOrder(StrategyParameterGroupName, 1)]
	[CategoryOrder(EntryGroupName, 20)]
	[CategoryOrder(StopLossGroupName, 30)]
	[CategoryOrder(TargetsGroupName, 40)]
	[CategoryOrder(TimeControlGroupName, 50)]
	[CategoryOrder(MoneyManagementGroupName, 60)]
	[CategoryOrder(MiscFiltersGroupName, 70)]
	[CategoryOrder(HTFMovingAveragesGroupName, 80)]
	[CategoryOrder(MarketStructureFilterGroupName, 90)]
	[CategoryOrder(VMLeanGroupName, 100)]
	[CategoryOrder(ProductInfoGroupName, 110)]
	[CategoryOrder(StrategyVisualsParameterGroupName, 200)]
	[CategoryOrder(VMLeanPlotsGroupName, 210)]
	[CategoryOrder(VisualsGroupName, 220)]
	public abstract class ARC_TSScalperAlgo_ARCStrategyBase : Strategy, ARC_TSScalperAlgo_IARCLicensedWithMessages
	{
		#region Properties/Fields
		[XmlIgnore, Browsable(false)]
		public virtual bool ColicensedOnly => false;
		[Browsable(false), XmlIgnore]
		public virtual string ProductInfusionSoftTag => "";
		[Browsable(false), XmlIgnore]
		public virtual List<string> ProductBundleInfusionSoftTags => new List<string>();
		[XmlIgnore, Browsable(false)]
		public TextFixed LicensingLoadingText { get; set; }
		[XmlIgnore, Browsable(false)]
		public TextFixed LicensingErrorText { get; set; }
		[Display(GroupName = ProductInfoGroupName)]
		public virtual string ProductVersion => throw new NotImplementedException();
		[Display(GroupName = ProductInfoGroupName)]
		public virtual string ModuleName => GetType().Name.Replace("ARC_", "");

		private TextFixed inBacktestModeText;

		/// <summary>
		/// The default name for the script in the UI and ToString
		/// </summary>
		protected virtual string ProductName => GetType().Name;

		public override string DisplayName => ToString() + ARC_TSScalperAlgo_ARCLicenseValidator.LicenseModeDenotingNameSuffix;

		/// <summary>
		/// The prefix used for automation IDs for UI components to avoid collisions with other products.
		/// </summary>
		protected string AutomationIdsPrefix => ModuleName;

		/// <summary>
		/// True if we can only enter on the close of a primary (for time based bars), or the first tick of the next bar (for non-time based bars)
		/// </summary>
		protected virtual bool AllowIntrabarEntries => false;

		protected virtual float BottomRenderMargin => 0;

		protected virtual bool OverridesVMBiasAndConfluenceHandling => false;

		[XmlIgnore, Browsable(false)]
		public virtual bool HasStrategyBasedStops => false;
		[XmlIgnore, Browsable(false)]
		public virtual bool HasStrategyBasedTargets => false;

		private int[] TargetQuantities => new[] { Entry1Quantity, Entry2Quantity, Entry3Quantity };

		/// <summary>
		/// The flat PNL since the start of the strategy
		/// </summary>
		private double ChartClosedPnl => SystemPerformance.AllTrades.TradesPerformance.NetProfit;

		private int OrderBarsIdx => State == State.Realtime ? 0 : tickBarsIdx;

		/// <summary>
		/// The flat PNL since our equity curve managers start time
		/// </summary>
		private double SessionClosedPnl
		{
			get
			{
				if (SystemPerformance.AllTrades.Count == tradeCountAtLastSessionClosedPnlRefresh && lastMmReset == lastMmResetAtLastSessionClosedPnlRefresh)
					return lastSessionClosedPnl;

				lastSessionClosedPnl = SystemPerformance.AllTrades
					.Skip(tradeCountAtLastMmReset)
					.Where(trd => trd.Entry.Time >= lastMmReset)
					.Sum(trd => trd.ProfitCurrency);
				lastMmResetAtLastSessionClosedPnlRefresh = lastMmReset;
				tradeCountAtLastSessionClosedPnlRefresh = SystemPerformance.AllTrades.Count;
				return lastSessionClosedPnl;
			}
		}
		private double lastSessionClosedPnl;
		
		private bool Armed
		{
			get => armed;
			set
			{
				if (AutoDisarm && ChartControl != null && miArmDisarm != null)
					ChartControl.Dispatcher.InvokeAsync(() => miArmDisarm.Header = value ? "DISARM (Currently Armed)" : "ARM (Currently Disarmed)");
				if (State == State.Realtime)
					Log($"Strategy {(value ? "armed" : "disarmed")}", LogLevel.Warning);
				armed = value;
			}
		}
		private bool armed;
		
		protected int PendingEntryDir { get; private set; }

		protected double CurBarHigh { get; private set; }
		protected double CurBarLow { get; private set; }

		private int tradeCountAtLastSessionClosedPnlRefresh;
		private DateTime lastMmResetAtLastSessionClosedPnlRefresh;
		private int tradeCountAtLastMmReset;

		protected const string OppositeOrderName = "Opposite Exit";

		private string customToolbarControlsGridAutomationId;
		private bool isToolBarButtonAdded;
		private Grid customToolbarControlsGrid;
		private Menu menuControlContainer;
		private MenuItem menuControl, miOff, miBoth, miLong, miShort, miBreakEven, miStopLoss, miMoveStop, miArmDisarm;

		private DateTime lastMmReset;
		private double mmMaxGain;
		protected bool mmCanTrade = true;
		
		private ARC_TSScalperAlgo_OrderTracker orderTracker;
		protected int tickBarsIdx;

		private ARC_TSScalperAlgo_ChartPnl indPnlChart;
		private ARC_TSScalperAlgo_OrderSingle indOrder;
		private ARC_TSScalperAlgo_TargStop indStopTrg;

		protected double stopLossUserOverride;

		protected ARC_TSScalperAlgo_VMAlgo indMomo;
		private ARC_TSScalperAlgo_TrendFilters trendFilters;
		private bool firstTickOfPrimaryBar;
		private bool pendingFirstNewTimeTickOfPrimaryBar;

		protected int primaryBarOnLastExit = -1;
		protected int lastEntryBar;
		
		private int barToPaintAsInvalidPriceCancellation = -1;
		protected int lastSignalBar;
		protected int lastSignalDir;
		private double? pendingBarPlotSl;
		private double?[] pendingBarPlotTp;
		private double? pendingEntryLimitPrice;
		private double? pendingStopLossPrice;
		private double? pendingProfitTargetPrice;

		private ARC_TSScalperAlgo_ARC_MWPatternFinderZigZag msFilterZigZag;
		protected Brush longStripBrush;
		protected Brush shortStripBrush;
		private ATR stopLossAtr;
		private ATR targetAtr;
		private bool hitHistoricalState;

		private int consecutiveTradesInCurrentDir;
		private int lastTradeDir;
		private bool barHadValidEntry;

		private readonly ARC_TSScalperAlgo_DefaultingDictionary<string, int> safeEntryCurrentQuantities = new ARC_TSScalperAlgo_DefaultingDictionary<string, int>();
		private readonly ARC_TSScalperAlgo_DefaultingDictionary<string, double> safeEntryCurrentAvgFillPrices = new ARC_TSScalperAlgo_DefaultingDictionary<string, double>();
		private bool mmAlertShown;
		#endregion

		static ARC_TSScalperAlgo_ARCStrategyBase()
		{
			var a = new ARC_TSScalperAlgo_BoolEnumConverter();
			var b = new ARC_TSScalperAlgo_NonOptimizationCheckBoxEditor();
			var c = new ARC_TSScalperAlgo_EnhancedBrushPicker();
			foreach (var i in new object[] { a, b, c })
			{
				Debug.WriteLine(i.ToString());
				Console.WriteLine(i.ToString());
			}
		}

		#region NT Overrides
		protected override void OnStateChange()
		{
			if (State != State.SetDefaults && State != State.Configure && State != State.Terminated && !this.ARC_TSScalperAlgo_IsLicensed())
				return;
			
			if (State == State.SetDefaults)
			{
				Name = ProductName + ARC_TSScalperAlgo_ARCLicenseValidator.LicenseModeDenotingNameSuffix;
				Calculate = Calculate.OnBarClose;
				EntriesPerDirection = 3;
				MaximumBarsLookBack = MaximumBarsLookBack.TwoHundredFiftySix;
				IsInstantiatedOnEachOptimizationIteration = true;
				IsExitOnSessionCloseStrategy = false;

				StartingBalance = 1000000;
				EnableCompounding = false;

				RunType = ARC_TSScalperAlgo_RunType.BackTest;
				StartTime = 600;
				EndTime = 1600;
				ExitAtEndTime = false;
				RestartPnlOnSession = false;
				DayMaxGain = 0;
				DayMaxLoss = 0;
				HighWaterMarkType = ARC_TSScalperAlgo_HighWaterMarkType.Off;
				DailyHighWaterMarkPct = 0;
				HwmActivatedAt = 200;
				IgnoreTradeTime = false;
				StopDotColor = Brushes.Red;
				TargetDotColor = Brushes.Lime;
				AllowedEntryDirections = ARC_TSScalperAlgo_AllowedEntryDirection.LongAndShort;
				Entry1Quantity = 1;
				Entry2Quantity = 0;
				Entry3Quantity = 0;
				EntryOrderType = ARC_TSScalperAlgo_EntryOrderType.Market;
				LimitEntryOffsetTicks = 0;
				EnableAlgoDefinedStopLosses = HasStrategyBasedStops;
				StopLossType = ARC_TSScalperAlgo_StopLossType.Ticks;
				StopLoss = 10;
				StopLossATRPeriod = 14;
				EnableAlgoDefinedTargets = HasStrategyBasedTargets;
				MinAllowableTakeProfit = 1;
				MaxAllowableTakeProfit = 1000;
				TargetType = ARC_TSScalperAlgo_TargetType.Ticks;
				UseMitTargetOrders = false;
				DistanceToTargetMultiple = 1;
				ProfitTargetValue1 = 8;
				ProfitTargetValue2 = 0;
				ProfitTargetValue3 = 0;
				TrailTriggerTicks = 0;
				TrailLookbackBars = 0;
				TrailTicks = 0;
				BreakEvenTrigger = 0;
				BreakEvenPlus = 0;
				DashHistoricPnl = true;
				OnOppositeSignal = ARC_TSScalperAlgo_OppositeSignalAction.None;
				MaxPendingOrderBars = 1;
				MaxPendingOrderDistance = 10;
				TargetATRPeriod = 14;
				LimitPreOrderGapBars = true;
				MaxPreOrderGapBars = 0;
				AllowEntriesOnExitBars = true;
				AutoDisarm = false;
				MinAllowableStopLoss = 1;
				MaxAllowableStopLoss = 1000;
				EnableBacktestMmExits = false;
				ShowBacktestModeWarning = true;

				LimitConsecutiveTradesInDirection = false;
				MaxConsecutiveTradesInDirection = 1;

				ShowVMAlgo = false;
				BlockLevelEntry = 0;
				VMBiasType = ARC_TSScalperAlgo_VMAlgo_BiasType.ZeroLine;
				VMHistogramBackground = false;
				BandPeriod = 10;
				Fast = 12;
				Slow = 26;
				StdDevNumber = 1;
				VMSwingStrength = 1;
				MinDeviationMultiplier = 0;
				UseVMBias = false;
				UseVMConfluence = false;
				VMShowEmaCrossover = false;
				VMFastEmaPeriod = 14;
				VMSlowEmaPeriod = 30;
					 
				// Trend Filter indicator params
				UseHTFMovingAverage = false;
				MABarBiasPercentRequirement = 0;
				MACount = ARC_TSScalperAlgo_TrendFiltersMaCount.Single;
				MAType = ARC_TSScalperAlgo_MovingAverageType.EMA;
				MABasis = ARC_TSScalperAlgo_TrendFiltersMaBasis.Minutes;
				MATimeframe = 1;
				MAPeriod = 15;
				MAPeriod2 = 30;
				FilterMAStepSize = 40;
				FilterMAStepSize2 = 80;
				FilterMATrendType = ARC_TSScalperAlgo_StepMaTrendType.Trend;
				MABarBiasPercentRequirement = 0;
				MAColor = Brushes.WhiteSmoke;
				MAColor2 = Brushes.DodgerBlue;

				ShowMsFilterZigZag = false;
				ShowMsFilterBiasStrip = false;
				UseMsFilter = false;
				MsFilterSwingStrength = 3;
				MsFilterIncludeWicks = true;
				MsFilterNeutralColor = Brushes.Black;
				MsFilterUptrendColor = Brushes.Cyan;
				MsFilterDowntrendColor = Brushes.Magenta;
				MsFilterZigZagThickness = 2;
				MsFilterBiasStripThickness = 12;

				LongStripColor = Brushes.Green;
				LongStripOpacity = 50;
				ShortStripColor = Brushes.Red;
				ShortStripOpacity = 50;
				ChartPnLTextColor = Brushes.DimGray;

				DotsUpRisingColor = Brushes.Green;
				DotsDownRisingColor = Brushes.Green;
				DotsDownFallingColor = Brushes.Red;
				DotsUpFallingColor = Brushes.Red;
				DotsRimColor = Brushes.Black;
				BBAverageColor = Brushes.Transparent;
				BBUpperColor = Brushes.Black;
				BBLowerColor = Brushes.Black;
				HistUpColor = Brushes.LimeGreen;
				HistDownColor = Brushes.Maroon;
				ZeroLineColor = Brushes.Black;
				ConnectorColor = Brushes.White;
				DeepBullishBackgroundColor = Brushes.DarkGreen;
				BullishBackgroundColor = Brushes.Green;
				OppositeBackgroundColor = Brushes.Gray;
				BearishBackgroundColor = Brushes.Red;
				DeepBearishBackgroundColor = Brushes.DarkRed;
				ChannelColor = Brushes.DodgerBlue;
				ExcursionLevel1Color = Brushes.White;
				ExcursionLevel2Color = Brushes.Blue;
				ExcursionLevel3Color = Brushes.Red;
				VMFastEmaColor = Brushes.Aqua;
				VMSlowEmaColor = Brushes.Purple;

				UnfilledOrderColor = Brushes.Yellow;
				GapBarOrderColor = Brushes.Orange;
			}
			else if (State == State.Configure)
			{
				RealtimeErrorHandling = RealtimeErrorHandling.StopCancelCloseIgnoreRejects;
				TraceOrders = true;
				StartBehavior = StartBehavior.WaitUntilFlat;
				this.ARC_TSScalperAlgo_EnactLicensingWithWarnings(ARC_TSScalperAlgo_LicensingContextStep.Configure);
				if (!this.ARC_TSScalperAlgo_IsLicensed())
					return;

				// Reset fields for optimization
				hitHistoricalState = false;
				ResetPerRunCustomValues();

				if (Entry3Quantity > 0)
					EntriesPerDirection = 3;
				else if (Entry2Quantity > 0)
					EntriesPerDirection = 2;
				else
					EntriesPerDirection = 1;

				stopLossUserOverride = StopLoss;

				tickBarsIdx = this.ARC_TSScalperAlgo_EnsureDataSeriesAdded(AddDataSeries, BarsPeriodType.Tick, 1);
				this.ARC_TSScalperAlgo_EnsureDataSeriesAdded(AddDataSeries, BarsPeriodType.Minute, MATimeframe);

				if (IgnoreTradeTime)
					return;

				foreach (var w1 in invalidTimeWindows.Values.Where(w => w.Enabled))
				foreach (var w2 in invalidTimeWindows.Values.Where(w => w.Enabled))
				{
					if (w1 == w2 || !w1.Overlaps(w2))
						continue;

					Log("Enabled invalid trade windows are overlapping!", LogLevel.Alert);
					SetState(State.Terminated);
				}
			}
			else if (State == State.DataLoaded)
			{
				indStopTrg = ARC_TSScalperAlgo_TargStop(1, 3);
				indStopTrg.StopPlots.ForEach(p => p.Brush = StopDotColor);
				indStopTrg.TargetPlots.ForEach(p => p.Brush = TargetDotColor);
				indStopTrg.Name = "";
				AddChartIndicator(indStopTrg);

				indOrder = ARC_TSScalperAlgo_OrderSingle();
				indOrder.Plots[0].Brush = Brushes.Cyan;
				indOrder.Plots[1].Brush = Brushes.Magenta;
				indOrder.Name = "";
				AddChartIndicator(indOrder);

				indPnlChart = ARC_TSScalperAlgo_ChartPnl();
				indPnlChart.defaultTextBrush = ChartPnLTextColor;
				indPnlChart.Name = "";
				AddChartIndicator(indPnlChart);

				indMomo = ARC_TSScalperAlgo_VMAlgo(BarsArray[0], ARC_TSScalperAlgo_VMAlgo_OptimizeSpeedSettings.Max, BandPeriod, Fast, Slow, StdDevNumber, VMSwingStrength, MinDeviationMultiplier, 0, VMShowEmaCrossover, VMFastEmaPeriod, VMSlowEmaPeriod);
				indMomo.BackgroundFlooding = VMHistogramBackground ? ARC_TSScalperAlgo_VMAlgo_Flooding.Histogram : ARC_TSScalperAlgo_VMAlgo_Flooding.None;
				indMomo.DisplayLevel1 = true;
				indMomo.DotsUpRisingColor = DotsUpRisingColor;
				indMomo.DotsDownRisingColor = DotsDownRisingColor;
				indMomo.DotsDownFallingColor = DotsDownFallingColor;
				indMomo.DotsUpFallingColor = DotsUpFallingColor;
				indMomo.DotsRimColor = DotsRimColor;
				indMomo.BBAverageColor = BBAverageColor;
				indMomo.BBUpperColor = BBUpperColor;
				indMomo.BBLowerColor = BBLowerColor;
				indMomo.HistDownColor = HistDownColor;
				indMomo.HistUpColor = HistUpColor;
				indMomo.ZerolineColor = ZeroLineColor;
				indMomo.ConnectorColor = ConnectorColor;
				indMomo.DeepBearishBackgroundColor = DeepBearishBackgroundColor;
				indMomo.DeepBullishBackgroundColor = DeepBullishBackgroundColor;
				indMomo.OppositeBackgroundColor = OppositeBackgroundColor;
				indMomo.BullishBackgroundColor = BullishBackgroundColor;
				indMomo.BearishBackgroundColor = BearishBackgroundColor;
				indMomo.ChannelColor = ChannelColor;
				indMomo.Level1Color = ExcursionLevel1Color;
				indMomo.Level2Color = ExcursionLevel2Color;
				indMomo.Level3Color = ExcursionLevel3Color;
				indMomo.FastEmaColor = VMFastEmaColor;
				indMomo.SlowEmaColor = VMSlowEmaColor;
				if (ShowVMAlgo)
					AddChartIndicator(indMomo);

				if (UseHTFMovingAverage || ShowMA)
				{
					trendFilters = ARC_TSScalperAlgo_TrendFilters(MACount, MAType, MABasis, MATimeframe, MAPeriod, MAPeriod2, FilterMAStepSize, FilterMAStepSize2, FilterMATrendType, MABarBiasPercentRequirement);
					if (ShowMA)
					{
						AddChartIndicator(trendFilters);
						trendFilters.MAColor = MAColor;
						trendFilters.MAColor2 = MAColor2;
					}
				}

				orderTracker = new ARC_TSScalperAlgo_OrderTracker(3);

				if (StopLossType == ARC_TSScalperAlgo_StopLossType.ATR)
					stopLossAtr = ATR(StopLossATRPeriod);
				if (TargetType == ARC_TSScalperAlgo_TargetType.ATR)
					targetAtr = ATR(TargetATRPeriod);

				if (ShowMsFilterZigZag || ShowMsFilterBiasStrip || UseMsFilter)
					msFilterZigZag = ARC_TSScalperAlgo_ARC_MWPatternFinderZigZag(MsFilterSwingStrength, MsFilterIncludeWicks);
			}
			else if (State == State.Historical)
			{
				hitHistoricalState = true;

				longStripBrush = LongStripColor.Clone();
				longStripBrush.Opacity = LongStripOpacity / 100.0;
				longStripBrush.Freeze();

				shortStripBrush = ShortStripColor.Clone();
				shortStripBrush.Opacity = ShortStripOpacity / 100.0;
				shortStripBrush.Freeze();

				if (ChartControl == null || IsInStrategyAnalyzer)
					return;

				customToolbarControlsGridAutomationId = $"{AutomationIdsPrefix}{ChartControl.ChartTab.PersistenceId}CustomToolbarControlsGridAutomationId";
				if (isToolBarButtonAdded)
					return;

				ChartControl.Dispatcher.InvokeAsync(() =>
				{
					if (!(Window.GetWindow(ChartControl.Parent) is Chart chartWindow))
						return;

					isToolBarButtonAdded |= chartWindow.MainMenu
						.OfType<DependencyObject>()
						.Select(AutomationProperties.GetAutomationId)
						.Contains(customToolbarControlsGridAutomationId);

					if (isToolBarButtonAdded)
						return;

					AddToolBar(chartWindow);
					isToolBarButtonAdded = true;
				});
			}
			else if (State == State.Realtime)
			{
				orderTracker.AllLiveExitOrders.ForEach(CancelOrder);
				CancelPendingEntries();
				ExitPosition("EndBacktest");
				orderTracker.TransitionToRealtime(this);

				orderTracker.Reset();
				ResetMoneyManagement();
			}
			else if (State == State.Terminated)
			{
				if (hitHistoricalState)
					GC.Collect();

				if (IsInStrategyAnalyzer || !isToolBarButtonAdded || ChartControl == null)
					return;

				ChartControl.Dispatcher.InvokeAsync(() =>
				{
					if (!(Window.GetWindow(ChartControl.Parent) is Chart chartWindow))
						return;

					chartWindow.MainMenu.Remove(customToolbarControlsGrid);
					foreach (var grid in chartWindow.MainMenu.OfType<Grid>().Where(g => AutomationProperties.GetAutomationId(g) == customToolbarControlsGridAutomationId).ToList())
						chartWindow.MainMenu.Remove(grid);

					customToolbarControlsGrid = null;
					chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
				});
			}
		}

		protected override void OnMarketData(MarketDataEventArgs marketDataUpdate)
		{
			if (!this.ARC_TSScalperAlgo_IsLicensed())
				return;

			if (marketDataUpdate.MarketDataType != MarketDataType.Last || RunType == ARC_TSScalperAlgo_RunType.BackTest)
				return;

			if (Position.MarketPosition != MarketPosition.Flat)
				SyncPnlPlot();

			SyncMoneyManagement(marketDataUpdate.Price);
		}

		protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string comment)
		{
			if (orderState == OrderState.Rejected || error != ErrorCode.NoError || !string.IsNullOrWhiteSpace(comment))
			{
				Log($"Rejection: {error}", LogLevel.Warning);
				ExitPosition("Order Rejection Exit");
			}

			orderTracker.ProcessUpdate(order);
		}

		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
		{
			if (Regex.IsMatch(execution.Order.Name, @"^(L|S)\d+$"))
				HandleEntryExecution(execution, price, quantity);
			else
				HandleExitExecution(execution, quantity);

			// Can't have a pending entry order in the opposite direction, so limit reversals are entered here, after the reversal exit 
			if (OnOppositeSignal != ARC_TSScalperAlgo_OppositeSignalAction.Reverse || EntryOrderType != ARC_TSScalperAlgo_EntryOrderType.Limit)
				return;

			if (execution.Order.Name != OppositeOrderName)
				return;

			if (lastEntryBar < CurrentBars[0])
				return;

			var signalDir = execution.Order.IsLong ? 1 : -1;
			var limitPrice = Closes[0].GetValueAt(lastEntryBar);
			SubmitOrder(signalDir, limitPrice);
		}

		protected override void OnPositionUpdate(Position position, double averagePrice, int quantity, MarketPosition marketPosition)
		{
			if (IsInStrategyAnalyzer || ChartControl == null || !isToolBarButtonAdded)
				return;

			ChartControl.Dispatcher.InvokeAsync(() =>
			{
				var enabled = position.MarketPosition != MarketPosition.Flat;
				foreach (var mi in new[] { miStopLoss, miMoveStop })
					mi.IsEnabled = enabled;
			});
		}

		protected override void OnBarUpdate()
		{
			this.ARC_TSScalperAlgo_EnactLicensingWithWarnings(ARC_TSScalperAlgo_LicensingContextStep.BarUpdate);
			if (!this.ARC_TSScalperAlgo_IsLicensed())
				return;

			if (inBacktestModeText == null && Category == Category.NinjaScript && RunType == ARC_TSScalperAlgo_RunType.BackTest && ShowBacktestModeWarning)
				inBacktestModeText = Draw.TextFixed(this, "BacktestModeDisclaimer", "Backtest Mode selected, no live trades will be taken", TextPosition.BottomRight);

			if (BarsInProgress == tickBarsIdx)
			{
				if (CurrentBars[0] < 0 || CurrentBars[tickBarsIdx] < 2)
					return;

				CurBarHigh = firstTickOfPrimaryBar ? Close[0] : Math.Max(Close[0], CurBarHigh);
				CurBarLow = firstTickOfPrimaryBar ? Close[0] : Math.Min(Close[0], CurBarLow);

				// Handle the first tick to cross the session end time
				if (!ManualTradeMode && CurrentBar != 0 && (Time[0].Date != Time[1].Date || (Time[0].ARC_TSScalperAlgo_CompareTime(EndTime) != -1 && Time[1].ARC_TSScalperAlgo_CompareTime(EndTime) == -1)))
				{
					if (!IgnoreTradeTime || ExitAtEndTime)
						CancelPendingEntries();

					if (ExitAtEndTime)
						ExitPosition("endTime");
				}

				// Cancel pending entries if any distance exceeds
				if (EntryOrderType == ARC_TSScalperAlgo_EntryOrderType.Limit && CurrentBars[0] >= 0 && orderTracker
						.Where(o => o != null && !o.ARC_TSScalperAlgo_IsTerminal())
						.Select(o => o.LimitPrice)
						.Any(p => Math.Abs(Close[0] - p) > MaxPendingOrderDistance))
				{
					barToPaintAsInvalidPriceCancellation = CurrentBars[0] + (Time[0] > Times[0][0] ? 1 : 0);
					CancelPendingEntries();
				}

				if (BarsArray[tickBarsIdx].IsFirstBarOfSession || BarsArray[tickBarsIdx].IsLastBarOfSession)
				{
					if (ResetConsecutiveTradeCountOnSessionClose)
					{
						consecutiveTradesInCurrentDir = 0;
						lastTradeDir = 0;
					}

					if (RestartPnlOnSession)
						ResetMoneyManagement();
				}

				UpdateStop();
				if (State == State.Realtime)
				{
					SyncMoneyManagement(GetCurrentBid(tickBarsIdx));
					SyncMoneyManagement(GetCurrentAsk(tickBarsIdx));
				}
				else
				{
					SyncMoneyManagement(Closes[tickBarsIdx][0]);
				}

				OnTickBar();

				// Track whether we're the first tick of the current primary bar.
				// If we're allowing intrabar entries, process pending ones them here.
				if (firstTickOfPrimaryBar)
					firstTickOfPrimaryBar = false;

				if (pendingFirstNewTimeTickOfPrimaryBar)
				{
					if (Time[0] > Times[0][0])
						pendingFirstNewTimeTickOfPrimaryBar = false;
					else if (!AllowIntrabarEntries)
						return;
				}

				ProcessPendingEntries();
			}
			else if (BarsInProgress == 0)
			{
				barHadValidEntry = false;
				CurBarHigh = CurBarLow = Close[0];

				// We paint here in case orders are rejected the same bar the 
				if (barToPaintAsInvalidPriceCancellation != -1)
				{
					BackBrushes[CurrentBars[0] - barToPaintAsInvalidPriceCancellation] = UnfilledOrderColor;
					barToPaintAsInvalidPriceCancellation = -1;
				}

				if (lastSignalBar == CurrentBar && ShowRacingStripes)
					BackBrushes[0] = lastSignalDir == 1 ? longStripBrush : shortStripBrush;

				var wasFirstTickOfPrimaryBar = firstTickOfPrimaryBar;
				firstTickOfPrimaryBar = true;
				pendingFirstNewTimeTickOfPrimaryBar = true;

				// Force update momo and HTF and copy values if necessary, as we've seen this indicator show flat incorrectly
				if (ShowMsFilterZigZag || ShowMsFilterBiasStrip || UseMsFilter)
					msFilterZigZag.Update();
				indMomo.Update();
				if (ShowMA)
					trendFilters.Update();

				if (!mmCanTrade)
					BarBrushes[0] = Brushes.DimGray;

				// Check whether our gab bar settings require dequeuing pending entries
				if (PendingEntryDir != 0 && LimitPreOrderGapBars)
				{
					var gapBarCount = 0;
					for (var i = 0; i < CurrentBar - lastSignalBar && gapBarCount <= MaxPreOrderGapBars; i++)
						if (Time[i] == Time[i + 1])
							gapBarCount++;
					
					if (gapBarCount > MaxPreOrderGapBars)
					{
						PendingEntryDir = 0;
						BackBrush = GapBarOrderColor;
					}
				}

				// Draw our start of window and end of window marker
				if (!AutoDisarm)
				{
					var curTimeValid = InValidTradingWindow(Time[0]);
					if (CurrentBars[0] >= 1 && curTimeValid != InValidTradingWindow(Time[1]) && !IgnoreTradeTime)
					{
						var offset = curTimeValid ? 0 : 1;
						Draw.VerticalLine(this, $"{CurrentBars[0]}d", offset, curTimeValid ? Brushes.LimeGreen : Brushes.Red, IsMajorTimeBorder(Time[offset]) ? DashStyleHelper.Dash : DashStyleHelper.Dot, 2);
					}
				}

				if (State != State.Realtime || RunType != ARC_TSScalperAlgo_RunType.BackTest)
					SyncPnlPlot();

				// Signal order cancellations
				if (EntryOrderType != ARC_TSScalperAlgo_EntryOrderType.Market && orderTracker.lastPendingOrderInitiation < CurrentBar - MaxPendingOrderBars && orderTracker.IsPendingEntryOrders)
				{
					BackBrush = UnfilledOrderColor;
					CancelPendingEntries();
				}

				// If we're not limiting pre-order gap bars we don't need to wait for a non gap bar to process
				// orders. Otherwise, process if not already dequeued and we've received a non gap bar 
				if (!LimitPreOrderGapBars || (CurrentBars[0] >= 1 && Time[0] > Time[1] && wasFirstTickOfPrimaryBar))
					ProcessPendingEntries(1);

				if (!LimitPreOrderGapBars)
					PendingEntryDir = 0;

				// Update stop and target visuals
				SyncStopPlots();
				SyncTargetPlots();

				// Trigger strategy execution handling
				OnPrimaryBar();

				if (orderTracker[0] == null)
					return;

				// Update pending order visuals
				var dir = orderTracker[0].OrderAction == OrderAction.Buy || orderTracker[0].OrderAction == OrderAction.BuyToCover ? 1 : -1;
				var plotSeries = dir == 1 ? indOrder.EntryPriceL : indOrder.EntryPriceS;
				if (orderTracker[0].OrderType == OrderType.Limit)
					plotSeries[0] = orderTracker[0].LimitPrice;
				if (orderTracker[0].OrderType == OrderType.StopMarket || orderTracker[0].OrderType == OrderType.StopLimit)
					plotSeries[0] = orderTracker[0].StopPrice;
			}
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			if (State != State.Realtime && State != State.Terminated)
				return;

			if (!this.ARC_TSScalperAlgo_IsLicensed())
				return;

			if (!ShowMsFilterZigZag && !ShowMsFilterBiasStrip)
				return;

			if (msFilterZigZag.SwingPoints.Count < 4)
				return;
			
			msFilterZigZag.Update(CurrentBars[0], 0);

			// Check to see if any points occur past the plotted left edge, if none do, skip rendering
			var rangeStart = msFilterZigZag.SwingPoints.FindIndex(pt => pt.Bar >= ChartBars.FromIndex);
			if (rangeStart == -1)
				return;

			rangeStart = Math.Max(0, rangeStart - 6);
			var rangeEnd = Math.Min(msFilterZigZag.SwingPoints.Count - 1, msFilterZigZag.SwingPoints.FindLastIndex(pt => pt.Bar <= ChartBars.ToIndex) + 5);

			// Get the range of points that intersect the visible range, plus a few extra so that we can determine trend
			var points = msFilterZigZag.SwingPoints.GetRange(rangeStart, rangeEnd - rangeStart + 1);

			// Group points by their comparison to the prior point on that side
			var contiguousTrends = points
				.Select((p, i) => new { Point = p, Index = i, Trend = i < 2 ? 0 : p.Price.ApproxCompare(points[i - 2].Price) })
				.Skip(2)
				.ARC_TSScalperAlgo_GetContiguousGroups((t1, t2) => t1.Trend == t2.Trend && t2.Trend != 0)
				.Where(g => g.Count > 2)
				.ToList();

			// For each contiguous trend, get the points that make up the full trend
			var trends = new ARC_TSScalperAlgo_DefaultingDictionary<int, List<List<ARC_TSScalperAlgo_ZigZagPoint>>>(_ => new List<List<ARC_TSScalperAlgo_ZigZagPoint>>());
			foreach (var group in contiguousTrends)
			{
				var groupPoints = group
					.Select(g => g.Point)
					.Prepend(points[group[0].Index - 1])
					.Prepend(points[group[0].Index - 2])
					.ToList();

				if (group.Last().Index < points.Count - 1)
				{
					var addedLastPoint = false;

					// Check if there was a point where we exceeded a threshold and that was what ended the trend
					// If there is such a point, add a point to the trend marking the exact bar where it ended
					var p0 = groupPoints.Last();
					var p1 = points[group.Last().Index + 1];
					var thresh = groupPoints[groupPoints.Count - 2].Price;
					var threshCrossDir = -groupPoints.Last().Side;
					var series = !MsFilterIncludeWicks ? Closes[0] : (threshCrossDir == -1 ? Lows[0] : Highs[0]);
					for (int i = p0.Bar; i < p1.Bar; i++)
					{
						if (series.GetValueAt(i).ApproxCompare(thresh) == -threshCrossDir) 
							continue;
						groupPoints.Add(p0.GetMidpoint(p1, i));
						addedLastPoint = true;
						break;
					}

					// If we didn't end by exceeding a threshold, then we must have ended by not exceeding one.
					// In that case our trend ended when the point that failed to exceed a thresh was confirmed
					if (!addedLastPoint)
					{
						groupPoints.Add(points[group.Last().Index + 1]);
						if (group.Last().Index < points.Count - 2)
						{
							var confirmingPoint = points[group.Last().Index + 2];
							groupPoints.Add(groupPoints.Last().GetMidpoint(confirmingPoint, confirmingPoint.BarCreated));
						}
					}
				}

				trends[group[0].Trend].Add(groupPoints);
			}

			var orderedTrends = trends
				.SelectMany(kvp => kvp.Value.Select(pts => new { Points = pts, Trend = kvp.Key }))
				.OrderBy(t => t.Points[0].Bar)
				.ToList();

			var priorAaMode = RenderTarget.AntialiasMode;
			try
			{
				RenderTarget.AntialiasMode = AntialiasMode.PerPrimitive;

				// Draw the no trend zig zag below everything else
				if (ShowMsFilterZigZag)
					using (var neutralDxBrush = MsFilterNeutralColor.ToDxBrush(RenderTarget))
						RenderTarget.ARC_TSScalperAlgo_DrawZigZag(this, chartScale, points, neutralDxBrush, MsFilterZigZagThickness);

				using var uptrendDxBrush = MsFilterUptrendColor.ToDxBrush(RenderTarget);
				using var downtrendDxBrush = MsFilterDowntrendColor.ToDxBrush(RenderTarget);
				foreach (var trend in orderedTrends.Where(t => t.Trend != 0))
				{
					// Split the trend points into the 4 points that started the trend, and the points within the trend
					var backFillPoints = trend.Points
						.Take(4)
						.ToList();
					var realTrendPoints = trend.Points
						.Skip(3)
						.ToList();

					// Draw the trend as a zigzag. First 4 points as a dotted line, and the rest as a solid line
					if (ShowMsFilterZigZag)
					{
						RenderTarget.ARC_TSScalperAlgo_DrawZigZag(this, chartScale, backFillPoints, trend.Trend == 1 ? uptrendDxBrush : downtrendDxBrush, Math.Max(1, MsFilterZigZagThickness - 1), DashStyleHelper.Dot);
						RenderTarget.ARC_TSScalperAlgo_DrawZigZag(this, chartScale, realTrendPoints, trend.Trend == 1 ? uptrendDxBrush : downtrendDxBrush, MsFilterZigZagThickness);
					}

					if (!ShowMsFilterBiasStrip)
						continue;

					// Draw the trend as a bias strip. First 4 points as a dotted line, and the rest as a solid line
					var bottomY = chartScale.GetYByValue(chartScale.MinValue);
					for (int i = 0; i < 2; i++)
					{
						var thickness = i == 0 ? MsFilterBiasStripThickness * 3 / 4 : MsFilterBiasStripThickness;
						var subset = i == 0 ? backFillPoints : realTrendPoints;
						var vectorArray = subset
							.Take(1)
							.Append(subset.Last())
							.Select(p => new Vector2(chartControl.GetXByBarIndex(ChartBars, p.Bar), bottomY - (int)Math.Ceiling(MsFilterBiasStripThickness / 2) - BottomRenderMargin))
							.ToArray();

						var strokeStyle = new Stroke(Brushes.Transparent, i == 0 ? DashStyleHelper.Dot : DashStyleHelper.Solid, thickness).StrokeStyle;
						RenderTarget.DrawLine(vectorArray[0], vectorArray[1], trend.Trend == 1 ? uptrendDxBrush : downtrendDxBrush, thickness, strokeStyle);
					}
				}
			}
			finally
			{
				RenderTarget.AntialiasMode = priorAaMode;
			}
		}
		#endregion

		#region UI
		private void AddToolBar(Chart chartWindow)
		{
			menuControlContainer = new Menu { Background = Brushes.Orange, VerticalAlignment = VerticalAlignment.Center };
			menuControl = new MenuItem { BorderThickness = new Thickness(2), BorderBrush = Brushes.Gold, Header = ButtonText, Foreground = Brushes.Gold, Background = Brushes.MidnightBlue, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			menuControlContainer.Items.Add(menuControl);

			miOff = new MenuItem { Header = "OFF", Name = "ARCOff", IsCheckable = true, IsChecked = AllowedEntryDirections == ARC_TSScalperAlgo_AllowedEntryDirection.None };
			miOff.Click += (_, __) =>
			{
				AllowedEntryDirections = ARC_TSScalperAlgo_AllowedEntryDirection.None;
				miOff.IsChecked = true;
				miBoth.IsChecked = false;
				miLong.IsChecked = false;
				miShort.IsChecked = false;
				TriggerCustomEvent(___ =>
				{
					CancelPendingEntries();
					if (Position.MarketPosition != MarketPosition.Flat)
						ExitPosition("OFF");
				}, tickBarsIdx, null);
			};
			menuControl.Items.Add(miOff);

			miBoth = new MenuItem { Header = "LONG AND SHORT", Name = "ARCBoth", IsCheckable = true, IsChecked = AllowedEntryDirections == ARC_TSScalperAlgo_AllowedEntryDirection.LongAndShort };
			miBoth.Click += (_, __) =>
			{
				AllowedEntryDirections = ARC_TSScalperAlgo_AllowedEntryDirection.LongAndShort;
				miOff.IsChecked = false;
				miBoth.IsChecked = true;
				miLong.IsChecked = false;
				miShort.IsChecked = false;
			};
			menuControl.Items.Add(miBoth);

			miLong = new MenuItem { Header = "LONG ONLY", Name = "ARCLong", IsCheckable = true, IsChecked = AllowedEntryDirections == ARC_TSScalperAlgo_AllowedEntryDirection.LongOnly };
			miLong.Click += (_, __) =>
			{
				AllowedEntryDirections = ARC_TSScalperAlgo_AllowedEntryDirection.LongOnly;
				miOff.IsChecked = false;
				miBoth.IsChecked = false;
				miLong.IsChecked = true;
				miShort.IsChecked = false;
			};
			menuControl.Items.Add(miLong);

			miShort = new MenuItem { Header = "SHORT ONLY", Name = "ARCShort", IsCheckable = true, IsChecked = AllowedEntryDirections == ARC_TSScalperAlgo_AllowedEntryDirection.ShortOnly };
			miShort.Click += (_, __) =>
			{
				AllowedEntryDirections = ARC_TSScalperAlgo_AllowedEntryDirection.ShortOnly;
				miOff.IsChecked = false;
				miBoth.IsChecked = false;
				miLong.IsChecked = false;
				miShort.IsChecked = true;
			};
			menuControl.Items.Add(miShort);
			menuControl.Items.Add(new Separator());

			if (ManualTradeMode)
			{
				miArmDisarm = new MenuItem { Header = "ARM (Currently Disarmed)", Name = "ARCArmDisarm" };
				miArmDisarm.Click += (_, __) => Armed = !Armed;
				menuControl.Items.Add(miArmDisarm);
				menuControl.Items.Add(new Separator());
			}

			miBreakEven = new MenuItem { Header = "Move Stop to BE", Name = "ARCBreakEven", IsCheckable = false };
			miBreakEven.Click += (_, __) => TriggerCustomEvent(___ => SetStopToEntryPrice(), null);
			menuControl.Items.Add(miBreakEven);
			menuControl.Items.Add(new Separator());

			miStopLoss = new MenuItem { Header = $"SL Ticks:   {stopLossUserOverride}", StaysOpenOnClick = true };
			miStopLoss.Click += (_, e) => TriggerCustomEvent(__ => SetStopOverride(stopLossUserOverride + 1), tickBarsIdx, null);
			miStopLoss.MouseWheel += (_, e) => TriggerCustomEvent(__ => SetStopOverride(stopLossUserOverride + e.Delta.CompareTo(0)), tickBarsIdx, null);
			menuControl.Items.Add(miStopLoss);

			miMoveStop = new MenuItem { Header = "Move Stop", Name = "ARCMoveStop", IsCheckable = false };
			miMoveStop.Click += (_, __) => TriggerCustomEvent(___ => SetStopToUserOverride(), null);
			menuControl.Items.Add(miMoveStop);

			customToolbarControlsGrid = new Grid { Visibility = Visibility.Collapsed };
			customToolbarControlsGrid.Children.Add(menuControlContainer);

			chartWindow.MainMenu.Add(customToolbarControlsGrid);
			chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

			if (ReferenceEquals(chartWindow.MainTabControl.SelectedContent, ChartControl.ChartTab))
				customToolbarControlsGrid.Visibility = Visibility.Visible;

			foreach (var mi in menuControl.Items.OfType<MenuItem>())
			{
				mi.Foreground = Brushes.Black;
				mi.FontWeight = FontWeights.Normal;
				mi.IsEnabled = RunType != ARC_TSScalperAlgo_RunType.BackTest;
			}

			AutomationProperties.SetAutomationId(customToolbarControlsGrid, customToolbarControlsGridAutomationId);
		}

		private void TabSelectionChangedHandler(object sender, SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0)
				return;

			if (!(e.AddedItems[0] is TabItem tabItem))
				return;

			if (tabItem.Content is ChartTab temp && customToolbarControlsGrid != null)
				customToolbarControlsGrid.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
		}

		private void SetStopOverride(double ticks)
		{
			stopLossUserOverride = ticks;
			if (!IsInStrategyAnalyzer)
				ChartControl.Dispatcher.InvokeAsync(() => miStopLoss.Header = $"SL Ticks:   {ticks}");
		}
		#endregion

		#region Order Handling
		/*
         * NOTE: Backtest execution seems to be fairly different depending on the current bars in progress, for max accuracy, we need to execute
         * while on the tick time frame. This is either an NT8 execution engine limitation (as hinted at by documentation), or because of the order
         * bars are arriving in (meaning the tick to cap a bar arrives after the bar it caps).
         */
		
		private void HandleExitExecution(Execution execution, int quantity)
		{
			OnExitExecution(execution, quantity);

			if (string.IsNullOrWhiteSpace(execution.Order.FromEntrySignal))
			{
				if (quantity != safeEntryCurrentQuantities.Values.Sum())
					throw new Exception("Exit not tied to entry, but does not exit entire position!");
				safeEntryCurrentQuantities.Clear();
				safeEntryCurrentAvgFillPrices.Clear();
			}
			else
			{
				safeEntryCurrentQuantities[execution.Order.FromEntrySignal] -= quantity;
				if (safeEntryCurrentQuantities[execution.Order.FromEntrySignal] == 0)
					safeEntryCurrentAvgFillPrices[execution.Order.FromEntrySignal] = 0;
			}

			primaryBarOnLastExit = execution.BarIndex;
			
			SyncPnlPlot();

			if (string.IsNullOrWhiteSpace(execution.Order.FromEntrySignal) || !int.TryParse(execution.Order.FromEntrySignal.Substring(1), out var orderIdx))
				return;
			orderIdx -= 1;

			// If we've executed, partially or otherwise, our stop loss then adjust or cancel out take profit
			var stop = orderTracker.stopLossOrders[orderIdx];
			var target = orderTracker.targetOrders[orderIdx];
			if (stop == null || target == null)
				return;

			var oppositeOrder = stop.OrderId == execution.OrderId ? target : (target.OrderId == execution.OrderId ? stop : null);
			if (oppositeOrder == null)
				return;
			
			if (oppositeOrder.ARC_TSScalperAlgo_IsTerminal())
				return;

			if (safeEntryCurrentQuantities[execution.Order.FromEntrySignal] == 0)
				CancelOrder(oppositeOrder);
			else
				ChangeOrder(oppositeOrder, safeEntryCurrentQuantities[execution.Order.FromEntrySignal], oppositeOrder.LimitPrice, oppositeOrder.StopPrice);
		}

		private void HandleEntryExecution(Execution execution, double price, int quantity)
		{
			OnEntryExecution(execution, price, quantity);
			if (ManualTradeMode && State == State.Realtime)
				Armed = false;
			
			safeEntryCurrentAvgFillPrices[execution.Order.Name] = (quantity * price + safeEntryCurrentQuantities[execution.Order.Name] * safeEntryCurrentAvgFillPrices[execution.Order.Name]) / (quantity + safeEntryCurrentQuantities[execution.Order.Name]);
			safeEntryCurrentQuantities[execution.Order.Name] += quantity;
			
			var dir = execution.Order.IsLong ? 1 : -1;
			var sameDirAsLastTrade = dir == lastTradeDir;
			lastTradeDir = dir;

			var orderIdx = int.Parse(execution.Order.Name.Substring(1)) - 1;
			var sl = GetSlPrice(dir, safeEntryCurrentAvgFillPrices[execution.Order.Name]);

			if (orderTracker.stopLossOrders[orderIdx] == null)
			{
				var slOrder = dir == 1
					? ExitLongStopMarket(OrderBarsIdx, true, safeEntryCurrentQuantities[execution.Order.Name], sl, "Stop loss", execution.Order.Name)
					: ExitShortStopMarket(OrderBarsIdx, true, safeEntryCurrentQuantities[execution.Order.Name], sl, "Stop loss", execution.Order.Name);
				pendingBarPlotSl = dir == 1 
					? Math.Min(orderTracker.MinStopLossValue, sl)
					: Math.Max(orderTracker.MaxStopLossValue, sl);
				if (slOrder == null)
				{
					ExitPosition("Stop Loss Rejected");
					return;
				}

				orderTracker.ProcessUpdate(slOrder);

				// Since we don't have an active stop loss, this is the first entry of the order
				// and not a secondary partial. Adjust our consecutive directional trade count.
				if (orderIdx == 0)
				{
					if (sameDirAsLastTrade)
						consecutiveTradesInCurrentDir++;
					else
						consecutiveTradesInCurrentDir = 1;
				}
			}
			else
			{
				pendingBarPlotSl = dir == 1 
					? Math.Min(orderTracker.MinStopLossValue, sl)
					: Math.Max(orderTracker.MaxStopLossValue, sl);
				ChangeOrder(orderTracker.stopLossOrders[orderIdx], safeEntryCurrentQuantities[execution.Order.Name], 0, sl);
			}

			var tpValue = orderIdx switch
			{
				0 => ProfitTargetValue1,
				1 => ProfitTargetValue2,
				2 => ProfitTargetValue3,
				_ => throw new IndexOutOfRangeException()
			};

			if (tpValue <= 0) 
				return;

			var tpBaseOffset = TargetType switch
			{
				ARC_TSScalperAlgo_TargetType.Ticks => TickSize,
				ARC_TSScalperAlgo_TargetType.RR => Math.Abs(safeEntryCurrentAvgFillPrices[execution.Order.Name] - sl),
				ARC_TSScalperAlgo_TargetType.ATR => targetAtr[0],
				_ => throw new ArgumentOutOfRangeException()
			};

			var tp = Math.Max(0, safeEntryCurrentAvgFillPrices[execution.Order.Name] + dir * tpValue * tpBaseOffset);
			if (pendingProfitTargetPrice != null && EnableAlgoDefinedTargets && orderIdx == 0)
				tp = safeEntryCurrentAvgFillPrices[execution.Order.Name] + DistanceToTargetMultiple * (pendingProfitTargetPrice.Value - safeEntryCurrentAvgFillPrices[execution.Order.Name]);

			if (orderTracker.targetOrders[orderIdx] != null)
			{
				ChangeOrder(orderTracker.targetOrders[orderIdx], safeEntryCurrentQuantities[execution.Order.Name], UseMitTargetOrders ? 0 : tp, UseMitTargetOrders ? tp : 0);
				pendingBarPlotTp[orderIdx] = tp;
				return;
			}

			Order tpOrder;
			if (UseMitTargetOrders)
			{
				tpOrder = dir == 1
					? ExitLongMIT(OrderBarsIdx, true, quantity, tp, "Profit target", execution.Order.Name)
					: ExitShortMIT(OrderBarsIdx, true, quantity, tp, "Profit target", execution.Order.Name);
			}
			else
			{
				tpOrder = dir == 1
					? ExitLongLimit(OrderBarsIdx, true, quantity, tp, "Profit target", execution.Order.Name)
					: ExitShortLimit(OrderBarsIdx, true, quantity, tp, "Profit target", execution.Order.Name);
			}

			pendingBarPlotTp[orderIdx] = tp;
			if (tpOrder == null)
			{
				ExitPosition("Take Profit Rejected");
				return;
			}

			orderTracker.ProcessUpdate(tpOrder);
		}

		private double GetSlPrice(int dir, double avgEntryPrice)
		{
			return pendingStopLossPrice ?? Math.Max(0, avgEntryPrice - dir * StopLoss * (StopLossType == ARC_TSScalperAlgo_StopLossType.Ticks ? TickSize : stopLossAtr[0]));
		}

		private void UpdateStop()
		{
			if (Position.MarketPosition == MarketPosition.Flat)
				return;

			var dir = Position.MarketPosition == MarketPosition.Long ? 1 : -1;
			var stop = dir == 1 ? 0 : double.MaxValue;

			var extreme = dir == 1 ? High[0] : Low[0];
			var crossedTrailTrigger = extreme.ApproxCompare(Position.AveragePrice + dir * TrailTriggerTicks * TickSize) == dir;
			if (crossedTrailTrigger)
			{
				if (TrailLookbackBars != 0)
				{
					var priceSeries = dir == 1 ? Lows[0] : Highs[0];
					var barsAgo = dir == 1 ? LowestBar(priceSeries, TrailLookbackBars) : HighestBar(priceSeries, TrailLookbackBars);
					stop = priceSeries[barsAgo];
				}
				else if (TrailTicks > 0)
				{
					stop = extreme;
				}

				stop -= dir * TrailTicks * TickSize;
			}

			if (BreakEvenTrigger > 0 && extreme.ApproxCompare(Position.AveragePrice + dir * BreakEvenTrigger * TickSize) != -dir)
				stop = dir == 1 ? Math.Max(stop, Position.AveragePrice + BreakEvenPlus * TickSize) : Math.Min(stop, Position.AveragePrice - BreakEvenPlus * TickSize);

			// If our stop is closer to our target then the target value, do nothing
			if (stop.ApproxCompare(dir == 1 ? orderTracker.MaxStopLossValue : orderTracker.MinStopLossValue) != dir)
				return;

			if (stop.ApproxCompare(dir == 1 ? GetCurrentBid() : GetCurrentAsk()) != dir)
				SetStopLoss(stop);
			else
				ExitPosition("Stop loss Cross");
		}

		private int GetOrderQuantity(int quantityFactor, double entryPrice, double stopLoss)
		{
			if (SizingStrategy == ARC_TSScalperAlgo_SizingStrategy.Static)
				return quantityFactor;

			var accountSize = Category == Category.NinjaScript
				? Account.Get(AccountItem.NetLiquidation, Currency.UsDollar)
				: StartingBalance + (EnableCompounding ? indPnlChart.OpenPnl + indPnlChart.ChartTotalClosedPnl : 0);
			var pricePerContract = Math.Abs(entryPrice - stopLoss) * Instrument.MasterInstrument.PointValue;
			return SizingStrategy switch
			{
				ARC_TSScalperAlgo_SizingStrategy.FixedCost => (int) (quantityFactor / pricePerContract),
				ARC_TSScalperAlgo_SizingStrategy.PercentOfBalance => (int) ((quantityFactor / 100d) * accountSize / pricePerContract),
				_ => throw new ArgumentOutOfRangeException()
			};
		}

		private void SubmitOrder(int direction, double price)
		{
			if (direction == 0 || !mmCanTrade)
				return;

			var orderPref = direction == 1 ? "L" : "S";

			var quantities = TargetQuantities;

			// Iterate through our orders, checking if it will replace an existing tracked order, and cancelling it if it won't be and is cancellable
			var replacingOrder = Enumerable.Range(0, quantities.Length)
				.Select(i => orderTracker[i] != null)
				.ToArray();
			for (var i = 0; i < quantities.Length; i++)
			{
				if (quantities[i] == 0 || !replacingOrder[i])
					continue;

				// If the order isn't an opposing order and both are market orders, or both target the same limit price, then we are replacing the existing order
				if (orderTracker[i].ARC_TSScalperAlgo_Direction() != -direction && (orderTracker[i].OrderType != OrderType.Limit || EntryOrderType == ARC_TSScalperAlgo_EntryOrderType.Limit || orderTracker[i].LimitPrice.ApproxCompare(price) == 0))
					continue;

				if (!orderTracker[i].ARC_TSScalperAlgo_IsTerminal())
				{
					CancelOrder(orderTracker[i]);
					orderTracker[i] = null;
				}

				replacingOrder[i] = false;
			}

			var slPrice = GetSlPrice(direction, price);
			var rejectedBasedOnPrice = false;
			for (var i = 0; i < quantities.Length; i++)
			{
				var quantity = GetOrderQuantity(quantities[i], price, slPrice);
				if (quantity == 0)
					continue;

				// Process individual orders
				var orderName = orderPref + (i + 1);
				switch (EntryOrderType)
				{
				case ARC_TSScalperAlgo_EntryOrderType.Market:
					if (orderTracker[i] != null)
						continue;

					orderTracker[i] = direction == 1
						? EnterLong(OrderBarsIdx, quantity, orderName)
						: EnterShort(OrderBarsIdx, quantity, orderName);
					break;
				case ARC_TSScalperAlgo_EntryOrderType.Limit:
					// TODO Move this price protection to cover everything except market orders
					var p = price - direction * LimitEntryOffsetTicks * TickSize;
					if (p.ApproxCompare(direction == 1 ? GetCurrentAsk() : GetCurrentBid()) == direction)
					{
						rejectedBasedOnPrice = true;
						continue;
					}

					if (orderTracker[i] == null)
					{
						orderTracker[i] = direction == 1
							? EnterLongLimit(OrderBarsIdx, true, quantity, p, orderName)
							: EnterShortLimit(OrderBarsIdx, true, quantity, p, orderName);
						continue;
					}

					// Determine if this is a switch from stop to limit at the same price
					if (orderTracker[i].OrderType == OrderType.StopMarket && orderTracker[i].StopPrice.ApproxCompare(price) == 0)
						continue;

					if (orderTracker[i].LimitPrice.ApproxCompare(p) == 0)
						continue;

					orderTracker[i] = direction == 1
						? EnterLongLimit(OrderBarsIdx, true, quantity, p, orderName)
						: EnterShortLimit(OrderBarsIdx, true, quantity, p, orderName);
					break;
				}
			}

			if (rejectedBasedOnPrice)
				barToPaintAsInvalidPriceCancellation = lastSignalBar + 1;
			else if (EntryOrderType != ARC_TSScalperAlgo_EntryOrderType.Market && !replacingOrder.Any(i => i))
				orderTracker.lastPendingOrderInitiation = CurrentBars[0];
		}

		/// <summary>
		/// Queues an entry in the provided direction, which will execute on the next available primary bar, as long as it's not preceded by gap bars
		/// </summary>
		protected void QueueEntry(int dir, int signalBarOffset = 0, double? limitPrice = null, double? profitTargetPrice = null, double? stopLossPrice = null)
		{
			if (signalBarOffset <= 0 && ShowRacingStripes && (PendingEntryDir != dir || profitTargetPrice != pendingProfitTargetPrice || pendingStopLossPrice != stopLossPrice))
				BackBrushes[-signalBarOffset] = dir == 1 ? longStripBrush : shortStripBrush;

			barHadValidEntry = true;
			PendingEntryDir = dir;
			pendingProfitTargetPrice = profitTargetPrice;
			pendingStopLossPrice = stopLossPrice;
			pendingEntryLimitPrice = limitPrice;
			lastSignalDir = dir;
			lastSignalBar = CurrentBars[0] + signalBarOffset;
		}

		protected void SetStopLoss(double price)
		{
			if (Position.MarketPosition == MarketPosition.Flat)
				return;

			if (price <= double.Epsilon)
				return;

			var dir = Position.MarketPosition == MarketPosition.Long ? 1 : -1;
			for (var i = 0; i < orderTracker.Count; i++)
			{
				if (orderTracker.stopLossOrders[i] == null || price.ApproxCompare(orderTracker.stopLossOrders[i].StopPrice) != dir)
					continue;

				if (!orderTracker.stopLossOrders[i].ARC_TSScalperAlgo_IsTerminal())
					ChangeOrder(orderTracker.stopLossOrders[i], orderTracker.stopLossOrders[i].Quantity, 0, price);
			}
		}

		protected void ExitPosition(string orderName)
		{
			if (Position.MarketPosition == MarketPosition.Flat || orderTracker.cancelOrders.Any(c => c != null))
				return;

			for (var i = 0; i < 3; i++)
			{
				if (TargetQuantities[i] == 0)
					break;

				var entryName = (Position.MarketPosition == MarketPosition.Long ? "L" : "S") + (i + 1);
				orderTracker.cancelOrders[i] = Position.MarketPosition == MarketPosition.Long 
					? ExitLong(OrderBarsIdx, safeEntryCurrentQuantities[entryName], orderName, entryName)
					: ExitShort(OrderBarsIdx, safeEntryCurrentQuantities[entryName], orderName, entryName);
			}
		}

		protected void CancelPendingEntries()
		{
			if (!orderTracker.IsPendingEntryOrders)
			{
				PendingEntryDir = 0;
				return;
			}

			orderTracker
				.Where(o => o != null && o.OrderType != OrderType.Market && !o.ARC_TSScalperAlgo_IsTerminal())
				.ToList()
				.ForEach(CancelOrder);
		}

		private void SetStopToEntryPrice()
		{
			if (Position.MarketPosition == MarketPosition.Flat)
				return;

			var dir = Position.MarketPosition == MarketPosition.Long ? 1 : -1;

			// If the stop closest to where we started is already at or above the entry price, do nothing
			if (Position.AveragePrice.ApproxCompare(dir == 1 ? orderTracker.MinStopLossValue : orderTracker.MaxStopLossValue) != dir)
				return;

			// If our entry price is on the wrong side of the relevant bid ask price, do nothing
			if ((dir == 1 ? GetCurrentBid() : GetCurrentAsk()).ApproxCompare(Position.AveragePrice) != dir)
				return;
			
			SetStopLoss(Position.AveragePrice);
		}

		private void SetStopToUserOverride()
		{
			if (Position.MarketPosition == MarketPosition.Flat)
				return;
			var dir = Position.MarketPosition == MarketPosition.Long ? 1 : -1;
			var sl = Position.AveragePrice - dir * stopLossUserOverride * TickSize;
			if ((dir == 1 ? GetCurrentBid() : GetCurrentAsk()).ApproxCompare(sl) == dir)
				SetStopLoss(sl);
		}

		private void ProcessPendingEntries(int signalBarOffset = 0)
		{
			if (PendingEntryDir == 0)
				return;

			// Don't enter on any bar occurring after a gap bar
			var curEntry = PendingEntryDir;
			PendingEntryDir = 0;

			if (CurrentBars[0] - signalBarOffset < Math.Max(BarsRequiredToTrade, 1) || CurrentBars[tickBarsIdx] < 1)
				return;

			if (!TradeAllowed(curEntry, ARC_TSScalperAlgo_ARCFilterType.Direction | ARC_TSScalperAlgo_ARCFilterType.MoneyManagement | ARC_TSScalperAlgo_ARCFilterType.Time | ARC_TSScalperAlgo_ARCFilterType.ConsecutiveTrades | ARC_TSScalperAlgo_ARCFilterType.ArmState))
				return;

			// Enter if possible and needed, otherwise just exit (limit orders are entered on the execution of the reversal exit)
			var positionOpposesSignal = Position.MarketPosition == (curEntry == 1 ? MarketPosition.Short : MarketPosition.Long);
			lastEntryBar = CurrentBars[0] - signalBarOffset;
			if (positionOpposesSignal && (OnOppositeSignal == ARC_TSScalperAlgo_OppositeSignalAction.ExitOnly || (OnOppositeSignal == ARC_TSScalperAlgo_OppositeSignalAction.Reverse && EntryOrderType == ARC_TSScalperAlgo_EntryOrderType.Limit)))
				ExitPosition(OppositeOrderName);
			if (Position.MarketPosition == MarketPosition.Flat || (positionOpposesSignal && OnOppositeSignal == ARC_TSScalperAlgo_OppositeSignalAction.Reverse && EntryOrderType == ARC_TSScalperAlgo_EntryOrderType.Market))
			{
				foreach (var o in orderTracker.stopLossOrders.Concat(orderTracker.targetOrders).Where(o => o != null && !o.ARC_TSScalperAlgo_IsTerminal()))
					CancelOrder(o);
				var entryPrice = (EntryOrderType == ARC_TSScalperAlgo_EntryOrderType.Limit ? pendingEntryLimitPrice : null) ?? (AllowIntrabarEntries ? Closes[tickBarsIdx][0] : Closes[0][signalBarOffset]);
				SubmitOrder(curEntry, entryPrice);
			}
		}
		#endregion

		#region Price/Bar Helpers
		/// <summary>
		/// Return the max high and min low in the range (includes the current
		/// primary bar, meaning offset = 0 won't include Highs[0][0])
		/// </summary>
		/// <param name="offset"></param>
		/// <param name="lookback"></param>
		/// <param name="includeCurrentBar"></param>
		/// <returns></returns>
		public (double Min, double Max) GetRangeMinMax(int lookback, int offset = 0, bool includeCurrentBar = false)
		{
			var min = double.MaxValue;
			var max = double.MinValue;
			for (var i = offset; i <= lookback + offset; i++)
			{
				min = Math.Min(min, includeCurrentBar && i == 0 ? CurBarLow : Lows[0][i - (includeCurrentBar ? 1 : 0)]);
				max = Math.Max(max, includeCurrentBar && i == 0 ? CurBarHigh : Highs[0][i - (includeCurrentBar ? 1 : 0)]);
			}

			return (min, max);
		}

		/// <summary>
		/// Return the max high - min low in the range (includes the current
		/// primary bar, meaning offset = 0 won't include Highs[0][0])
		/// </summary>
		/// <param name="offset"></param>
		/// <param name="lookback"></param>
		/// <param name="includeCurrentBar"></param>
		/// <returns></returns>
		public double GetRange(int lookback, int offset = 0, bool includeCurrentBar = false)
		{
			var (min, max) = GetRangeMinMax(lookback, offset, includeCurrentBar);
			return max - min;
		}

		/// <summary>
		/// Return the barth bars open to close to high low ratio
		/// </summary>
		/// <returns></returns>
		public double GetBodyRatio(int bar)
		{
			return Math.Abs(Opens[0][bar] - Closes[0][bar]) / (Highs[0][bar] - Lows[0][bar]);
		}

		protected ARC_TSScalperAlgo_SingleBarPattern GetSingleBarPattern(int offset)
		{
			var comparisons = new[] { Lows, Highs }
				.Select(v => v[0][offset].ApproxCompare(v[0][offset + 1]))
				.ToArray();

			// 2 = directional bar
			if (comparisons[0] == comparisons[1] || comparisons[0] == 0 || comparisons[1] == 0)
				return ARC_TSScalperAlgo_SingleBarPattern.Directional;

			// 3 = Outside bar, 1 = inside bar
			return comparisons[0] == -1 ? ARC_TSScalperAlgo_SingleBarPattern.Outside : ARC_TSScalperAlgo_SingleBarPattern.Inside;
		}
		#endregion

		private bool IsMajorTimeBorder(DateTime time)
		{
			var timeComp = time.Hour * 100 + time.Minute;
			return timeComp == StartTime || timeComp == EndTime;
		}

		private void ResetPerRunCustomValues()
		{
			barHadValidEntry = false;
			safeEntryCurrentAvgFillPrices.Clear();
			safeEntryCurrentQuantities.Clear();
			primaryBarOnLastExit = -1;
			pendingEntryLimitPrice = null;
			consecutiveTradesInCurrentDir = 0;
			lastTradeDir = 0;
			pendingBarPlotSl = null;
			pendingBarPlotTp = new double?[3];
			lastSessionClosedPnl = 0;
			tradeCountAtLastSessionClosedPnlRefresh = 0;
			lastMmResetAtLastSessionClosedPnlRefresh = default;
			tradeCountAtLastMmReset = 0;
			lastMmReset = default;
			mmMaxGain = 0;
			mmCanTrade = true;
			firstTickOfPrimaryBar = false;
			pendingFirstNewTimeTickOfPrimaryBar = false;
			lastEntryBar = -1;
			PendingEntryDir = 0;
			barToPaintAsInvalidPriceCancellation = -1;
			lastSignalBar = -1;
			lastSignalDir = 0;
			pendingStopLossPrice = null;
			pendingProfitTargetPrice = null;
			Armed = false;
			mmAlertShown = false;
		}

		protected virtual void OnPrimaryBar()
		{ }

		protected virtual void OnTickBar()
		{ }

		protected virtual void OnExitExecution(Execution execution, int quantity)
		{ }

		protected virtual void OnEntryExecution(Execution execution, double price, int quantity)
		{ }

		protected bool TradeAllowedWithStop(int dir, double entryPrice, double stopLossPrice)
		{
			return stopLossPrice.ApproxCompare(entryPrice) == -dir && Math.Abs((entryPrice - stopLossPrice) / TickSize).ARC_TSScalperAlgo_InRange(MinAllowableStopLoss, MaxAllowableStopLoss) && TargetQuantities.Sum(q => GetOrderQuantity(q, entryPrice, stopLossPrice)) != 0;
		}

		protected bool TradeAllowedWithTakeProfit(int dir, double entryPrice, double takeProfitPrice)
		{
			return takeProfitPrice.ApproxCompare(entryPrice) == dir && Math.Abs((entryPrice - takeProfitPrice) / TickSize * DistanceToTargetMultiple).ARC_TSScalperAlgo_InRange(MinAllowableTakeProfit, MaxAllowableTakeProfit);
		}

		protected bool TradeAllowed(int dir, ARC_TSScalperAlgo_ARCFilterType consideredFilters = ARC_TSScalperAlgo_ARCFilterType.AllExceptArmState)
		{
			// Prevent queuing orders twice in one bar
			if (consideredFilters.HasFlag(ARC_TSScalperAlgo_ARCFilterType.SameBar) && barHadValidEntry)
				return false;

			// Prevent queueing additional entries in the same direction
			if (Position.MarketPosition == (dir == 1 ? MarketPosition.Long : MarketPosition.Short))
				return false;
			
			if (Category == Category.NinjaScript && ((RunType == ARC_TSScalperAlgo_RunType.RealTime && State == State.Historical) || (RunType == ARC_TSScalperAlgo_RunType.BackTest && State == State.Realtime)))
				return false;

			if (consideredFilters.HasFlag(ARC_TSScalperAlgo_ARCFilterType.ArmState) && ManualTradeMode && !Armed && State == State.Realtime)
				return false;

			// Allowed dir
			if (consideredFilters.HasFlag(ARC_TSScalperAlgo_ARCFilterType.Direction) && AllowedEntryDirections != ARC_TSScalperAlgo_AllowedEntryDirection.LongAndShort && AllowedEntryDirections != (dir == 1 ? ARC_TSScalperAlgo_AllowedEntryDirection.LongOnly : ARC_TSScalperAlgo_AllowedEntryDirection.ShortOnly))
				return false;

			if (!ManualTradeMode)
			{
				if (consideredFilters.HasFlag(ARC_TSScalperAlgo_ARCFilterType.MoneyManagement) && !mmCanTrade)
					return false;

				if (consideredFilters.HasFlag(ARC_TSScalperAlgo_ARCFilterType.ConsecutiveTrades))
				{
					// Prevent opposing signals if ignoring reversals
					if (OnOppositeSignal == ARC_TSScalperAlgo_OppositeSignalAction.None && Position.MarketPosition != MarketPosition.Flat)
						return false;

					if (LimitConsecutiveTradesInDirection && dir == lastTradeDir && consecutiveTradesInCurrentDir >= MaxConsecutiveTradesInDirection)
						return false;

					// Block entries on bars where we've exited
					if (!AllowEntriesOnExitBars && BarsSinceExitExecution(0, "", 0) == 0)
						return false;
				}

				// Time window
				if (consideredFilters.HasFlag(ARC_TSScalperAlgo_ARCFilterType.Time) && !InValidTradingWindow(Times[tickBarsIdx][0]))
					return false;
			}

			if (!consideredFilters.HasFlag(ARC_TSScalperAlgo_ARCFilterType.TaFilters))
				return true;

			// Excursion blocking
			if (BlockLevelEntry != 0)
			{
				var series = BlockLevelEntry switch
				{
					1 => dir == 1 ? indMomo.PriceExcursionUL1 : indMomo.PriceExcursionLL1,
					2 => dir == 1 ? indMomo.PriceExcursionUL2 : indMomo.PriceExcursionLL2,
					3 => dir == 1 ? indMomo.PriceExcursionUL3 : indMomo.PriceExcursionLL3,
					_ => throw new Exception("Invalid Block Level Entry Setting")
				};

				if (indMomo.Histogram[0].ApproxCompare(series[0]) != -dir)
					return false;
			}

			// VM bias / confluence
			if (!OverridesVMBiasAndConfluenceHandling)
			{
				// Momo Color
				if (UseVMBias && (VMBiasType == ARC_TSScalperAlgo_VMAlgo_BiasType.ZeroLine ? indMomo.Histogram : indMomo.StructureBiasState)[0].ApproxCompare(0) != dir)
					return false;

				// Momo Confluence
				if (UseVMConfluence && indMomo.BBMACD[0].ApproxCompare(0) != dir)
					return false;
			}

			// VM EMA Crossover
			if (VMRequireEmaCrossover && indMomo.FastEMA[0].ApproxCompare(indMomo.SlowEMA[0]) == -dir)
				return false;

			// Ma filter
			if (UseHTFMovingAverage && trendFilters.Trend != dir)
				return false;

			// Market structure filter
			if (UseMsFilter)
			{
				if (msFilterZigZag.SwingPoints.Count < 4)
					return false;

				// Select the prices of the last 4 finalized zigzag points
				var lastPoints = msFilterZigZag.SwingPoints
					.Skip(msFilterZigZag.SwingPoints.Count - 4)
					.Take(4)
					.ToArray();

				// Points alternate between high and low, so compare in pairs separated by 1 to ensure directionality
				if (lastPoints[2].Price.ApproxCompare(lastPoints[0].Price) != dir || lastPoints[3].Price.ApproxCompare(lastPoints[1].Price) != dir)
					return false;
			}

			return true;
		}

		private void SyncPnlPlot()
		{
			indPnlChart.OpenPnl = Position.MarketPosition == MarketPosition.Flat ? 0 : Position.GetUnrealizedProfitLoss(PerformanceUnit.Currency, Closes[tickBarsIdx][0]);
			if (Position.MarketPosition == MarketPosition.Flat)
			{
				indPnlChart.SessionClosedPnl = SessionClosedPnl;
				indPnlChart.ChartTotalClosedPnl = ChartClosedPnl;
			}

			var plotIdx = !DashHistoricPnl || State == State.Realtime ? 0 : 1;
			indPnlChart.Values[plotIdx][0] = indPnlChart.ChartTotalClosedPnl + indPnlChart.OpenPnl;
			indPnlChart.PlotBrushes[plotIdx][0] = indPnlChart.Values[plotIdx][0] < 0 ? Brushes.Red : Brushes.Green;
		}

		private void SyncStopPlots()
		{
			var sl = pendingBarPlotSl ?? orderTracker.MinStopLossValue;
			pendingBarPlotSl = null;
			if (sl > double.Epsilon)
				indStopTrg.SetStop(sl);
		}

		private void SyncTargetPlots()
		{
			for (var i = 0; i < orderTracker.Count; i++)
			{
				var order = orderTracker.targetOrders[i];
				if (pendingBarPlotTp[i] == null && (order == null || order.ARC_TSScalperAlgo_IsTerminal()))
					continue;
				
				var tp = pendingBarPlotTp[i] ?? (UseMitTargetOrders ? order.StopPrice : order.LimitPrice);
				pendingBarPlotTp[i] = null;
				indStopTrg.SetTarget(tp, i);
			}
		}

		private void ResetMoneyManagement()
		{
			lastSessionClosedPnl = 0;
			mmMaxGain = 0;
			lastMmReset = Times[tickBarsIdx].Count == 0 ? DateTime.MinValue : Times[tickBarsIdx][0];
			tradeCountAtLastMmReset = SystemPerformance.AllTrades.Count;
			tradeCountAtLastSessionClosedPnlRefresh = tradeCountAtLastMmReset;
			mmCanTrade = true;
			indPnlChart.SessionClosedPnl = 0;
		}

		private void SyncMoneyManagement(double price)
		{
			// Get current session open pnl
			var unRealizedPnl = Position == null || Position.MarketPosition == MarketPosition.Flat ? 0d : Position.GetUnrealizedProfitLoss(PerformanceUnit.Currency, price);
			var sessionOpenPnl = SessionClosedPnl;
			if (HighWaterMarkType == ARC_TSScalperAlgo_HighWaterMarkType.RealizedPlusUnrealized)
				sessionOpenPnl += unRealizedPnl;

			// Track high watermark
			if (HighWaterMarkType != ARC_TSScalperAlgo_HighWaterMarkType.Off) 
				mmMaxGain = Math.Max(mmMaxGain, sessionOpenPnl);

			// If we're already out of trading, do nothing
			if (!mmCanTrade)
				return;

			string messageCore;

			// High watermark
			if (HighWaterMarkType != ARC_TSScalperAlgo_HighWaterMarkType.Off && mmMaxGain.ApproxCompare(HwmActivatedAt) >= 0 && sessionOpenPnl.ApproxCompare(mmMaxGain * (1 - DailyHighWaterMarkPct / 100)) <= 0)
				messageCore = "Higher water mark %";
			// Daily max gain
			else if (DayMaxGain != 0 && (SessionClosedPnl + unRealizedPnl).ApproxCompare(DayMaxGain) >= 0)
				messageCore = "Daily Profit Goal";
			// Daily max loss
			else if (DayMaxLoss != 0 && (SessionClosedPnl + unRealizedPnl).ApproxCompare(-DayMaxLoss) <= 0)
				messageCore = "Max Daily Loss";
			else
				return;

			mmCanTrade = false;
			// In back tests exit the position, in realtime, warn the user that we won't exit the trade for them, and how to do so themselves
			if (State == State.Realtime)
			{
				if (mmAlertShown)
					return;

				mmAlertShown = true;
				const string messageFormat = "Money Management [{0}, {1}, {2}]: {3} has been reached.\nTrading will be halted automatically AFTER the current trade is closed.\nTo close the current trade NOW, click OFF in the UI dropdown menu.";
				var message = string.Format(messageFormat, Name, Instrument.FullName, Account.DisplayName, messageCore);
				Dispatcher.InvokeAsync(() => NTMessageBox.Show(message, "Warning!", MessageBoxButton.OK, MessageBoxImage.Asterisk));
				Log(message, LogLevel.Warning);
			}
			else if (EnableBacktestMmExits && State != State.Realtime)
			{
				ExitPosition(messageCore);
			}
		}

		protected bool InValidTradingWindow(DateTime t)
		{
			if (!enabledDaysOfTheWeek[t.DayOfWeek])
				return false;

			if (SkippedDays.Contains(t.Date))
				return false;

			if (StartTime == 0 && EndTime == 0)
				return true;

			if (IgnoreTradeTime)
				return true;

			if (invalidTimeWindows.Values.Any(tw => tw.Enabled && t.ARC_TSScalperAlgo_InRange(tw.StartTime, tw.EndTime)))
				return false;

			return (t.DayOfWeek != DayOfWeek.Friday || t.ARC_TSScalperAlgo_CompareTime(2500) != 1) && t.ARC_TSScalperAlgo_InRange(StartTime, EndTime);
		}

		public override string ToString()
		{
			return $"{ProductName} {ProductVersion}";
		}

		#region Parameters
		protected const string StrategyParameterGroupName = "Strategy Parameters";
		protected const string StrategyVisualsParameterGroupName = "Strategy Visuals";
		protected const string ProductInfoGroupName = "Product Info";

		[XmlIgnore, Browsable(false)]
		[ARC_TSScalperAlgo_HideOthersIf(ARC_TSScalperAlgo_PropComparisonType.EQ, true, Groups = new[] { TimeControlGroupName, MoneyManagementGroupName, MiscFiltersGroupName }, Properties = new[] { "OnOppositeSignal" })]
		public bool ManualTradeMode => Category == Category.NinjaScript && AutoDisarm;

		/*
		 * NOTE: For bool properties that conditional property depend on, we must use a bool enum property as an intermediate, or it won't work in optimization.
		 */

		#region Entry
		protected const string EntryGroupName = "Entries";

		[NinjaScriptProperty]
		[Display(Name = "Entry Direction", Order = 1, GroupName = EntryGroupName, Description = "Entry Direction")]
		public ARC_TSScalperAlgo_AllowedEntryDirection AllowedEntryDirections { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Sizing Strategy", Order = 2, GroupName = EntryGroupName, Description = "Quantity associated with entry 1")]
		public ARC_TSScalperAlgo_SizingStrategy SizingStrategy { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_TSScalperAlgo_Rename("Quantity 1 (Contracts)", nameof(SizingStrategy), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_SizingStrategy.Static)]
		[ARC_TSScalperAlgo_Rename("Quantity 1 (Risked $)", nameof(SizingStrategy), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_SizingStrategy.FixedCost)]
		[ARC_TSScalperAlgo_Rename("Quantity 1 (% of Account)", nameof(SizingStrategy), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_SizingStrategy.PercentOfBalance)]
		[XmlElement("Target1Quantity")]
		[Display(Name = "Quantity 1", Order = 3, GroupName = EntryGroupName, Description = "Quantity associated with entry 1")]
		public int Entry1Quantity { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_TSScalperAlgo_Rename("Quantity 2 (Contracts)", nameof(SizingStrategy), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_SizingStrategy.Static)]
		[ARC_TSScalperAlgo_Rename("Quantity 2 (Risked $)", nameof(SizingStrategy), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_SizingStrategy.FixedCost)]
		[ARC_TSScalperAlgo_Rename("Quantity 2 (% of Account)", nameof(SizingStrategy), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_SizingStrategy.PercentOfBalance)]
		[XmlElement("Target2Quantity")]
		[Display(Name = "Quantity 2", Order = 4, GroupName = EntryGroupName, Description = "Quantity associated with entry 2")]
		public int Entry2Quantity { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_TSScalperAlgo_Rename("Quantity 3 (Contracts)", nameof(SizingStrategy), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_SizingStrategy.Static)]
		[ARC_TSScalperAlgo_Rename("Quantity 3 (Risked $)", nameof(SizingStrategy), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_SizingStrategy.FixedCost)]
		[ARC_TSScalperAlgo_Rename("Quantity 3 (% of Account)", nameof(SizingStrategy), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_SizingStrategy.PercentOfBalance)]
		[XmlElement("Target3Quantity")]
		[Display(Name = "Quantity 3", Order = 5, GroupName = EntryGroupName, Description = "Quantity associated with entry 3")]
		public int Entry3Quantity { get; set; }

		[Range(0, int.MaxValue)]
		[Display(Name = "Starting Balance", Order = 6, GroupName = EntryGroupName)]
		public int StartingBalance { get; set; }
		
		[Range(0, int.MaxValue)]
		[Display(Name = "Enable Compounding", Order = 7, GroupName = EntryGroupName)]
		public bool EnableCompounding { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Entry Order Type", Order = 8, GroupName = EntryGroupName, Description = "Entry Order Type")]
		public ARC_TSScalperAlgo_EntryOrderType EntryOrderType { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(EntryOrderType), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_EntryOrderType.Limit)]
		[Display(Name = "Entry Offset Ticks", Order = 9, GroupName = EntryGroupName, Description = "Offset ticks for Limit Order")]
		public int LimitEntryOffsetTicks { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(EntryOrderType), ARC_TSScalperAlgo_PropComparisonType.NEQ, ARC_TSScalperAlgo_EntryOrderType.Market)]
		[Display(Name = "Max Pending Order Distance", Order = 10, GroupName = EntryGroupName)]
		public int MaxPendingOrderDistance { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Action On Opposite Signal", Order = 11, GroupName = EntryGroupName)]
		public ARC_TSScalperAlgo_OppositeSignalAction OnOppositeSignal { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(EntryOrderType), ARC_TSScalperAlgo_PropComparisonType.NEQ, ARC_TSScalperAlgo_EntryOrderType.Market)]
		[Display(Name = "Max Pending Order Bars", Order = 12, GroupName = EntryGroupName)]
		public int MaxPendingOrderBars { get; set; }
		
		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Limit Pre-Order Gap Bars", Order = 13, GroupName = EntryGroupName)]
		public ARC_TSScalperAlgo_BoolEnum LimitPreOrderGapBarsEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool LimitPreOrderGapBars
		{
			get => LimitPreOrderGapBarsEnum == ARC_TSScalperAlgo_BoolEnum.True;
			set => LimitPreOrderGapBarsEnum = value ? ARC_TSScalperAlgo_BoolEnum.True : ARC_TSScalperAlgo_BoolEnum.False;
		}

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(LimitPreOrderGapBarsEnum), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_BoolEnum.True)]
		[Display(Name = "Max Pre-Order Gap Bars", Order = 14, GroupName = EntryGroupName)]
		public int MaxPreOrderGapBars { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Allow Entries on Exit Bars", Order = 15, GroupName = EntryGroupName)]
		public bool AllowEntriesOnExitBars { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Auto Disarm", Order = 16, GroupName = EntryGroupName)]
		public bool AutoDisarm { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Run Type", Description = "Set to Backtest when backtesting, RealTime when trading in real-time", Order = 17, GroupName = EntryGroupName)]
		public ARC_TSScalperAlgo_RunType RunType { get; set; }
		#endregion

		#region Stops
		protected const string StopLossGroupName = "Stop Losses";

		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_NonOptimizationCheckBoxEditor")]
		[ARC_TSScalperAlgo_HideUnless(nameof(HasStrategyBasedStops), ARC_TSScalperAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Enable Algo Stop Loss", GroupName = StopLossGroupName, Order = -99)]
		public ARC_TSScalperAlgo_BoolEnum EnableAlgoDefinedStopLossesEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool EnableAlgoDefinedStopLosses
		{
			get => EnableAlgoDefinedStopLossesEnum == ARC_TSScalperAlgo_BoolEnum.True;
			set => EnableAlgoDefinedStopLossesEnum = value ? ARC_TSScalperAlgo_BoolEnum.True : ARC_TSScalperAlgo_BoolEnum.False;
		}

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_BoolEnum.True)]
		[Display(Name = "Min Allowable Stop Loss (Ticks)", GroupName = StopLossGroupName, Order = -98)]
		public int MinAllowableStopLoss { get; set; }
		
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_BoolEnum.True)]
		[Display(Name = "Max Allowable Stop Loss (Ticks)", GroupName = StopLossGroupName, Order = -97)]
		public int MaxAllowableStopLoss { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_TSScalperAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_BoolEnum.False)]
		[Display(Name = "Stop Loss Type", Order = -96, GroupName = StopLossGroupName)]
		public ARC_TSScalperAlgo_StopLossType StopLossType { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_BoolEnum.False)]
		[ARC_TSScalperAlgo_HideUnless(nameof(StopLossType), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_StopLossType.ATR)]
		[Display(Name = "Stop Loss ATR Period", Order = -95, GroupName = StopLossGroupName)]
		public int StopLossATRPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(EnableAlgoDefinedStopLossesEnum), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_BoolEnum.False)]
		[ARC_TSScalperAlgo_Rename("Stop Loss (Ticks)", nameof(StopLossType), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_StopLossType.Ticks)]
		[ARC_TSScalperAlgo_Rename("Stop Loss (ATRs)", nameof(StopLossType), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_StopLossType.ATR)]
		[XmlElement("StopLossTicks")]
		[Display(Name = "Stop Loss", Order = -94, GroupName = StopLossGroupName)]
		public double StopLoss { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "Trail Trigger", Order = -93, GroupName = StopLossGroupName, Description = "Number of ticks to in profit to enable the trail")]
		public int TrailTriggerTicks { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "Trail # Bars Back", Order = -92, GroupName = StopLossGroupName, Description = "Set this to 1 for tight management, greater than 1 for loose management (where the value you place is the number of bars lookback for the high / low price)")]
		public int TrailLookbackBars { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name = "Trail Tick Offset", Order = -91, GroupName = StopLossGroupName, Description = "Offset ticks for trail.")]
		public double TrailTicks { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Range(0, double.MaxValue)]
		[Display(Name = "BreakEven Trigger", Order = -90, GroupName = StopLossGroupName, Description = "Number of ticks in profit to break event")]
		public double BreakEvenTrigger { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(BreakEvenTrigger), ARC_TSScalperAlgo_PropComparisonType.NEQ, 0d)]
		[Display(Name = "BreakEven Plus", Order = -89, GroupName = StopLossGroupName)]
		public double BreakEvenPlus { get; set; }
		#endregion

		#region Targets
		protected const string TargetsGroupName = "Targets";

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Target Type", Order = -100, GroupName = TargetsGroupName)]
		public ARC_TSScalperAlgo_TargetType TargetType { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(TargetType), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TargetType.ATR)]
		[Display(Name = "ATR Period", Order = -99, GroupName = TargetsGroupName)]
		public int TargetATRPeriod { get; set; }

		[NinjaScriptProperty]
		[XmlElement("UseMITsForTargets")]
		[Display(Name = "Use MIT Targets", Order = -98, GroupName = TargetsGroupName)]
		public bool UseMitTargetOrders { get; set; }

		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_NonOptimizationCheckBoxEditor")]
		[ARC_TSScalperAlgo_HideUnless(nameof(HasStrategyBasedTargets), ARC_TSScalperAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Enable Algo Profit Target 1", GroupName = TargetsGroupName, Order = -97)]
		public ARC_TSScalperAlgo_BoolEnum EnableAlgoDefinedTargetsEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool EnableAlgoDefinedTargets
		{
			get => EnableAlgoDefinedTargetsEnum == ARC_TSScalperAlgo_BoolEnum.True;
			set => EnableAlgoDefinedTargetsEnum = value ? ARC_TSScalperAlgo_BoolEnum.True : ARC_TSScalperAlgo_BoolEnum.False;
		}

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(EnableAlgoDefinedTargetsEnum), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_BoolEnum.True)]
		[Display(Name = "Distance to Target Multiple", Order = -96, GroupName = TargetsGroupName)]
		public double DistanceToTargetMultiple { get; set; }

		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(EnableAlgoDefinedTargetsEnum), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_BoolEnum.True)]
		[Display(Name = "Min Allowable Take Profit (Ticks)", GroupName = TargetsGroupName, Order = -95)]
		public int MinAllowableTakeProfit { get; set; }
		
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(EnableAlgoDefinedTargetsEnum), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_BoolEnum.True)]
		[Display(Name = "Max Allowable Take Profit (Ticks)", GroupName = TargetsGroupName, Order = -94)]
		public int MaxAllowableTakeProfit { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(EnableAlgoDefinedTargetsEnum), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_BoolEnum.False)]
		[ARC_TSScalperAlgo_Rename("Profit Target 1 (Ticks)", nameof(TargetType), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TargetType.Ticks)]
		[ARC_TSScalperAlgo_Rename("Profit Target 1 (ATRs)", nameof(TargetType), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TargetType.ATR)]
		[ARC_TSScalperAlgo_Rename("Profit Target 1 (RR)", nameof(TargetType), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TargetType.RR)]
		[Display(Name = "Profit Target 1", Description = "Static St = # Ticks, RR = Multiplier factor", Order = -93, GroupName = TargetsGroupName)]
		[XmlElement("ProfitTargetTicks1")]
		public double ProfitTargetValue1 { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(Entry2Quantity), ARC_TSScalperAlgo_PropComparisonType.GT, 0)]
		[ARC_TSScalperAlgo_Rename("Profit Target 2 (Ticks)", nameof(TargetType), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TargetType.Ticks)]
		[ARC_TSScalperAlgo_Rename("Profit Target 2 (ATRs)", nameof(TargetType), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TargetType.ATR)]
		[ARC_TSScalperAlgo_Rename("Profit Target 2 (RR)", nameof(TargetType), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TargetType.RR)]
		[XmlElement("ProfitTargetTicks2")]
		[Display(Name = "Profit Target 2", Description = "Static St = # Ticks, RR = Multiplier factor", Order = -92, GroupName = TargetsGroupName)]
		public double ProfitTargetValue2 { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(Entry3Quantity), ARC_TSScalperAlgo_PropComparisonType.GT, 0)]
		[ARC_TSScalperAlgo_Rename("Profit Target 3 (Ticks)", nameof(TargetType), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TargetType.Ticks)]
		[ARC_TSScalperAlgo_Rename("Profit Target 3 (ATRs)", nameof(TargetType), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TargetType.ATR)]
		[ARC_TSScalperAlgo_Rename("Profit Target 3 (RR)", nameof(TargetType), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TargetType.RR)]
		[XmlElement("ProfitTargetTicks3")]
		[Display(Name = "Profit Target 3", Description = "Static St = # Ticks, RR = Multiplier factor", Order = -91, GroupName = TargetsGroupName)]
		public double ProfitTargetValue3 { get; set; }
		#endregion

		#region Time Controls
		private const string TimeControlGroupName = "Time Controls";
		private readonly ARC_TSScalperAlgo_DefaultingDictionary<int, ARC_TSScalperAlgo_TimeWindow> invalidTimeWindows = new ARC_TSScalperAlgo_DefaultingDictionary<int, ARC_TSScalperAlgo_TimeWindow>(_ => new ARC_TSScalperAlgo_TimeWindow());
		private readonly ARC_TSScalperAlgo_DefaultingDictionary<DayOfWeek, bool> enabledDaysOfTheWeek = new ARC_TSScalperAlgo_DefaultingDictionary<DayOfWeek, bool>(true);

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "Trade Start Time", Order = 1, GroupName = TimeControlGroupName, Description = "Time in hhmm 24-hour format")]
		public int StartTime { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "Trade End Time", Order = 2, GroupName = TimeControlGroupName, Description = "Time in hhmm 24-hour format")]
		public int EndTime { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Exit At End Time", Order = 3, GroupName = TimeControlGroupName, Description = "Set to true to exit at the end time, false otherwise")]
		public bool ExitAtEndTime { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Ignore Trade Time", Order = 4, GroupName = TimeControlGroupName, Description = "Set true to trade all the time")]
		public bool IgnoreTradeTime { get; set; }
		
		[TypeConverter(typeof(ExpandableObjectConverter))]
		[ARC_TSScalperAlgo_HideUnless(nameof(IgnoreTradeTime), ARC_TSScalperAlgo_PropComparisonType.EQ, false)]
		[Display(Name = "Invalid Trade Window 1", Order = 5, GroupName = TimeControlGroupName)]
		public ARC_TSScalperAlgo_TimeWindow InvalidWindow1 { get => invalidTimeWindows[0]; set => invalidTimeWindows[0] = value; }
		
		[TypeConverter(typeof(ExpandableObjectConverter))]
		[ARC_TSScalperAlgo_HideUnless(nameof(IgnoreTradeTime), ARC_TSScalperAlgo_PropComparisonType.EQ, false)]
		[Display(Name = "Invalid Trade Window 2", Order = 6, GroupName = TimeControlGroupName)]
		public ARC_TSScalperAlgo_TimeWindow InvalidWindow2 { get => invalidTimeWindows[1]; set => invalidTimeWindows[1] = value; }
		
		[TypeConverter(typeof(ExpandableObjectConverter))]
		[ARC_TSScalperAlgo_HideUnless(nameof(IgnoreTradeTime), ARC_TSScalperAlgo_PropComparisonType.EQ, false)]
		[Display(Name = "Invalid Trade Window 3", Order = 7, GroupName = TimeControlGroupName)]
		public ARC_TSScalperAlgo_TimeWindow InvalidWindow3 { get => invalidTimeWindows[2]; set => invalidTimeWindows[2] = value; }

		[NinjaScriptProperty]
		[Display(Name = "Enable Mondays", Order = 8, GroupName = TimeControlGroupName)]
		public bool MondayEnabled { get => enabledDaysOfTheWeek[DayOfWeek.Monday]; set => enabledDaysOfTheWeek[DayOfWeek.Monday] = value; }
		
		[NinjaScriptProperty]
		[Display(Name = "Enable Tuesdays", Order = 9, GroupName = TimeControlGroupName)]
		public bool TuesdayEnabled { get => enabledDaysOfTheWeek[DayOfWeek.Tuesday]; set => enabledDaysOfTheWeek[DayOfWeek.Tuesday] = value; }
		
		[NinjaScriptProperty]
		[Display(Name = "Enable Wednesdays", Order = 10, GroupName = TimeControlGroupName)]
		public bool WednesdayEnabled { get => enabledDaysOfTheWeek[DayOfWeek.Wednesday]; set => enabledDaysOfTheWeek[DayOfWeek.Wednesday] = value; }
		
		[NinjaScriptProperty]
		[Display(Name = "Enable Thursdays", Order = 11, GroupName = TimeControlGroupName)]
		public bool ThursdayEnabled { get => enabledDaysOfTheWeek[DayOfWeek.Thursday]; set => enabledDaysOfTheWeek[DayOfWeek.Thursday] = value; }
		
		[NinjaScriptProperty]
		[Display(Name = "Enable Fridays", Order = 12, GroupName = TimeControlGroupName)]
		public bool FridayEnabled { get => enabledDaysOfTheWeek[DayOfWeek.Friday]; set => enabledDaysOfTheWeek[DayOfWeek.Friday] = value; }

		[NinjaScriptProperty]
		[Display(Name = "Enable Saturdays", Order = 13, GroupName = TimeControlGroupName)]
		public bool SaturdayEnabled { get => enabledDaysOfTheWeek[DayOfWeek.Saturday]; set => enabledDaysOfTheWeek[DayOfWeek.Saturday] = value; }

		[NinjaScriptProperty]
		[Display(Name = "Enable Sundays", Order = 14, GroupName = TimeControlGroupName)]
		public bool SundayEnabled { get => enabledDaysOfTheWeek[DayOfWeek.Sunday]; set => enabledDaysOfTheWeek[DayOfWeek.Sunday] = value; }

		[XmlIgnore]
		[Display(Name = "Skipped Days", Order = 15, GroupName = TimeControlGroupName)]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_DateListEditor")]
		public List<DateTime> SkippedDays { get; set; } = new List<DateTime>();

		[Browsable(false)]
		public string SkippedDaysSerializable
		{
			get => string.Join("|", SkippedDays.Select(dt => dt.ToString("yyyy-M-d"))); 
			set 
			{
				SkippedDays = new List<DateTime>();
				if (string.IsNullOrWhiteSpace(value))
					return;

				foreach (var skippedDay in value.Split('|'))
				{
					if (!DateTime.TryParseExact(skippedDay, "yyyy-M-d", CultureInfo.CurrentCulture, DateTimeStyles.AllowWhiteSpaces, out var dt))
					{
						SkippedDays = new List<DateTime>();
						return;
					}

					SkippedDays.Add(dt);
				}
			}
		}
		#endregion

		#region Money Management
		private const string MoneyManagementGroupName = "Money Management";
		
		[NinjaScriptProperty]
		[Display(Name = "Reset Pnl On Time Slot", Order = 1, GroupName = MoneyManagementGroupName, Description = "Restart Pnl Calculation at each time slot")]
		public bool RestartPnlOnSession { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "DayMaxGoal $", Order = 2, GroupName = MoneyManagementGroupName, Description = "Day Gain when achieved stop trading. 0 to disable")]
		public int DayMaxGain { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "DayMaxLoss $", Order = 3, GroupName = MoneyManagementGroupName, Description = "Day Loss when achieved stop trading. 0 to disable")]
		public int DayMaxLoss { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "High Water Mark", Order = 4, GroupName = MoneyManagementGroupName, Description = "Day High Water Mark")]
		public ARC_TSScalperAlgo_HighWaterMarkType HighWaterMarkType { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(HighWaterMarkType), ARC_TSScalperAlgo_PropComparisonType.NEQ, ARC_TSScalperAlgo_HighWaterMarkType.Off)]
		[Display(Name = "High Water Mark %", Order = 5, GroupName = MoneyManagementGroupName, Description = "Day High Water Mark % DrawDown. 0 to disable")]
		public double DailyHighWaterMarkPct { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(HighWaterMarkType), ARC_TSScalperAlgo_PropComparisonType.NEQ, ARC_TSScalperAlgo_HighWaterMarkType.Off)]
		[Display(Name = "HWM Activated at $", Order = 6, GroupName = MoneyManagementGroupName, Description = "Min profit in dollars for the High Water Mark to activate")]
		public int HwmActivatedAt { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Enable Backtest MM Exits", Order = 7, GroupName = MoneyManagementGroupName)]
		public bool EnableBacktestMmExits { get; set; }
		#endregion

		#region Misc. Filters
		private const string MiscFiltersGroupName = "Misc. Filters";

		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Limit Consecutive Trades in Direction", Order = 0, GroupName = MiscFiltersGroupName)]
		public ARC_TSScalperAlgo_BoolEnum LimitConsecutiveTradesInDirectionEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool LimitConsecutiveTradesInDirection
		{
			get => LimitConsecutiveTradesInDirectionEnum == ARC_TSScalperAlgo_BoolEnum.True;
			set => LimitConsecutiveTradesInDirectionEnum = value ? ARC_TSScalperAlgo_BoolEnum.True : ARC_TSScalperAlgo_BoolEnum.False;
		}

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(LimitConsecutiveTradesInDirectionEnum), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_BoolEnum.True)]
		[Display(Name = "Max Consecutive Trades in Direction", Order = 1, GroupName = MiscFiltersGroupName)]
		public int MaxConsecutiveTradesInDirection { get; set; }
		
		[NinjaScriptProperty]
		[ARC_TSScalperAlgo_HideUnless(nameof(LimitConsecutiveTradesInDirectionEnum), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_BoolEnum.True)]
		[Display(Name = "Reset Consecutive Trade Count on Session Close", Order = 2, GroupName = MiscFiltersGroupName)]
		public bool ResetConsecutiveTradeCountOnSessionClose { get; set; }
		#endregion

		#region HTF Moving Averages
		private const string HTFMovingAveragesGroupName = "Moving Averages Filter";

		[RefreshProperties(RefreshProperties.All)]
		[ARC_TSScalperAlgo_ShowOthersIf(ARC_TSScalperAlgo_PropComparisonType.EQ, true, Properties = new[] { "MAType", "MABasis", "MATimeframe", "MAPeriod", "MAPeriod2", "FilterMAStepSize", "FilterMAStepSize2", "MACount" })]
		[Display(Name = "Show", Order = 0, GroupName = HTFMovingAveragesGroupName, Description = "Whether the strategy shows the moving average")]
		public bool ShowMA { get; set; }

		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_TSScalperAlgo_ShowOthersIf(ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_BoolEnum.True, Properties = new[] { "MAType", "MABasis", "MATimeframe", "MAPeriod", "MAPeriod2", "FilterMAStepSize", "FilterMAStepSize2", "MACount" })]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Require", Order = 1, GroupName = HTFMovingAveragesGroupName)]
		public ARC_TSScalperAlgo_BoolEnum UseHTFMovingAverageEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool UseHTFMovingAverage
		{
			get => UseHTFMovingAverageEnum == ARC_TSScalperAlgo_BoolEnum.True;
			set => UseHTFMovingAverageEnum = value ? ARC_TSScalperAlgo_BoolEnum.True : ARC_TSScalperAlgo_BoolEnum.False;
		}

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_TSScalperAlgo_HideByDefault]
		[Display(Name = "MA Count", Order = 2, GroupName = HTFMovingAveragesGroupName)]
		public ARC_TSScalperAlgo_TrendFiltersMaCount MACount { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_TSScalperAlgo_HideByDefault]
		[Display(Name = "Type", Order = 3, GroupName = HTFMovingAveragesGroupName, Description = "Moving average type")]
		public ARC_TSScalperAlgo_MovingAverageType MAType { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_TSScalperAlgo_HideByDefault]
		[Display(Name = "Basis", Order = 4, GroupName = HTFMovingAveragesGroupName)]
		public ARC_TSScalperAlgo_TrendFiltersMaBasis MABasis { get; set; }

		[Range(1, int.MaxValue)]
		[ARC_TSScalperAlgo_HideByDefault]
		[ARC_TSScalperAlgo_HideUnless(nameof(MABasis), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TrendFiltersMaBasis.Minutes)]
		[ARC_TSScalperAlgo_HideUnless(nameof(MAType), ARC_TSScalperAlgo_PropComparisonType.NEQ, ARC_TSScalperAlgo_MovingAverageType.StepMA)]
		[Display(Name = "Timeframe Minutes", Order = 5, GroupName = HTFMovingAveragesGroupName, Description = "Timeframe to calculate moving average on in minutes")]
		public int MATimeframe { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_TSScalperAlgo_HideByDefault]
		[ARC_TSScalperAlgo_HideUnless(nameof(MAType), ARC_TSScalperAlgo_PropComparisonType.NEQ, ARC_TSScalperAlgo_MovingAverageType.StepMA)]
		[ARC_TSScalperAlgo_Rename("Period", nameof(MACount), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TrendFiltersMaCount.Single)]
		[ARC_TSScalperAlgo_Rename("Period 1", nameof(MACount), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TrendFiltersMaCount.Double)]
		[Display(Name = "Period", Order = 6, GroupName = HTFMovingAveragesGroupName, Description = "Period of the filter moving average")]
		public int MAPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_TSScalperAlgo_HideByDefault]
		[ARC_TSScalperAlgo_HideUnless(nameof(MAType), ARC_TSScalperAlgo_PropComparisonType.NEQ, ARC_TSScalperAlgo_MovingAverageType.StepMA)]
		[ARC_TSScalperAlgo_HideUnless(nameof(MACount), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TrendFiltersMaCount.Double)]
		[Display(Name = "Period 2", Order = 7, GroupName = HTFMovingAveragesGroupName, Description = "Period of the filter moving average")]
		public int MAPeriod2 { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_TSScalperAlgo_HideByDefault]
		[ARC_TSScalperAlgo_HideUnless(nameof(MAType), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_MovingAverageType.StepMA)]
		[ARC_TSScalperAlgo_Rename("Step Size", nameof(MACount), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TrendFiltersMaCount.Single)]
		[ARC_TSScalperAlgo_Rename("Step Size 1", nameof(MACount), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TrendFiltersMaCount.Double)]
		[Display(Name = "Step Size", Order = 8, GroupName = HTFMovingAveragesGroupName, Description = "Step size of the filter moving average")]
		public int FilterMAStepSize { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_TSScalperAlgo_HideByDefault]
		[ARC_TSScalperAlgo_HideUnless(nameof(MAType), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_MovingAverageType.StepMA)]
		[ARC_TSScalperAlgo_HideUnless(nameof(MACount), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TrendFiltersMaCount.Double)]
		[Display(Name = "Step Size 2", Order = 9, GroupName = HTFMovingAveragesGroupName, Description = "Step size of the filter moving average")]
		public int FilterMAStepSize2 { get; set; }

		[NinjaScriptProperty]
		[ARC_TSScalperAlgo_HideUnless(nameof(UseHTFMovingAverageEnum), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_BoolEnum.True)]
		[ARC_TSScalperAlgo_HideUnless(nameof(MAType), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_MovingAverageType.StepMA)]
		[ARC_TSScalperAlgo_HideUnless(nameof(MACount), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TrendFiltersMaCount.Single)]
		[Display(Name = "Step Method", Order = 10, GroupName = HTFMovingAveragesGroupName, Description = "The method step MA will use to determine direction")]
		public ARC_TSScalperAlgo_StepMaTrendType FilterMATrendType { get; set; }

		[NinjaScriptProperty]
		[Range(0, 100)]
		[ARC_TSScalperAlgo_HideUnless(nameof(UseHTFMovingAverageEnum), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_BoolEnum.True)]
		[Display(Name = "Bar % HTF MA", Order = 11, GroupName = HTFMovingAveragesGroupName, Description = "The minimum percentage of the bar that must be on the right side of the MA.")]
		public double MABarBiasPercentRequirement { get; set; }

		[XmlIgnore]
		[ARC_TSScalperAlgo_HideUnless(nameof(ShowMA), ARC_TSScalperAlgo_PropComparisonType.EQ, true)]
		[ARC_TSScalperAlgo_Rename("Color", nameof(MACount), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TrendFiltersMaCount.Single)]
		[ARC_TSScalperAlgo_Rename("Color 1", nameof(MACount), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TrendFiltersMaCount.Double)]
		[Display(Name = "Color", Order = 12, GroupName = HTFMovingAveragesGroupName)]
		public Brush MAColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string MAColorSerializable
		{
			get => Serialize.BrushToString(MAColor);
			set => MAColor = Serialize.StringToBrush(value);
		}
		
		[XmlIgnore]
		[ARC_TSScalperAlgo_HideUnless(nameof(ShowMA), ARC_TSScalperAlgo_PropComparisonType.EQ, true)]
		[ARC_TSScalperAlgo_HideUnless(nameof(MACount), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_TrendFiltersMaCount.Double)]
		[Display(Name = "Color 2", Order = 13, GroupName = HTFMovingAveragesGroupName)]
		public Brush MAColor2 { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string MAColor2Serializable
		{
			get => Serialize.BrushToString(MAColor2);
			set => MAColor2 = Serialize.StringToBrush(value);
		}
		#endregion

		#region Market Structure Filter
		protected const string MarketStructureFilterGroupName = "Market Structure Filter";
		
		[RefreshProperties(RefreshProperties.All)]
		[ARC_TSScalperAlgo_ShowOthersIf(ARC_TSScalperAlgo_PropComparisonType.EQ, true, Properties = new[] { "MsFilterSwingStrength", "MsFilterNeutralColor", "MsFilterUptrendColor", "MsFilterDowntrendColor" })]
		[Display(Name = "Show Zig Zag", Order = 0, GroupName = MarketStructureFilterGroupName, Description = "Whether the strategy shows the zigzag")]
		public bool ShowMsFilterZigZag { get; set; }
		
		[RefreshProperties(RefreshProperties.All)]
		[ARC_TSScalperAlgo_ShowOthersIf(ARC_TSScalperAlgo_PropComparisonType.EQ, true, Properties = new[] { "MsFilterSwingStrength", "MsFilterNeutralColor", "MsFilterUptrendColor", "MsFilterDowntrendColor" })]
		[Display(Name = "Show Bias Strip", Order = 1, GroupName = MarketStructureFilterGroupName, Description = "Whether the strategy shows bias strip at the bottom of the main panel")]
		public bool ShowMsFilterBiasStrip { get; set; }
		
		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_TSScalperAlgo_ShowOthersIf(ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_BoolEnum.True, Properties = new[] { "MsFilterSwingStrength" })]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Require", Order = 2, GroupName = MarketStructureFilterGroupName)]
		public ARC_TSScalperAlgo_BoolEnum UseMsFilterEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool UseMsFilter
		{
			get => UseMsFilterEnum == ARC_TSScalperAlgo_BoolEnum.True;
			set => UseMsFilterEnum = value ? ARC_TSScalperAlgo_BoolEnum.True : ARC_TSScalperAlgo_BoolEnum.False;
		}
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_TSScalperAlgo_HideByDefault]
		[Display(Order = 3, Name = "Swing Strength", GroupName = MarketStructureFilterGroupName, Description = "Number of bars used to identify a swing high or low")]
		public int MsFilterSwingStrength { get; set; }
		
		[NinjaScriptProperty]
		[Display(Order = 4, Name = "Include Wicks", GroupName = MarketStructureFilterGroupName, Description = "Whether or not to use wicks (vs closes) for pivot points")]
		public bool MsFilterIncludeWicks { get; set; }
		
		[XmlIgnore]
		[ARC_TSScalperAlgo_HideByDefault]
		[Display(Name = "Neutral Zig Zag Color", Order = 5, GroupName = MarketStructureFilterGroupName)]
		public Brush MsFilterNeutralColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string MsFilterNeutralColorSerializable
		{
			get => Serialize.BrushToString(MsFilterNeutralColor);
			set => MsFilterNeutralColor = Serialize.StringToBrush(value);
		}
		
		[XmlIgnore]
		[ARC_TSScalperAlgo_HideByDefault]
		[Display(Name = "Uptrend Color", Order = 6, GroupName = MarketStructureFilterGroupName)]
		public Brush MsFilterUptrendColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string MsFilterUptrendColorSerializable
		{
			get => Serialize.BrushToString(MsFilterUptrendColor);
			set => MsFilterUptrendColor = Serialize.StringToBrush(value);
		}
		
		[XmlIgnore]
		[ARC_TSScalperAlgo_HideByDefault]
		[Display(Name = "Downtrend Color", Order = 7, GroupName = MarketStructureFilterGroupName)]
		public Brush MsFilterDowntrendColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string MsFilterDowntrendColorSerializable
		{
			get => Serialize.BrushToString(MsFilterDowntrendColor);
			set => MsFilterDowntrendColor = Serialize.StringToBrush(value);
		}
		
		[NinjaScriptProperty]
		[Range(1e-5f, float.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(ShowMsFilterZigZag), ARC_TSScalperAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Zig Zag Thickness", Order = 8, GroupName = MarketStructureFilterGroupName)]
		public float MsFilterZigZagThickness { get; set; }
		
		[NinjaScriptProperty]
		[Range(1e-5f, float.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(ShowMsFilterBiasStrip), ARC_TSScalperAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Bias Strip Thickness", Order = 9, GroupName = MarketStructureFilterGroupName)]
		public float MsFilterBiasStripThickness { get; set; }
		#endregion

		#region VM Parameters
		protected const string VMLeanGroupName = "VM Lean";
		
		[RefreshProperties(RefreshProperties.All)]
		[ARC_TSScalperAlgo_HideOthersIf(ARC_TSScalperAlgo_PropComparisonType.EQ, false, Groups = new []{ VMLeanPlotsGroupName })]
		[Display(Name = "Show VM Sub Panel", Order = 0, GroupName = VMLeanGroupName)]
		public bool ShowVMAlgo { get; set; }

		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Require VM Histo Bias", Order = 1, GroupName = VMLeanGroupName)]
		public ARC_TSScalperAlgo_BoolEnum UseVMBiasEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool UseVMBias
		{
			get => UseVMBiasEnum == ARC_TSScalperAlgo_BoolEnum.True;
			set => UseVMBiasEnum = value ? ARC_TSScalperAlgo_BoolEnum.True : ARC_TSScalperAlgo_BoolEnum.False;
		}
		
		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TSScalperAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Require VM BB Bias", Order = 2, GroupName = VMLeanGroupName)]
		public ARC_TSScalperAlgo_BoolEnum UseVMConfluenceEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool UseVMConfluence
		{
			get => UseVMConfluenceEnum == ARC_TSScalperAlgo_BoolEnum.True;
			set => UseVMConfluenceEnum = value ? ARC_TSScalperAlgo_BoolEnum.True : ARC_TSScalperAlgo_BoolEnum.False;
		}

		[NinjaScriptProperty]
		[Range(0, 3)]
		[Display(Name = "Enable Block Level", Order = 3, GroupName = VMLeanGroupName, Description = "0 to disable, this is the level at which to block if the histogram level is above / below")]
		public int BlockLevelEntry { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "VM Bias Type", Order = 4, GroupName = VMLeanGroupName)]
		public ARC_TSScalperAlgo_VMAlgo_BiasType VMBiasType { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "VM Histogram Background", Order = 5, GroupName = VMLeanGroupName)]
		public bool VMHistogramBackground { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Period Bollinger Band", Order = 6, GroupName = VMLeanGroupName, Description = "Band Period for Bollinger Band")]
		public int BandPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Lookback fast EMA", Order = 7, GroupName = VMLeanGroupName, Description = "Period for fast EMA")]
		public int Fast { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Lookback slow EMA", Order = 8, GroupName = VMLeanGroupName, Description = "Period for slow EMA")]
		public int Slow { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name = "Std. dev. multiplier", Order = 9, GroupName = VMLeanGroupName, Description = "Number of standard deviations")]
		public double StdDevNumber { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Swing strength", Order = 10, GroupName = VMLeanGroupName, Description = "Number of bars used to identify a swing high or low")]
		public int VMSwingStrength { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name = "Deviation multiplier", Order = 11, GroupName = VMLeanGroupName, Description = "Multiplier used to calculate minimum deviation as an ATR multiple")]
		public double MinDeviationMultiplier { get; set; }
		
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Show Histo EMA Crossover", GroupName = VMLeanGroupName, Order = 12)]
		public bool VMShowEmaCrossover { get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(VMShowEmaCrossover), ARC_TSScalperAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Fast Period", GroupName = VMLeanGroupName, Order = 13)]
		public int VMFastEmaPeriod { get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_TSScalperAlgo_HideUnless(nameof(VMShowEmaCrossover), ARC_TSScalperAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Slow Period", GroupName = VMLeanGroupName, Order = 14)]
		public int VMSlowEmaPeriod { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Require Histo EMA Crossover", GroupName = VMLeanGroupName, Order = 15)]
		public bool VMRequireEmaCrossover { get; set; }
		#endregion

		#region VM Plot Colors
		private const string VMLeanPlotsGroupName = "VM Lean Visuals";

		[XmlIgnore]
		[Display(Name = "Rising dots above channel", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 0)]
		public Brush DotsUpRisingColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DotsUpRisingColorSerialize
		{
			get => Serialize.BrushToString(DotsUpRisingColor);
			set => DotsUpRisingColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Rising dots inside/below channel ", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 1)]
		public Brush DotsDownRisingColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DotsDownRisingColorSerialize
		{
			get => Serialize.BrushToString(DotsDownRisingColor);
			set => DotsDownRisingColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Falling dots below channel ", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 2)]
		public Brush DotsDownFallingColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DotsDownFallingColorSerialize
		{
			get => Serialize.BrushToString(DotsDownFallingColor);
			set => DotsDownFallingColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Falling dots inside/above channel ", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 3)]
		public Brush DotsUpFallingColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DotsUpFallingColorSerialize
		{
			get => Serialize.BrushToString(DotsUpFallingColor);
			set => DotsUpFallingColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Dots rim", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 4)]
		public Brush DotsRimColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DotsRimColorSerialize
		{
			get => Serialize.BrushToString(DotsRimColor);
			set => DotsRimColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Bollinger average", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 5)]
		public Brush BBAverageColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string BBAverageColorSerialize
		{
			get => Serialize.BrushToString(BBAverageColor);
			set => BBAverageColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Bollinger upper band", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 6)]
		public Brush BBUpperColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string BBUpperColorSerialize
		{
			get => Serialize.BrushToString(BBUpperColor);
			set => BBUpperColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Bollinger lower band", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 7)]
		public Brush BBLowerColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string BBLowerColorSerialize
		{
			get => Serialize.BrushToString(BBLowerColor);
			set => BBLowerColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Momo Histogram Hi Color", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 8)]
		public Brush HistUpColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string HistUpColorSerialize
		{
			get => Serialize.BrushToString(HistUpColor);
			set => HistUpColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Momo Histogram Down Color", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 9)]
		public Brush HistDownColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string HistDownColorSerialize
		{
			get => Serialize.BrushToString(HistDownColor);
			set => HistDownColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Zeroline", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 10)]
		public Brush ZeroLineColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ZeroLineColorSerialize
		{
			get => Serialize.BrushToString(ZeroLineColor);
			set => ZeroLineColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Connector", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 11)]
		public Brush ConnectorColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ConnectorColorSerialize
		{
			get => Serialize.BrushToString(ConnectorColor);
			set => ConnectorColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Channel shading", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 12)]
		public Brush ChannelColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ChannelColorSerialize
		{
			get => Serialize.BrushToString(ChannelColor);
			set => ChannelColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Deep Bearish background flooding", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 13)]
		public Brush DeepBearishBackgroundColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DeepBearishBackgroundColorSerialize
		{
			get => Serialize.BrushToString(DeepBearishBackgroundColor);
			set => DeepBearishBackgroundColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Bearish background flooding", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 14)]
		public Brush BearishBackgroundColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string BearishBackgroundColorSerialize
		{
			get => Serialize.BrushToString(BearishBackgroundColor);
			set => BearishBackgroundColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Opposite background flooding", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 15)]
		public Brush OppositeBackgroundColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string OppositeBackgroundColorSerialize
		{
			get => Serialize.BrushToString(OppositeBackgroundColor);
			set => OppositeBackgroundColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Bullish background flooding", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 16)]
		public Brush BullishBackgroundColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string BullishBackgroundColorSerialize
		{
			get => Serialize.BrushToString(BullishBackgroundColor);
			set => BullishBackgroundColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Deep Bullish background flooding", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 17)]
		public Brush DeepBullishBackgroundColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DeepBullishBackgroundColorSerialize
		{
			get => Serialize.BrushToString(DeepBullishBackgroundColor);
			set => DeepBullishBackgroundColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Excursion Level 1 Color", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 18)]
		public Brush ExcursionLevel1Color { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ExcursionLevel1ColorSerialize
		{
			get => Serialize.BrushToString(ExcursionLevel1Color);
			set => ExcursionLevel1Color = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Excursion Level 2 Color", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 19)]
		public Brush ExcursionLevel2Color { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ExcursionLevel2ColorSerialize
		{
			get => Serialize.BrushToString(ExcursionLevel2Color);
			set => ExcursionLevel2Color = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Excursion Level 3 Color", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 20)]
		public Brush ExcursionLevel3Color { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ExcursionLevel3ColorSerialize
		{
			get => Serialize.BrushToString(ExcursionLevel3Color);
			set => ExcursionLevel3Color = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[ARC_TSScalperAlgo_HideUnless(nameof(VMShowEmaCrossover), ARC_TSScalperAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Fast EMA Color", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 21)]
		public Brush VMFastEmaColor { get; set; }
		[Browsable(false)]
		public string VMFastEmaColorSerialize
		{
			get => Serialize.BrushToString(VMFastEmaColor);
			set => VMFastEmaColor = Serialize.StringToBrush(value);
		}
		
		[XmlIgnore]
		[ARC_TSScalperAlgo_HideUnless(nameof(VMShowEmaCrossover), ARC_TSScalperAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Slow EMA Color", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 22)]
		public Brush VMSlowEmaColor { get; set; }
		[Browsable(false)]
		public string VMSlowEmaColorSerialize
		{
			get => Serialize.BrushToString(VMSlowEmaColor);
			set => VMSlowEmaColor = Serialize.StringToBrush(value);
		}
		#endregion

		#region Visuals
		protected const string VisualsGroupName = "Misc. Visuals";

		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Show Stripes", Order = 0, GroupName = VisualsGroupName)]
		public bool ShowRacingStripes { get; set; }

		[XmlIgnore]
		[ARC_TSScalperAlgo_HideUnless(nameof(ShowRacingStripes), ARC_TSScalperAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Long Stripe Signal Color", Order = 1, GroupName = VisualsGroupName)]
		public Brush LongStripColor { get; set; }

		[ARC_TSScalperAlgo_HideUnless(nameof(ShowRacingStripes), ARC_TSScalperAlgo_PropComparisonType.EQ, true)]
		[Range(0, int.MaxValue)]
		[Display(Name = "Long Strip Opacity", Order = 2, GroupName = VisualsGroupName)]
		public int LongStripOpacity { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string LongStripColorSerializable
		{
			get => Serialize.BrushToString(LongStripColor);
			set => LongStripColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[ARC_TSScalperAlgo_HideUnless(nameof(ShowRacingStripes), ARC_TSScalperAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Short Stripe Signal Color", Order = 3, GroupName = VisualsGroupName)]
		public Brush ShortStripColor { get; set; }

		[ARC_TSScalperAlgo_HideUnless(nameof(ShowRacingStripes), ARC_TSScalperAlgo_PropComparisonType.EQ, true)]
		[Range(0, int.MaxValue)]
		[Display(Name = "Short Strip Opacity", Order = 4, GroupName = VisualsGroupName)]
		public int ShortStripOpacity { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ShortStripColorSerializable
		{
			get => Serialize.BrushToString(ShortStripColor);
			set => ShortStripColor = Serialize.StringToBrush(value);
		}

		[Display(Name = "Button Text", Order = 101, GroupName = VisualsGroupName)]
		public string ButtonText { get; set; }

		[XmlIgnore]
		[Display(Name = "Stop Dot Color", Order = 102, GroupName = VisualsGroupName)]
		public Brush StopDotColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string StopDotColorSerializable
		{
			get => Serialize.BrushToString(StopDotColor);
			set => StopDotColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Target Dot Color", Order = 103, GroupName = VisualsGroupName)]
		public Brush TargetDotColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string TargetDotColorSerializable
		{
			get => Serialize.BrushToString(TargetDotColor);
			set => TargetDotColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Chart PnL Text Color", Order = 104, GroupName = VisualsGroupName)]
		public Brush ChartPnLTextColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ChartPnLTextColorSerializable
		{
			get => Serialize.BrushToString(ChartPnLTextColor);
			set => ChartPnLTextColor = Serialize.StringToBrush(value);
		}

		[Display(Name = "Dash Historical PNL", Order = 105, GroupName = VisualsGroupName)]
		public bool DashHistoricPnl { get; set; }

		[XmlIgnore]
		[Display(Name = "Missed Order Color (Unfilled)", Order = 106, GroupName = VisualsGroupName)]
		public Brush UnfilledOrderColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string UnfilledOrderColorSerializable
		{
			get => Serialize.BrushToString(UnfilledOrderColor);
			set => UnfilledOrderColor = Serialize.StringToBrush(value);
		}

		[XmlIgnore]
		[Display(Name = "Missed Order Color (Gap Bar)", Order = 107, GroupName = VisualsGroupName)]
		public Brush GapBarOrderColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string GapBarOrderColorSerializable
		{
			get => Serialize.BrushToString(GapBarOrderColor);
			set => GapBarOrderColor = Serialize.StringToBrush(value);
		}

		[NinjaScriptProperty]
		[ARC_TSScalperAlgo_HideUnless(nameof(RunType), ARC_TSScalperAlgo_PropComparisonType.EQ, ARC_TSScalperAlgo_RunType.BackTest)]
		[Display(Name = "Show Backtest Mode Warning", Order = 108, GroupName = VisualsGroupName)]
		public bool ShowBacktestModeWarning { get; set; }
		#endregion
		#endregion
	}
}