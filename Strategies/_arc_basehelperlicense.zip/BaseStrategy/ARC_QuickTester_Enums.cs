using System;

public enum ARC_QuickTester_RunType
{
	BackTest,
	RealTime,
	Combined
}

public enum ARC_QuickTester_NsOrderType
{
	Market,
	LimitFixed,
	StopFixed,
	StopLimit
}

public enum ARC_QuickTester_HighWaterMarkType
{
	Off,
	Realized,
	RealizedPlusUnrealized
}

public enum ARC_QuickTester_TargetType
{
	Ticks,
	RR,
	ATR
}

public enum ARC_QuickTester_BidAsk { Bid, Ask }

[Flags]
public enum ARC_QuickTester_BidAskFlags { Bid = 1, Ask = 2 }

public enum ARC_QuickTester_StopLossType
{
	Ticks,
	ATR
}

public enum ARC_QuickTester_EntryOrderType
{
	Market,
	Limit
}

public enum ARC_QuickTester_AllowedEntryDirection
{
	LongAndShort,
	LongOnly,
	ShortOnly,
	None
}

public enum ARC_QuickTester_OppositeSignalAction
{
	None,
	ExitOnly,
	Reverse
}

public enum ARC_QuickTester_ImbalanceCalculationMode
{
	Diagonally,
	Horizontally
}

public enum ARC_QuickTester_BidAskVolumeCalculationMode
{
	UpTickDownTick,
	TrueBidAsk
}

public enum ARC_QuickTester_ImbalanceCalculationMethod
{
	AnalyticaChart3,
	Ratio
}

public enum ARC_QuickTester_BoolEnum
{
	True,
	False
}

public enum ARC_QuickTester_MovingAverageType { EMA, SMA, StepMA }

public enum ARC_QuickTester_StepMaTrendType { Level, Trend }

public enum ARC_QuickTester_DayWeekMonth { Day, Week, Month }