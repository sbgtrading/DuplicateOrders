using NinjaTrader.Cbi;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	internal static class ARC_CloseFlipAlgo_OrderExtensions
	{
		internal static bool ARC_CloseFlipAlgo_IsTerminal(this Order order, bool treatPendingCancellationAsTerminal = true, bool treatGuaranteedExecutionAsTerminal = true)
		{
			if (treatPendingCancellationAsTerminal && (order.OrderState == OrderState.CancelSubmitted || order.OrderState == OrderState.CancelPending))
				return true;
			
			if (treatGuaranteedExecutionAsTerminal && order.OrderState == OrderState.Accepted && (order.OrderType == OrderType.Market || order.OrderType == OrderType.MIT))
				return true;

			return Order.IsTerminalState(order.OrderState);
		}

		/// <summary>
		/// Return the direction of the order (buy = 1, sell = -1)
		/// </summary>
		/// <param name="order"></param>
		/// <returns></returns>
		internal static int ARC_CloseFlipAlgo_Direction(this Order order)
		{
			return order.OrderAction == OrderAction.BuyToCover || order.OrderAction == OrderAction.Buy ? 1 : -1;
		}
	}
}