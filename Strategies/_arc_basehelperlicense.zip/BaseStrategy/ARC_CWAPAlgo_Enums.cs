using System;

public enum ARC_CWAPAlgo_RunType { BackTest, RealTime, Combined }

public enum ARC_CWAPAlgo_HighWaterMarkType { Off, Realized, RealizedPlusUnrealized }

public enum ARC_CWAPAlgo_TargetType { Ticks, RR, ATR }

public enum ARC_CWAPAlgo_BidAsk { Bid, Ask }

[Flags]
public enum ARC_CWAPAlgo_BidAskFlags { Bid = 1, Ask = 2 }

public enum ARC_CWAPAlgo_StopLossType { Ticks, ATR }

public enum ARC_CWAPAlgo_AtrOrTicks { Ticks, ATR }

public enum ARC_CWAPAlgo_SizingStrategy { Static, FixedCost, PercentOfBalance }

public enum ARC_CWAPAlgo_EntryOrderType { Market, Limit }

public enum ARC_CWAPAlgo_AllowedEntryDirection { LongAndShort, LongOnly, ShortOnly, None }

public enum ARC_CWAPAlgo_OppositeSignalAction { None, ExitOnly, Reverse }

public enum ARC_CWAPAlgo_ImbalanceCalculationMode { Diagonally, Horizontally }

public enum ARC_CWAPAlgo_BidAskVolumeCalculationMode { UpTickDownTick, TrueBidAsk }

public enum ARC_CWAPAlgo_BoolEnum { True, False }

public enum ARC_CWAPAlgo_MovingAverageType { EMA, SMA, StepMA }

public enum ARC_CWAPAlgo_StepMaTrendType { Level, Trend }

public enum ARC_CWAPAlgo_DayWeekMonth { Day, Week, Month }

public enum ARC_CWAPAlgo_SingleBarPattern
{
	Inside = 1, 
	Directional = 2,
	Outside = 3
}

[Flags]
public enum ARC_CWAPAlgo_ARCFilterType
{
	TaFilters = 1,
	MoneyManagement = 2,
	Time = 4,
	Direction = 8,
	ConsecutiveTrades = 16,
	ArmState = 32,
	SameBar = 64,
	AllExceptArmState = TaFilters | MoneyManagement | Time | Direction | ConsecutiveTrades | SameBar,
	All = AllExceptArmState | ArmState
}