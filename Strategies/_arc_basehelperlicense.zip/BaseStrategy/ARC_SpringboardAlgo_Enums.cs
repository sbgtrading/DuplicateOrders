using System;

public enum ARC_SpringboardAlgo_RunType { BackTest, RealTime, Combined }

public enum ARC_SpringboardAlgo_HighWaterMarkType { Off, Realized, RealizedPlusUnrealized }

public enum ARC_SpringboardAlgo_TargetType { Ticks, RR, ATR }

public enum ARC_SpringboardAlgo_BidAsk { Bid, Ask }

[Flags]
public enum ARC_SpringboardAlgo_BidAskFlags { Bid = 1, Ask = 2 }

public enum ARC_SpringboardAlgo_StopLossType { Ticks, ATR }

public enum ARC_SpringboardAlgo_AtrOrTicks { Ticks, ATR }

public enum ARC_SpringboardAlgo_SizingStrategy { Static, FixedCost, PercentOfBalance }

public enum ARC_SpringboardAlgo_EntryOrderType { Market, Limit }

public enum ARC_SpringboardAlgo_AllowedEntryDirection { LongAndShort, LongOnly, ShortOnly, None }

public enum ARC_SpringboardAlgo_OppositeSignalAction { None, ExitOnly, Reverse }

public enum ARC_SpringboardAlgo_ImbalanceCalculationMode { Diagonally, Horizontally }

public enum ARC_SpringboardAlgo_BidAskVolumeCalculationMode { UpTickDownTick, TrueBidAsk }

public enum ARC_SpringboardAlgo_BoolEnum { True, False }

public enum ARC_SpringboardAlgo_MovingAverageType { EMA, SMA, StepMA }

public enum ARC_SpringboardAlgo_StepMaTrendType { Level, Trend }

public enum ARC_SpringboardAlgo_DayWeekMonth { Day, Week, Month }

public enum ARC_SpringboardAlgo_SingleBarPattern
{
	Inside = 1, 
	Directional = 2,
	Outside = 3
}

[Flags]
public enum ARC_SpringboardAlgo_ARCFilterType
{
	TaFilters = 1,
	MoneyManagement = 2,
	Time = 4,
	Direction = 8,
	ConsecutiveTrades = 16,
	ArmState = 32,
	SameBar = 64,
	AllExceptArmState = TaFilters | MoneyManagement | Time | Direction | ConsecutiveTrades | SameBar,
	All = AllExceptArmState | ArmState
}