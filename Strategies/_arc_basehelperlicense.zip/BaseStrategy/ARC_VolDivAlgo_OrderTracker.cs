using System.Collections;
using System.Collections.Generic;
using System.Linq;
using NinjaTrader.Cbi;

namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	/// <summary>
	/// Acts as a collection of orders controlled by the NS base strategy, automatically 
	/// </summary>
	internal class ARC_VolDivAlgo_OrderTracker : IEnumerable<Order>
	{
		/*
		 * The weird linq expression on both this and min are for optimization reasons, both are called far too frequently to worry about code cleanliness
		 */
		public double MaxStopLossValue
		{
			get
			{
				return stopLossOrders
					.Where(o => o != null)
					.Select(o => o.StopPrice)
					.Prepend(0)
					.Max();
			}
		}
		
		public double MinStopLossValue
		{
			get
			{
				var minValue = stopLossOrders
					.Where(o => o != null)
					.Select(o => o.StopPrice)
					.Prepend(double.MaxValue)
					.Min();

				return minValue == double.MaxValue ? 0 : minValue;
			}
		}

		public List<Order> AllLiveExitOrders
		{
			get
			{
				return stopLossOrders
					.Concat(targetOrders)
					.Where(o => o != null && !o.ARC_VolDivAlgo_IsTerminal())
					.ToList();
			}
		}

		public bool IsPendingEntryOrders { get { return PendingEntryDir != 0; } }

		public int PendingEntryDir
		{
			get
			{
				return this
					.Where(o => o != null && o.OrderType != OrderType.Market)
					.Select(o => o.IsLong ? 1 : -1)
					.FirstOrDefault();
			}
		}

		public int Count { get { return entryOrders.Length; } }

		/// <summary>
		/// Access the Ith tracked entry order
		/// </summary>
		/// <param name="i"></param>
		/// <returns></returns>
		public Order this[int i]
		{
			get { return entryOrders[i]; }
			set { entryOrders[i] = value; }
		}

		// TODO Rename more descriptively
		public int lastPendingOrderInitiation;
		public Order cancelOrder;
		public readonly Order[] stopLossOrders;
		public readonly Order[] targetOrders;
		private readonly Order[] entryOrders;
		public ARC_VolDivAlgo_OrderTracker(int numOrders)
		{
			entryOrders = new Order[numOrders];
			targetOrders = new Order[numOrders];
			stopLossOrders = new Order[numOrders];
		}

		public void Reset()
		{
			for (var i = 0; i < Count; i++)
			{
				this[i] = null;
				stopLossOrders[i] = null;
				targetOrders[i] = null;
			}

			cancelOrder = null;
		}

		public void TransitionToRealtime(Strategy strategy)
		{
			TransitionToRealtime(strategy, stopLossOrders);
			TransitionToRealtime(strategy, targetOrders);
			TransitionToRealtime(strategy, entryOrders);
		}

		private static void TransitionToRealtime(Strategy strategy, Order[] arr)
		{
			for (var i = 0; i < arr.Length; i++)
			{
				if (arr[i] == null)
					continue;

				arr[i] = strategy.GetRealtimeOrder(arr[i]);
			}
		}

		/// <summary>
		/// Untracks completed orders
		/// </summary>
		private void ClearTerminatedOrders()
		{
			// Refresh entry orders
			for (var i = 0; i < Count; i++)
				if (this[i] != null && this[i].ARC_VolDivAlgo_IsTerminal())
					this[i] = null;

			// Clear out our stop loss and target orders if either are dead
			if (cancelOrder != null && cancelOrder.ARC_VolDivAlgo_IsTerminal())
				cancelOrder = null;

			// Clear out our stop loss and target orders if either are dead
			for (var i = 0; i < Count; i++)
				foreach (var orderArr in new[] { stopLossOrders, targetOrders })
					if (orderArr[i] != null && orderArr[i].ARC_VolDivAlgo_IsTerminal())
						orderArr[i] = null;
		}

		internal void ProcessUpdate(Order order)
		{
			ClearTerminatedOrders();
			if (order == null || order.ARC_VolDivAlgo_IsTerminal())
				return;

			if (string.IsNullOrWhiteSpace(order.FromEntrySignal))
				return;

			var orderIdx = int.Parse(order.FromEntrySignal.Substring(1)) - 1;
			if (order.Name == "Stop loss")
				stopLossOrders[orderIdx] = order;
			if (order.Name == "Profit target")
				targetOrders[orderIdx] = order;
		}

		public IEnumerator<Order> GetEnumerator()
		{
			return entryOrders.AsEnumerable().GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}
	}
}