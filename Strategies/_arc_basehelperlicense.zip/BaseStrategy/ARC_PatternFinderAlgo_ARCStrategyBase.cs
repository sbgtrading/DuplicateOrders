using NinjaTrader.Cbi;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.Indicators.ARC;
using NinjaTrader.NinjaScript.Indicators.ARC.AlgoSup;
using NinjaTrader.NinjaScript.Indicators.ARC.Supporting;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Media;
using System.Xml.Serialization;
using SharpDX;
using SharpDX.Direct2D1;
using Brush = System.Windows.Media.Brush;
using DayOfWeek = System.DayOfWeek;
using Order = NinjaTrader.Cbi.Order;
using System.Diagnostics;

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_PatternFinderAlgo_ExtendedStrategyConverter")]
	[ARC_PatternFinderAlgo_HideParameters(ARC_PatternFinderAlgo_StrategyContext.Backtest, ARC_PatternFinderAlgo_StrategyContext.Optimization, Properties = new [] { "AutoDisarmEnum", "RunType" })]
	[ARC_PatternFinderAlgo_CoLicenses(typeof(ARC_PatternFinderAlgo_VMAlgo), typeof(ARC_PatternFinderAlgo_ARC_TrendStepper), typeof(ARC_PatternFinderAlgo_ARC_MWPatternFinderZigZag))]
	[CategoryOrder(StrategyParameterGroupName, 1)]
	[CategoryOrder(EntryGroupName, 20)]
	[CategoryOrder(StopLossGroupName, 30)]
	[CategoryOrder(TargetsGroupName, 40)]
	[CategoryOrder(TimeControlGroupName, 50)]
	[CategoryOrder(MoneyManagementGroupName, 60)]
	[CategoryOrder(MiscFiltersGroupName, 70)]
	[CategoryOrder(HTFMovingAveragesGroupName, 80)]
	[CategoryOrder(MarketStructureFilterGroupName, 90)]
	[CategoryOrder(VMLeanGroupName, 100)]
	[CategoryOrder(ProductInfoGroupName, 110)]
	[CategoryOrder(StrategyVisualsParameterGroupName, 200)]
	[CategoryOrder(VMLeanPlotsGroupName, 210)]
	[CategoryOrder(VisualsGroupName, 220)]
	public abstract class ARC_PatternFinderAlgo_ARCStrategyBase : Strategy, ARC_PatternFinderAlgo_IARCLicensedWithMessages
	{
		#region Properties/Fields
		[XmlIgnore, Browsable(false)]
		public virtual bool ColicensedOnly { get { return false; } }
		[Browsable(false), XmlIgnore]
		public virtual string ProductInfusionSoftTag { get { return ""; } }
		[Browsable(false), XmlIgnore]
		public virtual List<string> ProductBundleInfusionSoftTags { get { return new List<string>(); } }
		[XmlIgnore, Browsable(false)]
		public TextFixed LicensingLoadingText { get; set; }
		[XmlIgnore, Browsable(false)]
		public TextFixed LicensingErrorText { get; set; }
		[Display(GroupName = ProductInfoGroupName)]
		public virtual string ProductVersion { get { throw new NotImplementedException(); } }
		[Display(GroupName = ProductInfoGroupName)]
		public virtual string ModuleName { get { return GetType().Name.Replace("ARC_", ""); } }

		/// <summary>
		/// The default name for the script in the UI and ToString
		/// </summary>
		protected virtual string ProductName { get { return GetType().Name; } }

		public override string DisplayName { get { return ToString() + ARC_PatternFinderAlgo_ARCLicenseValidator.LicenseModeDenotingNameSuffix; } }

		/// <summary>
		/// The prefix used for automation IDs for UI components to avoid collisions with other products.
		/// </summary>
		protected string AutomationIdsPrefix { get { return ModuleName; } }
		
		/// <summary>
		/// True if we can only enter on the close of a primary (for time based bars), or the first tick of the next bar (for non time based bars)
		/// </summary>
		protected virtual bool AllowIntrabarEntries { get { return false; } }

		protected virtual float BottomRenderMargin { get { return 0; } }
		
		protected virtual bool OverridesVMBiasAndConfluenceHandling { get { return false; } }
		private int[] TargetQuantities { get { return new[] { Entry1Quantity, Entry2Quantity, Entry3Quantity }; } }

		/// <summary>
		/// The flat PNL since the start of the strategy
		/// </summary>
		private double ChartClosedPnl
		{
			get
			{
				return SystemPerformance.AllTrades.TradesPerformance.NetProfit;
			}
		}

		/// <summary>
		/// The flat PNL since our equity curve managers start time
		/// </summary>
		private double SessionClosedPnl
		{
			get
			{
				if (SystemPerformance.AllTrades.Count == tradeCountAtLastSessionClosedPnlRefresh && lastMmReset == lastMmResetAtLastSessionClosedPnlRefresh)
					return lastSessionClosedPnl;

				lastSessionClosedPnl = SystemPerformance.AllTrades
					.Skip(tradeCountAtLastMmReset)
					.Where(trd => trd.Entry.Time >= lastMmReset)
					.Sum(trd => trd.ProfitCurrency);
				lastMmResetAtLastSessionClosedPnlRefresh = lastMmReset;
				tradeCountAtLastSessionClosedPnlRefresh = SystemPerformance.AllTrades.Count;
				return lastSessionClosedPnl;
			}
		}
		private double lastSessionClosedPnl;
		private int tradeCountAtLastSessionClosedPnlRefresh;
		private DateTime lastMmResetAtLastSessionClosedPnlRefresh;
		private int tradeCountAtLastMmReset;

		protected const string OppositeOrderName = "Opposite Exit";

		private string customToolbarControlsGridAutomationId;
		private bool isToolBarButtonAdded;
		private Grid customToolbarControlsGrid;
		private Menu menuControlContainer;
		private MenuItem menuControl, miOff, miBoth, miLong, miShort, miBreakEven, miStopLoss, miMoveStop, miArmDisarm;

		private DateTime lastMmReset;
		private double mmMaxGain;
		protected bool mmCanTrade = true;
		
		private ARC_PatternFinderAlgo_OrderTracker orderTracker;
		protected int orderBarsIdx;

		private ARC_PatternFinderAlgo_ChartPnl indPnlChart;
		private ARC_PatternFinderAlgo_OrderSingle indOrder;
		private ARC_PatternFinderAlgo_TargStop indStopTrg;

		protected double stopLossUserOverride;

		protected ARC_PatternFinderAlgo_VMAlgo indMomo;
		protected Indicator filterMa;
		private int htfBarsIdx = -1;
		private bool firstTickOfPrimaryBar;
		private bool pendingFirstNewTimeTickOfPrimaryBar;
		private int idxOfFirstTickOfCurrentPrimaryBar = -1;

		protected int primaryBarOnLastExit = -1;
		private int orderBarOnLastExit = -1;
		protected int lastEntryBar;
		protected int PendingEntryDir { get; private set; }
		private int barToPaintAsInvalidPriceCancellation = -1;
		protected int lastSignalBar;
		protected int lastSignalDir;
		private double pendingTpMultiple = 1;
		private double? pendingBarPlotSl;
		private double?[] pendingBarPlotTp;
		private double? pendingEntryLimitPrice;

		private ARC_PatternFinderAlgo_ARC_MWPatternFinderZigZag msFilterZigZag;
		protected Brush longStripBrush;
		protected Brush shortStripBrush;
		private ATR stopLossAtr;
		private ATR targetAtr;
		private bool hitHistoricalState;

		private int consecutiveTradesInCurrentDir;
		private int lastTradeDir;

		private bool Armed
		{
			get { return armed; }
			set
			{
				if (AutoDisarm && ChartControl != null && miArmDisarm != null)
					ChartControl.Dispatcher.InvokeAsync(() => miArmDisarm.Header = value ? "DISARM (Currently Armed)" : "ARM (Currently Disarmed)");
				armed = value;
			}
		}
		private bool armed;

		private readonly ARC_PatternFinderAlgo_DefaultingDictionary<string, int> safeEntryCurrentQuantities = new ARC_PatternFinderAlgo_DefaultingDictionary<string, int>();
		private readonly ARC_PatternFinderAlgo_DefaultingDictionary<string, double> safeEntryCurrentAvgFillPrices = new ARC_PatternFinderAlgo_DefaultingDictionary<string, double>();
		#endregion

		static ARC_PatternFinderAlgo_ARCStrategyBase()
		{
			var a = new ARC_PatternFinderAlgo_BoolEnumConverter();
			var b = new ARC_PatternFinderAlgo_NonOptimizationCheckBoxEditor();
			foreach (var i in new object[] { a, b })
			{
				Debug.WriteLine(i.ToString());
				Console.WriteLine(i.ToString());
			}
		}

		#region NT Overrides
		protected override void OnStateChange()
		{
			if (State != State.SetDefaults && State != State.Configure && State != State.Terminated && !this.ARC_PatternFinderAlgo_IsLicensed())
				return;
			
			if (State == State.SetDefaults)
			{
				Name = ProductName + ARC_PatternFinderAlgo_ARCLicenseValidator.LicenseModeDenotingNameSuffix;
				Calculate = Calculate.OnBarClose;
				EntriesPerDirection = 3;
				MaximumBarsLookBack = MaximumBarsLookBack.TwoHundredFiftySix;
				IsInstantiatedOnEachOptimizationIteration = true;
				IsExitOnSessionCloseStrategy = false;

				RunType = ARC_PatternFinderAlgo_RunType.BackTest;
				StartTime = 600;
				EndTime = 1600;
				ExitAtEndTime = false;
				RestartPnlOnSession = false;
				DayMaxGain = 0;
				DayMaxLoss = 0;
				HighWaterMarkType = ARC_PatternFinderAlgo_HighWaterMarkType.Off;
				DailyHighWaterMarkPct = 0;
				HwmActivatedAt = 200;
				IgnoreTradeTime = false;
				StopDotColor = Brushes.Red;
				TargetDotColor = Brushes.Lime;
				AllowedEntryDirections = ARC_PatternFinderAlgo_AllowedEntryDirection.LongAndShort;
				Entry1Quantity = 1;
				Entry2Quantity = 0;
				Entry3Quantity = 0;
				EntryOrderType = ARC_PatternFinderAlgo_EntryOrderType.Market;
				LimitEntryOffsetTicks = 0;
				StopLossType = ARC_PatternFinderAlgo_StopLossType.Ticks;
				StopLoss = 10;
				StopLossATRPeriod = 14;
				TargetType = ARC_PatternFinderAlgo_TargetType.Ticks;
				UseMitTargetOrders = false;
				ProfitTargetValue1 = 8;
				ProfitTargetValue2 = 0;
				ProfitTargetValue3 = 0;
				TrailTriggerTicks = 0;
				TrailLookbackBars = 0;
				TrailTicks = 0;
				BreakEvenTrigger = 0;
				BreakEvenPlus = 0;
				DashHistoricPnl = true;
				OnOppositeSignal = ARC_PatternFinderAlgo_OppositeSignalAction.None;
				UseHTFMovingAverage = false;
				MABarBiasPercentRequirement = 0;
				MaxPendingOrderBars = 1;
				MaxPendingOrderDistance = 0;
				TargetATRPeriod = 14;
				LimitPreOrderGapBars = true;
				MaxPreOrderGapBars = 0;
				AllowEntriesOnExitBars = true;
				AutoDisarm = false;

				LimitConsecutiveTradesInDirection = false;
				MaxConsecutiveTradesInDirection = 1;

				ShowVMAlgo = false;
				BlockLevelEntry = 0;
				VMBiasType = ARC_PatternFinderAlgo_VMAlgo_BiasType.ZeroLine;
				VMHistogramBackground = false;
				BandPeriod = 10;
				Fast = 12;
				Slow = 26;
				StdDevNumber = 1;
				VMSwingStrength = 1;
				MinDeviationMultiplier = 0;
				UseVMBias = false;
				UseVMConfluence = false;
					 
				MAPeriod = 15;
				MATimeframe = 1;
				MAType = ARC_PatternFinderAlgo_MovingAverageType.EMA;
				FilterMAStepSize = 40;
				FilterMATrendType = ARC_PatternFinderAlgo_StepMaTrendType.Trend;
				ShowMA = false;
				MAColor = Brushes.WhiteSmoke;

				ShowMsFilterZigZag = false;
				ShowMsFilterBiasStrip = false;
				UseMsFilter = false;
				MsFilterSwingStrength = 3;
				MsFilterIncludeWicks = true;
				MsFilterNeutralColor = Brushes.Black;
				MsFilterUptrendColor = Brushes.Cyan;
				MsFilterDowntrendColor = Brushes.Magenta;
				MsFilterZigZagThickness = 2;
				MsFilterBiasStripThickness = 12;

				LongStripColor = Brushes.Green;
				LongStripOpacity = 50;
				ShortStripColor = Brushes.Red;
				ShortStripOpacity = 50;
				ChartPnLTextColor = Brushes.DimGray;
				DotsUpRisingColor = Brushes.Green;
				DotsDownRisingColor = Brushes.Green;
				DotsDownFallingColor = Brushes.Red;
				DotsUpFallingColor = Brushes.Red;
				DotsRimColor = Brushes.Black;
				BBAverageColor = Brushes.Transparent;
				BBUpperColor = Brushes.Black;
				BBLowerColor = Brushes.Black;
				HistUpColor = Brushes.LimeGreen;
				HistDownColor = Brushes.Maroon;
				ZeroLineColor = Brushes.Black;
				ConnectorColor = Brushes.White;
				DeepBullishBackgroundColor = Brushes.DarkGreen;
				BullishBackgroundColor = Brushes.Green;
				OppositeBackgroundColor = Brushes.Gray;
				BearishBackgroundColor = Brushes.Red;
				DeepBearishBackgroundColor = Brushes.DarkRed;
				ChannelColor = Brushes.DodgerBlue;
				ExcursionLevel1Color = Brushes.White;
				ExcursionLevel2Color = Brushes.Blue;
				ExcursionLevel3Color = Brushes.Red;
				UnfilledOrderColor = Brushes.Yellow;
				GapBarOrderColor = Brushes.Orange;
			}
			else if (State == State.Configure)
			{
				RealtimeErrorHandling = RealtimeErrorHandling.StopCancelCloseIgnoreRejects;
				TraceOrders = true;
				StartBehavior = StartBehavior.WaitUntilFlat;
				this.ARC_PatternFinderAlgo_EnactLicensingWithWarnings(ARC_PatternFinderAlgo_LicensingContextStep.Configure);
				if (!this.ARC_PatternFinderAlgo_IsLicensed())
					return;

				// Reset fields for optimization
				hitHistoricalState = false;
				ResetPerRunCustomValues();

				if (Entry3Quantity > 0)
					EntriesPerDirection = 3;
				else if (Entry2Quantity > 0)
					EntriesPerDirection = 2;
				else
					EntriesPerDirection = 1;

				stopLossUserOverride = StopLoss;

				orderBarsIdx = EnsureDataSeriesAdded(BarsPeriodType.Tick, 1);
				if (ShowMA)
				{
					const string maPlotName = "HTF MA";
					var filterMaPlotIdx = Array.FindIndex(Plots, p => p.Name == maPlotName);
					if (filterMaPlotIdx == -1)
					{
						AddPlot(MAColor, maPlotName);
						filterMaPlotIdx = Plots.Length - 1;					
					}

					Plots[filterMaPlotIdx].PlotStyle = MAType == ARC_PatternFinderAlgo_MovingAverageType.StepMA ? PlotStyle.Square : PlotStyle.Line;
					Plots[filterMaPlotIdx].Width = 2;
				}

				htfBarsIdx = EnsureDataSeriesAdded(BarsPeriodType.Minute, MATimeframe);
			}
			else if (State == State.DataLoaded)
			{
				indStopTrg = ARC_PatternFinderAlgo_TargStop(1, 3);
				indStopTrg.StopPlots.ForEach(p => p.Brush = StopDotColor);
				indStopTrg.TargetPlots.ForEach(p => p.Brush = TargetDotColor);
				indStopTrg.Name = "";
				AddChartIndicator(indStopTrg);

				indOrder = ARC_PatternFinderAlgo_OrderSingle();
				indOrder.Plots[0].Brush = Brushes.Cyan;
				indOrder.Plots[1].Brush = Brushes.Magenta;
				indOrder.Name = "";
				AddChartIndicator(indOrder);

				indPnlChart = ARC_PatternFinderAlgo_ChartPnl();
				indPnlChart.defaultTextBrush = ChartPnLTextColor;
				indPnlChart.Name = "";
				AddChartIndicator(indPnlChart);

				indMomo = ARC_PatternFinderAlgo_VMAlgo(BarsArray[0], ARC_PatternFinderAlgo_VMAlgo_OptimizeSpeedSettings.Max, BandPeriod, Fast, Slow, StdDevNumber, VMSwingStrength, MinDeviationMultiplier, 0);
				indMomo.BackgroundFlooding = VMHistogramBackground ? ARC_PatternFinderAlgo_VMAlgo_Flooding.Histogram : ARC_PatternFinderAlgo_VMAlgo_Flooding.None;
				indMomo.DisplayLevel1 = true;
				indMomo.DotsUpRisingColor = DotsUpRisingColor;
				indMomo.DotsDownRisingColor = DotsDownRisingColor;
				indMomo.DotsDownFallingColor = DotsDownFallingColor;
				indMomo.DotsUpFallingColor = DotsUpFallingColor;
				indMomo.DotsRimColor = DotsRimColor;
				indMomo.BBAverageColor = BBAverageColor;
				indMomo.BBUpperColor = BBUpperColor;
				indMomo.BBLowerColor = BBLowerColor;
				indMomo.HistDownColor = HistDownColor;
				indMomo.HistUpColor = HistUpColor;
				indMomo.ZerolineColor = ZeroLineColor;
				indMomo.ConnectorColor = ConnectorColor;
				indMomo.DeepBearishBackgroundColor = DeepBearishBackgroundColor;
				indMomo.DeepBullishBackgroundColor = DeepBullishBackgroundColor;
				indMomo.OppositeBackgroundColor = OppositeBackgroundColor;
				indMomo.BullishBackgroundColor = BullishBackgroundColor;
				indMomo.BearishBackgroundColor = BearishBackgroundColor;
				indMomo.ChannelColor = ChannelColor;
				indMomo.Level1Color = ExcursionLevel1Color;
				indMomo.Level2Color = ExcursionLevel2Color;
				indMomo.Level3Color = ExcursionLevel3Color;
				if (ShowVMAlgo)
					AddChartIndicator(indMomo);

				if (UseHTFMovingAverage || ShowMA)
					switch (MAType)
					{
					case ARC_PatternFinderAlgo_MovingAverageType.EMA:
						filterMa = EMA(Closes[htfBarsIdx], MAPeriod);
						break;
					case ARC_PatternFinderAlgo_MovingAverageType.SMA:
						filterMa = SMA(Closes[htfBarsIdx], MAPeriod);
						break;
					case ARC_PatternFinderAlgo_MovingAverageType.StepMA:
						filterMa = ARC_PatternFinderAlgo_ARC_TrendStepper(Closes[0], FilterMAStepSize, 0);
						break;
					default: 
						throw new ArgumentOutOfRangeException();
					}

				orderTracker = new ARC_PatternFinderAlgo_OrderTracker(3);

				if (StopLossType == ARC_PatternFinderAlgo_StopLossType.ATR)
					stopLossAtr = ATR(StopLossATRPeriod);
				if (TargetType == ARC_PatternFinderAlgo_TargetType.ATR)
					targetAtr = ATR(TargetATRPeriod);

				if (ShowMsFilterZigZag || ShowMsFilterBiasStrip || UseMsFilter)
					msFilterZigZag = ARC_PatternFinderAlgo_ARC_MWPatternFinderZigZag(MsFilterSwingStrength, MsFilterIncludeWicks);
			}
			else if (State == State.Historical)
			{
				hitHistoricalState = true;

				longStripBrush = LongStripColor.Clone();
				longStripBrush.Opacity = LongStripOpacity / 100.0;
				longStripBrush.Freeze();

				shortStripBrush = ShortStripColor.Clone();
				shortStripBrush.Opacity = ShortStripOpacity / 100.0;
				shortStripBrush.Freeze();

				if (ChartControl == null || IsInStrategyAnalyzer)
					return;

				customToolbarControlsGridAutomationId = AutomationIdsPrefix + ChartControl.ChartTab.PersistenceId + "CustomToolbarControlsGridAutomationId";
				if (isToolBarButtonAdded)
					return;

				ChartControl.Dispatcher.InvokeAsync(() =>
				{
					var chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
					if (chartWindow == null)
						return;

					isToolBarButtonAdded |= chartWindow.MainMenu
						.OfType<DependencyObject>()
						.Select(AutomationProperties.GetAutomationId)
						.Contains(customToolbarControlsGridAutomationId);

					if (isToolBarButtonAdded)
						return;

					AddToolBar(chartWindow);
					isToolBarButtonAdded = true;
				});
			}
			//else if (State == State.Transition)
			//{
			//	var indicatorsToMove = ChartIndicators
			//		.GroupBy(i => i.Panel)
			//		.Where(g => (g.Key == 0 || g.Count() > 1) && g.Any(i => !i.IsOverlay))
			//		.SelectMany(g => g.Skip(g.Key == 0 ? 0 : 1).Where(i => !i.IsOverlay))
			//		.ToArray();

			//	if (indicatorsToMove.Length == 0)
			//		return;

			//	try
			//	{
			//		var curPanelIdx = ChartIndicators.Max(i => i.Panel) + 1;
			//		foreach (var i in indicatorsToMove)
			//		{
			//			i.Panel = curPanelIdx;
			//			curPanelIdx++;
			//		}
			//	}
			//	catch
			//	{ }
			//}
			else if (State == State.Realtime)
			{
				orderTracker.AllLiveExitOrders.ForEach(CancelOrder);
				CancelPendingEntries();
				ExitPosition("EndBacktest");
				orderTracker.TransitionToRealtime(this);

				orderTracker.Reset();
				ResetMoneyManagement();
			}
			else if (State == State.Terminated)
			{
				if (hitHistoricalState)
					GC.Collect();

				if (IsInStrategyAnalyzer || !isToolBarButtonAdded || ChartControl == null)
					return;

				ChartControl.Dispatcher.InvokeAsync(() =>
				{
					var chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
					if (chartWindow == null)
						return;

					chartWindow.MainMenu.Remove(customToolbarControlsGrid);
					foreach (var grid in chartWindow.MainMenu.OfType<Grid>().Where(g => AutomationProperties.GetAutomationId(g) == customToolbarControlsGridAutomationId).ToList())
						chartWindow.MainMenu.Remove(grid);

					customToolbarControlsGrid = null;
					chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
				});
			}
		}

		protected override void OnMarketData(MarketDataEventArgs marketDataUpdate)
		{
			if (!this.ARC_PatternFinderAlgo_IsLicensed())
				return;

			if (marketDataUpdate.MarketDataType != MarketDataType.Last || RunType == ARC_PatternFinderAlgo_RunType.BackTest)
				return;

			if (Position.MarketPosition != MarketPosition.Flat)
				SyncPnlPlot();

			SyncMoneyManagement(marketDataUpdate.Price);
		}

		protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string comment)
		{
			if (orderState == OrderState.Rejected || error != ErrorCode.NoError || !string.IsNullOrWhiteSpace(comment))
			{
				Log("Rejection: " + error, LogLevel.Warning);
				ExitPosition("Order Rejection Exit");
			}

			orderTracker.ProcessUpdate(order);
		}

		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
		{
			if (Regex.IsMatch(execution.Order.Name, @"^(L|S)\d+$"))
				HandleEntryExecution(execution, price, quantity);
			else
				HandleExitExecution(execution, quantity);

			// Can't have a pending entry order in the opposite direction, so limit reversals are entered here, after the reversal exit 
			if (OnOppositeSignal != ARC_PatternFinderAlgo_OppositeSignalAction.Reverse || EntryOrderType != ARC_PatternFinderAlgo_EntryOrderType.Limit)
				return;

			if (execution.Order.Name != OppositeOrderName)
				return;

			if (lastEntryBar < CurrentBars[0])
				return;

			var signalDir = execution.Order.IsLong ? 1 : -1;
			var limitPrice = Closes[0].GetValueAt(lastEntryBar);
			SubmitOrder(signalDir, limitPrice);
		}

		protected override void OnPositionUpdate(Position position, double averagePrice, int quantity, MarketPosition marketPosition)
		{
			if (IsInStrategyAnalyzer || ChartControl == null || !isToolBarButtonAdded)
				return;

			ChartControl.Dispatcher.InvokeAsync(() =>
			{
				var enabled = position.MarketPosition != MarketPosition.Flat;
				foreach (var mi in new[] { miStopLoss, miMoveStop })
					mi.IsEnabled = enabled;
			});
		}

		protected override void OnBarUpdate()
		{
			this.ARC_PatternFinderAlgo_EnactLicensingWithWarnings(ARC_PatternFinderAlgo_LicensingContextStep.BarUpdate);
			if (!this.ARC_PatternFinderAlgo_IsLicensed())
				return;

			if (CurrentBars[0] < 1 || CurrentBars[orderBarsIdx] < 5)
				return;

			if (BarsInProgress == orderBarsIdx)
			{
				if (firstTickOfPrimaryBar)
					idxOfFirstTickOfCurrentPrimaryBar = CurrentBars[orderBarsIdx];

				// Handle the first tick to cross the session end time
				if (!ManualTradeMode && (Time[0].Date != Time[1].Date || (Time[0].ARC_PatternFinderAlgo_CompareTime(EndTime) != -1 && Time[1].ARC_PatternFinderAlgo_CompareTime(EndTime) == -1)))
				{
					if (!IgnoreTradeTime || ExitAtEndTime)
						CancelPendingEntries();

					if (ExitAtEndTime)
						ExitPosition("endTime");
				}

				// Cancel pending entries if any distance exceeds
				if (EntryOrderType == ARC_PatternFinderAlgo_EntryOrderType.Limit && orderTracker
						.Where(o => o != null && !o.ARC_PatternFinderAlgo_IsTerminal())
						.Select(o => o.LimitPrice)
						.Any(p => Math.Abs(Close[0] - p) > MaxPendingOrderDistance))
				{
					barToPaintAsInvalidPriceCancellation = CurrentBars[0] + (Time[0] > Times[0][0] ? 1 : 0);
					CancelPendingEntries();
				}

				if (BarsArray[orderBarsIdx].IsFirstBarOfSession || BarsArray[orderBarsIdx].IsLastBarOfSession)
				{
					if (ResetConsecutiveTradeCountOnSessionClose)
					{
						consecutiveTradesInCurrentDir = 0;
						lastTradeDir = 0;
					}

					if (RestartPnlOnSession)
						ResetMoneyManagement();
				}

				UpdateStop();
				if (State == State.Realtime)
				{
					SyncMoneyManagement(GetCurrentBid(orderBarsIdx));
					SyncMoneyManagement(GetCurrentAsk(orderBarsIdx));
				}
				else
				{
					SyncMoneyManagement(Closes[orderBarsIdx][0]);
				}

				OnTickBar();

				// Track whether or not we're the first tick of the current primary bar.
				// If we're allowing intrabar entries, process pending ones them here.
				if (firstTickOfPrimaryBar)
					firstTickOfPrimaryBar = false;

				if (pendingFirstNewTimeTickOfPrimaryBar)
				{
					if (Time[0] > Times[0][0])
						pendingFirstNewTimeTickOfPrimaryBar = false;
					else if (!AllowIntrabarEntries)
						return;
				}

				ProcessPendingEntries();
			}
			else if (BarsInProgress == 0)
			{
				// We paint here in case orders are rejected the same bar the 
				if (barToPaintAsInvalidPriceCancellation != -1)
				{
					BackBrushes[CurrentBars[0] - barToPaintAsInvalidPriceCancellation] = UnfilledOrderColor;
					barToPaintAsInvalidPriceCancellation = -1;
				}

				if (lastSignalBar == CurrentBar && ShowRacingStripes)
					BackBrushes[0] = lastSignalDir == 1 ? longStripBrush : shortStripBrush;

				var wasFirstTickOfPrimaryBar = firstTickOfPrimaryBar;
				firstTickOfPrimaryBar = true;
				pendingFirstNewTimeTickOfPrimaryBar = true;

				// Force update momo and HTF and copy values if necessary, as we've seen this indicator show flat incorrectly
				if (ShowMsFilterZigZag || ShowMsFilterBiasStrip || UseMsFilter)
					msFilterZigZag.Update();
				indMomo.Update();
				if (ShowMA && (MAType == ARC_PatternFinderAlgo_MovingAverageType.StepMA || CurrentBars[htfBarsIdx] >= 0))
					Value[0] = filterMa[0];

				if (!mmCanTrade)
					BarBrushes[0] = Brushes.DimGray;

				if (CurrentBars[0] < 0 || CurrentBars[orderBarsIdx] < 0)
					return;

				// Check whether or not our gab bar settings require dequeuing pending entries
				if (PendingEntryDir != 0 && LimitPreOrderGapBars)
				{
					var gapBarCount = 0;
					for (var i = 0; i < CurrentBar - lastSignalBar && gapBarCount <= MaxPreOrderGapBars; i++)
						if (Time[i] == Time[i + 1])
							gapBarCount++;
					
					if (gapBarCount > MaxPreOrderGapBars)
					{
						PendingEntryDir = 0;
						BackBrush = GapBarOrderColor;
					}
				}

				// Draw our start of window and end of window marker
				if (InValidTradingWindow(Time[0]) != InValidTradingWindow(Time[1]))
					Draw.VerticalLine(this, CurrentBars[0] + "d", 0, InValidTradingWindow(Time[0]) ? Brushes.LimeGreen : Brushes.Red, DashStyleHelper.Dash, 2);

				if (State != State.Realtime || RunType != ARC_PatternFinderAlgo_RunType.BackTest)
					SyncPnlPlot();

				// Signal order cancellations
				if (EntryOrderType != ARC_PatternFinderAlgo_EntryOrderType.Market && orderTracker.lastPendingOrderInitiation < CurrentBar - MaxPendingOrderBars && orderTracker.IsPendingEntryOrders)
				{
					BackBrush = UnfilledOrderColor;
					CancelPendingEntries();
				}

				// If we're not limiting pre-order gap bars we don't need to wait for a non gap bar to process
				// orders. Otherwise process if not already dequeued and we've received a non gap bar 
				if (!LimitPreOrderGapBars || (Time[0] > Time[1] && wasFirstTickOfPrimaryBar))
					ProcessPendingEntries(1);

				if (!LimitPreOrderGapBars)
					PendingEntryDir = 0;

				// Update stop and target visuals
				SyncStopPlots();
				SyncTargetPlots();

				// Trigger strategy execution handling
				OnPrimaryBar();

				if (orderTracker[0] == null)
					return;

				// Update pending order visuals
				var dir = orderTracker[0].OrderAction == OrderAction.Buy || orderTracker[0].OrderAction == OrderAction.BuyToCover ? 1 : -1;
				var plotSeries = dir == 1 ? indOrder.EntryPriceL : indOrder.EntryPriceS;
				if (orderTracker[0].OrderType == OrderType.Limit)
					plotSeries[0] = orderTracker[0].LimitPrice;
				if (orderTracker[0].OrderType == OrderType.StopMarket || orderTracker[0].OrderType == OrderType.StopLimit)
					plotSeries[0] = orderTracker[0].StopPrice;
			}
			else if (BarsInProgress == htfBarsIdx)
			{
				if (ShowMA && MAType != ARC_PatternFinderAlgo_MovingAverageType.StepMA)
					Value[0] = filterMa[0];
			}
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			if (State != State.Realtime && State != State.Terminated)
				return;

			if (!this.ARC_PatternFinderAlgo_IsLicensed())
				return;

			if (!ShowMsFilterZigZag && !ShowMsFilterBiasStrip)
				return;

			if (msFilterZigZag.SwingPoints.Count < 4)
				return;
			
			msFilterZigZag.Update(CurrentBars[0], 0);

			// Check to see if any points occur past the plotted left edge, if none do, skip rendering
			var rangeStart = msFilterZigZag.SwingPoints.FindIndex(pt => pt.Bar >= ChartBars.FromIndex);
			if (rangeStart == -1)
				return;

			rangeStart = Math.Max(0, rangeStart - 6);
			var rangeEnd = Math.Min(msFilterZigZag.SwingPoints.Count - 1, msFilterZigZag.SwingPoints.FindLastIndex(pt => pt.Bar <= ChartBars.ToIndex) + 5);

			// Get the range of points that intersect the visible range, plus a few extra so we can determine trend
			var points = msFilterZigZag.SwingPoints.GetRange(rangeStart, rangeEnd - rangeStart + 1);

			// Group points by their comparison to the prior point on that side
			var contiguousTrends = points
				.Select((p, i) => new { Point = p, Index = i, Trend = i < 2 ? 0 : p.Price.ApproxCompare(points[i - 2].Price) })
				.Skip(2)
				.ARC_PatternFinderAlgo_GetContiguousGroups((t1, t2) => t1.Trend == t2.Trend && t2.Trend != 0)
				.Where(g => g.Count > 2)
				.ToList();

			// For each contiguous trend, get the points that make up the full trend
			var trends = new ARC_PatternFinderAlgo_DefaultingDictionary<int, List<List<ARC_PatternFinderAlgo_ZigZagPoint>>>(_ => new List<List<ARC_PatternFinderAlgo_ZigZagPoint>>());
			foreach (var group in contiguousTrends)
			{
				var groupPoints = group
					.Select(g => g.Point)
					.Prepend(points[group[0].Index - 1])
					.Prepend(points[group[0].Index - 2])
					.ToList();

				if (group.Last().Index < points.Count - 1)
				{
					var addedLastPoint = false;

					// Check if there was a point where we exceeded a threshold and that was what ended the trend
					// If there is such a point, add a point to the trend marking the exact bar where it ended
					var p0 = groupPoints.Last();
					var p1 = points[group.Last().Index + 1];
					var thresh = groupPoints[groupPoints.Count - 2].Price;
					var threshCrossDir = -groupPoints.Last().Side;
					var series = !MsFilterIncludeWicks ? Closes[0] : (threshCrossDir == -1 ? Lows[0] : Highs[0]);
					for (int i = p0.Bar; i < p1.Bar; i++)
						if (series.GetValueAt(i).ApproxCompare(thresh) != -threshCrossDir)
						{
							groupPoints.Add(p0.GetMidpoint(p1, i));
							addedLastPoint = true;
							break;
						}

					// If we didn't end by exceeding a threshold, then we must have ended by not exceeding one.
					// In that case our trend ended when the point that failed to exceed a thresh was confirmed
					if (!addedLastPoint)
					{
						groupPoints.Add(points[group.Last().Index + 1]);
						if (group.Last().Index < points.Count - 2)
						{
							var confirmingPoint = points[group.Last().Index + 2];
							groupPoints.Add(groupPoints.Last().GetMidpoint(confirmingPoint, confirmingPoint.BarCreated));
						}
					}
				}

				trends[group[0].Trend].Add(groupPoints);
			}

			var orderedTrends = trends
				.SelectMany(kvp => kvp.Value.Select(pts => new { Points = pts, Trend = kvp.Key }))
				.OrderBy(t => t.Points[0].Bar)
				.ToList();

			var priorAaMode = RenderTarget.AntialiasMode;
			try
			{
				RenderTarget.AntialiasMode = AntialiasMode.PerPrimitive;

				// Draw the no trend zig zag below everything else
				if (ShowMsFilterZigZag)
					using (var neutralDxBrush = MsFilterNeutralColor.ToDxBrush(RenderTarget))
						RenderTarget.ARC_PatternFinderAlgo_DrawZigZag(this, chartScale, points, neutralDxBrush, MsFilterZigZagThickness);

				using (var uptrendDxBrush = MsFilterUptrendColor.ToDxBrush(RenderTarget))
				using (var downtrendDxBrush = MsFilterDowntrendColor.ToDxBrush(RenderTarget))
				{
					foreach (var trend in orderedTrends.Where(t => t.Trend != 0))
					{
						// Split the trend points into the 4 points that started the trend, and the points within the trend
						var backFillPoints = trend.Points
							.Take(4)
							.ToList();
						var realTrendPoints = trend.Points
							.Skip(3)
							.ToList();

						// Draw the trend as a zig zag. First 4 points as a dotted line, and the rest as a solid line
						if (ShowMsFilterZigZag)
						{
							RenderTarget.ARC_PatternFinderAlgo_DrawZigZag(this, chartScale, backFillPoints, trend.Trend == 1 ? uptrendDxBrush : downtrendDxBrush, Math.Max(1, MsFilterZigZagThickness - 1), DashStyleHelper.Dot);
							RenderTarget.ARC_PatternFinderAlgo_DrawZigZag(this, chartScale, realTrendPoints, trend.Trend == 1 ? uptrendDxBrush : downtrendDxBrush, MsFilterZigZagThickness);
						}

						if (!ShowMsFilterBiasStrip)
							continue;

						// Draw the trend as a bias strip. First 4 points as a dotted line, and the rest as a solid line
						var bottomY = chartScale.GetYByValue(chartScale.MinValue);
						for (int i = 0; i < 2; i++)
						{
							var thickness = i == 0 ? MsFilterBiasStripThickness * 3 / 4 : MsFilterBiasStripThickness;
							var subset = i == 0 ? backFillPoints : realTrendPoints;
							var vectorArray = subset
								.Take(1)
								.Append(subset.Last())
								.Select(p => new Vector2(chartControl.GetXByBarIndex(ChartBars, p.Bar), bottomY - (int)Math.Ceiling(MsFilterBiasStripThickness / 2) - BottomRenderMargin))
								.ToArray();

							var strokeStyle = new Stroke(Brushes.Transparent, i == 0 ? DashStyleHelper.Dot : DashStyleHelper.Solid, thickness).StrokeStyle;
							RenderTarget.DrawLine(vectorArray[0], vectorArray[1], trend.Trend == 1 ? uptrendDxBrush : downtrendDxBrush, thickness, strokeStyle);
						}
					}
				}
			}
			finally
			{
				RenderTarget.AntialiasMode = priorAaMode;
			}
		}
		#endregion

		#region UI
		private void AddToolBar(Chart chartWindow)
		{
			menuControlContainer = new Menu { Background = Brushes.Orange, VerticalAlignment = VerticalAlignment.Center };
			menuControl = new MenuItem { BorderThickness = new Thickness(2), BorderBrush = Brushes.Gold, Header = ButtonText, Foreground = Brushes.Gold, Background = Brushes.MidnightBlue, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			menuControlContainer.Items.Add(menuControl);

			miOff = new MenuItem { Header = "OFF", Name = "ARCOff", IsCheckable = true, IsChecked = AllowedEntryDirections == ARC_PatternFinderAlgo_AllowedEntryDirection.None };
			miOff.Click += (_, __) =>
			{
				AllowedEntryDirections = ARC_PatternFinderAlgo_AllowedEntryDirection.None;
				miOff.IsChecked = true;
				miBoth.IsChecked = false;
				miLong.IsChecked = false;
				miShort.IsChecked = false;
				TriggerCustomEvent(___ =>
				{
					CancelPendingEntries();
					if (Position.MarketPosition != MarketPosition.Flat)
						ExitPosition("OFF");
				}, orderBarsIdx, null);
			};
			menuControl.Items.Add(miOff);

			miBoth = new MenuItem { Header = "LONG AND SHORT", Name = "ARCBoth", IsCheckable = true, IsChecked = AllowedEntryDirections == ARC_PatternFinderAlgo_AllowedEntryDirection.LongAndShort };
			miBoth.Click += (_, __) =>
			{
				AllowedEntryDirections = ARC_PatternFinderAlgo_AllowedEntryDirection.LongAndShort;
				miOff.IsChecked = false;
				miBoth.IsChecked = true;
				miLong.IsChecked = false;
				miShort.IsChecked = false;
			};
			menuControl.Items.Add(miBoth);

			miLong = new MenuItem { Header = "LONG ONLY", Name = "ARCLong", IsCheckable = true, IsChecked = AllowedEntryDirections == ARC_PatternFinderAlgo_AllowedEntryDirection.LongOnly };
			miLong.Click += (_, __) =>
			{
				AllowedEntryDirections = ARC_PatternFinderAlgo_AllowedEntryDirection.LongOnly;
				miOff.IsChecked = false;
				miBoth.IsChecked = false;
				miLong.IsChecked = true;
				miShort.IsChecked = false;
			};
			menuControl.Items.Add(miLong);

			miShort = new MenuItem { Header = "SHORT ONLY", Name = "ARCShort", IsCheckable = true, IsChecked = AllowedEntryDirections == ARC_PatternFinderAlgo_AllowedEntryDirection.ShortOnly };
			miShort.Click += (_, __) =>
			{
				AllowedEntryDirections = ARC_PatternFinderAlgo_AllowedEntryDirection.ShortOnly;
				miOff.IsChecked = false;
				miBoth.IsChecked = false;
				miLong.IsChecked = false;
				miShort.IsChecked = true;
			};
			menuControl.Items.Add(miShort);
			menuControl.Items.Add(new Separator());

			if (ManualTradeMode)
			{
				miArmDisarm = new MenuItem { Header = "DISARM (Currently Armed)", Name = "ARCArmDisarm" };
				miArmDisarm.Click += (_, __) => Armed = !Armed;
				menuControl.Items.Add(miArmDisarm);
				menuControl.Items.Add(new Separator());
			}

			miBreakEven = new MenuItem { Header = "Move Stop to BE", Name = "ARCBreakEven", IsCheckable = false };
			miBreakEven.Click += (_, __) => TriggerCustomEvent(___ => SetStopToEntryPrice(), null);
			menuControl.Items.Add(miBreakEven);
			menuControl.Items.Add(new Separator());

			miStopLoss = new MenuItem { Header = "SL Ticks:   " + stopLossUserOverride, StaysOpenOnClick = true };
			miStopLoss.Click += (_, e) => TriggerCustomEvent(__ => SetStopOverride(stopLossUserOverride + 1), orderBarsIdx, null);
			miStopLoss.MouseWheel += (_, e) => TriggerCustomEvent(__ => SetStopOverride(stopLossUserOverride + e.Delta.CompareTo(0)), orderBarsIdx, null);
			menuControl.Items.Add(miStopLoss);

			miMoveStop = new MenuItem { Header = "Move Stop", Name = "ARCMoveStop", IsCheckable = false };
			miMoveStop.Click += (_, __) => TriggerCustomEvent(___ => SetStopToUserOverride(), null);
			menuControl.Items.Add(miMoveStop);

			customToolbarControlsGrid = new Grid { Visibility = Visibility.Collapsed };
			customToolbarControlsGrid.Children.Add(menuControlContainer);

			chartWindow.MainMenu.Add(customToolbarControlsGrid);
			chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

			if (ReferenceEquals(chartWindow.MainTabControl.SelectedContent, ChartControl.ChartTab))
				customToolbarControlsGrid.Visibility = Visibility.Visible;

			foreach (var mi in menuControl.Items.OfType<MenuItem>())
			{
				mi.Foreground = Brushes.Black;
				mi.FontWeight = FontWeights.Normal;
			}

			AutomationProperties.SetAutomationId(customToolbarControlsGrid, customToolbarControlsGridAutomationId);
		}

		private void TabSelectionChangedHandler(object sender, SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0)
				return;

			var tabItem = e.AddedItems[0] as TabItem;
			if (tabItem == null)
				return;

			var temp = tabItem.Content as ChartTab;
			if (temp != null && customToolbarControlsGrid != null)
				customToolbarControlsGrid.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
		}

		private void SetStopOverride(double ticks)
		{
			stopLossUserOverride = ticks;
			if (!IsInStrategyAnalyzer)
				ChartControl.Dispatcher.InvokeAsync(() => miStopLoss.Header = "SL Ticks:   " + ticks);
		}
		#endregion

		#region Order Handling
		/*
         * NOTE: Backtest execution seems to be fairly different depending on the current bars in progress, for max accuracy, we need to execute
         * while on the tick time frame. This is either an NT8 execution engine limitation (as hinted at by documentation), or because of the order
         * bars are arriving in (meaning the tick to cap a bar arrives after the bar it caps).
         */
		
		private void HandleExitExecution(Execution execution, int quantity)
		{
			OnExitExecution(execution, quantity);

			if (string.IsNullOrWhiteSpace(execution.Order.FromEntrySignal))
			{
				if (quantity != safeEntryCurrentQuantities.Values.Sum())
					throw new Exception("Exit not tied to entry, but does not exit entire position!");
				safeEntryCurrentQuantities.Clear();
				safeEntryCurrentAvgFillPrices.Clear();
			}
			else
			{
				safeEntryCurrentQuantities[execution.Order.FromEntrySignal] -= quantity;
				if (safeEntryCurrentQuantities[execution.Order.FromEntrySignal] == 0)
					safeEntryCurrentAvgFillPrices[execution.Order.FromEntrySignal] = 0;
			}

			primaryBarOnLastExit = execution.BarIndex;
			orderBarOnLastExit = CurrentBars[orderBarsIdx];
			
			SyncPnlPlot();
			
			int orderIdx;
			if (string.IsNullOrWhiteSpace(execution.Order.FromEntrySignal) || !int.TryParse(execution.Order.FromEntrySignal.Substring(1), out orderIdx))
				return;
			orderIdx -= 1;

			// If we've executed, partially or otherwise, our stop loss then adjust or cancel out take profit
			var stop = orderTracker.stopLossOrders[orderIdx];
			var target = orderTracker.targetOrders[orderIdx];
			if (stop == null || target == null)
				return;

			var oppositeOrder = stop.OrderId == execution.OrderId ? target : (target.OrderId == execution.OrderId ? stop : null);
			if (oppositeOrder == null)
				return;
			
			if (oppositeOrder.ARC_PatternFinderAlgo_IsTerminal())
				return;

			if (safeEntryCurrentQuantities[execution.Order.FromEntrySignal] == 0)
				CancelOrder(oppositeOrder);
			else
				ChangeOrder(oppositeOrder, safeEntryCurrentQuantities[execution.Order.FromEntrySignal], oppositeOrder.LimitPrice, oppositeOrder.StopPrice);
		}

		private void HandleEntryExecution(Execution execution, double price, int quantity)
		{
			OnEntryExecution(execution, price, quantity);
			if (ManualTradeMode && State == State.Realtime)
				Armed = false;
			
			safeEntryCurrentAvgFillPrices[execution.Order.Name] = (quantity * price + safeEntryCurrentQuantities[execution.Order.Name] * safeEntryCurrentAvgFillPrices[execution.Order.Name]) / (quantity + safeEntryCurrentQuantities[execution.Order.Name]);
			safeEntryCurrentQuantities[execution.Order.Name] += quantity;
			
			var dir = execution.Order.IsLong ? 1 : -1;
			var sameDirAsLastTrade = dir == lastTradeDir;
			lastTradeDir = dir;

			var orderIdx = int.Parse(execution.Order.Name.Substring(1)) - 1;
			var sl = Math.Max(0, safeEntryCurrentAvgFillPrices[execution.Order.Name] - dir * StopLoss * (StopLossType == ARC_PatternFinderAlgo_StopLossType.Ticks ? TickSize : stopLossAtr[0]));

			if (orderTracker.stopLossOrders[orderIdx] == null)
			{
				var slOrder = dir == 1
					? ExitLongStopMarket(orderBarsIdx, true, safeEntryCurrentQuantities[execution.Order.Name], sl, "Stop loss", execution.Order.Name)
					: ExitShortStopMarket(orderBarsIdx, true, safeEntryCurrentQuantities[execution.Order.Name], sl, "Stop loss", execution.Order.Name);
				pendingBarPlotSl = dir == 1 
					? Math.Min(orderTracker.MinStopLossValue, sl)
					: Math.Max(orderTracker.MaxStopLossValue, sl);
				if (slOrder == null)
				{
					ExitPosition("Stop Loss Rejected");
					return;
				}

				orderTracker.ProcessUpdate(slOrder);

				// Since we don't have an active stop loss, this is the first entry of the order
				// and not a secondary partial. Adjust our consecutive directional trade count.
				if (orderIdx == 0)
				{
					if (sameDirAsLastTrade)
						consecutiveTradesInCurrentDir++;
					else
						consecutiveTradesInCurrentDir = 1;
				}
			}
			else
			{
				pendingBarPlotSl = dir == 1 
					? Math.Min(orderTracker.MinStopLossValue, sl)
					: Math.Max(orderTracker.MaxStopLossValue, sl);
				ChangeOrder(orderTracker.stopLossOrders[orderIdx], safeEntryCurrentQuantities[execution.Order.Name], 0, sl);
			}

			double tpValue;
			switch (orderIdx)
			{
			case 0:
				tpValue = ProfitTargetValue1;
				break;
			case 1:
				tpValue = ProfitTargetValue2;
				break;
			case 2:
				tpValue = ProfitTargetValue3;
				break;
			default:
				throw new IndexOutOfRangeException();
			}

			if (tpValue <= 0) 
				return;

			double tpBaseOffset;
			switch (TargetType)
			{
			case ARC_PatternFinderAlgo_TargetType.Ticks:
				tpBaseOffset = TickSize;
				break;
			case ARC_PatternFinderAlgo_TargetType.RR:
				tpBaseOffset = Math.Abs(price - sl);
				break;
			case ARC_PatternFinderAlgo_TargetType.ATR:
				tpBaseOffset = targetAtr[0];
				break;
			default:
				throw new ArgumentOutOfRangeException();
			}

			var tp = Math.Max(0, safeEntryCurrentAvgFillPrices[execution.Order.Name] + dir * tpValue * tpBaseOffset * pendingTpMultiple);
			if (orderTracker.targetOrders[orderIdx] != null)
			{
				ChangeOrder(orderTracker.targetOrders[orderIdx], safeEntryCurrentQuantities[execution.Order.Name], UseMitTargetOrders ? 0 : tp, UseMitTargetOrders ? tp : 0);
				pendingBarPlotTp[orderIdx] = tp;
				return;
			}

			Order tpOrder;
			if (UseMitTargetOrders)
			{
				tpOrder = dir == 1
					? ExitLongMIT(orderBarsIdx, true, quantity, tp, "Profit target", execution.Order.Name)
					: ExitShortMIT(orderBarsIdx, true, quantity, tp, "Profit target", execution.Order.Name);
			}
			else
			{
				tpOrder = dir == 1
					? ExitLongLimit(orderBarsIdx, true, quantity, tp, "Profit target", execution.Order.Name)
					: ExitShortLimit(orderBarsIdx, true, quantity, tp, "Profit target", execution.Order.Name);
			}

			pendingBarPlotTp[orderIdx] = tp;
			if (tpOrder == null)
			{
				ExitPosition("Take Profit Rejected");
				return;
			}

			orderTracker.ProcessUpdate(tpOrder);
		}

		private void UpdateStop()
		{
			if (Position.MarketPosition == MarketPosition.Flat)
				return;

			var dir = Position.MarketPosition == MarketPosition.Long ? 1 : -1;
			var stop = dir == 1 ? 0 : double.MaxValue;

			var extreme = dir == 1 ? High[0] : Low[0];
			var crossedTrailTrigger = extreme.ApproxCompare(Position.AveragePrice + dir * TrailTriggerTicks * TickSize) == dir;
			if (crossedTrailTrigger)
			{
				if (TrailLookbackBars != 0)
				{
					var priceSeries = dir == 1 ? Lows[0] : Highs[0];
					var barsAgo = dir == 1 ? LowestBar(priceSeries, TrailLookbackBars) : HighestBar(priceSeries, TrailLookbackBars);
					stop = priceSeries[barsAgo];
				}
				else if (TrailTicks > 0)
				{
					stop = extreme;
				}

				stop -= dir * TrailTicks * TickSize;
			}

			if (BreakEvenTrigger > 0 && extreme.ApproxCompare(Position.AveragePrice + dir * BreakEvenTrigger * TickSize) != -dir)
				stop = dir == 1 ? Math.Max(stop, Position.AveragePrice + BreakEvenPlus * TickSize) : Math.Min(stop, Position.AveragePrice - BreakEvenPlus * TickSize);

			// If our stop is closer to our target then the target value, do nothing
			if (stop.ApproxCompare(dir == 1 ? orderTracker.MaxStopLossValue : orderTracker.MinStopLossValue) != dir)
				return;

			if (stop.ApproxCompare(dir == 1 ? GetCurrentBid() : GetCurrentAsk()) != dir)
				SetStopLoss(stop);
			else
				ExitPosition("Stop loss Cross");
		}

		private void SubmitOrder(int direction, double price)
		{
			if (direction == 0 || !mmCanTrade)
				return;

			var orderPref = direction == 1 ? "L" : "S";

			var quantities = TargetQuantities;

			// Iterate through our orders, checking if it will replace an existing tracked order, and cancelling it if it won't be and is cancellable
			var replacingOrder = Enumerable.Range(0, quantities.Length)
				.Select(i => orderTracker[i] != null)
				.ToArray();
			for (var i = 0; i < quantities.Length; i++)
			{
				if (quantities[i] == 0 || !replacingOrder[i])
					continue;

				// If the order isn't an opposing order and both are market orders, or both target the same limit price, then we are replacing the existing order
				if (orderTracker[i].ARC_PatternFinderAlgo_Direction() != -direction && (orderTracker[i].OrderType != OrderType.Limit || EntryOrderType == ARC_PatternFinderAlgo_EntryOrderType.Limit || orderTracker[i].LimitPrice.ApproxCompare(price) == 0))
					continue;

				if (!orderTracker[i].ARC_PatternFinderAlgo_IsTerminal())
				{
					CancelOrder(orderTracker[i]);
					orderTracker[i] = null;
				}

				replacingOrder[i] = false;
			}

			var rejectedBasedOnPrice = false;
			for (var i = 0; i < quantities.Length; i++)
			{
				if (quantities[i] == 0)
					continue;

				// Process individual orders
				var orderName = orderPref + (i + 1);
				switch (EntryOrderType)
				{
				case ARC_PatternFinderAlgo_EntryOrderType.Market:
					if (orderTracker[i] != null)
						continue;

					orderTracker[i] = direction == 1
						? EnterLong(orderBarsIdx, quantities[i], orderName)
						: EnterShort(orderBarsIdx, quantities[i], orderName);
					break;
				case ARC_PatternFinderAlgo_EntryOrderType.Limit:
					// TODO Move this price protection to cover everything except market orders
					var p = price - direction * LimitEntryOffsetTicks * TickSize;
					if (p.ApproxCompare(direction == 1 ? GetCurrentAsk() : GetCurrentBid()) == direction)
					{
						rejectedBasedOnPrice = true;
						continue;
					}

					if (orderTracker[i] == null)
					{
						orderTracker[i] = direction == 1
							? EnterLongLimit(orderBarsIdx, true, quantities[i], p, orderName)
							: EnterShortLimit(orderBarsIdx, true, quantities[i], p, orderName);
						continue;
					}

					// Determine if this is a switch from stop to limit at the same price
					if (orderTracker[i].OrderType == OrderType.StopMarket && orderTracker[i].StopPrice.ApproxCompare(price) == 0)
						continue;

					if (orderTracker[i].LimitPrice.ApproxCompare(p) == 0)
						continue;

					orderTracker[i] = direction == 1
						? EnterLongLimit(orderBarsIdx, true, quantities[i], p, orderName)
						: EnterShortLimit(orderBarsIdx, true, quantities[i], p, orderName);
					break;
				}
			}

			if (rejectedBasedOnPrice)
				barToPaintAsInvalidPriceCancellation = lastSignalBar + 1;
			else if (EntryOrderType != ARC_PatternFinderAlgo_EntryOrderType.Market && !replacingOrder.Any(i => i))
				orderTracker.lastPendingOrderInitiation = CurrentBars[0];
		}

		/// <summary>
		/// Queues an entry in the provided direction, which will execute on the next available primary bar, as long as it's not preceded by gap bars
		/// </summary>
		protected void QueueEntry(int dir, int signalBarOffset = 0, double? limitPrice = null, double tpMultiple = 1)
		{
			if (signalBarOffset <= 0 && ShowRacingStripes && (PendingEntryDir != dir || pendingTpMultiple.ApproxCompare(tpMultiple) != 0))
				BackBrushes[-signalBarOffset] = dir == 1 ? longStripBrush : shortStripBrush;

			PendingEntryDir = dir;
			pendingTpMultiple = tpMultiple;
			pendingEntryLimitPrice = limitPrice;
			lastSignalDir = dir;
			lastSignalBar = CurrentBars[0] + signalBarOffset;
		}

		protected void SetStopLoss(double price)
		{
			if (Position.MarketPosition == MarketPosition.Flat)
				return;

			if (price <= double.Epsilon)
				return;

			var dir = Position.MarketPosition == MarketPosition.Long ? 1 : -1;
			for (var i = 0; i < orderTracker.Count; i++)
			{
				if (orderTracker.stopLossOrders[i] == null || price.ApproxCompare(orderTracker.stopLossOrders[i].StopPrice) != dir)
					continue;

				if (!orderTracker.stopLossOrders[i].ARC_PatternFinderAlgo_IsTerminal())
					ChangeOrder(orderTracker.stopLossOrders[i], TargetQuantities[i], 0, price);
			}
		}

		protected void ExitPosition(string orderName)
		{
			if (Position.MarketPosition == MarketPosition.Flat || orderTracker.cancelOrders.Any(c => c != null))
				return;

			for (var i = 0; i < 3; i++)
			{
				if (TargetQuantities[i] == 0)
					break;

				var entryName = (Position.MarketPosition == MarketPosition.Long ? "L" : "S") + (i + 1);
				orderTracker.cancelOrders[i] = Position.MarketPosition == MarketPosition.Long 
					? ExitLong(orderBarsIdx, safeEntryCurrentQuantities[entryName], orderName, entryName)
					: ExitShort(orderBarsIdx, safeEntryCurrentQuantities[entryName], orderName, entryName);
			}
		}

		protected void CancelPendingEntries()
		{
			if (!orderTracker.IsPendingEntryOrders)
			{
				PendingEntryDir = 0;
				return;
			}

			orderTracker
				.Where(o => o != null && o.OrderType != OrderType.Market && !o.ARC_PatternFinderAlgo_IsTerminal())
				.ToList()
				.ForEach(CancelOrder);
		}

		private void SetStopToEntryPrice()
		{
			if (Position.MarketPosition == MarketPosition.Flat)
				return;

			var dir = Position.MarketPosition == MarketPosition.Long ? 1 : -1;

			// If the stop closest to where we started is already at or above the entry price, do nothing
			if (Position.AveragePrice.ApproxCompare(dir == 1 ? orderTracker.MinStopLossValue : orderTracker.MaxStopLossValue) != -dir)
				return;

			// If our entry price is on the wrong side of the relevant bid ask price, do nothing
			if ((dir == 1 ? GetCurrentBid() : GetCurrentAsk()).ApproxCompare(Position.AveragePrice) != dir)
				return;
			
			SetStopLoss(Position.AveragePrice);
		}

		private void SetStopToUserOverride()
		{
			if (Position.MarketPosition == MarketPosition.Flat)
				return;
			var dir = Position.MarketPosition == MarketPosition.Long ? 1 : -1;
			var sl = Position.AveragePrice - dir * stopLossUserOverride * TickSize;
			if ((dir == 1 ? GetCurrentBid() : GetCurrentAsk()).ApproxCompare(sl) == dir)
				SetStopLoss(sl);
		}

		private void ProcessPendingEntries(int signalBarOffset = 0)
		{
			if (PendingEntryDir == 0)
				return;

			// Don't enter on any bar occurring after a gap bar
			var curEntry = PendingEntryDir;
			PendingEntryDir = 0;

			if (CurrentBars[0] - signalBarOffset < Math.Max(BarsRequiredToTrade, 1) || CurrentBars[orderBarsIdx] < 1)
				return;

			if (!TradeAllowed(curEntry, ARC_PatternFinderAlgo_ARCFilterType.Direction | ARC_PatternFinderAlgo_ARCFilterType.MoneyManagement | ARC_PatternFinderAlgo_ARCFilterType.Time | ARC_PatternFinderAlgo_ARCFilterType.ConsecutiveTrades | ARC_PatternFinderAlgo_ARCFilterType.ArmState))
				return;

			// Enter if possible and needed, otherwise just exit (limit orders are entered on the execution of the reversal exit)
			var positionOpposesSignal = Position.MarketPosition == (curEntry == 1 ? MarketPosition.Short : MarketPosition.Long);
			lastEntryBar = CurrentBars[0] - signalBarOffset;
			if (positionOpposesSignal && (OnOppositeSignal == ARC_PatternFinderAlgo_OppositeSignalAction.ExitOnly || (OnOppositeSignal == ARC_PatternFinderAlgo_OppositeSignalAction.Reverse && EntryOrderType == ARC_PatternFinderAlgo_EntryOrderType.Limit)))
				ExitPosition(OppositeOrderName);
			if (Position.MarketPosition == MarketPosition.Flat || (positionOpposesSignal && OnOppositeSignal == ARC_PatternFinderAlgo_OppositeSignalAction.Reverse && EntryOrderType == ARC_PatternFinderAlgo_EntryOrderType.Market))
			{
				foreach (var o in orderTracker.stopLossOrders.Concat(orderTracker.targetOrders).Where(o => o != null && !o.ARC_PatternFinderAlgo_IsTerminal()))
					CancelOrder(o);
				SubmitOrder(curEntry, EntryOrderType == ARC_PatternFinderAlgo_EntryOrderType.Limit && pendingEntryLimitPrice != null ? pendingEntryLimitPrice.Value : Closes[0][signalBarOffset]);
			}
		}
		#endregion
		
		/// <summary>
		/// Adds the provided series if it doesn't already exist. Either way returns the index of the data series
		/// </summary>
		protected int EnsureDataSeriesAdded(BarsPeriodType periodType, int period, MarketDataType marketDataType = MarketDataType.Last)
		{
			var idx = Array.FindIndex(BarsPeriods, b => b.BarsPeriodType == periodType && b.Value == period && b.MarketDataType == marketDataType);
			if (idx != -1)
				return idx;

			var bp = (BarsPeriod) BarsPeriods[0].Clone();
			bp.BarsPeriodType = periodType;
			bp.Value = period;
			bp.MarketDataType = marketDataType;
			AddDataSeries(bp);
			return BarsArray.Length - 1;
		}

		private void ResetPerRunCustomValues()
		{
			safeEntryCurrentAvgFillPrices.Clear();
			safeEntryCurrentQuantities.Clear();
			primaryBarOnLastExit = -1;
			orderBarOnLastExit = -1;
			idxOfFirstTickOfCurrentPrimaryBar = -1;
			pendingEntryLimitPrice = null;
			consecutiveTradesInCurrentDir = 0;
			lastTradeDir = 0;
			pendingBarPlotSl = null;
			pendingBarPlotTp = new double?[3];
			lastSessionClosedPnl = 0;
			tradeCountAtLastSessionClosedPnlRefresh = 0;
			lastMmResetAtLastSessionClosedPnlRefresh = default(DateTime);
			tradeCountAtLastMmReset = 0;
			lastMmReset = default(DateTime);
			mmMaxGain = 0;
			mmCanTrade = true;
			firstTickOfPrimaryBar = false;
			pendingFirstNewTimeTickOfPrimaryBar = false;
			lastEntryBar = -1;
			PendingEntryDir = 0;
			barToPaintAsInvalidPriceCancellation = -1;
			lastSignalBar = -1;
			lastSignalDir = 0;
			pendingTpMultiple = 1;
			Armed = true;
		}

		protected virtual void OnPrimaryBar()
		{ }

		protected virtual void OnTickBar()
		{ }

		protected virtual void OnExitExecution(Execution execution, int quantity)
		{ }

		protected virtual void OnEntryExecution(Execution execution, double price, int quantity)
		{ }

		protected bool TradeAllowed(int dir, ARC_PatternFinderAlgo_ARCFilterType consideredFilters = ARC_PatternFinderAlgo_ARCFilterType.AllExceptArmState)
		{
			// Prevent queueing additional entries in the same direction
			if (Position.MarketPosition == (dir == 1 ? MarketPosition.Long : MarketPosition.Short))
				return false;
			
			if (Category == Category.NinjaScript && ((RunType == ARC_PatternFinderAlgo_RunType.RealTime && State == State.Historical) || (RunType == ARC_PatternFinderAlgo_RunType.BackTest && State == State.Realtime)))
				return false;

			if (consideredFilters.HasFlag(ARC_PatternFinderAlgo_ARCFilterType.ArmState) && ManualTradeMode && !Armed && State == State.Realtime)
				return false;

			// Allowed dir
			if (consideredFilters.HasFlag(ARC_PatternFinderAlgo_ARCFilterType.Direction) && AllowedEntryDirections != ARC_PatternFinderAlgo_AllowedEntryDirection.LongAndShort && AllowedEntryDirections != (dir == 1 ? ARC_PatternFinderAlgo_AllowedEntryDirection.LongOnly : ARC_PatternFinderAlgo_AllowedEntryDirection.ShortOnly))
				return false;

			if (!ManualTradeMode)
			{
				if (consideredFilters.HasFlag(ARC_PatternFinderAlgo_ARCFilterType.MoneyManagement) && !mmCanTrade)
					return false;

				if (consideredFilters.HasFlag(ARC_PatternFinderAlgo_ARCFilterType.ConsecutiveTrades))
				{
					// Prevent opposing signals if ignoring reversals
					if (OnOppositeSignal == ARC_PatternFinderAlgo_OppositeSignalAction.None && Position.MarketPosition != MarketPosition.Flat)
						return false;

					if (LimitConsecutiveTradesInDirection && dir == lastTradeDir && consecutiveTradesInCurrentDir >= MaxConsecutiveTradesInDirection)
						return false;

					// Block entries on bars where we've exited
					if (!AllowEntriesOnExitBars && primaryBarOnLastExit >= CurrentBars[0] && orderBarOnLastExit >= idxOfFirstTickOfCurrentPrimaryBar)
						return false;
				}

				// Time window
				if (consideredFilters.HasFlag(ARC_PatternFinderAlgo_ARCFilterType.Time) && !InValidTradingWindow(Times[orderBarsIdx][0]))
					return false;
			}

			if (!consideredFilters.HasFlag(ARC_PatternFinderAlgo_ARCFilterType.TaFilters))
				return true;

			// Excursion blocking
			if (BlockLevelEntry != 0)
			{
				Series<double> series;
				switch (BlockLevelEntry)
				{
				case 1:
					series = dir == 1 ? indMomo.PriceExcursionUL1 : indMomo.PriceExcursionLL1;
					break;
				case 2:
					series = dir == 1 ? indMomo.PriceExcursionUL2 : indMomo.PriceExcursionLL2;
					break;
				case 3:
					series = dir == 1 ? indMomo.PriceExcursionUL3 : indMomo.PriceExcursionLL3;
					break;
				default:
					throw new Exception("Invalid Block Level Entry Setting");
				}

				if (indMomo.Histogram[0].ApproxCompare(series[0]) != -dir)
					return false;
			}

			// VM bias / confluence
			if (!OverridesVMBiasAndConfluenceHandling)
			{
				// Momo Color
				if (UseVMBias && (VMBiasType == ARC_PatternFinderAlgo_VMAlgo_BiasType.ZeroLine ? indMomo.Histogram : indMomo.StructureBiasState)[0].ApproxCompare(0) != dir)
					return false;

				// Momo Confluence
				if (UseVMConfluence && indMomo.BBMACD[0].ApproxCompare(0) != dir)
					return false;
			}

			// Ma filter
			if (UseHTFMovingAverage)
			{
				if (MAType != ARC_PatternFinderAlgo_MovingAverageType.StepMA && CurrentBars[htfBarsIdx] < 0)
					return false;

				if (MAType == ARC_PatternFinderAlgo_MovingAverageType.StepMA && FilterMATrendType == ARC_PatternFinderAlgo_StepMaTrendType.Trend)
				{
					if (((ARC_PatternFinderAlgo_ARC_TrendStepper) filterMa).LastMovementDir != dir)
						return false;
				}
				else
				{
					if (Closes[0][0].ApproxCompare(filterMa[0]) != dir)
						return false;

					var anchor = dir == 1
						? Lows[0][0] * MABarBiasPercentRequirement / 100 + Highs[0][0] * (1 - MABarBiasPercentRequirement / 100)
						: Highs[0][0] * MABarBiasPercentRequirement / 100 + Lows[0][0] * (1 - MABarBiasPercentRequirement / 100);

					if (anchor.ApproxCompare(filterMa[0]) != dir)
						return false;
				}
			}

			// Market structure filter
			if (UseMsFilter)
			{
				if (msFilterZigZag.SwingPoints.Count < 5)
					return false;

				// Select the prices of the last 4 finalized zig zag points
				var lastPoints = msFilterZigZag.SwingPoints
					.Skip(msFilterZigZag.SwingPoints.Count - 5)
					.Take(4)
					.ToArray();

				// Points alternate between high and low, so compare in pairs separated by 1 to ensure directionality
				if (lastPoints[2].Price.ApproxCompare(lastPoints[0].Price) != dir || lastPoints[3].Price.ApproxCompare(lastPoints[1].Price) != dir)
					return false;

				// Ensure our last point doesn't break the chain
				if (msFilterZigZag.SwingPoints.Last().Price.ApproxCompare(lastPoints[3].Price) != dir)
					return false;
			}

			return true;
		}

		private void SyncPnlPlot()
		{
			indPnlChart.OpenPnl = Position.MarketPosition == MarketPosition.Flat ? 0 : Position.GetUnrealizedProfitLoss(PerformanceUnit.Currency, Closes[orderBarsIdx][0]);
			if (Position.MarketPosition == MarketPosition.Flat)
			{
				indPnlChart.SessionClosedPnl = SessionClosedPnl;
				indPnlChart.ChartTotalClosedPnl = ChartClosedPnl;
			}

			var plotIdx = !DashHistoricPnl || State == State.Realtime ? 0 : 1;
			indPnlChart.Values[plotIdx][0] = indPnlChart.ChartTotalClosedPnl + indPnlChart.OpenPnl;
			indPnlChart.PlotBrushes[plotIdx][0] = indPnlChart.Values[plotIdx][0] < 0 ? Brushes.Red : Brushes.Green;
		}

		private void SyncStopPlots()
		{
			var sl = pendingBarPlotSl ?? orderTracker.MinStopLossValue;
			pendingBarPlotSl = null;
			if (sl > double.Epsilon)
				indStopTrg.SetStop(sl);
		}

		private void SyncTargetPlots()
		{
			for (var i = 0; i < orderTracker.Count; i++)
			{
				var order = orderTracker.targetOrders[i];
				if (pendingBarPlotTp[i] == null && (order == null || order.ARC_PatternFinderAlgo_IsTerminal()))
					continue;
				
				var tp = pendingBarPlotTp[i] ?? (UseMitTargetOrders ? order.StopPrice : order.LimitPrice);
				pendingBarPlotTp[i] = null;
				indStopTrg.SetTarget(tp, i);
			}
		}

		private void ResetMoneyManagement()
		{
			lastSessionClosedPnl = 0;
			mmMaxGain = 0;
			lastMmReset = Times[orderBarsIdx][0];
			tradeCountAtLastMmReset = SystemPerformance.AllTrades.Count;
			tradeCountAtLastSessionClosedPnlRefresh = tradeCountAtLastMmReset;
			mmCanTrade = true;
			indPnlChart.SessionClosedPnl = 0;
		}

		private void SyncMoneyManagement(double price)
		{
			// Get current session open pnl
			var unRealizedPnl = Position == null || Position.MarketPosition == MarketPosition.Flat ? 0d : Position.GetUnrealizedProfitLoss(PerformanceUnit.Currency, price);
			var sessionOpenPnl = SessionClosedPnl;
			if (HighWaterMarkType == ARC_PatternFinderAlgo_HighWaterMarkType.RealizedPlusUnrealized)
				sessionOpenPnl += unRealizedPnl;

			// Track high watermark
			if (HighWaterMarkType != ARC_PatternFinderAlgo_HighWaterMarkType.Off) 
				mmMaxGain = Math.Max(mmMaxGain, sessionOpenPnl);

			// If we're already out of trading, do nothing
			if (!mmCanTrade)
				return;

			string messageCore;

			// High watermark
			if (HighWaterMarkType != ARC_PatternFinderAlgo_HighWaterMarkType.Off && mmMaxGain.ApproxCompare(HwmActivatedAt) >= 0 && sessionOpenPnl.ApproxCompare(mmMaxGain * (1 - DailyHighWaterMarkPct / 100)) <= 0)
				messageCore = "Higher water mark %";
			// Daily max gain
			else if (DayMaxGain != 0 && (SessionClosedPnl + unRealizedPnl).ApproxCompare(DayMaxGain) >= 0)
				messageCore = "Daily Profit Goal";
			// Daily max loss
			else if (DayMaxLoss != 0 && (SessionClosedPnl + unRealizedPnl).ApproxCompare(-DayMaxLoss) <= 0)
				messageCore = "Max Daily Loss";
			else
				return;

			mmCanTrade = false;
			// In back tests exit the position, in realtime, warn the user that we won't exit the trade for them, and how to do so themselves
			if (State == State.Realtime)
			{
				const string messageFormat = "Money Management [{0}, {1}, {2}]: {3} has been reached.\nTrading will be halted automatically AFTER the current trade is closed.\nTo close the current trade NOW, click OFF in the UI dropdown menu.";
				var message = string.Format(messageFormat, Name, Instrument.FullName, Account.DisplayName, messageCore);
				Dispatcher.InvokeAsync(() => NTMessageBox.Show(message, "Warning!", MessageBoxButton.OK, MessageBoxImage.Asterisk));
				Log(message, LogLevel.Warning);
			}
			else
			{
				ExitPosition(messageCore);
			}
		}

		protected bool InValidTradingWindow(DateTime t)
		{
			if (StartTime == 0 && EndTime == 0)
				return true;

			if (IgnoreTradeTime)
				return true;

			return (t.DayOfWeek != DayOfWeek.Friday || t.ARC_PatternFinderAlgo_CompareTime(2500) != 1) && t.ARC_PatternFinderAlgo_InRange(StartTime, EndTime);
		}

		public override string ToString()
		{
			return ProductName + " " + ProductVersion;
		}

		#region Parameters
		protected const string StrategyParameterGroupName = "Strategy Parameters";
		protected const string StrategyVisualsParameterGroupName = "Strategy Visuals";
		protected const string ProductInfoGroupName = "Product Info";

		[XmlIgnore, Browsable(false)]
		[ARC_PatternFinderAlgo_HideOthersIf(ARC_PatternFinderAlgo_PropComparisonType.EQ, true, Groups = new [] { TimeControlGroupName, MoneyManagementGroupName, MiscFiltersGroupName }, Properties = new []{ "OnOppositeSignal" })]
		public bool ManualTradeMode { get { return Category == Category.NinjaScript && AutoDisarm; } }

		/*
		 * NOTE: For bool properties that conditional property depend on, we must use a bool enum property as an intermediate, or it won't work in optimization.
		 */

		#region Entry
		protected const string EntryGroupName = "Entries";

		[NinjaScriptProperty]
		[Display(Name = "Entry Direction", Order = 1, GroupName = EntryGroupName, Description = "Entry Direction")]
		public ARC_PatternFinderAlgo_AllowedEntryDirection AllowedEntryDirections { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Quantity 1", Order = 2, GroupName = EntryGroupName, Description = "Quantity associated with entry 1")]
		[XmlElement("Target1Quantity")]
		public int Entry1Quantity { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[RefreshProperties(RefreshProperties.All)]
		[XmlElement("Target2Quantity")]
		[Display(Name = "Quantity 2", Order = 3, GroupName = EntryGroupName, Description = "Quantity associated with entry 2")]
		public int Entry2Quantity { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[RefreshProperties(RefreshProperties.All)]
		[XmlElement("Target3Quantity")]
		[Display(Name = "Quantity 3", Order = 4, GroupName = EntryGroupName, Description = "Quantity associated with entry 3")]
		public int Entry3Quantity { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Entry Order Type", Order = 5, GroupName = EntryGroupName, Description = "Entry Order Type")]
		public ARC_PatternFinderAlgo_EntryOrderType EntryOrderType { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[ARC_PatternFinderAlgo_HideUnless("EntryOrderType", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_EntryOrderType.Limit)]
		[Display(Name = "Entry Offset Ticks", Order = 6, GroupName = EntryGroupName, Description = "Offset ticks for Limit Order")]
		public int LimitEntryOffsetTicks { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[ARC_PatternFinderAlgo_HideUnless("EntryOrderType", ARC_PatternFinderAlgo_PropComparisonType.NEQ, ARC_PatternFinderAlgo_EntryOrderType.Market)]
		[Display(Name = "Max Pending Order Distance", Order = 7, GroupName = EntryGroupName)]
		public int MaxPendingOrderDistance { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Action On Opposite Signal", Order = 8, GroupName = EntryGroupName)]
		public ARC_PatternFinderAlgo_OppositeSignalAction OnOppositeSignal { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[ARC_PatternFinderAlgo_HideUnless("EntryOrderType", ARC_PatternFinderAlgo_PropComparisonType.NEQ, ARC_PatternFinderAlgo_EntryOrderType.Market)]
		[Display(Name = "Max Pending Order Bars", Order = 9, GroupName = EntryGroupName)]
		public int MaxPendingOrderBars { get; set; }
		
		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_PatternFinderAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_PatternFinderAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Limit Pre-Order Gap Bars", Order = 10, GroupName = EntryGroupName)]
		public ARC_PatternFinderAlgo_BoolEnum LimitPreOrderGapBarsEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool LimitPreOrderGapBars
		{
			get { return LimitPreOrderGapBarsEnum == ARC_PatternFinderAlgo_BoolEnum.True; }
			set { LimitPreOrderGapBarsEnum = value ? ARC_PatternFinderAlgo_BoolEnum.True : ARC_PatternFinderAlgo_BoolEnum.False; }
		}

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[ARC_PatternFinderAlgo_HideUnless("LimitPreOrderGapBarsEnum", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_BoolEnum.True)]
		[Display(Name = "Max Pre-Order Gap Bars", Order = 11, GroupName = EntryGroupName)]
		public int MaxPreOrderGapBars { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Allow Entries on Exit Bars", Order = 12, GroupName = EntryGroupName)]
		public bool AllowEntriesOnExitBars { get; set; }

		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_PatternFinderAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_PatternFinderAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Auto Disarm", Order = 13, GroupName = EntryGroupName)]
		public ARC_PatternFinderAlgo_BoolEnum AutoDisarmEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool AutoDisarm
		{
			get { return AutoDisarmEnum == ARC_PatternFinderAlgo_BoolEnum.True; }
			set { AutoDisarmEnum = value ? ARC_PatternFinderAlgo_BoolEnum.True : ARC_PatternFinderAlgo_BoolEnum.False; }
		}

		[NinjaScriptProperty]
		[Display(Name = "Run Type", Description = "Set to Backtest when backtesting, RealTime when trading in real-time", Order = 14, GroupName = EntryGroupName)]
		public ARC_PatternFinderAlgo_RunType RunType { get; set; }
		#endregion

		#region Stops
		protected const string StopLossGroupName = "Stop Losses";

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Stop Loss Type", Order = 0, GroupName = StopLossGroupName)]
		public ARC_PatternFinderAlgo_StopLossType StopLossType { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_PatternFinderAlgo_HideUnless("StopLossType", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_StopLossType.ATR)]
		[Display(Name = "Stop Loss ATR Period", Order = 1, GroupName = StopLossGroupName)]
		public int StopLossATRPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_PatternFinderAlgo_Rename("Stop Loss (Ticks)", "StopLossType", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_StopLossType.Ticks)]
		[ARC_PatternFinderAlgo_Rename("Stop Loss (ATRs)", "StopLossType", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_StopLossType.ATR)]
		[XmlElement("StopLossTicks")]
		[Display(Name = "Stop Loss", Order = 2, GroupName = StopLossGroupName)]
		public double StopLoss { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "Trail Trigger", Order = 3, GroupName = StopLossGroupName, Description = "Number of ticks to in profit to enable the trail")]
		public int TrailTriggerTicks { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "Trail # Bars Back", Order = 4, GroupName = StopLossGroupName, Description = "Set this to 1 for tight management, greater than 1 for loose management (where the value you place is the number of bars lookback for the high / low price)")]
		public int TrailLookbackBars { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name = "Trail Tick Offset", Order = 5, GroupName = StopLossGroupName, Description = "Offset ticks for trail.")]
		public double TrailTicks { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Range(0, double.MaxValue)]
		[Display(Name = "BreakEven Trigger", Order = 6, GroupName = StopLossGroupName, Description = "Number of ticks in profit to break event")]
		public double BreakEvenTrigger { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_PatternFinderAlgo_HideUnless("BreakEvenTrigger", ARC_PatternFinderAlgo_PropComparisonType.NEQ, 0d)]
		[Display(Name = "BreakEven Plus", Order = 7, GroupName = StopLossGroupName)]
		public double BreakEvenPlus { get; set; }
		#endregion

		#region Targets
		protected const string TargetsGroupName = "Targets";

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Target Type", Order = 0, GroupName = TargetsGroupName)]
		public ARC_PatternFinderAlgo_TargetType TargetType { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_PatternFinderAlgo_HideUnless("TargetType", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_TargetType.ATR)]
		[Display(Name = "ATR Period", Order = 1, GroupName = TargetsGroupName)]
		public int TargetATRPeriod { get; set; }

		[NinjaScriptProperty]
		[XmlElement("UseMITsForTargets")]
		[Display(Name = "Use MIT Targets", Order = 2, GroupName = TargetsGroupName)]
		public bool UseMitTargetOrders { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_PatternFinderAlgo_Rename("Profit Target 1 (Ticks)", "TargetType", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_TargetType.Ticks)]
		[ARC_PatternFinderAlgo_Rename("Profit Target 1 (ATRs)", "TargetType", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_TargetType.ATR)]
		[ARC_PatternFinderAlgo_Rename("Profit Target 1 (RR)", "TargetType", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_TargetType.RR)]
		[Display(Name = "Profit Target 1", Description = "Static St = # Ticks, RR = Multiplier factor", Order = 3, GroupName = TargetsGroupName)]
		[XmlElement("ProfitTargetTicks1")]
		public double ProfitTargetValue1 { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_PatternFinderAlgo_HideUnless("Entry2Quantity", ARC_PatternFinderAlgo_PropComparisonType.GT, 0)]
		[ARC_PatternFinderAlgo_Rename("Profit Target 2 (Ticks)", "TargetType", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_TargetType.Ticks)]
		[ARC_PatternFinderAlgo_Rename("Profit Target 2 (ATRs)", "TargetType", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_TargetType.ATR)]
		[ARC_PatternFinderAlgo_Rename("Profit Target 2 (RR)", "TargetType", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_TargetType.RR)]
		[XmlElement("ProfitTargetTicks2")]
		[Display(Name = "Profit Target 2", Description = "Static St = # Ticks, RR = Multiplier factor", Order = 4, GroupName = TargetsGroupName)]
		public double ProfitTargetValue2 { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_PatternFinderAlgo_HideUnless("Entry3Quantity", ARC_PatternFinderAlgo_PropComparisonType.GT, 0)]
		[ARC_PatternFinderAlgo_Rename("Profit Target 3 (Ticks)", "TargetType", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_TargetType.Ticks)]
		[ARC_PatternFinderAlgo_Rename("Profit Target 3 (ATRs)", "TargetType", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_TargetType.ATR)]
		[ARC_PatternFinderAlgo_Rename("Profit Target 3 (RR)", "TargetType", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_TargetType.RR)]
		[XmlElement("ProfitTargetTicks3")]
		[Display(Name = "Profit Target 3", Description = "Static St = # Ticks, RR = Multiplier factor", Order = 5, GroupName = TargetsGroupName)]
		public double ProfitTargetValue3 { get; set; }
		#endregion

		#region Time Controls
		private const string TimeControlGroupName = "Time Controls";

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "Trade Start Time", Order = 1, GroupName = TimeControlGroupName, Description = "Time in hhmm 24-hour format")]
		public int StartTime { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "Trade End Time", Order = 2, GroupName = TimeControlGroupName, Description = "Time in hhmm 24-hour format")]
		public int EndTime { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Exit At End Time", Order = 3, GroupName = TimeControlGroupName, Description = "Set to true to exit at the end time, false otherwise")]
		public bool ExitAtEndTime { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Ignore Trade Time", Order = 4, GroupName = TimeControlGroupName, Description = "Set true to trade all the time")]
		public bool IgnoreTradeTime { get; set; }
		#endregion

		#region Money Management
		private const string MoneyManagementGroupName = "Money Management";
		
		[NinjaScriptProperty]
		[Display(Name = "Reset Pnl On Time Slot", Order = 1, GroupName = MoneyManagementGroupName, Description = "Restart Pnl Calculation at each time slot")]
		public bool RestartPnlOnSession { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "DayMaxGoal $", Order = 2, GroupName = MoneyManagementGroupName, Description = "Day Gain when achieved stop trading. 0 to disable")]
		public int DayMaxGain { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "DayMaxLoss $", Order = 3, GroupName = MoneyManagementGroupName, Description = "Day Loss when achieved stop trading. 0 to disable")]
		public int DayMaxLoss { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "High Water Mark", Order = 4, GroupName = MoneyManagementGroupName, Description = "Day High Water Mark")]
		public ARC_PatternFinderAlgo_HighWaterMarkType HighWaterMarkType { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_PatternFinderAlgo_HideUnless("HighWaterMarkType", ARC_PatternFinderAlgo_PropComparisonType.NEQ, ARC_PatternFinderAlgo_HighWaterMarkType.Off)]
		[Display(Name = "High Water Mark %", Order = 5, GroupName = MoneyManagementGroupName, Description = "Day High Water Mark % DrawDown. 0 to disable")]
		public double DailyHighWaterMarkPct { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[ARC_PatternFinderAlgo_HideUnless("HighWaterMarkType", ARC_PatternFinderAlgo_PropComparisonType.NEQ, ARC_PatternFinderAlgo_HighWaterMarkType.Off)]
		[Display(Name = "HWM Activated at $", Order = 6, GroupName = MoneyManagementGroupName, Description = "Min profit in dollars for the High Water Mark to activate")]
		public int HwmActivatedAt { get; set; }
		#endregion

		#region Misc. Filters
		private const string MiscFiltersGroupName = "Misc. Filters";

		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_PatternFinderAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_PatternFinderAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Limit Consecutive Trades in Direction", Order = 0, GroupName = MiscFiltersGroupName)]
		public ARC_PatternFinderAlgo_BoolEnum LimitConsecutiveTradesInDirectionEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool LimitConsecutiveTradesInDirection
		{
			get { return LimitConsecutiveTradesInDirectionEnum == ARC_PatternFinderAlgo_BoolEnum.True; }
			set { LimitConsecutiveTradesInDirectionEnum = value ? ARC_PatternFinderAlgo_BoolEnum.True : ARC_PatternFinderAlgo_BoolEnum.False; }
		}

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_PatternFinderAlgo_HideUnless("LimitConsecutiveTradesInDirectionEnum", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_BoolEnum.True)]
		[Display(Name = "Max Consecutive Trades in Direction", Order = 1, GroupName = MiscFiltersGroupName)]
		public int MaxConsecutiveTradesInDirection { get; set; }
		
		[NinjaScriptProperty]
		[ARC_PatternFinderAlgo_HideUnless("LimitConsecutiveTradesInDirectionEnum", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_BoolEnum.True)]
		[Display(Name = "Reset Consecutive Trade Count on Session Close", Order = 2, GroupName = MiscFiltersGroupName)]
		public bool ResetConsecutiveTradeCountOnSessionClose { get; set; }
		#endregion

		#region HTF Moving Averages
		private const string HTFMovingAveragesGroupName = "Moving Averages Filter";

		[RefreshProperties(RefreshProperties.All)]
		[ARC_PatternFinderAlgo_ShowOthersIf(ARC_PatternFinderAlgo_PropComparisonType.EQ, true, Properties = new []{ "MAType", "MATimeframe", "MAPeriod", "FilterMAStepSize" })]
		[Display(Name = "Show", Order = 0, GroupName = HTFMovingAveragesGroupName, Description = "Whether the strategy shows the moving average")]
		public bool ShowMA { get; set; }

		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_PatternFinderAlgo_ShowOthersIf(ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_BoolEnum.True, Properties = new []{ "MAType", "MATimeframe", "MAPeriod", "FilterMAStepSize" })]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_PatternFinderAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_PatternFinderAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Require", Order = 1, GroupName = HTFMovingAveragesGroupName)]
		public ARC_PatternFinderAlgo_BoolEnum UseHTFMovingAverageEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool UseHTFMovingAverage
		{
			get { return UseHTFMovingAverageEnum == ARC_PatternFinderAlgo_BoolEnum.True; }
			set { UseHTFMovingAverageEnum = value ? ARC_PatternFinderAlgo_BoolEnum.True : ARC_PatternFinderAlgo_BoolEnum.False; }
		}
		
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_PatternFinderAlgo_HideByDefault]
		[Display(Name = "Type", Order = 2, GroupName = HTFMovingAveragesGroupName, Description = "Moving average type")]
		public ARC_PatternFinderAlgo_MovingAverageType MAType { get; set; }

		[Range(1, int.MaxValue)]
		[ARC_PatternFinderAlgo_HideByDefault]
		[ARC_PatternFinderAlgo_HideUnless("MAType", ARC_PatternFinderAlgo_PropComparisonType.NEQ, ARC_PatternFinderAlgo_MovingAverageType.StepMA)]
		[Display(Name = "Timeframe Minutes", Order = 3, GroupName = HTFMovingAveragesGroupName, Description = "Timeframe to calculate moving average on in minutes")]
		public int MATimeframe { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_PatternFinderAlgo_HideByDefault]
		[ARC_PatternFinderAlgo_HideUnless("MAType", ARC_PatternFinderAlgo_PropComparisonType.NEQ, ARC_PatternFinderAlgo_MovingAverageType.StepMA)]
		[Display(Name = "Period", Order = 4, GroupName = HTFMovingAveragesGroupName, Description = "Period of the filter moving average")]
		public int MAPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_PatternFinderAlgo_HideByDefault]
		[ARC_PatternFinderAlgo_HideUnless("MAType", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_MovingAverageType.StepMA)]
		[Display(Name = "Step Size", Order = 5, GroupName = HTFMovingAveragesGroupName, Description = "Step size of the filter moving average")]
		public int FilterMAStepSize { get; set; }

		[NinjaScriptProperty]
		[ARC_PatternFinderAlgo_HideUnless("UseHTFMovingAverageEnum", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_BoolEnum.True)]
		[ARC_PatternFinderAlgo_HideUnless("MAType", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_MovingAverageType.StepMA)]
		[Display(Name = "Step Method", Order = 6, GroupName = HTFMovingAveragesGroupName, Description = "The method step MA will use to determine direction")]
		public ARC_PatternFinderAlgo_StepMaTrendType FilterMATrendType { get; set; }

		[NinjaScriptProperty]
		[Range(0, 100)]
		[ARC_PatternFinderAlgo_HideUnless("UseHTFMovingAverageEnum", ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_BoolEnum.True)]
		[Display(Name = "Bar % HTF MA", Order = 7, GroupName = HTFMovingAveragesGroupName, Description = "The minimum percentage of the bar that must be on the right side of the MA.")]
		public double MABarBiasPercentRequirement { get; set; }

		[XmlIgnore]
		[ARC_PatternFinderAlgo_HideUnless("ShowMA", ARC_PatternFinderAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Color", Order = 8, GroupName = HTFMovingAveragesGroupName)]
		public Brush MAColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string MAColorSerializable
		{
			get { return Serialize.BrushToString(MAColor); }
			set { MAColor = Serialize.StringToBrush(value); }
		}
		#endregion

		#region Market Structure Filter
		protected const string MarketStructureFilterGroupName = "Market Structure Filter";
		
		[RefreshProperties(RefreshProperties.All)]
		[ARC_PatternFinderAlgo_ShowOthersIf(ARC_PatternFinderAlgo_PropComparisonType.EQ, true, Properties = new[] { "MsFilterSwingStrength", "MsFilterNeutralColor", "MsFilterUptrendColor", "MsFilterDowntrendColor" })]
		[Display(Name = "Show Zig Zag", Order = 0, GroupName = MarketStructureFilterGroupName, Description = "Whether the strategy shows the zigzag")]
		public bool ShowMsFilterZigZag { get; set; }
		
		[RefreshProperties(RefreshProperties.All)]
		[ARC_PatternFinderAlgo_ShowOthersIf(ARC_PatternFinderAlgo_PropComparisonType.EQ, true, Properties = new[] { "MsFilterSwingStrength", "MsFilterNeutralColor", "MsFilterUptrendColor", "MsFilterDowntrendColor" })]
		[Display(Name = "Show Bias Strip", Order = 1, GroupName = MarketStructureFilterGroupName, Description = "Whether the strategy shows bias strip at the bottom of the main panel")]
		public bool ShowMsFilterBiasStrip { get; set; }
		
		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_PatternFinderAlgo_ShowOthersIf(ARC_PatternFinderAlgo_PropComparisonType.EQ, ARC_PatternFinderAlgo_BoolEnum.True, Properties = new[] { "MsFilterSwingStrength" })]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_PatternFinderAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_PatternFinderAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Require", Order = 2, GroupName = MarketStructureFilterGroupName)]
		public ARC_PatternFinderAlgo_BoolEnum UseMsFilterEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool UseMsFilter
		{
			get { return UseMsFilterEnum == ARC_PatternFinderAlgo_BoolEnum.True; }
			set { UseMsFilterEnum = value ? ARC_PatternFinderAlgo_BoolEnum.True : ARC_PatternFinderAlgo_BoolEnum.False; }
		}
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_PatternFinderAlgo_HideByDefault]
		[Display(Order = 3, Name = "Swing Strength", GroupName = MarketStructureFilterGroupName, Description = "Number of bars used to identify a swing high or low")]
		public int MsFilterSwingStrength { get; set; }
		
		[NinjaScriptProperty]
		[Display(Order = 4, Name = "Include Wicks", GroupName = MarketStructureFilterGroupName, Description = "Whether or not to use wicks (vs closes) for pivot points")]
		public bool MsFilterIncludeWicks { get; set; }
		
		[XmlIgnore]
		[ARC_PatternFinderAlgo_HideByDefault]
		[Display(Name = "Neutral Zig Zag Color", Order = 5, GroupName = MarketStructureFilterGroupName)]
		public Brush MsFilterNeutralColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string MsFilterNeutralColorSerializable
		{
			get { return Serialize.BrushToString(MsFilterNeutralColor); }
			set { MsFilterNeutralColor = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[ARC_PatternFinderAlgo_HideByDefault]
		[Display(Name = "Uptrend Color", Order = 6, GroupName = MarketStructureFilterGroupName)]
		public Brush MsFilterUptrendColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string MsFilterUptrendColorSerializable
		{
			get { return Serialize.BrushToString(MsFilterUptrendColor); }
			set { MsFilterUptrendColor = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[ARC_PatternFinderAlgo_HideByDefault]
		[Display(Name = "Downtrend Color", Order = 7, GroupName = MarketStructureFilterGroupName)]
		public Brush MsFilterDowntrendColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string MsFilterDowntrendColorSerializable
		{
			get { return Serialize.BrushToString(MsFilterDowntrendColor); }
			set { MsFilterDowntrendColor = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Range(1e-5f, float.MaxValue)]
		[ARC_PatternFinderAlgo_HideUnless("ShowMsFilterZigZag", ARC_PatternFinderAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Zig Zag Thickness", Order = 8, GroupName = MarketStructureFilterGroupName)]
		public float MsFilterZigZagThickness { get; set; }
		
		[NinjaScriptProperty]
		[Range(1e-5f, float.MaxValue)]
		[ARC_PatternFinderAlgo_HideUnless("ShowMsFilterBiasStrip", ARC_PatternFinderAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Bias Strip Thickness", Order = 9, GroupName = MarketStructureFilterGroupName)]
		public float MsFilterBiasStripThickness { get; set; }
		#endregion

		#region VM Parameters
		protected const string VMLeanGroupName = "VM Lean";
		
		[RefreshProperties(RefreshProperties.All)]
		[ARC_PatternFinderAlgo_HideOthersIf(ARC_PatternFinderAlgo_PropComparisonType.EQ, false, Groups = new []{ VMLeanPlotsGroupName })]
		[Display(Name = "Show VM Sub Panel", Order = 0, GroupName = VMLeanGroupName)]
		public bool ShowVMAlgo { get; set; }

		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_PatternFinderAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_PatternFinderAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Require VM Histo Bias", Order = 1, GroupName = VMLeanGroupName)]
		public ARC_PatternFinderAlgo_BoolEnum UseVMBiasEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool UseVMBias
		{
			get { return UseVMBiasEnum == ARC_PatternFinderAlgo_BoolEnum.True; }
			set { UseVMBiasEnum = value ? ARC_PatternFinderAlgo_BoolEnum.True : ARC_PatternFinderAlgo_BoolEnum.False; }
		}
		
		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_PatternFinderAlgo_BoolEnumConverter")]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_PatternFinderAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Require VM BB Bias", Order = 2, GroupName = VMLeanGroupName)]
		public ARC_PatternFinderAlgo_BoolEnum UseVMConfluenceEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool UseVMConfluence
		{
			get { return UseVMConfluenceEnum == ARC_PatternFinderAlgo_BoolEnum.True; }
			set { UseVMConfluenceEnum = value ? ARC_PatternFinderAlgo_BoolEnum.True : ARC_PatternFinderAlgo_BoolEnum.False; }
		}

		[NinjaScriptProperty]
		[Range(0, 3)]
		[Display(Name = "Enable Block Level", Order = 3, GroupName = VMLeanGroupName, Description = "0 to disable, this is the level at which to block if the histogram level is above / below")]
		public int BlockLevelEntry { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "VM Bias Type", Order = 4, GroupName = VMLeanGroupName)]
		public ARC_PatternFinderAlgo_VMAlgo_BiasType VMBiasType { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "VM Histogram Background", Order = 5, GroupName = VMLeanGroupName)]
		public bool VMHistogramBackground { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Period Bollinger Band", Order = 6, GroupName = VMLeanGroupName, Description = "Band Period for Bollinger Band")]
		public int BandPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Lookback fast EMA", Order = 7, GroupName = VMLeanGroupName, Description = "Period for fast EMA")]
		public int Fast { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Lookback slow EMA", Order = 8, GroupName = VMLeanGroupName, Description = "Period for slow EMA")]
		public int Slow { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name = "Std. dev. multiplier", Order = 9, GroupName = VMLeanGroupName, Description = "Number of standard deviations")]
		public double StdDevNumber { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Swing strength", Order = 10, GroupName = VMLeanGroupName, Description = "Number of bars used to identify a swing high or low")]
		public int VMSwingStrength { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name = "Deviation multiplier", Order = 11, GroupName = VMLeanGroupName, Description = "Multiplier used to calculate minimum deviation as an ATR multiple")]
		public double MinDeviationMultiplier { get; set; }
		#endregion

		#region VM Plot Colors
		private const string VMLeanPlotsGroupName = "VM Lean Visuals";

		[XmlIgnore]
		[Display(Name = "Rising dots above channel", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 0)]
		public Brush DotsUpRisingColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DotsUpRisingColorSerialize
		{
			get { return Serialize.BrushToString(DotsUpRisingColor); }
			set { DotsUpRisingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Rising dots inside/below channel ", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 1)]
		public Brush DotsDownRisingColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DotsDownRisingColorSerialize
		{
			get { return Serialize.BrushToString(DotsDownRisingColor); }
			set { DotsDownRisingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Falling dots below channel ", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 2)]
		public Brush DotsDownFallingColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DotsDownFallingColorSerialize
		{
			get { return Serialize.BrushToString(DotsDownFallingColor); }
			set { DotsDownFallingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Falling dots inside/above channel ", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 3)]
		public Brush DotsUpFallingColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DotsUpFallingColorSerialize
		{
			get { return Serialize.BrushToString(DotsUpFallingColor); }
			set { DotsUpFallingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Dots rim", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 4)]
		public Brush DotsRimColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DotsRimColorSerialize
		{
			get { return Serialize.BrushToString(DotsRimColor); }
			set { DotsRimColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bollinger average", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 5)]
		public Brush BBAverageColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string BBAverageColorSerialize
		{
			get { return Serialize.BrushToString(BBAverageColor); }
			set { BBAverageColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bollinger upper band", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 6)]
		public Brush BBUpperColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string BBUpperColorSerialize
		{
			get { return Serialize.BrushToString(BBUpperColor); }
			set { BBUpperColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bollinger lower band", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 7)]
		public Brush BBLowerColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string BBLowerColorSerialize
		{
			get { return Serialize.BrushToString(BBLowerColor); }
			set { BBLowerColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Momo Histogram Hi Color", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 8)]
		public Brush HistUpColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string HistUpColorSerialize
		{
			get { return Serialize.BrushToString(HistUpColor); }
			set { HistUpColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Momo Histogram Down Color", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 9)]
		public Brush HistDownColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string HistDownColorSerialize
		{
			get { return Serialize.BrushToString(HistDownColor); }
			set { HistDownColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Zeroline", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 10)]
		public Brush ZeroLineColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ZeroLineColorSerialize
		{
			get { return Serialize.BrushToString(ZeroLineColor); }
			set { ZeroLineColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Connector", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 11)]
		public Brush ConnectorColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ConnectorColorSerialize
		{
			get { return Serialize.BrushToString(ConnectorColor); }
			set { ConnectorColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Channel shading", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 12)]
		public Brush ChannelColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ChannelColorSerialize
		{
			get { return Serialize.BrushToString(ChannelColor); }
			set { ChannelColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Deep Bearish background flooding", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 13)]
		public Brush DeepBearishBackgroundColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DeepBearishBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(DeepBearishBackgroundColor); }
			set { DeepBearishBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bearish background flooding", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 14)]
		public Brush BearishBackgroundColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string BearishBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(BearishBackgroundColor); }
			set { BearishBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Opposite background flooding", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 15)]
		public Brush OppositeBackgroundColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string OppositeBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(OppositeBackgroundColor); }
			set { OppositeBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bullish background flooding", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 16)]
		public Brush BullishBackgroundColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string BullishBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(BullishBackgroundColor); }
			set { BullishBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Deep Bullish background flooding", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 17)]
		public Brush DeepBullishBackgroundColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DeepBullishBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(DeepBullishBackgroundColor); }
			set { DeepBullishBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Excursion Level 1 Color", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 18)]
		public Brush ExcursionLevel1Color { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ExcursionLevel1ColorSerialize
		{
			get { return Serialize.BrushToString(ExcursionLevel1Color); }
			set { ExcursionLevel1Color = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Excursion Level 2 Color", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 19)]
		public Brush ExcursionLevel2Color { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ExcursionLevel2ColorSerialize
		{
			get { return Serialize.BrushToString(ExcursionLevel2Color); }
			set { ExcursionLevel2Color = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Excursion Level 3 Color", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 20)]
		public Brush ExcursionLevel3Color { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ExcursionLevel3ColorSerialize
		{
			get { return Serialize.BrushToString(ExcursionLevel3Color); }
			set { ExcursionLevel3Color = Serialize.StringToBrush(value); }
		}
		#endregion

		#region Visuals
		protected const string VisualsGroupName = "Misc. Visuals";

		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Show Stripes", Order = 0, GroupName = VisualsGroupName)]
		public bool ShowRacingStripes { get; set; }

		[XmlIgnore]
		[ARC_PatternFinderAlgo_HideUnless("ShowRacingStripes", ARC_PatternFinderAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Long Stripe Signal Color", Order = 1, GroupName = VisualsGroupName)]
		public Brush LongStripColor { get; set; }

		[ARC_PatternFinderAlgo_HideUnless("ShowRacingStripes", ARC_PatternFinderAlgo_PropComparisonType.EQ, true)]
		[Range(0, int.MaxValue)]
		[Display(Name = "Long Strip Opacity", Order = 2, GroupName = VisualsGroupName)]
		public int LongStripOpacity { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string LongStripColorSerializable
		{
			get { return Serialize.BrushToString(LongStripColor); }
			set { LongStripColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[ARC_PatternFinderAlgo_HideUnless("ShowRacingStripes", ARC_PatternFinderAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Short Stripe Signal Color", Order = 3, GroupName = VisualsGroupName)]
		public Brush ShortStripColor { get; set; }

		[ARC_PatternFinderAlgo_HideUnless("ShowRacingStripes", ARC_PatternFinderAlgo_PropComparisonType.EQ, true)]
		[Range(0, int.MaxValue)]
		[Display(Name = "Short Strip Opacity", Order = 4, GroupName = VisualsGroupName)]
		public int ShortStripOpacity { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ShortStripColorSerializable
		{
			get { return Serialize.BrushToString(ShortStripColor); }
			set { ShortStripColor = Serialize.StringToBrush(value); }
		}

		[Display(Name = "Button Text", Order = 101, GroupName = VisualsGroupName)]
		public string ButtonText { get; set; }

		[XmlIgnore]
		[Display(Name = "Stop Dot Color", Order = 102, GroupName = VisualsGroupName)]
		public Brush StopDotColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string StopDotColorSerializable
		{
			get { return Serialize.BrushToString(StopDotColor); }
			set { StopDotColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Target Dot Color", Order = 103, GroupName = VisualsGroupName)]
		public Brush TargetDotColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string TargetDotColorSerializable
		{
			get { return Serialize.BrushToString(TargetDotColor); }
			set { TargetDotColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Chart PnL Text Color", Order = 104, GroupName = VisualsGroupName)]
		public Brush ChartPnLTextColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ChartPnLTextColorSerializable
		{
			get { return Serialize.BrushToString(ChartPnLTextColor); }
			set { ChartPnLTextColor = Serialize.StringToBrush(value); }
		}

		[Display(Name = "Dash Historical PNL", Order = 105, GroupName = VisualsGroupName)]
		public bool DashHistoricPnl { get; set; }

		[XmlIgnore]
		[Display(Name = "Missed Order Color (Unfilled)", Order = 106, GroupName = VisualsGroupName)]
		public Brush UnfilledOrderColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string UnfilledOrderColorSerializable
		{
			get { return Serialize.BrushToString(UnfilledOrderColor); }
			set { UnfilledOrderColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Missed Order Color (Gap Bar)", Order = 107, GroupName = VisualsGroupName)]
		public Brush GapBarOrderColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string GapBarOrderColorSerializable
		{
			get { return Serialize.BrushToString(GapBarOrderColor); }
			set { GapBarOrderColor = Serialize.StringToBrush(value); }
		}
		#endregion
		#endregion
	}
}