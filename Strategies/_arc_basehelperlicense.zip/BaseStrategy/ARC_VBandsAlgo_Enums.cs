using System;

public enum ARC_VBandsAlgo_RunType { BackTest, RealTime, Combined }

public enum ARC_VBandsAlgo_HighWaterMarkType { Off, Realized, RealizedPlusUnrealized }

public enum ARC_VBandsAlgo_TargetType { Ticks, RR, ATR }

public enum ARC_VBandsAlgo_BidAsk { Bid, Ask }

[Flags]
public enum ARC_VBandsAlgo_BidAskFlags { Bid = 1, Ask = 2 }

public enum ARC_VBandsAlgo_StopLossType { Ticks, ATR }

public enum ARC_VBandsAlgo_AtrOrTicks { Ticks, ATR }

public enum ARC_VBandsAlgo_SizingStrategy { Static, FixedCost, PercentOfBalance }

public enum ARC_VBandsAlgo_EntryOrderType { Market, Limit }

public enum ARC_VBandsAlgo_AllowedEntryDirection { LongAndShort, LongOnly, ShortOnly, None }

public enum ARC_VBandsAlgo_OppositeSignalAction { None, ExitOnly, Reverse }

public enum ARC_VBandsAlgo_BarCloseOrIntrabar { BarClose, Intrabar }

public enum ARC_VBandsAlgo_TickOrPercentPatternHLRange { Ticks, PercentOfPatternHLRange }

public enum ARC_VBandsAlgo_ImbalanceCalculationMode { Diagonally, Horizontally }

public enum ARC_VBandsAlgo_BidAskVolumeCalculationMode { UpTickDownTick, TrueBidAsk }

public enum ARC_VBandsAlgo_BoolEnum { True, False }

public enum ARC_VBandsAlgo_MovingAverageType { EMA, SMA, StepMA }

public enum ARC_VBandsAlgo_StepMaTrendType { Level, Trend }

public enum ARC_VBandsAlgo_DayWeekMonth { Day, Week, Month }

public enum	ARC_VBandsAlgo_AlgoEntryType
{
	BarClose,
	Intrabar
}

public enum ARC_VBandsAlgo_SingleBarPattern
{
	Inside = 1, 
	Directional = 2,
	Outside = 3
}

[Flags]
public enum ARC_VBandsAlgo_ARCFilterType
{
	TaFilters = 1,
	MoneyManagement = 2,
	Time = 4,
	Direction = 8,
	ConsecutiveTrades = 16,
	ArmState = 32,
	SameBar = 64,
	AllExceptArmState = TaFilters | MoneyManagement | Time | Direction | ConsecutiveTrades | SameBar,
	All = AllExceptArmState | ArmState
}