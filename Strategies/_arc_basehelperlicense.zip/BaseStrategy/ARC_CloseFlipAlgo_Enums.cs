using System;

public enum ARC_CloseFlipAlgo_RunType { BackTest, RealTime, Combined }

public enum ARC_CloseFlipAlgo_HighWaterMarkType { Off, Realized, RealizedPlusUnrealized }

public enum ARC_CloseFlipAlgo_TargetType { Ticks, RR, ATR }

public enum ARC_CloseFlipAlgo_BidAsk { Bid, Ask }

[Flags]
public enum ARC_CloseFlipAlgo_BidAskFlags { Bid = 1, Ask = 2 }

public enum ARC_CloseFlipAlgo_StopLossType { Ticks, ATR }

public enum ARC_CloseFlipAlgo_AtrOrTicks { Ticks, ATR }

public enum ARC_CloseFlipAlgo_SizingStrategy { Static, FixedCost, PercentOfBalance }

public enum ARC_CloseFlipAlgo_EntryOrderType { Market, Limit }

public enum ARC_CloseFlipAlgo_AllowedEntryDirection { LongAndShort, LongOnly, ShortOnly, None }

public enum ARC_CloseFlipAlgo_OppositeSignalAction { None, ExitOnly, Reverse }

public enum ARC_CloseFlipAlgo_BarCloseOrIntrabar { BarClose, Intrabar }

public enum ARC_CloseFlipAlgo_TickOrPercentPatternHLRange { Ticks, PercentOfPatternHLRange }

public enum ARC_CloseFlipAlgo_ImbalanceCalculationMode { Diagonally, Horizontally }

public enum ARC_CloseFlipAlgo_BidAskVolumeCalculationMode { UpTickDownTick, TrueBidAsk }

public enum ARC_CloseFlipAlgo_BoolEnum { True, False }

public enum ARC_CloseFlipAlgo_MovingAverageType { EMA, SMA, StepMA }

public enum ARC_CloseFlipAlgo_StepMaTrendType { Level, Trend }

public enum ARC_CloseFlipAlgo_DayWeekMonth { Day, Week, Month }

public enum ARC_CloseFlipAlgo_SingleBarPattern
{
	Inside = 1, 
	Directional = 2,
	Outside = 3
}

[Flags]
public enum ARC_CloseFlipAlgo_ARCFilterType
{
	TaFilters = 1,
	MoneyManagement = 2,
	Time = 4,
	Direction = 8,
	ConsecutiveTrades = 16,
	ArmState = 32,
	SameBar = 64,
	AllExceptArmState = TaFilters | MoneyManagement | Time | Direction | ConsecutiveTrades | SameBar,
	All = AllExceptArmState | ArmState
}