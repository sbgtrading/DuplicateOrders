using System;

public enum ARC_HybridAlgo_RunType { BackTest, RealTime, Combined }

public enum ARC_HybridAlgo_HighWaterMarkType { Off, Realized, RealizedPlusUnrealized }

public enum ARC_HybridAlgo_TargetType { Ticks, RR, ATR }

public enum ARC_HybridAlgo_BidAsk { Bid, Ask }

[Flags]
public enum ARC_HybridAlgo_BidAskFlags { Bid = 1, Ask = 2 }

public enum ARC_HybridAlgo_StopLossType { Ticks, ATR }

public enum ARC_HybridAlgo_EntryOrderType { Market, Limit }

public enum ARC_HybridAlgo_AllowedEntryDirection { LongAndShort, LongOnly, ShortOnly, None }

public enum ARC_HybridAlgo_OppositeSignalAction { None, ExitOnly, Reverse }

public enum ARC_HybridAlgo_ImbalanceCalculationMode { Diagonally, Horizontally }

public enum ARC_HybridAlgo_BidAskVolumeCalculationMode { UpTickDownTick, TrueBidAsk }

public enum ARC_HybridAlgo_BoolEnum { True, False }

public enum ARC_HybridAlgo_MovingAverageType { EMA, SMA, StepMA }

public enum ARC_HybridAlgo_StepMaTrendType { Level, Trend }

public enum ARC_HybridAlgo_DayWeekMonth { Day, Week, Month }

[Flags]
public enum ARC_HybridAlgo_ARCFilterType
{
	TaFilters = 1,
	MoneyManagement = 2,
	Time = 4,
	Direction = 8,
	ConsecutiveTrades = 16,
	ArmState = 32,
	AllExceptArmState = TaFilters | MoneyManagement | Time | Direction | ConsecutiveTrades,
	All = AllExceptArmState | ArmState
}