using NinjaTrader.Cbi;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.Custom.Strategies.Helpers.ARC;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.Indicators.ARC;
using NinjaTrader.NinjaScript.Indicators.ARC.AlgoSup;
using NinjaTrader.NinjaScript.Indicators.ARC.Supporting;
using NinjaTrader.NinjaScript.Strategies.Licensing;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Media;
using System.Xml.Serialization;
using SharpDX;
using SharpDX.Direct2D1;
using Brush = System.Windows.Media.Brush;
using DayOfWeek = System.DayOfWeek;
using Order = NinjaTrader.Cbi.Order;

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies.ARC
{
	[TypeConverter("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TrendStepperAlgo_ExtendedStrategyConverter")]
	[ARC_TrendStepperAlgo_CoLicenses(typeof(ARC_TrendStepperAlgo_VMAlgo), typeof(ARC_TrendStepperAlgo_ARC_TrendStepper), typeof(ARC_TrendStepperAlgo_ARC_MWPatternFinderZigZag))]
	[CategoryOrder(StrategyParameterGroupName, 1)]
	[CategoryOrder(EntryGroupName, 20)]
	[CategoryOrder(StopLossGroupName, 30)]
	[CategoryOrder(TargetsGroupName, 40)]
	[CategoryOrder(TimeControlGroupName, 50)]
	[CategoryOrder(MoneyManagementGroupName, 60)]
	[CategoryOrder(HTFMovingAveragesGroupName, 70)]
	[CategoryOrder(MarketStructureFilterGroupName, 80)]
	[CategoryOrder(VMLeanGroupName, 90)]
	[CategoryOrder(ProductInfoGroupName, 100)]
	[CategoryOrder(StrategyVisualsParameterGroupName, 110)]
	[CategoryOrder(VMLeanPlotsGroupName, 120)]
	[CategoryOrder(VisualsGroupName, 130)]
	public abstract class ARC_TrendStepperAlgo_ARCStrategyBase : Strategy, ARC_TrendStepperAlgo_IARCLicensed
	{
		#region Properties/Fields
		[XmlIgnore, Browsable(false)]
		public virtual bool ColicensedOnly { get { return false; } }
		[Browsable(false), XmlIgnore]
		public virtual string ProductInfusionSoftTag { get { return ""; } }
		[Browsable(false), XmlIgnore]
		public virtual List<string> ProductBundleInfusionSoftTags { get { return new List<string>(); } }
		[Display(GroupName = ProductInfoGroupName)]
		public virtual string ProductVersion { get { throw new NotImplementedException(); } }
		[Display(GroupName = ProductInfoGroupName)]
		public virtual string ModuleName { get { return GetType().Name.Replace("ARC_", ""); } }

		/// <summary>
		/// The default name for the script in the UI and ToString
		/// </summary>
		protected virtual string ProductName { get { return GetType().Name; } }

		public override string DisplayName { get { return ToString() + ARC_TrendStepperAlgo_ARCLicenseValidator.LicenseModeDenotingNameSuffix; } }

		/// <summary>
		/// The prefix used for automation IDs for UI components to avoid collisions with other products.
		/// </summary>
		protected string AutomationIdsPrefix { get { return ModuleName; } }
		
		protected virtual bool AllowIntrabarEntries { get { return false; } }
		protected virtual bool OverridesVMBiasAndConfluenceHandling { get { return false; } }
		private int[] TargetQuantities { get { return new[] { Entry1Quantity, Entry2Quantity, Entry3Quantity }; } }

		/// <summary>
		/// The flat PNL since the start of the strategy
		/// </summary>
		private double ChartClosedPnl
		{
			get
			{
				return SystemPerformance.AllTrades.TradesPerformance.NetProfit;
			}
		}

		/// <summary>
		/// The flat PNL since our equity curve managers start time
		/// </summary>
		private double SessionClosedPnl
		{
			get
			{
				if (SystemPerformance.AllTrades.Count == tradeCountAtLastSessionClosedPnlRefresh && lastMmReset == lastMmResetAtLastSessionClosedPnlRefresh)
					return lastSessionClosedPnl;

				lastSessionClosedPnl = SystemPerformance.AllTrades
					.Skip(tradeCountAtLastMmReset)
					.Where(trd => trd.Entry.Time >= lastMmReset)
					.Sum(trd => trd.ProfitCurrency);
				lastMmResetAtLastSessionClosedPnlRefresh = lastMmReset;
				tradeCountAtLastSessionClosedPnlRefresh = SystemPerformance.AllTrades.Count;
				return lastSessionClosedPnl;
			}
		}
		private double lastSessionClosedPnl;
		private int tradeCountAtLastSessionClosedPnlRefresh;
		private DateTime lastMmResetAtLastSessionClosedPnlRefresh;
		private int tradeCountAtLastMmReset;

		protected const string OppositeOrderName = "Opposite Exit";

		private string customToolbarControlsGridAutomationId;
		private bool isToolBarButtonAdded;
		private Grid customToolbarControlsGrid;
		private Menu menuControlContainer;
		private MenuItem menuControl, miOff, miBoth, miLong, miShort, miBreakEven, miStopLoss, miMoveStop;

		private DateTime lastMmReset;
		private double mmMaxGain;
		protected bool mmCanTrade = true;
		
		private ARC_TrendStepperAlgo_OrderTracker orderTracker;
		protected int orderBarsIdx;

		private ARC_TrendStepperAlgo_ChartPnl indPnlChart;
		private ARC_TrendStepperAlgo_OrderSingle indOrder;
		private ARC_TrendStepperAlgo_TargStop indStopTrg;

		protected double stopLossUserOverride;

		protected ARC_TrendStepperAlgo_VMAlgo indMomo;
		protected Indicator filterMa;
		private int htfBarsIdx = -1;
		private bool firstTickOfPrimaryBar;

		protected int lastEntryBar;
		protected int PendingEntryDir { get; private set; }
		private int barToPaintAsInvalidPriceCancellation = -1;
		protected int lastSignalBar;
		protected int lastSignalDir;
		private double pendingTpMultiple = 1;
		private double? pendingBarPlotSl;
		private double?[] pendingBarPlotTp;

		private ARC_TrendStepperAlgo_ARC_MWPatternFinderZigZag msFilterZigZag;
		protected Brush longStripBrush;
		protected Brush shortStripBrush;
		private ATR stopLossAtr;
		private ATR targetAtr;
		private bool hitHistoricalState;
		#endregion

		#region NT Overrides
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Name = ProductName + ARC_TrendStepperAlgo_ARCLicenseValidator.LicenseModeDenotingNameSuffix;
				Calculate = Calculate.OnBarClose;
				EntriesPerDirection = 3;
				MaximumBarsLookBack = MaximumBarsLookBack.TwoHundredFiftySix;
				IsInstantiatedOnEachOptimizationIteration = true;
				IsExitOnSessionCloseStrategy = false;

				RunType = ARC_TrendStepperAlgo_RunType.BackTest;
				StartTime = 600;
				EndTime = 1600;
				ExitAtEndTime = false;
				RestartPnlOnSession = false;
				DayMaxGain = 0;
				DayMaxLoss = 0;
				HighWaterMarkType = ARC_TrendStepperAlgo_HighWaterMarkType.Off;
				DailyHighWaterMarkPct = 0;
				HwmActivatedAt = 200;
				IgnoreTradeTime = false;
				StopDotColor = Brushes.Red;
				TargetDotColor = Brushes.Lime;
				AllowedEntryDirections = ARC_TrendStepperAlgo_AllowedEntryDirection.LongAndShort;
				Entry1Quantity = 1;
				Entry2Quantity = 0;
				Entry3Quantity = 0;
				EntryOrderType = ARC_TrendStepperAlgo_EntryOrderType.Market;
				LimitEntryOffsetTicks = 0;
				StopLossType = ARC_TrendStepperAlgo_StopLossType.Ticks;
				StopLoss = 10;
				StopLossATRPeriod = 14;
				TargetType = ARC_TrendStepperAlgo_TargetType.Ticks;
				UseMitTargetOrders = false;
				ProfitTargetValue1 = 8;
				ProfitTargetValue2 = 0;
				ProfitTargetValue3 = 0;
				TrailTriggerTicks = 0;
				TrailLookbackBars = 0;
				TrailTicks = 0;
				BreakEvenTrigger = 0;
				BreakEvenPlus = 0;
				DashHistoricPnl = true;
				OnOppositeSignal = ARC_TrendStepperAlgo_OppositeSignalAction.None;
				UseHTFMovingAverage = false;
				MABarBiasPercentRequirement = 0;
				MaxPendingOrderBars = 1;
				TargetATRPeriod = 14;
				LimitPreOrderGapBars = true;
				MaxPreOrderGapBars = 0;

				BlockLevelEntry = 0;
				VMBiasType = ARC_TrendStepperAlgo_VMAlgo_BiasType.ZeroLine;
				VMHistogramBackground = false;
				BandPeriod = 10;
				Fast = 12;
				Slow = 26;
				StdDevNumber = 1;
				VMSwingStrength = 1;
				MinDeviationMultiplier = 0;
				UseVMBias = false;
				UseVMConfluence = false;
					 
				MAPeriod = 15;
				MATimeframe = 1;
				MAType = ARC_TrendStepperAlgo_MovingAverageType.EMA;
				FilterMAStepSize = 40;
				FilterMATrendType = ARC_TrendStepperAlgo_StepMaTrendType.Trend;
				ShowMA = true;
				MAColor = Brushes.WhiteSmoke;

				LongStripColor = Brushes.Green;
				LongStripOpacity = 50;
				ShortStripColor = Brushes.Red;
				ShortStripOpacity = 50;
				ChartPnLTextColor = Brushes.DimGray;
				DotsUpRisingColor = Brushes.Green;
				DotsDownRisingColor = Brushes.Green;
				DotsDownFallingColor = Brushes.Red;
				DotsUpFallingColor = Brushes.Red;
				DotsRimColor = Brushes.Black;
				BBAverageColor = Brushes.Transparent;
				BBUpperColor = Brushes.Black;
				BBLowerColor = Brushes.Black;
				HistUpColor = Brushes.LimeGreen;
				HistDownColor = Brushes.Maroon;
				ZeroLineColor = Brushes.Black;
				ConnectorColor = Brushes.White;
				DeepBullishBackgroundColor = Brushes.DarkGreen;
				BullishBackgroundColor = Brushes.Green;
				OppositeBackgroundColor = Brushes.Gray;
				BearishBackgroundColor = Brushes.Red;
				DeepBearishBackgroundColor = Brushes.DarkRed;
				ChannelColor = Brushes.DodgerBlue;
				ExcursionLevel1Color = Brushes.White;
				ExcursionLevel2Color = Brushes.Blue;
				ExcursionLevel3Color = Brushes.Red;
				UnfilledOrderColor = Brushes.Yellow;
				GapBarOrderColor = Brushes.Orange;
			}
			else if (State == State.Configure)
			{
				ShowMsFilterZigZag = false;
				ShowMsFilterBiasStrip = false;
				UseMsFilter = false;
				MsFilterSwingStrength = 3;
				MsFilterIncludeWicks = false;
				MsFilterNeutralColor = Brushes.Black;
				MsFilterUptrendColor = Brushes.Blue;
				MsFilterDowntrendColor = Brushes.Purple;
				MsFilterZigZagThickness = 2;
				MsFilterBiasStripThickness = 12;

				// Reset fields for optimization
				hitHistoricalState = false;
				ResetPerRunCustomValues();

				StartBehavior = StartBehavior.WaitUntilFlat;
				this.ARC_TrendStepperAlgo_EnactLicensing(ARC_TrendStepperAlgo_LicensingContextStep.Configure);
				if (Entry3Quantity > 0)
					EntriesPerDirection = 3;
				else if (Entry2Quantity > 0)
					EntriesPerDirection = 2;
				else
					EntriesPerDirection = 1;

				stopLossUserOverride = StopLoss;

				orderBarsIdx = EnsureDataSeriesAdded(BarsPeriodType.Tick, 1);
				if (ShowMA)
				{
					const string maPlotName = "HTF MA";
					var filterMaPlotIdx = Array.FindIndex(Plots, p => p.Name == maPlotName);
					if (filterMaPlotIdx == -1)
					{
						AddPlot(MAColor, maPlotName);
						filterMaPlotIdx = Plots.Length - 1;					
					}

					Plots[filterMaPlotIdx].PlotStyle = MAType == ARC_TrendStepperAlgo_MovingAverageType.StepMA ? PlotStyle.Square : PlotStyle.Line;
					Plots[filterMaPlotIdx].Width = 2;
				}

				htfBarsIdx = EnsureDataSeriesAdded(BarsPeriodType.Minute, MATimeframe);
			}
			else if (State == State.DataLoaded)
			{
				indStopTrg = ARC_TrendStepperAlgo_TargStop(1, 3);
				indStopTrg.StopPlots.ForEach(p => p.Brush = StopDotColor);
				indStopTrg.TargetPlots.ForEach(p => p.Brush = TargetDotColor);
				indStopTrg.Name = "";
				AddChartIndicator(indStopTrg);

				indOrder = ARC_TrendStepperAlgo_OrderSingle();
				indOrder.Plots[0].Brush = Brushes.Cyan;
				indOrder.Plots[1].Brush = Brushes.Magenta;
				indOrder.Name = "";
				AddChartIndicator(indOrder);

				indPnlChart = ARC_TrendStepperAlgo_ChartPnl();
				indPnlChart.defaultTextBrush = ChartPnLTextColor;
				indPnlChart.Name = "";
				AddChartIndicator(indPnlChart);

				indMomo = ARC_TrendStepperAlgo_VMAlgo(BarsArray[0], ARC_TrendStepperAlgo_VMAlgo_OptimizeSpeedSettings.Max, BandPeriod, Fast, Slow, StdDevNumber, VMSwingStrength, MinDeviationMultiplier, 0);
				indMomo.BackgroundFlooding = VMHistogramBackground ? ARC_TrendStepperAlgo_VMAlgo_Flooding.Histogram : ARC_TrendStepperAlgo_VMAlgo_Flooding.None;
				indMomo.DisplayLevel1 = true;
				indMomo.DotsUpRisingColor = DotsUpRisingColor;
				indMomo.DotsDownRisingColor = DotsDownRisingColor;
				indMomo.DotsDownFallingColor = DotsDownFallingColor;
				indMomo.DotsUpFallingColor = DotsUpFallingColor;
				indMomo.DotsRimColor = DotsRimColor;
				indMomo.BBAverageColor = BBAverageColor;
				indMomo.BBUpperColor = BBUpperColor;
				indMomo.BBLowerColor = BBLowerColor;
				indMomo.HistDownColor = HistDownColor;
				indMomo.HistUpColor = HistUpColor;
				indMomo.ZerolineColor = ZeroLineColor;
				indMomo.ConnectorColor = ConnectorColor;
				indMomo.DeepBearishBackgroundColor = DeepBearishBackgroundColor;
				indMomo.DeepBullishBackgroundColor = DeepBullishBackgroundColor;
				indMomo.OppositeBackgroundColor = OppositeBackgroundColor;
				indMomo.BullishBackgroundColor = BullishBackgroundColor;
				indMomo.BearishBackgroundColor = BearishBackgroundColor;
				indMomo.ChannelColor = ChannelColor;
				indMomo.Level1Color = ExcursionLevel1Color;
				indMomo.Level2Color = ExcursionLevel2Color;
				indMomo.Level3Color = ExcursionLevel3Color;
				AddChartIndicator(indMomo);

				if (UseHTFMovingAverage || ShowMA)
					switch (MAType)
					{
					case ARC_TrendStepperAlgo_MovingAverageType.EMA:
						filterMa = EMA(Closes[htfBarsIdx], MAPeriod);
						break;
					case ARC_TrendStepperAlgo_MovingAverageType.SMA:
						filterMa = SMA(Closes[htfBarsIdx], MAPeriod);
						break;
					case ARC_TrendStepperAlgo_MovingAverageType.StepMA:
						filterMa = ARC_TrendStepperAlgo_ARC_TrendStepper(Closes[0], FilterMAStepSize, 0);
						break;
					default: 
						throw new ArgumentOutOfRangeException();
					}

				orderTracker = new ARC_TrendStepperAlgo_OrderTracker(3);

				if (StopLossType == ARC_TrendStepperAlgo_StopLossType.ATR)
					stopLossAtr = ATR(StopLossATRPeriod);
				if (TargetType == ARC_TrendStepperAlgo_TargetType.ATR)
					targetAtr = ATR(TargetATRPeriod);

				if (ShowMsFilterZigZag || ShowMsFilterBiasStrip || UseMsFilter)
					msFilterZigZag = ARC_TrendStepperAlgo_ARC_MWPatternFinderZigZag(MsFilterSwingStrength, MsFilterIncludeWicks);
			}
			else if (State == State.Historical)
			{
				hitHistoricalState = true;

				longStripBrush = LongStripColor.Clone();
				longStripBrush.Opacity = LongStripOpacity / 100.0;
				longStripBrush.Freeze();

				shortStripBrush = ShortStripColor.Clone();
				shortStripBrush.Opacity = ShortStripOpacity / 100.0;
				shortStripBrush.Freeze();

				if (ChartControl == null || IsInStrategyAnalyzer)
					return;

				customToolbarControlsGridAutomationId = AutomationIdsPrefix + ChartControl.ChartTab.PersistenceId + "CustomToolbarControlsGridAutomationId";
				if (isToolBarButtonAdded)
					return;

				ChartControl.Dispatcher.InvokeAsync(() =>
				{
					var chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
					if (chartWindow == null)
						return;

					isToolBarButtonAdded |= chartWindow.MainMenu
						.OfType<DependencyObject>()
						.Select(AutomationProperties.GetAutomationId)
						.Contains(customToolbarControlsGridAutomationId);

					if (isToolBarButtonAdded)
						return;

					AddToolBar(chartWindow);
					isToolBarButtonAdded = true;
				});
			}
			else if (State == State.Realtime)
			{
				orderTracker.TransitionToRealtime(this);
				orderTracker.AllLiveExitOrders.ForEach(CancelOrder);
				CancelPendingEntries();
				ExitPosition("EndBacktest");

				orderTracker.Reset();
				ResetMoneyManagement();
			}
			else if (State == State.Terminated)
			{
				if (hitHistoricalState)
					GC.Collect();

				if (IsInStrategyAnalyzer || !isToolBarButtonAdded || ChartControl == null)
					return;

				ChartControl.Dispatcher.InvokeAsync(() =>
				{
					var chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
					if (chartWindow == null)
						return;

					chartWindow.MainMenu.Remove(customToolbarControlsGrid);
					foreach (var grid in customToolbarControlsGrid.FindAll(customToolbarControlsGridAutomationId).ToList())
						chartWindow.MainMenu.Remove(grid);

					customToolbarControlsGrid = null;
					chartWindow.MainTabControl.SelectionChanged -= TabSelectionChangedHandler;
				});
			}
		}

		protected override void OnMarketData(MarketDataEventArgs marketDataUpdate)
		{
			if (!this.ARC_TrendStepperAlgo_IsLicensed())
				return;

			if (marketDataUpdate.MarketDataType != MarketDataType.Last || RunType == ARC_TrendStepperAlgo_RunType.BackTest)
				return;

			if (Position.MarketPosition != MarketPosition.Flat)
				SyncPnlPlot();

			SyncMoneyManagement(marketDataUpdate.Price);
		}

		protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string comment)
		{
			orderTracker.ProcessUpdate(order);
		}

		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
		{
			if (Regex.IsMatch(execution.Order.Name, @"^(L|S)\d+$"))
				HandleEntryExecution(execution, price, quantity);
			else
				HandleExitExecution(execution, quantity);

			// Can't have a pending entry order in the opposite direction, so limit reversals are entered here, after the reversal exit 
			if (OnOppositeSignal != ARC_TrendStepperAlgo_OppositeSignalAction.Reverse || EntryOrderType != ARC_TrendStepperAlgo_EntryOrderType.Limit)
				return;

			if (execution.Order.Name != OppositeOrderName)
				return;

			if (lastEntryBar < CurrentBars[0])
				return;

			var signalDir = execution.Order.IsLong ? 1 : -1;
			var limitPrice = Closes[0].GetValueAt(lastEntryBar);
			SubmitOrder(signalDir, limitPrice);
		}

		protected override void OnPositionUpdate(Position position, double averagePrice, int quantity, MarketPosition marketPosition)
		{
			if (IsInStrategyAnalyzer || ChartControl == null || !isToolBarButtonAdded)
				return;

			ChartControl.Dispatcher.InvokeAsync(() =>
			{
				var enabled = position.MarketPosition != MarketPosition.Flat;
				foreach (var mi in new[] { miStopLoss, miMoveStop })
					mi.IsEnabled = enabled;
			});
		}

		protected override void OnBarUpdate()
		{
			this.ARC_TrendStepperAlgo_EnactLicensing(ARC_TrendStepperAlgo_LicensingContextStep.BarUpdate);
			if (!this.ARC_TrendStepperAlgo_IsLicensed())
				return;

			if (CurrentBars[0] < 1 || CurrentBars[orderBarsIdx] < 5)
				return;

			if (BarsInProgress == orderBarsIdx)
			{
				// Handle the first tick to cross the session end time
				if (Time[0].Date != Time[1].Date || (Time[0].ARC_TrendStepperAlgo_CompareTime(EndTime) != -1 && Time[1].ARC_TrendStepperAlgo_CompareTime(EndTime) == -1))
				{
					if (!IgnoreTradeTime || ExitAtEndTime)
						CancelPendingEntries();

					if (ExitAtEndTime)
						ExitPosition("endTime");

					if (RestartPnlOnSession)
						ResetMoneyManagement();
				}

				UpdateStop();
				if (State == State.Realtime)
				{
					SyncMoneyManagement(GetCurrentBid(orderBarsIdx));
					SyncMoneyManagement(GetCurrentAsk(orderBarsIdx));
				}
				else
				{
					SyncMoneyManagement(Closes[orderBarsIdx][0]);
				}

				OnTickBar();

				// Track whether or not we're the first tick of the current primary bar.
				// If we're allowing intrabar entries, process pending ones them here.
				if (firstTickOfPrimaryBar)
				{
					if (Time[0] > Times[0][0])
						firstTickOfPrimaryBar = false;
					else if (!AllowIntrabarEntries)
						return;
				}

				ProcessPendingEntries();
			}
			else if (BarsInProgress == 0)
			{
				// We paint here in case orders are rejected the same bar the 
				if (barToPaintAsInvalidPriceCancellation != -1)
				{
					BackBrushes[CurrentBars[0] - barToPaintAsInvalidPriceCancellation] = UnfilledOrderColor;
					barToPaintAsInvalidPriceCancellation = -1;
				}

				if (lastSignalBar == CurrentBar)
					BackBrushes[0] = lastSignalDir == 1 ? longStripBrush : shortStripBrush;

				var wasFirstTickOfPrimaryBar = firstTickOfPrimaryBar;
				firstTickOfPrimaryBar = true;

				// Force update momo and HTF and copy values if necessary, as we've seen this indicator show flat incorrectly
				indMomo.Update();
				if (ShowMA && (MAType == ARC_TrendStepperAlgo_MovingAverageType.StepMA || CurrentBars[htfBarsIdx] >= 0))
					Value[0] = filterMa[0];

				if (!mmCanTrade)
					BarBrushes[0] = Brushes.DimGray;

				if (CurrentBars[0] < 0 || CurrentBars[orderBarsIdx] < 0)
					return;

				// Check whether or not our gab bar settings require dequeuing pending entries
				if (PendingEntryDir != 0 && LimitPreOrderGapBars)
				{
					var gapBarCount = 0;
					for (var i = 0; i < CurrentBar - lastSignalBar && gapBarCount <= MaxPreOrderGapBars; i++)
						if (Time[i] == Time[i + 1])
							gapBarCount++;
					
					if (gapBarCount > MaxPreOrderGapBars)
					{
						PendingEntryDir = 0;
						BackBrush = GapBarOrderColor;
					}
				}

				// Draw our start of window and end of window marker
				if (InValidTradingWindow(Time[0]) != InValidTradingWindow(Time[1]))
					Draw.VerticalLine(this, CurrentBars[0] + "d", 0, InValidTradingWindow(Time[0]) ? Brushes.LimeGreen : Brushes.Red, DashStyleHelper.Dash, 2);

				if (State != State.Realtime || RunType != ARC_TrendStepperAlgo_RunType.BackTest)
					SyncPnlPlot();

				// Signal order cancellations
				if (EntryOrderType != ARC_TrendStepperAlgo_EntryOrderType.Market && orderTracker.lastPendingOrderInitiation < CurrentBar - MaxPendingOrderBars && orderTracker.IsPendingEntryOrders)
				{
					BackBrush = UnfilledOrderColor;
					CancelPendingEntries();
				}

				// If we're not limiting pre-order gap bars we don't need to wait for a non gab bar to process
				// orders. Otherwise process if not already dequeued and we've received a non gab bar 
				if (!LimitPreOrderGapBars || (Time[0] > Time[1] && wasFirstTickOfPrimaryBar))
					ProcessPendingEntries(1);

				if (!LimitPreOrderGapBars)
					PendingEntryDir = 0;

				// Update stop and target visuals
				SyncStopPlots();
				SyncTargetPlots();

				// Trigger strategy execution handling
				OnPrimaryBar();

				if (orderTracker[0] == null)
					return;

				// Update pending order visuals
				var dir = orderTracker[0].OrderAction == OrderAction.Buy || orderTracker[0].OrderAction == OrderAction.BuyToCover ? 1 : -1;
				var plotSeries = dir == 1 ? indOrder.EntryPriceL : indOrder.EntryPriceS;
				if (orderTracker[0].OrderType == OrderType.Limit)
					plotSeries[0] = orderTracker[0].LimitPrice;
				if (orderTracker[0].OrderType == OrderType.StopMarket || orderTracker[0].OrderType == OrderType.StopLimit)
					plotSeries[0] = orderTracker[0].StopPrice;
			}
			else if (BarsInProgress == htfBarsIdx)
			{
				if (ShowMA && MAType != ARC_TrendStepperAlgo_MovingAverageType.StepMA)
					Value[0] = filterMa[0];
			}
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			base.OnRender(chartControl, chartScale);
			if (!ShowMsFilterZigZag && !ShowMsFilterBiasStrip)
				return;

			if (msFilterZigZag.SwingPoints.Count < 4)
				return;

			// Get the range of points that intersect the visible range, plus a few extra so we can determine trend
			var rangeStart = Math.Max(0, msFilterZigZag.SwingPoints.FindIndex(pt => pt.Bar >= ChartBars.FromIndex) - 4);
			var rangeEnd = Math.Min(msFilterZigZag.SwingPoints.Count - 1, msFilterZigZag.SwingPoints.FindLastIndex(pt => pt.Bar <= ChartBars.ToIndex) + 5);
			var points = msFilterZigZag.SwingPoints.GetRange(rangeStart, rangeEnd - rangeStart + 1);

			// Group points by their comparison to the prior point on that side
			var contiguousTrends = points
				.Select((p, i) => new { Point = p, Index = i, Trend = i < 2 ? 0 : p.Price.ApproxCompare(points[i - 2].Price) })
				.Skip(2)
				.ARC_TrendStepperAlgo_GetContiguousGroups((t1, t2) => t1.Trend == t2.Trend && t2.Trend != 0)
				.ToList();

			var trends = new ARC_TrendStepperAlgo_DefaultingDictionary<int, List<List<ARC_TrendStepperAlgo_ZigZagPoint>>>(_ => new List<List<ARC_TrendStepperAlgo_ZigZagPoint>>());
			var lastNeutralTrendIdx = -1;
			foreach (var group in contiguousTrends)
			{
				var groupPoints = group
					.Select(g => g.Point)
					.Prepend(points[group[0].Index - 1])
					.Prepend(points[group[0].Index - 2])
					.ToList();

				// For trending groups with 4 or more points then 4 points that aren't neutral, assume them a separate group
				if (group.Count >= 3 && group[0].Trend != 0)
				{
					trends[group[0].Trend].Add(groupPoints);
					continue;
				}

				// If this group is a continuation of the last neutral group, append to that group, otherwise start a new group
				if (lastNeutralTrendIdx + 1 == group[0].Index)
					trends[0].Last().AddRange(groupPoints);
				else
					trends[0].Add(groupPoints);
				lastNeutralTrendIdx = group.Last().Index;
			}

			var orderedTrends = trends
				.SelectMany(kvp => kvp.Value.Select(pts => new { Points = pts, Trend = kvp.Key }))
				.OrderBy(t => t.Points[0].Bar)
				.ToList();

			var priorAaMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = AntialiasMode.PerPrimitive;

			try
			{
				using (var uptrendDxBrush = MsFilterUptrendColor.ToDxBrush(RenderTarget))
				using (var downtrendDxBrush = MsFilterDowntrendColor.ToDxBrush(RenderTarget))
				{
					if (ShowMsFilterZigZag)
					{
						using (var neutralDxBrush = MsFilterNeutralColor.ToDxBrush(RenderTarget))
							RenderTarget.ARC_TrendStepperAlgo_DrawZigZag(this, chartScale, points, neutralDxBrush);

						foreach (var trend in orderedTrends.Where(t => t.Trend != 0))
						{
							var backFillPoints = trend.Points
								.Take(4)
								.ToList();
							var realTrendPoints = trend.Points
								.Skip(3)
								.ToList();

							if (ShowMsFilterZigZag)
							{
								RenderTarget.ARC_TrendStepperAlgo_DrawZigZag(this, chartScale, backFillPoints, trend.Trend == 1 ? uptrendDxBrush : downtrendDxBrush, Math.Max(1, MsFilterZigZagThickness - 1), DashStyleHelper.Dot);
								RenderTarget.ARC_TrendStepperAlgo_DrawZigZag(this, chartScale, realTrendPoints, trend.Trend == 1 ? uptrendDxBrush : downtrendDxBrush, MsFilterZigZagThickness);
							}

							if (!ShowMsFilterBiasStrip)
								continue;

							var bottomY = chartScale.GetYByValue(chartScale.MinValue);
							for (int i = 0; i < 2; i++)
							{
								var thickness = i == 0 ? MsFilterBiasStripThickness * 3 / 4 : MsFilterBiasStripThickness;
								var subset = i == 0 ? backFillPoints : realTrendPoints;
								var vectorArray = subset
									.Take(1)
									.Append(subset.Last())
									.Select(p => new Vector2(chartControl.GetXByBarIndex(ChartBars, p.Bar), bottomY - (int)Math.Ceiling(MsFilterBiasStripThickness / 2)))
									.ToArray();

								var strokeStyle = new Stroke(Brushes.Transparent, i == 0 ? DashStyleHelper.Dot : DashStyleHelper.Solid, thickness).StrokeStyle;
								RenderTarget.DrawLine(vectorArray[0], vectorArray[1], trend.Trend == 1 ? uptrendDxBrush : downtrendDxBrush, thickness, strokeStyle);
							}
						}
					}
				}
			}
			finally
			{
				RenderTarget.AntialiasMode = priorAaMode;
			}
		}
		#endregion

		#region UI
		private void AddToolBar(Chart chartWindow)
		{
			menuControlContainer = new Menu { Background = Brushes.Orange, VerticalAlignment = VerticalAlignment.Center };
			menuControl = new MenuItem { BorderThickness = new Thickness(2), BorderBrush = Brushes.Gold, Header = ButtonText, Foreground = Brushes.Gold, Background = Brushes.MidnightBlue, VerticalAlignment = VerticalAlignment.Stretch, FontWeight = FontWeights.Bold, FontSize = 13 };
			menuControlContainer.Items.Add(menuControl);

			miOff = new MenuItem { Header = "OFF", Name = "ARCOff", Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = AllowedEntryDirections == ARC_TrendStepperAlgo_AllowedEntryDirection.None };
			miOff.Click += (_, __) =>
			{
				AllowedEntryDirections = ARC_TrendStepperAlgo_AllowedEntryDirection.None;
				miOff.IsChecked = true;
				miBoth.IsChecked = false;
				miLong.IsChecked = false;
				miShort.IsChecked = false;
				TriggerCustomEvent(___ =>
				{
					CancelPendingEntries();
					if (Position.MarketPosition != MarketPosition.Flat)
						ExitPosition("OFF");
				}, orderBarsIdx, null);
			};
			menuControl.Items.Add(miOff);

			miBoth = new MenuItem { Header = "LONG AND SHORT", Name = "ARCBoth", Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = AllowedEntryDirections == ARC_TrendStepperAlgo_AllowedEntryDirection.LongAndShort };
			miBoth.Click += (_, __) =>
			{
				AllowedEntryDirections = ARC_TrendStepperAlgo_AllowedEntryDirection.LongAndShort;
				miOff.IsChecked = false;
				miBoth.IsChecked = true;
				miLong.IsChecked = false;
				miShort.IsChecked = false;
			};
			menuControl.Items.Add(miBoth);

			miLong = new MenuItem { Header = "LONG ONLY", Name = "ARCLong", Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = AllowedEntryDirections == ARC_TrendStepperAlgo_AllowedEntryDirection.LongOnly };
			miLong.Click += (_, __) =>
			{
				AllowedEntryDirections = ARC_TrendStepperAlgo_AllowedEntryDirection.LongOnly;
				miOff.IsChecked = false;
				miBoth.IsChecked = false;
				miLong.IsChecked = true;
				miShort.IsChecked = false;
			};
			menuControl.Items.Add(miLong);

			miShort = new MenuItem { Header = "SHORT ONLY", Name = "ARCShort", Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = true, IsChecked = AllowedEntryDirections == ARC_TrendStepperAlgo_AllowedEntryDirection.ShortOnly };
			miShort.Click += (_, __) =>
			{
				AllowedEntryDirections = ARC_TrendStepperAlgo_AllowedEntryDirection.ShortOnly;
				miOff.IsChecked = false;
				miBoth.IsChecked = false;
				miLong.IsChecked = false;
				miShort.IsChecked = true;
			};
			menuControl.Items.Add(miShort);
			menuControl.Items.Add(new Separator());

			miBreakEven = new MenuItem { Header = "Move Stop to BE", Name = "ARCBreakEven", Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = false };
			miBreakEven.Click += (_, __) => TriggerCustomEvent(___ => SetStopToEntryPrice(), null);
			menuControl.Items.Add(miBreakEven);
			menuControl.Items.Add(new Separator());

			miStopLoss = new MenuItem { Header = "SL Ticks:   " + stopLossUserOverride, Foreground = Brushes.Black, FontWeight = FontWeights.Normal, StaysOpenOnClick = true };
			miStopLoss.Click += (_, e) => TriggerCustomEvent(__ => SetStopOverride(stopLossUserOverride + 1), orderBarsIdx, null);
			miStopLoss.MouseWheel += (_, e) => TriggerCustomEvent(__ => SetStopOverride(stopLossUserOverride + e.Delta.CompareTo(0)), orderBarsIdx, null);
			menuControl.Items.Add(miStopLoss);

			miMoveStop = new MenuItem { Header = "Move Stop", Name = "ARCMoveStop", Foreground = Brushes.Black, FontWeight = FontWeights.Normal, IsCheckable = false };
			miMoveStop.Click += (_, __) => TriggerCustomEvent(___ => SetStopToUserOverride(), null);
			menuControl.Items.Add(miMoveStop);

			customToolbarControlsGrid = new Grid { Visibility = Visibility.Collapsed };
			customToolbarControlsGrid.Children.Add(menuControlContainer);

			chartWindow.MainMenu.Add(customToolbarControlsGrid);
			chartWindow.MainTabControl.SelectionChanged += TabSelectionChangedHandler;

			if (ReferenceEquals(chartWindow.MainTabControl.SelectedContent, ChartControl.ChartTab))
				customToolbarControlsGrid.Visibility = Visibility.Visible;

			AutomationProperties.SetAutomationId(customToolbarControlsGrid, customToolbarControlsGridAutomationId);
		}

		private void TabSelectionChangedHandler(object sender, SelectionChangedEventArgs e)
		{
			if (e.AddedItems.Count <= 0)
				return;

			var tabItem = e.AddedItems[0] as TabItem;
			if (tabItem == null)
				return;

			var temp = tabItem.Content as ChartTab;
			if (temp != null && customToolbarControlsGrid != null)
				customToolbarControlsGrid.Visibility = temp.ChartControl == ChartControl ? Visibility.Visible : Visibility.Collapsed;
		}

		private void SetStopOverride(double ticks)
		{
			stopLossUserOverride = ticks;
			if (!IsInStrategyAnalyzer)
				ChartControl.Dispatcher.InvokeAsync(() => miStopLoss.Header = "SL Ticks:   " + ticks);
		}
		#endregion

		#region Order Handling
		/*
         * NOTE: Backtest execution seems to be fairly different depending on the current bars in progress, for max accuracy, we need to execute
         * while on the tick time frame. This is either an NT8 execution engine limitation (as hinted at by documentation), or because of the order
         * bars are arriving in (meaning the tick to cap a bar arrives after the bar it caps).
         */
		
		private void HandleExitExecution(Execution execution, int quantity)
		{
			int orderIdx;
			if (string.IsNullOrWhiteSpace(execution.Order.FromEntrySignal) || !int.TryParse(execution.Order.FromEntrySignal.Substring(1), out orderIdx))
				return;
			orderIdx -= 1;

			// If we've executed, partially or otherwise, our stop loss then adjust or cancel out take profit
			var stop = orderTracker.stopLossOrders[orderIdx];
			var target = orderTracker.targetOrders[orderIdx];
			if (stop == null || target == null)
				return;

			if (stop.OrderId == execution.OrderId)
			{
				if (target.ARC_TrendStepperAlgo_IsTerminal())
					return;

				if (target.QuantityChanged <= quantity)
					CancelOrder(target);
				else
					ChangeOrder(target, target.QuantityChanged - quantity, target.LimitPrice, target.StopPrice);
			}
			else if (target.OrderId == execution.OrderId)
			{
				if (stop.ARC_TrendStepperAlgo_IsTerminal())
					return;

				if (stop.QuantityChanged <= quantity)
					CancelOrder(stop);
				else
					ChangeOrder(stop, stop.QuantityChanged - quantity, stop.LimitPrice, stop.StopPrice);
			}
		}

		private void HandleEntryExecution(Execution execution, double price, int quantity)
		{
			var orderIdx = int.Parse(execution.Order.Name.Substring(1)) - 1;
			var dir = execution.Order.IsLong ? 1 : -1;
			var sl = Math.Max(0, price - dir * StopLoss * (StopLossType == ARC_TrendStepperAlgo_StopLossType.Ticks ? TickSize : stopLossAtr[0]));
			
			if (orderTracker.stopLossOrders[orderIdx] == null)
			{
				var slOrder = dir == 1
					? ExitLongStopMarket(orderBarsIdx, true, quantity, sl, "Stop loss", execution.Order.Name)
					: ExitShortStopMarket(orderBarsIdx, true, quantity, sl, "Stop loss", execution.Order.Name);
				pendingBarPlotSl = dir == 1 
					? Math.Min(orderTracker.MinStopLossValue, sl)
					: Math.Max(orderTracker.MaxStopLossValue, sl);
				if (slOrder == null)
					throw new Exception("Couldn't set stop loss!");
			}
			else
			{
				var newPrice = (orderTracker.stopLossOrders[orderIdx].StopPrice * orderTracker.stopLossOrders[orderIdx].Quantity + sl * quantity) / (orderTracker.stopLossOrders[orderIdx].Quantity + quantity);
				pendingBarPlotSl = dir == 1 
					? Math.Min(orderTracker.MinStopLossValue, newPrice)
					: Math.Max(orderTracker.MaxStopLossValue, newPrice);
				ChangeOrder(orderTracker.stopLossOrders[orderIdx], orderTracker.stopLossOrders[orderIdx].Quantity + quantity, 0, newPrice);
			}

			double tpValue;
			switch (orderIdx)
			{
			case 0:
				tpValue = ProfitTargetValue1;
				break;
			case 1:
				tpValue = ProfitTargetValue2;
				break;
			case 2:
				tpValue = ProfitTargetValue3;
				break;
			default:
				throw new IndexOutOfRangeException();
			}

			if (tpValue <= 0) 
				return;

			double tpBaseOffset;
			switch (TargetType)
			{
			case ARC_TrendStepperAlgo_TargetType.Ticks:
				tpBaseOffset = TickSize;
				break;
			case ARC_TrendStepperAlgo_TargetType.RR:
				tpBaseOffset = Math.Abs(price - sl);
				break;
			case ARC_TrendStepperAlgo_TargetType.ATR:
				tpBaseOffset = targetAtr[0];
				break;
			default:
				throw new ArgumentOutOfRangeException();
			}

			var tp = Math.Max(0, price + dir * tpValue * tpBaseOffset * pendingTpMultiple);
			if (orderTracker.targetOrders[orderIdx] != null)
			{
				var newPrice = ((UseMitTargetOrders ? orderTracker.targetOrders[orderIdx].StopPrice : orderTracker.targetOrders[orderIdx].LimitPrice) * orderTracker.targetOrders[orderIdx].Quantity + tp * quantity) / (orderTracker.targetOrders[orderIdx].Quantity + quantity);
				ChangeOrder(orderTracker.targetOrders[orderIdx], orderTracker.targetOrders[orderIdx].Quantity + quantity, UseMitTargetOrders ? 0 : newPrice, UseMitTargetOrders ? newPrice : 0);
				pendingBarPlotTp[orderIdx] = newPrice;
				return;
			}

			Order tpOrder;
			if (UseMitTargetOrders)
			{
				tpOrder = dir == 1
					? ExitLongMIT(orderBarsIdx, true, quantity, tp, "Profit target", execution.Order.Name)
					: ExitShortMIT(orderBarsIdx, true, quantity, tp, "Profit target", execution.Order.Name);
			}
			else
			{
				tpOrder = dir == 1
					? ExitLongLimit(orderBarsIdx, true, quantity, tp, "Profit target", execution.Order.Name)
					: ExitShortLimit(orderBarsIdx, true, quantity, tp, "Profit target", execution.Order.Name);
			}

			pendingBarPlotTp[orderIdx] = tp;
			if (tpOrder == null)
				throw new Exception("Couldn't set profit target!");
		}

		private void UpdateStop()
		{
			if (Position.MarketPosition == MarketPosition.Flat)
				return;

			var dir = Position.MarketPosition == MarketPosition.Long ? 1 : -1;
			var stop = dir == 1 ? 0 : double.MaxValue;

			var extreme = dir == 1 ? High[0] : Low[0];
			var crossedTrailTrigger = extreme.ApproxCompare(Position.AveragePrice + dir * TrailTriggerTicks * TickSize) == dir;
			if (crossedTrailTrigger)
			{
				if (TrailLookbackBars != 0)
				{
					var priceSeries = dir == 1 ? Lows[0] : Highs[0];
					var barsAgo = dir == 1 ? LowestBar(priceSeries, TrailLookbackBars) : HighestBar(priceSeries, TrailLookbackBars);
					stop = priceSeries[barsAgo];
				}
				else if (TrailTicks > 0)
				{
					stop = extreme;
				}

				stop -= dir * TrailTicks * TickSize;
			}

			if (BreakEvenTrigger > 0 && extreme.ApproxCompare(Position.AveragePrice + dir * BreakEvenTrigger * TickSize) != -dir)
				stop = dir == 1 ? Math.Max(stop, Position.AveragePrice + BreakEvenPlus * TickSize) : Math.Min(stop, Position.AveragePrice - BreakEvenPlus * TickSize);

			// If our stop is closer to our target then the target value, do nothing
			if (stop.ApproxCompare(dir == 1 ? orderTracker.MaxStopLossValue : orderTracker.MinStopLossValue) != dir)
				return;

			if (stop.ApproxCompare(dir == 1 ? GetCurrentBid() : GetCurrentAsk()) != dir)
				SetStopLoss(stop);
			else
				ExitPosition("Stop loss");
		}

		private void SubmitOrder(int direction, double price)
		{
			if (direction == 0 || !mmCanTrade)
				return;

			var orderPref = direction == 1 ? "L" : "S";

			var quantities = TargetQuantities;
			var replacingOrder = Enumerable.Range(0, quantities.Length)
				.Select(i => orderTracker[i] != null)
				.ToArray();
			for (var i = 0; i < quantities.Length; i++)
			{
				if (quantities[i] == 0 || !replacingOrder[i])
					continue;

				if (orderTracker[i].ARC_TrendStepperAlgo_Direction() != -direction && (orderTracker[i].OrderType != OrderType.Limit || EntryOrderType == ARC_TrendStepperAlgo_EntryOrderType.Limit || orderTracker[i].LimitPrice.ApproxCompare(price) == 0))
					continue;

				CancelOrder(orderTracker[i]);
				orderTracker[i] = null;
				replacingOrder[i] = false;
			}

			var rejectedBasedOnPrice = false;
			for (var i = 0; i < quantities.Length; i++)
			{
				if (quantities[i] == 0)
					continue;

				// Process individual orders
				var orderName = orderPref + (i + 1);
				switch (EntryOrderType)
				{
				case ARC_TrendStepperAlgo_EntryOrderType.Market:
					if (orderTracker[i] != null)
						continue;

					orderTracker[i] = direction == 1
						? EnterLong(orderBarsIdx, quantities[i], orderName)
						: EnterShort(orderBarsIdx, quantities[i], orderName);
					break;
				case ARC_TrendStepperAlgo_EntryOrderType.Limit:
					// TODO Move this price protection to cover everything except market orders
					var p = price - direction * LimitEntryOffsetTicks * TickSize;
					if (p.ApproxCompare(direction == 1 ? GetCurrentAsk() : GetCurrentBid()) == direction)
					{
						rejectedBasedOnPrice = true;
						continue;
					}

					if (orderTracker[i] == null)
					{
						orderTracker[i] = direction == 1
							? EnterLongLimit(orderBarsIdx, true, quantities[i], p, orderName)
							: EnterShortLimit(orderBarsIdx, true, quantities[i], p, orderName);
						continue;
					}

					// Determine if this is a switch from stop to limit at the same price
					if (orderTracker[i].OrderType == OrderType.StopMarket && orderTracker[i].StopPrice.ApproxCompare(price) == 0)
						continue;

					if (orderTracker[i].LimitPrice.ApproxCompare(p) == 0)
						continue;

					orderTracker[i] = direction == 1
						? EnterLongLimit(orderBarsIdx, true, quantities[i], p, orderName)
						: EnterShortLimit(orderBarsIdx, true, quantities[i], p, orderName);
					break;
				}
			}

			if (EntryOrderType != ARC_TrendStepperAlgo_EntryOrderType.Market && !replacingOrder.Any(i => i))
				orderTracker.lastPendingOrderInitiation = CurrentBars[0];
			if (rejectedBasedOnPrice)
				barToPaintAsInvalidPriceCancellation = lastSignalBar + 1;
		}

		/// <summary>
		/// Queues an entry in the provided direction, which will execute on the next available primary bar, as long as it's not preceded by gap bars
		/// </summary>
		protected void QueueEntry(int dir, double tpMultiple = 1)
		{
			if (BarsInProgress == 0 && (PendingEntryDir != dir || pendingTpMultiple.ApproxCompare(tpMultiple) != 0))
				BackBrush = dir == 1 ? longStripBrush : shortStripBrush;

			PendingEntryDir = dir;
			pendingTpMultiple = tpMultiple;
			if (BarsInProgress == 0)
			{
				lastSignalBar = CurrentBars[0];
			}
			else
			{
				lastSignalDir = dir;
				lastSignalBar = CurrentBars[0] + 1;
			}
		}

		protected void SetStopLoss(double price)
		{
			if (Position.MarketPosition == MarketPosition.Flat)
				return;

			if (price <= double.Epsilon)
				return;

			var dir = Position.MarketPosition == MarketPosition.Long ? 1 : -1;
			for (var i = 0; i < orderTracker.Count; i++)
			{
				if (orderTracker.stopLossOrders[i] == null || price.ApproxCompare(orderTracker.stopLossOrders[i].StopPrice) != dir)
					continue;

				if (!orderTracker.stopLossOrders[i].ARC_TrendStepperAlgo_IsTerminal())
					ChangeOrder(orderTracker.stopLossOrders[i], TargetQuantities[i], 0, price);
			}
		}

		protected void ExitPosition(string orderName)
		{
			if (Position.MarketPosition == MarketPosition.Flat || orderTracker.cancelOrder != null)
				return;

			orderTracker.cancelOrder = Position.MarketPosition == MarketPosition.Long ?
				ExitLong(orderBarsIdx, 0, orderName, "")
				: ExitShort(orderBarsIdx, 0, orderName, "");
		}

		protected void CancelPendingEntries()
		{
			if (!orderTracker.IsPendingEntryOrders)
			{
				PendingEntryDir = 0;
				return;
			}

			orderTracker
				.Where(o => o != null && o.OrderType != OrderType.Market && !o.ARC_TrendStepperAlgo_IsTerminal())
				.ToList()
				.ForEach(CancelOrder);
		}

		private void SetStopToEntryPrice()
		{
			if (Position.MarketPosition == MarketPosition.Flat)
				return;

			var dir = Position.MarketPosition == MarketPosition.Long ? 1 : -1;

			// If the stop closest to where we started is already at or above the entry price, do nothing
			if (Position.AveragePrice.ApproxCompare(dir == 1 ? orderTracker.MinStopLossValue : orderTracker.MaxStopLossValue) != -dir)
				return;

			// If our entry price is on the wrong side of the relevant bid ask price, do nothing
			if ((dir == 1 ? GetCurrentBid() : GetCurrentAsk()).ApproxCompare(Position.AveragePrice) != dir)
				return;
			
			SetStopLoss(Position.AveragePrice);
		}

		private void SetStopToUserOverride()
		{
			if (Position.MarketPosition == MarketPosition.Flat)
				return;
			var dir = Position.MarketPosition == MarketPosition.Long ? 1 : -1;
			var sl = Position.AveragePrice - dir * stopLossUserOverride * TickSize;
			if ((dir == 1 ? GetCurrentBid() : GetCurrentAsk()).ApproxCompare(sl) == dir)
				SetStopLoss(sl);
		}

		private void ProcessPendingEntries(int signalBarOffset = 0)
		{
			if (CurrentBars[0] - signalBarOffset < Math.Max(BarsRequiredToTrade, 1) || CurrentBars[orderBarsIdx] < 1)
				return;

			if (PendingEntryDir == 0)
				return;

			// Don't enter on any bar occurring after a gap bar
			var curEntry = PendingEntryDir;
			PendingEntryDir = 0;

			// Only enter if the just completed bar was a signal bar
			if (!TradeAllowedByFilters(curEntry))
				return;

			// Enter if possible and needed, otherwise just exit (limit orders are entered on the execution of the reversal exit)
			var positionOpposesSignal = Position.MarketPosition == (curEntry == 1 ? MarketPosition.Short : MarketPosition.Long);
			lastEntryBar = CurrentBars[0] - signalBarOffset;
			if (positionOpposesSignal && (OnOppositeSignal == ARC_TrendStepperAlgo_OppositeSignalAction.ExitOnly || (OnOppositeSignal == ARC_TrendStepperAlgo_OppositeSignalAction.Reverse && EntryOrderType == ARC_TrendStepperAlgo_EntryOrderType.Limit)))
				ExitPosition(OppositeOrderName);
			if (Position.MarketPosition == MarketPosition.Flat || (positionOpposesSignal && OnOppositeSignal == ARC_TrendStepperAlgo_OppositeSignalAction.Reverse && EntryOrderType == ARC_TrendStepperAlgo_EntryOrderType.Market))
			{
				foreach (var o in orderTracker.stopLossOrders.Concat(orderTracker.targetOrders).Where(o => o != null))
					CancelOrder(o);
				SubmitOrder(curEntry, Closes[0][signalBarOffset]);
			}
		}
		#endregion
		
		/// <summary>
		/// Adds the provided series if it doesn't already exist. Either way returns the index of the data series
		/// </summary>
		protected int EnsureDataSeriesAdded(BarsPeriodType periodType, int period, MarketDataType marketDataType = MarketDataType.Last)
		{
			var idx = Array.FindIndex(BarsPeriods, b => b.BarsPeriodType == periodType && b.Value == period && b.MarketDataType == marketDataType);
			if (idx != -1)
				return idx;

			AddDataSeries(periodType, period);
			return BarsArray.Length - 1;
		}

		private void ResetPerRunCustomValues()
		{
			pendingBarPlotSl = null;
			pendingBarPlotTp = new double?[3];
			lastSessionClosedPnl = 0;
			tradeCountAtLastSessionClosedPnlRefresh = 0;
			lastMmResetAtLastSessionClosedPnlRefresh = default(DateTime);
			tradeCountAtLastMmReset = 0;
			lastMmReset = default(DateTime);
			mmMaxGain = 0;
			mmCanTrade = true;
			firstTickOfPrimaryBar = false;
			lastEntryBar = -1;
			PendingEntryDir = 0;
			barToPaintAsInvalidPriceCancellation = -1;
			lastSignalBar = 0;
			lastSignalDir = 0;
			pendingTpMultiple = 1;
		}

		protected virtual void OnPrimaryBar()
		{ }

		protected virtual void OnTickBar()
		{ }

		protected bool TradeAllowedByFilters(int dir)
		{
			// Allowed dir
			if (AllowedEntryDirections != ARC_TrendStepperAlgo_AllowedEntryDirection.LongAndShort && AllowedEntryDirections != (dir == 1 ? ARC_TrendStepperAlgo_AllowedEntryDirection.LongOnly : ARC_TrendStepperAlgo_AllowedEntryDirection.ShortOnly))
				return false;

			if ((RunType == ARC_TrendStepperAlgo_RunType.RealTime && State == State.Historical) || (RunType == ARC_TrendStepperAlgo_RunType.BackTest && State == State.Realtime))
				return false;

			if (!mmCanTrade)
				return false;

			if (Position.MarketPosition == (dir == 1 ? MarketPosition.Long : MarketPosition.Short))
				return false;

			if (OnOppositeSignal == ARC_TrendStepperAlgo_OppositeSignalAction.None && Position.MarketPosition != MarketPosition.Flat)
				return false;

			// Excursion blocking
			if (BlockLevelEntry != 0)
			{
				Series<double> series;
				switch (BlockLevelEntry)
				{
				case 1:
					series = dir == 1 ? indMomo.PriceExcursionUL1 : indMomo.PriceExcursionLL1;
					break;
				case 2:
					series = dir == 1 ? indMomo.PriceExcursionUL2 : indMomo.PriceExcursionLL2;
					break;
				case 3:
					series = dir == 1 ? indMomo.PriceExcursionUL3 : indMomo.PriceExcursionLL3;
					break;
				default:
					throw new Exception("Invalid Block Level Entry Setting");
				}

				if (indMomo.Histogram[0].ApproxCompare(series[0]) != -dir)
					return false;
			}

			// VM bias / confluence
			if (!OverridesVMBiasAndConfluenceHandling)
			{
				// Momo Color
				if (UseVMBias && (VMBiasType == ARC_TrendStepperAlgo_VMAlgo_BiasType.ZeroLine ? indMomo.Histogram : indMomo.StructureBiasState)[0].ApproxCompare(0) != dir)
					return false;

				// Momo Confluence
				if (UseVMConfluence && indMomo.BBMACD[0].ApproxCompare(0) != dir)
					return false;
			}

			// Ma filter
			if (UseHTFMovingAverage)
			{
				if (MAType != ARC_TrendStepperAlgo_MovingAverageType.StepMA && CurrentBars[htfBarsIdx] < 0)
					return false;

				if (MAType == ARC_TrendStepperAlgo_MovingAverageType.StepMA && FilterMATrendType == ARC_TrendStepperAlgo_StepMaTrendType.Trend)
				{
					if (((ARC_TrendStepperAlgo_ARC_TrendStepper) filterMa).LastMovementDir != dir)
						return false;
				}
				else
				{
					if (Closes[0][0].ApproxCompare(filterMa[0]) != dir)
						return false;

					var anchor = dir == 1
						? Low[0] * MABarBiasPercentRequirement / 100 + High[0] * (1 - MABarBiasPercentRequirement / 100)
						: High[0] * MABarBiasPercentRequirement / 100 +
						Low[0] * (1 - MABarBiasPercentRequirement / 100);

					if (anchor.ApproxCompare(filterMa[0]) != dir)
						return false;
				}
			}

			// Time window
			if (!InValidTradingWindow(Times[orderBarsIdx][0]))
				return false;

			// Market structure filter
			if (UseMsFilter)
			{
				if (msFilterZigZag.SwingPoints.Count < 4)
					return false;

				// Select the prices of the last 4 zig zag points
				var lastPoints = msFilterZigZag.SwingPoints
					.Skip(msFilterZigZag.SwingPoints.Count - 4)
					.Take(4)
					.ToArray();

				// Points alternate between high and low, so compare in pairs separated by 1 to ensure directionality
				if (lastPoints[2].Price.ApproxCompare(lastPoints[0].Price) != dir || lastPoints[3].Price.ApproxCompare(lastPoints[1].Price) != dir)
					return false;
			}

			return true;
		}

		private void SyncPnlPlot()
		{
			indPnlChart.OpenPnl = Position.MarketPosition == MarketPosition.Flat ? 0 : Position.GetUnrealizedProfitLoss(PerformanceUnit.Currency, Closes[orderBarsIdx][0]);
			if (Position.MarketPosition == MarketPosition.Flat)
			{
				indPnlChart.SessionClosedPnl = SessionClosedPnl;
				indPnlChart.ChartTotalClosedPnl = ChartClosedPnl;
			}

			var plotIdx = !DashHistoricPnl || State == State.Realtime ? 0 : 1;
			indPnlChart.Values[plotIdx][0] = indPnlChart.ChartTotalClosedPnl + indPnlChart.OpenPnl;
			indPnlChart.PlotBrushes[plotIdx][0] = indPnlChart.Values[plotIdx][0] < 0 ? Brushes.Red : Brushes.Green;
		}

		private void SyncStopPlots()
		{
			var sl = pendingBarPlotSl ?? orderTracker.MinStopLossValue;
			pendingBarPlotSl = null;
			if (sl > double.Epsilon)
				indStopTrg.SetStop(sl);
		}

		private void SyncTargetPlots()
		{
			for (var i = 0; i < orderTracker.Count; i++)
			{
				var order = orderTracker.targetOrders[i];
				if (pendingBarPlotTp[i] == null && (order == null || order.ARC_TrendStepperAlgo_IsTerminal()))
					continue;
				
				var tp = pendingBarPlotTp[i] ?? (UseMitTargetOrders ? order.StopPrice : order.LimitPrice);
				pendingBarPlotTp[i] = null;
				indStopTrg.SetTarget(tp, i);
			}
		}

		private void ResetMoneyManagement()
		{
			lastSessionClosedPnl = 0;
			mmMaxGain = 0;
			lastMmReset = Times[orderBarsIdx][0];
			tradeCountAtLastMmReset = SystemPerformance.AllTrades.Count;
			tradeCountAtLastSessionClosedPnlRefresh = tradeCountAtLastMmReset;
			mmCanTrade = true;
			indPnlChart.SessionClosedPnl = 0;
		}

		private void SyncMoneyManagement(double price)
		{
			// Get current session open pnl
			var unRealizedPnl = Position == null || Position.MarketPosition == MarketPosition.Flat ? 0d : Position.GetUnrealizedProfitLoss(PerformanceUnit.Currency, price);
			var sessionOpenPnl = SessionClosedPnl;
			if (HighWaterMarkType == ARC_TrendStepperAlgo_HighWaterMarkType.RealizedPlusUnrealized)
				sessionOpenPnl += unRealizedPnl;

			// Track high watermark
			if (HighWaterMarkType != ARC_TrendStepperAlgo_HighWaterMarkType.Off) 
				mmMaxGain = Math.Max(mmMaxGain, sessionOpenPnl);

			// If we're already out of trading, do nothing
			if (!mmCanTrade)
				return;

			string messageCore;

			// High watermark
			if (HighWaterMarkType != ARC_TrendStepperAlgo_HighWaterMarkType.Off && mmMaxGain > HwmActivatedAt && sessionOpenPnl < mmMaxGain * (1 - DailyHighWaterMarkPct / 100))
				messageCore = "Higher water mark %";
			// Daily max gain
			else if (DayMaxGain != 0 && SessionClosedPnl + unRealizedPnl >= DayMaxGain)
				messageCore = "Daily Profit Goal";
			// Daily max loss
			else if (DayMaxLoss != 0 && SessionClosedPnl + unRealizedPnl <= -DayMaxLoss)
				messageCore = "Max Daily Loss";
			else
				return;

			mmCanTrade = false;
			if (State != State.Realtime)
				return;

			// Warn the user that we won't exit the trade for them, and how to do so themselves
			const string messageFormat = "Money Management: {0} has been reached.\nTrading will be halted automatically AFTER the current trade is closed.\nTo close the current trade NOW, click OFF in the UI dropdown menu.";
			var message = string.Format(messageFormat, messageCore);
			Dispatcher.InvokeAsync(() => NTMessageBox.Show(message, "Warning!", MessageBoxButton.OK, MessageBoxImage.Asterisk));
			Log(message, LogLevel.Warning);
		}

		protected bool InValidTradingWindow(DateTime t)
		{
			if (StartTime == 0 && EndTime == 0)
				return true;

			if (IgnoreTradeTime)
				return true;

			return (t.DayOfWeek != DayOfWeek.Friday || t.ARC_TrendStepperAlgo_CompareTime(2500) != 1) && t.ARC_TrendStepperAlgo_InRange(StartTime, EndTime);
		}

		public override string ToString()
		{
			return ProductName + " " + ProductVersion;
		}

		#region Parameters
		protected const string StrategyParameterGroupName = "Strategy Parameters";
		protected const string StrategyVisualsParameterGroupName = "Strategy Visuals";
		protected const string ProductInfoGroupName = "Product Info";

		/*
		 * NOTE: For bool properties that conditional property depend on, we must use a bool enum property as an intermediate, or it won't work in optimization.
		 */

		#region Entry
		protected const string EntryGroupName = "Entries";

		[NinjaScriptProperty]
		[Display(Name = "Entry Direction", Order = 1, GroupName = EntryGroupName, Description = "Entry Direction")]
		public ARC_TrendStepperAlgo_AllowedEntryDirection AllowedEntryDirections { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Quantity 1", Order = 2, GroupName = EntryGroupName, Description = "Quantity associated with entry 1")]
		[XmlElement("Target1Quantity")]
		public int Entry1Quantity { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[RefreshProperties(RefreshProperties.All)]
		[XmlElement("Target2Quantity")]
		[Display(Name = "Quantity 2", Order = 3, GroupName = EntryGroupName, Description = "Quantity associated with entry 2")]
		public int Entry2Quantity { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[RefreshProperties(RefreshProperties.All)]
		[XmlElement("Target3Quantity")]
		[Display(Name = "Quantity 3", Order = 4, GroupName = EntryGroupName, Description = "Quantity associated with entry 3")]
		public int Entry3Quantity { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Entry Order Type", Order = 5, GroupName = EntryGroupName, Description = "Entry Order Type")]
		public ARC_TrendStepperAlgo_EntryOrderType EntryOrderType { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[ARC_TrendStepperAlgo_HideUnless("EntryOrderType", ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_EntryOrderType.Limit)]
		[Display(Name = "Entry Offset Ticks", Order = 6, GroupName = EntryGroupName, Description = "Offset ticks for Limit Order")]
		public int LimitEntryOffsetTicks { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Action On Opposite Signal", Order = 7, GroupName = EntryGroupName)]
		public ARC_TrendStepperAlgo_OppositeSignalAction OnOppositeSignal { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[ARC_TrendStepperAlgo_HideUnless("EntryOrderType", ARC_TrendStepperAlgo_PropComparisonType.NEQ, ARC_TrendStepperAlgo_EntryOrderType.Market)]
		[Display(Name = "Max Pending Order Bars", Order = 8, GroupName = EntryGroupName)]
		public int MaxPendingOrderBars { get; set; }
		
		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(ARC_TrendStepperAlgo_BoolEnumConverter))]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TrendStepperAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Limit Pre-Order Gap Bars", Order = 9, GroupName = EntryGroupName)]
		public ARC_TrendStepperAlgo_BoolEnum LimitPreOrderGapBarsEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool LimitPreOrderGapBars
		{
			get { return LimitPreOrderGapBarsEnum == ARC_TrendStepperAlgo_BoolEnum.True; }
			set { LimitPreOrderGapBarsEnum = value ? ARC_TrendStepperAlgo_BoolEnum.True : ARC_TrendStepperAlgo_BoolEnum.False; }
		}

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[ARC_TrendStepperAlgo_HideUnless("LimitPreOrderGapBarsEnum", ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_BoolEnum.True)]
		[Display(Name = "Max Pre-Order Gap Bars", Order = 10, GroupName = EntryGroupName)]
		public int MaxPreOrderGapBars { get; set; }
		#endregion

		#region Stops
		protected const string StopLossGroupName = "Stop Losses";

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Stop Loss Type", Order = 0, GroupName = StopLossGroupName)]
		public ARC_TrendStepperAlgo_StopLossType StopLossType { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_TrendStepperAlgo_HideUnless("StopLossType", ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_StopLossType.ATR)]
		[Display(Name = "Stop Loss ATR Period", Order = 1, GroupName = StopLossGroupName)]
		public int StopLossATRPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_TrendStepperAlgo_Rename("Stop Loss (Ticks)", "StopLossType", ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_StopLossType.Ticks)]
		[ARC_TrendStepperAlgo_Rename("Stop Loss (ATRs)", "StopLossType", ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_StopLossType.ATR)]
		[XmlElement("StopLossTicks")]
		[Display(Name = "Stop Loss", Order = 2, GroupName = StopLossGroupName)]
		public double StopLoss { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "Trail Trigger", Order = 3, GroupName = StopLossGroupName, Description = "Number of ticks to in profit to enable the trail")]
		public int TrailTriggerTicks { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "Trail # Bars Back", Order = 4, GroupName = StopLossGroupName, Description = "Set this to 1 for tight management, greater than 1 for loose management (where the value you place is the number of bars lookback for the high / low price)")]
		public int TrailLookbackBars { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name = "Trail Tick Offset", Order = 5, GroupName = StopLossGroupName, Description = "Offset ticks for trail.")]
		public double TrailTicks { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Range(0, double.MaxValue)]
		[Display(Name = "BreakEven Trigger", Order = 6, GroupName = StopLossGroupName, Description = "Number of ticks in profit to break event")]
		public double BreakEvenTrigger { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_TrendStepperAlgo_HideUnless("BreakEvenTrigger", ARC_TrendStepperAlgo_PropComparisonType.NEQ, 0d)]
		[Display(Name = "BreakEven Plus", Order = 7, GroupName = StopLossGroupName)]
		public double BreakEvenPlus { get; set; }
		#endregion

		#region Targets
		protected const string TargetsGroupName = "Targets";

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "Target Type", Order = 0, GroupName = TargetsGroupName)]
		public ARC_TrendStepperAlgo_TargetType TargetType { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_TrendStepperAlgo_HideUnless("TargetType", ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_TargetType.ATR)]
		[Display(Name = "ATR Period", Order = 1, GroupName = TargetsGroupName)]
		public int TargetATRPeriod { get; set; }

		[NinjaScriptProperty]
		[XmlElement("UseMITsForTargets")]
		[Display(Name = "Use MIT Targets", Order = 2, GroupName = TargetsGroupName)]
		public bool UseMitTargetOrders { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_TrendStepperAlgo_Rename("Profit Target 1 (Ticks)", "TargetType", ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_TargetType.Ticks)]
		[ARC_TrendStepperAlgo_Rename("Profit Target 1 (ATRs)", "TargetType", ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_TargetType.ATR)]
		[ARC_TrendStepperAlgo_Rename("Profit Target 1 (RR)", "TargetType", ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_TargetType.RR)]
		[Display(Name = "Profit Target 1", Description = "Static St = # Ticks, RR = Multiplier factor", Order = 3, GroupName = TargetsGroupName)]
		[XmlElement("ProfitTargetTicks1")]
		public double ProfitTargetValue1 { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_TrendStepperAlgo_HideUnless("Entry2Quantity", ARC_TrendStepperAlgo_PropComparisonType.GT, 0)]
		[ARC_TrendStepperAlgo_Rename("Profit Target 2 (Ticks)", "TargetType", ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_TargetType.Ticks)]
		[ARC_TrendStepperAlgo_Rename("Profit Target 2 (ATRs)", "TargetType", ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_TargetType.ATR)]
		[ARC_TrendStepperAlgo_Rename("Profit Target 2 (RR)", "TargetType", ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_TargetType.RR)]
		[XmlElement("ProfitTargetTicks2")]
		[Display(Name = "Profit Target 2", Description = "Static St = # Ticks, RR = Multiplier factor", Order = 4, GroupName = TargetsGroupName)]
		public double ProfitTargetValue2 { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_TrendStepperAlgo_HideUnless("Entry3Quantity", ARC_TrendStepperAlgo_PropComparisonType.GT, 0)]
		[ARC_TrendStepperAlgo_Rename("Profit Target 3 (Ticks)", "TargetType", ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_TargetType.Ticks)]
		[ARC_TrendStepperAlgo_Rename("Profit Target 3 (ATRs)", "TargetType", ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_TargetType.ATR)]
		[ARC_TrendStepperAlgo_Rename("Profit Target 3 (RR)", "TargetType", ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_TargetType.RR)]
		[XmlElement("ProfitTargetTicks3")]
		[Display(Name = "Profit Target 3", Description = "Static St = # Ticks, RR = Multiplier factor", Order = 5, GroupName = TargetsGroupName)]
		public double ProfitTargetValue3 { get; set; }
		#endregion

		#region Time Controls
		private const string TimeControlGroupName = "Time Controls";

		[NinjaScriptProperty]
		[Display(Name = "Run Type", Description = "Set to Backtest when backtesting, RealTime when trading in real-time", Order = 1, GroupName = TimeControlGroupName)]
		public ARC_TrendStepperAlgo_RunType RunType { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "Trade Start Time", Order = 2, GroupName = TimeControlGroupName, Description = "Time in hhmm 24-hour format")]
		public int StartTime { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "Trade End Time", Order = 3, GroupName = TimeControlGroupName, Description = "Time in hhmm 24-hour format")]
		public int EndTime { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Exit At End Time", Description = "Set to true to exit at the end time, false otherwise", Order = 4, GroupName = TimeControlGroupName)]
		public bool ExitAtEndTime { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Ignore Trade Time", Order = 5, GroupName = TimeControlGroupName, Description = "Set true to trade all the time")]
		public bool IgnoreTradeTime { get; set; }
		#endregion

		#region Money Management
		private const string MoneyManagementGroupName = "Money Management";
		
		[NinjaScriptProperty]
		[Display(Name = "Reset Pnl On Time Slot", Order = 1, GroupName = MoneyManagementGroupName, Description = "Restart Pnl Calculation at each time slot")]
		public bool RestartPnlOnSession { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "DayMaxGoal $", Order = 2, GroupName = MoneyManagementGroupName, Description = "Day Gain when achieved stop trading. 0 to disable")]
		public int DayMaxGain { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[Display(Name = "DayMaxLoss $", Order = 3, GroupName = MoneyManagementGroupName, Description = "Day Loss when achieved stop trading. 0 to disable")]
		public int DayMaxLoss { get; set; }

		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[Display(Name = "High Water Mark", Order = 4, GroupName = MoneyManagementGroupName, Description = "Day High Water Mark")]
		public ARC_TrendStepperAlgo_HighWaterMarkType HighWaterMarkType { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[ARC_TrendStepperAlgo_HideUnless("HighWaterMarkType", ARC_TrendStepperAlgo_PropComparisonType.NEQ, ARC_TrendStepperAlgo_HighWaterMarkType.Off)]
		[Display(Name = "High Water Mark %", Order = 5, GroupName = MoneyManagementGroupName, Description = "Day High Water Mark % DrawDown. 0 to disable")]
		public double DailyHighWaterMarkPct { get; set; }

		[NinjaScriptProperty]
		[Range(0, int.MaxValue)]
		[ARC_TrendStepperAlgo_HideUnless("HighWaterMarkType", ARC_TrendStepperAlgo_PropComparisonType.NEQ, ARC_TrendStepperAlgo_HighWaterMarkType.Off)]
		[Display(Name = "HWM Activated at $", Order = 6, GroupName = MoneyManagementGroupName, Description = "Min profit in dollars for the High Water Mark to activate")]
		public int HwmActivatedAt { get; set; }
		#endregion

		#region HTF Moving Averages
		private const string HTFMovingAveragesGroupName = "Moving Averages Filter";

		[RefreshProperties(RefreshProperties.All)]
		[ARC_TrendStepperAlgo_ShowOthersIf(ARC_TrendStepperAlgo_PropComparisonType.EQ, true, Properties = new []{ "MAType", "MATimeframe", "MAPeriod", "FilterMAStepSize" })]
		[Display(Name = "Show", Order = 0, GroupName = HTFMovingAveragesGroupName, Description = "Whether the strategy shows the moving average")]
		public bool ShowMA { get; set; }

		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_TrendStepperAlgo_ShowOthersIf(ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_BoolEnum.True, Properties = new []{ "MAType", "MATimeframe", "MAPeriod", "FilterMAStepSize" })]
		[TypeConverter(typeof(ARC_TrendStepperAlgo_BoolEnumConverter))]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TrendStepperAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Require", Order = 1, GroupName = HTFMovingAveragesGroupName)]
		public ARC_TrendStepperAlgo_BoolEnum UseHTFMovingAverageEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool UseHTFMovingAverage
		{
			get { return UseHTFMovingAverageEnum == ARC_TrendStepperAlgo_BoolEnum.True; }
			set { UseHTFMovingAverageEnum = value ? ARC_TrendStepperAlgo_BoolEnum.True : ARC_TrendStepperAlgo_BoolEnum.False; }
		}
		
		[NinjaScriptProperty]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_TrendStepperAlgo_HideByDefault]
		[Display(Name = "Type", Order = 2, GroupName = HTFMovingAveragesGroupName, Description = "Moving average type")]
		public ARC_TrendStepperAlgo_MovingAverageType MAType { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_TrendStepperAlgo_HideByDefault]
		[ARC_TrendStepperAlgo_HideUnless("MAType", ARC_TrendStepperAlgo_PropComparisonType.NEQ, ARC_TrendStepperAlgo_MovingAverageType.StepMA)]
		[Display(Name = "Timeframe Minutes", Order = 3, GroupName = HTFMovingAveragesGroupName, Description = "Timeframe to calculate moving average on in minutes")]
		public int MATimeframe { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_TrendStepperAlgo_HideByDefault]
		[ARC_TrendStepperAlgo_HideUnless("MAType", ARC_TrendStepperAlgo_PropComparisonType.NEQ, ARC_TrendStepperAlgo_MovingAverageType.StepMA)]
		[Display(Name = "Period", Order = 4, GroupName = HTFMovingAveragesGroupName, Description = "Period of the filter moving average")]
		public int MAPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_TrendStepperAlgo_HideByDefault]
		[ARC_TrendStepperAlgo_HideUnless("MAType", ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_MovingAverageType.StepMA)]
		[Display(Name = "Step Size", Order = 5, GroupName = HTFMovingAveragesGroupName, Description = "Step size of the filter moving average")]
		public int FilterMAStepSize { get; set; }

		[NinjaScriptProperty]
		[ARC_TrendStepperAlgo_HideUnless("UseHTFMovingAverageEnum", ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_BoolEnum.True)]
		[ARC_TrendStepperAlgo_HideUnless("MAType", ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_MovingAverageType.StepMA)]
		[Display(Name = "Step Method", Order = 6, GroupName = HTFMovingAveragesGroupName, Description = "The method step MA will use to determine direction")]
		public ARC_TrendStepperAlgo_StepMaTrendType FilterMATrendType { get; set; }

		[NinjaScriptProperty]
		[Range(0, 100)]
		[ARC_TrendStepperAlgo_HideUnless("UseHTFMovingAverageEnum", ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_BoolEnum.True)]
		[Display(Name = "Bar % HTF MA", Order = 7, GroupName = HTFMovingAveragesGroupName, Description = "The minimum percentage of the bar that must be on the right side of the MA.")]
		public double MABarBiasPercentRequirement { get; set; }

		[XmlIgnore]
		[ARC_TrendStepperAlgo_HideUnless("ShowMA", ARC_TrendStepperAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Color", Order = 8, GroupName = HTFMovingAveragesGroupName)]
		public Brush MAColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string MAColorSerializable
		{
			get { return Serialize.BrushToString(MAColor); }
			set { MAColor = Serialize.StringToBrush(value); }
		}
		#endregion

		#region Market Structure Filter
		protected const string MarketStructureFilterGroupName = "Market Structure Filter";

		[Browsable(false)]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_TrendStepperAlgo_ShowOthersIf(ARC_TrendStepperAlgo_PropComparisonType.EQ, true, Properties = new[] { "MsFilterSwingStrength", "MsFilterNeutralColor", "MsFilterUptrendColor", "MsFilterDowntrendColor" })]
		[Display(Name = "Show Zig Zag", Order = 0, GroupName = MarketStructureFilterGroupName, Description = "Whether the strategy shows the zigzag")]
		public bool ShowMsFilterZigZag { get; set; }

		[Browsable(false)]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_TrendStepperAlgo_ShowOthersIf(ARC_TrendStepperAlgo_PropComparisonType.EQ, true, Properties = new[] { "MsFilterSwingStrength", "MsFilterNeutralColor", "MsFilterUptrendColor", "MsFilterDowntrendColor" })]
		[Display(Name = "Show Bias Strip", Order = 1, GroupName = MarketStructureFilterGroupName, Description = "Whether the strategy shows bias strip at the bottom of the main panel")]
		public bool ShowMsFilterBiasStrip { get; set; }

		[Browsable(false)]
		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[ARC_TrendStepperAlgo_ShowOthersIf(ARC_TrendStepperAlgo_PropComparisonType.EQ, ARC_TrendStepperAlgo_BoolEnum.True, Properties = new[] { "MsFilterSwingStrength" })]
		[TypeConverter(typeof(ARC_TrendStepperAlgo_BoolEnumConverter))]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TrendStepperAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Require", Order = 2, GroupName = MarketStructureFilterGroupName)]
		public ARC_TrendStepperAlgo_BoolEnum UseMsFilterEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool UseMsFilter
		{
			get { return UseMsFilterEnum == ARC_TrendStepperAlgo_BoolEnum.True; }
			set { UseMsFilterEnum = value ? ARC_TrendStepperAlgo_BoolEnum.True : ARC_TrendStepperAlgo_BoolEnum.False; }
		}

		[Browsable(false)]
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[ARC_TrendStepperAlgo_HideByDefault]
		[Display(Order = 3, Name = "Swing Strength", GroupName = MarketStructureFilterGroupName, Description = "Number of bars used to identify a swing high or low")]
		public int MsFilterSwingStrength { get; set; }

		[Browsable(false)]
		[NinjaScriptProperty]
		[Display(Order = 4, Name = "Include Wicks", GroupName = MarketStructureFilterGroupName, Description = "Whether or not to use wicks (vs closes) for pivot points")]
		public bool MsFilterIncludeWicks { get; set; }

		[Browsable(false)]
		[XmlIgnore]
		[ARC_TrendStepperAlgo_HideByDefault]
		[Display(Name = "Neutral Zig Zag Color", Order = 5, GroupName = MarketStructureFilterGroupName)]
		public Brush MsFilterNeutralColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string MsFilterNeutralColorSerializable
		{
			get { return Serialize.BrushToString(MsFilterNeutralColor); }
			set { MsFilterNeutralColor = Serialize.StringToBrush(value); }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		[ARC_TrendStepperAlgo_HideByDefault]
		[Display(Name = "Uptrend Color", Order = 6, GroupName = MarketStructureFilterGroupName)]
		public Brush MsFilterUptrendColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string MsFilterUptrendColorSerializable
		{
			get { return Serialize.BrushToString(MsFilterUptrendColor); }
			set { MsFilterUptrendColor = Serialize.StringToBrush(value); }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		[ARC_TrendStepperAlgo_HideByDefault]
		[Display(Name = "Downtrend Color", Order = 7, GroupName = MarketStructureFilterGroupName)]
		public Brush MsFilterDowntrendColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string MsFilterDowntrendColorSerializable
		{
			get { return Serialize.BrushToString(MsFilterDowntrendColor); }
			set { MsFilterDowntrendColor = Serialize.StringToBrush(value); }
		}

		[Browsable(false)]
		[NinjaScriptProperty]
		[Range(1e-5f, float.MaxValue)]
		[ARC_TrendStepperAlgo_HideUnless("ShowMsFilterZigZag", ARC_TrendStepperAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Zig Zag Thickness", Order = 8, GroupName = MarketStructureFilterGroupName)]
		public float MsFilterZigZagThickness { get; set; }
		
		[Browsable(false)]
		[NinjaScriptProperty]
		[Range(1e-5f, float.MaxValue)]
		[ARC_TrendStepperAlgo_HideUnless("ShowMsFilterBiasStrip", ARC_TrendStepperAlgo_PropComparisonType.EQ, true)]
		[Display(Name = "Bias Strip Thickness", Order = 9, GroupName = MarketStructureFilterGroupName)]
		public float MsFilterBiasStripThickness { get; set; }
		#endregion

		#region VM Parameters
		protected const string VMLeanGroupName = "VM Lean";
		
		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(ARC_TrendStepperAlgo_BoolEnumConverter))]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TrendStepperAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Require VM Bias", Order = 0, GroupName = VMLeanGroupName)]
		public ARC_TrendStepperAlgo_BoolEnum UseVMBiasEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool UseVMBias
		{
			get { return UseVMBiasEnum == ARC_TrendStepperAlgo_BoolEnum.True; }
			set { UseVMBiasEnum = value ? ARC_TrendStepperAlgo_BoolEnum.True : ARC_TrendStepperAlgo_BoolEnum.False; }
		}
		
		[NinjaScriptProperty, XmlIgnore]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(ARC_TrendStepperAlgo_BoolEnumConverter))]
		[PropertyEditor("NinjaTrader.Custom.Strategies.Helpers.ARC.ARC_TrendStepperAlgo_NonOptimizationCheckBoxEditor")]
		[Display(Name = "Require VM Confluence", Order = 1, GroupName = VMLeanGroupName)]
		public ARC_TrendStepperAlgo_BoolEnum UseVMConfluenceEnum { get; set; }

		[Browsable(false), RefreshProperties(RefreshProperties.All)]
		public bool UseVMConfluence
		{
			get { return UseVMConfluenceEnum == ARC_TrendStepperAlgo_BoolEnum.True; }
			set { UseVMConfluenceEnum = value ? ARC_TrendStepperAlgo_BoolEnum.True : ARC_TrendStepperAlgo_BoolEnum.False; }
		}

		[NinjaScriptProperty]
		[Range(0, 3)]
		[Display(Name = "Enable Block Level", Order = 2, GroupName = VMLeanGroupName, Description = "0 to disable, this is the level at which to block if the histogram level is above / below")]
		public int BlockLevelEntry { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "VM Bias Type", Order = 3, GroupName = VMLeanGroupName)]
		public ARC_TrendStepperAlgo_VMAlgo_BiasType VMBiasType { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "VM Histogram Background", Order = 4, GroupName = VMLeanGroupName)]
		public bool VMHistogramBackground { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Period Bollinger Band", Order = 5, GroupName = VMLeanGroupName, Description = "Band Period for Bollinger Band")]
		public int BandPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Lookback fast EMA", Order = 6, GroupName = VMLeanGroupName, Description = "Period for fast EMA")]
		public int Fast { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Lookback slow EMA", Order = 7, GroupName = VMLeanGroupName, Description = "Period for slow EMA")]
		public int Slow { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name = "Std. dev. multiplier", Order = 8, GroupName = VMLeanGroupName, Description = "Number of standard deviations")]
		public double StdDevNumber { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Swing strength", Order = 9, GroupName = VMLeanGroupName, Description = "Number of bars used to identify a swing high or low")]
		public int VMSwingStrength { get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name = "Deviation multiplier", Order = 10, GroupName = VMLeanGroupName, Description = "Multiplier used to calculate minimum deviation as an ATR multiple")]
		public double MinDeviationMultiplier { get; set; }
		#endregion

		#region VM Plot Colors
		private const string VMLeanPlotsGroupName = "VM Lean Visuals";

		[XmlIgnore]
		[Display(Name = "Rising dots above channel ", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 0)]
		public Brush DotsUpRisingColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DotsUpRisingColorSerialize
		{
			get { return Serialize.BrushToString(DotsUpRisingColor); }
			set { DotsUpRisingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Rising dots inside/below channel ", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 1)]
		public Brush DotsDownRisingColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DotsDownRisingColorSerialize
		{
			get { return Serialize.BrushToString(DotsDownRisingColor); }
			set { DotsDownRisingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Falling dots below channel ", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 2)]
		public Brush DotsDownFallingColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DotsDownFallingColorSerialize
		{
			get { return Serialize.BrushToString(DotsDownFallingColor); }
			set { DotsDownFallingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Falling dots inside/above channel ", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 3)]
		public Brush DotsUpFallingColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DotsUpFallingColorSerialize
		{
			get { return Serialize.BrushToString(DotsUpFallingColor); }
			set { DotsUpFallingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Dots rim", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 4)]
		public Brush DotsRimColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DotsRimColorSerialize
		{
			get { return Serialize.BrushToString(DotsRimColor); }
			set { DotsRimColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bollinger average", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 5)]
		public Brush BBAverageColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string BBAverageColorSerialize
		{
			get { return Serialize.BrushToString(BBAverageColor); }
			set { BBAverageColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bollinger upper band", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 6)]
		public Brush BBUpperColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string BBUpperColorSerialize
		{
			get { return Serialize.BrushToString(BBUpperColor); }
			set { BBUpperColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bollinger lower band", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 7)]
		public Brush BBLowerColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string BBLowerColorSerialize
		{
			get { return Serialize.BrushToString(BBLowerColor); }
			set { BBLowerColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Momo Histogram Hi Color", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 8)]
		public Brush HistUpColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string HistUpColorSerialize
		{
			get { return Serialize.BrushToString(HistUpColor); }
			set { HistUpColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Momo Histogram Down Color", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 9)]
		public Brush HistDownColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string HistDownColorSerialize
		{
			get { return Serialize.BrushToString(HistDownColor); }
			set { HistDownColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Zeroline", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 10)]
		public Brush ZeroLineColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ZeroLineColorSerialize
		{
			get { return Serialize.BrushToString(ZeroLineColor); }
			set { ZeroLineColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Connector", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 11)]
		public Brush ConnectorColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ConnectorColorSerialize
		{
			get { return Serialize.BrushToString(ConnectorColor); }
			set { ConnectorColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Channel shading", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 12)]
		public Brush ChannelColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ChannelColorSerialize
		{
			get { return Serialize.BrushToString(ChannelColor); }
			set { ChannelColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Deep Bearish background flooding", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 13)]
		public Brush DeepBearishBackgroundColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DeepBearishBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(DeepBearishBackgroundColor); }
			set { DeepBearishBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bearish background flooding", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 14)]
		public Brush BearishBackgroundColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string BearishBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(BearishBackgroundColor); }
			set { BearishBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Opposite background flooding", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 15)]
		public Brush OppositeBackgroundColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string OppositeBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(OppositeBackgroundColor); }
			set { OppositeBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Bullish background flooding", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 16)]
		public Brush BullishBackgroundColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string BullishBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(BullishBackgroundColor); }
			set { BullishBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Deep Bullish background flooding", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 17)]
		public Brush DeepBullishBackgroundColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string DeepBullishBackgroundColorSerialize
		{
			get { return Serialize.BrushToString(DeepBullishBackgroundColor); }
			set { DeepBullishBackgroundColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Excursion Level 1 Color", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 18)]
		public Brush ExcursionLevel1Color { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ExcursionLevel1ColorSerialize
		{
			get { return Serialize.BrushToString(ExcursionLevel1Color); }
			set { ExcursionLevel1Color = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Excursion Level 2 Color", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 19)]
		public Brush ExcursionLevel2Color { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ExcursionLevel2ColorSerialize
		{
			get { return Serialize.BrushToString(ExcursionLevel2Color); }
			set { ExcursionLevel2Color = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Excursion Level 3 Color", GroupName = VMLeanPlotsGroupName, Description = "Select Color", Order = 20)]
		public Brush ExcursionLevel3Color { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ExcursionLevel3ColorSerialize
		{
			get { return Serialize.BrushToString(ExcursionLevel3Color); }
			set { ExcursionLevel3Color = Serialize.StringToBrush(value); }
		}
		#endregion

		#region Visuals
		protected const string VisualsGroupName = "Misc. Visuals";

		[XmlIgnore]
		[Display(Name = "Long Stripe Signal Color", Order = 1, GroupName = VisualsGroupName)]
		public Brush LongStripColor { get; set; }

		[Range(0, int.MaxValue)]
		[Display(Name = "Long Strip Opacity", Order = 2, GroupName = VisualsGroupName)]
		public int LongStripOpacity { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string LongStripColorSerializable
		{
			get { return Serialize.BrushToString(LongStripColor); }
			set { LongStripColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Short Stripe Signal Color", Order = 3, GroupName = VisualsGroupName)]
		public Brush ShortStripColor { get; set; }

		[Range(0, int.MaxValue)]
		[Display(Name = "Short Strip Opacity", Order = 4, GroupName = VisualsGroupName)]
		public int ShortStripOpacity { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ShortStripColorSerializable
		{
			get { return Serialize.BrushToString(ShortStripColor); }
			set { ShortStripColor = Serialize.StringToBrush(value); }
		}

		[Display(Name = "Button Text", Order = 101, GroupName = VisualsGroupName)]
		public string ButtonText { get; set; }

		[XmlIgnore]
		[Display(Name = "Stop Dot Color", Order = 102, GroupName = VisualsGroupName)]
		public Brush StopDotColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string StopDotColorSerializable
		{
			get { return Serialize.BrushToString(StopDotColor); }
			set { StopDotColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Target Dot Color", Order = 103, GroupName = VisualsGroupName)]
		public Brush TargetDotColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string TargetDotColorSerializable
		{
			get { return Serialize.BrushToString(TargetDotColor); }
			set { TargetDotColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Chart PnL Text Color", Order = 104, GroupName = VisualsGroupName)]
		public Brush ChartPnLTextColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string ChartPnLTextColorSerializable
		{
			get { return Serialize.BrushToString(ChartPnLTextColor); }
			set { ChartPnLTextColor = Serialize.StringToBrush(value); }
		}

		[Display(Name = "Dash Historical PNL", Order = 105, GroupName = VisualsGroupName)]
		public bool DashHistoricPnl { get; set; }

		[XmlIgnore]
		[Display(Name = "Missed Order Color (Unfilled)", Order = 106, GroupName = VisualsGroupName)]
		public Brush UnfilledOrderColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string UnfilledOrderColorSerializable
		{
			get { return Serialize.BrushToString(UnfilledOrderColor); }
			set { UnfilledOrderColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Missed Order Color (Gap Bar)", Order = 107, GroupName = VisualsGroupName)]
		public Brush GapBarOrderColor { get; set; }

		[Browsable(false)]
		[SuppressMessage("ReSharper", "UnusedMember.Global")]
		public string GapBarOrderColorSerializable
		{
			get { return Serialize.BrushToString(GapBarOrderColor); }
			set { GapBarOrderColor = Serialize.StringToBrush(value); }
		}
		#endregion
		#endregion
	}
}
