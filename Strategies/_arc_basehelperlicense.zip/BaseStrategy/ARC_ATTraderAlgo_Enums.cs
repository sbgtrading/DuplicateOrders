using System;

public enum ARC_ATTraderAlgo_RunType { BackTest, RealTime, Combined }

public enum ARC_ATTraderAlgo_HighWaterMarkType { Off, Realized, RealizedPlusUnrealized }

public enum ARC_ATTraderAlgo_TargetType { Ticks, RR, ATR }

public enum ARC_ATTraderAlgo_BidAsk { Bid, Ask }

[Flags]
public enum ARC_ATTraderAlgo_BidAskFlags { Bid = 1, Ask = 2 }

public enum ARC_ATTraderAlgo_StopLossType { Ticks, ATR }

public enum ARC_ATTraderAlgo_AtrOrTicks { Ticks, ATR }

public enum ARC_ATTraderAlgo_SizingStrategy { Static, FixedCost, PercentOfBalance }

public enum ARC_ATTraderAlgo_EntryOrderType { Market, Limit }

public enum ARC_ATTraderAlgo_AllowedEntryDirection { LongAndShort, LongOnly, ShortOnly, None }

public enum ARC_ATTraderAlgo_OppositeSignalAction { None, ExitOnly, Reverse }

public enum ARC_ATTraderAlgo_BarCloseOrIntrabar { BarClose, Intrabar }

public enum ARC_ATTraderAlgo_TickOrPercentPatternHLRange { Ticks, PercentOfPatternHLRange }

public enum ARC_ATTraderAlgo_ImbalanceCalculationMode { Diagonally, Horizontally }

public enum ARC_ATTraderAlgo_BidAskVolumeCalculationMode { UpTickDownTick, TrueBidAsk }

public enum ARC_ATTraderAlgo_BoolEnum { True, False }

public enum ARC_ATTraderAlgo_MovingAverageType { EMA, SMA, StepMA }

public enum ARC_ATTraderAlgo_StepMaTrendType { Level, Trend }

public enum ARC_ATTraderAlgo_DayWeekMonth { Day, Week, Month }

public enum ARC_ATTraderAlgo_SingleBarPattern
{
	Inside = 1, 
	Directional = 2,
	Outside = 3
}

[Flags]
public enum ARC_ATTraderAlgo_ARCFilterType
{
	TaFilters = 1,
	MoneyManagement = 2,
	Time = 4,
	Direction = 8,
	ConsecutiveTrades = 16,
	ArmState = 32,
	SameBar = 64,
	AllExceptArmState = TaFilters | MoneyManagement | Time | Direction | ConsecutiveTrades | SameBar,
	All = AllExceptArmState | ArmState
}