using System;

public enum ARC_HFTAlgo_RunType { BackTest, RealTime, Combined }

public enum ARC_HFTAlgo_HighWaterMarkType { Off, Realized, RealizedPlusUnrealized }

public enum ARC_HFTAlgo_TargetType { Ticks, RR, ATR }

public enum ARC_HFTAlgo_BidAsk { Bid, Ask }

[Flags]
public enum ARC_HFTAlgo_BidAskFlags { Bid = 1, Ask = 2 }

public enum ARC_HFTAlgo_StopLossType { Ticks, ATR }

public enum ARC_HFTAlgo_EntryOrderType { Market, Limit }

public enum ARC_HFTAlgo_AllowedEntryDirection { LongAndShort, LongOnly, ShortOnly, None }

public enum ARC_HFTAlgo_OppositeSignalAction { None, ExitOnly, Reverse }

public enum ARC_HFTAlgo_ImbalanceCalculationMode { Diagonally, Horizontally }

public enum ARC_HFTAlgo_BidAskVolumeCalculationMode { UpTickDownTick, TrueBidAsk }

public enum ARC_HFTAlgo_BoolEnum { True, False }

public enum ARC_HFTAlgo_MovingAverageType { EMA, SMA, StepMA }

public enum ARC_HFTAlgo_StepMaTrendType { Level, Trend }

public enum ARC_HFTAlgo_DayWeekMonth { Day, Week, Month }

[Flags]
public enum ARC_HFTAlgo_ARCFilterType
{
	TaFilters = 1,
	MoneyManagement = 2,
	Time = 4,
	Direction = 8,
	ConsecutiveTrades = 16,
	ArmState = 32,
	AllExceptArmState = TaFilters | MoneyManagement | Time | Direction | ConsecutiveTrades,
	All = AllExceptArmState | ArmState
}