using System;

public enum ARC_ATRVolTraderAlgo_RunType { BackTest, RealTime, Combined }

public enum ARC_ATRVolTraderAlgo_HighWaterMarkType { Off, Realized, RealizedPlusUnrealized }

public enum ARC_ATRVolTraderAlgo_TargetType { Ticks, RR, ATR }

public enum ARC_ATRVolTraderAlgo_BidAsk { Bid, Ask }

[Flags]
public enum ARC_ATRVolTraderAlgo_BidAskFlags { Bid = 1, Ask = 2 }

public enum ARC_ATRVolTraderAlgo_StopLossType { Ticks, ATR }

public enum ARC_ATRVolTraderAlgo_EntryOrderType { Market, Limit }

public enum ARC_ATRVolTraderAlgo_AllowedEntryDirection { LongAndShort, LongOnly, ShortOnly, None }

public enum ARC_ATRVolTraderAlgo_OppositeSignalAction { None, ExitOnly, Reverse }

public enum ARC_ATRVolTraderAlgo_ImbalanceCalculationMode { Diagonally, Horizontally }

public enum ARC_ATRVolTraderAlgo_BidAskVolumeCalculationMode { UpTickDownTick, TrueBidAsk }

public enum ARC_ATRVolTraderAlgo_BoolEnum { True, False }

public enum ARC_ATRVolTraderAlgo_MovingAverageType { EMA, SMA, StepMA }

public enum ARC_ATRVolTraderAlgo_StepMaTrendType { Level, Trend }

public enum ARC_ATRVolTraderAlgo_DayWeekMonth { Day, Week, Month }

[Flags]
public enum ARC_ATRVolTraderAlgo_ARCFilterType
{
	TaFilters = 1,
	MoneyManagement = 2,
	Time = 4,
	Direction = 8,
	ConsecutiveTrades = 16,
	ArmState = 32,
	AllExceptArmState = TaFilters | MoneyManagement | Time | Direction | ConsecutiveTrades,
	All = AllExceptArmState | ArmState
}