#define DoLicense    //Uncomment to add NT licensing code at compilation for production only
using NinjaTrader.Cbi;
using NinjaTrader.NinjaScript.DrawingTools;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Cache;
using System.Text;
using System.Windows.Media;
using NinjaTrader.Gui.NinjaScript;
using NinjaTrader.Gui.Tools;

namespace NinjaTrader.NinjaScript.Strategies
{
    internal class MoneyRainLicenseHandler<TScript> where TScript : NinjaScriptBase, MoneyRainILicensedNinjaScript
    {
        private const string LicenseTextTag = "lictext";
        public bool ValidLicense { get; private set; }
        private bool LicenseChecked { get; set; }
        public string UserId { get; private set; }

        private const string SupportEmailAddress = "moneyrain@gmail.com";
        private readonly TScript script;

        private readonly string isoStoreExpireDateFile;

        public MoneyRainLicenseHandler(TScript ns)
        {
            script = ns;
            isoStoreExpireDateFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), string.Format("_ED_{0}.txt", script.ModuleName));
        }

        private string XorCipher(string data, string key2)
        {
            if (data == null || key2 == null)
                return null;

            var dataLen = data.Length;
            var output = new char[dataLen];

            var chars = key2.ToCharArray();
            for (var i = 0; i < chars.Length; i++)
                if (chars[i] < '0' || chars[i] > '9')
                    chars[i] = '0';
            key2 = new string(chars);
            for (var i = 0; i < chars.Length; i++)
                chars[i] = (char)('a' + 2 * (chars[i] - '0'));
            var key1 = string.Empty;
            for (var i = chars.Length - 1; i >= 0; i--)
                key1 = string.Format("{0}{1}", key1, chars[i]);

            if (key1 != key2)
            {
                var keyLen = key1.Length;
                for (var i = 0; i < dataLen; ++i)
                    output[i] = (char)(data[i] ^ key1[i % keyLen]);
                keyLen = key2.Length;
                for (var i = 0; i < dataLen; ++i)
                    output[i] = (char)(output[i] ^ key2[i % keyLen]);
                keyLen = key1.Length;
                for (var i = 0; i < dataLen; ++i)
                    output[i] = (char)(output[i] ^ key1[i % keyLen]);
            }
            else
            {
                var keyLen = key2.Length;
                for (var i = 0; i < dataLen; ++i)
                    output[i] = (char)(data[i] ^ key2[i % keyLen]);
            }

            return new string(output);
        }

        private char[] FromHexToByteArray(string input)
        {
            input = input.Trim();
            if (input.Length == 0)
                return null;

            var result = new char[input.Length / 2];
            try
            {
                var i = 0;
                var r = 0;
                while (i < input.Length)
                {
                    var s = input.Substring(i, 2);
                    uint u;
                    if (uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u))
                    {
                        result[r] = Convert.ToChar(u);
                    }
                    else
                    {
                        script.Print("FromHexToByteArray, could not covert hex:" + s + " to uint");
                        return null;
                    }
                    r++;
                    i += 2;
                }
            }
            catch (Exception e)
            {
                script.Print("FromHexToByteArray, conversion terminated:" + e);
                return null;
            }
            return result;
        }

        private string FromCharArrayToHexString(char[] input)
        {
            if (input.Length == 0)
            {
                script.Print("FromCharArrayToHexString, input string zero length");
                return null;
            }

            var result = new StringBuilder();
            try
            {
                var i = 0;
                while (i < input.Length)
                {
                    var inval = (int)input[i];
                    var hex = string.Format("{00:x}", inval);
                    if (hex.Length == 1)
                        result.Append("0");
                    result.Append(hex);
                    i += 1;
                }
            }
            catch (Exception e)
            {
                script.Print("FromCharArrayToHexString, conversion terminated:" + e);
                return null;
            }
            var str = result.ToString();
            return str;
        }

        private void MoveAllFilesFromNSto()
        {
            if (Directory.Exists(ConfigDirectory))
                return;

            var d = Directory.CreateDirectory(ConfigDirectory);
            if (!d.Exists)
            {
                NinjaScript.Log("Error - Could not create _config directory - licensing will fail", LogLevel.Information);
                return;
            }

            if (!Directory.Exists(nsConfigDirectory))
                return;

            var dirCustom = new DirectoryInfo(nsConfigDirectory);
            var filCustom = dirCustom.GetFiles("*.*");
            foreach (var fi in filCustom)
            {
                var newFname = Path.Combine(ConfigDirectory, fi.FullName).Replace("NS", "");
                File.Copy(fi.FullName, newFname);
            }
        }

        private void OverwriteIsoFile(string writeThisText, ref string errorMessage)
        {
            try
            {
                File.WriteAllText(isoStoreExpireDateFile, writeThisText);
            }
            catch (Exception err)
            {
                errorMessage = err.ToString();
                script.Print("Error " + errorMessage);
            }
        }

        private string GetLineFromIsoStorage(string inText, bool saveInText, ref string errorMessage)
        {
            /*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

            var result = "";
            if (File.Exists(isoStoreExpireDateFile))
            {
                //Read one line from isostorage - eliminates the dependence on an unstable config.xml file
                try
                {
                    var lines = File.ReadAllLines(isoStoreExpireDateFile);
                    foreach (var l in lines)
                    {
                        if (l.Trim().StartsWith(@"//") || l.Trim().Length == 0)
                            continue;

                        result = l.Trim();
                    }
                }
                catch (Exception err)
                {
                    errorMessage = Path.GetFileName(isoStoreExpireDateFile) + " IsoFile read error: " + err;
                    script.Print(errorMessage);
                }
            }

            if (result.CompareTo(inText) == 0 || !saveInText || inText.Trim().Length <= 0)
                return result;

            //Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
            OverwriteIsoFile(inText, ref errorMessage);
            return inText;
        }

        private int GetCustId(bool pingRegistry)
        {
            #region -- Get customer id from AI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
            var retCustId = -1;
            var folder = ConfigDirectory;
            if (!Directory.Exists(folder)) 
                Directory.CreateDirectory(folder);

            var seh = "cid_*.txt";
            var filCustom = new DirectoryInfo(folder).GetFiles(seh);
            foreach (var fi in filCustom)
            {
                var elements = fi.Name.Split(new[] { '_', '.' }, StringSplitOptions.RemoveEmptyEntries);
                if (elements.Length > 1)
                    retCustId = int.Parse(elements[1]);
            }

            if (retCustId == -1)
            {
                folder = nsConfigDirectory;
                seh = "nscid_*.txt";
                filCustom = new DirectoryInfo(folder).GetFiles(seh);
                foreach (var fi in filCustom)
                {
                    var elements = fi.Name.Split(new[] { '_', '.' }, StringSplitOptions.RemoveEmptyEntries);
                    if (elements.Length > 1)
                        retCustId = int.Parse(elements[1]);
                }
            }

            if (retCustId == -1 && pingRegistry)
            {
                //the config file doesn't exist, create one based on what is recovered from the registry
                try
                {
                    retCustId = reg.Read("custid");
                }
                catch (Exception ex2)
                {
                    if (!MoneyRainLicErrorMessageHandler.IsDuplicate(ex2.ToString())) 
                        NinjaScript.Log("Please run your '_LicenseActivator v1' and supply your AI Contact ID number", LogLevel.Alert);
                    return -1;
                }
            }

            if (retCustId > 0)
            {
                var fName = Path.Combine(ConfigDirectory, "cid_" + retCustId.ToString().Trim() + ".txt");
                if (!File.Exists(fName))
                    File.WriteAllText(fName, retCustId.ToString());
            }
            return retCustId;
            #endregion
        }

        private bool License(string supportEmailAddress, int firstPort, int lastPort)
        {
            // If this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
            if (MoneyRainLicErrorMessageHandler.IsExpired(script.ModuleName))
            {
                // Read ns config folder for NeuroStreetContactID
                try
                {
                    var folder = ConfigDirectory;
                    var seh = "cid_*.txt";
                    var filCustom = new DirectoryInfo(folder).GetFiles(seh);
                    foreach (var fi in filCustom)
                    {
                        var elements = fi.Name.Split(new[] { '_', '.' }, StringSplitOptions.RemoveEmptyEntries);
                        if (elements.Length > 1)
                            NewCustomerId = int.Parse(elements[1]);
                    }
                }
                catch
                {
                    NewCustomerId = reg.Read("custid");
                }

                UserId = NewCustomerId.ToString();
                return false;
            }

            MoveAllFilesFromNSto();
            var errorMessage = string.Empty;
            var nl = Environment.NewLine;

            var validateViaApi = true;
            string expiryDateEncrypted;
            if (File.Exists(isoStoreExpireDateFile))
            {
                //This determines if we need to ping the server again.  Fewer API pings increase speed of verification
                //If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
                //Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
                expiryDateEncrypted = GetLineFromIsoStorage("", true, ref errorMessage);
                if (expiryDateEncrypted.Trim().Length > 0)
                {
                    var expireDateDecrypted = XorCipher(new string(FromHexToByteArray(expiryDateEncrypted)), ExpirationDateKey);
                    if (expireDateDecrypted.Contains(License.MachineId))
                    {
                        //the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
                        var dateStr = expireDateDecrypted.Remove(0, expireDateDecrypted.IndexOf(':') + 1);
                        long expireLongInt;
                        long.TryParse(dateStr, out expireLongInt);
                        validateViaApi = DateTime.Now.Ticks >= expireLongInt;
                    }
                }
            }

            bool validLicense;
            if (!validateViaApi)
            {
                validLicense = true;
                UserId = "-9999";
            }
            else
            {
                NewCustomerId = GetCustId(true);
                UserId = NewCustomerId.ToString();

                // Check if moderator, if moderator exempt from licensing
                if (moderatorIds.Contains(UserId))
                    return true;

                var keyString = Math.Abs(DateTime.Now.Ticks / (DateTime.Now.Second + 10)).ToString("0");
                bool websiteFound;
                keyString = keyString.Replace("0", string.Empty).Trim();
                if (keyString.Length > 32)
                    keyString = keyString.Substring(0, 32);

                // Check the license
                var responseHexStr = "";
                var msgCb = "";
                var url = firstPort < 8080 || lastPort < 8080
                    ? "https://hitectsai.com/ns_scripts/IS/NS_LicenseCheck.php"
                    : string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", firstPort, License.MachineId, script.ModuleName, keyString, UserId);
                try
                {
                    var parameters = new NameValueCollection
                    {
                        { "nscustid", NewCustomerId.ToString() },
                        { "custnum", License.MachineId },
                        { "platform", "ninjatrader" },
                        { "version", script.ModuleName + " " + script.ProductVersion },
                        { "datetime", DateTime.Now.ToString() },
                        { "random", script.Name }
                    };

                    // Create WebClient and post request
                    var ntWebClient = new WebClient();
                    ntWebClient.CachePolicy = new HttpRequestCachePolicy(HttpRequestCacheLevel.NoCacheNoStore);
                    ntWebClient.Headers.Add(HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
                    ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;

                    try
                    {
                        var responseArray = ntWebClient.UploadValues(url, "POST", parameters);
                        responseHexStr = Encoding.ASCII.GetString(responseArray);
                        msgCb = "";
                        websiteFound = true;
                    }
                    catch (Exception er)
                    {
                        msgCb = er.ToString();
                        websiteFound = false;
                    }
                }
                catch (Exception err)
                {
                    websiteFound = false;
                    msgCb = string.Concat(msgCb, "===================", Environment.NewLine, err.Message);
                }

                if (!websiteFound)
                {
                    msgCb = string.Format("No response from  License Server {0}{0}{1}", nl, msgCb);
                    msgCb += string.Format(".Send this msg to {1}{0}{2}", nl, supportEmailAddress, msgCb);
                    if (!MoneyRainLicErrorMessageHandler.IsDuplicate(msgCb))
                        LogMsg(msgCb, LogLevel.Alert);
                    return false;
                }

                var plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
                var isTagsList = plainText.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).ToList();
                validLicense = isTagsList.Intersect(script.ExpectedInfusionSoftTagSet).Any();

                if (!validLicense)
                {
                    msgCb = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", nl, supportEmailAddress, UserId, script.ModuleName, License.MachineId);
                    if (!MoneyRainLicErrorMessageHandler.IsDuplicate(msgCb))
                        LogMsg(msgCb, LogLevel.Alert);
                    MoneyRainLicErrorMessageHandler.SetModuleExpired(script.ModuleName);
                    OverwriteIsoFile("", ref errorMessage);
                }
                else
                {
                    var expireDateString = string.Format("{0} License good until: {1}", License.MachineId, DateTime.Now.AddHours(HoursBetweenPings).Ticks.ToString());
                    expiryDateEncrypted = FromCharArrayToHexString(XorCipher(expireDateString, ExpirationDateKey).ToCharArray());
                    OverwriteIsoFile(expiryDateEncrypted, ref errorMessage);
                }
            }
            return validLicense;
        }

        private void LogMsg(string msg, LogLevel alert)
        {
            var folder = Path.Combine(Core.Globals.UserDataDir, "bin", "Custom");
            const string seh = "SharkIndicators*.*";

            FileInfo[] filCustom = null;
            try
            {
                var dirCustom = new DirectoryInfo(folder);
                filCustom = dirCustom.GetFiles(seh);
            }
            catch (Exception e)
            {
                NinjaScript.Log(e.ToString(), alert);
            }

            NinjaScript.Log(msg, filCustom == null || filCustom.Length == 0 ? alert : LogLevel.Warning);
        }

        public void RecheckLicense(bool forceRecheck = false)
        {
            if (LicenseChecked && !forceRecheck)
            {
                Console.WriteLine("RecheckLicense: LicenseChecked = true && !forceRecheck");
                return;
            }

            #if DoLicense
            ValidLicense = License(SupportEmailAddress, 7070, 7071);
            #else
            ValidLicense = true;
            #endif
            LicenseChecked = true;
            Console.WriteLine("RecheckLicense: LicenseChecked = true, ValidLicense: " + ValidLicense);
        }

        public void EnactLicensing(MoneyRainLicensingContextStep step)
        {
            #if !DoLicense
            return;
            #endif

            var strategy = script as StrategyRenderBase;
            var indicator = script as IndicatorRenderBase;

            switch (step)
            {
            case MoneyRainLicensingContextStep.Configure:
                if (strategy != null && strategy.Account.Name == "Backtest")
                    return;

                if (indicator != null || strategy != null)
                    Draw.TextFixed(script, LicenseTextTag, "Getting " + script.ModuleName + " license info", TextPosition.Center);

                RecheckLicense();
                script.IsVisible = true;

                if (strategy != null)
                    strategy.RemoveDrawObject(LicenseTextTag);
                else if (indicator != null)
                    indicator.RemoveDrawObject(LicenseTextTag);

                break;
            case MoneyRainLicensingContextStep.BarUpdate:
                if (ValidLicense)
                    break;

                if (strategy != null || indicator != null)
                {
                    var msg = NewCustomerId < 0
                        ? "Your  Contact Id is not present\n" + License.MachineId + "\n\nPlease run your _LicenseActivator v1 indicator\n\nContact " + SupportEmailAddress + " for assistance"
                        : script.ModuleName + " license not valid\n" + License.MachineId + "  " + UserId + "\nHas your NT machine id changed?  Log into your Member Site to update your NT machine id\nContact " + SupportEmailAddress + " for assistance";
                    Draw.TextFixed(script, LicenseTextTag, msg, TextPosition.Center, Brushes.White, new SimpleFont("Arial", 12), Brushes.Black, Brushes.Black, 90);
                }

                script.IsVisible = false;
                break;
            }
        }
    }

    public interface MoneyRainILicensedNinjaScript
    {
        string ProductVersion { get; }
        string ModuleName { get; }
        List<string> ExpectedInfusionSoftTagSet { get; }
    }

    public enum MoneyRainLicensingContextStep
    {
        Configure,
        BarUpdate
    }
}