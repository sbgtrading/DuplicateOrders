using System;

public enum ARC_VolDivAlgo_RunType { BackTest, RealTime, Combined }

public enum ARC_VolDivAlgo_HighWaterMarkType { Off, Realized, RealizedPlusUnrealized }

public enum ARC_VolDivAlgo_TargetType { Ticks, RR, ATR }

public enum ARC_VolDivAlgo_BidAsk { Bid, Ask }

[Flags]
public enum ARC_VolDivAlgo_BidAskFlags { Bid = 1, Ask = 2 }

public enum ARC_VolDivAlgo_StopLossType { Ticks, ATR }

public enum ARC_VolDivAlgo_EntryOrderType { Market, Limit }

public enum ARC_VolDivAlgo_AllowedEntryDirection { LongAndShort, LongOnly, ShortOnly, None }

public enum ARC_VolDivAlgo_OppositeSignalAction { None, ExitOnly, Reverse }

public enum ARC_VolDivAlgo_ImbalanceCalculationMode { Diagonally, Horizontally }

public enum ARC_VolDivAlgo_BidAskVolumeCalculationMode { UpTickDownTick, TrueBidAsk }

public enum ARC_VolDivAlgo_BoolEnum { True, False }

public enum ARC_VolDivAlgo_MovingAverageType { EMA, SMA, StepMA }

public enum ARC_VolDivAlgo_StepMaTrendType { Level, Trend }

public enum ARC_VolDivAlgo_DayWeekMonth { Day, Week, Month }