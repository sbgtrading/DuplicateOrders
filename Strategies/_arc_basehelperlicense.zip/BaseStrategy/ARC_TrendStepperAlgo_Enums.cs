using System;

public enum ARC_TrendStepperAlgo_RunType
{
	BackTest,
	RealTime,
	Combined
}

public enum ARC_TrendStepperAlgo_NsOrderType
{
	Market,
	LimitFixed,
	StopFixed,
	StopLimit
}

public enum ARC_TrendStepperAlgo_HighWaterMarkType
{
	Off,
	Realized,
	RealizedPlusUnrealized
}

public enum ARC_TrendStepperAlgo_TargetType
{
	Ticks,
	RR,
	ATR
}

public enum ARC_TrendStepperAlgo_BidAsk { Bid, Ask }

[Flags]
public enum ARC_TrendStepperAlgo_BidAskFlags { Bid = 1, Ask = 2 }

public enum ARC_TrendStepperAlgo_StopLossType
{
	Ticks,
	ATR
}

public enum ARC_TrendStepperAlgo_EntryOrderType
{
	Market,
	Limit
}

public enum ARC_TrendStepperAlgo_AllowedEntryDirection
{
	LongAndShort,
	LongOnly,
	ShortOnly,
	None
}

public enum ARC_TrendStepperAlgo_OppositeSignalAction
{
	None,
	ExitOnly,
	Reverse
}

public enum ARC_TrendStepperAlgo_ImbalanceCalculationMode
{
	Diagonally,
	Horizontally
}

public enum ARC_TrendStepperAlgo_BidAskVolumeCalculationMode
{
	UpTickDownTick,
	TrueBidAsk
}

public enum ARC_TrendStepperAlgo_ImbalanceCalculationMethod
{
	AnalyticaChart3,
	Ratio
}

public enum ARC_TrendStepperAlgo_BoolEnum
{
	True,
	False
}

public enum ARC_TrendStepperAlgo_MovingAverageType { EMA, SMA, StepMA }

public enum ARC_TrendStepperAlgo_StepMaTrendType { Level, Trend }

public enum ARC_TrendStepperAlgo_DayWeekMonth { Day, Week, Month }
