using System;

public enum ARC_VWapperAlgo_RunType
{
	BackTest,
	RealTime,
	Combined
}

public enum ARC_VWapperAlgo_NsOrderType
{
	Market,
	LimitFixed,
	StopFixed,
	StopLimit
}

public enum ARC_VWapperAlgo_HighWaterMarkType
{
	Off,
	Realized,
	RealizedPlusUnrealized
}

public enum ARC_VWapperAlgo_TargetType
{
	Ticks,
	RR,
	ATR
}

public enum ARC_VWapperAlgo_BidAsk { Bid, Ask }

[Flags]
public enum ARC_VWapperAlgo_BidAskFlags { Bid = 1, Ask = 2 }

public enum ARC_VWapperAlgo_StopLossType
{
	Ticks,
	ATR
}

public enum ARC_VWapperAlgo_EntryOrderType
{
	Market,
	Limit
}

public enum ARC_VWapperAlgo_AllowedEntryDirection
{
	LongAndShort,
	LongOnly,
	ShortOnly,
	None
}

public enum ARC_VWapperAlgo_OppositeSignalAction
{
	None,
	ExitOnly,
	Reverse
}

public enum ARC_VWapperAlgo_ImbalanceCalculationMode
{
	Diagonally,
	Horizontally
}

public enum ARC_VWapperAlgo_BidAskVolumeCalculationMode
{
	UpTickDownTick,
	TrueBidAsk
}

public enum ARC_VWapperAlgo_ImbalanceCalculationMethod
{
	AnalyticaChart3,
	Ratio
}

public enum ARC_VWapperAlgo_BoolEnum
{
	True,
	False
}

public enum ARC_VWapperAlgo_MovingAverageType { EMA, SMA, StepMA }

public enum ARC_VWapperAlgo_StepMaTrendType { Level, Trend }

public enum ARC_VWapperAlgo_DayWeekMonth { Day, Week, Month }