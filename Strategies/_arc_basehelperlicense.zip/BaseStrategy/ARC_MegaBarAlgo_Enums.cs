using System;

public enum ARC_MegaBarAlgo_RunType { BackTest, RealTime, Combined }

public enum ARC_MegaBarAlgo_HighWaterMarkType { Off, Realized, RealizedPlusUnrealized }

public enum ARC_MegaBarAlgo_TargetType { Ticks, RR, ATR }

public enum ARC_MegaBarAlgo_BidAsk { Bid, Ask }

[Flags]
public enum ARC_MegaBarAlgo_BidAskFlags { Bid = 1, Ask = 2 }

public enum ARC_MegaBarAlgo_StopLossType { Ticks, ATR }

public enum ARC_MegaBarAlgo_AtrOrTicks { Ticks, ATR }

public enum ARC_MegaBarAlgo_SizingStrategy { Static, FixedCost, PercentOfBalance }

public enum ARC_MegaBarAlgo_EntryOrderType { Market, Limit }

public enum ARC_MegaBarAlgo_AllowedEntryDirection { LongAndShort, LongOnly, ShortOnly, None }

public enum ARC_MegaBarAlgo_OppositeSignalAction { None, ExitOnly, Reverse }

public enum ARC_MegaBarAlgo_BarCloseOrIntrabar { BarClose, Intrabar }

public enum ARC_MegaBarAlgo_TickOrPercentPatternHLRange { Ticks, PercentOfPatternHLRange }

public enum ARC_MegaBarAlgo_ImbalanceCalculationMode { Diagonally, Horizontally }

public enum ARC_MegaBarAlgo_BidAskVolumeCalculationMode { UpTickDownTick, TrueBidAsk }

public enum ARC_MegaBarAlgo_BoolEnum { True, False }

public enum ARC_MegaBarAlgo_MovingAverageType { EMA, SMA, StepMA }

public enum ARC_MegaBarAlgo_StepMaTrendType { Level, Trend }

public enum ARC_MegaBarAlgo_DayWeekMonth { Day, Week, Month }

public enum ARC_MegaBarAlgo_SingleBarPattern
{
	Inside = 1, 
	Directional = 2,
	Outside = 3
}

[Flags]
public enum ARC_MegaBarAlgo_ARCFilterType
{
	TaFilters = 1,
	MoneyManagement = 2,
	Time = 4,
	Direction = 8,
	ConsecutiveTrades = 16,
	ArmState = 32,
	SameBar = 64,
	AllExceptArmState = TaFilters | MoneyManagement | Time | Direction | ConsecutiveTrades | SameBar,
	All = AllExceptArmState | ArmState
}