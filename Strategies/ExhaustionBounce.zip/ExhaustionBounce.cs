#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class ExhaustionBounce : Strategy
	{
		AmbushSignals ams1;
		AmbushSignals ams2;
		AmbushSignals ams3;
		SortedDictionary<DayOfWeek,List<double>> DOWRanges = new SortedDictionary<DayOfWeek,List<double>>();
		int JulianStartTime = 0;
		int JulianStopTime = 0;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "Exhaustion Bounce";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				pExhaustionMult1		= 0.1;
				pExhaustionMult2		= 0.1;
				pExhaustionMult3		= 0.1;
				pTargetMultiple = 0.5;
				pTimeframe1 = 1;
				pTimeframe2 = 2;
				pTimeframe3 = 3;
				pDaysOfWeek = "12345";
				pExcludeTimes = "//930-1000, 1400-1550";
				pEnableBEStop = false;
				pStartTime = 930;
				pStopTime = 1550;
				pGoFlatTime = 1550;
				AddPlot(new Stroke(Brushes.Lime, 3),    PlotStyle.Dot, "BuyLvl1");
				AddPlot(new Stroke(Brushes.Magenta, 3), PlotStyle.Dot, "SellLvl1");
				AddPlot(new Stroke(Brushes.Green, 3),   PlotStyle.Dot, "BuyLvl2");
				AddPlot(new Stroke(Brushes.Red, 3),     PlotStyle.Dot, "SellLvl2");
				AddPlot(new Stroke(Brushes.Cyan, 3),    PlotStyle.Dot, "BuyLvl3");
				AddPlot(new Stroke(Brushes.Pink, 3),    PlotStyle.Dot, "SellLvl3");
			}
			else if (State == State.Configure)
			{
				ClearOutputWindow();
				int hr = pStartTime/100;
				int min = pStartTime - hr*100;
				JulianStartTime = hr*60+min;
				hr = pStopTime/100;
				min = pStopTime - hr*100;
				JulianStopTime = hr*60+min;
				
				if(pExhaustionMult1>0)
					ams1 = AmbushSignals(pExhaustionMult1, pTimeframe1);
				if(pExhaustionMult2>0)
					ams2 = AmbushSignals(pExhaustionMult2, pTimeframe2);
				if(pExhaustionMult3>0)
					ams3 = AmbushSignals(pExhaustionMult3, pTimeframe3);
				var s = pDaysOfWeek.ToUpper().Trim();
				if(s.Contains("0") || s=="ALL") DOW.Add(DayOfWeek.Sunday);
				if(s.Contains("1") || s=="ALL" || s=="WEEKDAY") DOW.Add(DayOfWeek.Monday);
				if(s.Contains("2") || s=="ALL" || s=="WEEKDAY") DOW.Add(DayOfWeek.Tuesday);
				if(s.Contains("3") || s=="ALL" || s=="WEEKDAY") DOW.Add(DayOfWeek.Wednesday);
				if(s.Contains("4") || s=="ALL" || s=="WEEKDAY") DOW.Add(DayOfWeek.Thursday);
				if(s.Contains("5") || s=="ALL" || s=="WEEKDAY") DOW.Add(DayOfWeek.Friday);
				if(s.Contains("6") || s=="ALL") DOW.Add(DayOfWeek.Saturday);

				ExcludedTimesList.Add(Tuple.Create(pStopTime*100, pStartTime*100));
				string ex = pExcludeTimes;
				if(ex.Contains("//")) ex = ex.Substring(0, ex.IndexOf("//"));
				while(ex.Contains(" -")) ex = ex.Replace(" -","-");
				while(ex.Contains("- ")) ex = ex.Replace("- ","-");
				var range = ex.Split(new char[]{' ',','},StringSplitOptions.RemoveEmptyEntries);// = "930-1000, 1400-1550";
				foreach(var tt in range){
					var startstop = tt.Split(new char[]{'-'});
					var start = Convert.ToInt32(startstop[0]);
					var stop = Convert.ToInt32(startstop[1]);
					ExcludedTimesList.Add(Tuple.Create(start*100,stop*100));
				}
			}else if(State == State.DataLoaded){
				double H = double.MinValue;
				double L = double.MaxValue;
				DateTime t=DateTime.MinValue;
				DateTime t1=DateTime.MinValue;
				for(int i = 1; i<BarsArray[0].Count; i++){
					if(H!=double.MinValue){
						t = Times[0].GetValueAt(i);
						t1 = Times[0].GetValueAt(i-1);
						if(!DOWRanges.ContainsKey(t1.DayOfWeek)) DOWRanges[t1.DayOfWeek] = new List<double>();
						if(t.Day != t1.Day){
							DOWRanges[t1.DayOfWeek].Add(H-L);
							H = Highs[0].GetValueAt(i);
							L = Lows[0].GetValueAt(i);
						}
					}
					H = Math.Max(Highs[0].GetValueAt(i), H);
					L = Math.Min(Lows[0].GetValueAt(i), L);
				}
			}
		}
		List<DayOfWeek> DOW = new List<DayOfWeek>();
		List<Tuple<int,int>> ExcludedTimesList = new List<Tuple<int,int>>();

		private bool IsExcluded(int t){
			foreach(var e in ExcludedTimesList){
				if(e.Item1 > e.Item2){
					//Print(t+" session:   "+e.Item1+" to "+e.Item2);
					if(t > e.Item1) return true;
					if(t < e.Item2) return true;
				}else if(t >= e.Item1 && t <= e.Item2) return true;
			}
			return false;
		}
		int TPTicks = 0;
		string CurrentSignalName = "";
		protected override void OnBarUpdate()
		{
			if(CurrentBar<21) return;
			DateTime t = Times[0][0];
			var c1 = !IsExcluded(ToTime(t));
			double PctOfDay = Math.Max(0.1, (t.Hour*60.0 + t.Minute - JulianStartTime)/(JulianStopTime - JulianStartTime));

			#region -- Timeframe 1 --
			if(ams1!=null){
				if(ams1.BuySignal.IsValidDataPoint(1))  BuyLvl1[0] = ams1.BuySignal[1];
				if(ams1.SellSignal.IsValidDataPoint(1)) SellLvl1[0] = ams1.SellSignal[1];
				if(ams1.BuySignal.IsValidDataPoint(1) && c1 &&
						Lows[0][0] <= ams1.BuySignal[1] && 
						Closes[0][0] > ams1.BuySignal[1] && 
						DOW.Contains(t.DayOfWeek) &&
						Position.MarketPosition != MarketPosition.Long){
					EnterLong("L1");
					var ticks = Convert.ToInt32((Closes[0][0] - Lows[0][0])/TickSize) + 1;
					if(pEnableBEStop)
						SetTrailStop(CalculationMode.Ticks, ticks);
					else
						SetStopLoss(CalculationMode.Ticks, ticks);
//					double sum = 0;	for(int i = 1; i<20; i++) sum += Range()[i];
//					SetProfitTarget(CalculationMode.Ticks, Convert.ToInt32((sum/20)*pTargetMultiple/TickSize));
//Print("Long avg: "+DOWRanges[t.DayOfWeek].Average()+"    Count: "+DOWRanges[t.DayOfWeek].Count);
					TPTicks = Convert.ToInt32(DOWRanges[t.DayOfWeek].Average() * (1-PctOfDay)*pTargetMultiple/TickSize);
					SetProfitTarget(CalculationMode.Ticks, TPTicks);
					Draw.Dot(this,"AmbushTP1"+CurrentBar.ToString(), true, 0, ams1.BuySignal[1] + TPTicks*TickSize, Brushes.Lime);
					Draw.Diamond(this,"AmbushSL1"+CurrentBar.ToString(), false, 0, Lows[0][0]-TickSize, Brushes.Magenta);
				}
				if(ams1.SellSignal.IsValidDataPoint(1) && c1 &&
						Highs[0][0] >= ams1.SellSignal[1] && 
						Closes[0][0] < ams1.SellSignal[1] && 
						DOW.Contains(Times[0][0].DayOfWeek) &&
						Position.MarketPosition != MarketPosition.Short){
					EnterShort("S1");
					var ticks = Convert.ToInt32((Highs[0][0]-Closes[0][0])/TickSize) + 1;
					if(pEnableBEStop)
						SetTrailStop(CalculationMode.Ticks, ticks);
					else
						SetStopLoss(CalculationMode.Ticks, ticks);
//					double sum = 0;	for(int i = 1; i<20; i++) sum += Range()[i];
//					SetProfitTarget(CalculationMode.Ticks, Convert.ToInt32((sum/20)*pTargetMultiple/TickSize));
//Print("Short avg: "+DOWRanges[t.DayOfWeek].Average()+"    Count: "+DOWRanges[t.DayOfWeek].Count);
					TPTicks = Convert.ToInt32(DOWRanges[t.DayOfWeek].Average() * (1-PctOfDay)*pTargetMultiple/TickSize);
					SetProfitTarget(CalculationMode.Ticks, TPTicks);
					Draw.Dot(this,"AmbushTP1"+CurrentBar.ToString(), true, 0, ams1.SellSignal[1] - TPTicks*TickSize, Brushes.Lime);
					Draw.Diamond(this,"AmbushSL1"+CurrentBar.ToString(), false, 0, Highs[0][0]+TickSize, Brushes.Magenta);
				}
				if(CurrentSignalName == "1" && pEnableBEStop){
					if(Position.MarketPosition == MarketPosition.Long){
//						double sum = 0;	for(int i = 1; i<20; i++) sum += Range()[i];
//						double trigger = Instrument.MasterInstrument.RoundToTickSize(sum/20*pTargetMultiple/3) + Position.AveragePrice;
						double trigger = Instrument.MasterInstrument.RoundToTickSize(TPTicks*TickSize/3) + Position.AveragePrice;
						if(Lows[0][0] > trigger){
							SetTrailStop(CalculationMode.Ticks, 5);
							Draw.Diamond(this,"AmbushSL1"+CurrentBar.ToString(), false,0, Position.AveragePrice + TickSize*5, Brushes.Magenta);
							//Print(Times[0][0]+"  Long has trailing stop engaged");
						}
					}
					if(Position.MarketPosition == MarketPosition.Short && CurrentSignalName == "1"){
//						double sum = 0;	for(int i = 1; i<20; i++) sum += Range()[i];
//						double trigger = Position.AveragePrice - Instrument.MasterInstrument.RoundToTickSize(sum/20*pTargetMultiple/3);
						double trigger = Position.AveragePrice - Instrument.MasterInstrument.RoundToTickSize(TPTicks*TickSize/3);
						if(Highs[0][0] < trigger){
							SetTrailStop(CalculationMode.Ticks, 5);
							Draw.Diamond(this,"AmbushSL1"+CurrentBar.ToString(), false,0, Position.AveragePrice - TickSize*5, Brushes.Magenta);
						//Print(Times[0][0]+"  Short has trailing stop engaged");
						}
					}
				}
			}
			#endregion -- Timeframe 1 End --
			#region -- Timeframe 2 --
			if(ams2 != null){
				if(ams2.BuySignal.IsValidDataPoint(1))  BuyLvl2[0] = ams2.BuySignal[1];
				if(ams2.SellSignal.IsValidDataPoint(1)) SellLvl2[0] = ams2.SellSignal[1];
				if(ams2.BuySignal.IsValidDataPoint(1) && c1 &&
						Lows[0][0] <= ams2.BuySignal[1] && 
						Closes[0][0] > ams2.BuySignal[1] && 
						DOW.Contains(t.DayOfWeek) &&
						Position.MarketPosition != MarketPosition.Long){
					EnterLong("L2");
					var ticks = (Closes[0][0] - Lows[0][0])/TickSize + 1;
					if(pEnableBEStop)
						SetTrailStop(CalculationMode.Ticks, ticks);
					else
						SetStopLoss(CalculationMode.Ticks, ticks);
//					double sum = 0;	for(int i = 1; i<20; i++) sum += Range()[i];
//					SetProfitTarget(CalculationMode.Ticks, Convert.ToInt32((sum/20)*pTargetMultiple/TickSize));
//Print("Long avg: "+DOWRanges[t.DayOfWeek].Average()+"    Count: "+DOWRanges[t.DayOfWeek].Count);
					TPTicks = Convert.ToInt32(DOWRanges[t.DayOfWeek].Average() * (1-PctOfDay)*pTargetMultiple/TickSize);
					SetProfitTarget(CalculationMode.Ticks, TPTicks);
					Draw.Dot(this,"AmbushTP2"+CurrentBar.ToString(), true, 0, ams2.BuySignal[1] + TPTicks*TickSize, Brushes.Lime);
					Draw.Diamond(this,"AmbushSL2"+CurrentBar.ToString(), false, 0, Lows[0][0]-TickSize, Brushes.Magenta);
				}
				if(ams2.SellSignal.IsValidDataPoint(1) && c1 &&
						Highs[0][0] >= ams2.SellSignal[1] && 
						Closes[0][0] < ams2.SellSignal[1] && 
						DOW.Contains(Times[0][0].DayOfWeek) &&
						Position.MarketPosition != MarketPosition.Short){
					EnterShort("S2");
					var ticks = Convert.ToInt32((Highs[0][0]-Closes[0][0])/TickSize) + 1;
					if(pEnableBEStop)
						SetTrailStop(CalculationMode.Ticks, ticks);
					else
						SetStopLoss(CalculationMode.Ticks, ticks);
//					double sum = 0;	for(int i = 1; i<20; i++) sum += Range()[i];
//					SetProfitTarget(CalculationMode.Ticks, Convert.ToInt32((sum/20)*pTargetMultiple/TickSize));
//Print("Short avg: "+DOWRanges[t.DayOfWeek].Average()+"    Count: "+DOWRanges[t.DayOfWeek].Count);
					TPTicks = Convert.ToInt32(DOWRanges[t.DayOfWeek].Average() * (1-PctOfDay)*pTargetMultiple/TickSize);
					SetProfitTarget(CalculationMode.Ticks, TPTicks);
					Draw.Dot(this,"AmbushTP2"+CurrentBar.ToString(), true, 0, ams2.SellSignal[1] - TPTicks*TickSize, Brushes.Lime);
					Draw.Diamond(this,"AmbushSL2"+CurrentBar.ToString(), false, 0, Highs[0][0]+TickSize, Brushes.Magenta);
				}
				if(CurrentSignalName == "2" && pEnableBEStop){
					if(Position.MarketPosition == MarketPosition.Long){
//						double sum = 0;	for(int i = 1; i<20; i++) sum += Range()[i];
//						double trigger = Instrument.MasterInstrument.RoundToTickSize(sum/20*pTargetMultiple/3) + Position.AveragePrice;
						double trigger = Instrument.MasterInstrument.RoundToTickSize(TPTicks*TickSize/3) + Position.AveragePrice;
						if(Lows[0][0] > trigger){
							SetTrailStop(CalculationMode.Ticks, 5);
							Draw.Diamond(this,"AmbushSL2"+CurrentBar.ToString(), false,0, Position.AveragePrice + TickSize*5, Brushes.Magenta);
					//Print(Times[0][0]+"  Long has trailing stop engaged");
						}
					}
					if(Position.MarketPosition == MarketPosition.Short){
//						double sum = 0;	for(int i = 1; i<20; i++) sum += Range()[i];
//						double trigger = Position.AveragePrice - Instrument.MasterInstrument.RoundToTickSize(sum/20*pTargetMultiple/3);
						double trigger = Position.AveragePrice - Instrument.MasterInstrument.RoundToTickSize(TPTicks*TickSize/3);
						if(Highs[0][0] < trigger){
							SetTrailStop(CalculationMode.Ticks, 5);
							Draw.Diamond(this,"AmbushSL2"+CurrentBar.ToString(), false,0, Position.AveragePrice - TickSize*5, Brushes.Magenta);
							//Print(Times[0][0]+"  Short has trailing stop engaged");
						}
					}
			}
			}
			#endregion -- Timeframe 2 End --
			#region -- Timeframe 3 --
			if(ams3 != null){
				if(ams3.BuySignal.IsValidDataPoint(1))  BuyLvl3[0] = ams3.BuySignal[1];
				if(ams3.SellSignal.IsValidDataPoint(1)) SellLvl3[0] = ams3.SellSignal[1];
				if(ams3.BuySignal.IsValidDataPoint(1) && c1 &&
						Lows[0][0] <= ams3.BuySignal[1] && 
						Closes[0][0] > ams3.BuySignal[1] && 
						DOW.Contains(t.DayOfWeek) &&
						Position.MarketPosition != MarketPosition.Long){
					EnterLong("L3");
					var ticks = Convert.ToInt32((Highs[0][0] - Lows[0][0])/TickSize) + 1;
					if(pEnableBEStop)
						SetTrailStop(CalculationMode.Ticks, ticks);
					else
						SetStopLoss(CalculationMode.Ticks, ticks);
//					double sum = 0;	for(int i = 1; i<20; i++) sum += Range()[i];
//					SetProfitTarget(CalculationMode.Ticks, Convert.ToInt32((sum/20)*pTargetMultiple/TickSize));
//Print("Long avg: "+DOWRanges[t.DayOfWeek].Average()+"    Count: "+DOWRanges[t.DayOfWeek].Count);
					TPTicks = Convert.ToInt32(DOWRanges[t.DayOfWeek].Average() * (1-PctOfDay)*pTargetMultiple/TickSize);
					SetProfitTarget(CalculationMode.Ticks, TPTicks);
					Draw.Dot(this,"AmbushTP1"+CurrentBar.ToString(), true, 0, ams3.BuySignal[1] + TPTicks*TickSize, Brushes.Lime);
					Draw.Diamond(this,"AmbushSL1"+CurrentBar.ToString(), false, 0, Lows[0][0]-TickSize, Brushes.Magenta);
				}
				if(ams3.SellSignal.IsValidDataPoint(1) && c1 &&
						Highs[0][0] >= ams3.SellSignal[1] && 
						Closes[0][0] < ams3.SellSignal[1] && 
						DOW.Contains(Times[0][0].DayOfWeek) &&
						Position.MarketPosition != MarketPosition.Short){
					EnterShort("S3");
					var ticks = Convert.ToInt32((Highs[0][1]-Lows[0][1])/TickSize) + 1;
					if(pEnableBEStop)
						SetTrailStop(CalculationMode.Ticks, ticks);
					else
						SetStopLoss(CalculationMode.Ticks, ticks);
//					double sum = 0;	for(int i = 1; i<20; i++) sum += Range()[i];
//					SetProfitTarget(CalculationMode.Ticks, Convert.ToInt32((sum/20)*pTargetMultiple/TickSize));
//Print("Short avg: "+DOWRanges[t.DayOfWeek].Average()+"    Count: "+DOWRanges[t.DayOfWeek].Count);
					TPTicks = Convert.ToInt32(DOWRanges[t.DayOfWeek].Average() * (1-PctOfDay)*pTargetMultiple/TickSize);
					SetProfitTarget(CalculationMode.Ticks, TPTicks);
					Draw.Dot(this,"AmbushTP3"+CurrentBar.ToString(), true, 0, ams3.SellSignal[1] - TPTicks*TickSize, Brushes.Lime);
					Draw.Diamond(this,"AmbushSL3"+CurrentBar.ToString(), false, 0, Highs[0][0]+TickSize, Brushes.Magenta);
				}
	//if(CurrentSignalName!="") Print("CurrentSig: "+CurrentSignalName);
				if(CurrentSignalName == "3" && pEnableBEStop){
					if(Position.MarketPosition == MarketPosition.Long){
//Print("Long avg price: "+Position.AveragePrice);
//						double sum = 0;	for(int i = 1; i<20; i++) sum += Range()[i];
//						double trigger = Instrument.MasterInstrument.RoundToTickSize(sum/20*pTargetMultiple/3) + Position.AveragePrice;
						double trigger = Position.AveragePrice + Instrument.MasterInstrument.RoundToTickSize(TPTicks*TickSize/3);
Draw.Diamond(this,"AmbushSL3"+CurrentBar.ToString(), false,0, trigger, Brushes.Magenta);
						if(Lows[0][0] > trigger){
							SetTrailStop(CalculationMode.Ticks, 5);
							//Print(Times[0][0]+"  Long has trailing stop engaged");
						}
					}
					if(Position.MarketPosition == MarketPosition.Short){
//						double sum = 0;	for(int i = 1; i<20; i++) sum += Range()[i];
//						double trigger = Position.AveragePrice - Instrument.MasterInstrument.RoundToTickSize(sum/20*pTargetMultiple/3);
//Print("Short avg price: "+Position.AveragePrice);
						double trigger = Position.AveragePrice - Instrument.MasterInstrument.RoundToTickSize(TPTicks*TickSize/3);
Print($"{Times[0][0].ToString()}  {Highs[0][0]} < {trigger}");
Draw.Diamond(this,"AmbushSL3"+CurrentBar.ToString(), false,0, trigger, Brushes.Magenta);
						if(Highs[0][0] < trigger){
							SetTrailStop(CalculationMode.Ticks, 5);
							//Print(Times[0][0]+"  Short has trailing stop engaged");
						}
					}
				}
			}
			#endregion -- Timeframe 3 End --

			if(Position.MarketPosition != MarketPosition.Flat && ToTime(Times[0][0])/100 > pGoFlatTime){
				//Print("End of day on "+Times[0][0].ToString());
				if(Position.MarketPosition == MarketPosition.Long) ExitLong();
				if(Position.MarketPosition == MarketPosition.Short) ExitShort();
				CurrentSignalName = "";
			}
		}
		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time)
		{
			if(execution.Name.Contains("1")) CurrentSignalName = "1";
			else if(execution.Name.Contains("2")) CurrentSignalName = "2";
			else if(execution.Name.Contains("3")) CurrentSignalName = "3";
//Print(string.Format("OEU:  mktPos: {0}  ExecName {1}  currSigName: {2}", marketPosition,execution.Name,CurrentSignalName));
		}
		protected override void OnPositionUpdate(Position position, double averagePrice, int quantity, MarketPosition marketPosition)
		{
			//Print(string.Format("OPU   position: {0}  mktPos {1}", position.ToString(), marketPosition.ToString()));
			if(marketPosition == MarketPosition.Flat){
				CurrentSignalName = "";
//Print("OPU   FLAT  CurrSigName ''");
			}
		}
		#region Properties
		[NinjaScriptProperty]
		[Range(0.00, double.MaxValue)]
		[Display(Name="Exhaustion Mult 1", Order=10, GroupName="Parameters")]
		public double pExhaustionMult1
		{ get; set; }
		[NinjaScriptProperty]
		[Range(1, 3)]
		[Display(Name="Timeframe 1", Order=10, GroupName="Parameters")]
		public int pTimeframe1
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.00, double.MaxValue)]
		[Display(Name="Exhaustion Mult 2", Order=11, GroupName="Parameters")]
		public double pExhaustionMult2
		{ get; set; }
		[NinjaScriptProperty]
		[Range(1, 3)]
		[Display(Name="Timeframe 2", Order=11, GroupName="Parameters")]
		public int pTimeframe2
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.00, double.MaxValue)]
		[Display(Name="Exhaustion Mult 3", Order=12, GroupName="Parameters")]
		public double pExhaustionMult3
		{ get; set; }
		[NinjaScriptProperty]
		[Range(1, 3)]
		[Display(Name="Timeframe 3", Order=12, GroupName="Parameters")]
		public int pTimeframe3
		{ get; set; }

//		[NinjaScriptProperty]
//		[Range(1, 3)]
//		[Display(Name="Signal Timeframe", Order=20, GroupName="Parameters")]
//		public int pSigTimeframe
//		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Target multiple", Order=30, GroupName="Parameters")]
		public double pTargetMultiple
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Days Of week", Order=40, GroupName="Parameters")]
		public string pDaysOfWeek
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Exclude", Order=45, GroupName="Parameters")]
		public string pExcludeTimes
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name="Start time", Order=50, GroupName="Parameters")]
		public int pStartTime
		{get; set;}

		[NinjaScriptProperty]
		[Display(Name="Stop time", Order=51, GroupName="Parameters")]
		public int pStopTime
		{get; set;}

		[NinjaScriptProperty]
		[Display(Name="Go flat time", Order=52, GroupName="Parameters")]
		public int pGoFlatTime
		{get; set;}

		[NinjaScriptProperty]
		[Display(Name="Enable BE Stop", Order=60, GroupName="Parameters")]
		public bool  pEnableBEStop
		{get;set;}
		#endregion

		#region -- Plots --
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> BuyLvl1
		{
			get { return Values[0]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> SellLvl1
		{
			get { return Values[1]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> BuyLvl2
		{
			get { return Values[2]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> SellLvl2
		{
			get { return Values[3]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> BuyLvl3
		{
			get { return Values[4]; }
		}
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> SellLvl3
		{
			get { return Values[5]; }
		}
		#endregion
	}
}
