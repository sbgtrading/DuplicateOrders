#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion

//This namespace holds MarketAnalyzerColumns in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns.ARC
{
	public class ARC_Trend : MarketAnalyzerColumn
	{
		private double trend = 0; //+1 for up, -1 for down
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description	= @"If todays close is above the prior candle high, we're UP, if it's below prior candle low, it's DOWN";
				Name		= "ARC_Trend";
				Calculate	= Calculate.OnBarClose;
				pERCpercentage = 50;
				this.DaysBack = 20;
				this.BarsToLoad = 50;
				pERCTxt = "ERC";
				pNonERCTxt = "NRC";
				pUpColor = Brushes.Lime;
				pDownColor = Brushes.Red;
				pUpTxtColor = Brushes.Black;
				pDownTxtColor = Brushes.White;
//				IsDataSeriesRequired	= false;
			}
			else if (State == State.DataLoaded)
			{
//				for(int b = 1; b<Bars.Count; b++){
//					if(Closes[0].GetValueAt(b) > Highs[0].GetValueAt(b-1)) trend = 1;
//					else if(Closes[0].GetValueAt(b) < Lows[0].GetValueAt(b-1)) trend = -1;
//				}
				if(pUpTxt.ToLower().Contains("<inst>")) pUpTxt = Instrument.MasterInstrument.Name;
				if(pDownTxt.ToLower().Contains("<inst>")) pDownTxt = Instrument.MasterInstrument.Name;
			}
		}

//		double ptrend = 0;
		bool IsERC = false;
		bool z = false;
		protected override void OnBarUpdate()
		{
//			z = Instrument.FullName.StartsWith("HE ");
			int BIP = BarsInProgress;
			if(CurrentBars[BIP]<1) return;
			if(BIP == 0){
//				ptrend = trend;
				double bodyPts = Math.Abs(Opens[BIP][0]-Closes[BIP][0]);
				double rangePts = Math.Abs(Highs[BIP][0]-Lows[BIP][0]);
				if(Closes[BIP][0] > Highs[BIP][1]){
					IsERC = bodyPts > rangePts * pERCpercentage/100.0;
					trend = 1;
					if(z)Print(Times[0][0].ToString()+"  Up trend...IsERC?  "+IsERC.ToString()+"    "+BarsPeriod.ToString());
				}
				else if(Closes[BIP][0] < Lows[BIP][1]){
					IsERC = bodyPts > rangePts * pERCpercentage/100.0;
					trend = -1;
					if(z)Print(Times[0][0].ToString()+"  DOWN trend...IsERC?  "+IsERC.ToString()+"    "+BarsPeriod.ToString());
				}
			}
//			if(ptrend!=trend)
//				Print(Instrument.FullName+"  "+BarsPeriod+"   trend: "+trend);

			this.BackColor = trend == 1 ? pUpColor : (trend == -1 ? pDownColor: null);
			this.ForeColor = trend == 1 ? pUpTxtColor : (trend == -1 ? pDownTxtColor : null);
			var txt = trend == 1 ? pUpTxt.Replace("<inst>",Instrument.MasterInstrument.Name) : (trend == -1 ? pDownTxt.Replace("<inst>",Instrument.MasterInstrument.Name) : "");
			this.CurrentText = string.Format("{0} {1}",txt, IsERC? pERCTxt : pNonERCTxt);
		}
		#region Properties
		[Display(Name="Min % for ERC", Description="", Order=5, GroupName="Parameters")]
		public int pERCpercentage
		{ get; set; }
		[Display(Name="Text for ERC", Description="", Order=6, GroupName="Parameters")]
		public string pERCTxt
		{ get; set; }
		[Display(Name="Text for NonERC", Description="", Order=7, GroupName="Parameters")]
		public string pNonERCTxt
		{ get; set; }

		[Display(Name="Text for Up Trend", Description="", Order=10, GroupName="Parameters")]
		public string pUpTxt
		{ get; set; }

		[XmlIgnore]
		[Display(Order = 20, Name = "Up bkg color", GroupName = "Parameters")]
		public Brush pUpColor
		{ get; set; }
				[Browsable(false)]
				public string UpColorSerializable { get { return Serialize.BrushToString(pUpColor); } set { pUpColor = Serialize.StringToBrush(value); }        }
		[XmlIgnore]
		[Display(Order = 21, Name = "Up txt color", GroupName = "Parameters")]
		public Brush pUpTxtColor
		{ get; set; }
				[Browsable(false)]
				public string UpTxtColorSerializable { get { return Serialize.BrushToString(pUpTxtColor); } set { pUpTxtColor = Serialize.StringToBrush(value); }        }

		[Display(Name="Text for Down Trend", Description="", Order=30, GroupName="Parameters")]
		public string pDownTxt
		{ get; set; }

		[XmlIgnore]
		[Display(Order = 40, Name = "Down bkg color", GroupName = "Parameters")]
		public Brush pDownColor
		{ get; set; }
				[Browsable(false)]
				public string DownColorSerializable { get { return Serialize.BrushToString(pDownColor); } set { pDownColor = Serialize.StringToBrush(value); }        }
		[XmlIgnore]
		[Display(Order = 41, Name = "Down txt color", GroupName = "Parameters")]
		public Brush pDownTxtColor
		{ get; set; }
				[Browsable(false)]
				public string DownTxtColorSerializable { get { return Serialize.BrushToString(pDownTxtColor); } set { pDownTxtColor = Serialize.StringToBrush(value); }        }
		#endregion
	}
}
