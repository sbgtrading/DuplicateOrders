#define DoLicense		//Uncomment to add NT7 licensing code at compilation for production only
#define MODERATORS

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion

//This namespace holds MarketAnalyzerColumns in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns.ARC
{
	public class ARC_FrequenciesScanner : MarketAnalyzerColumn
	{
		private bool ValidLicense = false;
		private bool LicenseChecked = false;
		private string UserId = string.Empty;
		private string MachineId = string.Empty;
		string ModuleName = "Frequencies";
		
        private const string VERSION = "v1.3 Aug.4.2020";
        [Display(Name = "Indicator Version", GroupName = "Indicator Version", Description = "Indicator Version", Order = 0)]
        public string indicatorVersion { get { return VERSION; } }

		#region LicErrorMessageHandler
		static class LicErrorMessageHandler{
			static System.Collections.Generic.SortedDictionary<string,long> ErrorMessages = new System.Collections.Generic.SortedDictionary<string,long>();
			static System.Collections.Generic.List<string> ExpiredModules = new System.Collections.Generic.List<string>();

			static public void SetModuleExpired(string moduleToExpire){
				ExpiredModules.Add(moduleToExpire);
			}
			static public bool IsExpired(string moduleToCheck){
				return ExpiredModules.Contains(moduleToCheck);
			}
			static public bool IsDuplicate(string new_msg){
				var keys = new System.Collections.Generic.List<string>(ErrorMessages.Keys);
				foreach(string keymsg in keys){
					if(keymsg.CompareTo(new_msg)==0){
						var ts = new TimeSpan(DateTime.Now.Ticks - ErrorMessages[keymsg]);
						if(ts.TotalMinutes<2)//time limit = 2 minutes...messages are considered duplicates if they are less than 2 minutes old
							return true;
						ErrorMessages[new_msg] = DateTime.Now.Ticks;
						return false;
					}
				}
				ErrorMessages[new_msg] = DateTime.Now.Ticks;
				return false;
			}
		}
		#endregion
		List<string> Expected_ISTagSet = new List<string>(){"22344", "11879", "27223"};//27223 is Annual Membership
		#region ARCLicense
		#region --  Registry class  --
		public class ModifyRegistry
		{
			public int NO_KEY_DEFINED = -1;
			public int ERROR_READING_KEY = -2;
			public string ErrorStatus = string.Empty;

			private bool showError = true;
			/// <summary>
			/// A property to show or hide error messages 
			/// (default = false)
			/// </summary>
			public bool ShowError
			{
				get { return showError; }
				set	{ showError = value; }
			}

			private string subKey = "Software\\NeuroStreet\\Settings";
			/// <summary>
			/// A property to set the SubKey value
			/// (default = "SOFTWARE\\" + Application.ProductName.ToUpper())
			/// </summary>
			public string SubKey
			{
				get { return subKey; }
				set	{ subKey = value; }
			}

			private Microsoft.Win32.RegistryKey baseRegistryKey = Microsoft.Win32.Registry.CurrentUser;
			/// <summary>
			/// A property to set the BaseRegistryKey value.
			/// (default = Registry.LocalMachine)
			/// </summary>
			public Microsoft.Win32.RegistryKey BaseRegistryKey
			{
				get { return baseRegistryKey; }
				set	{ baseRegistryKey = value; }
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// To read a registry key.
			/// input: KeyName (string)
			/// output: value (string) 
			/// </summary>
			public int Read(string KeyName)
			{
				// Opening the registry key
				var rk = baseRegistryKey ;
				// Open a subKey as read-only
				var sk1 = rk.OpenSubKey(subKey);
				// If the RegistrySubKey doesn't exist -> (null)
				if ( sk1 == null )
				{
					return NO_KEY_DEFINED;
				}
				else
				{
					try 
					{
						// If the RegistryKey exists I get its value
						// or null is returned.
						return Convert.ToInt32(sk1.GetValue(KeyName));
					}
					catch (Exception e)
					{
						ErrorStatus = e.ToString();
						// AAAAAAAAAAARGH, an error!
						//if(parent!=null) ShowErrorMessage(e, "Reading registry " + KeyName, parent);
						return ERROR_READING_KEY;
					}
				}
			}	

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// To write into a registry key.
			/// input: KeyName (string) , Value (object)
			/// output: true or false 
			/// </summary>
			public bool Write(string KeyName, object Value, NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					// I have to use CreateSubKey 
					// (create or open it if already exits), 
					// 'cause OpenSubKey open a subKey as read-only
					var sk1 = rk.CreateSubKey(subKey);
					// Save the value
					sk1.SetValue(KeyName, Value);

					return true;
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					ShowErrorMessage(e, "Writing registry " + KeyName, parent);
					return false;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// To delete a registry key.
			/// input: KeyName (string)
			/// output: true or false 
			/// </summary>
			public bool DeleteKey(string KeyName, NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					var sk1 = rk.CreateSubKey(subKey);
					// If the RegistrySubKey doesn't exists -> (true)
					if ( sk1 == null )
						return true;
					else
						sk1.DeleteValue(KeyName);

					return true;
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					ShowErrorMessage(e, "Deleting SubKey " + subKey, parent);
					return false;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// To delete a sub key and any child.
			/// input: void
			/// output: true or false 
			/// </summary>
			public bool DeleteSubKeyTree(NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					var sk1 = rk.OpenSubKey(subKey);
					// If the RegistryKey exists, I delete it
					if ( sk1 != null )
						rk.DeleteSubKeyTree(subKey);

					return true;
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					ShowErrorMessage(e, "Deleting SubKey " + subKey, parent);
					return false;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// Retrive the count of subkeys at the current key.
			/// input: void
			/// output: number of subkeys
			/// </summary>
			public int SubKeyCount(NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					var sk1 = rk.OpenSubKey(subKey);
					// If the RegistryKey exists...
					if ( sk1 != null )
						return sk1.SubKeyCount;
					else
						return 0; 
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					ShowErrorMessage(e, "Retriving subkeys of " + subKey, parent);
					return 0;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/

			/// <summary>
			/// Retrive the count of values in the key.
			/// input: void
			/// output: number of keys
			/// </summary>
			public int ValueCount(NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				try
				{
					// Setting
					var rk = baseRegistryKey ;
					var sk1 = rk.OpenSubKey(subKey);
					// If the RegistryKey exists...
					if ( sk1 != null )
						return sk1.ValueCount;
					else
						return 0; 
				}
				catch (Exception e)
				{
					ErrorStatus = e.ToString();
					// AAAAAAAAAAARGH, an error!
					ShowErrorMessage(e, "Retriving keys of " + subKey, parent);
					return 0;
				}
			}

			/* **************************************************************************
			 * **************************************************************************/
			
			private void ShowErrorMessage(Exception e, string Title, NinjaTrader.NinjaScript.IndicatorBase parent)
			{
				if (showError)
					parent.Print(e.Message);
			}
		}
		#endregion ----------------------------------------
		ModifyRegistry Reg = new ModifyRegistry();
		private int NewCustId = -1;
		private string XORCipher(string data, string key2)
		{
			#region xorcipher
			if(data==null) return null;
			if(key2==null) return null;
			int dataLen = data.Length;
			char[] output = new char[dataLen];

			var chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				if(chars[i]<'0' || chars[i]>'9') chars[i]='0';
			key2 = new String(chars);

//			while(key2.Length<32)
//				key2 = string.Format("{0}0",key2);
//			chars = key2.ToCharArray();
			for(int i = 0; i<chars.Length; i++)
				chars[i] = (char)((int)'a'+2*((int)chars[i]-(int)'0'));
			var key1 = string.Empty;
			for(int i = chars.Length-1; i>=0; i--){
				key1 = string.Format("{0}{1}",key1,chars[i]);
			}

//Print("Key1 ("+key1.Length+"): '"+key1+"'");
//Print("Key2 ("+key2.Length+"): '"+key2+"'");
			if(key1 != key2){
				int keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key1[i % keyLen]);
//Print("Pass1: "+key1);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key2[i % keyLen]);
//Print("Pass2: "+key2);
//Print(this.FromCharArrayToHexString(output));
				keyLen = key1.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(output[i] ^ key1[i % keyLen]);
//Print("Pass3: "+key1);
//Print(this.FromCharArrayToHexString(output));
			}else{
				var keyLen = key2.Length;
				for (int i = 0; i < dataLen; ++i)
					output[i] = (char)(data[i] ^ key2[i % keyLen]);
			}
			#endregion
			return new string(output);
		}
		private char[] FromHexToByteArray(string input){
			#region FromHexToByteArray
			input = input.Trim();
			if(input.Length==0) {
				//Print("FromHexToByteArray, input string zero length");
				return null;
			}
			char[] result = new char[input.Length/2];
			try{
				int i = 0;
				int r = 0;
				string s = null;
				uint u = 0;
//Print("input.Length: "+input.Length);
//Print("result.Length: "+result.Length);
				while(i<input.Length){
//Print("  r: "+r);
//Print("  i: "+i);
					s = input.Substring(i,2);
					if(uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out u)){
//Print(r+" '"+s+"'   "+u);
						result[r] = Convert.ToChar(u);
					}
					else {
						Print("FromHexToByteArray, could not covert hex:"+s+" to uint");
						return null;
					}
					r++;
					i = i + 2;
				}
			}catch(Exception e){
				Print("FromHexToByteArray, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			return result;
		}
		private string FromCharArrayToHexString(char[] input){
			#region FromCharArrayToHexString
			if(input.Length==0) {
				Print("FromCharArrayToHexString, input string zero length");
				return null;
			}
//			if(input.Length%2!=0) {
//				Print("FromCharArrayToHexString, input string length not even number");
//				return null;
//			}
			var result = new System.Text.StringBuilder();
			try{
				int i = 0;
				int inval = 0;
				string hex = "";
				while(i<input.Length){
					inval = (int)input[i];
					hex = string.Format("{00:x}",inval);
					if(hex.Length==1) result.Append("0");
					result.Append(hex);
					i = i + 1;
				}
			}catch(Exception e){
				Print("FromCharArrayToHexString, conversion terminated:"+e.ToString());
				return null;
			}
			#endregion
			var str = result.ToString();
			return str;
		}
		private bool FileIsOld=false;
		private DateTime IndicatorLaunchDT=DateTime.Now;
		private DateTime DateOfFreeTrialFile = DateTime.MaxValue;
//=====================================================================================================================
		#region Supporting methods
		private string NSConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"NS_config");
		private string ARCConfigDirectory  = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),"ARCAI_license");
		//===========================================================================
		private bool IsoFileExists(string IsoFileName, ref bool FileIsOld){
			string fullpath = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
			var fileinfo = new System.IO.FileInfo(fullpath);
			DateOfFreeTrialFile = fileinfo.LastAccessTime.Date;
			FileIsOld = DateOfFreeTrialFile != DateTime.Now.Date;
//Print(IsoFileName+" is last accessed: "+fileinfo.LastAccessTime.ToString());
			return System.IO.File.Exists(fullpath);

//			return System.IO.File.Exists(fullpath);
		}
		//===========================================================================
		private void OverwriteIsoFile(string IsoFileName, string WriteThisText, ref string ErrorMessage){
			try{
				IsoFileName = System.IO.Path.Combine(ARCConfigDirectory,IsoFileName);
				//Print("Writing "+WriteThisText+"'\nTo file: "+IsoFileName);
				System.IO.File.WriteAllText(IsoFileName, WriteThisText);

			}catch(Exception err){
				ErrorMessage = err.ToString();
				Print("Error "+ErrorMessage);
			}
		}
		//===========================================================================
		private string GetLineFromIsoStorage(string IsoFileName, string InText, bool SaveInText, ref string ErrorMessage){
			/*If the fileName exists, read the contents of that infile and return the first line to the caller
			  If SaveInText is true and InText, then write the result to the IsoStore
			*/

			string result = string.Empty;
			bool InputFileExists = IsoFileExists(IsoFileName, ref FileIsOld);
			var IsoFileFullPath = System.IO.Path.Combine(ARCConfigDirectory, IsoFileName);
			if (InputFileExists){//Read one line from isostorage - eliminates the dependencce on an unstable config.xml file
				try{
					var lines = System.IO.File.ReadAllLines(IsoFileFullPath);
					foreach(string L in lines) {
						if(L.Trim().StartsWith(@"//")) continue;
						else if(L.Trim().Length==0) continue;
						else result = L.Trim();
					}
				}catch(Exception err){
					ErrorMessage = IsoFileName+" IsoFile read error: "+err.ToString();
					Print(ErrorMessage);
				}
			}
			if(result.CompareTo(InText)==0) {
				//Print("265:  returning: "+InText);//don't save the InText if matches the stored info
			}
			else if(SaveInText && InText.Trim().Length>0){
				//Save InText to isostorage - this eliminates the dependence on an unstable config.xml file
				OverwriteIsoFile(IsoFileName, InText, ref ErrorMessage);
				result = InText;
			}
			return result;
		}
		#endregion
		private int GetCustID(bool PingRegistry){
			#region -- Get customer id from ARCAI folder first, if not there, then try the NS_Config folder, if not there then try Registry --
			int ret_custid = -1;
			string folder = ARCConfigDirectory;
			if(!System.IO.Directory.Exists(folder)) System.IO.Directory.CreateDirectory(folder);
			string search = "arccid_*.txt";
			var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
if(IsDebug)Print("Searching for "+folder+", arccid_*.txt...");
			if(filCustom!=null){
				foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
					var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
					if(elements.Length>1)
						ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("  CustID: "+ret_custid);
				}
			}
			if(ret_custid == -1){
				folder = NSConfigDirectory;
if(IsDebug)Print("Searching for "+folder+", nscid_*.txt...");
				search = "nscid_*.txt";
				filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
				if(filCustom!=null){
					foreach(System.IO.FileInfo fi in filCustom){
if(IsDebug)Print("   reading filename: "+fi.Name);
						var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
						if(elements.Length>1)
							ret_custid = int.Parse(elements[1]);
if(IsDebug)Print("   CustID: "+ret_custid);
					}
				}
			}
			if(ret_custid == -1 && PingRegistry){
				//the config file doesn't exist, create one based on what is recovered from the registry
				try{
if(IsDebug) Print(" ARCCID file is getting custid from registry because of file missing");
					ret_custid = Reg.Read("custid");
				}catch(Exception ex2){
if(IsDebug) Print("Registry read error: "+ex2.ToString());
					if(!LicErrorMessageHandler.IsDuplicate(ex2.ToString())) LogMsg("Please run your 'ARC_LicenseActivator v1' and supply your ARCAI Contact ID number", Cbi.LogLevel.Alert);
					return -1;
				}
			}
			if(ret_custid>0){
				System.IO.File.WriteAllText(
					System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+ret_custid.ToString().Trim()+".txt"),
					ret_custid.ToString()
				);
			}
			return ret_custid;
			#endregion
		}
		private bool NSLicense(string ModuleName, string SupportEmailAddress, ref string UserId, ref string MachineId, int FirstPort, int LastPort){
			MachineId = NinjaTrader.Cbi.License.MachineId;
if(IsDebug)Print("Running ARC License now");
			#region -- NSLicense --
//if(IsDebug)MachineId = "CC224A5A36E376EC1409A2EEF890547A";
			if(LicErrorMessageHandler.IsExpired(ModuleName)) {
				NewCustId = GetCustID(true);
				UserId = NewCustId.ToString();
				return false;
			}//this module has already been found to be unlicensed, return "false" since there's no need to recheck the database
			double HOURS_BETWEEN_PINGS = 48;
			string ErrorMessage = string.Empty;
			bool   ValidLicense = false;
			string NL = Environment.NewLine;

			string IsoStoreExpireDateFile = string.Format("ARC_ED_{0}.txt",ModuleName);
			string ExpirationDateKey = @"rf_!~5 %*l;|P h3 wWf]";

			bool ValidateViaAPI = true;
			long ExpireLongInt  = 0;
			string ExpiryDateEncrypted = "";
			#region -- Should we ping the server again? --
			if(IsoFileExists(IsoStoreExpireDateFile, ref FileIsOld)){
if(IsDebug) Print(" Iso file exists...FileIsOld?: "+FileIsOld.ToString());
				//This determines if we need to ping the server again.  Fewer API pings increase speed of verification
				//If this Iso file doesn't exist, or if the encrypted contents do not contain this machine id, or if the date of expiration has passed, then reping the server for license validation
				//Otherwise, do not ping the server.  Repinging of the server will only happen once every HOURS_BETWEEN_PINGS hours
				ExpiryDateEncrypted = GetLineFromIsoStorage(IsoStoreExpireDateFile, "", true, ref ErrorMessage);
				if(ExpiryDateEncrypted.Trim().Length>0){
					var ExpireDateDecrypted = XORCipher(new String(FromHexToByteArray(ExpiryDateEncrypted)), ExpirationDateKey);
if(IsDebug)Print("   Decrypted: "+ExpireDateDecrypted);
					if(ExpireDateDecrypted.Contains(MachineId)){//the expiration date string must contain this machine id, to prevent this expiration file from being transferred to another computer
						string datestr = ExpireDateDecrypted.Remove(0,ExpireDateDecrypted.IndexOf(':')+1);
if(IsDebug)Print("   DateStr from Iso:  '"+datestr+"'");
						long.TryParse(datestr, out ExpireLongInt);
						ValidateViaAPI = DateTime.Now.Ticks >= ExpireLongInt;
if(IsDebug) Print(" Validate via API: "+ValidateViaAPI.ToString());
					}
				}
			}else{
if(IsDebug) Print(" Iso file not found");
			}
			#endregion

			if(!ValidateViaAPI){
				var d = new DateTime(ExpireLongInt);
				ValidLicense = true;
				UserId = "-9999";
if(IsDebug) Print(" License is considered valid,  Date from DateStr:  '"+d.ToString()+"'"+"    hours: "+HOURS_BETWEEN_PINGS);
			}else{
if(IsDebug) Print(" Getting custid from file");
				NewCustId = GetCustID(true);
				#region -- Read config folder for ContactID --
//				string folder = ARCConfigDirectory;
//				string search = "arccid_*.txt";
//				var filCustom = new System.IO.DirectoryInfo(folder).GetFiles(search);
//				if(filCustom!=null){
//					foreach(System.IO.FileInfo fi in filCustom){
//						var elements = fi.Name.Split(new char[]{'_','.'},StringSplitOptions.RemoveEmptyEntries);
//						if(elements.Length>1)
//							NewCustId = int.Parse(elements[1]);
//					}
//				}else{//the config file doesn't exist, create one based on what is recovered from the registry
//					try{
//if(IsDebug) Print(" ARCCID file is getting custid from registry because of file missing");
//						NewCustId = Reg.Read("custid", this);
//					}catch(Exception ex2){
//if(IsDebug) Print("Registry read error: "+ex2.ToString());
//						if(!LicErrorMessageHandler.IsDuplicate(ex2.ToString())) LogMsg("Please run your 'ARC_LicenseActivator v1' and supply your ARCAI Contact ID number", Cbi.LogLevel.Alert);
//						return false;
//					}
//					if(NewCustId>0){
//						System.IO.File.WriteAllText(
//							System.IO.Path.Combine(ARCConfigDirectory,"arccid_"+NewCustId.ToString().Trim()+".txt"),
//							NewCustId.ToString()
//						);
//					}
//				}
				#endregion
//if(IsDebug) NewCustId = 239389;
if(IsDebug)Print("Infusionsoft ContactID:  "+NewCustId);
				UserId = NewCustId.ToString();
#if MODERATORS
				bool IsSeanKozak = UserId.CompareTo("42277")==0;
				if(IsSeanKozak) return true;
				//if(UserId.CompareTo("42117")==0) return true;// Ben Letto
#endif
				string keyString = Math.Abs(DateTime.Now.Ticks/(DateTime.Now.Second+10)).ToString("0");
				bool WebsiteFound = false;
				keyString = keyString.Replace("0",string.Empty).Trim();
				if(keyString.Length>32) 
					keyString = keyString.Substring(0,32);

				string responseHexStr = string.Empty;
				string msgCB = string.Empty;
				string URL = string.Empty;
if(IsDebug) Print("Sending webclient request");
//				for(Port = FirstPort; !WebsiteFound && Port<=LastPort; Port++)
				{
					responseHexStr = string.Empty;
					if(FirstPort<8080 || LastPort<8080)
//						URL = string.Format("https://nstradingacademy.com/ns_scripts/IS/NS_LicenseCheck.php");
						URL = string.Format("https://architectsai.com/ns_scripts/IS/NS_LicenseCheck.php");
					else
						URL = string.Format("http://localhost:{0}/?m={1}-{4}-{2}&k={3}", FirstPort, NinjaTrader.Cbi.License.MachineId, ModuleName, keyString, UserId);
//Print(Port+"   URL: "+url);
//if(FirstPort==7070) continue;
//continue;
					try{
						#region -- Do the license check --
			            var parameters = new System.Collections.Specialized.NameValueCollection();
			            var values = new System.Collections.Generic.Dictionary<string, string>
	                        {
	                            { "nscustid", NewCustId.ToString() },
	                            { "custnum",  MachineId },
	                            { "platform", "ninjatrader"},
	                            { "version",  ModuleName+" "+indicatorVersion},
	                            { "datetime", DateTime.Now.ToString()},
	                            { "random",   this.Name}
	                        };
			            if(IsDebug) Print(string.Concat("   ====== parameters below =======", Environment.NewLine));
			            var paramstring = string.Empty;
			            foreach (var kvp in values)
			            {
			                if(IsDebug) Print(string.Concat("   ",kvp.Key, ":  ", kvp.Value, Environment.NewLine));
			                parameters.Add(kvp.Key, kvp.Value);
			                if(paramstring.Length==0)
			                    paramstring = string.Format("{0}={1}", kvp.Key, kvp.Value);
			                else
			                    paramstring = string.Format("{0}&{1}={2}", paramstring, kvp.Key, kvp.Value);
			            }
			            #endregion

if(IsDebug) Print(string.Concat("   ",URL," ?"+paramstring, Environment.NewLine));

						#region -- Create WebClient and post request --
			            var ntWebClient = new System.Net.WebClient();
			            ntWebClient.CachePolicy = new System.Net.Cache.HttpRequestCachePolicy(System.Net.Cache.HttpRequestCacheLevel.NoCacheNoStore);
			            ntWebClient.Headers.Add(System.Net.HttpRequestHeader.UserAgent, "NeuroStreet NinjaTrader DLL");
			            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

			            if(IsDebug) Print(string.Concat(Environment.NewLine, "====== response below =======", Environment.NewLine));
			            try
			            {
			                byte[] responseArray = ntWebClient.UploadValues(URL, "POST", parameters);
			                responseHexStr = System.Text.Encoding.ASCII.GetString(responseArray);
			                if(IsDebug) Print(string.Concat(responseArray.Length,"-char response was: ", Environment.NewLine, responseHexStr, Environment.NewLine));
							msgCB = string.Empty;
							WebsiteFound = true;
			            }
			            catch (Exception er) {
			                if(IsDebug) Print(string.Concat(Environment.NewLine, "====== error =======", Environment.NewLine, er.ToString(), Environment.NewLine));
							msgCB = er.ToString();
							WebsiteFound = false;
			            }
						#endregion
						//==========================================
					}catch(Exception err){
						WebsiteFound = false;
						msgCB = string.Concat(msgCB,"===================",Environment.NewLine,err.Message);
					}
				}
				if(!WebsiteFound) {
					msgCB = string.Format("No reponse from ARC License Server {0}{0}{1}", NL, msgCB);
if(IsDebug) Print(string.Format("{1}:: Web error:  {2}{0}{3}{0}{4}",NL,ModuleName,URL,responseHexStr,msgCB));
					System.Windows.Forms.Clipboard.SetText(string.Format("==============={0}{1}{0}===============",NL,msgCB));
					msgCB = string.Format(".Send this msg to {1}{0}(this info has already been copied to your clipboard){0}{2}", NL, SupportEmailAddress, msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					return false;
				}

				string plainText = responseHexStr;//XORCipher(new String(FromHexToByteArray(responseHexStr)), keyString);
				msgCB = string.Empty;
				var ISTagsList = plainText.Split(new char[]{','},StringSplitOptions.RemoveEmptyEntries).ToList();
if(IsDebug) Print("PlainText response from api: "+plainText);
				ValidLicense = false;
				foreach(var tag in ISTagsList) if(Expected_ISTagSet.Contains(tag)) {ValidLicense = true; break;}
				if(!ValidLicense){
					msgCB = string.Format("Send this message to: {1}{0}This license is expired{0}{2}  {3}{0}{4}", NL, SupportEmailAddress, UserId, ModuleName, MachineId);
					System.Windows.Forms.Clipboard.SetText(string.Format("==============={0}{1}{0}===============",NL,msgCB));
					msgCB = string.Format(".{1}{0}(this info has already been copied to your clipboard)",NL,msgCB);
					if(!LicErrorMessageHandler.IsDuplicate(msgCB)) LogMsg(msgCB, Cbi.LogLevel.Alert);
					LicErrorMessageHandler.SetModuleExpired(ModuleName);
					OverwriteIsoFile(IsoStoreExpireDateFile, "", ref ErrorMessage);
				}else{
					var expire_date_string = string.Format("{0} License good until: {1}",MachineId, DateTime.Now.AddHours(HOURS_BETWEEN_PINGS).Ticks.ToString());
if(IsDebug)Print("License is valid...will Expire: "+expire_date_string);
					ExpiryDateEncrypted = FromCharArrayToHexString(XORCipher(expire_date_string, ExpirationDateKey).ToCharArray());
					OverwriteIsoFile(IsoStoreExpireDateFile, ExpiryDateEncrypted, ref ErrorMessage);
//Print("ErrorMessage: '"+ErrorMessage+"'");
				}
			}
			return ValidLicense;
			#endregion
			//==============================================================
		}
		private void LogMsg(string msg, Cbi.LogLevel alrt){
			string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.UserDataDir,"bin","Custom");
			string search = "SharkIndicators*.*";

			System.IO.DirectoryInfo dirCustom=null;
			System.IO.FileInfo[] filCustom=null;
			try{
				dirCustom = new System.IO.DirectoryInfo(folder);
				filCustom = dirCustom.GetFiles().Where(kk=>kk.Name.Contains("SharkIndicators") || kk.Name.Contains("SilentLicenseErrors")).ToArray();
			}catch(Exception e){Print("Err: "+e.ToString());}
			if(filCustom==null || filCustom.Length==0)
				Log(msg, alrt);
			else
				Log(msg, Cbi.LogLevel.Warning);
		}

		#endregion
		bool IsDebug = false;

        private class PatternHistory
        {
            public string Name { get; set; }
            public int BarIndex { get; set; }
            public int DIndex { get; set; }
            public int OIndex { get; set; }
            public int PaternId { get; set; }
            public bool IsDrawn { get; set; }
            public bool IsLive { get; set; }
            public bool IsBullish { get; set; }
            public int Depth { get; set; }
            public double Stop { get; set; }
            public double Target { get; set; }
            public bool IsSpent { get; set; }

            public PatternHistory()
            {
                IsDrawn = false;
                IsSpent = false;
            }

//			public override string ToString()
//			{
//				return $"Pattern: {Name}, Id: {PaternId}, Stop: {Stop}, Target: {Target}, IsLive: {IsLive}";
//			}
		}

		internal class LoadSoundFileList : StringConverter
		{
			#region LoadSoundFileList
			public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
			{
				//true means show a combobox
				return true;
			}

			public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
			{
				//true will limit to list. false will show the list, 
				//but allow free-form entry
				return false;
			}

			public override System.ComponentModel.TypeConverter.StandardValuesCollection
				GetStandardValues(ITypeDescriptorContext context)
			{
				string folder = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir,"sounds");
				string search = "*.wav";
				System.IO.DirectoryInfo dirCustom=null;
				System.IO.FileInfo[] filCustom=null;
				try{
					dirCustom = new System.IO.DirectoryInfo(folder);
					filCustom = dirCustom.GetFiles( search);
				}catch{}

				var list = new List<string>();//new string[filCustom.Length+1];
				list.Add("SOUND OFF");
				if(filCustom!=null){
					foreach (System.IO.FileInfo fi in filCustom)
					{
						if(!list.Contains(fi.Name)){
							list.Add(fi.Name);
						}
					}
				}
				return new StandardValuesCollection(list.ToArray());
			}
			#endregion
        }

        #region Variables
        private double ExtCD = 0.886;
        private int RangeForPointD = 1;
		private bool firstRun = true;

        private double _barhigh = 0;
        private double _barlow = 0;
        private int _barindex = 0;
        private double phi = 1.618;
		private int Deviation = 5;
		private int Backstep = 3;
		private int MaxBarsBack = 500;
		private int MaxDepth = 40;
		private int MinDepth = 10;
		private int Direction = -1;
		
		private List<int> depths;
        private List<PatternHistory> Patterns;

        private string vBullBear = "";
        private string vNamePattern = "";
        private string patName;
        private string vBullBearToNumberPattern = "";
        private string vNamePatternToNumberPattern = "";
        private int maxPeak, vPatOnOff, vPatNew = 0;
		private int patternId = 0;
        private int patCounter = 0;
        private bool isLive = false;
        private double hBar, lBar;
        private bool FlagForD = true;
        private int TimeForDmin = 0, TimeForDminToNumberPattern;
        private int TimeForDmax = 0, TimeForDmaxToNumberPattern;
        private double LevelForDmin = 0, LevelForDminToNumberPattern;
        private double LevelForDmax = 0, LevelForDmaxToNumberPattern;
        private List<double> PeakPriceX;
        private List<double> PeakPriceA;
        private List<double> PeakPriceB;
        private List<double> PeakPriceC;
        private List<double> PeakPriceD;
        private List<int> PeakTimeX;
        private List<int> PeakTimeA;
        private List<int> PeakTimeB;
        private List<int> PeakTimeC;
        private List<int> PeakTimeD;
		private Color bullTextColor;
		private Color bearTextColor;
        private int countGartley = 0;
		private int lastD = -1;
		private Dictionary<int, NinjaTrader.NinjaScript.Indicators.ARC.Sup.ARC_Frequencies_Single> zigZags;
		#endregion
		
        //public override string DisplayName { get { return "ARC_FrequenciesScanner"; } }
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "ARC_FrequenciesScanner";
				Calculate = Calculate.OnBarClose;
				MaximumBarsLookBack = MaximumBarsLookBack.Infinite;
				MaxFibDelta				= 0.1;
				ShowGartley				= true;
				ShowBat					= true;
				ShowButterfly			= true;
				ShowCrab				= true;
				Show50					= true;
				ShowShark				= true;
				ShowThreeDrives			= true;
				ShowCypher				= true;
                ShowLong = true;
                ShowShort = true;
				ShowLarge = true;
				ShowSmall = true;
				BullColor = Brushes.Lime;
				BearColor = Brushes.Red;
				AlertSoundFile = "SOUND OFF";
				pEmailAddress = string.Empty;
			}
			else if (State == State.Configure)
			{
#if DoLicense
				if(!LicenseChecked){
					ValidLicense = NSLicense(ModuleName, "support@architectsai.com", ref UserId, ref MachineId, 7070, 7071);
					LicenseChecked = true;
				}
				IsDebug=false;
#endif
				Calculate = Calculate.OnBarClose;
				depths = new List<int>();
				
				MaxDepth = ShowLarge ? 40 : 22;
				MinDepth = ShowSmall ? 10 : 24;
				
				for(int i = MinDepth; i < 16; i++)
				{
					depths.Add(i);
				}
				for(int i = Math.Max(MinDepth, 16); i < Math.Min(30, MaxDepth); i+=2)
				{
					depths.Add(i);
				}
                for (int i = Math.Max(MinDepth, 30); i < Math.Min(80, MaxDepth); i += 5)
                {
                    depths.Add(i);
                }

				depths.Reverse();
				firstRun = true;
			}
			else if(State == State.Historical)
			{

                Patterns = new List<PatternHistory>();
            }
			else if(State == State.DataLoaded)
			{
				zigZags = new Dictionary<int, NinjaTrader.NinjaScript.Indicators.ARC.Sup.ARC_Frequencies_Single>();
				foreach(int depth in depths)
				{
					zigZags.Add(depth, ARC_Frequencies_Single(depth));
				}
			}
        }

		#region Gartley
        private void _Gartley(int depth, int index = 0)
        {
            int shift;

            double min_DeltaGartley = (1 - MaxFibDelta);
            double max_DeltaGartley = (1 + MaxFibDelta);
            double vl0382 = min_DeltaGartley * 0.382;
            double vl05 = min_DeltaGartley * 0.5;
            double vh05 = max_DeltaGartley * 0.5;
            double vl0618 = min_DeltaGartley * 0.618;
            double vh0618 = max_DeltaGartley * 0.618;
            double vl0786 = min_DeltaGartley * 0.786;
            double vh0786 = max_DeltaGartley * 0.786;
            double vl0886 = min_DeltaGartley * 0.886;
            double vh0886 = max_DeltaGartley * 0.886;
            double vl1128 = min_DeltaGartley * 1.128;
            double vh1128 = max_DeltaGartley * 1.128;
            double vl1272 = min_DeltaGartley * 1.272;
            double vh1272 = max_DeltaGartley * 1.272;
            double vl1414 = min_DeltaGartley * 1.414;
            double vh1414 = max_DeltaGartley * 1.414;
            double vl15 = min_DeltaGartley * 1.5;
            double vh15 = max_DeltaGartley * 1.5;
            double vl1618 = min_DeltaGartley * 1.61803399;
            double vh1618 = max_DeltaGartley * 1.61803399;
            double vh1732 = max_DeltaGartley * 1.732;
            double vl2236 = min_DeltaGartley * 2.236;
            double vh2236 = max_DeltaGartley * 2.236;
            double vh2618 = max_DeltaGartley * 2.618;
            double vh3618 = max_DeltaGartley * 3.618;

            double bartoD;
			double target1 = 0, target2 = 0, target3 = 0;
            double stop = 0;

            int[] aXABCD = 
            {
                0,
                0,
                0,
                0,
                0,
                0
            };
            double retXD = 0;
            double retXB = 0;
            double retBD = 0;
            double retAC = 0;
            double retOA = 0;
            double XA = 0, BC = 0, XC = 0;

            double vDelta0 = 1E-06;
            int O = 0, X = 1, A = 2, B = 3, C = 4, D = 5;
            string vBull = "Bullish";
            string vBear = "Bearish";
            string vGartley = "Gartley";
            string vBat = "Bat";
            string vButterfly = "Butterfly";
            string vCrab = "Crab";
            string vShark = "Shark";
            string vAB_CD = "AB=CD";
            string v3_drives = "Three Drives";
            string v5sub0 = "5-0 Pattern";
			string vCypher = "Cypher";
            int[] aNumBarPeak;
			double[] zz = new double[CurrentBar];

            maxPeak = 0;
			aNumBarPeak = new int[CurrentBar];

            int nextSwing = 0;
            for (shift = index; shift < CurrentBar; shift++)
            {
                zz[shift] = 0;
				if(double.IsNaN(zigZags[depth].zz[shift]) || zigZags[depth].zz[shift] == 0)
				{
					continue;
				}
                if (nextSwing >= 0 && zigZags[depth].zz[shift] >= High[shift])
                {
                    zz[shift] = zigZags[depth].zz[shift];
                    nextSwing = -1;
                    aNumBarPeak[maxPeak] = shift;
                    maxPeak++;
                }
                if (nextSwing <= 0 && zigZags[depth].zz[shift] <= Low[shift])
                {
                    zz[shift] = zigZags[depth].zz[shift];
                    nextSwing = 1;
                    aNumBarPeak[maxPeak] = shift;
                    maxPeak++;
                }
                //Print("Shift: " + shift + ", maxPeak: " + maxPeak);
                if (maxPeak > 7)
                {
                    break;
                }
            }
//			if(Depth == 10)
//            	Print("Scanner " + Instrument.MasterInstrument.Name + ", " + maxPeak + ", last Peak: " + aNumBarPeak[0] + " - " + zz[aNumBarPeak[0]] + ", Current Bar: " + CurrentBar + ", Close[0]: " + Close[0]);

            bartoD = 1.618 * (aNumBarPeak[4] - aNumBarPeak[0]);
            //Print(bartoD);

            aXABCD[D] = aNumBarPeak[0];

            int start = Math.Min(maxPeak - 7, 1);
            //Print(start);
            //Print(Instrument.MasterInstrument.Name + ", " + Depth + ", " + aNumBarPeak[0] + ", " + zz[aNumBarPeak[0]] + ", " + aNumBarPeak[1] + ", " + zz[aNumBarPeak[1]]);
            for(int k = start; k >= 0; k--)
            {
                vBullBear = "";
                vNamePattern = "";
                aXABCD[O] = aNumBarPeak[k + 5];
                aXABCD[X] = aNumBarPeak[k + 4];
                aXABCD[A] = aNumBarPeak[k + 3];
                aXABCD[B] = aNumBarPeak[k + 2];
                aXABCD[C] = aNumBarPeak[k + 1];
                aXABCD[D] = aNumBarPeak[k];
				
				
				if(lastD >= 0 && aXABCD[D] >= lastD)
				{
					//k++;
					//continue;
				}

                if ((zz[aXABCD[A]] > zz[aXABCD[C]]) && (zz[aXABCD[C]] > zz[aXABCD[B]]) && (zz[aXABCD[B]] > zz[aXABCD[X]]) && (zz[aXABCD[X]] > zz[aXABCD[D]]) && ((zz[aXABCD[C]] - zz[aXABCD[D]]) >= (zz[aXABCD[A]] - zz[aXABCD[B]]) * ExtCD))
                {
                    vBullBear = vBull;
                }
                else if ((zz[aXABCD[A]] > zz[aXABCD[C]]) && (zz[aXABCD[C]] > zz[aXABCD[B]]) && (zz[aXABCD[B]] > zz[aXABCD[D]]) && (zz[aXABCD[D]] > zz[aXABCD[X]]) && ((zz[aXABCD[C]] - zz[aXABCD[D]]) >= (zz[aXABCD[A]] - zz[aXABCD[B]]) * ExtCD))
                {
                    vBullBear = vBull;
                }
                else if ((zz[aXABCD[X]] > zz[aXABCD[D]]) && (zz[aXABCD[D]] > zz[aXABCD[B]]) && (zz[aXABCD[B]] > zz[aXABCD[C]]) && (zz[aXABCD[C]] > zz[aXABCD[A]]) && ((zz[aXABCD[D]] - zz[aXABCD[C]]) >= (zz[aXABCD[B]] - zz[aXABCD[A]]) * ExtCD))
                {
                    vBullBear = vBear;
                }
                else if ((zz[aXABCD[D]] > zz[aXABCD[X]]) && (zz[aXABCD[X]] > zz[aXABCD[B]]) && (zz[aXABCD[B]] > zz[aXABCD[C]]) && (zz[aXABCD[C]] > zz[aXABCD[A]]) && ((zz[aXABCD[D]] - zz[aXABCD[C]]) >= (zz[aXABCD[B]] - zz[aXABCD[A]]) * ExtCD))
                {
                    vBullBear = vBear;
                }
                else if ((zz[aXABCD[O]] > zz[aXABCD[A]]) && (zz[aXABCD[C]] > zz[aXABCD[A]]) && (zz[aXABCD[A]] > zz[aXABCD[X]]) && (zz[aXABCD[D]] > zz[aXABCD[B]]) && (zz[aXABCD[C]] > zz[aXABCD[B]]))
                {
                    vBullBear = vBull;
                }
                else if ((zz[aXABCD[A]] > zz[aXABCD[O]]) && (zz[aXABCD[A]] > zz[aXABCD[C]]) && (zz[aXABCD[X]] > zz[aXABCD[A]]) && (zz[aXABCD[B]] > zz[aXABCD[D]]) && (zz[aXABCD[B]] > zz[aXABCD[C]]))
                {
                    vBullBear = vBear;
                }
                else if ((zz[aXABCD[O]] > zz[aXABCD[A]]) && (zz[aXABCD[C]] > zz[aXABCD[A]]) && (zz[aXABCD[A]] > zz[aXABCD[X]]) && (zz[aXABCD[C]] > zz[aXABCD[B]]))
                {
                    vBullBear = vBull;
                }
                else if ((zz[aXABCD[A]] > zz[aXABCD[O]]) && (zz[aXABCD[A]] > zz[aXABCD[C]]) && (zz[aXABCD[X]] > zz[aXABCD[A]]) && (zz[aXABCD[B]] > zz[aXABCD[C]]))
                {
                    vBullBear = vBear;
                }
                else if ((zz[aXABCD[A]] > zz[aXABCD[C]]) && (zz[aXABCD[C]] > zz[aXABCD[B]]) && (zz[aXABCD[B]] > zz[aXABCD[D]]) && ((zz[aXABCD[C]] - zz[aXABCD[D]]) >= (zz[aXABCD[A]] - zz[aXABCD[B]]) * ExtCD))
                {
                    vBullBear = vBull;
                }
                else if ((zz[aXABCD[D]] > zz[aXABCD[B]]) && (zz[aXABCD[B]] > zz[aXABCD[C]]) && (zz[aXABCD[C]] > zz[aXABCD[A]]) && ((zz[aXABCD[D]] - zz[aXABCD[C]]) >= (zz[aXABCD[B]] - zz[aXABCD[A]]) * ExtCD))
                {
                    vBullBear = vBear;
                }
                else if ((zz[aXABCD[O]] > zz[aXABCD[A]]) && (zz[aXABCD[A]] > zz[aXABCD[C]]) && (zz[aXABCD[A]] > zz[aXABCD[X]]) && (zz[aXABCD[C]] > zz[aXABCD[D]]) && (zz[aXABCD[C]] > zz[aXABCD[B]]) && (zz[aXABCD[X]] > zz[aXABCD[B]]) && (zz[aXABCD[B]] > zz[aXABCD[D]]))
                {
                    vBullBear = vBull;
                }
                else if ((zz[aXABCD[A]] > zz[aXABCD[O]]) && (zz[aXABCD[C]] > zz[aXABCD[A]]) && (zz[aXABCD[X]] > zz[aXABCD[A]]) && (zz[aXABCD[D]] > zz[aXABCD[C]]) && (zz[aXABCD[B]] > zz[aXABCD[C]]) && (zz[aXABCD[B]] > zz[aXABCD[X]]) && (zz[aXABCD[D]] > zz[aXABCD[B]]))
                {
                    vBullBear = vBear;
                }

    //            if(Depth == 45)
				//{
				//	Print("Pattern: " + vBullBear + " 0: " + Time[aXABCD[0]].ToString() + " X: " + Time[aXABCD[X]].ToString() + " A: " + Time[aXABCD[X]].ToString() + " B: " + Time[aXABCD[B]].ToString() + " C: " + Time[aXABCD[C]].ToString() + " D: " + Time[aXABCD[D]].ToString() + " k: " + k);
				//}
                if (vBullBear.Length > 0)
                {
                    if (vBullBear == vBull)
                    {
                        retOA = (zz[aXABCD[X]] - zz[aXABCD[A]]) / (zz[aXABCD[X]] - zz[aXABCD[O]] + vDelta0);
                        retXB = (zz[aXABCD[A]] - zz[aXABCD[B]]) / (zz[aXABCD[A]] - zz[aXABCD[X]] + vDelta0);
						retXD = (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]]) / (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[X]] + vDelta0);
						retBD = (zz[aXABCD[C]] - zz[aXABCD[D]]) / (zz[aXABCD[C]] - zz[aXABCD[B]] + vDelta0);
                        retAC = (zz[aXABCD[C]] - zz[aXABCD[B]]) / (zz[aXABCD[A]] - zz[aXABCD[B]] + vDelta0);
                        if (RangeForPointD > 0 && FlagForD)
                        {
                  			XC = zz[aXABCD[C]] - zz[aXABCD[X]];
                            XA = zz[aXABCD[A]] - zz[aXABCD[X]];
                            BC = zz[aXABCD[C]] - zz[aXABCD[B]];
                        }
                    }
                    else if (vBullBear == vBear)
                    {
                        retOA = (zz[aXABCD[A]] - zz[aXABCD[X]]) / (zz[aXABCD[O]] - zz[aXABCD[X]] + vDelta0);
                        retXB = (zz[aXABCD[B]] - zz[aXABCD[A]]) / (zz[aXABCD[X]] - zz[aXABCD[A]] + vDelta0);
						retXD = (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]])) / (zz[aXABCD[X]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]) + vDelta0);
						retBD = (zz[aXABCD[D]] - zz[aXABCD[C]]) / (zz[aXABCD[B]] - zz[aXABCD[C]] + vDelta0);
                        retAC = (zz[aXABCD[B]] - zz[aXABCD[C]]) / (zz[aXABCD[B]] - zz[aXABCD[A]] + vDelta0);
                        if (RangeForPointD > 0 && FlagForD)
                        {
		                  	XC = zz[aXABCD[X]] - zz[aXABCD[C]];
                            XA = zz[aXABCD[X]] - zz[aXABCD[A]];
                            BC = zz[aXABCD[B]] - zz[aXABCD[C]];
                        }
                    }

                    if (ShowGartley && retAC >= vl0382 && retAC <= vh0886 && retXD >= vl0618 && retXD <= vh0786 && retBD >= vl1272 && retBD <= vh1618 && retXB >= vl0618 && retXB <= vh0618)
                    {
                        vNamePattern = vGartley;
                        // Gartley
                        if (RangeForPointD > 0 && FlagForD)
                        {
                            if (vBullBear == vBull)
                            {
                                LevelForDmin = Math.Max(zz[aXABCD[A]] - XA * vh0786, zz[aXABCD[C]] - BC * vh2236);
                                LevelForDmax = Math.Min(zz[aXABCD[A]] - XA * vl0618, zz[aXABCD[C]] - BC * vl1128);
								target1 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.382;
								target2 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.618;
								target3 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.5;
                                stop = zz[aXABCD[X]] - TickSize;
                                patName = "CRM1";
								patternId = 1;
                            }
                            else if (vBullBear == vBear)
                            {
                                LevelForDmin = Math.Max(zz[aXABCD[A]] + XA * vl0618, zz[aXABCD[C]] + BC * vl1128);
                                LevelForDmax = Math.Min(zz[aXABCD[A]] + XA * vh0786, zz[aXABCD[C]] + BC * vh2236);
								target1 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.382;
								target2 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.618;
								target3 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.5;
                                stop = zz[aXABCD[X]] + TickSize;
                                patName = "CRW1";
                                patternId = -1;
                            }
                        }
                    }
                   	else if (ShowButterfly && retAC >= vl0382 && retAC <= vh0886 && retXD >= vl1272 && retXD <= vh1618 && retBD >= vl1618 && retBD <= vh2618 && retXB >= vl0786 && retXB <= vh0786)
                    {
                        vNamePattern = vButterfly;
                        // Butterfly
                        if (RangeForPointD > 0 && FlagForD)
                        {
                            if (vBullBear == vBull)
                            {
                                LevelForDmin = Math.Max(zz[aXABCD[A]] - XA * vh1618, zz[aXABCD[C]] - BC * vh2618);
                                LevelForDmax = Math.Min(zz[aXABCD[A]] - XA * vl1272, zz[aXABCD[C]] - BC * vl1272);
								target1 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.382;
								target2 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.618;
								target3 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.5;
								patternId = 2;
                                stop = Math.Min(zz[aXABCD[A]] - XA * vh1618, zz[aXABCD[C]] - BC * vh2618) - TickSize;
                                patName = "RRM1";
                            }
                            else if (vBullBear == vBear)
                            {
                                LevelForDmin = Math.Max(zz[aXABCD[A]] + XA * vl1272, zz[aXABCD[C]] + BC * vl1272);
                                LevelForDmax = Math.Min(zz[aXABCD[A]] + XA * vh1618, zz[aXABCD[C]] + BC * vh2618);
								target1 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.382;
								target2 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.618;
								target3 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.5;
                                stop = Math.Max(zz[aXABCD[A]] + XA * vh1618, zz[aXABCD[C]] + BC * vh2618) + TickSize;
                                patternId = -2;
                                patName = "RRW1";
                            }
                        }
                    }
                    else if (ShowCrab && retAC >= vl0382 && retAC <= vh0886 && retXD >= vl1618 && retXD <= vh1618 && retBD >= vl2236 && retBD <= vh3618 && retXB >= vl0382 && retXB <= vh0618)
                    {
                        vNamePattern = vCrab;
                        // Crab
                        if (RangeForPointD > 0 && FlagForD)
                        {
                            if (vBullBear == vBull)
                            {
                                LevelForDmin = Math.Max(zz[aXABCD[A]] - XA * vh1618, zz[aXABCD[C]] - BC * vh3618);
                                LevelForDmax = Math.Min(zz[aXABCD[A]] - XA * vl1618, zz[aXABCD[C]] - BC * vl2236);
								target1 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.382;
								target2 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.618;
								target3 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.5;
                                stop = (zz[aXABCD[A]] - XA * 2) - TickSize;
                                patName = "RRM2";
                                patternId = 3;
                            }
                            else if (vBullBear == vBear)
                            {
                                LevelForDmin = Math.Max(zz[aXABCD[A]] + XA * vl1618, zz[aXABCD[C]] + BC * vl2236);
                                LevelForDmax = Math.Min(zz[aXABCD[A]] + XA * vh1618, zz[aXABCD[C]] + BC * vh3618);
								target1 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.382;
								target2 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.618;
								target3 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.5;
                                stop = (zz[aXABCD[A]] + XA * 2) + TickSize;
                                patName = "RRW2";
                                patternId = -3;
                            }
                        }
                    }
                    else if (ShowBat && retAC >= vl0382 && retAC <= vh0886 && retXD >= vl0886 && retXD <= vh0886 && retBD >= vl1618 && retBD <= vh2618 && retXB >= vl0382 && retXB <= vh05)
                    {
                        vNamePattern = vBat;
                        // Bat
                        if (RangeForPointD > 0 && FlagForD)
                        {
                            if (vBullBear == vBull)
                            {
                                LevelForDmin = Math.Max(zz[aXABCD[A]] - XA * vh0886, zz[aXABCD[C]] - BC * vh2618);
                                LevelForDmax = Math.Min(zz[aXABCD[A]] - XA * vl0886, zz[aXABCD[C]] - BC * vl1272);
								target1 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.382;
								target2 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.618;
								target3 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.5;
                                stop = zz[aXABCD[X]] - TickSize;
                                patName = "CRM2";
                                patternId = 4;
                            }
                            else if (vBullBear == vBear)
                            {
                                LevelForDmin = Math.Max(zz[aXABCD[A]] + XA * vl0886, zz[aXABCD[C]] + BC * vl1272);
                                LevelForDmax = Math.Min(zz[aXABCD[A]] + XA * vh0886, zz[aXABCD[C]] + BC * vh2618);
								target1 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.382;
								target2 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.618;
								target3 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.5;
                                stop = zz[aXABCD[X]] + TickSize;
                                patName = "CRW2";
                                patternId = -4;
                            }
                        }
                    }
                    else if (ShowCypher && retXB >= vl0382 && retXB <= vh0618 && retAC >= vl1128 && retAC <= vh1414 && retBD > vl1272 && retBD < 2 && retXD >= vl0786 && retXD <= vh0786)
                    {
                        vNamePattern = vCypher;
                        // Cypher
                        if (RangeForPointD > 0 && FlagForD)
                        {
                            if (vBullBear == vBull)
                            {
								LevelForDmin = zz[aXABCD[C]] - XC * vh0786;
								LevelForDmax = zz[aXABCD[C]] - XC * vl0786;
								target1 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.382;
								target2 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.618;
								target3 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]])*0.5;
                                stop = zz[aXABCD[X]] - TickSize;
                                patternId = 5;
                                patName = "CRM4";
                            }
                            else if (vBullBear == vBear)
                            {
								LevelForDmin = zz[aXABCD[C]] + XC * vl0786;
								LevelForDmax = zz[aXABCD[C]] + XC * vh0786;
								target1 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.382;
								target2 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.618;
								target3 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]]))*0.5;
                                stop = zz[aXABCD[X]] + TickSize;
                                patternId = -5;
                                patName = "CRW4";
                            }
                        }
                    }
                    else if (Show50 && retAC >= vl1618 && retAC <= vh2236 && retBD >= vl05 && retBD <= vh05 && retXB >= vl1128 && retXB <= vh1618 && retOA <= vh0886)
                    {
						//Print("5-0 Found");
                        vNamePattern = v5sub0;
                        // 5-0
                        if (RangeForPointD > 0 && FlagForD)
                        {
                            if (vBullBear == vBull)
                            {
                                LevelForDmin = zz[aXABCD[C]] - BC * vh0618;
                                LevelForDmax = zz[aXABCD[C]] - BC * vl0382;
                                target1 = zz[aXABCD[C]];
                                target2 = (zz[aXABCD[C]] - zz[B]) / 2 + zz[aXABCD[C]];
                                target3 = zz[aXABCD[C]];
                                stop = zz[aXABCD[C]] - BC * vh0786 - TickSize;
                                patternId = 6;
                                patName = "RRM3";
                            }
                            else if (vBullBear == vBear)
                            {
                                LevelForDmin = zz[aXABCD[C]] + BC * vl0382;
                                LevelForDmax = zz[aXABCD[C]] + BC * vh0618;
                                target1 = zz[aXABCD[C]];
                                target2 = zz[aXABCD[C]] - (zz[aXABCD[B]] - zz[C]) / 2;
                                target3 = zz[aXABCD[C]];
                                stop = zz[aXABCD[C]] + BC * vh0786 + TickSize;
                                patternId = -6;
                                patName = "RRW3";
                            }
                        }
                    }
                    else if (ShowThreeDrives && (retOA >= vl05 && retOA <= vh0618 && retAC >= vl05 && retAC <= vh0786) && ((retXB >= vl1272 && retXB <= vh1272 && retBD >= vl1272 && retBD <= vh1272) || (retXB >= vl15 && retXB <= vh15 && retBD >= vl15 && retBD <= vh15) || (retXB >= vl1618 && retXB <= vh1618 && retBD >= vl1618 && retBD <= vh1618)))
                    {
                        vNamePattern = v3_drives;
                        // Three Drives
                        if (RangeForPointD > 0 && FlagForD)
                        {
                            if (vBullBear == vBull)
                            {
								target1 = zz[aXABCD[C]];
								target2 = zz[aXABCD[A]];
								target3 = zz[aXABCD[C]];
                                if ((retBD >= vl1272) && (retBD <= vh1272))
                                {
                                    LevelForDmin = zz[aXABCD[C]] - BC * vh1414;
                                    LevelForDmax = zz[aXABCD[C]] - BC * vl1128;
                                }
                                else if ((retBD >= vl1414) && (retBD <= vh1414))
                                {
                                    LevelForDmin = zz[aXABCD[C]] - BC * vh15;
                                    LevelForDmax = zz[aXABCD[C]] - BC * vl1272;
                                }
                                else if ((retBD >= vl15) && (retBD <= vh15))
                                {
                                    LevelForDmin = zz[aXABCD[C]] - BC * vh1618;
                                    LevelForDmax = zz[aXABCD[C]] - BC * vl1414;
                                }
                                else if ((retBD >= vl1618) && (retBD <= vh1618))
                                {
                                    LevelForDmin = zz[aXABCD[C]] - BC * vh1732;
                                    LevelForDmax = zz[aXABCD[C]] - BC * vl15;
                                }
                                stop = LevelForDmin - TickSize;
                                patternId = 8;
                                patName = "RRM4";
                            }
                            else if (vBullBear == vBear)
                            {
								target1 = zz[aXABCD[C]];
								target2 = zz[aXABCD[A]];
								target3 = zz[aXABCD[C]];
                                if ((retBD >= vl1272) && (retBD <= vh1272))
                                {
                                    LevelForDmin = zz[aXABCD[C]] + BC * vl1128;
                                    LevelForDmax = zz[aXABCD[C]] + BC * vh1414;
                                }
                                else if ((retBD >= vl1414) && (retBD <= vh1414))
                                {
                                    LevelForDmin = zz[aXABCD[C]] + BC * vl1272;
                                    LevelForDmax = zz[aXABCD[C]] + BC * vh15;
                                }
                                else if ((retBD >= vl15) && (retBD <= vh15))
                                {
                                    LevelForDmin = zz[aXABCD[C]] + BC * vl1414;
                                    LevelForDmax = zz[aXABCD[C]] + BC * vh1618;
                                }
                                else if ((retBD >= vl1618) && (retBD <= vh1618))
                                {
                                    LevelForDmin = zz[aXABCD[C]] + BC * vl15;
                                    LevelForDmax = zz[aXABCD[C]] + BC * vh1732;
                                }
                                stop = LevelForDmax + TickSize;
                                patternId = -8;
                                patName = "RRW4";
                            }
                        }
                    }
					else if (ShowShark && retAC >= vl1128 && retAC <= vh1618 && retXD >= vl0886 && retXD <= vh1128 && retBD >= vl1618 && retBD <= vh2236)
              		{
               			vNamePattern=vShark; // Shark
               			if (RangeForPointD > 0 && FlagForD)
                 		{
                  			if (vBullBear == vBull)
                    		{
                     			LevelForDmin = Math.Min(zz[aXABCD[C]]-XC*vh1128,zz[aXABCD[C]]-BC*vh2236);
                     			LevelForDmax = Math.Max(zz[aXABCD[C]]-XC*vl0886,zz[aXABCD[C]]-BC*vl1618);
                                target1 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]]) * 0.382;
                                target2 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]]) * 0.618;
                                target3 = zz[aXABCD[D]] + (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]]) * 0.5;
                                stop = zz[aXABCD[D]] - (Math.Max(zz[aXABCD[A]], zz[aXABCD[C]]) - zz[aXABCD[D]]) * 0.382;
                                patternId = 9;
                                patName = "CRM3";
                            }
                            else if (vBullBear == vBear)
							{
								LevelForDmin = Math.Min(zz[aXABCD[C]]+XC*vl0886,zz[aXABCD[C]]+BC*vl1618);
								LevelForDmax = Math.Max(zz[aXABCD[C]]+XC*vh1128,zz[aXABCD[C]]+BC*vh2236);
                                target1 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]])) * 0.382;
                                target2 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]])) * 0.618;
                                target3 = zz[aXABCD[D]] - (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]])) * 0.5;
                                stop = zz[aXABCD[X]] + (zz[aXABCD[D]] - Math.Min(zz[aXABCD[A]], zz[aXABCD[C]])) * 0.382;
                                patternId = -9;
                                patName = "CRW3";
                            }
                        }
		            }
                }

                if (vNamePattern.Length > 0)
                {
                    //Print("Pattern: " + vBullBear + " 0: " + Time[aXABCD[0]].ToString() + " X: " + Time[aXABCD[X]].ToString() + " A: " + Time[aXABCD[X]].ToString() + " B: " + Time[aXABCD[B]].ToString() + " C: " + Time[aXABCD[C]].ToString() + " D: " + Time[aXABCD[D]].ToString() + " k: " + k);
                    //Print(Instrument.MasterInstrument.Name + ", " + patName + ", " + Depth + ", " + k + ", " + aXABCD[D]);
                    if (vBullBear == vBull && !ShowLong)
                    {
                        continue;
                    }
                    if (vBullBear == vBear && !ShowShort)
                    {
                        continue;
                    }

                    vPatOnOff = 1;

                    PatternHistory currentPattern = Patterns.FirstOrDefault(p => p.BarIndex == CurrentBar - aXABCD[C] && p.OIndex == CurrentBar - aXABCD[O] && p.Name == patName);
                    if (currentPattern == null)
                    {
                        //Print("Scanner New Pattern: " + patName + ", " + aXABCD[D] + ", " + k +", Depth: " + depth + ", Stop: " + stop + ", Target: " + target1 + ", on Instrument: " + Instrument.MasterInstrument.Name + ", Period: " + BarsPeriod.ToString());
                        currentPattern = new PatternHistory { BarIndex = CurrentBar - aXABCD[C], OIndex = CurrentBar - aXABCD[O], IsBullish = patternId > 0, Name = patName, PaternId = patCounter++, IsLive = true ? true : false, Depth = depth, Stop = stop, Target = target1 };
                        Patterns.Add(currentPattern);
                    }

                    if (depth > currentPattern.Depth)
                    {
//                        Print("Scanner New Pattern Depth: " + Depth + ", Name: " + currentPattern.Name);
                        currentPattern.Depth = depth;
                        currentPattern.IsLive = true;
                        currentPattern.IsDrawn = false;
                    }

                    if (currentPattern.Depth != depth)
                    {
                        continue;
                    }

                    if (currentPattern.IsLive)
                    {
                        if (currentPattern.DIndex != CurrentBar - aXABCD[D] || currentPattern.Stop != stop || currentPattern.Target != target1)
                        {
                            currentPattern.DIndex = CurrentBar - aXABCD[D];
							currentPattern.Stop = stop;
							currentPattern.Target = target1;
                            currentPattern.IsDrawn = false;
                        }
                    }
//                    else
//                    {
//                        if (k == 0)
//                        {
////                            Print("Scanner Resurrects pattern: " + currentPattern.Name);
//                            currentPattern.IsLive = true;
//                            currentPattern.DIndex = CurrentBar - aXABCD[D];
//                            currentPattern.IsDrawn = false;
//                        }
//                    }


                    //if (currentPattern.IsDrawn && (!currentPattern.IsLive || currentPattern.Depth != Depth))
                    //{
                    //    //Print("Pattern Already drawn");
                    //    //k++;
                    //    continue;
                    //}

                    //lastD = aXABCD[D];

                    //currentPattern.IsDrawn = true;

                    //---------------------------------------------
                    //return;
                }
                else
                {
					if(lastD == -1)
					{
						vBullBear = "";
						vNamePattern = "";
						vBullBearToNumberPattern = "";
						vNamePatternToNumberPattern = "";
					}
					patternId = 0;
                }
                //k++;

            }
        }
		#endregion

		private int EmailAlertABar = 0;
		protected override void OnBarUpdate()
		{
			if(Bars.Count < 500)
				return;
			
			if(CurrentBar < Bars.Count - 2)
				return;

			//Print(firstRun);
			if (State != State.Realtime)
				return;
			
#if DoLicense
			if(!ValidLicense) {
				this.IsVisible = false;
				////draw.TextFixed(this,"lictext",ModuleName+" license not valid\n"+MachineId+"  "+UserId+"\n\nContact support@architectsai.com for assistance",TextPosition.Center,Brushes.White,new SimpleFont("Arial",12),Brushes.Black,Brushes.Black,90);
				IsVisible = false;
				return;
			}
#endif

			//if (CurrentBar == _barindex && High[0] == _barhigh && Low[0] == _barlow)
             //   return;

            if (CurrentBar != _barindex)
            {
                _barindex = CurrentBar;
            }
			
			//Print(Time[0].ToString());
			
			MaxBarsBack = Math.Min(500, CurrentBar - 1);
            _barhigh = High[0];
            _barlow = Low[0];
            vPatOnOff = 0;
			lastD = -1;

            foreach (int depth in depths)
            {
    			_Gartley(depth);
			}

            Patterns.ForEach(p =>
            {
                if (p.IsLive)
                {
					//Print("Pattern : " + p.Name + "Target: " + p.Target);
                    if (High[0] > Math.Max(p.Stop, p.Target) || Low[0] < Math.Min(p.Stop, p.Target))
                    {
                        p.IsLive = false;
                        p.IsDrawn = false;
						//Print("Pattern : " + p.Name + "Finished");
                    }
                }
            });

            PatternHistory pattern = Patterns.Where(p => p.IsLive).OrderBy(p => p.DIndex).LastOrDefault();

            if (pattern != null)
			{
//				CurrentValue = patternId;
				if(string.IsNullOrWhiteSpace(CurrentText))
				{
					SoundAlert();
					if(EmailAlertABar == 0) EmailAlertABar = BarsArray[0].Count;
					if(State!=null && State == State.Realtime && !string.IsNullOrEmpty(pEmailAddress) && pEmailAddress.Length>0 && CurrentBars!=null && EmailAlertABar < CurrentBars[0]) {
						EmailAlertABar = CurrentBars[0];
						Log("Email sent:  FrequencyScanner trade on "+Instrument.MasterInstrument.Name+" "+pattern.Name,LogLevel.Information);
						SendMail(pEmailAddress, "FrequencyScanner trade on "+Instrument.MasterInstrument.Name+" "+pattern.Name, "Auto generated alert from your NinjaTrader platform");
					}
				}
				CurrentText = pattern.Name;

				if(pattern.IsBullish)
					BackColor = BullColor;
				else
					BackColor = BearColor;
			}
			else
			{
				CurrentText = " ";
				BackColor = Brushes.Transparent;
			}

		}

		protected override void OnMarketData(MarketDataEventArgs marketDataUpdate)
		{
            if(marketDataUpdate.MarketDataType != MarketDataType.Last || Math.Abs(marketDataUpdate.Price) < double.Epsilon)
            {
                return;
            }
			bool updatePattern = false;
			
			if(firstRun)
			{
				MaxBarsBack = Math.Min(500, CurrentBar - 1);
	            _barhigh = High[0];
	            _barlow = Low[0];
	            vPatOnOff = 0;
				lastD = -1;
				for(int i = 30; i >= 0; i--)
                {
					foreach (int depth in depths)
					{
	    				_Gartley(depth, i);
					}
				}
				firstRun = false;
				updatePattern = true;
			}
			
			Patterns.ForEach(p =>
			{
				if (p.IsLive)
				{
					if (marketDataUpdate.Price > Math.Max(p.Stop, p.Target) || marketDataUpdate.Price < Math.Min(p.Stop, p.Target))
					{
						p.IsLive = false;
						p.IsDrawn = false;
						updatePattern = true;
					}
				}
			});
			if(updatePattern)
			{
				PatternHistory pattern = Patterns.Where(p => p.IsLive).OrderBy(p => p.DIndex).LastOrDefault();

				if (pattern != null)
				{
					if(string.IsNullOrWhiteSpace(CurrentText))
					{
						SoundAlert();
						if(EmailAlertABar == 0) EmailAlertABar = BarsArray[0].Count;
						if(State!=null && State == State.Realtime && !string.IsNullOrEmpty(pEmailAddress) && pEmailAddress.Length>0 && CurrentBars!=null && EmailAlertABar < CurrentBars[0]) {
							EmailAlertABar = CurrentBars[0];
							Log("Email sent:  FrequencyScanner trade on "+Instrument.MasterInstrument.Name+" "+pattern.Name,LogLevel.Information);
							SendMail(pEmailAddress, "FrequencyScanner trade on "+Instrument.MasterInstrument.Name+" "+pattern.Name, "Auto generated alert from your NinjaTrader platform");
						}
					}
					this.CurrentText = pattern.Name;

					if (pattern.IsBullish)
						BackColor = BullColor;
					else
						BackColor = BearColor;
				}
				else
				{
					CurrentText = " ";
					BackColor = Brushes.Transparent;
				}
			}
		}
		
		private void SoundAlert()
		{
			string alertSoundFile = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, @"sounds", AlertSoundFile.Trim());
			bool fileVerified = System.IO.File.Exists(alertSoundFile);
			if(fileVerified)
			{
				PlaySound(alertSoundFile);
			}
		}


		#region Properties
		[Range(0, double.MaxValue)]
		[NinjaScriptProperty]
		[Display(Name="Max Deviation", Description="Maximum Deviation From the ratio parameters", Order=1, GroupName="Parameters")]
		public double MaxFibDelta
		{ get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Long Ratios", Order = 2, GroupName = "Parameters")]
        public bool ShowLong
        { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Short Ratios", Order = 3, GroupName = "Parameters")]
        public bool ShowShort
        { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Large Ratios", Order = 4, GroupName = "Parameters")]
        public bool ShowLarge
        { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show Small Ratios", Order = 5, GroupName = "Parameters")]
		public bool ShowSmall
		{ get; set; }

        [NinjaScriptProperty]
		[Display(Name="CRM1/CRW1 Ratio", Order=11, GroupName="Parameters")]
		public bool ShowGartley
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name= "CRM2/CRW2 Ratio", Order=12, GroupName="Parameters")]
		public bool ShowBat
		{ get; set; }

        [NinjaScriptProperty]
        [Display(Name = "CRM3/CRW3 Ratio", Order = 13, GroupName = "Parameters")]
        public bool ShowShark
        { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "CRM4/CRW4 Ratio", Order = 14, GroupName = "Parameters")]
        public bool ShowCypher
        { get; set; }

        [NinjaScriptProperty]
		[Display(Name= "RRM1/RRW1 Ratio", Order=15, GroupName="Parameters")]
		public bool ShowButterfly
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name= "RRM2/RRW2 Ratio", Order=16, GroupName="Parameters")]
		public bool ShowCrab
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name= "RRM3/RRW3 Ratio", Order=17, GroupName="Parameters")]
		public bool Show50
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name= "RRM4/RRW4 Ratio", Order=18, GroupName="Parameters")]
		public bool ShowThreeDrives
		{ get; set; }

        [XmlIgnore]
        [Display(Name = "Bull Ratio Color", Order = 31, GroupName = "Parameters")]
        public Brush BullColor
        { get; set; }

        [Browsable(false)]
        public string BullColorSerializable
        {
            get { return Serialize.BrushToString(BullColor); }
            set { BullColor = Serialize.StringToBrush(value); }
        }

        [XmlIgnore]
        [Display(Name = "Bear Ratio Color", Order = 32, GroupName = "Parameters")]
        public Brush BearColor
        { get; set; }

		[NinjaScriptProperty]
		[Display(Name= "Alert Sound File", Order=41, GroupName="Parameters")]
		[RefreshProperties(RefreshProperties.All)]
		[TypeConverter(typeof(LoadSoundFileList))]
		public string AlertSoundFile
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name= "Email address", Order=42, GroupName="Parameters")]
		public string pEmailAddress {get;set;}

        [Browsable(false)]
        public string BearColorSerializable
        {
            get { return Serialize.BrushToString(BearColor); }
            set { BearColor = Serialize.StringToBrush(value); }
        }
		#endregion
	}
}
