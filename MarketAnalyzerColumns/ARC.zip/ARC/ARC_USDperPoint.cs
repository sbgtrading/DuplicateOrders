#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion

//This namespace holds MarketAnalyzerColumns in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns.ARC
{
	public class ARC_USDperPoint : MarketAnalyzerColumn
	{
		#region Static class
		static class ARC_USDperPoint_Data{
			static System.Collections.Generic.SortedDictionary<string,double> PriceTable = new System.Collections.Generic.SortedDictionary<string,double>();
			static public void AddPrice(string currencyname, double mktprice){
				PriceTable[currencyname.ToUpper().Trim()] = mktprice;
			}
			static public double GetPrice(string currencyname){
				var s = currencyname.ToUpper().Trim();
				if(PriceTable.ContainsKey(s)) return PriceTable[s];
				else return -1;
			}
		}
		#endregion

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "ARC_USDperPoint";
				Calculate									= Calculate.OnBarClose;
				IsDataSeriesRequired	= false;
			}
			else if (State == State.Configure)
			{
			}
		}
		double close = -1;
		DateTime t = DateTime.MinValue;
		protected override void OnMarketData(Data.MarketDataEventArgs marketDataUpdate)
		{
			var ts = new TimeSpan(DateTime.Now.Ticks-t.Ticks);
			if(ts.TotalSeconds < 5){
				return;
			}
			t = DateTime.Now;
			if (marketDataUpdate.IsReset)
				close = double.MinValue;
			else if (marketDataUpdate.MarketDataType == Data.MarketDataType.Ask){
				close = marketDataUpdate.Price;
				if(Instrument.MasterInstrument.InstrumentType == InstrumentType.Forex){
	//				try{
						var basename = Instrument.FullName.Substring(0,3);
						var quotename = Instrument.FullName.Substring(3,3);
						if(quotename == "USD"){
							CurrentValue = 1;
							ARC_USDperPoint_Data.AddPrice(basename, close);
						}else{
							if(basename == "USD")
								ARC_USDperPoint_Data.AddPrice(quotename, 1/close);
							CurrentValue = ARC_USDperPoint_Data.GetPrice(quotename);
						}
						if(CurrentValue > 0){
							var s = CurrentValue.ToString("0.000000");
							for(int i = 0; i<10; i++)
								if(s.EndsWith("0")) s = s.Substring(0, s.Length-1); else break;
							if(s.EndsWith(".")) s = s.Replace(".","");
							if(s.EndsWith(".0")) s = s.Replace(".0","");
							CurrentText = s;
						} else CurrentText = "...wait";
						
	//				}catch{}
				}
			}
		}
	}
}
