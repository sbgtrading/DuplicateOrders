#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion

//This namespace holds MarketAnalyzerColumns in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns.ARC
{
	public class ARC_InsideOutsideDay : MarketAnalyzerColumn
	{
		private double YH=double.MinValue;
		private double YL=double.MinValue;
		private double val = 0;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description	= @"When current price is inside of yesterdays High and Low, +1.  All other situations is -1";
				Name		= "ARC Inside / Outside Day";
				Calculate	= Calculate.OnPriceChange;
				//this.DaysBack = 2;
//				IsDataSeriesRequired	= false;
			}
			else if (State == State.Configure)
			{
				AddDataSeries(Data.BarsPeriodType.Day, 1);
			}
		}

		protected override void OnMarketData(MarketDataEventArgs marketDataUpdate)
		{
			try{
			if(BarsInProgress==0 && YH!=double.MinValue && YL!=double.MinValue){
				val = 0;
				if(Closes[0][0] <= YH && Closes[0][0] >= YL)
					val = 1;//market is inside of yesterday high and low
				else //if(Highs[1][0] > Highs[1][1] && Lows[1][0] < Lows[1][1])
					val = -1;//market is outside of yesterday high and low
			}
			if(BarsInProgress==1 && CurrentBars[1]>0){
				YH = Highs[1][1];
				YL = Lows[1][1];
			}
			}catch{}

			if(YH==double.MinValue || YL==double.MinValue){
				val = -999;
			}
			CurrentValue = val;
		}

	}
}
