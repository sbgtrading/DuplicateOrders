#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion

//This namespace holds MarketAnalyzerColumns in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns.ARC
{
	public class ARC_DataLagTimer : MarketAnalyzerColumn
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Time (in seconds) between your computer time and the time of the last tick in the market";
				Name										= "ARC_DataLagTimer";
				Calculate									= Calculate.OnEachTick;
				pSecondsLabel = "-sec";
				pMinutesLabel = "-min";
				pMinutesAdjuster = 0;
				pThresholdForMinutes = 60;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnMarketData(MarketDataEventArgs e)
		{
			var ts = new TimeSpan(NinjaTrader.Core.Globals.Now.Ticks-e.Time.Ticks);
			var seconds = Math.Abs(ts.TotalSeconds) + pMinutesAdjuster*60;
			if(seconds < 2){
				CurrentValue = seconds;
				CurrentText = string.Format("{0}{1}",CurrentValue.ToString("0.00"), pSecondsLabel);
			}
			else if(seconds <= pThresholdForMinutes){
				CurrentValue = seconds;
				CurrentText = string.Format("{0}{1}",CurrentValue.ToString("0.0"), pSecondsLabel);
			}
			else{
				CurrentValue = Math.Round(seconds/60,1);
				CurrentText = string.Format("{0}{1}",CurrentValue, pMinutesLabel);
			}
		}


		#region Properties
		[NinjaScriptProperty]
		[Display(Name="Seconds label", Order=10, GroupName="Parameters")]
		public string pSecondsLabel		{ get; set; }
		[NinjaScriptProperty]
		[Display(Name="Minutes label", Order=20, GroupName="Parameters")]
		public string pMinutesLabel		{ get; set; }
		[NinjaScriptProperty]
		[Display(Name="Minutes adjuster", Description="Number of minutes (positive or negative) to adjust to the output", Order=30, GroupName="Parameters")]
		public int pMinutesAdjuster		{ get; set; }
		[NinjaScriptProperty]
		[Range(60,int.MaxValue)]
		[Display(Name="Threshold for minutes", Description="Second counts above this threshold will be converted to minutes", Order=40, GroupName="Parameters")]
		public int pThresholdForMinutes		{ get; set; }
		#endregion

	}
}
